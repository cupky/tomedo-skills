# Kommando-Bibliothek für Prompts

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

> Vollstaendige Kommando- und Konfigurator-Syntax: Skill `tomedo-kommandos`. Hier stehen nur die fuer KarteiChat-Prompts erprobten Kommandos.

---

Kopierfertige Anker. Vollständige Syntax und Konfiguratoren: Skill `tomedo-kommandos`.

## B.0 Pflichtschritt vor jedem Produktiveinsatz

**Jedes** Kommando einzeln in den KarteiChat einfügen und prüfen, ob ein plausibler Wert erscheint. Ein `-` oder ein leerer String sieht wie ein legitimer Leerwert aus und fällt im laufenden Betrieb nicht auf — genau so ist ein ganzer Testlauf entwertet worden. Status: **belegt**.

## B.1 Stammdaten

| Kommando | Liefert | Status |
|---|---|---|
| `$[&p.alter]$` | Alter in Jahren | belegt |
| `$[&p.geschlecht]$` | m / w / d | belegt |
| `$[beruf]$` | Beruf | belegt |
| `$[kasse_name]$` | Kasse (Logik Privat/Gesetzlich) | plausibel |
| `$[&p.versicherungsart]$` | GKV / PKV | plausibel |
| `$[d G MN]$` | Geburtsdatum formatiert | belegt |
| `$[d S MN]$` | Systemdatum | belegt |

## B.2 Diagnosen — der wichtigste Anker

Im Diagnosetext der Kartei sind ICD-Codes häufig **nicht** sichtbar. Für den Chat existieren sie dann nicht. Genau dafür ist dieser Anker da.

```
$[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$
```
Alle aktiven Dauerdiagnosen mit vorangestelltem ICD-Code. Status: **belegt** (Briefkontext).

```
$[x DIA+DDI _ _ _ NN NNNN NNNN ICDvorn K _]$
```
Alle ICD-Codes aus Diagnosen und Dauerdiagnosen. Status: **belegt** (Briefkontext).

> Das Ausgabeformat steht im **g₁**-Slot (`ICDvorn`, `nurAktiveDiagnosen`, aneinanderhängbar). `UD` an dieser Stelle gibt **keinen** Code aus. Bei Testdaten ohne Code bleibt der Fehler unsichtbar — an einem Patienten mit echt codierter Diagnose verifizieren.

## B.3 Daten und Volltexte je Eintragstyp

| Kommando | Liefert | Status |
|---|---|---|
| `$[d E MN <TYP>]$` | Datum des letzten Eintrags dieses Typs | belegt |
| `$[d E MN <TYP> -1]$` | Datum des vorletzten Eintrags | plausibel |
| `$[karteiEintragWert <TYP> eintrag _ N]$` | Volltext des letzten Eintrags | belegt |
| `$[karteiEintragWert <TYP> datum dd.MM.yyyy N]$` | Datum, frei formatiert | belegt |
| `$[x <TYP> 1 _ _ NN NJ22 NNND _ _ _]$` | Neuester Eintrag, Datum vorangestellt | belegt |
| `$[x <TYP> 10 _ _ NN NJ22 NNND _ _ _]$` | Die 10 neuesten, datiert | belegt |
| `$[x <TYP> 10 _ _ JN NJ22 NNND _ _ _]$` | Die 10 **ältesten**, datiert | belegt |

Merkregeln: **d₁d₂** steuert die Auswahlrichtung (`NN` = neueste zuerst, `JN` = älteste zuerst), der Anzahl-Cap greift am vorderen Ende der Sortierung. `NJ22 NNND` stellt jedem Eintrag das Datum voran; `NNJN NNNN` gibt einen kumulativen Block ohne Datum. `invTime` im g₁-Slot dreht nur die **Anzeige**, nicht die Auswahl. Quartalsfenster (`4q`) sind undokumentiert — bei „Export endet in einem alten Jahr" Arg 3 auf `_` stellen und über den Anzahl-Cap begrenzen.

## B.4 CKE- und Formularwerte

```
$[karteiEintragWert <CKE-Kürzel> customKarteiEintragEntries.<Variablenname> _ N]$
$[formularEintrag <PatF-Kürzel> <Feldname> 0]$
```

Zwei Fallstricke, beide **belegt**:
- `formularEintrag` matcht den Feldnamen **exakt**, inklusive Groß-/Kleinschreibung und Umlauten. Eine Umbenennung im Formular bricht das Kommando **still** — leeres Ergebnis, keine Fehlermeldung. Genau der Fall, den A.4 als gefährlichsten identifiziert.
- Bei Leerbefund immer zuerst die **Rohabfrage ohne `if`** absetzen: leer = Feld/Bogen fehlt · `{ZeileN=SpalteM}` = Matrixfeld, Mapping trifft nicht · nackte Zahl = kein Matrixfeld.

## B.5 Freitext-Scores per regex — der Übergangsweg

Wo ein Score nur im Fließtext steht, kann `regex` ihn deterministisch herausziehen:

```
$[regex PHQ-9[^0-9]{0,3}([0-9]{1,2}) x PSY -anzahlTreffer inf -trennsequenz ,_]$
```
→ liefert `4,5,8`. Status: **belegt** (09/2026, KarteiChat-Kontext).

**Grenzen, belegt:**
- Ausgabe ist **undatiert** und neueste-zuerst. Datum und Wert lassen sich in einem Treffer **nicht paaren** — ein Score-**Verlauf** ist per Kommando nicht rekonstruierbar.
- Das Muster darf **keine Leerzeichen** enthalten; `_` steht für ein Leerzeichen im Parameterwert.
- Regex bricht an jeder Schreibvariante. Für dauerhafte Auswertbarkeit führt kein Weg an CKE oder PatF-Feld vorbei — regex ist Übergang, nicht Ziel.

## B.6 Praxiseigene Typkürzel für Typdefinitions-Blöcke

Karteieintragstypen sind **je Praxis verschieden** — Kürzel, Bezeichnung und Zuschnitt.
Ein Typdefinitions-Block muss deshalb einmal je Installation erhoben werden; abgeschrieben
funktioniert er nicht. Erhebung über Admin → Karteieintragstypen oder probeweise über
`$[x <Kürzel> 1 …]$` gegen eine Testakte.

| Fachlich | Kürzel | Bezeichnung im Chat |
|---|---|---|
| Ärztliche Verlaufsbeurteilung | `<KÜRZEL>` | `<Bezeichnung>` |
| Ärztlicher Kurzkontakt / Intervention | `<KÜRZEL>` | `<Bezeichnung>` |
| Fachspezifische Verlaufskontrolle | `<KÜRZEL>` | `<Bezeichnung>` |
| Physiotherapie-Verlauf / -Erstbefund | `<KÜRZEL>` | `<Bezeichnung>` |
| Psychotherapie-Verlauf | `<KÜRZEL>` | `<Bezeichnung>` |
| Dauerdiagnose | `<KÜRZEL>` | `<Bezeichnung>` |
| Eingehende Fremdpost | `<KÜRZEL>` | `<Bezeichnung>` |
| Ausgehender Bericht | `<KÜRZEL>` | `<Bezeichnung>` |

> ⚠️ **Zwei Fallen beim Ausfüllen.** Erstens können **mehrere Kürzel unter derselben
> Bezeichnung** erscheinen — an der Referenzinstallation liefen drei Therapiezeilen-Typen
> aus verschiedenen Epochen alle unter „Therapie". Zweitens sieht der Chat die
> **Bezeichnung**, nicht das Kürzel: Für Typdefinitions-Blöcke gehört die rechte Spalte in
> den Prompt. Ob ein Kürzel überhaupt auflöst, vor dem Produktiveinsatz einmal prüfen — in
> einer Demoumgebung löste keines der geprüften Kürzel auf.

---
