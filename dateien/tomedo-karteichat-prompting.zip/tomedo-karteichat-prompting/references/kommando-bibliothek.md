# Kommando-Bibliothek für Prompts

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

> Vollstaendige Kommando- und Konfigurator-Syntax: Skill `tomedo-kommandos`. Hier stehen nur die fuer KarteiChat-Prompts erprobten Kommandos.

---

Kopierfertige Anker. Vollständige Syntax und Konfiguratoren: Skill `tomedo-kommandos`.

## B.0 Pflichtschritt vor jedem Produktiveinsatz

**Jedes** Kommando einzeln in den KarteiChat einfügen und prüfen, ob ein plausibler Wert erscheint. Ein `-` oder ein leerer String sieht wie ein legitimer Leerwert aus und fällt im laufenden Betrieb nicht auf — genau so ist ein ganzer Testlauf entwertet worden. Status: **belegt**.

Das Eingabefeld löscht ein Kommando, das sich nicht auflösen lässt, ganz aus dem Text; ein `-` liefert
das Kommando selbst (z. B. `d` ohne Treffer), ein Text „Fehler: Keypath …“ ein falscher KeyPath [ungeprüft]. Alle drei
sehen im fertigen Prompt unauffällig aus.

## B.1 Stammdaten

| Kommando | Liefert | Status |
|---|---|---|
| `$[&p.alter]$` | Alter in Jahren (geht ohnehin mit jeder Anfrage an den Chat [ungeprüft]) | belegt |
| `$[patient_geschlecht]$` | männlich / weiblich (Langtext) | belegt |
| `$[beruf]$` | Beruf | belegt |
| `$[kasse_name]$` | Kasse (Logik Privat/Gesetzlich) | plausibel |
| `$[patient_versichertenstatus]$` | privat / gesetzlich | plausibel |
| `$[d G MN]$` | Geburtsdatum formatiert | belegt |
| `$[d S MN]$` | Systemdatum | belegt |

> **Berichtigt:** Hier standen bis Fassung 1.5 `$[&p.geschlecht]$` („belegt“) und `$[&p.versicherungsart]$`.
> Nach aktuellem Stand lösen beide **nicht** auf: Der Patient hat diese Attribute
> nicht, das Geschlecht liegt in den Patientendetails. Eingabefeld und `run_briefkommando` nutzen denselben
> Interpreter wie der Brief; heraus kommt der Text „Fehler: Keypath p.geschlecht konnte nicht aufgelöst
> werden!“. `run_briefkommando` meldet das nicht als unaufgelöst, das Modell nimmt das Geschlecht dann aus
> der Akte — die Antwort stimmt, der Anker war trotzdem kaputt. So kann ein Fehlschlag wie ein Beleg
> aussehen. Für das frühere „belegt“ gibt es keine Testspur; in der Oberfläche ist es noch nicht
> nachgemessen. Darum B.0: das Kommando **allein** einfügen und den aufgelösten Text lesen.

## B.2 Diagnosen — der wichtigste Anker

Im Diagnosetext der Kartei sind ICD-Codes häufig **nicht** sichtbar. Für den Chat existieren sie dann nicht. Genau dafür ist dieser Anker da.

```
$[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$
```
Alle aktiven Dauerdiagnosen mit vorangestelltem ICD-Code. Status: **belegt** (Briefkontext).

```
$[x (DIA;DDI) _ _ _ NN NNNN NNNN ICDvornauchAbgesetzteDiagnosen K _]$
```
Alle ICD-Codes aus Diagnosen und Dauerdiagnosen, als eine gemischte Gruppe. Status: **[ungeprüft]**.

> **Berichtigt:** Bis Fassung 1.6 stand hier `$[x DIA+DDI _ _ _ NN NNNN NNNN ICDvorn K _]$` („belegt“).
> tomedo wertet das `+` nicht aus — `DIA+DDI` gilt als ein unbekanntes Kürzel und liefert leer; ohne
> `auchAbgesetzteDiagnosen` fehlen zudem ältere Akutdiagnosen. Schreibweise wie im Skill `tomedo-kommandos`.

> Das Ausgabeformat steht im **g₁**-Slot (`ICDvorn`, `nurAktiveDiagnosen`, aneinanderhängbar). `UD` an dieser Stelle gibt **keinen** Code aus. Bei Testdaten ohne Code bleibt der Fehler unsichtbar — an einem Patienten mit echt codierter Diagnose verifizieren.

## B.3 Daten und Volltexte je Eintragstyp

| Kommando | Liefert | Status |
|---|---|---|
| `$[d E MN <TYP>]$` | Datum des letzten Eintrags dieses Typs | belegt |
| `$[d E MN <TYP> -2]$` | Datum des vorletzten Eintrags (leer und `-1` = jüngster, `-2` = vorletzter, `0` = ältester; bis Fassung 1.6 stand hier `-1`) | [ungeprüft] |
| `$[karteiEintragWert <TYP> text _ N]$` | Volltext des letzten Eintrags (bis Fassung 1.6 stand hier der Schlüssel `eintrag`, den es nicht gibt — Ergebnis leer) | [ungeprüft] |
| `$[karteiEintragWert <TYP> datum dd.MM.yyyy N]$` | Datum, frei formatiert | belegt |
| `$[x <TYP> 1 _ _ NN NJ22 NNND _ _ _]$` | Neuester Eintrag, Datum vorangestellt | belegt |
| `$[x <TYP> 10 _ _ NN NJ22 NNND _ _ _]$` | Die 10 neuesten, datiert | belegt |
| `$[x <TYP> 10 _ _ NN NJ22 NNND invTime _ _]$` | Die 10 **ältesten**, datiert | [ungeprüft] |

Merkregeln, berichtigt [ungeprüft]: Die **Auswahl** steuert `invTime` an Position 8 — damit
wird **vor** dem Anzahl-Deckel aufsteigend sortiert, es kommen also die **ältesten** n; ohne `invTime` die neuesten.
Position 5 (`NN`/`JN`) schaltet nur den Fettdruck in Word-Vorlagen und ändert die Auswahl nicht. Das deckt sich mit der
gemessenen `invTime`-Falle in `SKILL.md`. Bis Fassung 1.6 stand hier „`JN` = älteste zuerst, `invTime` dreht nur die
Anzeige“. `NJ22 NNND` stellt dem Text das Datum voran (eine Datumszeile je Tag); `NNJN NNNN` gibt einen kumulativen
Block ohne Datum. Vollständige Parameter: Skill `tomedo-kommandos`. Quartalsfenster (`4q`) — bei „Export endet in einem
alten Jahr" Arg 3 auf `_` stellen und über den Anzahl-Cap begrenzen.

## B.4 CKE- und Formularwerte

```
$[karteiEintragWert <CKE-Kürzel> customKarteiEintragEntries.<Variablenname> _ N]$
$[formularEintrag <PatF-Kürzel> <Feldname> N]$
```

> **Berichtigt:** Bis Fassung 1.6 stand bei `formularEintrag` als letztes Argument `0`. Tatsächlich ist `0` eine
> Zeitspanne von null Tagen — es kommen nur **heute** ausgefüllte Bögen [ungeprüft]. Für den jüngsten Bogen `N`.

Zwei Fallstricke, beide **belegt**:
- `formularEintrag` matcht den Feldnamen **exakt**, inklusive Groß-/Kleinschreibung und Umlauten. Eine Umbenennung im Formular bricht das Kommando **still** — leeres Ergebnis, keine Fehlermeldung. Genau der Fall, den A.4 als gefährlichsten identifiziert.
- Bei Leerbefund immer zuerst die **Rohabfrage ohne `if`** absetzen: leer = Feld/Bogen fehlt · `{ZeileN=SpalteM}` = Matrixfeld, Mapping trifft nicht · nackte Zahl = kein Matrixfeld.

## B.5 Freitext-Scores per regex — der Übergangsweg

Wo ein Score nur im Fließtext steht, kann `regex` ihn deterministisch herausziehen:

```
$[regex PHQ-9[^0-9]{0,3}([0-9]{1,2}) x PSY -anzahlTreffer inf -trennsequenz ,_]$
```
→ liefert `4,5,8`. Status: **belegt** (09/2026, KarteiChat-Kontext).

**Grenzen, belegt:**
- Ausgabe ist **undatiert** und neueste-zuerst. Datum und Wert lassen sich in einem Treffer **nicht paaren** — ein Score-**Verlauf** ist per Kommando nicht rekonstruierbar.
- Das Muster darf **keine Leerzeichen** enthalten; `_` steht für ein Leerzeichen im Parameterwert.
- Regex bricht an jeder Schreibvariante. Für dauerhafte Auswertbarkeit führt kein Weg an CKE oder PatF-Feld vorbei — regex ist Übergang, nicht Ziel.

## B.6 Praxiseigene Typkürzel für Typdefinitions-Blöcke

Karteieintragstypen sind **je Praxis verschieden** — Kürzel, Bezeichnung und Zuschnitt.
Ein Typdefinitions-Block muss deshalb einmal je Installation erhoben werden; abgeschrieben
funktioniert er nicht. Erhebung über Admin → Karteieintragstypen oder probeweise über
`$[x <Kürzel> 1 …]$` gegen eine Testakte.

| Fachlich | Kürzel | Bezeichnung im Chat |
|---|---|---|
| Ärztliche Verlaufsbeurteilung | `<KÜRZEL>` | `<Bezeichnung>` |
| Ärztlicher Kurzkontakt / Intervention | `<KÜRZEL>` | `<Bezeichnung>` |
| Fachspezifische Verlaufskontrolle | `<KÜRZEL>` | `<Bezeichnung>` |
| Physiotherapie-Verlauf / -Erstbefund | `<KÜRZEL>` | `<Bezeichnung>` |
| Psychotherapie-Verlauf | `<KÜRZEL>` | `<Bezeichnung>` |
| Dauerdiagnose | `<KÜRZEL>` | `<Bezeichnung>` |
| Eingehende Fremdpost | `<KÜRZEL>` | `<Bezeichnung>` |
| Ausgehender Bericht | `<KÜRZEL>` | `<Bezeichnung>` |

> ⚠️ **Zwei Fallen beim Ausfüllen.** Erstens können **mehrere Kürzel unter derselben
> Bezeichnung** erscheinen — an der Referenzinstallation liefen drei Therapiezeilen-Typen
> aus verschiedenen Epochen alle unter „Therapie". Zweitens sieht der Chat die
> **Bezeichnung**, nicht das Kürzel: Für Typdefinitions-Blöcke gehört die rechte Spalte in
> den Prompt. Ob ein Kürzel überhaupt auflöst, vor dem Produktiveinsatz einmal prüfen — in
> einer Demoumgebung löste keines der geprüften Kürzel auf.
>
> **Nach aktuellem Stand** bekommt die Kartei-Recherche bei Karteieinträgen nur das **Kürzel**
> und kann gezielt nach Kürzeln filtern [ungeprüft]. Die Beobachtung „der Chat sieht die Bezeichnung“
> stammt vermutlich vom früheren Abrufweg. Bis das in der eigenen Version gemessen ist: in Typdefinitionen
> **beide Spalten** nennen („Einträge vom Typ Therapie (THE)“).

---
