# Testprotokoll

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

Für jeden neuen Prompt, der produktiv gehen soll.

1. **Erwartungsanker vorab notieren** — Sollwert plus Fundstelle, **vor** dem ersten Lauf. Ohne das ist nach drei Läufen nicht entscheidbar, ob eine Abweichung ein Modellfehler oder eine Fehlannahme des Auswerters ist.
2. **Anker-Auflösungsprobe** — jedes Kommando einzeln (B.0).
3. **Aufgelösten Prompt-Text sichern**, bevor abgesendet wird. Sonst ist der Ankerwert im Nachhinein nicht auditierbar.
4. **Zwanzig Läufe für alles Produktionskritische**, drei nur zur Orientierung. Siehe „Serienumfang" unten — drei Läufe hätten in 376 Läufen **keinen** der drei belegten Ausfallmodi gefunden.
5. **Eine Variable pro Prompt-Variante.** Guard und Typdefinition getrennt zuschalten, sonst ist die Wirkung nicht zuzuordnen.
6. **Prompts absichtlich einfach halten.** Ein komplexer Prompt scheitert an der Prompt-Komplexität, und man schreibt es dem Kontext zu.
7. **Gegen die Anker auswerten**, nicht gegen den Eindruck. Reproduzierbar falsch ist gefährlicher als streuend falsch — es besteht jede Stichprobe.

---

## Ground Truth zuerst, Läufe danach

**Vor dem ersten Lauf den Volltextexport der Testakte ziehen.** In tomedo: Kartei exportieren,
das ZIP enthält `Kartei.docx` plus alle Anlagen als PDF.

```bash
textutil -convert txt Kartei.docx
pdftotext -layout anlage.pdf anlage.txt
```

**Warum das nicht optional ist.** In der Benchmark waren **vier** Soll-Angaben zweier
sorgfältig gebauter Testdrehbücher falsch — **alle vier zu Lasten des Chats**. Einmal stand ein
erwarteter Wert in einem anderen Eintrag als angenommen (Abweichung: fast zwei Jahre), einmal
war eine als „erfunden" angeklagte Zahl wörtlich in der Akte belegt. **Ein Testprotokoll ohne
Ground Truth misst die Erinnerung des Autors, nicht das Werkzeug.**

## Doppelte Auswertung bei Anlagenbezug

Jede Faktenfrage **getrennt** werten: einmal gegen den Karteitext, einmal gegen Karteitext
**plus** Anlagen. Ohne diese Trennung erscheint der Faktenblock als 96-Prozent-Aufgabe, obwohl
kein einziger Lauf die ganze Akte trifft.

## Serienumfang

| Zweck | Läufe |
|---|---|
| Orientierung: läuft der Prompt grundsätzlich? | 3 |
| Aussage über Zuverlässigkeit | **20** |
| A/B-Vergleich zweier Prompt-Varianten | 20 je Arm |

**Drei Läufe reichen nicht.** In 376 Läufen hätte eine Dreierserie gefunden:

| Ausfallmodus | Häufigkeit | von 3 Läufen gefunden |
|---|---|---|
| Anlagen-Leser läuft nicht an | 10 von 65 · 15 % | unwahrscheinlich |
| Faktenblock-Totalverweigerung | 1 von 20 · 5 % | nein |
| erfundene Fundstelle | 1 von 20 und 1 von 18 | nein |
| einziger Lauf, der einen Aktenwiderspruch bemerkt | 1 von 20 | nein |

## Ein Serienergebnis ist an einen Zeitpunkt gebunden, nicht an das Werkzeug

Dieselbe Akte, derselbe Prompt, derselbe Tag — zwei Serien im Abstand von zweieinhalb Stunden:

| | früh (25 Läufe) | spät (20 Läufe) |
|---|---|---|
| stille Falschaussagen | 3 | **0** |
| Erfindungen | 1 | 0 |
| Läufe, die ihre Grenze **benennen** | 0 | **2** |

Das Fehlerprofil hat sich **innerhalb eines Vormittags** verschoben.

> **Wer eine Quote zitiert, nennt den Zeitpunkt dazu.** Und die Modellkennung, soweit
> ermittelbar — welches Modell antwortet, ist über den Hersteller-Support konfigurierbar.

## Maschinelle Gegenprobe statt Sichtprüfung

Ob ein Lauf zu einer Ablage in der Kartei geführt hat, ist per SQL belegbar statt per
Hinsehen — `karteieintrag.autoquelle` für den Eintrag, `llmcall` für den Aufruf. Siehe
`SKILL.md`, Abschnitt „Zwei DB-Spuren machen Testläufe prüfbar".

**Eine Erfolgsmeldung des Chats ist kein Nachweis.** Belegt: „erfolgreich erstellt,
einschließlich Anhang" — die Datei war nicht in der Akte.

---
