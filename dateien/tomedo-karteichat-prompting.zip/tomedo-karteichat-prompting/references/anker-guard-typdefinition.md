# Die drei Prompt-Bausteine

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

Der Kern dieses Skills. Ein produktionsreifer KarteiChat-Prompt hat bis zu drei Bausteine, in dieser Reihenfolge.

## A.1 Anker — harte Werte aus Briefkommandos

**Briefkommandos werden im KarteiChat-Eingabefeld aufgelöst.** Etwa eine Sekunde nach dem Einfügen des Prompt-Textes steht anstelle von `$[…]$` der Klartextwert aus der Datenbank. Erst danach wird abgesendet. Damit lässt sich eine Tatsache **vorgeben**, statt sie das Modell aus dem Karteitext erschließen zu lassen. Status: **belegt** (09/2026, mehrfach).

> ⚠️ **Diese Aussage ersetzt die frühere Skill-Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat".** Die alte Regel war falsch und ist entfernt.

Ein Anker bringt einen **Wert** mit, keine **Bedeutung**. Was daneben als Beschriftung steht, prüft niemand — und das ist die Hauptfehlerquelle (A.4).

## A.2 Guard — der Satz, der dem Anker die Unantastbarkeit nimmt

Ohne Guard behandelt das Modell einen vorgegebenen Wert als letztes Wort, auch gegen die Aktenlage. Der Guard-Block gehört in **jede** Vorlage mit Ankern:

```
Die Angaben oben stammen aus einzelnen Feldern und können veraltet oder leer sein.
Prüfe sie gegen die Kartei. Weiche ab, wenn die Kartei etwas anderes zeigt, und
benenne die Abweichung. Ein leeres Feld bedeutet nicht, dass es den Sachverhalt
nicht gibt.
```

**Wirkung, belegt:**
- Leerfeld-Kollaps: **3/3 repariert** — das Modell geht in den Fließtext und nennt alle Fundstellen.
- Falsch beschrifteter Anker: **1/3** — der systematische Fehler wird zur Streuung. Reicht allein nicht.
- Der Guard erzeugt die Abweichungsmeldung, die einen Vorlagenfehler überhaupt sichtbar macht. In einem Lauf hat er den falschen Anker selbst angezeigt.

Der Guard ist der billigste Qualitätsgewinn im ganzen Skill: vier Zeilen, kein Pflegeaufwand.

## A.3 Typdefinition — die entscheidende Variable

Der Guard sagt „glaub dem Wert nicht". Er sagt **nicht**, was stattdessen der richtige Wert wäre. Das Modell muss dann selbst entscheiden, was ein Fachbegriff bedeutet — und biegt unterschiedlich ab. Die Definition liefert die fehlende Regel, ausgedrückt in **Karteieintragstypen**:

```
Ärztliche Kontakte sind Einträge der Typen Anamnese und Therapie. Einträge vom
Typ „Verlauf Physio" und „Verlauf Psychosomatik" sind keine ärztlichen Kontakte.
```

**Wirkung, belegt: 3/3 richtig — bei unverändert falsch beschriftetem Anker**, mit ausdrücklicher Benennung der Abweichung.

**Regel:** Wo eine Kennzahl über Karteieintragstypen definiert ist, gehört diese Definition in den Prompt. Was für eine Query gilt, gilt für einen Prompt. Der „echte Behandler"-Fallstrick reproduziert sich eine Ebene höher: das Typ-Label trägt die Disziplin, aber nur, wenn man sie ihm ausdrücklich zuordnet.

## A.4 Der belegte Fehlerkatalog

| Konstellation | Guard | Typdefinition | Ergebnis (3 Läufe) |
|---|---|---|---|
| Anker falsch beschriftet | – | – | **3/3 falsch**, identisch |
| Anker leer, Nebenfrage | – | – | **3/3 Recherche abgebrochen** („Feld leer" statt Antwort) |
| Anker löst nicht auf (`-`), Antwortslot | – | – | **3/3 falsch**, mit nächstplausiblem Wert gefüllt |
| Anker falsch beschriftet | ✓ | – | **1/3 richtig**, Streuung inkl. Systemdatum |
| Anker falsch beschriftet | ✓ | ✓ | **3/3 richtig**, Abweichung benannt |
| Kein Anker, Freitext-Extraktion | – | – | **3/3 vollständig richtig** |

Fünf Regeln, die daraus folgen:

1. **Ein falsch beschriftetes Kommando ist durch Prompting nicht reparierbar.** Die Beschriftung muss die Kommando-Semantik beschreiben, nicht die gewünschte. Reparatur gehört in die Vorlage, nicht in den Prompt.
2. **Begriffe definieren, nicht voraussetzen.** Wirksamster Einzelhebel: 1/3 → 3/3.
3. **Guard-Satz in jede Vorlage.** Schließt den Leerfeld-Kollaps zuverlässig.
4. **Leere Anker sind der gefährlichere Fall.** Sie sehen nach Vollständigkeit aus und werden lautlos gefüllt. Ein falscher Anker fällt irgendwann auf, ein leerer nie.
5. **Kein Anker ohne Auftrag.** Ein korrekter harter Wert („4,5,8") ohne begleitende Aufgabenstellung wurde zu „Es wurden 3 Elemente gezählt." Ein Wert im Prompt wird nicht durchgereicht, sondern interpretiert.

## A.5 Verankern oder nicht — die Entscheidungsregel

| Gebraucht wird | Weg |
|---|---|
| ICD-Codes, Stammdaten, Zahlen, Kassendaten | **Anker.** Aus dem Karteitext sind Codes oft nicht lesbar |
| Ein Datum, das über Eintragstypen definiert ist | **Typdefinition genügt**, Anker verzichtbar |
| Werte, die nur im Fließtext stehen (NRS, Gehstrecke, PHQ-9, MPSS) | **Kein Anker.** Freitext-Extraktion war 3/3 fehlerfrei — hier ist das Modell stark |
| Verläufe von Werten (Datum + Wert gepaart) | **Nicht kommandierbar.** Entweder LLM-Extraktion oder CKE/PatF anlegen |

---
