# Die LLM-Toolebene des KarteiChats

Was der Chat tatsaechlich kann, woher das belegt ist, und welche Grenzen der
Hersteller selbst zieht.

**Statuskennzeichnung mit Quellendatum.**
`[Hersteller, TT.MM.JJJJ]` = Onlinehilfe oder zollsoft-Aussage ·
`[Export, TT.MM.JJJJ]` = Tool-Export der eigenen Installation ·
`[Referenzinstallation, TT.MM.JJJJ]` = eigene Messung · `[plausibel]` = abgeleitet ·
**[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz an einer Testakte prüfen.

---

## 1 · Der Chat ist ein Agent, kein Modell mit vorgeladener Akte

Der KarteiChat entscheidet selbst, ob er die Kartei durchsucht, einen Anhang
liest oder etwas schreibt. Er tut das ueber ein Werkzeuginventar, das der
Client an das Modell uebergibt.

**Konsequenz fuers Prompting:** Ein Prompt steuert nicht nur den Text, sondern
auch die **Werkzeugwahl**. Die im Skill dokumentierte Ankerverengung ist genau
das — ein Volltext-Anker im Prompt laesst das Modell den History-Aufruf
ueberspringen, weil es die Frage schon beantwortet glaubt.

**Nach aktuellem Stand** [ungeprüft]: Der Systemprompt liegt auf dem tomedo-Server, nicht im
Client. Der Client schickt je Anfrage den ganzen bisherigen Verlauf, die neue Nachricht, die Werkzeugliste,
Produkt, Version und Sprache sowie vom Patienten nur **Geschlecht, Alter, Krankenkasse und Pflegegrad**.
Name, Geburtsdatum und das heutige Datum holt sich das Modell bei Bedarf über Werkzeuge
(`LLMToolRunBriefkommando`, `LLMToolDate`); in Karteitexten wird der Name des Patienten vor dem Versand
durch „Patient“ ersetzt. Der Verlauf liegt nur im Arbeitsspeicher, getrennt je Patient und Nutzer; „Chat
leeren“ oder ein Patientenwechsel brechen eine laufende Antwort ab.

---

## 2 · Inventar

### 2.1 Was der Export zeigte — und was er nicht ist

Export der Toolebene, 113 Eintraege, davon 112 benannt.
[Export, 13.09.2026 — tomedo v1.170.0.16]

Dieser Export ist **nicht** die Werkzeugliste eines Chats, sondern eine Aufzählung **aller**
Werkzeuge, die tomedo kennt, aus einem herstellerinternen Prüffenster [ungeprüft]. Er stammt aus einer
älteren Version: Namen wie `run_briefkommando`, `list_briefkommandos`, `Diagnosensuche`, `Dokument-Downloader`,
`erkenneVerordnung` und das Werkzeug `LLMToolCreateFormular` gibt es in der Fassung vom Oktober 2026 nicht mehr.

### 2.2 Was der KarteiChat anbietet [ungeprüft]

Stand Oktober 2026. Das Modell sieht die Werkzeuge unter diesen Namen; fragt man den Chat nach seinen
Werkzeugen, sollte er sie so nennen.

| Bereich | Werkzeuge |
|---|---|
| Kartei lesen | `LLMToolGetPatientsHistory` (Kartei-Recherche, §3), `LLMToolAttachmentAgent` (Anlagen), `LLMToolExtrahiereFormularAgent` (ausgefülltes Formular), `LLMToolListFormularTypes`, `LLMToolgetValidKarteiEintragTypen`, `LLMToolEPAGetMetaData`, `LLMToolEPAGetDocuments` (ePA), `LLMToolDate`, `LLMToolEcho` |
| Briefkommandos | `LLMToolListBriefkommandos`, `LLMToolRunBriefkommando`, `LLMToolMatchBriefkommandosAgent` |
| Kartei schreiben | `LLMToolCreateKarteieintrag`, `LLMToolEditKarteieintrag`, `LLMToolDiagnose` (Diagnose anlegen), `LLMToolCreateEBM`, `LLMToolCreateGOAE`, `LLMToolLaborImportAgent`, `LLMToolListFavoritLaborTests` |
| Praxisabläufe | `LLMToolCreateAufgabe`, `LLMToolCreateErinnerung`, `LLMToolCreateNachricht`, `LLMToolFillAndOpenFormularAgent` (Formular anlegen, befüllen, öffnen) |
| Text | `LLMToolGenerateContextText` (Kontexte des LLM-Textgenerators) |
| Sonstiges | `LLMToolExplainAbrechnungsfehlerAgent`, `LLMToolOpenPatientDetails`, `LLMToolListEntities`, `LLMToolSupportAgent` (startet die KI-Soforthilfe, §11) |
| nur unter Bedingungen | `LLMToolMedikamentInfoSearch` (Arzneimitteldaten, nur Deutschland), `LLMToolValmed` (nur mit Systemeinstellung), QM-Wiki-Suche (nur mit QM-Modul), Zahnarzt-Werkzeuge (nur Dental), Werkzeuge eigener **MCP-Server** (§12). AMBOSS ist seit 01.07.2026 abgeschaltet; das geführte Tutorial steht Praxen nicht zur Verfügung |

**Nicht** angeboten werden: eigene Werkzeuge für Diagnosen-, Labor- oder Medikationslisten (das
macht jetzt die Kartei-Recherche), das Kürzen des Verlaufs (`LLMToolTrimChat`), die Briefwerkzeuge
`LLMToolGenerateArztbrief`, `…Befundbericht`, `…Zusammenfassung` und das Anlegen chat-flüchtiger Briefkommandos
(gibt es nur in der Aktion „KI-Prompt“) [ungeprüft].

**Technische Eigenheit:** Alle Parameter gehen als Text an das Modell und sind formal Pflicht; Listen (z. B.
Suchbegriffe) werden als JSON-Text übergeben [ungeprüft].

## 3 · Die fuenf Tools, die das Prompting am staerksten praegen

### `LLMToolGetPatientsHistory` — die Kartei-Recherche

**Export 13.09.2026:** Durchsucht die Patientenhistorie (Dokumentation, Diagnosen, Leistungen, Briefe,
gespeicherte Formulare, Pfade zu Dateianhaengen); einziger Parameter ein optionales `minDate`; vor relativen
Zeitangaben das Datum bestimmen. [Export, 13.09.2026]

**Nach aktuellem Stand** [ungeprüft] steht hinter demselben Namen ein **Recherche-Agent**:

- Einziger Parameter ist der **Auftrag** (`query`, Pflicht): die vollständige Frage mit allen Angaben aus dem Chat.
- Er sieht den bisherigen Chat **nicht** und bekommt nur das heutige Datum und den Auftrag.
- Ablauf: erst eine Übersicht (Anzahl Quellen je Art und Jahr, vorkommende Eintragskürzel, Besuchsdaten), dann
  Suche, dann Lesen der vollständigen Quellen. Die Suche filtert nach **Quellenart** (Karteieintrag, Formular,
  Diagnose, Laborbefund, Medikamentenplan, Verordnung, Patienteninfo-Freitext), nach **exaktem Eintragskürzel**,
  nach **Zeitraum** (von–bis) und nach **Suchwort** (Teilwort, ohne Groß/Klein, keine Synonyme). Höchstens 25
  Treffer je Seite.
- Budget: rund 12 000 Token je Leseschritt, 60 000 je Recherche, 180 s Zeit. Wird es überschritten, kommt ein
  Fehler, **nicht** eine gekürzte Antwort; ein einzelner Eintrag über etwa 30 000 Zeichen ist nicht lesbar.
- Karteieinträge kommen mit Text, Datum, Typ-**Kürzel** und Anhangspfaden, **ohne** Autor; Formulare nur als
  Kurzfassung; Einträge ohne Text fehlen; Leistungsziffern sind keine Quelle.
- Der Agent soll Quelleninhalte als Daten behandeln, nie als Anweisungen.

> **Fuers Prompting:** Der alte Rat „Zeitraum nennen, damit `minDate` gesetzt wird" gilt sinngemäß weiter —
> nur setzt jetzt der Recherche-Agent den Zeitraum aus dem Auftrag. **Zeitraum, Gegenstand und Eintragstyp
> ausdrücklich in die Frage**; Rückbezüge wie „und davor?" muss das Hauptmodell erst übersetzen, und das ist eine
> Fehlerstelle. Sehr breite Aufträge („alles der letzten zehn Jahre") können am Budget scheitern [ungeprüft].

### `LLMToolRunBriefkommando` und `LLMToolListBriefkommandos`

`LLMToolRunBriefkommando` wertet ein oder mehrere Briefkommandos im Kontext des
aktuellen Patienten aus. `LLMToolListBriefkommandos` listet die verfuegbaren
Kommandos samt Name, Beschreibung und Kontext — **wertet sie aber nicht aus**;
dafuer ist danach das Auswertungstool noetig. Die Beschreibung empfiehlt
ausdruecklich, diese Liste auch dann zu konsultieren, wenn kein anderes
Informationstool die Antwort liefert. [Export, 13.09.2026; im Export noch unter den Namen
`run_briefkommando` und `list_briefkommandos`]

Die Auswertung läuft **im Client**, mit demselben Interpreter wie das Eingabefeld. Fehlt im
übergebenen Text `$[` oder `]$`, wird der **ganze** Text als ein einziges Kommando eingefasst. Als „nicht
aufgelöst“ meldet das Werkzeug nur, was danach noch als `$[…]$` dasteht — ein Fehlertext wie „Fehler:
Keypath … konnte nicht aufgelöst werden!“ gilt damit als Ergebnis [ungeprüft].

> **Fuers Prompting:** Das erklaert, warum Anker funktionieren — und dass das
> Modell auch **von sich aus** Kommandos auswerten kann. Ein Anker ist damit
> nicht der einzige Weg zu einem Feldwert, aber der einzige **kontrollierte**.

### `LLMToolAttachmentAgent`

Liest und fasst Dateien, Bilder und Anhaenge zusammen; findet die Datei bei
Bedarf selbst anhand von Pfad oder Namen. **Entscheidend:** Das Tool hat
*keinen* Zugriff auf den bisherigen Chat — alle relevanten Informationen muessen
ihm explizit mitgegeben werden. [Export, 13.09.2026]

Im KarteiChat ist es das **einzige** Anlagen-Werkzeug; Auflisten, Herunterladen (nur Einträge des
aktuellen Patienten) und Auslesen erledigt es intern [ungeprüft].

> **Fuers Prompting:** Bestaetigt die Kontextisolation der Sub-Agenten. Kein
> Verlass auf Vorwissen aus fruehen Turns. Wer einen Anhang auswerten laesst,
> muss die Frage im selben Auftrag vollstaendig formulieren.

### `LLMToolManagedObjectAgent` und die generische Objektebene

Der Agent legt Core-Data-Objekte an, sucht und aendert sie — er kennt
die verfuegbaren Datentypen, fragt Pflichtangaben per Formular ab und schreibt
tatsaechlich in die Datenbank. Die Beschreibung weist das Modell explizit an,
solche Aufgaben **nicht selbst herzuleiten**, sondern zu delegieren. Auch
dieser Agent sieht den bisherigen Chatverlauf nicht. Was erzeugt werden darf, steuert eine generierte Registry;
ohne hinterlegte Signatur darf eine Entitaet nicht per LLM erstellt werden. [Export, 13.09.2026]

**Nach aktuellem Stand** [ungeprüft]:

- Im KarteiChat ist der Agent **nicht direkt** da, nur mittelbar über die KI-Soforthilfe (§11).
- Erzeugbar sind nur: eigene EBM- und GOÄ-Katalogeinträge, Früherkennungsregeln, Nutzer, KI-Tutorials (alle nur
  für Administratoren) sowie **Aktionsketten, Aktionsketteneinträge (rund 85 Arten, darunter AppleScript, E-Mail,
  SMS, KI-Prompt), Bedingungen und Auslöser** (mit dem jeweiligen Verwaltungsrecht).
- **Patienten** sind ausdrücklich ausgeschlossen (weder anlegen noch suchen noch ändern), obwohl die Beschreibung
  sie nennt. Karteieinträge, CKE, Textbausteine, Formulare und Statistiken stehen nicht in der Registry.
- Anlegen fragt vorher nach; das **Ändern eines Feldes** eines solchen Objekts speichert **ohne** Rückfrage.

> ⚠️ **Fuer Prompts heisst das weiterhin:** jede Formulierung, die als Auftrag zum Anlegen oder Aendern lesbar
> ist, kann schreiben — direkt (§3, Karteieinträge) oder über den Umweg KI-Soforthilfe. Abfrage-Prompts
> entsprechend formulieren. [plausibel]

### `LLMToolCreateKarteieintrag` und `LLMToolEditKarteieintrag`

Beide Beschreibungen enthalten dieselbe Auflage: Der uebergebene Inhalt darf
**keine Quellenverweise mehr enthalten** (Form `[1235, &diag1224…]`).
`EditKarteieintrag` ersetzt den Inhalt **vollstaendig**; Typ und Datum bleiben.
Die ID stammt aus einer vorherigen Historienabfrage. [Export, 13.09.2026]

**Nach aktuellem Stand** [ungeprüft]: Die Quellenverweise werden nur per Beschreibung verboten, nicht technisch
entfernt. Anlegen geht **ohne** Rückfrage; Brief- und Diagnosetypen werden abgewiesen (Diagnosen legt
`LLMToolDiagnose` über eine Katalogauswahl an), Formular- und Labortypen an die passenden Agenten weitergereicht;
Markdown wird zu Formatierung. Ändern fragt vorher nach, gilt nur für Einträge des offenen Patienten, nur für
bearbeitbare Typen und höchstens **7 Tage** alte Einträge; bei CKE ändert es nur die genannten Felder. Beide
setzen die KI-Kennung (`KC`).

> **Fuers Prompting:** Wer einen Eintrag schreiben laesst, muss die
> Quellenmarker vorher entfernen lassen — sonst landen sie im Text oder der
> Aufruf scheitert. Und: „bearbeiten" heisst hier **ueberschreiben**, nicht
> ergaenzen.

---

#### Schreibpfad, am 22.09.2026 an einer synthetischen Akte verifiziert

Erstmals tatsaechlich ausgeloest und das Ergebnis in der Kartei nachgesehen.

| Frage | Befund |
|---|---|
| Schreibt er auf einen kombinierten Prompt? | **Nein.** „Filtere … und schreibe es danach in den Karteieintrag DOK" fuehrte **nur** zur Zusammenfassung. Lesen und Schreiben sind auf **Turn-Ebene** getrennt |
| Schreibt er auf einen eigenstaendigen Befehl? | **Ja.** „Erstelle einen Karteieintrag DOK mit dieser Information" legt an, Wortlaut woertlich |
| Landet er im geforderten Typ? | **Ja** |
| Nutzerzuordnung | **Angemeldeter Nutzer**, in `Doku` **und** `letzte Aenderung`. Nicht „tomedo" |
| Loeschbar | **Ja, ohne Storno** |
| Kennzeichnung als KI-erzeugt | ✦ in der Karteiliste, **abschaltbar**; in der Datenbank als `karteieintrag.autoquelle` |
| **Hochgeladene Datei als Anhang** | **landet nicht in der Akte** — obwohl der Chat „erfolgreich erstellt, mit Anhang" quittiert |
| Datei per Drag-and-drop lesen | **funktioniert**, zweiseitiges PDF vollstaendig und korrekt |

> **Eine Erfolgsmeldung des Chats ist kein Nachweis.** Der Schreibpfad ist genauso
> gegenzupruefen wie jede Fundstelle.

**Konsequenz fuer den Prompt-Bau.** Ein Prompt, der lesen **und** schreiben soll, tut nur
eines. Wer ablegen will, baut zwei Turns: erst erzeugen, dann in einem eigenen Turn den
Schreibbefehl. Das ist zugleich die Stelle, an der ein Mensch gegenliest — siehe
Checklistenpunkt 19.

**Offen:** ob das Anlegen eine Aktionskette oder eine Leistungsanlage ausloest. Bisher wurde
keine beobachtet, aber nicht aktiv geprueft. Dass ein hochgeladener Anhang nicht in der Akte landet, passt dazu: kein
Werkzeug des KarteiChats speichert Dateien in die Kartei [ungeprüft]. Und: **n=1.** Ein einziger Anlegevorgang ist fuer
eine Aussage ueber Zuverlaessigkeit zu wenig.

## 4 · Quellenverknuepfung als Verifikationsregel

Jede Information, die der Chat liefert, wird mit ihrer Quelle in der Kartei
verknuepft, dargestellt als Kuerzel in eckigen Klammern wie `[ANA]`; ein Klick
oeffnet den Eintrag. Der Hersteller leitet daraus eine Arbeitsregel ab: Laesst
sich eine Information **nicht** mit einer Quelle verknuepfen, muss der Nutzer
sie zusaetzlich verifizieren. [Hersteller, 11.09.2026]

Der Chat zeigt höchstens drei Quellen je Klammer, danach „+N weitere“; Einträge erscheinen als
Typ-Kürzel, Diagnosen als ICD-Code. Unbekannte oder fremde IDs verschwinden **still** aus dem Text; „Kopieren“
entfernt alle Marker [ungeprüft].

> **Einordnung.** Das ist die offizielle Halluzinations-Erkennungsregel und ein
> echter Gewinn. Sie ersetzt den Wiederhollauf aber **nicht**: Ein falsch
> zugeordneter Eintrag traegt ebenfalls eine Quellenangabe. Die belegte
> Konfabulationsklasse der Behandler-Attribution ist genau von dieser Art.
> [Referenzinstallation, 08.09.2026]

---

## 5 · Zweckbestimmung — die Grenze, die der Hersteller zieht

Der KarteiChat unterstuetzt beim **Auffinden vorhandener Informationen**. Er
dient ausdruecklich **nicht** der Unterstuetzung bei Diagnose und Therapie
durch Auswertung und Interpretation der vorhandenen Daten.
[Hersteller, 11.09.2026]

Fuer den Sprechstunden-Assistenten gilt dieselbe Abgrenzung.
[Hersteller, 11.09.2026]

| Prompt-Vorhaben | Innerhalb der Zweckbestimmung? |
|---|---|
| Wertabfrage, Verlaufszusammenfassung | ja |
| Fremdbefund in feste Rubriken ueberfuehren | ja |
| Gespraech in Anamnese, Befund, Therapie gliedern | ja |
| Mehrjahres-Akte zu einem Verlaufsnarrativ verdichten | **fraglich** — enthaelt Auswahl, Gewichtung, Kausalzuschreibung |
| Therapievorschlag ableiten | **nein** |

Keine Rechtsauskunft. Aber die Stelle, an der ein Prompt-Vorhaben eine
Begruendung braucht. [Referenzinstallation, 13.09.2026]

---

## 6 · Prompts als Textbausteine — Pflegeort und Grenze

**Pflegeort:** Verwaltung › **KI-Assistenten** › KI-Assistenten-Verwaltung, Bereich „Chat-Assistent“ › „Prompt“.
Dort liegt die Uebersicht aller als Prompt nutzbaren Textbausteine, samt Anlage
neuer Prompts, Schnell-Button-Anzeige und Buttonfarbe.
[Hersteller, 11.09.2026; die Onlinehilfe nannte das Untermenü „Sprechstunden-Assistent“, nach aktuellem Stand heißt es
„KI-Assistenten“ [ungeprüft]]

Alternativ ueber die Textbaustein-Makroverwaltung, Reiter **Sichtbarkeit**,
Freigabe getrennt fuer KarteiChat und Support-Chat. Die Einstellung gilt
**nutzeruebergreifend**. [Hersteller, 11.09.2026] In der KI-Assistenten-Verwaltung heißen die Freigaben
„Kartei-Chat“, „KI-Soforthilfe“ (= Support-Chat) und „Aktionsketteneintrag KI-Prompt“ [ungeprüft].

Der Platzhalter `___` laesst eine Stelle offen, an der vor dem Absenden
ergaenzt werden kann. [Hersteller, 11.09.2026] Daneben gilt **jeder Text in eckigen Klammern** ebenso als
Platzhalter [ungeprüft].

> ⚠️ **Herstelleraussage vom 11.09.2026:** Makros zur Auswahl von Karteieintraegen,
> Diagnosen oder Medikamenten sowie Frage-Antwort-Makros werden **nicht
> ausgefuehrt**, sondern als reiner Text an den Chatbot weitergereicht.
>
> **Nach aktuellem Stand** gilt das nur noch für die Aktion „KI-Prompt“ einer Aktionskette (dort
> werden aber `$[…]$` mit den Werten der laufenden Kette ersetzt). Im KarteiChat öffnet ein Schnell-Button
> oder das Kürzel im Eingabefeld den Frage-Antwort-Dialog, und `$[…]$` werden aufgelöst [ungeprüft]. Ein
> Frage-Antwort-Baustein ist als Chat-Prompt damit nutzbar — vor dem Einsatz in der eigenen Version testen.

> ⚠️ **Loeschen wirkt durch.** Ein in der Promptverwaltung geloeschter Eintrag
> loescht den **Textbaustein**. [Hersteller, 11.09.2026] Und zwar ohne Rückfrage; eine Aktion
> „KI-Prompt“, die ihn nutzt, wird danach mit Meldung übersprungen [ungeprüft].

---

## 7 · Modellwahl

Standardmaessig verwendet der KarteiChat ein Sprachmodell von Google Gemini.
**Bei Bedarf stehen andere Modelle zur Verfuegung; fuer einen Wechsel ist der
zollsoft-Support zu kontaktieren.** [Hersteller, 11.09.2026]

> **Widerrufen:** Die Annahme, im Chat entscheide eine Checkbox
> „experimentelle Features" zwischen Flash und Mistral, stammt aus einem
> Forumskommentar vom 17.10.2025 und ist ueberholt.

> **Widerrufen:** Die Skill-Formulierung „einfaches Gemini-Modell" ist keine
> Systemeigenschaft, sondern eine Voreinstellung. Vor jeder
> Modellgrenzen-Analyse pruefen, welches Modell tatsaechlich antwortet.

**Nicht ueber den Prompt steuerbar** — in keinem Pfad. Das Modell ist ein
Transportparameter, kein Inhalt. Ein Satz wie „antworte als Pro" bewirkt nichts.

**Nach aktuellem Stand** [ungeprüft]: Beim KarteiChat schickt der Client **kein** Modell mit — der
tomedo-Server wählt es. Die Seite „KI-Modelle“ der KI-Assistenten-Verwaltung ist ausgeblendet; den Anbieter stellt
nur der Hersteller ein (darunter ist auch ein lokales Modell über Ollama vorbereitet). Sub-Agenten wie die
Kartei-Recherche laufen mit eigener Modellvorgabe (Gemini 2.5 Flash). Die frühere Checkbox „experimentelle
Features“ schaltete übrigens Zusatzwerkzeuge, nicht das Modell. Welches Modell tatsächlich antwortet, bleibt
damit eine Frage an den Support.

### Was ein Modellwechsel bringt — gemessen

A/B-Messung am LLM-Service-Endpunkt, `gemini-2.5-flash` gegen `gemini-2.5-pro`,
je fuenf Laeufe, identischer Fachprompt ohne Personenbezug, Blindbewertung
nach sechs Kriterien. [Referenzinstallation, 13.09.2026]

| Kennzahl | Flash | Pro |
|---|---|---|
| Erfuellte Kriterien | 28 von 30 | 29 von 30 |
| Fachlich falsche Aussagen | 0 | 0 |
| Laengenspanne der Ausgaben | 2444 Zeichen | 142 Zeichen |
| Latenz, Mittel | 16,1 s | 16,6 s |
| Latenzspanne | 5,3 – 35,2 s | 15,2 – 17,6 s |
| Kosten je Lauf | 0,0008 $ | 0,0014 $ |

**Befund: kein Qualitaetssprung, sondern ein Konstanzsprung.** Beide Modelle
waren fachlich fehlerfrei; der Abstand von 29 zu 28 liegt bei n=5 im Rauschen.
Was Pro deutlich besser kann, ist Wiederholbarkeit — Ausgabelaenge und Latenz
streuen um eine Groessenordnung weniger.

**Der wichtigste Einzelbefund steht ausserhalb des Rasters:** Ein Flash-Lauf
erfuellte formal alle sechs Kriterien und **liess trotzdem einen von drei
geforderten Inhaltsbloecken komplett weg**, weil er die Rubriken anders
schnitt. Pro legte die Struktur in 5 von 5 Laeufen wie beabsichtigt aus, Flash
in 2 von 5 anders. [Referenzinstallation, 13.09.2026]

> **Fuers Prompting, zwei Lehren:**
> 1. **Strukturvorgaben muessen die Gliederungsachse benennen**, nicht nur die
>    Anzahl der Abschnitte. „Drei Rubriken" reicht nicht — es muss stehen,
>    **wonach** gegliedert wird.
> 2. **Vollstaendigkeit gehoert ins Pruefraster.** Ein Kriterienkatalog, der
>    nur Form und Fachlichkeit prueft, laesst fehlende Inhalte durch. Siehe
>    `testprotokoll.md`.

Latenz war **nicht** der erwartete Nachteil von Pro. Die aeltere
Hersteller-Aussage, Pro rechne durch staendiges Nachdenken sehr lange
[Hersteller, 18.09.2025], hat sich in dieser Messung nicht bestaetigt.

---

## 8 · Backlog: die generische Objektebene austesten

Der Export belegt, **dass** es die Tools gibt, nicht **wie weit** sie reichen. [Export, 13.09.2026]
Nach aktuellem Stand ist die Reichweite inzwischen eng umrissen (§3: Katalogeinträge, Nutzer, Früherkennungsregeln,
Tutorials, Aktionsketten samt Einträgen, Bedingungen und Auslösern; **keine** Patienten, Karteieinträge, CKE,
Textbausteine, Formulare, Statistiken) und im KarteiChat nur über die KI-Soforthilfe erreichbar [ungeprüft].

### Testreihe, gefahrlos und in dieser Reihenfolge

Nur in einer **Testinstanz**. Alle Schritte **lesend** beginnen. Erst wenn das Schema bekannt ist, schreiben —
und dann nur an einem Wegwerf-Objekt, nie an Katalogen oder Stammdaten.

| Nr. | Anfrage im Chat | Erwartung |
|---|---|---|
| G1 | Welche Entitaeten kannst du anlegen? | im KarteiChat nur mittelbar; die Liste oben [ungeprüft] |
| G2 | Zeige das Schema der Entitaet `<CKE-Typ>` | Schema ja, Anlegen nein (nicht in der Registry) [ungeprüft] |
| G3 | Gibt es eine Create-Signatur fuer `<Entitaet>`? | die eigentliche Schranke |
| G4 | Lege eine Test-Aktionskette mit einem Eintrag an | Rückfrage je Objekt, Verwaltungsrecht nötig [ungeprüft] |
| G5 | Aendere ein Feld dieses Testobjekts | **speichert ohne Rückfrage** [ungeprüft] |
| G6 | Lege einen Patienten an | **Ablehnung** [ungeprüft]. Fällt sie aus, ist das ein Befund für zollsoft |

### Warum das dringlich ist

Die Schreibfaehigkeit besteht **unabhaengig davon, ob wir sie nutzen**. Ein
Prompt, der als Anlege- oder Aenderungsauftrag lesbar ist, kann bereits heute
schreiben. Solange die Reichweite nicht gemessen ist, gilt:

> **Abfrage-Prompts duerfen keinen Satz enthalten, der als Auftrag zum Anlegen,
> Ergaenzen oder Aktualisieren lesbar ist.** Formulierungen wie „trage
> zusammen", „erfasse", „lege dar" sind harmlos gemeint und potenziell als
> Schreibauftrag lesbar. Sicher sind Frageformen und „nenne", „liste auf",
> „gib zurueck". [plausibel]

---

## 9 · Was das Inventar nicht verraet

- **Welches Modell** antwortet. Der Export enthaelt die Modellidentitaet nicht.
  [Export, 13.09.2026] Nach aktuellem Stand wählt es der Server (§7) [ungeprüft].
- **Wann der Bestaetigungsdialog** beim KI-Prompt in der Aktionskette erscheint.
  Dass er erscheinen kann und manuell zu bestaetigen ist, ist belegt
  [Hersteller, 11.09.2026]. Nach aktuellem Stand erscheint er je Werkzeugaufruf, der eine Rückfrage verlangt (§10)
  [ungeprüft].
- **Ob das Inventar installationsabhaengig ist.** Nach aktuellem Stand ja, in Grenzen: Land, Zahnarzt-Modus,
  QM-Modul, Valmed-Einstellung und eigene MCP-Server ändern die Liste (§2.2) [ungeprüft].

---

## 10 · Welche Aktionen vorher nachfragen [ungeprüft]

tomedo zeigt vor manchen Werkzeugaufrufen den Dialog „Zustimmung erforderlich – Der Kartei-Chat
möchte die folgende Aktion ausführen: …“ mit „Zustimmen“ und „Ablehnen“.

| mit Rückfrage | ohne Rückfrage |
|---|---|
| Karteieintrag ändern, Diagnose anlegen (nach Katalogauswahl), Aufgabe, Erinnerung, Nachricht; über die KI-Soforthilfe: Objekt anlegen, Ticket, Fernwartung | **Karteieintrag anlegen**, **EBM- und GOÄ-Ziffer anlegen** (Zahnarzt: BEMA, GOZ), Formular anlegen und befüllen (Sofortdruck-Formulare sind gesperrt), Werkzeuge eigener MCP-Server; über die KI-Soforthilfe: **Menüeintrag klicken**, Objektfeld ändern |

In der Aktion „KI-Prompt“ gilt dieselbe Liste; dort lautet der Absender „Aktionsketteneintrag KI-Prompt“.

> **Fuers Prompting:** Die Rückfrage ist kein Schutz gegen das Anlegen von Einträgen und Ziffern — genau die
> laufen ohne. Darum bleibt Checklistenpunkt 19: Lese-Prompts ohne schreibbaren Satz.

## 11 · KI-Soforthilfe im KarteiChat [ungeprüft]

Das Werkzeug `LLMToolSupportAgent` startet einen vollständigen Support-Chat (mit leerem Verlauf).
Dessen Werkzeuge sind damit aus dem KarteiChat **mittelbar** erreichbar: Menüeinträge klicken, Objekte anlegen und
ändern (§3), Aktionsketten bauen, Support-Tickets anlegen, Protokolle lesen, TI-Diagnose. Der Hersteller führt
das Werkzeug als Vorstufe („POC“). Für Prompt-Schreiber: Bedienfragen („wie stelle ich … ein“) können
dort landen; Patientendaten gehören nicht in solche Fragen.

## 12 · Eigene Werkzeuge per MCP-Server [ungeprüft]

Eine Praxis kann eigene Werkzeuge einbinden: KI-Assistenten-Verwaltung › „Erweitert“ ›
„MCP-Server“ (sichtbar, solange die zugehörige Systemeinstellung an ist — Standard: an). Ein Eintrag gilt
**praxisweit** (Adresse, Übertragungsart HTTP oder SSE, Zugangsdaten). Die Werkzeuge der eingetragenen Server
bietet der KarteiChat **direkt** an, **ohne Rückfrage je Aufruf**. Einrichten geht auch über die KI-Soforthilfe
(Speichern mit Rückfrage). Eine eigene Rechteprüfung für diese Verwaltung ist nicht bekannt.

> ⚠️ **Größter Hebel, größtes Risiko.** Ein MCP-Werkzeug bekommt, was das Modell ihm übergibt — auch
> Patientendaten. Nur Server einbinden, deren Betreiber und Datenweg datenschutzrechtlich geklärt sind, und vorher
> in einer Testinstanz prüfen.

---

*Erhoben 09/2026. Quellen: Tool-Export der eigenen Installation (113 Eintraege,
tomedo v1.170.0.16), Onlinehilfe tomedo Intelligence Stand 11.09.2026,
A/B-Messreihe am LLM-Service-Endpunkt vom 13.09.2026. Überarbeitet im Oktober 2026;
noch nicht in der Oberfläche nachgestellte Aussagen tragen [ungeprüft].*
