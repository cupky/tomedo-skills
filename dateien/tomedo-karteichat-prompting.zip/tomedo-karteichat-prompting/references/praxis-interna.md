# Praxis-Interna dieser Installation

**Diese Datei ist absichtlich leer ausgeliefert.** Sie ist der vorgesehene Ort für die
Aktenkennungen, Kürzel und Pflegestände **Ihrer** Installation. Der übrige Skill nennt
dieselben Sachverhalte generisch — mit einer Anleitung, wie Sie den eigenen Wert ermitteln.
Tragen Sie die Ergebnisse hier ein, dann arbeitet die KI mit Ihren Werten statt mit
Vermutungen.

**Warum getrennt:** So lässt sich der Skill weitergeben, ohne dass Praxisinterna mitwandern.

**Beim Aktualisieren:** Ein neues ZIP ersetzt beim Hochladen den ganzen Skill, auch diese
Datei — sie kommt wieder leer an. Wer sie ausgefüllt hat, sichert sie vorher und legt die
eigene Fassung vor dem Hochladen in das neue ZIP, an dieselbe Stelle
(`references/praxis-interna.md`).

**Nicht hierher gehören die gemessenen Quoten** aus `modellgrenzen-und-quellen.md`. Die sind
an synthetischen Demoakten erhoben und Teil des Skills.

**Erhebungsstand:** _(Datum eintragen)_

---

## 1 · Kommando-Inventur — welche Anker bei Ihnen tatsächlich tragen

**Das ist der wichtigste Abschnitt dieser Datei.** Ein Briefkommando ist so stark wie die
strukturierte Pflege Ihrer Akte. Ein Kommando, das ins Leere greift, liefert **lautlos
nichts** — und Ihr verankerter Prompt ist dann wieder ein unverankerter, ohne dass es jemand
merkt.

**So erheben Sie es:** `Admin › Kommandos` → Kommando anlegen oder auswählen →
**[Ausführen]** gegen eine echte Akte. Kein Briefvorlagen-Bau nötig, nichts wird gesendet.

Prüfen Sie mindestens diese, bevor Sie einen verankerten Baustein ausliefern:

| Kommando | Status | gelieferter Wert |
|---|---|---|
| `$[beruf]$` | | |
| `$[adressfeld_patient]$` | | |
| `$[x DDI …]$` Dauerdiagnosen | | |
| `$[x ANA 1 …]$` Anamnese | | |
| `$[x THE 3 …]$` Therapie | | |
| `$[medikamenteVorhanden]$` | | |
| `$[x MED …]$` · `$[x REZ …]$` Verordnungen | | |
| `$[medikamentenplan]$` | | |
| `$[x AU …]$` Arbeitsunfähigkeit | | |
| `$[x DIAX …]$` Freitextdiagnosen | | |
| `$[l]$` · `$[l_alle]$` Leistungen | | |
| `$[letzteLaborwerte 1]$` | | |
| `$[patientenTermine]$` | | |
| `$[x DIA …]$` Scheindiagnosen | | |

> ⚠️ **Tragen Sie bei `OK` auch den gelieferten Wert ein.** Der gefährlichste Fall ist nicht
> das leere Kommando, sondern die Kombination aus einer Prüfabfrage, die „Daten vorhanden"
> meldet, und einem Kommando, das trotzdem nichts liefert. Der Prompt läuft dann unverankert
> weiter, und niemand merkt es.

**Halten Sie fest, welche Datenklassen bei Ihnen strukturiert gepflegt sind.** Verankerte
Bausteine dürfen nur auf diese bauen.

> 💡 **Fahren Sie die Inventur ein zweites Mal, nachdem Sie etwas nachgepflegt haben.** An der
> Referenzinstallation stieg die Zahl der nutzbaren Datenklassen dadurch von zwei auf fünf —
> ohne dass sich am Chat etwas geändert hätte. Das Ergebnispaar ist das überzeugendste Argument
> für strukturierte Dokumentation, das sich im eigenen Haus zeigen lässt.

**Zwei Fallen, die Sie beim Ausfüllen kennen sollten:**

- **Tabellenerzeugende Kommandos lösen im Chat-Eingabefeld nicht auf.** `medikamentenplan` und
  `med` bleiben leer, auch wenn die Prüfabfrage `medikamenteVorhanden` den Wert 1 meldet. Der
  Umweg führt über den Karteieintragstyp, etwa `$[x MED …]$`.
- **`invTime` wählt vom Aktenanfang.** Bei kleinen Anzahlen bekommen Sie damit die ältesten
  statt der neuesten Einträge — und die Antwort des Chats sieht in beiden Fällen gleich
  souverän aus.

---

## 2 · Aktenkennungen Ihrer Testakten

| Akte | Nummer | Rolle |
|---|---|---|
| | | |

Verwenden Sie für Messreihen **synthetische** Akten. Achten Sie darauf, was im
Kurzinfo-/Patienteninfo-Feld steht: Der Chat liest dieses Feld, obwohl es nicht Teil des
Kartei-Exports ist, und mischt den Inhalt gelegentlich in Verdichtungen.

---

## 3 · Rollout- und Kontostand

| Befund | Wert bei Ihnen |
|---|---|
| Rollout des KarteiChat | |
| Testkonten, die keine Behandlerkonten sind | |
| Karteieinträge mit `autoquelle IS NOT NULL` | |

Solange nur Testkonten schreiben, verzerrt eine Auswertung je Behandler das Bild. Und solange
der einzige KI-Eintrag an einer Demoakte hängt, entfernt ihn die übliche Demo-Exklusion —
während der Testphase deshalb ohne Demo-Filter auswerten.

Die Query dazu steht in `tomedo-statistik-hql`, Query-Baustein „Maschinell erzeugte
Karteieinträge je Nutzer und Quartal".

---

## 4 · Eigene Messbefunde

Hierher gehört alles, was nur bei Ihnen gilt: eigene Typkürzel, abweichende
Karteieintragstypen, Besonderheiten Ihrer Dokumentationsdisziplin. Ein Muster je Befund:

### `<Gegenstand>`

_Messung vom TT.MM.JJJJ: …_

_Konsequenz für den Prompt-Bau: …_
