# Toolebene: Inventar und Prompt-Hebel

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

**Belegbasis, zwei Stände:**

1. Export der tomedo-LLM-Tool-Definitionen (`llm_tools_export.json`, 09/2026) — 112 Funktionsdefinitionen im
   OpenAI-Function-Calling-Format, plus ein leerer Platzhaltereintrag. Ausgewertet wurden Namen, Beschreibungen und
   Parameterschemata.
2. Überarbeitung im Oktober 2026. Aussagen, die noch nicht in der Oberfläche nachgestellt sind, tragen **[ungeprüft]**.

**Vorbehalt, der für die ganze Datei gilt:** Der Export ist eine Aufzählung **aller** Werkzeuge, die
tomedo kennt, nicht die Liste eines Chats, und er stammt aus einer älteren Version [ungeprüft]. Welche Werkzeuge der
KarteiChat im Stand Oktober 2026 anbietet, steht in `llm-toolebene.md` §2.2. Mehrere Werkzeuge dieser Datei gibt es dort
nicht mehr oder unter anderem Namen; das ist je Abschnitt vermerkt.

**Statuskennzeichnung** wie im Skill: **belegt** · **plausibel** · **zu evaluieren** · **[ungeprüft]**. Zusätzlich hier:
**dokumentiert** = steht so in der Tool-Beschreibung des Herstellers (Export), ist aber nicht von uns beobachtet.

---

## 1 · Der Kern in fünf Sätzen

Der KarteiChat ist kein Modell mit vorgeladenem Karteitext, sondern ein **Agent mit Werkzeugen** — die Akte kommt über
einen Werkzeugaufruf herein und liegt danach als Werkzeugergebnis in der Chat-Historie. Nach aktuellem Stand ist dieses
Werkzeug inzwischen eine eigene **Kartei-Recherche**: Sie bekommt einen Auftrag in Worten, sucht nach Quellenart,
Eintragskürzel, Zeitraum und Suchwort und liefert die gelesenen Originalquellen mit ihren IDs zurück — ohne den Chat
zu sehen [ungeprüft]. Quellenanker erscheinen als Hyperlinks, weil die IDs als `[1235]` bzw. `[&diag1224]` im Text
stehen. Für das Prompting folgt daraus ein Baustein neben Anker, Guard und Typdefinition: die **Werkzeuganweisung** —
dem Modell sagen, *was* es mit welchem Werkzeug holen soll; nach aktuellem Stand heißt das vor allem, den
**Rechercheauftrag** vollständig zu machen (Zeitraum, Quellenart, Eintragstyp). Anlagen erreicht nur das
Anlagen-Werkzeug.

---

## 2 · Tool-Inventar, für das Prompting relevanter Teil

### 2.1 Datenbeschaffung am Patienten

| Werkzeug | Liefert | Parameter | Aktueller Stand [ungeprüft] |
|---|---|---|---|
| `LLMToolGetPatientsHistory` | Export: Dokumentation, Diagnosen, Leistungen, Briefe, gespeicherte Formulare, Pfade zu Dateianhängen, Stammdaten | Export: nur `minDate` | Kartei-**Recherche** mit Auftrag `query`. Quellen: Karteieinträge (Text, Datum, Typ-Kürzel, Anhangspfade, kein Autor), Formulare (Kurzfassung), Diagnosen, strukturierte Laborbefunde, Medikamentenplan und Verordnungen (Deutschland), Patienteninfo-Freitext. **Keine** Leistungsziffern. Interne Filter: Quellenart, exaktes Eintragskürzel, Zeitraum, Suchwort |
| `Diagnosensuche` (Export) | Diagnosen chronologisch, neueste zuerst | `minDate` | im KarteiChat **kein eigenes Werkzeug** mehr; Diagnosen sind Quellen der Recherche (Quellenmarker zeigt den ICD-Code). Das gleichnamige Lesewerkzeug gibt es nur noch in der Aktion „KI-Prompt“ |
| `LLMToolGetPatientsMedicationHistory` | zwei Typen: `Medikamentenplan` („nicht zwingend vollständig") und `Verordnung`; dasselbe Präparat kann in beiden stehen | `minDate` | im KarteiChat herausgenommen; beide Typen sind Quellenarten der Recherche. Die Doppelzählung bleibt eine Fehlerquelle |
| `LLMToolGetPatientsLaborData` | Befunde mit Messwerten, Normbereichen, Auffälligkeiten | `minDate`, Testkürzel | im KarteiChat kein eigenes Werkzeug; Laborbefunde sind Quellen der Recherche. (In der Aktion „KI-Prompt“ wird das Testkürzel nicht ausgewertet) |
| `LLMToolAttachmentAgent` | liest und fasst PDF/Bild zusammen, gibt strukturierten Text | Auftrag, Dateiangabe | im KarteiChat das **einzige** Anlagen-Werkzeug; Auflisten und Herunterladen (nur Einträge des offenen Patienten) intern. **Kontextisoliert** (§5.7) |
| `LLMToolExtrahiereFormularAgent` | liest ein ausgefülltes Formular aus | ID des Karteieintrags mit dem Formular | unverändert vorhanden. Alternativer PatF-Auslesepfad ohne `$[formularEintrag …]$` |
| `LLMToolDate` | aktuelles Datum | – | Format nach Systemsprache, mit Uhrzeit. Erklärt „Systemdatum als Befund". Der Recherche gibt der Client das Datum selbst mit |
| `LLMToolEPAGetMetaData`, `LLMToolEPAGetDocuments` | Übersicht bzw. Inhalt von ePA-Dokumenten | Dokument-IDs | Quellenmarker `[&epadoc<N>]` |

### 2.2 Briefkommandos — drei verschiedene Pfade

| Pfad | Mechanik | Deterministisch? |
|---|---|---|
| **Eingabefeld-Auflösung** | Client löst `$[…]$` kurz nach der letzten Änderung auf (nach 0,3 s, nicht auflösbare werden gelöscht [ungeprüft]); der aufgelöste Wert geht als Text an das Modell | ja, und sichtbar prüfbar |
| **`LLMToolRunBriefkommando`** (im Export `run_briefkommando`) | Das **Modell** ruft ein Kommando im Patientenkontext auf und erhält das Ergebnis als Tool-Antwort. Mehrere Kommandos in einem String möglich. Im Client ausgewertet; fehlt `$[` oder `]$`, wird der ganze Text ein Kommando [ungeprüft] | nein — Modell wählt Kommando und Argumente |
| **`LLMToolCreateBriefkommando`** | Das Modell **erzeugt** ein Kommando mit Namen und Wert; es „besteht nur im Kontext des Chats (z.B. für die folgenden Einträge einer laufenden Aktionskette)". Nur in der Aktion „KI-Prompt“, nicht im KarteiChat [ungeprüft] | Wert ist Modelloutput |

Dazu `LLMToolListBriefkommandos` (im Export `list_briefkommandos`): listet Name, Beschreibung und Kontext aller
Kommandos, wertet sie ausdrücklich **nicht** aus.

Die Unterscheidung ist wichtig: Der Anker-Mechanismus des Skills beruht auf Pfad 1 und behält seine belegte
Zuverlässigkeit. Pfad 2 ist bequemer, verschiebt aber die Kommando-Wahl ins Modell — und damit in die Zone, für die der
Fehlerkatalog gilt. **Regel: Produktionskritische Werte über Pfad 1 verankern, Pfad 2 nur für Exploration und Tests.**

> **Nebennutzen für uns:** Pfad 2 macht den KarteiChat zum **Test-Harness für Kommando-Syntax** — Varianten von
> `$[formularEintrag …]$` oder `$[karteiEintragWert …]$` lassen sich am lebenden Patientenkontext durchprobieren, ohne
> eine Briefvorlage zu bauen. Achtung: Ein Fehlertext des Interpreters gilt dort als Ergebnis, nicht als Fehler
> [ungeprüft]. Siehe `tomedo-kommandos`.

### 2.3 Rückschreiben in die Akte

| Tool | Verhalten, das man kennen muss |
|---|---|
| `LLMToolCreateKarteieintrag` | Typ als Name **oder Kürzel** („Kürzel werden bevorzugt"), Datum defaultet auf heute; Existenz des Typs vorher prüfen → `LLMToolgetValidKarteiEintragTypen`. **Ohne Rückfrage**; Brief- und Diagnosetypen abgewiesen; Anhänge werden nie gespeichert [ungeprüft] |
| `LLMToolEditKarteieintrag` | ersetzt den Inhalt **vollständig**. ID „niemals raten". Mit Rückfrage, nur Einträge des offenen Patienten, höchstens 7 Tage alt; bei CKE nur die genannten Felder [ungeprüft] |
| `LLMToolDiagnose` | legt eine Diagnose über Katalogauswahl an (Suchbegriffe exakt aus der Nutzereingabe oder ICD-Code, bis 20 Vorschläge, Formular, dann Rückfrage) [ungeprüft] |
| `LLMToolFillAndOpenFormularAgent` | legt ein Formular an, befüllt es aus Akte und Nutzerangaben und öffnet es — ohne Rückfrage; Formulare mit Sofortdruck sind gesperrt [ungeprüft]. Ersetzt das Export-Werkzeug `LLMToolCreateFormular` („UNWIDERRUFLICH – GENAU EINMAL aufrufen"; Formular-ID als String), das es nach aktuellem Stand nicht mehr gibt |
| `LLMToolShowForm` | zeigt dem Nutzer ein Eingabeformular und liefert die Eingaben als JSON. Acht Feldarten (zusätzlich Suche, Mehrfachauswahl, Knöpfe), im KarteiChat nur innerhalb von Agenten [ungeprüft] |

**Durchgehende Konvention:** In den Schreibwerkzeugen steht jeweils, der Inhalt dürfe **keine Quellenverweise** der Form
`[1235, &diag1224…]` mehr enthalten. Das ist nur eine Anweisung an das Modell, kein Filter [ungeprüft].
Daraus folgt §5.5.

### 2.4 Textgenerierung — die Pfade

| Pfad | Tool | Input | Kartei-Zugriff |
|---|---|---|---|
| **P1** | KarteiChat-Hauptmodell | Prompt + Tools | ja, über §2.1 |
| **P2** | `LLMToolGenerateContextText` | `kontextName`, `zusatzInfo`; die **im Kontext hinterlegten Briefkommandos/Textbausteine werden mit den Patientendaten aufgelöst** und mit dem **kontextspezifischen System-Prompt** zu einem Text generiert | indirekt — nur was die hinterlegten Kommandos liefern |
| **P3** | `GenerateArztbrief`, `GenerateBefundbericht`, `GenerateZusammenfassung` (Export) | ausschließlich `stichpunkte` | **nein** |

Nach aktuellem Stand [ungeprüft]: **P2** nutzt genau die Kontexte des Fensters „LLM-Textgenerator“ (`llm-textgenerator.md`);
der Kontextname muss exakt stimmen, sonst kommt eine Liste der verfügbaren Kontexte zurück. **P3** bietet
kein Chat mehr an — die Überlegung zum Füllzwang durch feste Abschnittsgerüste betrifft damit nur noch den
Textgenerator (dessen Standard-Systemprompts geben Gliederungen vor).

Für P2 gilt: Quellentreue ist dort **primär eine Konfigurationsfrage** (welche Kommandos sind im Kontext hinterlegt) und
nur sekundär eine Promptfrage. Ein System-Prompt kann Fakten nicht retten, die die Kommando-Auflösung nicht geliefert hat.

### 2.5 Externe medizinische Auskunft

`LLMToolValmed` und `LLMToolAmbossAIModeAsText` beantworten Fachfragen außerhalb von tomedo. Bei Valmed steht
ausdrücklich: „Frage darf keine personenbezogenen Patientendaten enthalten." tomedo prüft das **nicht
technisch**; Valmed erscheint nur mit eigener
Systemeinstellung, AMBOSS ist seit 01.07.2026 abgeschaltet [ungeprüft]. Die Einhaltung liegt damit **beim
Modell**. Konsequenz für Prompts, die nach außen führen können: explizites Verbot mitgeben, nicht auf die Tool-Auflage
vertrauen. Dasselbe gilt für Werkzeuge eigener MCP-Server (`llm-toolebene.md` §12).

---

## 3 · Delta zur Quellengrenzen-Tabelle

Ergänzung zu `modellgrenzen-und-quellen.md`, Abschnitt C.2.

| Zeile in C.2 | Bisher | Laut Export | Aktueller Stand [ungeprüft] |
|---|---|---|---|
| Leistungen (EBM/GOÄ) | unbekannt | im Lieferumfang des Historie-Tools | **keine** Quelle der Kartei-Recherche; nur über das Werkzeug „Abrechnungsfehler erklären“ |
| Gespeicherte Formulare | nicht geführt | im Lieferumfang | Quelle, aber nur als Kurzfassung |
| PDF-Anlagen | nein | über eine Werkzeugkette erreichbar | über das Anlagen-Werkzeug erreichbar; in der Recherche nur als Pfad |
| Diagnose-ICD-Codes, wenn nicht im Text | nein | über `Diagnosensuche` | Diagnosen sind eigene Quellen; Quellenmarker zeigt den ICD-Code |
| Dokumentierender Nutzer je Eintrag | unbekannt | kein Tool | wird **nicht** übertragen |
| Laborwerte | nicht gemessen | eigenes Labor-Tool | strukturierte Laborbefunde sind Quellen; Labor nur als PDF über das Anlagen-Werkzeug |
| Retrieval ohne erkennbare Kürzung | belegt | ein Ergebnis mit der ganzen Historie | keine Kürzung, aber Budgets je Recherche (`llm-toolebene.md` §3); Überschreitung = Fehler |

---

## 4 · Was der Export **nicht** erklärt

Diese belegten Grenzen bleiben ohne Mechanismus und damit ohne neuen Hebel: Kollaps bei Konsolidierung vieler IDs auf
wenige Slots, stilistische Variabilität über Läufe, Filter-Inkonsistenz, performative Selbst-Audits, Nichteinhaltung von
Zeichenvorgaben, asymmetrischer Informationsverlust bei Verdichtung. Das sind Modell-, nicht Architektureigenschaften.

Für die Verarbeitungs-Queue (≥30 s, `zu evaluieren`) lieferte der Export nur einen schwachen Hinweis (`LLMToolSleep`).
Im KarteiChat gibt es das Werkzeug nicht. Bekannt ist anderes [ungeprüft]: Während einer Antwort ist das
Senden gesperrt; eine leere Modellantwort erscheint als „Verarbeitungsfehler“ mit Wiederholen-Knopf; und starten zwei
KI-Anfragen innerhalb von etwa einer Sekunde (zwei Chatfenster, mehrere KI-Prompt-Aktionen kurz nacheinander), läuft nur
die erste — die zweite bleibt ohne Antwort und ohne Fehlermeldung. Für die 30 Sekunden gibt es keinen Beleg.

---

## 5 · Prompt-Hebel

### 5.1 Werkzeuganweisung als Prompt-Baustein

Im Stand des Exports gab es Spezialwerkzeuge für Diagnosen, Medikation und Labor. Nach aktuellem Stand läuft das
alles über die Kartei-Recherche, die nach **Quellenart** filtern kann [ungeprüft]. Die Werkzeuganweisung wird damit zur
Anweisung, **was in den Rechercheauftrag gehört**:

```
Suche die Diagnosen in den Diagnose-Einträgen der Kartei, nicht im Freitext der Verläufe.
Suche Medikamente im Medikamentenplan und in den Verordnungen. Unterscheide
„Medikamentenplan" (Dauermedikation) von „Verordnung" (Rezeptausstellung)
und zähle dasselbe Präparat nicht doppelt.
Laborwerte nur aus den Laborbefunden, nicht aus Verlaufstext.
```

Erwartung: senkt ICD-Konfabulation und Zahlendrift, weil die Quelle strukturiert statt narrativ ist. **zu evaluieren**,
Sonde S-3.

### 5.2 Zeitraum als Kontextverkleinerung

Im Export war `minDate` der einzige Systemfilter. Nach aktuellem Stand filtert die Recherche nach einem Zeitraum von–bis und
bekommt das heutige Datum mit [ungeprüft]. Statt „berücksichtige nur die letzten zwei Jahre" also den Zeitraum als Teil
der Frage nennen: „Suche in den Einträgen seit dem 01.10.2024." Das verlagert Filterarbeit vom Modell ins System.

### 5.3 Typfilter: jetzt über das Kürzel

Im Export gab es **keinen** KE-Typfilter. Nach aktuellem Stand kann die Recherche nach dem **exakten Eintragskürzel**
filtern, und Karteieinträge kommen mit dem Kürzel, nicht mit der Bezeichnung [ungeprüft]. Darum gehört in eine
Typdefinition **beides**: Bezeichnung und Kürzel („Einträge vom Typ Anamnese (ANA) und Therapie (THE)"). Die
Whitelist/Conditional/Blacklist-Trias und die Typdefinition bleiben unverzichtbar. Datenschutzseitig: Ohne
Eingrenzung sind **alle** Eintragstypen erreichbar, auch somatische bei psychotherapeutischen Aufträgen.

### 5.4 Anlagen explizit beauftragen

Die bisherige Regel „keine Abhängigkeit von Anlageninhalten" (Checkliste Punkt 14) bleibt der Default. Wo eine Anlage
unvermeidlich ist, ausdrücklich das Lesen der Anlage verlangen, **mit** vollständigem Auftrag (§5.7). Gemessen: mit
ausdrücklichem Anlagenbezug **54/65 · 83 %** (S-4).

### 5.5 Quellen-ID-Zwang als Verifikationshebel

Quellenverweise sind ein natives Format (`[1235]`, `[&diag1224]`, für ePA-Dokumente `[&epadoc<token>]`). Daraus wird
eine automatisch prüfbare Regel:

```
Setze hinter jede Aussage die ID des Karteieintrags, aus dem sie stammt.
Eine Aussage ohne ID gilt als nicht belegt und ist zu unterlassen.
```

Jede Prozedur- oder Zahlenbehauptung ohne auflösbare ID ist damit als Fabrikat erkennbar. Allerdings verschwindet
eine unbekannte ID **still** aus der Anzeige [ungeprüft] — wer prüft, liest den kopierten Rohtext oder
zählt die Marker. **Wichtig:** Vor dem Rückschreiben in Kartei, Formular oder Brief müssen die IDs wieder raus (§2.3).
Der ID-Zwang gehört also in den **Prüflauf**, nicht in den produktiven Generierungslauf.

### 5.6 Kontexthygiene

Der Export enthielt `LLMToolTrimChat` („kürzt die Chat-Historie, indem alte Nachrichten entfernt werden"). Im
KarteiChat ist es **nicht** aktiv, und der Client kürzt den Verlauf auch sonst nicht: Jede Anfrage schickt
den ganzen bisherigen Chat samt aller Werkzeugergebnisse [ungeprüft]. Die Vorhersage „die Akte fällt aus der Historie"
hat damit in tomedo keinen eigenen Mechanismus mehr; was der Server bei langen Verläufen tut, ist unbekannt. Praxisregel bleibt:
**Chat leeren zwischen Prompt-Strängen** — der Verlauf wird sonst mit jeder Recherche größer und alte Ergebnisse
konkurrieren mit neuen. **zu evaluieren**, Sonde S-5.

### 5.7 Sub-Agenten sind kontextisoliert

Bei den Agenten-Werkzeugen (Anlagen, Briefkommando-Zuordnung, Formulare, Objektebene, Diktatvorlagen) steht
gleichlautend, der Sub-Agent habe „kein Gedächtnis und keinen Zugriff auf den umgebenden Chat". Das gilt
**auch für die Kartei-Recherche**; Sub-Agenten erben nur den Patienten [ungeprüft]. Für uns: Ein Prompt, der eine
Teilaufgabe delegiert, muss den Teilauftrag **selbsttragend** formulieren — Rückverweise wie „wie oben", „der genannte
Patient", „nach den Regeln aus Schritt 1" gehen dort verloren. Bei jeder Faktenfrage heißt das: Zeitraum, Gegenstand
und Eintragstyp in **dieselbe** Frage.

### 5.8 Werkzeug statt Systemprompt für Schrittfolgen

Der Export enthielt ein Werkzeug, das die „verbindliche Schrittfolge" eines Labor-PDF-Imports als Werkzeugergebnis
zurückgibt. Nach aktuellem Stand ist es in keinem Chat mehr eingebunden; die Schrittfolge steht jetzt im Systemprompt des
Labor-Import-Agenten [ungeprüft]. Die Überlegung zur Instruktionshierarchie (spät eintreffende Werkzeugergebnisse
wirksamer als frühe System-Prompt-Absätze) bleibt **zu evaluieren**, hat aber diesen Beleg verloren.

---

## 6 · Anti-Patterns

| Anti-Pattern | Warum falsch |
|---|---|
| Werte über `LLMToolRunBriefkommando` verankern | Verschiebt die Kommando-Wahl ins Modell. Anker gehören ins Eingabefeld |
| Formular- oder KE-IDs als Zahl behandeln | 18-stellige Idents werden gerundet und zeigen dann auf ein anderes Objekt |
| Formularanlage wiederholen, wenn unklar ist, ob der erste Aufruf griff | Erzeugt ein zweites Formular |
| Quellen-IDs im produktiven Rückschreibe-Output stehen lassen | Verstößt gegen die Konvention aller Schreib-Tools; Idents landen im Karteitext (kein Filter) |
| Auf Dauermedikation aus dem Medikamentenplan als vollständig vertrauen | Der Plan ist praxisgepflegt und laut Hersteller „nicht zwingend vollständig" |
| Teilaufgaben oder Folgefragen mit Rückverweisen formulieren | Sub-Agenten und die Kartei-Recherche sehen den Chat nicht |
| Patientendaten in Fragen an externe Auskunfts- oder MCP-Werkzeuge | Auflage liegt beim Modell, nicht am System |

---

## 7 · Sondenprotokoll

Was zu prüfen ist, bevor irgendetwas aus dieser Datei den Status `belegt` bekommt. Jede Sonde einzeln, Chat leeren
zwischen den Sonden, Ergebnisse ins Testprotokoll.

| ID | Frage | Vorgehen |
|---|---|---|
| **S-1** | Welche Tools sind im KarteiChat exponiert? | Direkt fragen: „Welche Werkzeuge stehen dir zur Verfügung? Nenne die exakten Namen." Erwartung: die Liste in `llm-toolebene.md` §2.2 [ungeprüft] |
| **S-2** | Antwortet `LLMToolRunBriefkommando`? | „Wie alt ist der Patient laut dem Briefkommando für das Patientenalter? Nenne nur das Ergebnis." — ohne das Kommando selbst einzufügen (sonst greift Pfad 1 und die Sonde ist wertlos) |
| **S-3** | Wirkt die Werkzeuganweisung (§5.1)? | Diagnose-Frage an einer Akte, deren ICD-Codes **nicht** im Karteitext stehen, mit und ohne Anweisung, je 3 Läufe |
| ~~**S-4**~~ | ~~Ist die Anlagenkette begehbar?~~ | **beantwortet, 22.09.2026: ja.** Mit ausdrücklichem Anlagenbezug **54/65 · 83 %**. Die frühere Lesart „4/4 nicht dokumentiert = korrekte Abstinenz" ist widerrufen — dort war der Wert in der Anlage vorhanden. Offen bleibt nur, **warum** der Leser in 15 % der Läufe nicht anläuft |
| **S-5** | Verschlechtert ein langer Verlauf die Antworten? | Kartei abrufen, dann N Turns Nebenthema, dann Faktenfrage zur Akte; N variieren. Kontrolle: dieselbe Frage im geleerten Chat |
| ~~**S-6**~~ | ~~Welcher Pfad ist der „neue Textgenerator"?~~ | P2 = Kontexte des LLM-Textgenerators; P3 wird nicht mehr angeboten [ungeprüft] |
| ~~**S-7**~~ | ~~Sind Kontexte praxisseitig editierbar?~~ | ja: praxisweit als Textbausteine gespeichert, ohne Rechteprüfung beim Bearbeiten [ungeprüft] |
| **S-8** | Sieht die Recherche Kürzel oder Bezeichnung? | „Welche Eintragstypen gibt es in dieser Akte, mit Kürzel und Bezeichnung?" — Erwartung: Kürzel [ungeprüft] |

**Namensfamilien:** Der Export mischte vier Namenskonventionen — `LLMTool*`, deutsche Anzeigenamen (`Diagnosensuche`,
`Dokument-Downloader`), snake_case (`list_briefkommandos`, `run_briefkommando`) und camelCase (`erkenneVerordnung`).
Nach aktuellem Stand heißen alle Werkzeuge nach dem Schema `LLMTool…`; eigene Namen haben nur Werkzeuge von
MCP-Servern [ungeprüft]. Eigene Werkzeuge lassen sich über MCP-Server einbinden (`llm-toolebene.md` §12).

---

## 8 · Anschluss an andere Skills

- `tomedo-kommandos` — `LLMToolRunBriefkommando` als Test-Harness für Kommando-Syntax; `LLMToolCreateBriefkommando` als LLM-befüllter Platzhalter (nur Aktion „KI-Prompt“)
- `tomedo-aktionsketten` — chat-flüchtige Kommandos für Folgeschritte einer laufenden Kette; Aktionsketten anlegen kann nur die KI-Soforthilfe (mit Rückfrage je Objekt) [ungeprüft]
- `tomedo-patientenformulare` — `LLMToolExtrahiereFormularAgent` als Auslesepfad ohne Briefkommando; ID-als-String-Regel
- `tomedo-statistik-hql` — `LLMToolListEntities` macht Entitätsnamen des Datenmodells abfragbar
- `tomedo-navigation` — Menüeinträge klicken kann nur die KI-Soforthilfe, ohne Rückfrage [ungeprüft]
- `tomedo-textbausteine` — `LLMToolShowForm` als LLM-natives Gegenstück zu Dialogfragen; `LLMToolMatchBriefkommandosAgent` nimmt Fragenlisten im Format `[{id, frage}]`

---

*Referenz zu `tomedo-karteichat-prompting`, Stand 2026-09-10, überarbeitet im Oktober 2026.
Belegbasis: Tool-Definitions-Export 09/2026, 112 Definitionen. Aussagen aus dem
Export sind **dokumentiert**, noch nicht in der Oberfläche nachgestellte **[ungeprüft]**; nur S-4 ist an unserer Demoakte belegt. Kernaussage: der
KarteiChat ist ein Agent mit Werkzeugen, nicht ein Modell mit vorgeladener Akte; daraus folgt die Werkzeuganweisung als
vierter Prompt-Baustein neben Anker, Guard und Typdefinition.*
