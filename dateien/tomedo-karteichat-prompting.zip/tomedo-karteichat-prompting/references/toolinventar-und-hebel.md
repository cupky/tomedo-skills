# Toolebene: Inventar und Prompt-Hebel

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

**Belegbasis:** Export der tomedo-LLM-Tool-Definitionen (`llm_tools_export.json`, 09/2026) — 112 Funktionsdefinitionen im OpenAI-Function-Calling-Format, plus ein leerer Platzhaltereintrag. Ausgewertet wurden Namen, Beschreibungen und Parameterschemata.

**Vorbehalt, der für die ganze Datei gilt:** Der Export ist die **Union aller Toolsets**, nicht das Kontextabbild eines einzelnen Chats. Belegbar am Tool `LLMToolUIAutomationHinweis`, das selbst formuliert, das geführte Tutorial laufe „nur im Kartei-Chat einer geöffneten Patientenkartei, nicht hier im Support-Chat" — der Export enthält also mindestens Support-Chat und Kartei-Chat gemeinsam, dazu Dental-Tools (BEMA, GOZ, PSI-Befunde) und reine Client-Diagnose-Tools (TI-Konnektor, Kameralogin, Spracherkennung, Loglevels). **Welche Tools im KarteiChat tatsächlich exponiert sind, ist unbelegt** (§7).

**Statuskennzeichnung** wie im Skill: **belegt** · **plausibel** · **zu evaluieren**. Zusätzlich hier: **dokumentiert** = steht so in der Tool-Beschreibung des Herstellers, ist aber nicht von uns beobachtet.

---

## 1 · Der Kern in fünf Sätzen

Der KarteiChat ist kein Modell mit vorgeladenem Karteitext, sondern ein **Agent mit Werkzeugen** — die Akte kommt über einen Tool-Aufruf herein und liegt danach als Tool-Ergebnis in der Chat-Historie. Das erklärt drei bislang nur beobachtete Dinge auf einmal: warum das Retrieval über die ganze Akte funktioniert (das Historie-Tool hat **keinen** Typ- oder Volltextfilter, es liefert alles), warum Anlagen nicht im Kontext sind (sie kommen nur über eine eigene Toolkette) und warum Quellenanker als Hyperlinks erscheinen (die Idents stehen als `[1235]` bzw. `[&diag1224]` im Text und werden vor jedem Rückschreiben wieder entfernt). Für das Prompting folgt daraus ein neuer Baustein neben Anker, Guard und Typdefinition: die **Werkzeuganweisung** — dem Modell sagen, *welches* Werkzeug es für eine Teilfrage benutzen soll. Der stärkste Fall davon ist das Umleiten strukturierter Fragen auf ein Spezialtool statt auf den Karteivolltext, der billigste das Setzen eines Datumsfilters. Und: die Kartei kann **aus der Historie herausfallen** — es gibt ein Tool, das alte Nachrichten verwirft (§5.6).

---

## 2 · Tool-Inventar, für das Prompting relevanter Teil

Alle Beschreibungen **dokumentiert**, sofern nicht anders vermerkt.

### 2.1 Datenbeschaffung am Patienten

| Tool | Liefert | Parameter | Prompt-Relevanz |
|---|---|---|---|
| `LLMToolGetPatientsHistory` | Dokumentation, Diagnosen, **Leistungen**, Briefe, **gespeicherte Formulare**, **Pfade zu Dateianhängen**, Stammdaten | nur `minDate` | Der Haupt-Kontextlieferant. Kein Typfilter → Filterarbeit bleibt beim Modell. Datumsfilter ist der einzige Systemhebel. |
| `Diagnosensuche` | Diagnosen chronologisch, neueste zuerst | `minDate` | Strukturierte Quelle gegen ICD-Konfabulation |
| `LLMToolGetPatientsMedicationHistory` | zwei Typen: `Medikamentenplan` (Arzneimittelhaushalt, praxisgepflegt, „nicht zwingend vollständig") und `Verordnung` (konkrete Rezeptausstellungen); dasselbe Präparat kann in beiden stehen | `minDate` | Die Doppelzählung ist eine benannte Fehlerquelle für Medikationsabschnitte |
| `LLMToolGetPatientsLaborData` | Befunde mit Messwerten, Normbereichen, Auffälligkeiten | `minDate`, Testkürzel | Laborwerte als Zahlen statt aus Fließtext |
| `LLMToolListKEAttachments` | vollständige Pfade zu Anhangsdateien der Kartei | – | Erster Schritt der Anlagenkette |
| `Dokument-Downloader` | lädt den Anhang eines Karteieintrags lokal verfügbar | KE-ID, „muss exakt richtig sein" | Zweiter Schritt |
| `LLMToolAttachmentAgent` / `…ExtractAgent` | liest und fasst PDF/JPG zusammen, gibt strukturierten Text | Pfad bzw. Auftrag | Dritter Schritt. **Kontextisoliert** (§5.7) |
| `LLMToolExtrahiereFormularAgent` | liest ein ausgefülltes Formular aus | `ident` des KE, in dem das Formular liegt | Alternativer PatF-Auslesepfad ohne `$[formularEintrag …]$` |
| `LLMToolDate` | aktuelles Datum, Format `dd.MM.yyyy [HH:mm]` | – | Erklärt „Systemdatum als Befund". Relative Zeitangaben verlangen laut Beschreibung **zwingend** diesen Aufruf vorab |

### 2.2 Briefkommandos — drei verschiedene Pfade

| Pfad | Mechanik | Deterministisch? |
|---|---|---|
| **Eingabefeld-Auflösung** (bekannt, Skill v2) | Client löst `$[…]$` rund eine Sekunde nach dem Einfügen auf; der aufgelöste Wert geht als Text an das Modell | ja, und sichtbar prüfbar |
| **`run_briefkommando`** (neu) | Das **Modell** ruft ein Kommando im Patientenkontext auf und erhält das Ergebnis als Tool-Antwort. Mehrere Kommandos in einem String möglich | nein — Modell wählt Kommando und Argumente |
| **`LLMToolCreateBriefkommando`** (neu) | Das Modell **erzeugt** ein Kommando mit Namen und Wert; es „besteht nur im Kontext des Chats (z.B. für die folgenden Einträge einer laufenden Aktionskette)" | Wert ist Modelloutput |

Dazu `list_briefkommandos`: listet Name, Beschreibung und Kontext aller Kommandos, wertet sie ausdrücklich **nicht** aus.

Die Unterscheidung ist wichtig: Der Anker-Mechanismus des Skills beruht auf Pfad 1 und behält seine belegte Zuverlässigkeit. Pfad 2 ist bequemer, verschiebt aber die Kommando-Wahl ins Modell — und damit in die Zone, für die der Fehlerkatalog gilt. **Regel: Produktionskritische Werte über Pfad 1 verankern, Pfad 2 nur für Exploration und Tests.**

> **Nebennutzen für uns:** Pfad 2 macht den KarteiChat zum **Test-Harness für Kommando-Syntax** — Varianten von `$[formularEintrag …]$` oder `$[karteiEintragWert …]$` lassen sich am lebenden Patientenkontext durchprobieren, ohne eine Briefvorlage zu bauen. Siehe `tomedo-kommandos`.

### 2.3 Rückschreiben in die Akte

| Tool | Verhalten, das man kennen muss |
|---|---|
| `LLMToolCreateKarteieintrag` | Typ als Name **oder Kürzel** („Kürzel werden bevorzugt"), Datum defaultet auf heute; Existenz des Typs muss vorher geprüft sein → `LLMToolgetValidKarteiEintragTypen` |
| `LLMToolEditKarteieintrag` | ersetzt den Inhalt **vollständig**. ID „niemals raten" |
| `LLMToolCreateFormular` | „UNWIDERRUFLICH – GENAU EINMAL aufrufen"; zweiter Aufruf erzeugt ein zweites Formular. Formular-ID **als String**, weil 18-stellige Zahlen sonst gerundet werden und auf ein anderes Formular zeigen |
| `LLMToolShowForm` | zeigt dem Nutzer ein Eingabeformular (`text_single`, `text_multi`, `dropdown`, `checkbox`, `date`, `required`) und liefert die Eingaben als JSON zurück |

**Durchgehende Konvention:** In `CreateKarteieintrag`, `EditKarteieintrag`, `CreateFormular` und `CreateBriefkommando` steht jeweils, der Inhalt dürfe **keine Quellenverweise** der Form `[1235, &diag1224…]` mehr enthalten. Daraus folgt §5.5.

### 2.4 Textgenerierung — drei Pfade

| Pfad | Tool | Input | Kartei-Zugriff |
|---|---|---|---|
| **P1** | KarteiChat-Hauptmodell | Prompt + Tools | ja, über §2.1 |
| **P2** | `LLMToolGenerateContextText` | `kontextName`, `zusatzInfo`; die **im Kontext hinterlegten Briefkommandos/Textbausteine werden mit den Patientendaten aufgelöst** und mit dem **kontextspezifischen System-Prompt** zu einem Text generiert | indirekt — nur was die hinterlegten Kommandos liefern |
| **P3** | `GenerateArztbrief`, `GenerateBefundbericht`, `GenerateZusammenfassung` | ausschließlich `stichpunkte` | **nein** |

P3 hat je Tool ein **festes Abschnittsgerüst** („strukturiert mit Anamnese, Befund, Diagnose und Therapie" bzw. „nach Fragestellung, Untersuchung, Befund und Beurteilung"). Ein fest verdrahteter Abschnitt plus unterspezifizierter Input erzeugt Füllzwang — das ist der strukturelle Mechanismus hinter Prozedur-Konfabulation aus reinen Mengennotationen. **plausibel**, prüfbar durch Differenzlauf P1/P2/P3 auf identischem Input.

Für P2 gilt: Quellentreue ist dort **primär eine Konfigurationsfrage** (welche Kommandos sind im Kontext hinterlegt) und nur sekundär eine Promptfrage. Ein System-Prompt kann Fakten nicht retten, die die Kommando-Auflösung nicht geliefert hat.

### 2.5 Externe medizinische Auskunft

`LLMToolValmed` und `LLMToolAmbossAIModeAsText` beantworten Fachfragen außerhalb von tomedo. Bei Valmed steht ausdrücklich: „Frage darf keine personenbezogenen Patientendaten enthalten." Dieselbe Auflage trägt `LLMToolUIAutomationAgent.handbuch_frage` („keine Patientennamen, Geburtsdaten, Diagnosen"). Die Einhaltung liegt damit **beim Modell**. Konsequenz für Prompts, die nach außen führen können: explizites Verbot mitgeben, nicht auf die Tool-Auflage vertrauen.

---

## 3 · Delta zur Quellengrenzen-Tabelle

Ergänzung zu `modellgrenzen-und-quellen.md`, Abschnitt C.2. Alles hier ist **dokumentiert**, nicht von uns beobachtet — die Statusspalte der Zieltabelle sollte das ausweisen.

| Zeile in C.2 | Bisher | Laut Export |
|---|---|---|
| Leistungen (EBM/GOÄ) | unbekannt | Das Historie-Tool nennt „Leistungen" ausdrücklich im Lieferumfang → **im Kontext, sofern das Tool gerufen wurde** |
| Gespeicherte Formulare | nicht geführt | ebenfalls ausdrücklich im Lieferumfang des Historie-Tools |
| PDF-Anlagen | nein | Präziser: **nicht im Kontext, aber über die Kette Pfade → Downloader → AttachmentAgent erreichbar.** Unsere Beobachtung „4/4 nicht dokumentiert" ist damit vereinbar: das Modell rief die Kette nicht |
| Diagnose-ICD-Codes, wenn nicht im Text | nein | Über `Diagnosensuche` erreichbar |
| Dokumentierender Nutzer je Eintrag | unbekannt | unverändert unbekannt — kein Tool liefert Attribution |
| Retrieval ohne erkennbare Kürzung | belegt | Mechanik: ein Tool-Ergebnis mit der ganzen Historie, kein Filterparameter. Die Kürzungsgefahr liegt nicht in der Akte, sondern in der Chat-Historie (§5.6) |

---

## 4 · Was der Export **nicht** erklärt

Diese belegten Grenzen bleiben ohne Mechanismus und damit ohne neuen Hebel: Kollaps bei Konsolidierung vieler IDs auf wenige Slots, stilistische Variabilität über Läufe, Filter-Inkonsistenz, performative Selbst-Audits, Nichteinhaltung von Zeichenvorgaben, asymmetrischer Informationsverlust bei Verdichtung. Das sind Modell-, nicht Architektureigenschaften. Für die Verarbeitungs-Queue (≥30 s, `zu evaluieren`) liefert der Export einen schwachen Hinweis: es existiert ein `LLMToolSleep` mit maximal 300 Sekunden je Aufruf, gedacht für laufende Hintergrundaktionen.

---

## 5 · Neue Prompt-Hebel

### 5.1 Werkzeuganweisung als Prompt-Baustein
Teilfragen mit strukturierter Entsprechung explizit auf das Spezialtool leiten, statt sie im Karteivolltext suchen zu lassen:

```
Hole die Diagnosen über die Diagnosensuche, nicht aus dem Karteitext.
Hole Medikamente über die Medikationshistorie. Unterscheide dort
„Medikamentenplan" (Dauermedikation) von „Verordnung" (Rezeptausstellung)
und zähle dasselbe Präparat nicht doppelt.
Laborwerte nur aus den Labordaten, nicht aus Verlaufstext.
```

Erwartung: senkt ICD-Konfabulation und Zahlendrift, weil die Quelle strukturiert statt narrativ ist. **zu evaluieren**, Sonde S-3.

### 5.2 Datumsfilter als Kontextverkleinerung
`minDate` ist der einzige Systemfilter. Statt „berücksichtige nur die letzten zwei Jahre" (Modellarbeit) besser: „Bestimme zuerst das heutige Datum, dann rufe die Historie mit einem Mindestdatum von zwei Jahren davor ab." Das verlagert Filterarbeit vom Modell ins System — genau die Richtung, die Feature-Wunsch 3 einforderte, nur eben nur auf der Zeitachse.

### 5.3 Typfilter bleibt Modellarbeit
Es gibt **keinen** KE-Typfilter. Der Wunsch nach systemseitiger Typfilterung ist unerfüllt; die Whitelist/Conditional/Blacklist-Trias und die Typdefinition bleiben deshalb unverzichtbar. Datenschutzseitig heißt das: bei Aufrufen des Historie-Tools sind **alle** Eintragstypen im Kontext, auch somatische bei psychotherapeutischen Aufträgen.

### 5.4 Anlagenkette explizit beauftragen
Die bisherige Regel „keine Abhängigkeit von Anlageninhalten" (Checkliste Punkt 14) bleibt der Default. Wo eine Anlage unvermeidlich ist, ist die Kette explizit zu beauftragen: Historie → KE-ID der Anlage → Anhang laden → auslesen, **mit** der Auflage, dem auslesenden Agenten den vollständigen Auftrag mitzugeben (§5.7). **zu evaluieren**, Sonde S-4.

### 5.5 Quellen-ID-Zwang als Verifikationshebel
Quellenverweise sind ein natives Format (`[1235]`, `[&diag1224]`, für ePA-Dokumente `[&epadoc<token>]`). Daraus wird eine automatisch prüfbare Regel:

```
Setze hinter jede Aussage die ID des Karteieintrags, aus dem sie stammt.
Eine Aussage ohne ID gilt als nicht belegt und ist zu unterlassen.
```

Jede Prozedur- oder Zahlenbehauptung ohne auflösbare ID ist damit als Fabrikat erkennbar — das ist die schärfste bisher verfügbare Gegenmaßnahme gegen erfundene Prozeduren und Zahlen. **Wichtig:** Vor dem Rückschreiben in Kartei, Formular oder Brief müssen die IDs wieder raus (siehe Konvention in §2.3). Der ID-Zwang gehört also in den **Prüflauf**, nicht in den produktiven Generierungslauf.

### 5.6 Kontexthygiene: die Kartei kann herausfallen
`LLMToolTrimChat` „kürzt die Chat-Historie, indem alte Nachrichten entfernt werden". Die Akte liegt als **eine** alte Nachricht in der Historie. Vorhersage: in langen Chats verliert das Modell nicht die Akte still innerhalb eines Tool-Ergebnisses, sondern **das ganze Ergebnis** — und arbeitet danach aus seiner eigenen früheren Zusammenfassung weiter, was Verdichtungsfehler kumuliert. Praxisregel bleibt: **Chat leeren zwischen Prompt-Strängen**, jetzt mit Mechanismus statt Aberglauben. Erwartung: Fabrikationsrate steigt mit der Turn-Zahl und fällt nach erneutem Kartei-Abruf. **zu evaluieren**, Sonde S-5. Mutmaßlich auch die Mechanik hinter wörtlichen Wiederholungen aus vorhergehenden Outputs bei nicht geleertem Chat.

### 5.7 Sub-Agenten sind kontextisoliert
Bei `AttachmentAgent`, `MatchBriefkommandosAgent`, `UIAutomationAgent`, `ManagedObjectAgent` und `GenerateDiktatVorlageAgent` steht gleichlautend, der Sub-Agent habe „kein Gedächtnis und keinen Zugriff auf den umgebenden Chat", alle relevanten Informationen müssten im Auftrag mitgegeben werden. Für uns: Ein Prompt, der eine Teilaufgabe delegiert, muss den Teilauftrag **selbsttragend** formulieren — Rückverweise wie „wie oben", „der genannte Patient", „nach den Regeln aus Schritt 1" gehen dort verloren. Das ist die Prompt-seitige Entsprechung der Regel „eine Aufgabe pro Prompt".

### 5.8 Werkzeug statt Systemprompt für Schrittfolgen
`LLMToolLabPDFImportWorkflow` „liefert die verbindliche Schrittfolge" — der Hersteller legt eine mehrstufige Prozedur also nicht in den System-Prompt, sondern gibt sie als **Tool-Ergebnis** zurück, mit einer Vorbedingung, die im Konjunktiv Imperativ formuliert ist („tue dies JETZT SOFORT"). Das ist ein Hinweis auf die effektive Instruktionshierarchie: spät im Kontext eingetroffene Tool-Ergebnisse scheinen wirksamer zu sein als frühe System-Prompt-Absätze. **zu evaluieren** — direkt anschlussfähig an die Instruktionshierarchie-Sonde.

---

## 6 · Anti-Patterns, neu

| Anti-Pattern | Warum falsch |
|---|---|
| Werte über `run_briefkommando` verankern | Verschiebt die Kommando-Wahl ins Modell. Anker gehören ins Eingabefeld |
| Formular- oder KE-IDs als Zahl behandeln | 18-stellige Idents werden gerundet und zeigen dann auf ein anderes Objekt |
| Formularerzeugung wiederholen, wenn unklar ist, ob der erste Aufruf griff | Erzeugt ein zweites, doppeltes Formular. Unwiderruflich |
| Quellen-IDs im produktiven Rückschreibe-Output stehen lassen | Verstößt gegen die Konvention aller Schreib-Tools; Idents landen im Karteitext |
| Auf Dauermedikation aus dem Medikamentenplan als vollständig vertrauen | Der Plan ist praxisgepflegt und laut Hersteller „nicht zwingend vollständig" |
| Teilaufgaben an Sub-Agenten mit Rückverweisen formulieren | Sub-Agenten sehen den Chat nicht |
| Patientendaten in Fragen an externe Auskunftstools | Auflage liegt beim Modell, nicht am System |

---

## 7 · Sondenprotokoll

Was zu prüfen ist, bevor irgendetwas aus dieser Datei den Status `belegt` bekommt. Jede Sonde einzeln, Chat leeren zwischen den Sonden, Ergebnisse ins Testprotokoll.

| ID | Frage | Vorgehen |
|---|---|---|
| **S-1** | Welche Tools sind im KarteiChat exponiert? | Direkt fragen: „Welche Werkzeuge stehen dir zur Verfügung? Nenne die exakten Namen." Gegenprobe im Sprechstundenassistenten |
| **S-2** | Ist `run_briefkommando` im KarteiChat verfügbar? | `Werte das Briefkommando $[pa]$ aus und nenne nur das Ergebnis.` — ohne das Kommando selbst einzufügen (sonst greift Pfad 1 und die Sonde ist wertlos). Formulierung ohne `$…$`: „Wie alt ist der Patient laut dem Kommando für das Patientenalter?" |
| **S-3** | Wirkt die Werkzeuganweisung (§5.1)? | Diagnose-Frage an einer Akte, deren ICD-Codes **nicht** im Karteitext stehen, mit und ohne Anweisung, je 3 Läufe |
| ~~**S-4**~~ | ~~Ist die Anlagenkette begehbar?~~ | **beantwortet, 22.09.2026: ja.** Mit ausdrücklichem Anlagenbezug **54/65 · 83 %**. Die frühere Lesart „4/4 nicht dokumentiert = korrekte Abstinenz" ist widerrufen — dort war der Wert in der Anlage vorhanden. Offen bleibt nur, **warum** der Leser in 15 % der Läufe nicht anläuft |
| **S-5** | Fällt die Kartei aus der Historie? | Kartei abrufen, dann N Turns Nebenthema, dann Faktenfrage zur Akte; N variieren. Kontrolle: erneuter Kartei-Abruf vor derselben Frage |
| **S-6** | Welcher Pfad ist der „neue Textgenerator"? | P2 gegen P3 unterscheiden: liefert er Inhalte, die **nicht** in den Stichpunkten stehen, ist es P2 |
| **S-7** | Sind Kontexte praxisseitig editierbar? | Nachfrage bei zollsoft; entscheidet, ob P2 für uns überhaupt steuerbar ist |

**Namensfamilien als Hinweis:** Der Export mischt vier Namenskonventionen — `LLMTool*` (Klassennamen), deutsche Anzeigenamen (`Diagnosensuche`, `Dokument-Downloader`), snake_case (`list_briefkommandos`, `run_briefkommando`) und camelCase (`erkenneVerordnung`). Das legt unterschiedliche Herkunft und damit möglicherweise unterschiedliche Verfügbarkeit oder Konfigurierbarkeit nahe. Ob praxisseitig eigene Tools hinterlegt werden können, ist **zu evaluieren** und wäre der größte Hebel von allen.

---

## 8 · Anschluss an andere Skills

- `tomedo-kommandos` — `run_briefkommando` als Test-Harness für Kommando-Syntax; `CreateBriefkommando` als LLM-befüllter Platzhalter
- `tomedo-aktionsketten` — chat-flüchtige Kommandos für Folgeschritte einer laufenden Kette; es gibt **kein** Tool zum Anlegen von Aktionsketten
- `tomedo-patientenformulare` — `ExtrahiereFormularAgent` als Auslesepfad ohne Briefkommando; ID-als-String-Regel
- `tomedo-statistik-hql` — `ListEntities` / `DescribeEntitySchema` / `FindEntityByProperty` machen das Core-Data-Schema abfragbar (`className == entityName`)
- `tomedo-navigation` — `GetMenuItems` / `Menu` liefern den Menübaum inklusive Sidebar-Sektionspfaden; `UIAutomationAgent` ist ein natives Klickstrecken-Tutorial
- `tomedo-textbausteine` — `ShowForm` als LLM-natives Gegenstück zu Dialogfragen; `MatchBriefkommandosAgent` nimmt Fragenlisten im Format `[{id, frage}]`

---

*Referenz zu `tomedo-karteichat-prompting`, Stand 2026-09-10. Belegbasis: Tool-Definitions-Export 09/2026, 112 Definitionen. Alle Aussagen hier sind **dokumentiert oder plausibel**, keine ist an unserer Demoakte belegt — Sondenprotokoll §7 ist Voraussetzung für jede Statusanhebung. Kernaussage: der KarteiChat ist ein Agent mit Werkzeugen, nicht ein Modell mit vorgeladener Akte; daraus folgt die Werkzeuganweisung als vierter Prompt-Baustein neben Anker, Guard und Typdefinition.*
