# Modellgrenzen

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

Konsistent beobachtet, Stand 09/2026.

| Limit | Auswirkung | Workaround | Status |
|---|---|---|---|
| Vorgegebene Werte schlagen die Aktenlage | Anker wird ausgegeben, auch wenn die Kartei widerspricht | Guard + Typdefinition | belegt |
| Leerer Anker beendet die Recherche | „Feld leer" statt Antwort aus dem Fließtext | Guard-Satz zur Leere | belegt |
| Anker ohne Auftrag wird interpretiert | Harter Wert wird zu einer Aussage über den Wert | Immer Aufgabe mitgeben | belegt |
| Zeichen- und Längenvorgaben | **2/19** innerhalb der Vorgabe; die Angabe wirkt als grobe Größenordnung, nicht als Grenze | Nicht auf Zeichenzahl verlassen; Lückentext mit Platzhalter-Längen | belegt, 19 Läufe |
| Asymmetrischer Informationsverlust bei Verdichtung | Nutzenaussage wird übernommen, Vorbehalt im selben Satz nicht (4/4) | Vorbehalt als eigene Instruktion, nicht auf Übernahme hoffen | belegt |
| Kausalbehauptung unter Kompression | 2/8 behaupteten eine Wirkung, die die Akte ausschließt | Kausalverbot explizit; Ausgabe gegen Quelleintrag prüfen | belegt |
| Attributionsdrift im Einstiegssatz | Mehrstufige Vorgänge werden zu einer Ursache verkürzt | Nach Ursachen getrennt fragen | belegt |
| Systemdatum als Befund | Antwort auf „wann" kann der Anfragezeitpunkt sein | Bei Datumsfragen Erwartungsanker prüfen | belegt |
| **Anlagen-Leser startet unzuverlässig** | Der Chat **kann** PDF-Anlagen lesen (54/65), startet den Leser aber in 15 % der Läufe nicht — und meldet dann „nicht dokumentiert" oder etikettiert einen Karteitextwert falsch | Anlage ausdrücklich ansprechen; doppelt auswerten; Zitierfähiges zusätzlich in den Eintragstext | belegt, 65 Läufe |
| Trade-off Struktur ↔ Filter | Verschärft man eines, rutscht das andere | Multi-Turn, eine Aufgabe pro Prompt | belegt |
| Abstrakte Strukturvorgaben werden ignoriert | Modell erfindet eigene Headlines | Wörtlicher Lückentext mit `{Platzhaltern}` | belegt |
| Selbst-Audits sind performativ | ✅ ohne tatsächliche Prüfung | Externe Endkontrolle | belegt |
| Konsolidierung (50+ IDs → 4 Slots) kollabiert | Output bleibt leer | Aufgabe splitten | belegt |
| Stilistische Variabilität | Drei Läufe, drei Formulierungen | Mehrfach laufen, besten wählen | belegt |
| Filter-Inkonsistenz | Mal sauber, mal Blacklist-Schmuggel | Sanity-Check durch den Anwender | belegt |
| Verarbeitungs-Queue | Zu schnelle Folge-Prompts → leere Outputs | ≥30 Sekunden warten | zu evaluieren |

| **Keine Plausibilitätsprüfung** | Widersprüche in der Akte werden nicht bemerkt, auch nicht bei selbst genannten Gegendaten | Prüfauftrag **plus** Verankerung; ohne beides nicht reparierbar | belegt, 98 Läufe |
| **Aktenfehler wird weitergereicht** | Falsche Aktenangaben kommen mit Quellenangabe zurück (3/20) und wandern ungefragt in Verdichtungen (7/20) | Zahlen aus der Akte bleiben prüfpflichtig | belegt |

## C.1 Was der KarteiChat gut kann

Diese Stärken gehören in jede Bewertung, sonst entstehen falsche Erwartungen in beide Richtungen.

- **Retrieval über die ganze Akte.** Positionsprobe an Anfang, Mitte und letztem Eintrag einer Akte mit 108 Einträgen: 4/4 korrekt, alle Läufe. Keine erkennbare Kürzung. **belegt**
- **Erfindungen sind selten.** In 376 Läufen an zwei Akten **drei** belegte Erfindungen, unter einem Prozent. Das Hauptrisiko ist nicht, dass er etwas erfindet, sondern dass er **falsche Aktenangaben konserviert**. **belegt**
  > ⚠️ **Zurückgezogen:** Der frühere Eintrag wertete „4/4 nicht dokumentiert" bei einer Frage mit Antwort in der PDF-Anlage als *korrekte Abstinenz*. Gegen den Volltextexport gemessen ist genau das der **20/20-Fehlschlag** aus C.3 — der Wert stand in der Akte, nur nicht im Karteitext. Eine Verweigerung ist kein Beleg für Sorgfalt, solange nicht feststeht, dass der Wert wirklich fehlt.
- **Freitext-Extraktion.** Drei über 15 Einträge verstreute Messwerte, chronologisch, mit Datum: 3/3 vollständig richtig, ohne jeden Anker. **belegt**
- **Alltagsfragen.** „Was ist seit dem letzten ärztlichen Kontakt passiert, welche Wiedervorstellungskriterien gelten?": 4/4 sachlich richtig, inklusive Trennung ärztlich / physiotherapeutisch. **belegt**
- **Quellenanker als Hyperlinks** je Aussage, mit Sprung in den Karteieintrag. Prüfbarkeit am Einzelsatz — das kann kein Modell außerhalb von tomedo. **belegt**

## C.2 Quellengrenzen

| Quelle | Im Chatkontext | Status |
|---|---|---|
| Karteieintragstext, alle Typen, gesamter Zeitraum | ja | belegt |
| Typ-Bezeichnung je Eintrag | ja | belegt |
| Datum je Eintrag | ja | belegt |
| Stammdaten (Name, Geburtsdatum, Geschlecht, Beruf) | ja | belegt |
| Systemdatum und -uhrzeit | ja | belegt |
| **PDF-Anlagen an Karteieinträgen** | **ja, über ein eigenes Werkzeug** — das aber in 15 % der Läufe nicht anläuft | belegt, 65 Läufe |
| Diagnose-ICD-Codes, wenn nicht im Text | nein | belegt |
| Dokumentierender Nutzer je Eintrag | unbekannt | zu evaluieren |
| Leistungen (EBM/GOÄ) | unbekannt | zu evaluieren |
| Formulare, Rezepte, AU-Bescheinigungen, Laborwerte | **nicht gemessen** — die Demoakten enthalten keine | offen |
| Kurzinfo-/Patienteninfo-Feld (nicht Teil des Kartei-Exports) | **ja** — taucht ungefragt in Verdichtungen auf | belegt |

## C.3 Gemessene Quoten — der Betrieb **ohne** Briefkommandos

Alle Zahlen vom 22.09.2026. Die Tabelle misst die **276 unverankerten** Läufe des
Bestands; die 100 verankerten stehen in `SKILL.md` im Abschnitt zur zweiten Betriebsart.

| Rang | Aufgabe | Quote | Läufe |
|---|---|---|---|
| 1 | **Volltextwiedergabe** eines benannten Eintrags | **25/25 zeichengenau** | 25 |
| 2 | **Fundstelle nennen, mit Zitatzwang** | 37/38 mit Datum, **jedes Zitat zeichengenau** | 38 |
| 3 | **Geschlossene Faktenfrage** gegen den **Karteitext** | **169/172 Teilantworten · 98 %** | 43 |
| 4 | Wertfrage mit Fundstelle im Karteitext | 20/20 identisch | 20 |
| 5 | **Anlagenfrage** (PDF lesen) | **54/65 · 83 %** | 65 |
| 6 | **Geschlossene Faktenfrage** gegen **Karteitext plus Anlagen** | **66/92 · 72 %** | 23 |
| 7 | Fundstelle nennen, **ohne** Zitatzwang | Datum ja, **kein Zitat** in 40/40 | 40 |
| 8 | **Verdichtung** | Zahlen korrekt; **Termine 19/20, Vorbehalte 1/25** | 27 |
| 9 | Zeichenzahl-Vorgabe einhalten | **2/19** | 19 |
| 10 | **Widerspruch in der Akte bemerken** | **1/98 · 1 %** | 98 |
| 11 | Eigenen Prompt schreiben | **0/5** | 5 |

**Die Trennlinie liegt zwischen Rang 5 und 8:** bis dahin sind es Suchaufgaben, danach
Aufgaben, bei denen die Antwort erst entstehen muss.

**Rang 3 gegen Rang 6 ist der wichtigste Zahlenvergleich.** Dieselben Fragen, dieselben Läufe —
einmal gegen den Karteitext gemessen, einmal gegen die ganze Akte. **98 % gegen 72 %.** Die
Differenz ist genau der Anteil, der in den Anlagen steht.

### Die Streuung ist selbst ein Messwert

Nach **relativer** Streuung (SD geteilt durch Median):

| Serie | n | Median | SD | relativ | Aufgabentyp |
|---|---|---|---|---|---|
| Volltextwiedergabe | 5 | 1034 | 24 | **2,4 %** | reproduzieren |
| Faktenblock, enge Slots | 20 | 299 | 9 | 3,0 % | geschlossen |
| Fundstelle ohne Zwang | 20 | 80 | 6 | 8,0 % | geschlossen, ein Wert |
| Zeichenzahl | 10 | 237 | 40 | 16,7 % | offen mit Größenvorgabe |
| Fundstelle mit Zitatzwang | 20 | 190 | 73 | 38,5 % | offen, mit Formatauftrag |
| Anlagenfrage | 20 | 140 | 83 | 58,9 % | eng, **aber mit Werkzeugaufruf** |
| Verdichtung | 5 | 1376 | 925 | 67,2 % | vollständig offen |
| Selbstprompt | 5 | 610 | 410 | 67,2 % | vollständig offen |

**Ein hoher SD heißt „in dieser Serie ist etwas passiert", nicht „dieser Prompt ist schlecht".**
Man muss hineinsehen. Ohne Aktenkenntnis bleibt er trotzdem messbar: zwanzig Läufe, Zeichen
zählen, Ausreißer aufschlagen.

> **Weicht die Länge nach oben ab, ist etwas schiefgegangen. Ob der Chat es zugibt oder
> auffüllt, sagt die Länge nicht.** In der späten Anlagenserie waren die beiden längsten
> Antworten die beiden **ehrlichen** Verweigerungen; in drei anderen Serien waren die längsten
> die Fehlläufe.

**Die Umkehrung gilt nicht.** Eine frei erfundene Fundstelle war 77 Zeichen lang bei Median 80 —
völlig unauffällig. **Bei Fundstellen hilft nur die Gegenprobe.**

### Betriebsverhalten

| | Wert |
|---|---|
| Netzwerkfehler (HTTP 502/503) | 2 von 376 · unter einem Prozent |
| Antwortdauer typisch | 18–48 s |
| Antwortdauer nach Typ | Fundstelle 18 s · Zitatzwang 24 s · Faktenblock 27 s · Volltext 30 s · Verdichtung 33 s · **Anlagenfrage 39 s** |

Für eine Live-Vorführung: mit rund einem Ausfall pro hundert Prompts rechnen und für
Anlagenfragen die doppelte Wartezeit einplanen.

### Einmal in 100 Läufen: interne Datenbankreferenz statt ICD-Code

`Bandscheibenschäden (&diag193356276762673152)` — keine Erfindung, aber in einem Text, der in
einen Brief kopiert wird, ein Fehler.

---

**Doku-Konsequenz:** Was zitierfähig sein muss — fremde Indikationsstellungen, Zweitmeinungsergebnisse, Klinikbefunde — muss als **Text im Karteieintrag** stehen, nicht nur als Anlage. Nur dann ist es gleichzeitig für den Chat lesbar, per `$[x SCAN …]$` kommandierbar und für HQL auswertbar. Ein Textlayer im PDF nützt keinem der drei Wege.

---
