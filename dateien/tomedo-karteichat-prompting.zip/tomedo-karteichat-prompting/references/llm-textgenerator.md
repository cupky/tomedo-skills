# Der LLM-Textgenerator

Ein eigenstaendiges Fenster, das aus hinterlegten Briefkommandos plus einem
frei editierbaren System-Prompt einen Text erzeugt. Fuer strukturierte
Langtexte — Arztbriefe, Berichte, Antraege — der derzeit direkteste Weg in
tomedo.

**Statuskennzeichnung mit Quellendatum.**
`[UI, 13.09.2026]` = aus der laufenden Instanz erhoben, tomedo v1.170.0.16 ·
`[Export, 13.09.2026]` = Tool-Export ·
`[Referenzinstallation, TT.MM.JJJJ]` = eigene Messung · `[plausibel]` = abgeleitet ·
`[zu evaluieren]` = offen.

---

## 1 · Wo er liegt

**Menueleiste: `Format` › `LLM-Textgenerator`** — unterhalb von `Schrift` und
`Text`. [UI, 13.09.2026]

Das ist ein ungewoehnlicher Pflegeort: `Format` ist sonst das Menue fuer
Textauszeichnung, nicht fuer Werkzeuge. Wer den Generator sucht, sucht ihn
zuerst unter `Aktion` oder `Verwaltung` und findet ihn nicht.

> **Zuordnung zur Toolebene:** Sehr wahrscheinlich die Oberflaeche zu
> `LLMToolGenerateContextText`, dessen Beschreibung dasselbe Verfahren nennt —
> vordefinierter Kontext, hinterlegte Briefkommandos und Textbausteine werden
> mit den Patientendaten aufgeloest und mit einem kontextgebundenen
> System-Prompt zu einem Text generiert. [Export, 13.09.2026] · [plausibel]
>
> Damit waere derselbe Generator auch aus dem KarteiChat und aus einer
> KI-Prompt-Aktionskette heraus aufrufbar. **Nicht geprueft.**

---

## 2 · Aufbau des Fensters

```
Kontext:  [Arztbrief            ▾]   [⚙︎ bearbeiten]  [🗑 löschen]
Patient:  [🔍 <Patientensuche>          ]
┌─────────────────────────────────────────────────────────────┐
│  aufgelöste Textbaustein-Vorlage (editierbar)               │
└─────────────────────────────────────────────────────────────┘
[Generieren]  [Kopieren]  [Löschen]
┌─────────────────────────────────────────────────────────────┐
│  Ergebnis                                                   │
└─────────────────────────────────────────────────────────────┘
```

[UI, 13.09.2026]

**Drei Eigenschaften, die den Arbeitsablauf bestimmen:**

1. **Patient wird im Fenster gewaehlt**, nicht aus dem Kartei-Kontext
   uebernommen — der Generator laeuft unabhaengig von der geoeffneten Akte.
2. **Die aufgeloeste Vorlage ist editierbar**, bevor generiert wird. Man sieht
   also, was das Modell bekommt, und kann es korrigieren. Das ist der
   entscheidende Unterschied zum Chat.
3. **Das Ergebnis geht nicht in die Kartei**, sondern nur in die
   Zwischenablage. Kein Schreibzugriff, keine Vidierungsfrage — der Mensch
   entscheidet, wohin der Text wandert.

---

## 3 · Der Kontext-Editor

Dialog `Kontext bearbeiten`, aufgerufen ueber das Zahnrad. Zwei Felder,
darunter `Speichern`, `Auf Standard zuruecksetzen`, `Abbrechen`.
[UI, 13.09.2026]

### Feld 1 — System-Prompt

Beschriftet mit der Frage, wie das LLM antworten soll. Der ausgelieferte
Arztbrief-Kontext enthaelt eine Rollenzuweisung und sieben Regeln: im Stil
eines Arztes schreiben, medizinische Fachsprache verwenden, den Brief mit den
Ueberschriften Anamnese, Befund, Diagnose und Therapie strukturieren, in ganzen
Saetzen formulieren, fuer aerztliche Handlungen die Passivform nutzen, praezise
und vollstaendig sein, keine Informationen hinzuerfinden. [UI, 13.09.2026]

### Feld 2 — Textbaustein-Vorlage

Die Datenvorlage. Ausgeliefert fuer den Arztbrief-Kontext, gekuerzt
wiedergegeben: [UI, 13.09.2026]

```
Patient: $[pvoll]$
Geburtsdatum: $[pg]$ ($[palter_formatiert]$, $[pMW]$)

Diagnosen:
$[x ddi,dia inf _ 14 NN NNJN NNNN invTimemitICD]$

Anamnese, Befunde und bisheriger Verlauf:
$[x ana,bef,the inf _ 30 NN NNJN NNNN invTime]$

Dauermedikation:
$[medikamentenplan]$

Allergien: …
```

### Zwei Platzhaltersysteme nebeneinander

Der Dialog nennt **Makro-Befehle** der Form `{P_NN}`, `{P_VN}`, `{Diagnose}`,
die beim Laden automatisch ersetzt werden — zusaetzlich zu den
`$[…]$`-Briefkommandos in der Vorlage. [UI, 13.09.2026]

> **Offen:** Verhaeltnis und Vorrang der beiden Systeme. Ob `{Diagnose}` und
> `$[x ddi,dia …]$` dieselbe Quelle haben, ob eines das andere ueberschreibt,
> und welche Makro-Namen es ueberhaupt gibt, ist **nicht dokumentiert und nicht
> geprueft.** Bis dahin: **nur `$[…]$` verwenden** — die Syntax ist belegt und
> in `tomedo-kommandos` vollstaendig beschrieben.

---

## 4 · Was das fuers Prompting bedeutet

Der Generator ist die **Anker-Architektur als Produktfunktion**:

| Skill-Baustein | Entsprechung im Generator |
|---|---|
| Anker | Briefkommandos in der Textbaustein-Vorlage |
| Aufgabe | System-Prompt |
| Typdefinition | Kommando-Auswahl je Rubrik (`ana,bef,the` gegen `ddi,dia`) |
| Guard-Satz | **fehlt in der Auslieferung** |

**Der Guard fehlt.** Die ausgelieferte Regelliste enthaelt „Erfinde keine
Informationen hinzu" — das ist eine Negativregel, kein Guard. Ein Guard sagt
dem Modell, dass die **vorgegebenen Werte selbst** unvollstaendig oder veraltet
sein koennen und gegen die Akte zu pruefen sind. Ohne ihn gilt der belegte
Fehlerkatalog: Ein leerer oder falsch beschrifteter Anker wird lautlos
uebernommen. [Referenzinstallation, 08.09.2026]

> **Erste Anpassung an jedem eigenen Kontext:** Guard-Block in den
> System-Prompt aufnehmen. Wortlaut siehe `anker-guard-typdefinition.md`.

---

## 5 · Die Kappungen in der Vorlage

Die ausgelieferte Vorlage kappt **mengenbasiert**, nicht zeitbasiert:

| Rubrik | Kappung |
|---|---|
| Diagnosen | 14 Eintraege |
| Anamnese, Befund, Therapie | 30 Eintraege |

[UI, 13.09.2026]

**Das ist die wichtigste Grenze fuer lange Akten.** Dreissig Eintraege decken
bei einer aktiven Schmerzakte wenige Quartale ab. Eine Mehrjahres-Betreuung
wird damit **stillschweigend abgeschnitten** — das Modell erfaehrt nicht, dass
etwas fehlt, und der System-Prompt verlangt zugleich Vollstaendigkeit.

Die Kombination „harte Mengenkappung plus Vollstaendigkeitsanspruch" ist genau
die Konstellation, in der stiller Inhaltsverlust entsteht.
[Referenzinstallation, 13.09.2026] Siehe `modellgrenzen-und-quellen.md`.

> **Vor jedem produktiven Einsatz:** Kappung gegen die Aktenlaenge pruefen und
> im System-Prompt verlangen, dass der Betrachtungszeitraum benannt wird. Eine
> Angabe wie „Der Bericht stuetzt sich auf die letzten N dokumentierten
> Eintraege" macht die Kappung fuer die freigebende Aerztin sichtbar.

---

## 6 · Abgrenzung zum externen Arztbrief-Verfahren

| Dimension | LLM-Textgenerator | externer Export-Weg |
|---|---|---|
| Datenschutz | kein Anonymisierungsschritt noetig | Anonymisierung als Gate |
| Datengrundlage | mengengekappt, hier 14 / 30 Eintraege | vollstaendiger Aktenexport |
| Eingriff vor dem Lauf | Vorlage ist editierbar | Export ist editierbar |
| Iteration | ein Durchlauf, dann neu generieren | Review-Runden im Dialog |
| Wiederhollauf-Diff | nicht vorgesehen, manuell moeglich | etabliert |
| Zielstruktur | Anamnese, Befund, Diagnose, Therapie | frei, hausspezifisch |
| Rueckweg | Zwischenablage | Zwischenablage |

**Fuer Briefe aus einem ueberschaubaren Zeitraum ist der Generator der
schnellere Weg.** Fuer Mehrjahres-Verdichtung bleibt die Mengenkappung die
offene Frage — und die Zweckbestimmung des Herstellers (`llm-toolebene.md`,
Abschnitt 5) die zweite.

---

## 7 · Offene Punkte

| Nr. | Frage |
|---|---|
| T1 | Laesst sich die Mengenkappung erhoehen, ohne dass der Kontext reisst? Ab welcher Eintragszahl bricht es? |
| T2 | Welche Makro-Befehle `{…}` gibt es, und wie verhalten sie sich zu `$[…]$`? |
| T3 | Ist der Generator tatsaechlich `LLMToolGenerateContextText` — also aus Chat und Aktionskette aufrufbar? |
| T4 | Welches Modell antwortet hier, und folgt es der Chat-Einstellung? |
| T5 | Sind Kontexte praxisweit oder nutzerbezogen? Wer darf sie bearbeiten? |
| T6 | Wirkt `Auf Standard zuruecksetzen` auf den ausgelieferten Kontext oder auf den zuletzt gespeicherten? |
| T7 | Reproduzierbarkeit: dreimal derselbe Kontext, derselbe Patient — wie gross ist die Streuung? |

T1 und T7 sind die beiden, die ueber den produktiven Einsatz entscheiden.

---

*Erhoben 13.09.2026 aus der laufenden Instanz (tomedo v1.170.0.16), zwei
Bildschirmfotos: Hauptfenster und Kontext-Editor. Keine Onlinehilfe-Seite zu
dieser Funktion gefunden; Changelog-Recherche ohne Treffer.*
