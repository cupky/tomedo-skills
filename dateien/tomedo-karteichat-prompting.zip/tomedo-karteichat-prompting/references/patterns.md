# Patterns und Anti-Patterns

> Teil des Skills `tomedo-karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

## Pattern 1: Multi-Turn statt Mega-Prompt

Wenn ein Prompt mehr als ein Ziel verfolgt → aufteilen.

- ❌ Ein Prompt mit Klassifikation + Quellenzuordnung + Lückentext + Fact-Check
- ✅ Schritt 1 nur Klassifikation, Schritt 2 nur Bericht, Endkontrolle extern

Pro Prompt ein Output-Format. Folge-Prompt referenziert mit „basierend auf der oben durchgeführten…". Vor jedem Folge-Prompt ≥30 Sekunden warten.

## Pattern 2: Wörtlicher Lückentext statt abstrakter Struktur

```
============== START LÜCKENTEXT — WORTGLEICH KOPIEREN ==============

**Therapierelevante Diagnosen:**
- {ICD-Code} {Klartext}

**Anamnese und aktuelle Symptomatik:**
{Prosa 150–250 Wörter, Konjunktiv I. Inhalte: …}

============== ENDE ==============
```

Markdown-Headlines werden wortgleich kopiert. Inhaltsangaben gehören **in die Platzhalter**, nicht in eine eigene Sektion — sonst werden sie als alternative Berichtsstruktur missverstanden. Längenangaben pro Platzhalter werden grob eingehalten; absolute Zeichenzahlen nicht (Teil C).

## Pattern 3: Anti-Schmuggel-Liste explizit

Allgemeine Verbote wirken nicht. Konkrete Begriffe namentlich aufzählen:

```
VERBOTENE INHALTE — auch wenn klinisch passend:
❌ Anatomie: LWS, BWS, HWS, ISG, „linkes Bein", „Gesäßbereich"
❌ Neurologie: Fußheberparese, Lasègue, Radikulopathie
❌ Bildgebung: MRT, CT, Röntgen
❌ Datierung körperlicher Beschwerden: „seit Juni 2023"
❌ ICD-Codes ohne wortwörtlichen Quellenbeleg
```

Wirkt erstaunlich gut — auch wenn der Kontext die Begriffe enthält.

## Pattern 4: Wörtliche Begründungs-Templates für Conditional Filter

```
PHASE-B (nur bei wörtlicher Begründung):
  MAIL-Ein → „Pat. beschreibt subjektives Erleben, Stimmung oder Belastung"
  NOTIZ    → „Psychotherapeutische Reflexion zum Therapieprozess"
  BES      → „enthält Marker '(PSY)' oder '(Gespräch, PSY)' im Eintragstext"

Andere Begründungen → Eintrag gehört in Ausgeschlossen.
Verbotene Begründungen: „pt-relevant", „klinisch passend", „psychotherapeutisch relevant"
```

Wildcards wie „pt-relevant" schmuggeln sonst Blacklist-Typen durch.

## Pattern 5: Wartezeit zwischen Folge-Prompts

Bei unter 30 Sekunden kollabiert der Folge-Prompt (leere Outputs). Stichprobe von 5 Iterationen, **zu evaluieren**. Im Zweifel länger warten oder Prompt erneut absenden.

## Pattern 6: Externe Endkontrolle statt interner Selbstprüfung

Fact-Check-Punkte im Prompt werden **performativ** beantwortet. Stattdessen Checkliste beim Anwender:
- Blacklist-Typen in den Quellenlisten?
- Verbotene Begriffe im Output?
- ICD-Codes belegt oder erfunden?
- **Bei Ausgaben nach außen:** Vorbehalte des Quelleintrags mitgeführt oder verloren?

## Pattern 7: Mehrfach laufen lassen

Drei identische Läufe, drei Outputs. Bei produktionskritischen Berichten 2–3× ausführen, nebeneinander prüfen, besten wählen oder mergen, Endkontrolle durch den Anwender.

## Pattern 8: Der vollständige Prompt-Rahmen

Kopierfertig. Reihenfolge ist Teil des Patterns.

```
Harte Fakten aus tomedo:
Aktive Diagnosen: $[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$
Letzter ärztlicher Kontakt: $[d E MN <TYP>]$
Letzter Verlauf im Volltext: $[x <TYP> 1 _ _ NN NJ22 NNND _ _ _]$

Die Angaben oben stammen aus einzelnen Feldern und können veraltet oder leer sein.
Prüfe sie gegen die Kartei. Weiche ab, wenn die Kartei etwas anderes zeigt, und
benenne die Abweichung. Ein leeres Feld bedeutet nicht, dass es den Sachverhalt
nicht gibt.

Ärztliche Kontakte sind Einträge der Typen Anamnese und Therapie. Einträge vom
Typ „Verlauf Physio" und „Verlauf Psychosomatik" sind keine ärztlichen Kontakte.

Aufgabe: <genau eine Aufgabe>. Verwende ausschließlich Daten und Zahlen aus den
Fakten oben und aus der Kartei. Füge keine eigenen Zahlen, Werte oder Zeitangaben
hinzu. Wenn die Akte eine Einschränkung zur Aussagekraft enthält, übernimm sie
wörtlich.
```

Der letzte Satz ist die Gegenmaßnahme zum asymmetrischen Informationsverlust: der Vorbehalt wird nicht dem Zufall überlassen, sondern beauftragt. Wirkt am besten in Kombination mit einem Anker, der den betreffenden Eintrag im Volltext einspielt — dann ist der Vorbehalt nicht mehr aufzufinden, sondern vorgelegt.

## Pattern 9: Arbeitsteilung Kommando ↔ Modell

Die Akte teilt sich in zwei Zonen. Die Linie ist verschiebbar — durch Dokumentationsstruktur, nicht durch Prompting.

| Zone | Inhalte | Beschaffung |
|---|---|---|
| **Verankerbar** | Stammdaten, ICD-Codes, Daten, Eintrags-Volltexte, CKE- und Formularfelder | Kommando, deterministisch |
| **Nicht verankerbar** | Werte im Fließtext (NRS, Gehstrecke, PHQ-9, MPSS, von Korff), Zusammenhänge, Formulierung | Modell |

Zahlen und Daten aus Kommandos, Sprache und Extraktion aus dem Modell. Wer eine Kennzahl dauerhaft auswertbar braucht, verschiebt sie durch einen CKE oder ein PatF-Feld über die Linie.

---

---

# Anti-Patterns

| Anti-Pattern | Beobachtung |
|---|---|
| Anker ohne Guard | Vorgegebener Wert schlägt die Aktenlage, 3/3 |
| Anker ohne Typdefinition bei Fachbegriffen | Streuung, 1/3 richtig |
| Anker ohne Auftrag | Wert wird interpretiert statt verwendet |
| Anker nie einzeln getestet | `-` sieht wie ein Leerwert aus und fällt nie auf |
| Beschriftung beschreibt den Wunsch, nicht das Kommando | Nicht durch Prompting reparierbar |
| Absolute Zeichenzahl als Vorgabe | 0/8 eingehalten |
| Auf Übernahme von Vorbehalten hoffen | 0/4 übernommen, während 4/4 die Nutzenhälfte übernahmen |
| Mehrere Constraints in einem Prompt | Trade-off-Rutschen |
| „Bitte strukturiere in 4 Abschnitte: …" | Modell erfindet eigene Headlines |
| Self-Check mit Beweispflicht | Compliance wird behauptet, nicht belegt |
| Inhaltliche Leitlinien als eigene Sektion | Wird als Berichtsstruktur missverstanden |
| Freie Begründungen für Conditional Filter | Wildcards reichen Blacklist-Typen durch |
| Lange Konsolidierungsaufgaben in einer Phase | Output kollabiert leer |
| Annahme „Lauf 1 = Lauf 2" | Variabilität ist inhärent |
| Verlass auf Anlageninhalte | PDF ist für den Chat nicht existent |

---
