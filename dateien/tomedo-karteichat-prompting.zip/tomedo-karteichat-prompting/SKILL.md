---
name: tomedo-karteichat-prompting
description: >-
  Erstellt und debuggt Prompts und Prompt-Ketten fuer den tomedo KarteiChat (Agent mit
  Werkzeugebene; Modell wechselbar ueber den zollsoft-Support). Verwende diesen Skill IMMER wenn
  KarteiChat-Prompts, Multi-Turn-Prompts in tomedo, Briefe via KarteiChat, Berichte aus
  Karteieintraegen, Kurzberichte, Arztbriefe oder Antraege automatisiert generiert werden sollen.
  Auch bei: Prompt rutscht, Modell ignoriert Vorgaben, Filter-Bruch trotz Regeln, Output zu lang
  oder leer, Briefkommando im Prompt, harte Fakten verankern, Anker, Guard-Satz, Typdefinition,
  Modell nennt falsches Datum, Kartei wird nicht durchsucht, Anlage wird nicht gelesen, Vorbehalt
  geht verloren, KarteiChat testen, Testprotokoll. Ebenso bei: welche Tools hat der KarteiChat,
  LLMTool, Toolebene, Werkzeugzugriff, Quellenverknuepfung, Zweckbestimmung, Promptverwaltung,
  Textbaustein als Prompt, Modellwahl im Chat, Flash gegen Pro. Der Skill ist ein Navigator; die
  Inhalte liegen in references/.
metadata:
  version: 1.4
---

# tomedo KarteiChat Prompting Skill

Best Practices für Prompts und Prompt-Ketten im tomedo KarteiChat. **Navigator** — die Inhalte liegen in `references/`.

> **Belegbasis:** Prompt-Engineering-Session psychotherapeutischer Kurzbericht (05/2026), eine Testserie an einer synthetischen Demoakte (09/2026) und eine kontrollierte Benchmark an **zwei** synthetischen Demoakten: **376 protokollierte Läufe**, davon **100 mit Verankerung per Briefkommando**. Jeder Lauf einzeln gegen den **tomedo-Volltextexport beider Akten einschließlich aller Anlagen** beziehungsweise gegen die Kommandoausgabe geprüft [Referenzinstallation, 22.09.2026].
>
> ⚠️ **Der Chat hat zwei Betriebsarten.** Alle Quoten dieses Skills messen den Betrieb **ohne** Briefkommandos — den Weg, den ein Anwender geht, der einfach tippt. Jede dort belegte Fehlerklasse ist eine **Abruffehlerklasse**. Die zweite Betriebsart steht unter „Transportkanal: Prompt als Textbaustein".

**Statuskennzeichnung:** **belegt** = mehrfach beobachtet, Läufe protokolliert · **plausibel** = einmal beobachtet oder abgeleitet · **zu evaluieren** = Vermutung.

---

## Wann diesen Skill verwenden

- Neue KarteiChat-Prompts für strukturierte Outputs (Berichte, Briefe, Anträge)
- Debugging bestehender Prompts, die unzuverlässig laufen
- Prompts, in die Briefkommandos eingebettet werden
- Multi-Turn-Prompt-Ketten entwerfen
- Testprotokolle für KarteiChat-Verhalten aufsetzen
- Vorbereitung von Forumsbeiträgen / Erfahrungsaustausch

**Nicht für:** den Bau von Briefvorlagen selbst (→ `tomedo-kommandos`), statische Textbausteine (→ `tomedo-textbausteine`), HQL-Auswertungen (→ `tomedo-statistik-hql`).

---

## Der Kern in fünf Sätzen

**Briefkommandos werden im KarteiChat-Eingabefeld aufgelöst** — etwa eine Sekunde nach dem Einfügen steht anstelle von `$[…]$` der Datenbankwert. Damit lässt sich eine Tatsache **vorgeben** („Anker"), statt sie das Modell erschließen zu lassen. Ein Anker bringt aber nur einen **Wert** mit, keine **Bedeutung**: die Beschriftung daneben prüft niemand, und ein vorgegebener Wert schlägt die Aktenlage. Gegen diesen Effekt wirken zwei Zusätze — ein **Guard-Satz**, der dem Anker die Unantastbarkeit nimmt, und eine **Typdefinition**, die den Fachbegriff der Frage in Karteieintragstypen ausdrückt. Die Typdefinition ist der wirksamste Baustein, der Guard der billigste, ein **leerer Anker** der gefährlichste Fehler. Ein vierter Baustein kommt hinzu, sobald man den Chat als **Agenten mit Werkzeugen** versteht: die **Werkzeuganweisung** — dem Modell sagen, *welches* Werkzeug es für eine Teilfrage benutzen soll. Der stärkste Fall ist das Umleiten einer strukturierten Frage auf ein Spezialwerkzeug statt auf den Karteivolltext, der billigste das Setzen eines Datumsfilters. Inventar und Formulierungen: `references/toolinventar-und-hebel.md`.

> ⚠️ **Widerrufen:** die Skill-v1-Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat" ist falsch und entfernt.

> ⚠️ **Widerrufen:** „einfaches Gemini-Modell" als Systemeigenschaft. Der Chat nutzt
> standardmaessig ein Google-Gemini-Modell; andere Modelle stehen auf Anfrage beim
> zollsoft-Support zur Verfuegung [Hersteller, 11.09.2026]. Vor jeder Modellgrenzen-Analyse
> pruefen, **welches** Modell antwortet. Eigene A/B-Messung: der Sprung Flash → Pro bringt
> keinen Qualitaets-, sondern einen **Konstanzsprung** — Laengenstreuung 142 statt 2444
> Zeichen bei gleicher Fachqualitaet [Referenzinstallation, 13.09.2026]. Details in `references/llm-toolebene.md`.

> ⚠️ **Zweckbestimmung.** Der Hersteller grenzt den Chat auf das *Auffinden vorhandener*
> Informationen ein; Auswertung und Interpretation zur Diagnose- und Therapieunterstuetzung
> sind ausgeschlossen [Hersteller, 11.09.2026]. Verdichtungs-Prompts brauchen eine Begruendung.

### Die zwei Befunde, die jede Prompt-Planung vorab kennen muss

**1 · Er prüft so gut wie nichts nach.** Der Chat rechnet nicht gegen und bemerkt Widersprüche
in der Akte nicht — auch dann nicht, wenn er die widersprechenden Werte im selben Satz selbst
nennt. **1 von 98 Läufen** hat einen belegten Aktenwiderspruch markiert, und dieser eine nur,
weil die Frage unmittelbar darauf zielte. Lag der Widerspruch bloß im Kontext, waren es **0 von
78**. Die Gegenrichtung ist häufiger: **3 von 20** Läufen reichten die falsche Aktenaussage mit
Quellenangabe weiter, einer davon verschärfte sie zu einem falschen Anfangsdatum.

> **Jede Zahl, die in der Akte falsch steht, kommt mit ruhiger Stimme zurück.**

**2 · Er halluziniert selten. Er konserviert.** In 376 Läufen an zwei Akten: **drei** belegte
Erfindungen, unter einem Prozent. Wer einen „erfundenen" Wert findet, prüft zuerst die Akte —
er steht überraschend oft darin. Vier Soll-Angaben zweier sorgfältig gebauter Testdrehbücher
erwiesen sich gegen den Volltextexport als falsch, **alle vier zu Lasten des Chats**.

> **Die fünfte Rücknahme traf den Prüfer selbst.** Eine gemeldete Dosisangabe sah nach
> Erfindung aus und stand wörtlich in der Akte — die Ground Truth des Auswerters war
> unvollständig. **Wer einem Modell einen Fehler nachweisen will, prüft zuerst den eigenen
> Anker.**

**Was daraus für die Planung folgt:** Fragen Sie nach **Werten**, nicht nach **Ergebnissen**.
„Welcher Wert steht dort" ist die sicherste Aufgabe des Bestands. „Wie lange", „wie alt",
„wie viele" ist die unsicherste — dort muss die Antwort erst entstehen, und genau dort prüft
er nicht nach.

### Der belegte Fehlerkatalog

| Konstellation | Guard | Typdefinition | Ergebnis (3 Läufe) |
|---|---|---|---|
| Anker falsch beschriftet | – | – | **3/3 falsch**, identisch |
| Anker leer, Nebenfrage | – | – | **3/3 Recherche abgebrochen** |
| Anker löst nicht auf (`-`), Antwortslot | – | – | **3/3 falsch**, lautlos gefüllt |
| Anker falsch beschriftet | ✓ | – | **1/3 richtig**, Streuung inkl. Systemdatum |
| Anker falsch beschriftet | ✓ | ✓ | **3/3 richtig**, Abweichung benannt |
| Kein Anker, Freitext-Extraktion | – | – | **3/3 vollständig richtig** |

#### Drei Negativbefunde, gemessen

**Das Quellenkürzel ist kein Beleg.** Der Chat hängt `[ANA]`, `[THE]`, `[PSY]`, `[SCAN]` an
seine Sätze. Das Kürzel markiert, **worauf er sich bezieht**, nicht, **woher der Wert stammt**.
In allen drei Fehlläufen einer 20er-Serie stand `[SCAN]` an einem Wert, der nicht aus dem Scan
kam. In 4 von 20 Läufen einer anderen Serie stand ein Kürzel an einer **Verweigerung**
(„nicht dokumentiert [PHY]").

**Der Zitatzwang kostet nichts und bringt viel.** Der Zusatz *„Zitiere die Textstelle wörtlich,
mit Datum und Typ des Eintrags. Rechne nichts aus."* — A/B über beide Akten, 78 Läufe:

| | ohne Zusatz | mit Zusatz |
|---|---|---|
| Läufe | 40 | 38 |
| **wörtliches Zitat mit Datum und Typ** | **0** | **37** |
| Fundstelle frei erfunden | 1 | 1 |

Je eine Erfindung in jedem Arm — **kein messbarer Unterschied.** Der Zusatz erhöht die
Erfindungsrate nicht und macht 37 von 38 Antworten in zehn Sekunden prüfbar.

> **Ein Zitat ist erst ein Beleg, wenn der Eintrag aufgeschlagen ist.** Die Gegenprobe
> `Gib den Eintrag vom {Datum} wörtlich wieder.` ist **25/25 zeichengenau** belegt und kostet
> zehn Sekunden.

**Er schreibt seinen eigenen Prompt nicht.** *„Schreibe mir den Prompt dafür."* — **0 von 5**
brauchbar; zwei Läufe gaben Programmcode gegen die interne Werkzeugebene aus. Streuung SD 410
bei Median 610. Als Baustein widerrufen.

### Der stille Inhaltsverlust

Die gefährlichste Abweichung ist die, die **formal korrekt aussieht**. In der A/B-Messreihe
am LLM-Endpunkt erfüllte ein Lauf **alle sechs Prüfkriterien** — drei Rubriken, korrekte
Zeilenanfänge, je zwei Merkmale, keine Formatierungszeichen, fachlich richtig,
literaturgedeckt — und **ließ trotzdem einen von drei geforderten Inhaltsblöcken
vollständig weg**. Ursache: Das Modell schnitt die Rubriken nach einer anderen Achse
(Vergleichsdimensionen statt Sachtypen) und füllte die geforderte Rubrikzahl damit auf.
Das schwächere Modell tat das in 2 von 5 Läufen, das stärkere in 0 von 5.
[Referenzinstallation, 13.09.2026]

**Zwei Regeln folgen daraus:**

1. **Die Gliederungsachse gehört in die Strukturvorgabe.** „Bilde drei Rubriken" reicht
   nicht — es muss stehen, **wonach** gegliedert wird. Eine Zahl allein ist erfüllbar,
   ohne die Aufgabe zu erfüllen.
2. **Vollständigkeit ist ein eigenes Prüfkriterium.** Ein Raster aus Form und Fachlichkeit
   lässt fehlende Inhalte durch. Jeder Testkatalog braucht die Frage: *Kommt jeder
   geforderte Gegenstand im Ergebnis vor?* — getrennt von der Frage, ob das Ergebnis
   richtig ist.

Besonders scharf wird der Effekt, wenn eine **Mengenkappung** auf einen
**Vollständigkeitsanspruch** trifft — etwa im LLM-Textgenerator, dessen ausgelieferte
Vorlage auf 30 Karteieinträge kappt, während der System-Prompt Vollständigkeit verlangt
(`references/llm-textgenerator.md`).

#### „Nicht dokumentiert" heißt nicht „steht nicht in der Akte"

Der zuverlässigste Prompttyp des Bestands — die geschlossene Faktenfrage mit
Verweigerungserlaubnis — ist **genau dann unzuverlässig, wenn der gesuchte Wert in einer
Anlage liegt.** Er meldet ihn als fehlend und warnt nicht davor.

| dieselben 20 Läufe, dieselben vier Fragen | Quote |
|---|---|
| gegen den **Karteitext** gewertet | 77/80 · **96 %** |
| gegen **Karteitext plus Anlagen** gewertet | 57/80 · **71 %** |
| Läufe, die die ganze Akte treffen | **0/20** |

Die vierte Frage lautete „Welche Gehstrecke ist in der Zweitmeinung dokumentiert?". Antwort
**20/20 „nicht dokumentiert"**. In der Anlage zu diesem Eintrag steht „Gehstrecke **unbegrenzt**
bei mäßigen Beschwerden" — bei einer Spinalkanalstenose das Argument gegen die Dekompression.

> **Ein „nicht dokumentiert" heißt: steht nicht dort, wo ich gesucht habe.**

**Zwei Ausfallmodi, die nichts an der Antwort verrät:**

| Modus | Häufigkeit | Verhalten |
|---|---|---|
| **Anlagen-Leser läuft nicht an** | 10 von 65 · 15 % | nimmt den nächstbesten Wert aus dem Karteitext und etikettiert ihn falsch; in 5 von 8 Fällen wurde das **Eintragsdatum als Briefdatum** ausgegeben |
| **Karteitext-Abruf läuft nicht an** | 1 von 20 · 5 % | verweigert alle vier Teilfragen in derselben ruhigen Form wie die 19 richtigen Läufe |

**Erkennungsmarker ohne Aktenkenntnis:** Enthält die Antwort nichts, was nicht schon im
Karteitext steht, wurde die Anlage nicht geöffnet.

**Konsequenz für die Prompt-Planung.** Bei jedem Wert, der aus einem Fremdbrief, einem
Klinikbefund oder einer Zweitmeinung stammen könnte, die Anlage **ausdrücklich** ansprechen.
Und bei der Auswertung eines Testlaufs **doppelt werten**: einmal gegen den Karteitext, einmal
gegen die ganze Akte. Ohne diese Trennung erscheint der Faktenblock als 96-Prozent-Aufgabe,
obwohl kein einziger Lauf die ganze Akte trifft.

> ⚠️ **Nur zwei Abrufebenen sind überhaupt gemessen.** Beide Demoakten enthalten **keine
> Formulare, keine Rezepte, keine AU-Bescheinigungen, keine Leistungsziffern, keine Laborwerte**.
> Ob der Chat diese Ebenen sieht, ist **nicht gemessen und an diesem Material nicht messbar**.
> „Nicht dort, wo ich gesucht habe" ist bisher an **einer** verborgenen Ebene belegt — es gibt
> mindestens vier weitere.

### Der Prompt-Rahmen

```
Harte Fakten aus tomedo:
Aktive Diagnosen: $[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$
Letzter ärztlicher Kontakt: $[d E MN <TYP>]$

Die Angaben oben stammen aus einzelnen Feldern und können veraltet oder leer sein.
Prüfe sie gegen die Kartei. Weiche ab, wenn die Kartei etwas anderes zeigt, und
benenne die Abweichung. Ein leeres Feld bedeutet nicht, dass es den Sachverhalt
nicht gibt.

Ärztliche Kontakte sind Einträge der Typen Anamnese und Therapie. Einträge vom
Typ „Verlauf Physio" und „Verlauf Psychosomatik" sind keine ärztlichen Kontakte.

Aufgabe: <genau eine Aufgabe>. Verwende ausschließlich Daten und Zahlen aus den
Fakten oben und aus der Kartei. Füge keine eigenen Zahlen, Werte oder Zeitangaben
hinzu. Wenn die Akte eine Einschränkung zur Aussagekraft enthält, übernimm sie
wörtlich.
```

Herleitung, Wirkungsnachweise und die Entscheidungsregel „verankern oder nicht" → `references/anker-guard-typdefinition.md`.

---


### Emoji dürfen keine Semantik tragen

> Die Baustein-Seite dieser Regel — Zeichensatzfalle beim Export, `___`-Notation,
> Sichtbarkeitsstufen — steht im Skill `tomedo-textbausteine`. Hier geht es nur darum,
> was das für den Prompt-Bau bedeutet.

Prompt-Bausteine setzen gern `✅ / ⚠️ / ❌` als Phasenmarker ein. Das ist lesefreundlich und
funktional riskant: diese Zeichen liegen ausserhalb von cp1252 und werden im RTF-Langtext eines
Textbausteins als `\uN?`-Escape gespeichert. Bei Export/Reimport, Encoding-Wechsel oder Copy-Paste
ueber Systemgrenzen kann der Escape verloren gehen — dann bleibt das Fallback-Zeichen stehen und
die Regel wird stillschweigend bedeutungslos.

**Regel:** Jede Zeile, deren Bedeutung an einem Emoji haengt, bekommt ein ASCII-Label als
Redundanz. Das Emoji bleibt Dekoration.

```text
# schlecht — Bedeutung haengt am Zeichen
PHASE-C:
❌ ANA, T, SCHMA, BEF

# gut — Bedeutung steht im Text, Emoji ist optional
PHASE-C (VERBOTEN, auch wenn der Inhalt passt):
- VERBOTEN: ANA, T, SCHMA, BEF
```

Gleiches gilt fuer `→` in Begruendungs-Templates (durch `=>` oder `:` ersetzbar) und fuer
typografische Striche in Zahlenbereichen (`150–250 Wörter` → `150-250 Wörter`).

**Pruefschritt vor Auslieferung:** Baustein einmal exportieren, reimportieren und die
Nicht-ASCII-Zeichen zaehlen. Weicht die Zahl ab, ist der Baustein nicht transportsicher.

### Markdown hat zwei Adressaten

> Wie Markdown im Textbaustein selbst behandelt wird, regelt `tomedo-textbausteine`.
> Hier steht nur die Folge für den Prompt.

Der Lueckentext arbeitet mit `**Fett**`-Headlines. Die werden an **zwei** Stellen wirksam und
verhalten sich dort unterschiedlich:

| Ziel | Verhalten |
|---|---|
| Chat-Fenster | Markdown-Rendering ist laut zollsoft-Forum-Antwort inzwischen moeglich — `**` wird zu Fettschrift |
| Karteieintrag nach Copy-Paste | Markdown wird **nicht** interpretiert; `**` landet als Literal im Text |

**Konsequenz fuer den Prompt-Bau:** Entscheide vor dem Bau, wohin der Output geht.

- **Ziel Karteieintrag:** Headlines ohne `**` vorgeben (`Therapierelevante Diagnosen:`). Sonst muss
  jede Ausgabe manuell nachgeputzt werden — und in einer Messreihe wird der Putzaufwand faelschlich
  dem Modell zugerechnet.
- **Ziel Brief/Weiterverarbeitung:** `**` ist unschaedlich, solange die Zielpipeline Markdown kennt.
- **Bei Messungen:** vorher festlegen, ob Markdown-Reste als Formatfehler zaehlen. Ohne diese
  Festlegung ist ein Score zwischen zwei tomedo-Versionen nicht vergleichbar, weil sich das
  Rendering-Verhalten geaendert hat.

XML-Tags (`<diagnosen>…</diagnosen>`) sind gegen dieses Problem immun — sie werden in keinem der
beiden Ziele gerendert und sind deterministisch per Regex abgreifbar. Fuer maschinelle
Weiterverarbeitung deshalb vorzuziehen.

### Das Modell ist keine Konstante

Laut Onlinehilfe verarbeitet der Kartei-Chat Karteiinhalte mit einem LLM; **standardmaessig Google
Gemini**, andere Modelle sind **auf Anfrage beim zollsoft-Support verfuegbar**. Daraus folgen drei
Arbeitsregeln:

1. **Keine Prompt-Version ohne Modellstempel.** Wer eine Prompt-Kette dokumentiert oder ihre
   Ergebnisse zitiert, notiert tomedo-Version, Datum und — soweit ermittelbar — die Modellkennung.
   Ohne Stempel sind Aussagen wie „v7 haelt die Struktur zu 90 %" nicht reproduzierbar.
2. **Modellidentitaet ist erfragbar, nicht nur erratbar.** Ein Probe-Prompt zeigt nur den
   Ist-Zustand. Fuer die Historie (welches Modell lief zu welchem Zeitpunkt im eigenen Account)
   ist der Support die Quelle.
3. **Patterns dieses Skills sind an eine Modellklasse gebunden, nicht an „den KarteiChat".**
   Nach einem Modellwechsel gelten sie als unbestaetigt, bis sie neu gemessen wurden. Insbesondere
   koennen Multi-Turn-Aufteilung und Anti-Schmuggel-Liste bei einem stärkeren Backend zu
   ueberfluessigem Aufwand werden.

**Quellenverknuepfung ist Backend-Eigenschaft, nicht Prompt-Leistung.** Die Onlinehilfe beschreibt,
dass jede Information, die der Chat liefert, mit ihrer Quelle in der Kartei verknuepft wird. Wer
in einem Prompt zusaetzlich „gib Datum und KE-ID an" fordert, misst also nicht nur das Modell,
sondern auch dieses Retrieval. Bei Vergleichsmessungen ueber Versionsgrenzen hinweg ist das ein
Confounder und gehoert ins Protokoll.

**Bekannte Grenze:** Laborbefunde sind laut zollsoft-Antwort im Forum nicht durchsuchbar. Prompts,
die Laborverlaeufe auswerten sollen, scheitern nicht am Prompt-Design.


### Was die Verdichtung überlebt — und was systematisch verschwindet

Die Trennlinie verläuft **nicht** zwischen Befund und Anweisung, sondern zwischen
**konkret-terminiert** und **einschränkend**. 20 Verdichtungsläufe an einer Akte:

| was verdichtet werden soll | überlebt |
|---|---|
| **Termin:** „vierter Denervierungszyklus für Oktober 2026" | **19/20** |
| stehendes Angebot: „Rückenmarkstimulation abgelehnt, **Angebot bleibt bestehen**" | **3/20** |
| **Vorbehalt:** „wiederkehrendes und **kein heilendes** Verfahren" | **1/20** |

Aktenübergreifend, 25 Verdichtungsläufe: der Vorbehalt überlebt **1 Mal**. Dazu ein halbierter
Lauf, der „über die Art des **wiederkehrenden** Verfahrens aufgeklärt" schreibt und
„kein heilendes" weglässt — die tragende Hälfte.

> **Was terminiert und konkret ist, überlebt. Was einschränkt, verschwindet.**

**Das stehende Angebot zeigt die Richtung des Schadens.** 17 von 20 Läufen schreiben, der
Patient habe die Rückenmarkstimulation **abgelehnt**; nur 3 behalten, dass das **Angebot
bestehen bleibt**. Aus einer offenen Option wird eine erledigte Ablehnung.

**Der Aktenfehler wandert ungefragt in die Übergabe.** 7 von 20 Läufen übernahmen eine
nachweislich falsche Monatszahl aus der Akte in die Zusammenfassung, ohne dass jemand danach
gefragt hatte. Keiner markierte sie.

**Der Vorbehalt kann in sein Gegenteil kippen.** In der Akte steht, dass aus dem Verlauf
**kein** Kausalzusammenhang folgt. Ein Verdichtungslauf schrieb: „der konservative
Behandlungsweg wurde als **erfolgreich bewertet**, **obwohl** es drei nicht umgesetzte
Operationsempfehlungen gab." Das „obwohl" kehrt den Vorbehalt um.

**Prioritätsfehler, an beiden Akten belegt.** Je ein Lauf mischte Administratives in eine
medizinische Zusammenfassung — einmal den Hinweis „SYNTHETISCHE DEMOAKTE — NICHT ABRECHNEN",
einmal einen Zusammenführungsvermerk als **ersten Satz** vor Diagnosen und Verlauf. Beide
Male las der Chat ein **Kurzinfo-Feld, das nicht Teil des Kartei-Exports ist**.

**Regel:** Vorbehalte, Einschränkungen und stehende Angebote **ausdrücklich anfordern**.
Termine nicht — die kommen von allein.

## Transportkanal: Prompt als Textbaustein

Ein Prompt ist im Kartei-Chat kein Freitext, sondern ein Artefakt mit Pflegeort und
Ausspielungsweg. Die folgenden Punkte sind aus der Onlinehilfe bzw. aus zollsoft-Antworten im
Forum belegt.

**Was zollsoft vorgibt**

| Punkt | Beleg |
|---|---|
| Textbausteine dienen als vorkonfigurierte Prompts; mehrere werden mitgeliefert, eigene sind ergaenzbar | Onlinehilfe, Kartei-Chat |
| Freigabe ueber Reiter *Sichtbarkeit* (Kartei-Chat oder Support-Chat), **nutzeruebergreifend** | Onlinehilfe |
| Pflegeort ohne Umweg ueber die Makroverwaltung: Verwaltung → Sprechstunden-Assistent → KI-Assistenten-Verwaltung; dort auch Schnell-Button ein/aus und Buttonfarbe | Onlinehilfe |
| Platzhalter `___` im Baustein erlaubt, vor dem Absenden an dieser Stelle Text zu ergaenzen | Onlinehilfe |
| Schnell-Buttons loesen den Prompt **direkt** aus | Onlinehilfe |

**Es gibt kein zollsoft-Regelwerk zur inhaltlichen Prompt-Formulierung.** Die einzige
Schreibempfehlung des Herstellers steht auf der Sprechstunden-Assistent-Seite: in der Beschreibung
angeben, welche Inhalte dokumentiert werden sollen, inklusive Formatierungshinweisen (Beispiel dort:
Bewegungsmaße immer als drei Winkelwerte, getrennt durch Schrägstriche). Die Patterns dieses Skills
stehen also nicht in Konkurrenz zu einer Hersteller-Konvention, sondern fuellen eine Luecke.

**Ausloeseweg ist verhaltensrelevant.** Aus einem Forum-Fall: wird ein Prompt per Schnell-Button
ausgeloest, verliert das Modell den Bezug zu einem vorher per Drag&Drop eingefuegten PDF. Nur
gemeinsames Senden von Anhang und Prompt-Text funktioniert — also Prompt aus dem Textbaustein
kopieren und einfuegen statt den Button zu klicken.

**Regeln fuer den Skill-Einsatz**

1. **Ein Ausloeseweg pro Arbeitsablauf.** Button oder Paste, nicht gemischt. Bei Anhaengen (PDF,
   gescannter Brief) zwingend Paste.
2. **`___` fuer variable Anteile nutzen**, statt fuer jede Adressatenvariante einen eigenen
   Baustein zu pflegen. Bei Multi-Turn-Ketten aber sparsam — jede Fuellstelle ist eine
   Fehlerquelle im Ablauf.
3. **Kuerzel-Konvention und Reihenfolge dokumentieren.** Bei Multi-Turn muss aus dem Kuerzel die
   Schrittnummer hervorgehen (`v7.1` vor `v7.3`), sonst wird die Kette falsch bedient.
4. **Nutzeruebergreifende Freigabe bedenken.** Eine Sichtbarkeitsaenderung wirkt fuer alle
   Nutzer; Testbausteine gehoeren nicht in die Chat-Freigabe.

---

## Die zweite Betriebsart: Verankerung per Briefkommando

Alles bisher Gesagte beschreibt den Betrieb, in dem **das Modell abruft**. Das ist die
schlechtere der beiden Betriebsarten. Ein in das Chat-Eingabefeld eingefügtes Briefkommando
wird von tomedo **zwischen 0,25 s und 0,5 s** durch den Aktenwert ersetzt — der Chat sieht nur
noch den aufgelösten Text. Gilt mehrzeilig und bei großen Ausgaben; ein Anker über die gesamte
Therapiehistorie lieferte 3816 Zeichen datierten Text.

**Der Prompt trägt die Aktendaten selbst hinein. Es gibt keinen Abruf, der fehlschlagen kann.**

### Was das repariert — und was nicht

| | Befund |
|---|---|
| Fehlerklasse „findet nicht" | **entfällt** für strukturiert gepflegte Daten |
| Fehlerklasse „prüft nicht", verankert **neutral** gefragt | **0/20** — aktenübergreifend **0/118** |
| dieselbe Frage **mit Prüfauftrag** | **18/20** markieren die Abweichung, **17/20** rechnen richtig |
| wo der Abruf ohnehin trägt | keine Verbesserung, **SD 8 → 73** |

> **Verankerung ersetzt das Suchen, nicht das Denken.**

Beide Hälften sind nötig. Der Prüfauftrag allein hätte nichts, wogegen er prüfen könnte — die
Datumsangaben stehen nur im Kontext, weil das Kommando sie hineingeholt hat. Die Verankerung
allein bewirkt nichts; die Antworten wurden sogar **kürzer** (Median 94 Zeichen). Erst zusammen
heben sie das Erkennen von Aktenwidersprüchen **von 0 aus 118 auf 18 aus 20** — der einzige
gemessene Eingriff, der eine als unreparierbar belegte Fehlerklasse repariert.

**Nicht jeden Prompt verankern.** Bei einer Frage, die der Abruf sicher beherrscht („Nenne alle
aktiven Dauerdiagnosen mit ICD-Code"), liefern beide Arme 20/20 — die Verankerung **verneunfacht
aber die Streuung**.

### Der wirksame Baustein, wörtlich wie gemessen

```
Hier sind die Therapie-Einträge der Akte mit Datum:

$[x THE 40 _ _ JN NJ22 NNND invTime K 0]$

{Frage}

Prüfe die Angabe gegen die Datumsangaben oben. Weicht sie ab, benenne die
Abweichung ausdrücklich und nenne beide Zahlen.
```

### Das Restrisiko

2 von 20 versagen. Der gefährlichere Fehllauf **behauptet Konsistenz** — „die Angabe ist
konsistent in den Einträgen zum … vermerkt" —, nennt beide Eckdaten und rechnet trotzdem nicht.
Die Antwort klingt nach durchgeführter Prüfung. **Mehrfach wiederholt ist nicht richtig.**

### Die Reichweitengrenze

**Kommandos lesen keine PDF-Anhänge.** Werte aus Fremdbriefen erreicht nur der Abruf. Die
beiden Betriebsarten ersetzen einander nicht: Anlagen erreicht nur der Abruf, Prüfbarkeit nur
die Verankerung.

### Die Abhängigkeit von der Pflege — der Befund mit der größten Tragweite

Die Kommando-Inventur wurde an derselben Akte **zweimal** gefahren: einmal vor und einmal nach
einer Nachpflege durch die Praxis. Das Ergebnispaar ist selbst der Beleg.

| Kommando | vor der Pflege | nach der Pflege |
|---|---|---|
| Verordnungen (`x MED`, `x REZ`) | LEER | **OK — mit PZN, Dosis, Einnahmeschema** |
| Arbeitsunfähigkeit (`x AU`) | LEER | **OK** |
| Freitextdiagnosen (`x DIAX`) | LEER | **OK** |
| `medikamenteVorhanden` | 0 | **1** |
| Dauerdiagnosen, Anamnese, Therapie | OK | OK |
| Leistungen, Labor, Termine, Scheindiagnosen | LEER | LEER |

> **Von zwei auf fünf nutzbare Datenklassen — durch Pflege, nicht durch ein besseres Modell.**

Das ist der wichtigste Satz dieses Abschnitts: **Briefkommandos koppeln den KI-Nutzen
unmittelbar an die Dokumentationsdisziplin.** Wer strukturiert pflegt, kann verankern. Wer alles
in den Freitext schreibt, bleibt auf den Abruf angewiesen — und damit auf die Fehlerquoten der
ersten Betriebsart. Kein Prompt-Kniff ersetzt das.

> **Pflichtschritt vor dem Bau:** jedes vorgesehene Kommando einzeln über
> `Admin › Kommandos › [Ausführen]` gegen eine echte Akte prüfen. Ein Kommando, das ins Leere
> greift, liefert **lautlos nichts** — der Prompt ist dann wieder ein unverankerter, ohne dass es
> jemand merkt. Die Inventur der eigenen Installation gehört in `references/praxis-interna.md`.

### Zwei Fallen, die den Anker still entwerten

**1 · `invTime` wählt vom Aktenanfang, nicht vom Ende.** `$[x ANA,THE 8 … invTime …]$` lieferte
die **ältesten** Einträge (2021–2024) statt der jüngsten. Der Chat verglich daraufhin die
heutige Verordnung mit der Medikation von vor vier Jahren — **korrekt gerechnet, am falschen
Material**, und die Antwort sah genauso souverän aus wie eine richtige.

Ohne den Flag kommen die neuesten Einträge. **Bei kleinen Anzahlen entscheidet dieser Flag
darüber, ob aktuelle oder historische Daten verankert werden.** Bei großen Anzahlen (40) fällt
er nicht auf, weil ohnehin die ganze Akte im Anker liegt — genau deshalb ist er bei kleinen
Anzahlen gefährlich.

**2 · Tabellenerzeugende Kommandos lösen im Chat-Eingabefeld nicht auf.** `medikamentenplan`
und `med` bleiben leer, **obwohl `medikamenteVorhanden` den Wert 1 meldet**. Nur
textproduzierende Kommandos werden ersetzt.

> Das ist die tückischste Kombination des Bestands: Die Prüfabfrage sagt „Daten vorhanden", das
> eigentliche Kommando liefert nichts, und der Prompt läuft unverankert weiter.

Der Umweg führt über den Karteieintragstyp: **`$[x MED …]$` statt `$[medikamentenplan]$`.**

### Der gemessene Anwendungsfall: Medikationsabgleich

Der stärkste Baustein des Bestands, 20 Läufe. Zwei Anker plus Prüfauftrag — Verordnung gegen
Karteitext:

```
Verordnete Präparate laut Rezepthistorie:

$[x MED _ _ _ NN NNNN NNNN _ K _]$

Medikation laut den jüngsten Karteieinträgen:

$[x ANA,THE 6 _ _ JN NJ22 NNND _ K 0]$

Gleiche beide Listen ab. Nenne je Präparat, ob es in beiden steht und ob die
Dosisangaben übereinstimmen. Weicht etwas ab, benenne die Abweichung
ausdrücklich mit beiden Werten.
```

Aufgelöst 5783 Zeichen.

| | |
|---|---|
| **Dosisabweichung gefunden** | **20/20** |
| ausdrücklich als Abweichung benannt | 19/20 |
| **Handelsname und Wirkstoffname als dasselbe erkannt** | **18/20** |
| nur verordnetes Präparat als solches erkannt | 18/20 |
| übereinstimmendes Präparat als übereinstimmend erkannt | 15/20 |
| **Präparat erfunden** | **0/20** |
| Abweichung mit dem Verordnungsdatum wegerklärt | 0/20 |

**Die Gleichsetzung von Handels- und Wirkstoffname ist der bemerkenswerteste Teil — das leistet
kein Zeichenvergleich.** Hier arbeitet das Modell tatsächlich als Modell, nicht als Sucher.

**Die Grenze, die dazugehört:** 4 von 20 führen ein **abgesetztes** Präparat als aktuelle
Medikation mit auf, weil der Eintrag „vollständig abgesetzt" noch im Ankerfenster liegt.

> **Der Chat trennt aktuelle und abgesetzte Medikation nicht zuverlässig. Wer das Fenster zu
> weit zieht, bekommt Altlasten als Gegenwart.** Das Ankerfenster ist deshalb eine fachliche
> Entscheidung, keine technische.

### Die Auslieferung — der eigentliche Kern

`$[x THE 40 _ _ JN NJ22 NNND invTime K 0]$` tippt niemand aus dem Kopf, und den Prüfauftrag
auch nicht. Der wirksame Prompt hat **zwei** Bestandteile, die beide niemand auswendig kann.

> **Verankerung ist keine Prompt-Technik, sondern eine Auslieferungstechnik.** Der Prompt muss
> als **Textbaustein** existieren, sonst ist die Fähigkeit praktisch nicht vorhanden.

Nicht „lernen Sie Kommandos", sondern: **Sie bekommen fertige Bausteine — die tippt niemand
von Ihnen aus dem Kopf.**

## Referenz-Routing

| Frage | Datei |
|---|---|
| Was sind Anker, Guard, Typdefinition? Welche Regeln gelten? Verankern oder nicht? | `references/anker-guard-typdefinition.md` |
| Welches Kommando liefert Diagnosen, Daten, Volltexte, CKE- und Formularwerte? Praxiseigene Typkürzel? | `references/kommando-bibliothek.md` |
| Was kann das Modell nicht? Was kann es gut? Was ist überhaupt im Chatkontext? | `references/modellgrenzen-und-quellen.md` |
| Lückentext, Anti-Schmuggel-Liste, Multi-Turn, Arbeitsteilung Kommando ↔ Modell, Anti-Patterns | `references/patterns.md` |
| Wie teste ich einen neuen Prompt, bevor er produktiv geht? | `references/testprotokoll.md` |
| Welche Quoten sind gemessen? Was überlebt eine Zusammenfassung? Wie erkenne ich einen nicht gelaufenen Anlagen-Leser? | `references/modellgrenzen-und-quellen.md`, Abschnitt C.3 |
| Welche Kommandos sind in **meiner** Installation gepflegt? Welche laufen leer? | `references/praxis-interna.md` |

**Vor dem Bau eines verankerten Prompts `references/praxis-interna.md` lesen.** Dort steht die
Kommando-Inventur der eigenen Installation — welche Anker tragen und welche lautlos leer
laufen. Ist die Datei noch nicht ausgefüllt, gilt ausschließlich der generische Text; dann die
vorgesehenen Kommandos einzeln über `Admin › Kommandos › [Ausführen]` prüfen, bevor ein
Baustein ausgeliefert wird. Praxisbezogene Angaben gehören **nur** in diese Datei, nie in den
übrigen Text.
| Welche Tools hat der Chat? Was darf er laut Hersteller? Welches Modell antwortet? Was bringt ein Modellwechsel? | `references/llm-toolebene.md` |
| Welches Werkzeug holt welche Daten? Wie lenke ich eine Teilfrage gezielt auf ein Tool statt auf den Karteivolltext? | `references/toolinventar-und-hebel.md` |
| Wie baue ich einen Kontext im LLM-Textgenerator? Wo liegt er? Welche Kappungen hat die Auslieferung? | `references/llm-textgenerator.md` |

---

## Praxis-Workflow für strukturierte Outputs

1. **Zonen festlegen:** welche Inhalte per Kommando, welche vom Modell (`patterns.md`, Pattern 9)
2. **Anker-Block bauen** und jedes Kommando einzeln auf Auflösung prüfen (`kommando-bibliothek.md`, Abschnitt „Pflichtschritt")
3. **Guard- und Typdefinitions-Block einsetzen** (`anker-guard-typdefinition.md`)
4. **Klassifikations-Prompt** mit Whitelist/Conditional/Blacklist-Trias
5. **Generierungs-Prompt** mit Lückentext, Anti-Schmuggel-Liste und Vorbehalts-Auftrag
6. **Im KarteiChat ausprobieren** (Chat leeren, Prompt 1, ≥30 s, Prompt 2)
7. **Testprotokoll fahren** (`testprotokoll.md`)
8. **Bei Versagen** Pattern-Analyse: welcher Constraint ist gerutscht, welcher Baustein fehlt
9. **Bei Erfolg** Prompt-Strang dokumentieren, ggf. als Textbaustein hinterlegen — **mit** Guard- und Definitionsblock, sonst geht die Wirkung beim Kopieren verloren

---

## Verifikations-Checkliste

```
[ ]  1. Eine Aufgabe pro Prompt
[ ]  2. Lückentext wörtlich, Inhaltsangaben in den Platzhaltern
[ ]  3. Anti-Schmuggel-Liste mit konkreten Begriffen
[ ]  4. Begründungs-Templates wörtlich vorgegeben
[ ]  5. Kein interner Self-Check als Qualitätssicherung
[ ]  6. Mehrfachlauf für produktionskritische Outputs
[ ]  7. Jeder Anker einzeln auf Auflösung geprüft
[ ]  8. Beschriftung des Ankers beschreibt die Kommando-Semantik, nicht den Wunsch
[ ]  9. Guard-Block vorhanden, inklusive Leerfeld-Satz
[ ] 10. Typdefinition über Eintrags-Bezeichnungen vorhanden, wo ein Fachbegriff vorkommt
[ ] 11. Jeder Anker hat eine begleitende Aufgabe
[ ] 12. Keine absolute Zeichenzahl als Vorgabe
[ ] 13. Vorbehalts-Auftrag im Prompt, wenn die Ausgabe nach außen geht
[ ] 14. Keine Abhängigkeit von Anlageninhalten
[ ] 15. Erwartungsanker vor dem ersten Lauf notiert
[ ] 16. Aufgelöster Prompt-Text gesichert
[ ] 17. Strukturvorgabe benennt die Gliederungsachse, nicht nur die Anzahl
[ ] 18. Vollständigkeit ist eigenes Prüfkriterium, nicht nur Form und Fachlichkeit
[ ] 19. Kein Satz im Prompt, der als Schreibauftrag lesbar ist, wenn nur gelesen werden soll
```

---

```
[ ] 20. Soll-Werte gegen den Volltextexport der Akte geprüft, nicht aus dem Gedächtnis
[ ] 21. Verdichtungs-Prompt fordert Vorbehalte und Einschränkungen ausdrücklich an
[ ] 22. Jede genannte Fundstelle mit der Volltext-Gegenprobe aufgeschlagen
[ ] 23. Kein Quellenkürzel als Beleg gewertet
[ ] 24. Jede Faktenfrage doppelt gewertet: gegen Karteitext und gegen Karteitext plus Anlagen
[ ] 25. Mindestens 20 Läufe, bevor ein Prompt vor Publikum oder produktiv geht
[ ] 26. Jedes Briefkommando des Ankers einzeln auf Auflösung geprüft — auch die, deren
        Prüfabfrage „Daten vorhanden" meldet
[ ] 27. Bei kleinen Ankeranzahlen geprüft, ob die neuesten oder die ältesten Einträge kommen
[ ] 28. Ankerfenster fachlich gewählt: reicht es weit genug zurück, trägt es Abgesetztes mit
```

**Zu Punkt 20:** In der Benchmark waren **vier** Soll-Angaben zweier sorgfältig gebauter
Testdrehbücher falsch — alle vier zu Lasten des Chats. Ein Testprotokoll ohne Ground Truth
misst die Erinnerung des Autors, nicht das Werkzeug.

**Zu Punkt 25:** Drei Läufe hätten in 376 Läufen **keinen** der drei Ausfallmodi gefunden —
nicht den Anlagen-Leser (15 %), nicht die Totalverweigerung des Faktenblocks (1/20), nicht die
erfundene Fundstelle (1/20 und 1/18). Und auch nicht den einzigen Lauf, der einen
Aktenwiderspruch bemerkt hat.

### Zwei DB-Spuren machen Testläufe prüfbar

Ein KarteiChat-Lauf hinterlässt zwei unabhängig auswertbare Spuren. Beide sind lesend
abfragbar und ersetzen die Sichtprüfung im Testprotokoll. Die Feldbeschreibungen stehen in
`tomedo-statistik-hql/references/datenmodell.md`, Abschnitte 2 und 18.

**Spur 1 — der abgelegte Eintrag.** `karteieintrag.autoquelle` trägt bei chat-erzeugten
Einträgen `[{"kuerzel":"KC"}]`, sonst `NULL`. Das ist das ✦ der Karteiliste. Damit ist
belegbar, ob ein Prompt überhaupt zu einer Ablage geführt hat — und wie viele Antworten
verworfen wurden. Auswertung immer über `IS NOT NULL`, nie über Wertgleichheit.

**Spur 2 — der Aufruf selbst.** `llmcall` führt Modell, Token und Kosten je Aufruf. Aufruftyp
`KarteiChat` für die Hauptaufrufe, `AgentSubcall` für die Werkzeugaufrufe der Agentenebene.
Eine Interaktion erzeugt typischerweise **zwei** `KarteiChat`-Aufrufe (einer mit konstantem
Kontextpräfix von rund 10.200 Token, einer mit 18.000 bis 24.000) plus drei bis vier
`AgentSubcall` [Referenzinstallation, 22.09.2026]. Wer die Agentenebene debuggt, sieht an Zahl
und Größe der Subcalls, wie viele Werkzeugschritte das Modell tatsächlich gegangen ist.

**Für Prompt-Ökonomie relevant:** der Input dominiert um den Faktor 25. Ein langer Systemprompt
kostet in jedem Aufruf erneut; eine längere Antwort kostet fast nichts.

**Keine Verknüpfung zwischen beiden Spuren.** `llmcall` hat keinen Fremdschlüssel auf
`karteieintrag` — die Zuordnung ist nur über Nutzer und Zeitfenster annäherbar.

**Ungeprüft:** ob alle KI-Pfade `autoquelle` setzen. Belegt ist nur der KarteiChat. Bleibt das
Feld bei KI-Prompts aus Aktionsketten leer, untererfasst jede KI-Kennzahl systematisch.

### Die KI-Kennzeichnung verlässt die Kartei nicht

Das ✦ ist eine Eigenschaft des **Eintrags**, nicht des **Textes**. Der Schalter „✦ anzeigen"
ist **kein Filter** — er blendet nur das Symbol aus, die Einträge bleiben stehen. Die
Kennzeichnung erscheint **nicht** im Eintragseditor, **nicht** in der Kommandoausgabe und
**nicht** im Ausdruck.

> **Ihre Kartei weiß, dass der Satz von der KI kam. Der Brief, den Sie daraus machen, weiß es
> nicht mehr.**

Das ist der Übergabepunkt, an dem der Mensch verantwortlich wird. Wer Herkunft dauerhaft
dokumentieren will, schreibt sie **in den Text**, nicht in das Flag.

## Referenzen auf andere Skills

- `tomedo-kommandos` — vollständige Kommando- und Konfigurator-Syntax; verbindlich bei allen `$[…]$`-Fragen
- `tomedo-statistik-hql` — dieselben Definitionen als Query; Quelle der Typ-Abgrenzungen
- `tomedo-textbausteine` — statische Bausteine, in denen Prompt-Stränge hinterlegt werden
- `tomedo-patientenformulare` — CKE- und PatF-Felder anlegen, um Werte über die Verankerungslinie zu schieben

---

## Versionsverlauf

- **v1 (05/2026):** Initialversion nach Prompt-Engineering-Session „Psychotherapeutischer Kurzbericht v7". Patterns 1–7, Modellgrenzen-Tabelle, Anti-Patterns. Monolithisch.
- **v2 (09/2026):** Vollständige Neufassung nach Testserie an synthetischer Demoakte, zugleich Umbau auf Navigator plus `references/` (ADR-SKILL-01).
  - **Widerrufen:** die Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat".
  - **Neu:** Anker-Guard-Typdefinition-Architektur mit belegtem Fehlerkatalog, Kommando-Bibliothek mit praxiseigenen Typkürzeln, belegte Stärken, Quellengrenzen-Tabelle inklusive Anlagen, vollständiger Prompt-Rahmen, Arbeitsteilung Kommando ↔ Modell, Testprotokoll.
  - **Ergänzt:** sechs neue Modellgrenzen (Ankerbindung, Leerfeld-Kollaps, Anker ohne Auftrag, Zeichenvorgaben, asymmetrischer Informationsverlust, Systemdatum), fünf Anti-Patterns, Checkliste von 6 auf 16 Punkte.
  - **Offen:** Trägerkürzel der „Therapie"-Einträge (praxiseigen, mehrere Kürzel unter einer Bezeichnung), Nutzer-Attribution im Chatkontext, Leistungen im Chatkontext.
- **Stand 09/2026, ausgeliefert als Fassung 1.1:** Toolebene ergänzt.
  - **Neu:** `references/toolinventar-und-hebel.md` (Inventar der Werkzeuge, die der Chat
    aufruft); **Werkzeuganweisung** als vierter Prompt-Baustein neben Anker, Guard und
    Typdefinition; Querverweise auf `tomedo-textbausteine` für die Baustein-Seite der
    Markdown- und Emoji-Regeln.
  - **Checkliste auf 19 Punkte.** Aus der Toolebene stammen Punkt 17 (Gliederungsachse statt
    blosser Anzahl) und Punkt 19 (kein Satz, der als Schreibauftrag lesbar ist — es gibt
    schreibende Werkzeuge). Punkt 18 (Vollständigkeit als eigenes Prüfkriterium) stammt aus
    der Arbeit an `anker-guard-typdefinition.md`; wann genau er dazukam, ist nicht mehr
    rekonstruierbar.
  - **Zur Zählung:** Die Fassung steht im Frontmatter unter `metadata.version`. Die frühere
    Fußzeile führte eine zweite, abweichende Zählung und ist deshalb entfallen.

---

- **Fassung 1.2 (09/2026): Benchmark gegen Volltextexport, zweite Betriebsart, KI-Flag.**
  356 protokollierte Läufe an zwei synthetischen Akten, erstmals mit Ground Truth aus dem
  tomedo-Kartei-Export statt gegen Erinnerung, dazu 80 Läufe zur Verankerung per Briefkommando.
  - **Neu:** zwei Kernbefunde vorangestellt · drei Negativbefunde · „nicht dokumentiert heißt
    nicht dort, wo ich gesucht habe" mit beiden Ausfallmodi · Verdichtungsbefund nach
    terminiert/einschränkend aufgetrennt · **die zweite Betriebsart** als eigener Abschnitt ·
    zwei DB-Spuren (`autoquelle`, `llmcall`) · Reichweite der ✦-Kennzeichnung ·
    Quotentabelle C.3 · `references/praxis-interna.md` · Checkliste von 19 auf 26 Punkte.
  - **Widerrufen:** „PDF-Anlagen sind nicht im Chatkontext" — der Chat liest sie in **54 von 65**
    Läufen; was er nicht tut, ist den Leser zuverlässig zu starten. Ebenso widerrufen:
    „4/4 korrekte Abstinenz" bei einer Anlagenfrage — dieselbe Konstellation ist der
    20/20-Fehlschlag. Und: „Schreibe mir den Prompt dafür" als Baustein (0/5).
  - **Relativiert:** „er prüft nichts nach" — 1 von 98, nicht 0. „Halluzination als
    Hauptrisiko" — 3 Erfindungen in 356 Läufen; das Hauptrisiko ist die **Konservierung**
    falscher Aktenangaben. „Anweisungen überleben die Verdichtung nicht" — die datierte
    Anweisung überlebt 19/20; verloren geht das **Einschränkende**.
  - **Zurückgezogen aus Runde 1:** „der Zitatzwang erzeugt eine neue Fehlerklasse" stand auf
    n=1; über beide Akten liegt je eine Erfindung in jedem Arm.
  - **Offen:** ob der Chat Formulare, Rezepte, AU-Bescheinigungen, Leistungsziffern und
    Laborwerte überhaupt sieht — an diesem Material nicht messbar. Ob KI-Prompts aus
    Aktionsketten `autoquelle` setzen. Schreibpfad mit n=1.

- **Fassung 1.3 (09/2026): zweite Kommando-Inventur, Medikationsabgleich.** Belegbasis auf
  **376 Läufe** erweitert, davon 100 verankert.
  - **Neu:** die Inventur ein zweites Mal nach einer Nachpflege gefahren — **von zwei auf fünf
    nutzbare Datenklassen, durch Pflege statt durch ein besseres Modell**. Dazu der
    Medikationsabgleich als stärkster gemessener Baustein (Dosisabweichung 20/20,
    Handelsname gegen Wirkstoffname 18/20, keine Erfindung), die `invTime`-Falle und der Befund,
    dass **tabellenerzeugende Kommandos im Chat-Eingabefeld nicht auflösen**, obwohl die
    zugehörige Prüfabfrage „vorhanden" meldet. Checkliste von 26 auf 28 Punkte.
  - **Ersetzt:** das Beispiel „ein Kommando liefert einen gültigen Wert 0". Das war an der
    ungepflegten Akte gemessen; nach der Pflege steht dort 1. Der bleibende Befund ist ein
    anderer und schärfer — die Prüfabfrage kann „vorhanden" melden, während das eigentliche
    Kommando leer bleibt.
  - **Offen:** ob der Chat abgesetzte von aktueller Medikation trennen kann, wenn man ihn
    ausdrücklich darauf hinweist. 4 von 20 taten es nicht, ohne Hinweis gefragt.

- **Fassung 1.4 (09/2026): Umbenennung.** Der Skill heißt jetzt `tomedo-karteichat-prompting`
  statt `karteichat-prompting`, damit alle neun Anleitungen mit `tomedo-` beginnen. Inhalt
  unverändert; die Verweise in den übrigen Anleitungen und im Handbuch sind nachgezogen.
  Wer die alte Fassung installiert hat, entfernt sie — sonst liegen zwei Skills mit denselben
  Auslösern nebeneinander.

---

*Belegbasis: Testserien 1–3 an Demoakte 03 (108 Karteieinträge, 6 Anlagen), Modellvergleich unter Bedingung A (Kartei-Volltext ohne Anlagen, ohne Spezifikations-Metaebenen). Kernaussage: der wirksamste Prompt-Baustein ist die Typdefinition, der billigste der Guard-Satz, der gefährlichste ein leerer Anker.*
