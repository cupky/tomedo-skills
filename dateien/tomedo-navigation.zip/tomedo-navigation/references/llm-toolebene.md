# LLM-Toolebene: der dritte Automatisierungskanal

> Teil des Skills `tomedo-navigation`. Der Navigator ist `SKILL.md`.

---

**Belegbasis:** Export der tomedo-LLM-Tool-Definitionen (09/2026, 112 Funktionsdefinitionen
im Function-Calling-Format). Ausgewertet wurden Namen, Beschreibungen und Parameterschemata.

**Statusregel für diese Datei:** Alles hier ist **dokumentiert** — es steht so in der
Tool-Beschreibung des Herstellers, ist aber **nicht** von uns empirisch geprüft. Der Export
ist zudem die Union aller Toolsets (Kartei-Chat, Support-Chat, Dental), nicht das
Kontextabbild eines einzelnen Chats. **Welche dieser Tools im Kartei-Chat tatsächlich
exponiert sind, ist unbelegt.** Vor produktivem Einsatz Sonde fahren (siehe
`tomedo-karteichat-prompting/references/toolinventar-und-hebel.md`, §7).

**Diese Datei ist abgeleitet**, nicht aus einem eigenen Versuchslauf entstanden: Sie ordnet
den Tool-Export in die Automatisierungslandschaft dieses Skills ein. Jede Aussage über das
Verhalten im Betrieb ist damit eine Erwartung, keine Messung.

---

## 1 · Drei Kanäle, aus denen heraus tomedo ferngesteuert werden kann

`SKILL.md` beschreibt zwei Wege, von außen auf tomedo zu wirken. Der Tool-Export zeigt einen
dritten, der anders funktioniert als die beiden anderen:

| Kanal | Wer löst aus | Was passiert | Determinismus |
|---|---|---|---|
| **A · Skriptebene** (`tomedo.sdef`, AppleScript, Deeplinks, Toolbar-Buttons, Ereignis-Hooks) | ein Skript oder der Anwender | genau das, was das Kommando sagt | vollständig |
| **B · Endpunktebene** (`llmservice`, HTTP) | ein Skript | ein Modell erzeugt Text, das Skript verarbeitet ihn weiter | Aufruf deterministisch, Antwort nicht |
| **C · Toolebene** (Kartei-Chat als Agent) | das **Modell** entscheidet, welches Werkzeug es ruft | Datenzugriff und teilweise Schreibvorgänge in tomedo | weder Auswahl noch Ergebnis |

Kanal C ist der einzige, bei dem **nicht der Aufrufer bestimmt, was ausgeführt wird**. Das
Modell wählt das Werkzeug anhand der Formulierung der Frage. Für die Navigation heißt das:
Es gibt keinen Menüpfad und keine Einstellung, an der man ablesen könnte, was bei einer
Chat-Frage tatsächlich passiert.

## 2 · Eine Eigenschaft, die man beim Einweisen kennen muss

Der Export führt Werkzeuge, die Karteieinträge anlegen oder bearbeiten, Formulare
vorbefüllen und Briefkommandos auflösen. Eine Frage, die wie ein Auftrag klingt, kann
damit etwas anlegen. Das ist kein Navigationsweg und keine Einstellung, sondern eine
Eigenschaft des Chats — sie gehört in die Einweisung, nicht in einen Menüpfad.

## 3 · Abgrenzung zu den anderen Kanälen

Wer eine **reproduzierbare** Automatisierung braucht — Abrechnungslauf, Serienbrief,
Terminimport —, nimmt Kanal A. Wer **Text erzeugen** will und das Ergebnis selbst prüft,
nimmt Kanal B; das Rezeptbuch dazu ist `references/applescript-rezeptbuch.md`. Kanal C ist
für die Arbeit am einzelnen Fall gedacht, nicht für Abläufe, die ohne Sichtprüfung laufen.

## 4 · Was diese Datei **nicht** belegt

- welche Werkzeuge im Kartei-Chat einer konkreten Installation exponiert sind
- ob ein Werkzeugaufruf protokolliert wird und wo dieses Protokoll läge
- ob sich der Umfang zwischen Modellständen ändert

Alle drei Punkte sind offen und nur durch eine eigene Sonde zu klären. Das Vorgehen dafür
steht in `tomedo-karteichat-prompting/references/toolinventar-und-hebel.md`, §7.
