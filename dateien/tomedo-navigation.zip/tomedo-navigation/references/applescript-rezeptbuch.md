# AppleScript-Rezeptbuch: LLM-Aufruf und Kartei-Uebergabe


> **Routing: was wo steht.** Dieses Rezeptbuch beschreibt den **Skript-Pfad** —
> wie ein Aufruf aus AppleScript herausgeht und wie die Antwort zurueck in die
> Kartei kommt. Der **Endpunkt selbst** (Parameter, Modellwahl, Fehlercodes,
> Kosten, Limits) steht in `tomedo-llm-endpunkt`. Bei Widerspruch gilt dort.


Validierte Bausteine fuer den Aufruf eines Sprachmodells aus tomedo heraus per
AppleScript, sowie die Uebergabewege zwischen Kartei, Skript und Aktionskette.

**Statuskennzeichnung mit Quellendatum.**
`[Hersteller, TT.MM.JJJJ]` = zollsoft-Dokumentation oder -Aussage ·
`[Referenzinstallation, TT.MM.JJJJ]` = eigene Messung · `[Fremdbericht, TT.MM.JJJJ]` =
Forums-Erfahrungsbericht, nicht reproduziert · `[plausibel]` = abgeleitet.

> **Abgrenzung.** Dieses Rezeptbuch beschreibt den **Skript-Pfad**. Der
> KI-Prompt in der Aktionskette ist ein anderer Weg mit anderen Eigenschaften —
> der steht in `tomedo-aktionsketten/references/ki-prompt-aktion.md`. Wer
> Werkzeugzugriff braucht (Karteieintrag anlegen, CKE fuellen), ist hier falsch.

---

## 1 · Der LLM-Service-Endpunkt

### Adressschema [Hersteller, 17.10.2025]

```
{server_url}llmservice/{userIdent}/v1/chat/completions
```

Vollstaendig: `http://{host}:{port}/{db}/llmservice/{userIdent}/v1/chat/completions`

Die Schnittstelle ist OpenAI-kompatibel. Ein bestehender Ollama-Aufruf laesst
sich durch Austausch der Adresse und des Modellnamens umstellen; weitere
Aenderungen am Request sind nicht noetig.

### Die drei Angaben [Hersteller, 17.10.2025]

| Angabe | Woher |
|---|---|
| Server-URL inklusive Datenbankname | tomedo-Client: **tomedo › Ueber tomedo › Server-URL** |
| `userIdent` | Statistik-Abfrage `select Ident from Nutzer where Kuerzel = 'XXX'` |
| Modellname | siehe Modellliste unten |

Der `userIdent` steht **im Pfad**, nicht im Body, und ist zwingend. Ohne
korrekten Wert wird die Anfrage abgelehnt.

> **Fallstrick aus der Praxis.** Forums-Beispiele enthalten fremde Hostnamen
> (`tomedo.localnet`) und fremde Idents (`2`). Beide gelten nur beim jeweiligen
> Autor. Ein Copy-Paste-Aufruf scheitert lautlos, wenn zusaetzlich `curl -s`
> gesetzt ist. [Referenzinstallation, 13.09.2026]

### Modellliste [Hersteller, 17.10.2025 — Alterungshinweis beachten]

Mistral: `mistral-medium-latest`, `-2508`, `-2505`,
`mistral-small-latest`, `-2506`, `-2503`, `-2501`
Google: `gemini-2.5-pro`, `gemini-2.5-flash`, `gemini-2.5-flash-lite`

Die Liste stammt aus einem Forumsbeitrag vom Oktober 2025 und ist nicht
nachverfolgt. **Vor Gebrauch pruefen** — siehe Abschnitt 6, Test A liefert die
Antwort nebenbei.

### Fehler in der offiziellen Vorlage [Hersteller, 17.10.2025]

Im dokumentierten curl-Beispiel steht `"messages"` als **Objekt**. Die
OpenAI-Spezifikation verlangt ein **Array**. Funktionierende Skripte senden
`"messages": [{...}]`.

---

## 2 · Karteitext ins Skript holen

Der eleganteste Uebergabeweg loest den Text **vor** dem Skriptstart auf: Das
Briefkommando steht im AppleScript-Quelltext und wird von tomedo ersetzt,
bevor das Skript laeuft.

```applescript
set the prompt to "$[x DOK 1 _ _ NJ NJ2N NNNN _ K _]$"
```

Liest den Text des juengsten Karteieintrags vom Typ `DOK`.
[Fremdbericht, 10.09.2026]

Vollstaendige Parametrierung des x-Kommandos: `tomedo-kommandos`. Dieses
Rezeptbuch fuehrt nur den Uebergabeweg, nicht die Kommandosyntax.

**Warum das gut ist:** kein Zwischenablage-Umweg auf dem Hinweg, keine
Race-Condition, und der Kontext kommt aus derselben Quelle wie in der
Briefschreibung.

**Warum das riskant ist:** Der aufgeloeste Karteitext steht danach im
Skript-Kontext — und Skript-Quelltexte liegen im Klartext in der Server-DB und
im lokalen Cache jedes Arbeitsplatzes (siehe `scriptability.md`, Regel 2).
Der aufgeloeste Wert selbst wird nicht persistiert, der **Aufrufkontext** aber
sehr wohl. Kein Logging des Prompt-Inhalts. [plausibel]

---

## 3 · Prompt an den Prozess uebergeben

**Nie per Quoting in die Kommandozeile.** Karteitexte enthalten
Anfuehrungszeichen, Backslashes und Zeilenumbrueche; jedes davon bricht das
AppleScript-Quoting. Stattdessen per Umgebungsvariable.
[Fremdbericht, 09.09.2025]

```applescript
set shellCmd to "/usr/bin/env /bin/zsh -lc " & quoted form of ¬
    ("export USER_PROMPT=" & quoted form of prompt & "; " & ¬
     "export USER_MODEL=" & quoted form of selectedModel & "; " & ¬
     "export LLM_ENDPOINT=" & quoted form of llm_endpoint & "; " & ¬
     "python3 - <<'PY'
" & pyCode & "
PY")
```

Das Python-Fragment liest `os.environ` und kommt mit der Standardbibliothek aus
— keine Installation noetig.

**Zusaetzlich vorher bereinigen:** Die Zeichen `"` und `\` per
Zurueckschreiben-Aktion aus dem Karteitext entfernen, bevor das Skript startet.
[Fremdbericht, 10.09.2026]

---

## 4 · Antwort auswerten

Primaerpfad `choices[0].message.content`. Robuste Skripte pruefen zwei
Rueckfallebenen, weil dieselbe Skriptbasis frueher gegen Ollama lief:

1. `choices[0].message.content`
2. `message.content`
3. `content`

[Fremdbericht, 10.09.2026]

---

## 5 · Rueckkanal in die Kartei

Der Skript-Pfad hat **keinen Werkzeugzugriff** — das Modell gibt Text zurueck
und ruft von sich aus nichts auf. Der Rueckweg laeuft deshalb ueber die
Zwischenablage plus die Aktionsketten-Aktion „Zurueckschreiben".
[Fremdbericht, 10.09.2026]

```applescript
set the clipboard to resultText
```

**Harte Grenze:** „Zurueckschreiben" wirkt nur auf den **juengsten**
Karteieintrag. Der gesamte Ablauf muss um diese Bedingung herum gebaut werden.
[Fremdbericht, 10.09.2026]

**Nicht per Aktionskette setzbar:** Karteieintragstyp und -datum.
[Fremdbericht, 10.09.2026]

> **Bewertung fuer den Praxiseinsatz.** Die Zwischenablage ist global und
> ueberschreibbar. Bei parallelem Arbeiten an vielen Arbeitsplaetzen ist das
> eine Verwechslungsquelle mit Patientenbezug. Wo es geht: Datei- oder
> Feldübergabe statt Zwischenablage. [Referenzinstallation, 13.09.2026]

---

## 6 · Aktionskette aus dem Skript starten

```applescript
tell application "Finder" to open location "tomedo://aktionskette?<Kuerzel>"
```

[Fremdbericht, 10.09.2026]

Zu Deeplinks allgemein und zu `call aktionskette` siehe `scriptability.md`.
Dort steht auch die harte Grenze: `call aktionskette` nimmt keine Parameter.

---

## 7 · Diagnose: der Aufruf antwortet nicht

Messreihe vom 13.09.2026, tomedo v1.170.0.16. [Referenzinstallation, 13.09.2026]

| Beobachtung | Ursache | Vorgehen |
|---|---|---|
| Leere Antwort, kein Fehler | `curl -s` unterdrueckt die Fehlerausgabe | mit `-i` oder `-w '%{http_code}'` wiederholen |
| **HTTP 422**, Text `Unbekanntes Modell` | Modellname nicht auf der Serverliste | gueltigen Namen setzen |
| HTTP 404 mit Hinweis auf die Authentifizierungsanfrage | trat 01/2026 als serverseitiges Netzwerkproblem auf und wurde behoben [Fremdbericht, 28.01.2026] | einmal wiederholen, dann Support |
| HTTP 404 sonst | Datenbankname im Pfad falsch, oder Version ohne Endpunkt | Server-URL gegen **Ueber tomedo** pruefen |
| Verbindung scheitert, Timeout | Host oder Port falsch, oder Rechner nicht im Praxisnetz | Erreichbarkeit separat pruefen |
| Ablehnung trotz 200er-Pfad | falscher `userIdent` | Statistik-Abfrage wiederholen |
| HTTP 200, leerer Inhalt | Extraktionspfad greift daneben | drei Rueckfallebenen aus Abschnitt 4 |

### Nachweis, dass die Modellwahl wirkt

Zwei Aufrufe, sonst identisch: einmal mit erfundenem Modellnamen, einmal mit
gueltigem. Erfundener Name → **HTTP 422**, deutschsprachiger Klartext ohne
JSON-Huelle. Gueltiger Name → **HTTP 200**, die Antwort spiegelt den
Modellnamen im Feld `model` zurueck. [Referenzinstallation, 13.09.2026]

Die Fehlermeldung stammt erkennbar aus der tomedo-Schicht, nicht von Google:
**der Server fuehrt eine eigene Positivliste** und reicht das Feld nicht
ungeprueft durch. Damit ist der 422-Test zugleich der billigste Weg, die
aktuelle Modellliste zu ermitteln. [Referenzinstallation, 13.09.2026]

Das Modell nach seiner Identitaet zu **fragen**, ist kein Nachweis —
Sprachmodelle geben darueber haeufig Falsches an.

---

## 8 · Budget und Abrechnung

## 8 · Budget und Abrechnung — steht woanders

Die Antwort des Endpunkts enthaelt `cost` und `usage`. **Die Zahlen stehen nicht hier.**
Kostenrechnung, Denk-Tokens, die Korrekturformel und das 5-$-Limit gehoeren in den
Skill `tomedo-llm-endpunkt` — `references/kosten-und-budget.md`.

> ⚠️ **Nicht aus diesem Rezeptbuch hochrechnen.** `cost` meldet nur Prompt- und
> Completion-Tokens und untertreibt dadurch messbar. Wer aus dem Skript heraus ein
> Budget plant, liest `tomedo-llm-endpunkt` und rechnet dort.

Fuer den Skript-Pfad relevant bleibt nur: das `cost`-Objekt ist auslesbar und eignet
sich als **Abbruchsignal im Skript**, nicht als Abrechnungsgrundlage.

## 9 · Datenschutz-Tatsachen fuer diesen Pfad

**Hersteller-Aussage:** Die Modelle laufen nicht lokal. Es besteht ein
Zero-Data-Retention-Vertrag und EU-Hosting mit Mistral und Google. Eine
Anonymisierung ist danach nicht erforderlich; ueber den Einsatz sind Patienten
gegebenenfalls zu informieren, wofuer zollsoft auf den eigenen
Datenschutzbeauftragten verweist. [Hersteller, 22.10.2025]

**Eigene Beobachtung:** Die HTTP-Antwort des Endpunkts enthielt ein `Set-Cookie`
fuer die Domain `.generativelanguage.googleapis.com`. Der Endpunkt reicht also
Antwortheader des Google-Dienstes durch; die Anfragen gehen an Googles
Generative Language API. [Referenzinstallation, 13.09.2026]

Das ist eine **Tatsachenfeststellung, keine Bewertung.** Sie gehoert dem
Datenschutzbeauftragten vorgelegt, nicht in eine technische Entscheidung.

---

## 10 · Was dieser Pfad nicht kann

| Fehlt | Wo es stattdessen steht |
|---|---|
| Werkzeugzugriff — Karteieintrag anlegen, CKE fuellen, Formular oeffnen | Kartei-Chat und KI-Prompt-Aktion |
| Quellenverknuepfung der Aussagen zu Karteieintraegen | Kartei-Chat |
| Ergebnisweitergabe an Folgeschritte per Kommando | KI-Prompt-Aktion |
| Setzen von Karteieintragstyp und -datum | derzeit nirgends automatisierbar |

Wer die Werkzeugebene braucht, baut sie hier per Ausgabemarker und Regex nach —
mehr Aufwand, dafuer Modellwahl und Nachvollziehbarkeit. **Vor jedem Nachbau
pruefen, ob die Ergebnisweitergabe der KI-Prompt-Aktion reicht.**

---

## 11 · Mindestpruefung vor Produktivsetzung

```
[ ] 1. Server-URL aus "Ueber tomedo", nicht aus einer Vorlage uebernommen
[ ] 2. userIdent per Statistik-Abfrage ermittelt, eigener technischer Nutzer
[ ] 3. Smoke-Test mit -i, HTTP 200 gesehen
[ ] 4. 422-Test gefahren: Modellwahl nachweislich wirksam, Liste bekannt
[ ] 5. messages als Array, nicht als Objekt
[ ] 6. Prompt per Env-Variable, nicht per Quoting
[ ] 7. Sonderzeichen im Karteitext vorher ersetzt
[ ] 8. Drei Extraktions-Rueckfallebenen implementiert
[ ] 9. Timeout mindestens 300 s
[ ] 10. Kein Prompt-Inhalt im Log
[ ] 11. Zwischenablage-Rueckkanal auf Verwechslungsrisiko geprueft
[ ] 12. Juengster-Eintrag-Bedingung im Ablauf beruecksichtigt
[ ] 13. Budget ueber cost hochgerechnet, nicht ueber total_tokens
[ ] 14. Wiederhollauf gefahren, Ergebnisse gediffed
```

---

*Erhoben 09/2026. Quellen: Forum-Threads 106811, 109465, 114946, 125081;
eigene Messreihe 13.09.2026 an tomedo v1.170.0.16 (2 Modelle, je 5 Laeufe,
Blindbewertung).*
