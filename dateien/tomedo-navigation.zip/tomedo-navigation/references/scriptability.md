# Scriptability, Skript-Feature, Deeplinks und Steuerung von aussen

Quelle: Bundle `tomedo.app` und lokaler Core-Data-Cache `ServerEntities.sqlite`
(read-only gelesen), tomedo **v1.169.0.21**; Deeplink-Befunde aus dem Pilot 08/2026.
**Seit Fassung 1.5 systematisch ueberprueft** (Oktober 2026).
**[ungeprueft]** = noch nicht in der Oberflaeche nachgestellt — vor dem Einsatz an einer Testakte pruefen.

---

## 1 · tomedo ist offiziell scriptbar

- `Info.plist`: **`NSAppleScriptEnabled = true`**, `OSAScriptingDefinition = tomedo.sdef`
- Dictionary: `Contents/Resources/tomedo.sdef`
- Python-Laufzeit im Bundle: `Contents/PlugIns/libZSPython.dylib`

**Ein vom Hersteller vorgesehener Erweiterungspunkt**, keine Hintertuer — fuer die
MVZ-Abwaegung wichtig: ein Skript ueber diese Schnittstelle ist kategorial etwas anderes
als ein nicht unterstuetzter Direkt-Write in die Datenbank.

## 2 · Das vollstaendige Kommando-Inventar

| Kommando | Parameter | Was es wirklich tut |
|---|---|---|
| **`call aktionskette`** | Kuerzel (text) | ruft eine Aktionskette anhand ihres Kuerzels auf. **Der Hebel.** Einzelheiten unten |
| **`call statistik`** | Dateipfad | zeigt eine **CSV** im Statistik-Ergebnisfenster an |
| `search patient` | Suchtext | setzt den Text ins Patientensuchfeld des Hauptfensters und oeffnet die Trefferliste; im Kioskmodus wirkungslos |
| `call number` | Telefonnummer | startet einen Anruf ueber die eingestellte Telefonanlage |
| `handle starface / nfon / agfeo / swyx / direct call event` | Liste von Texten | **Rueckkanal der Telefon-Clients**: die Telefonsoftware meldet tomedo damit Anrufzustaende. tomedo legt dafuer beim Einrichten der Telefonanlage ein eigenes Skript in den Skriptordner des Telefon-Clients. Erwartet je Anlage eine feste Mindestzahl an Werten, sonst wird das Ereignis still verworfen. „direct" = direct/Teamcall |
| ~~`terminateForRelaunch`~~ | — | im sdef auskommentiert, nicht verfuegbar |

Alle Kommandos haben nur den einen direkten Parameter und **liefern nichts zurueck**.

**Was das Dictionary NICHT kann:** kein Kommando erzeugt oder aendert tomedo-Objekte —
kein Sperrtag, kein Termin, keine Aufgabe, keine Nachricht, kein Karteieintrag.
Schreibende Wirkung ist ausschliesslich **indirekt ueber eine Aktionskette** erreichbar.

### `call aktionskette` im Einzelnen

- Kuerzel **exakt**, Gross-/Kleinschreibung zaehlt; nur sichtbare, gueltige Ketten.
  Unbekannt: Hinweis „Es gibt keine Aktionskette für das Kürzel …" am Arbeitsplatz.
- Braucht eine **offene Kartei** und nimmt die **zuletzt aktive**. Ist keine offen:
  „Es existiert keine geöffnete Kartei." Schliesst man eine von zwei offenen Karteien, gilt
  bis zum naechsten Fensterwechsel „keine Kartei" **[ungeprueft]**.
- Startet die Kette und kehrt **sofort** zurueck; das Skript wartet nicht auf das Ende.
- Haeufige Syntaxfalle: das Wort `kuerzel` im Aufruf **weglassen**
  (`tell application "tomedo" to call aktionskette "ABC"`).

### `call statistik` im Einzelnen

CSV mit **Semikolon** als Trennzeichen, Anfuehrungszeichen erlaubt; **erste Zeile =
Spaltennamen** (werden kleingeschrieben); Zeilen mit mehr Feldern als der Kopf werden verworfen;
Kodierung nach Arbeitsplatz-Einstellung (Standard UTF-8). Die Spaltenreihenfolge im Fenster muss
nicht der Datei entsprechen **[ungeprueft]**.

### Zwei Einschraenkungen, die das Design bestimmen

1. **`call aktionskette` nimmt nur ein Kuerzel — keine Parameter.** Konkrete Werte
   (Behandler, Datum, Terminzeit) koennen nicht mitgegeben werden. Die Kette muss ihre Daten
   selbst beschaffen (Kontext, Statistik-Ergebnisliste) oder ueber Aktionsketten-*Fragen* —
   die sind interaktiv. **Ausweg mit Parametern:** die URL `tomedo://aktionskette?…`
   (Abschnitt 5) bzw. derselbe Aufruf per HTTP (Abschnitt 5a); aus AppleScript per
   `open location`.
2. **`call statistik` ist ein Anzeige-, kein Abfragekanal.** Es fuehrt keine HQL-Statistik
   aus und liefert dem Aufrufer kein Ergebnis; es rendert eine CSV. Eine HQL-Statistik *in*
   tomedo bleibt als Query-Traeger nuetzlich, ihr Ergebnis programmatisch abzuholen ist
   damit **nicht** geloest. (Loesung dafuer: Metabase-Card-API, s. `tomedo-metabase-migration`.)

## 3 · Das Skript-Feature (`Admin › Skripte (Python- und AppleScripts)`)

Fenster **„Skriptverwaltung"**, geteilt in „Details zum ausgewählten Skript (praxisweit)" und
„Rechnerspezifische Einstellung". Objekte liegen in `ZSKRIPT` (Core Data, serverseitig gepflegt,
lokal gecacht). Gemessener Bestand an der Referenzinstallation: **30 Skripte, alle AppleScript**.

| Spalte / Feld im Fenster | Bedeutung |
|---|---|
| `ZSOURCECODE` / „Skript-Code" | Skripttext, **Klartext**; Knopf „Überprüfe Syntax" |
| `ZLANGUAGE` / „Programmiersprache:" | **0 = AppleScript**, **1 = Python**, **2 = GDT-Export-Konfiguration**. Python-Skripte fuehrt der Skript-Ausfuehrer **nicht** aus; sie sind Skripttext fuer die **Marker-Automatik** (Knopf „zu Marker hinzufügen", Skill `tomedo-marker`) |
| Spalte „aktiv" / Haken „(automatische) Ausführung dieses Skriptes an diesem Rechner gestattet bzw. aktiv" | **Aktivierung je Rechner**, lokal am Arbeitsplatz gespeichert (ueber „Zentrale Konfiguration" auf andere Rechner uebertragbar). `ZISACTIVE` in der Server-DB ist **nicht** diese Aktivierung — es dient nur der einmaligen Uebernahme an einem neuen Rechner und wird beim Loeschen auf NO gesetzt. Ein neues Skript laesst sich ohne Serververbindung nicht aktivieren |
| `ZRUNONSTARTUP` / „nach Programmstart (d.h. bei Anzeige der Tagesliste) ausführen" | einmal beim Start, nur wenn am Rechner aktiv (Bestand: 5 Skripte) |
| `ZRUNWITHTIMEINTERVAL` + `ZTIMEINTERVAL` / „periodisch ausführen nach x Minuten:" | **periodisch, Einheit Minuten** (gemessene Werte 1, 10, 60 = 1 min, 10 min, 1 h). Nur wenn am Rechner aktiv; der Timer wird beim Programmstart angelegt, Aenderungen wirken nach einem Neustart **[ungeprueft]** |
| `ZRUNPARALLEL` / „Skript parallel ausführen …" | Standard **an**: Lauf ausserhalb von tomedo ueber eine kurzlebige Temp-Datei. Der Rechner-Schalter „synchrones Ausführen von ALLEN Skripten auf diesem Rechner" hat Vorrang |
| `ZINKARTEITOOLBAR` / `ZINTAGESLISTETOOLBAR` | **wirkungslos**: Kartei-, Tageslisten- und Kompaktansicht-Symbolleiste bieten in der Symbolleisten-Anpassung **alle** Skripte an; der Nutzer zieht sie selbst hinein |
| `ZINFORMULARTOOLBAR` / „Icon in Toolbarkonfiguration von Formularen" | nur dieses Feld filtert: Skript wird der Formular-Symbolleiste zur Auswahl angeboten |
| „In Auswahlliste" | „deaktiviert" oder **„E-Mailknopf in Terminfenster"**: das Skript wird beim E-Mail-Knopf des Terminfensters angeboten (Patient = Terminpatient) |
| `ZBESCHREIBUNG`, `ZTOOLTIP`, `ZCUSTOMIMAGE` | Beschreibung, Tooltipp, „Icon (für Toolbar)" (Aenderung erst nach Neustart) |
| `ZMARKETPLACEVERSION`, `ZONLINEID` | Anbindung an das **Tausch-Center** (so heisst der Marktplatz in der Oberflaeche); Upload fragt vorher, ob das Skript Passwoerter enthaelt |

Weitere Knoepfe: „AppleScript jetzt ausführen" (ohne Aktivierungspruefung, mit aktivem Besuch),
„Steuerung des Computers autorisieren", „Kommandos" (Briefkommandoliste). Skripte werden an
vielen Stellen **per Name** gefunden — Umbenennen trennt Symbolleisten-Knoepfe und andere
Verweise **[ungeprueft]**.

### Wer die Rechner-Aktivierung beachtet

| Aufrufweg | prueft „aktiv an diesem Rechner" |
|---|---|
| Programmstart, Intervall, Login-/Logout-Skript, GDT-Export vorher/danach | ja — sonst Hinweis „Das AppleScript '…' kann nicht ausgeführt werden, da es nicht auf Ihrem Arbeitsplatz aktiviert ist …" |
| Symbolleisten (Kartei, Tagesliste, Kompaktansicht, Formular), Aktionsketten-Schritt „AppleScript", Statistik-Ergebnisfenster, E-Mail-Knopf im Terminfenster, Warteschlangenaufruf, „AppleScript jetzt ausführen" | nein |

### Ereignisse: es gibt keine Hooks per Skriptname

Im Bestand der Referenzinstallation heissen zwei Skripte `#_KarteiGeoeffnet` und
`#_KarteiGeschlossen` (Skripttext: „Dieses Script wird von tomedo ausgefuehrt, wenn eine Kartei
geoeffnet wird."). tomedo wertet aber **keine Skriptnamen** aus — die Namen sind eine
Konvention dieser Installation. Ereignisgesteuert laufen Skripte nur ueber diese Wege:

| Ausloeser | Konfigurationsort |
|---|---|
| Programmstart, Intervall | Skriptverwaltung (siehe oben) |
| **Login und Logout** (auch Nutzerwechsel, Bildschirmsperre, Programmende) | `Einstellungen › Praxis › Login & Sicherheit` › „Apple-Skripte" (praxisweit). Parameter `$[ZSLoginLogoutEvent]$` (`login` / `logout`) und `$[nutzerkuerzel]$` (beim Logout der **abgemeldete** Nutzer). Laeuft losgeloest per `osascript`, auch noch nach dem Beenden von tomedo; nur AppleScript |
| Kartei oeffnen / schliessen | Aktionskettenausloeser Objekt `KarteiFenster`, Aktion `Öffnen` bzw. `Schließen`, darin ein Schritt „AppleScript" — so sind die Bestandsskripte vermutlich angebunden **[ungeprueft]** |
| GDT-Export (Öffnen der Kartei, Anlegen eines Besuchs, Änderung der Patientenstammdaten, GKV-Karte lesen) | GDT-Export-Verwaltung: „Vorher Skript ausführen …" / „Danach Skript ausführen …" |
| Automatischer Statistik-Export | Skript vorher / danach |
| Warteschlangenaufruf | Warteschlangen-Skript bzw. Aktionsketten-Schritt „Warteschlangenaufruf" |

### Aktionsketten-Schritt „AppleScript"

Laeuft **an seiner Position in der Kette**, mit Patient, Besuch und den Variablen der Kette;
der naechste Schritt beginnt erst nach dem Skriptende. Die Rechner-Aktivierung prueft der
Schritt nicht.

### Kontext kommt ueber tomedo-Platzhalter

Skripte werden vor der Ausfuehrung substituiert, in dieser Reihenfolge:

1. **Feste Skript-Platzhalter** (keine Briefkommandos): `$[patientID]$`, `$[patientVN]$`,
   `$[patientNN]$`, `$[patientGebDatum]$` (JJJJMMTT), `$[patientGebDatum_WithFormat_dd.MM.yyyy]$`,
   `$[patientGebDatum_WithFormat_ddMMyyyy]$`, `$[aktuellerTodoRaum]$`, `$[home]$`
   (Benutzerordner); bei Bedarf nachgeladen `$[patientVersichertenNummer]$`,
   `$[patientGeschlecht]$`. `$[patientHerrFrau]$` liefert keinen Wert — vor dem Einsatz testen.
2. **Aufrufparameter** des jeweiligen Weges (Login/Logout, Formularfelder, Statistikspalten).
3. **Briefkommandos** — dieselbe `$[…]$`-Aufloesung wie in Briefen, mit Patient und Besuch des
   Aufrufs; ohne Besuch der aktive, bei Start und Intervall der in der Tagesliste ausgewaehlte.

Im Bestand tatsaechlich verwendet: `$[nutzerkuerzel]$` (5×) · `$[pid]$` (4×) · `$[bk]$` (4×) ·
**`$[arbeitsplatz]$`** (3×) · `$[pv]$` · `$[pn]$` · `$[patientVN]$` · `$[patientNN]$` ·
`$[patientID]$` · `$[bes_gebDatum]$` · `$[aktuellerTodoRaum]$`.

**`$[arbeitsplatz]$`** ist das Kuerzel des dem Rechner zugeordneten Arbeitsplatzes (nicht der
Rechnername; ohne Zuordnung leer), **`$[nutzerkuerzel]$`** das Kuerzel des angemeldeten Nutzers.
Damit kann sich ein periodisches Skript auf einen Arbeitsplatz einschraenken — einfacher ist,
es nur an diesem Rechner zu aktivieren. **Nebenwirkung:** Ein Intervall-Skript mit irgendeinem
`$[…]$` laedt bei jedem Lauf die Patientendetails des gerade in der Tagesliste ausgewaehlten
Patienten nach **[ungeprueft]**.

### `do shell script` ist der Ausweg aus AppleScript

**28 von 30** Skripten nutzen `do shell script`. Ein tomedo-Skript kann also beliebige lokale
Programme starten — vorhandene Python-Logik muss **nicht** nach AppleScript portiert werden.
Vorteil zusaetzlich: Geheimnisse bleiben im aufgerufenen Prozess (Keychain) statt im
Skripttext.

## 4 · Gegenprobe: Aktionsketten koennen keine Sperrtage anlegen

Gegen den Aktionstypen-Katalog geprueft (07/2026, erneut geprueft 10/2026). Die
terminbezogenen Aktionstypen stehen im Aktionsmenue der Kettenverwaltung ohne Untermenue, und
**keiner schreibt**:

| Aktionstyp | Verhalten |
|---|---|
| Terminsuche (Definiert) | oeffnet ein Suchfenster, **blockierend**; gefundene Termine gehen an Folgeschritte |
| Terminsuche (Kette) | Kettenterminsuche, interaktiv |
| Sprechstundenassistent | oeffnet den Assistenten |

Kein „Termin anlegen", kein „Sperrtag", kein „Urlaubstag", keine Ganztagsart. Wer
Ganztags-Abwesenheiten programmatisch setzen will, braucht den Weg ueber das
Arbeitszeitkonto (ArZeKo → nativer tomedo-Sync). Ein direkt im Kalender gesetzter Sperrtag
verbucht **keinen** Urlaubsanspruch und reduziert **keine** Sollzeit.

**Baubar sind dagegen:** `Aufgabe` (aus Aufgabenvorlage — der Standard-Meldekanal),
`Nachricht` (Nachrichtenvorlage), `ToDo anlegen` (Tagesliste), `AppleScript` (laeuft an seiner
Position, die Kette wartet), `Zurueckschreiben` (Besuchs-/Patientenfelder — taugt als
Zustandsuebergabe zwischen Ketten, z.B. „schon gemeldet"; Zielfelder im Skill
`tomedo-aktionsketten`). Vorlagen muessen **vorher** existieren. Debugging:
`Hilfe › Logs › Loglevels Feinschaltung › LogLevelAktionskettenbedingung`.

### Das Parameterproblem hat zwei Loesungen im Statistik-Ergebnisfenster

| Menuepunkt im Ergebnisfenster | Wirkung |
|---|---|
| „Aktionskette für alle Listeneinträge nacheinander auslösen" | startet je Zeile eine Kette mit dem Patienten der Zeile |
| „Listeneinträge alle einzeln mit (Serien-)AppleScript aufrufen" | ruft je Zeile ein Skript auf; **jede Spalte steht als `$[spaltenname]$`** im Skript, dazu `$[tabelle]$`; der Patient kommt aus den Spalten `patientid` bzw. `besuchid` |
| „Liste mit AppleScript aufrufen" | ein Skriptlauf mit der ganzen Liste als `$[tabelle]$` |

```
HQL-Statistik (eine Zeile je Fall)
        ↓ Ergebnisliste
Aktionskette je Listeneintrag → Aktionstyp „Aufgabe" (aus Aufgabenvorlage)
  oder AppleScript je Listeneintrag mit $[spalte]$-Werten
```

Der Kontext kommt aus der Listenzeile, nicht aus einem Aufrufparameter. **Offen:** ob sich der
Durchlauf ohne Klick im Statistikfenster anstossen laesst. Der automatische Statistik-Export
kann vor und nach dem Export je ein Skript starten.

## 5 · Deeplinks (`tomedo://`)

```
tomedo://patient#<patient.ident>              → Kartei des Patienten
tomedo://termin#<termin.ident>                → Kalender auf den Tag + Termin-Detailansicht
tomedo://karteieintrag#<karteieintrag.ident>  → Akte + Eintrag selektiert
```

**Alle Ziele.** tomedo kennt 17 Ziele; Schema und Ziel sind
unabhaengig von Gross-/Kleinschreibung, Parameternamen und Kettenkuerzel nicht.

| Ziel | Syntax | Wirkung |
|---|---|---|
| `patient` | `#<ident>` | Kartei oeffnen — sucht **nur in den lokal geladenen Daten**; unbekannte Ident: nichts passiert, keine Meldung |
| `termin` | `#<ident>` | Kalender + Termin; lokal (auch **geloeschte** Termine), sonst vom Server |
| `karteieintrag` | `#<ident>` | Akte + Eintrag; sonst Serversuche, Meldung „Ausgewählter Karteieintrag mit Ident … existiert nicht …" |
| `aufgabe` | `#<ident>` | Aufgabe in der Aufgabenverwaltung |
| `dokument` | `#<ident>` | QM-Dokument (Meldung, wenn geloescht oder kein Recht) |
| `email` | `#<ident>` | E-Mail-Details; sonst vom Server |
| `ticket` | `#<Ticketnummer>` | Ticketverwaltung |
| `terminSuche` | `?suche=<ident>&patient=<ident>` | Fenster Terminsuche (Query-Parameter, beide optional) |
| `terminKetteSuche` | `?ketteSuche=<ident>&patient=<ident>` | Terminsuche fuer eine Terminkette |
| `aktionskette` | `?<Kuerzel>&…` | Aktionskette starten (unten) |
| `menu` | `#<Menuetitel oder Kennung>` | **loest einen beliebigen sichtbaren, aktiven Menueeintrag aus** (Titel wie angezeigt, Schreibweise egal; „Bearbeiten" und „Format" ausgenommen). Nicht gefunden: „Menüeintrag '…' wurde per Link ausgelöst aber nicht gefunden." So funktionieren die Menuelinks in tomedos eigenen Hinweistexten |
| `custom/laboreinstellungen-gruppenverwaltung`, `custom/mutterpasseinstellungen-mutterpass` | Pfad | Laboreinstellungen bzw. Mutterpass-Einstellungen (nur Admins) |
| `inboxkopplungsanfrage`, `marktplatz`, `sikant`, `keycloak`, `blueEvidenceOAuth` | — | interne Ziele (arzt-direkt-Kopplung, Tausch-Center, Sachkosten-Schnittstelle, Anmeldungen) |

- **Fragment oder Query:** Die meisten Ziele lesen das Fragment hinter `#`;
  `tomedo://patient?patientID=42` funktioniert nicht. Query-Parameter lesen `aktionskette`,
  `terminSuche` und `terminKetteSuche`.
- **Aktionskette per Link:**

```
tomedo://aktionskette?<Kuerzel>&patientident=<ident>&<name>=<wert>#variable
```
  Erster Parameter = Kettenkuerzel **ohne** Wert (`?ABC=` wird abgewiesen); `patientident` oder
  `besuchident` waehlt den Patienten (ohne: Besuch der zuletzt benutzten Kartei, sonst Meldung
  „Keine Kartei geöffnet. …"); mit `patientident` legt tomedo einen lokalen Besuch fuer heute an
  bzw. nimmt den vorhandenen. Weitere `name=wert` gehen an die Kette, je nach Fragment
  `#variable` (Standard), `#briefkommando` oder `#beides`; der Parameter
  `variablenmodus=variable|briefkommando|beides` hat Vorrang vor dem Fragment. Idents liest der
  Link nur bis 2 147 483 647 — Besuche mit groesserer Ident findet er nicht **[ungeprueft]**.
  **Keine Rueckfrage** und keine Freigabe an der Kette noetig: jede sichtbare Kette laesst sich
  per Link starten, auch aus einem fremden Link (z. B. aus einer Webseite oder E-Mail) —
  vor dem Einsatz bedenken. Der ganze Link samt Parametern wird protokolliert.
- **Bildschirmsperre:** Ist sie aktiv, nimmt tomedo keinen Link an („Bitte loggen Sie sich mit
  Ihrem Benutzernamen und Passwort in tomedo ein.").
- **`menu#` ohne Anmeldung:** zeigt den Hinweis „Solche Links gehen nur, wenn ein Nutzer
  angemeldet ist …" — der Menueaufruf folgt nach aktuellem Stand trotzdem **[ungeprueft]**.
- **`termin` und `karteieintrag`** loesen den Patientenkontext **selbst** auf und laden bei Bedarf
  vom Server. `patient` laedt nichts nach.
- **`termin` fragt den Server direkt ab:** bei ungueltiger Ident erscheint
  `Serverfehler 404 ; URL http://<server>:8080/tomedo_live/Termin/<ident> (GET)` und danach
  „Der Termin konnte nicht geladen werden. Bitte überprüfen Sie Ihre Internetverbindung …" —
  **die naheliegende Diagnose (Netz) ist fast immer falsch.** Zusaetzlich schaltet dieser
  Fehler tomedo in den **Offline-Zustand**, bis die naechste Serveranfrage gelingt
  **[ungeprueft]**. Lokal vorhandene Patienten, Termine und Karteieintraege oeffnen auch ohne
  Serververbindung.
- **Registrierte Schemata:** Die `Info.plist` registriert neben `tomedo` die Alt-Schemata
  `patient`, `aufgabe`, `dokument` (werden auf `tomedo://` umgeleitet) und zwoelf
  Familien-Schemata (`mutter`, `vater` … `enkeltochter`), die tomedo **nie** auswertet —
  sie erzeugen keinen Sprung (an der Referenzinstallation als „Hosts ohne Wirkung" gemessen).
- **Idents sind 58 Bit** (`zeitstempel << 19`, vom Server vergeben) → nie durch `float`/JS-Number
  parsen, in SQL `ident::text`. `patient.ident` (27 Bit) ist unkritisch.
- **Tests brauchen echte Idents.** Ein 404 ist von einem geloeschten Objekt nicht
  unterscheidbar; `MAX(ident)` liefert das neueste Objekt als besten Kandidaten.
- **Nach jedem tomedo-Update pruefen** (`open 'tomedo://termin#<ident>'`): ein Fehlschlag
  heisst tote Links, bei `patient` sogar ohne Meldung, und **Nutzer melden das nicht, sie hoeren
  auf zu klicken.** Gehoert in die Update-Nachsorge, nicht in die Bug-Bearbeitung.
- **Wo tomedo selbst Links erzeugt:** Kartei › Karteieintrag › „Link kopieren", Termin-Info
  Knopf „Terminlink", Aufgaben- und Ticket-Links, Menuelinks in Hinweistexten.

Wo Deeplinks klickbar werden (Metabase-Spalte, HTML-Dateianhang) und wo nicht (tomedo-
Formularfelder, Dashboard-Text-Cards): `tomedo-metabase-migration/references/deep-linking.md`
und `tomedo-patientenformulare/references/permalink-api.md`.

## 5a · Steuerung von aussen per HTTP

tomedo betreibt einen eingebauten Webserver, der **ab Programmstart immer laeuft**.

**Pflegeort:** `Einstellungen › Arbeitsplatz › Grundeinstellungen`, Abschnitt **„Steuerung von
außen"** (nur Deutschland; Werte gelten je Rechner):

| Bedienelement | Wirkung |
|---|---|
| „Port zur Steuerung von außen" + „Neustart" | Standard **8070** |
| Auswahl „Aktionsketten nicht starten lassen" / „Aktionsketten starten mit Nachfrage" (Standard) / „Aktionsketten einfach starten" | ob ein HTTP-Aufruf Ketten startet |
| „Token (authToken)" + „Erzeugen" | leer = keine Tokenpruefung; sonst muss jeder Aufruf `authToken=<Token>` mitgeben |
| „Freigegebene Adressen" + „Zurücksetzen" (nur Admin) | IP-Adressen, die ohne Rueckfrage aufrufen duerfen |
| „tomedo nach vorn holen" | holt tomedo vor dem Kettenstart in den Vordergrund |

**Aufruf:** `http://<rechner>:8070/aktionskette?<Kuerzel>&patientident=<ident>&<name>=<wert>&variablenmodus=beides&authToken=<Token>`
— dieselben Parameter wie der Deeplink, nur kommt ein `#…` per HTTP nicht an; den Modus also
mit `variablenmodus=` waehlen **[ungeprueft]**. Antworten: 200 gestartet, 400 abgelehnt
(Bildschirmsperre, Einstellung, Startfehler), 401 Token fehlt oder falsch.

**Pruefreihenfolge:** (1) Bildschirmsperre → 400. (2) Einstellung: „nicht" → abgelehnt;
„mit Nachfrage" → Dialog „Aktionskettenauslösung via Netzwerk" am Arbeitsplatz. (3) Unbekannte
Adresse → Dialog zur Freigabe; dauerhaft gespeichert wird sie nur, wenn ein Admin zustimmt,
auch `127.0.0.1` muss freigegeben sein. (4) Token. Die Dialoge erscheinen also **vor** der
Tokenpruefung — wer den Token nicht kennt, kann am Arbeitsplatz trotzdem Rueckfragen ausloesen.
Der Admin-Knopf „Ja, aber beim nächsten Mal wieder fragen" stellt nach aktuellem Stand dauerhaft auf
„einfach starten" um **[ungeprueft]** — vor dem Einsatz testen.

**Netz:** Der Server lauscht auf allen Netzwerkschnittstellen und spricht nur HTTP, ohne
Verschluesselung **[ungeprueft]**; der Token steht im Klartext in der Adresse. Daneben gibt es
einen Endpunkt, ueber den der Hersteller-Support die Logdateien abruft — nur mit einem Token,
den der tomedo-Server bestaetigt.

## 6 · Sicherheitsbefunde

- **`ZSOURCECODE` ist unverschluesselter Klartext** — im Server-Objekt und im lokalen
  SQLite-Cache **jedes** Arbeitsplatzes, auf Dateiebene ohne Adminrecht lesbar.
- **Der aufgeloeste Skripttext wird protokolliert.** Bei jedem Lauf schreibt tomedo den Text
  **nach** dem Einsetzen der Platzhalter ins Protokoll, also mitsamt Karteitext und
  Patientendaten, vermutlich in `tomedo.log` **[ungeprueft]**. Im Parallelmodus liegt er
  zusaetzlich kurz als Temp-Datei im Skriptordner des Nutzers.
- **Skript-Bestaende enthalten erfahrungsgemaess Passwort-Schluesselwoerter** — typischer
  Kontext: SMB-Mounts, RDP-Verbindungen, Druckerinstallation. In einem geprueften Bestand
  betraf das rund ein Drittel der Skripte. Ob es echte Zugangsdaten oder nur Variablennamen
  sind, laesst sich nur je Installation klaeren und **gehoert unabhaengig geprueft**; die
  konkreten Werte sollten dabei nicht gelesen werden.
- **Konsequenz:** Skripttexte sind kein Ort fuer Geheimnisse. Zugangsdaten in den
  Login-Schluesselbund, Zugriff aus dem per `do shell script` gestarteten Prozess.
- **Ein Skript traegt die Identitaet des angemeldeten Nutzers** — fuer alles, was in tomedo
  passiert (Briefkommandos, Patientendaten, Aktionsketten). `do shell script` laeuft dagegen mit
  den Rechten des **macOS-Benutzers**. Start- und Intervall-Skripte laufen auch, wenn niemand
  angemeldet ist **[ungeprueft]**. Fuer Automatisierung deshalb einen minimal privilegierten
  Nutzer entwerfen (`Admin › Praxisorganisation › Rechteverwaltung` + `Patientenzugriffsprofile`).
- **Deeplinks und HTTP starten Ketten ohne Rueckfrage** (Abschnitte 5 und 5a): bei
  `tomedo://aktionskette` und `tomedo://menu` immer, bei HTTP je nach Einstellung.

## 7 · Elektron-Nachbar ArZeKo (Abgrenzung)

Die App ArZeKo (Arbeitszeitkonto) ist **Electron**, nicht Cocoa. Konsequenzen, falls dort
automatisiert wird: das Fenster muss **unverdeckt** sein — bei verdecktem Fenster pausiert
Chromium das Rendering, der AX-Baum endet als `AXGroup`-Kette ohne `AXWebArea`, und jede
Automation scheitert **stumm**. „Nicht minimiert" genuegt nicht. tomedo selbst ist als
native Cocoa-App deutlich stabiler adressierbar (role+name durchgaengig,
`AXManualAccessibility` nicht noetig). tomedo hat dafuer einen eigenen Menueeintrag
`Aktion › Arzeko - Arbeitszeitkonto`.

## 8 · CKE-Editor per Accessibility (belegt 28.09.2026)

Das Fenster „CustomKarteieintragVerwaltung – <Name>" ist per System-Events-AX bedienbar,
**ohne `activate`**. Elementpfade: Tabelle `outline 1 of scroll area 1 of splitter group 1`,
Art-Menü `pop up button 1 of UI element 4 of row n`, Detailfeld `group 3 of splitter group 1`,
OK-Knopf `button "OK" of splitter group 1` (nicht direkt am Fenster).

| Handlung | Wirkung auf den Nutzer |
|---|---|
| Lesen (Werte, Menüeinträge ohne Öffnen) | keine |
| Zeile auswählen, `AXPress` auf Knöpfe (+, OK, Export) | keine, tomedo bleibt im Hintergrund |
| `AXShowMenu` + `AXPress` auf Menüeintrag | tomedo bleibt hinten, **aber das offene Menü fängt Tastendrücke ab** |
| `AXPress` auf Markierungsfeld (Checkbox) | **holt tomedo nach vorn** (2× beobachtet) |
| `set value` auf einzeiliges Textfeld | Anzeige ändert sich, **Wert kommt nicht im Export an** |
| `set value` auf Textbereich (Tooltipp, Vorauswahl, Karteitext) | wird übernommen |

Regeln für Arbeit neben einem tippenden Nutzer: Menüs nur öffnen, wenn
`ioreg -c IOHIDSystem` → `HIDIdleTime` ≥ 8 s **und** tomedo nicht vorn ist; Checkboxen nicht
per Klick setzen; nach „+" steht die neue Zeile im Bearbeitungsmodus, dann öffnet kein Menü —
vorher eine Zeile ohne Textfeld (Trennlinie) auswählen. `kind` ist in System Events reserviert.

**Export** (Karteieintragstypenverwaltung → Export) schreibt ohne Speicherdialog nach
`~/Desktop/customKarteieintrag_<KÜRZEL>.dict` und öffnet ein Fenster „Hinweis" **ohne
OK-Knopf**; `button 1` darin ist die **Stecknadel**, schließen über den Knopf mit
description „Schließen-Taste". Der Schreibtisch ist für Claude per macOS-Datenschutz gesperrt,
die Datei muss der Nutzer verschieben. Andere tomedo-Fenster tragen Patientendaten im Titel —
Fensterlisten nicht protokollieren.
