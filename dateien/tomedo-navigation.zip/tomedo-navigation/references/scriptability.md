# Scriptability, Skript-Feature und Deeplinks

Quelle: Bundle `tomedo.app` und lokaler Core-Data-Cache `ServerEntities.sqlite`
(read-only gelesen), tomedo **v1.169.0.21**; Deeplink-Befunde aus dem Pilot 08/2026.

---

## 1 · tomedo ist offiziell scriptbar

- `Info.plist`: **`NSAppleScriptEnabled = true`**, `OSAScriptingDefinition = tomedo.sdef`
- Dictionary: `Contents/Resources/tomedo.sdef`
- Python-Laufzeit im Bundle: `Contents/PlugIns/libZSPython.dylib`

**Ein vom Hersteller vorgesehener Erweiterungspunkt**, keine Hintertuer — fuer die
MVZ-Abwaegung wichtig: ein Skript ueber diese Schnittstelle ist kategorial etwas anderes
als ein nicht unterstuetzter Direkt-Write in die Datenbank.

## 2 · Das vollstaendige Kommando-Inventar

| Kommando | Parameter | Was es wirklich tut |
|---|---|---|
| **`call aktionskette`** | `kuerzel` (text) | ruft eine Aktionskette anhand ihres Kuerzels auf. **Der Hebel.** |
| **`call statistik`** | `file` (Dateipfad) | zeigt eine **CSV** im Statistikfenster an |
| `search patient` | `searchtext` | oeffnet die Patientensuche mit dem Text |
| `call number`, `handle … call event` | text | Telefonie (Starface/NFON/Agfeo/Swyx) |
| ~~`terminateForRelaunch`~~ | — | im sdef auskommentiert, nicht verfuegbar |

**Was das Dictionary NICHT kann:** kein Kommando erzeugt oder aendert tomedo-Objekte —
kein Sperrtag, kein Termin, keine Aufgabe, keine Nachricht, kein Karteieintrag.
Schreibende Wirkung ist ausschliesslich **indirekt ueber `call aktionskette`** erreichbar.

### Zwei Einschraenkungen, die das Design bestimmen

1. **`call aktionskette` nimmt nur ein Kuerzel — keine Parameter.** Konkrete Werte
   (Behandler, Datum, Terminzeit) koennen nicht mitgegeben werden; haeufige Syntaxfalle:
   das Wort `kuerzel` im Aufruf **weglassen**. Die Kette muss ihre Daten selbst beschaffen
   (Kontext, Statistik-Ergebnisliste) oder ueber Aktionsketten-*Fragen* — die sind interaktiv.
2. **`call statistik` ist ein Anzeige-, kein Abfragekanal.** Es fuehrt keine HQL-Statistik
   aus und liefert dem Aufrufer kein Ergebnis; es rendert eine CSV. Eine HQL-Statistik *in*
   tomedo bleibt als Query-Traeger nuetzlich, ihr Ergebnis programmatisch abzuholen ist
   damit **nicht** geloest. (Loesung dafuer: Metabase-Card-API, s. `tomedo-metabase-migration`.)

## 3 · Das Skript-Feature (`Admin › Skripte`)

Objekte liegen in `ZSKRIPT` (Core Data, serverseitig gepflegt, lokal gecacht).
Bestand: **30 Skripte, alle AppleScript** (`ZLANGUAGE = 0`; der Python-Wert ist unbelegt).

| Spalte | Bedeutung |
|---|---|
| `ZSOURCECODE` | Quelltext, **Klartext** |
| `ZISACTIVE` | Aktivierung erfolgt **je Arbeitsplatz** durch Admin |
| `ZRUNWITHTIMEINTERVAL` + `ZTIMEINTERVAL` | **periodische Ausfuehrung** — belegte Werte: 1 s, 10 s, 60 s |
| `ZRUNONSTARTUP` | beim Start ausfuehren (5 Skripte) |
| `ZRUNPARALLEL` | parallele Ausfuehrung |
| `ZINKARTEITOOLBAR` / `ZINTAGESLISTETOOLBAR` / `ZINFORMULARTOOLBAR` | Platzierung als **Toolbar-Button** |
| `ZMARKETPLACEVERSION`, `ZONLINEID` | es existiert ein **Skript-Marktplatz** |
| `ZBESCHREIBUNG`, `ZTOOLTIP`, `ZCUSTOMIMAGE` | UI-Metadaten |

### Ereignis-Hooks sind belegt

Zwei Skripte heissen `#_KarteiGeoeffnet` und `#_KarteiGeschlossen`; der Quelltext des ersten
beginnt mit „Dieses Script wird von tomedo ausgefuehrt, wenn eine Kartei geoeffnet wird."
→ tomedo ruft Skripte **ereignisgesteuert** auf. Der vollstaendige Ereigniskatalog ist noch
offen (Zuordnung vermutlich in der Admin-UI, nicht ueber den Namen).

### Kontext kommt ueber tomedo-Platzhalter

Skripte werden vor der Ausfuehrung substituiert — dieselbe `$[…]$`-Syntax wie Briefkommandos.
Im Bestand tatsaechlich verwendet: `$[nutzerkuerzel]$` (5×) · `$[pid]$` (4×) · `$[bk]$` (4×) ·
**`$[arbeitsplatz]$`** (3×) · `$[pv]$` · `$[pn]$` · `$[patientVN]$` · `$[patientNN]$` ·
`$[patientID]$` · `$[bes_gebDatum]$` · `$[aktuellerTodoRaum]$`.

**`$[arbeitsplatz]$` und `$[nutzerkuerzel]$` loesen das Mehrfachausfuehrungs-Problem:** ein
periodisches Skript, das auf allen Arbeitsplaetzen aktiv ist, kann sich selbst auf genau
einen Arbeitsplatz einschraenken.

### `do shell script` ist der Ausweg aus AppleScript

**28 von 30** Skripten nutzen `do shell script`. Ein tomedo-Skript kann also beliebige lokale
Programme starten — vorhandene Python-Logik muss **nicht** nach AppleScript portiert werden.
Vorteil zusaetzlich: Geheimnisse bleiben im aufgerufenen Prozess (Keychain) statt im
Skript-Quelltext.

## 4 · Gegenprobe: Aktionsketten koennen keine Sperrtage anlegen

Gegen den Aktionstypen-Katalog geprueft (07/2026). Kategorie „Termin & Kalender" enthaelt
**genau drei** Aktionstypen, und **keiner schreibt**:

| Aktionstyp | Verhalten |
|---|---|
| Terminsuche (Definiert) | oeffnet ein Suchfenster, **blockierend** |
| Terminsuche (Kette) | Kettenterminsuche, interaktiv |
| Sprechstundenassistent | oeffnet den Assistenten |

Kein „Termin anlegen", kein „Sperrtag", kein „Urlaubstag", keine Ganztagsart. Wer
Ganztags-Abwesenheiten programmatisch setzen will, braucht den Weg ueber das
Arbeitszeitkonto (ArZeKo → nativer tomedo-Sync). Ein direkt im Kalender gesetzter Sperrtag
verbucht **keinen** Urlaubsanspruch und reduziert **keine** Sollzeit.

**Baubar sind dagegen:** `Aufgabe` (aus Aufgabenvorlage — der Standard-Meldekanal),
`Nachricht` (Nachrichtenvorlage), `ToDo anlegen` (Tagesliste), `AppleScript` (laeuft *nach*
der Aktion), `Zurueckschreiben` (Bool1-4/String1-4/Info in Besuchs-/Patientenfelder — taugt
als Zustandsuebergabe zwischen Ketten, z.B. „schon gemeldet"). Vorlagen muessen **vorher**
existieren. Debugging: `Hilfe › Loglevels Feinschaltung › LogLevelAktionskettenbedingung`.

### Das Parameterproblem hat eine Loesung: Statistik-Ergebnislisten

Die Aktion „Aktionskette fuer alle Listeneintraege nacheinander ausfuehren" iteriert eine
Statistik-Ergebnisliste:

```
HQL-Statistik (eine Zeile je Fall)
        ↓ Ergebnisliste
Aktionskette je Listeneintrag → Aktionstyp „Aufgabe" (aus Aufgabenvorlage)
```

Der Kontext kommt aus der Listenzeile, nicht aus einem Aufrufparameter. **Offen:** ob der
Durchlauf automatisiert anstossbar ist oder eine Nutzeraktion im Statistikfenster erfordert.

## 5 · Deeplinks (`tomedo://`)

```
tomedo://patient#<patient.ident>              → Kartei des Patienten
tomedo://termin#<termin.ident>                → Kalender auf den Tag + Termin-Detailansicht
tomedo://karteieintrag#<karteieintrag.ident>  → Akte + Eintrag selektiert
```

- **Nur das Fragment wird ausgewertet.** `tomedo://patient?patientID=42` funktioniert nicht.
- `termin` und `karteieintrag` loesen den Patientenkontext **selbst** auf.
- Die Host-Liste ist eine **handgepflegte Whitelist im Client**; sieben weitere in
  `Info.plist` registrierte Hosts erzeugen mit gueltigen Idents **keinen** Sprung.
- **Der Handler ist ein REST-Client**: bei ungueltiger Ident erscheint
  `Serverfehler 404 ; URL http://<server>:8080/tomedo_live/Termin/<ident> (GET)`. Ohne
  Serververbindung ist die Navigationsschicht tot, und dem Nutzer wird „Bitte ueberpruefen
  Sie Ihre Internetverbindung" gezeigt — **die naheliegende Diagnose (Netz) ist fast immer
  falsch.**
- **Idents sind 58 Bit** (`zeitstempel << 19`) → nie durch `float`/JS-Number parsen,
  in SQL `ident::text`. `patient.ident` (27 Bit) ist unkritisch.
- **Tests brauchen echte Idents.** Ein 404 ist von einem geloeschten Objekt nicht
  unterscheidbar; `MAX(ident)` liefert das neueste Objekt als besten Kandidaten.
- **Nach jedem tomedo-Update pruefen** (`open 'tomedo://termin#<ident>'`): ein Fehlschlag
  heisst tote Links ohne Fehlermeldung, und **Nutzer melden das nicht, sie hoeren auf zu
  klicken.** Gehoert in die Update-Nachsorge, nicht in die Bug-Bearbeitung.

Wo Deeplinks klickbar werden (Metabase-Spalte, HTML-Dateianhang) und wo nicht (tomedo-
Formularfelder, Dashboard-Text-Cards): `tomedo-metabase-migration/references/deep-linking.md`
und `tomedo-patientenformulare/references/permalink-api.md`.

## 6 · Sicherheitsbefunde

- **`ZSOURCECODE` ist unverschluesselter Klartext** — im Server-Objekt und im lokalen
  SQLite-Cache **jedes** Arbeitsplatzes, auf Dateiebene ohne Adminrecht lesbar.
- **Skript-Bestaende enthalten erfahrungsgemaess Passwort-Schluesselwoerter** — typischer
  Kontext: SMB-Mounts, RDP-Verbindungen, Druckerinstallation. In einem geprueften Bestand
  betraf das rund ein Drittel der Skripte. Ob es echte Zugangsdaten oder nur Variablennamen
  sind, laesst sich nur je Installation klaeren und **gehoert unabhaengig geprueft**; die
  konkreten Werte sollten dabei nicht gelesen werden.
- **Konsequenz:** Skript-Quelltexte sind kein Ort fuer Geheimnisse. Zugangsdaten in den
  Login-Schluesselbund, Zugriff aus dem per `do shell script` gestarteten Prozess.
- **Ein Skript traegt die Identitaet des angemeldeten Nutzers.** Der Client muss laufen und
  angemeldet sein; damit steht dem Skript grundsaetzlich offen, was diesem Nutzer offensteht.
  Fuer Automatisierung deshalb einen minimal privilegierten Nutzer entwerfen
  (`Admin › Rechteverwaltung` + `Patientenzugriffsprofile`).

## 7 · Elektron-Nachbar ArZeKo (Abgrenzung)

Die App ArZeKo (Arbeitszeitkonto) ist **Electron**, nicht Cocoa. Konsequenzen, falls dort
automatisiert wird: das Fenster muss **unverdeckt** sein — bei verdecktem Fenster pausiert
Chromium das Rendering, der AX-Baum endet als `AXGroup`-Kette ohne `AXWebArea`, und jede
Automation scheitert **stumm**. „Nicht minimiert" genuegt nicht. tomedo selbst ist als
native Cocoa-App deutlich stabiler adressierbar (role+name durchgaengig,
`AXManualAccessibility` nicht noetig).
