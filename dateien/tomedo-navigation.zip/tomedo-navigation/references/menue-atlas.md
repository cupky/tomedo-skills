# Menue-Atlas tomedo

Quelle: Accessibility-Auslesung der Menueleiste der laufenden Instanz v1.169.0.21 (zwei Dumps
derselben Instanz: ohne und mit Adminrecht; Werkzeug `dump_menus.applescript`, rein lesend),
**seit Fassung 1.5 systematisch ueberprueft** (Oktober 2026). Wo sich tomedo seit der
Erhebung geaendert hat, steht der neuere Stand; **[ungeprueft]** = noch nicht in der
Oberflaeche nachgestellt — vor dem Einsatz an einer Testakte pruefen.

Menues haengen an Land (DE/AT/CH), Fachrichtung (Dental), Modulen und Systemeinstellungen.
Was hier steht, ist der Bestand; ob ein Eintrag in einer Praxis sichtbar ist, entscheiden diese
Schalter. Dazu kommt die **Menueanpassung** (§ 6): ausgeblendete Eintraege liegen unter
„ausgeblendet…" am Ende des Menues.

---

## 1 · Ordnungslogik aller Menues

| Menue | Rolle | Merkregel |
|---|---|---|
| `tomedo` | App + Infrastruktur: `Über tomedo ⌥⌘I`, `Einstellungen ⌘,`, `Serveradresse ändern`, `Server-Tools Webinterface`, `TI-Services Dashboard` (nur mit Konnektor), `Lokale Datenbank löschen`, `tomedo neu starten`; dazu eine Kopie des Hilfe-Menues (`tomedo › Hilfe ›`) | Alles ueber *das Programm* |
| `Bearbeiten` | Text: Suchen/Ersetzen, Rechtschreibung, Apple-`Schreibtools` (fuegt macOS selbst ein) | macOS-Standard + Textwerkzeuge |
| `Format` | Schrift/Absatz im Brief- und Karteitext; `LLM-Textgenerator` nur, wenn per Systemeinstellung eingeschaltet | nur beim Schreiben relevant |
| `Verwaltung` | Listen und Verwaltungsfenster **oeffnen** | „Ich will eine Uebersicht" |
| `Admin` | Konfiguration des Systems | „Ich will festlegen, wie tomedo arbeitet" (Sichtbarkeit § 5) |
| `Formular` | Formulare/Vordrucke im Patientenkontext; Kategorien und meistgenutzte Formulare werden zur Laufzeit aus den Stammdaten gebaut | „Ich will ein Vordruck-Dokument" |
| `Aktion` | Neue Objekte **anlegen** | „Ich will etwas erzeugen" |
| `Patient` | erscheint mit Tagesliste, Kartei oder Patientendetails im Vordergrund; je Fenster eigenes Menue mit Patientenkuerzeln (§ 8) | „Ich will etwas mit *diesem* Patienten" |
| `Eintrag` | erscheint mit der Kartei im Vordergrund; listet die Karteieintragstypen | „Ich will einen Karteieintrag anlegen" |
| `Panel` | Seiten-/Dock-Panels ein- und ausblenden (gehoert zum Hauptfenster) | „Ich will ein Dauer-Fenster daneben" |
| `Fenster` | macOS-Fensterverwaltung + Liste der offenen Fenster | ⚠ enthaelt PHI |
| `Hilfe` | tomedo-Suche (`⌥ Leertaste`), Handbuch, Campus, Forum, **Logs ›**, **Hilfswerkzeuge ›** | Support + Diagnose |

`Logs ›` liegt unter `Hilfe` (Eintraege `tomedo.log öffnen`, `tomedo.extra.log öffnen`,
`Loglevels Feinschaltung`, `plistHistory.log öffnen`), im tomedo-Menue nur ueber dessen
Hilfe-Kopie. Ein Menue `zollsoft` gibt es nur fuer den Hersteller-Zugang.

## 2 · Pflegeort → Org-Skill

Die wichtigste Tabelle fuer Skills, die erklaeren sollen, **wo** etwas eingerichtet wird.

| Pfad unter `Admin` | Zustaendiger Skill |
|---|---|
| `Kommandos` | `tomedo-kommandos` — Pflegeort der Briefkommandos/Platzhalter |
| `Aktionsketten ›` (Aktionsketten · Aktionsketten-Auslöser · Aktionsketten-Bedingungen · Aktionsketten-Fragen) | `tomedo-aktionsketten` — genau die vier Objekttypen des Skills, 1:1 |
| `Patientenformulare` · `Webformulare` · `arzt-direkt ›` (Instanzkonten, Nutzerkonten, Automatisierte Nachrichten, Nachrichtenvorlagen (arzt-direkt), Zeitversetzte Nachrichten) | `tomedo-patientenformulare` — Formularpflege **und** Ausspielkanal. `Geräteeinstellungen › arzt-direkt` ist nur noch eine Umleitung mit dem Hinweis, die Konten lägen jetzt unter `arzt-direkt › Nutzerkonten` |
| `Textbausteine/Makros` | `tomedo-textbausteine` |
| `Marker` (auch Kartei › `Patient › Marker ⌃⇧⌘M` und Zahnrad im Marker-Popover der Kartei) | `tomedo-marker` — automatische Marker: Regeln, Test, Fehlerbilder |
| `Karteieintragstypen` (Menueeintrag ohne Untermenue; im Fenster Knoepfe `CustomKarteieintrag`, `Editieren`, `Export`, `Import`) | `tomedo-cke` — Custom-Karteieinträge bauen, prüfen, importieren |
| `Statistikverwaltung` · `Cockpit › Cockpit 3.0 / 4.0` | `tomedo-statistik-hql`, `tomedo-metabase-migration` |
| `Vorlagen (Briefe, Rechnungen, PDF-Formulare)` · `Formulare` | `tomedo-kommandos` (Briefvorlagen und Platzhalter) |
| `KV (EBM) ›` · `Privat (GOÄ) / BG (UV-GOÄ) ›` (Titel je nach Fachrichtung und Land anders) | `tomedo-statistik-hql` (Leistungsauswertung) |
| `Nutzerverwaltung ›` · `Praxisorganisation › Rechteverwaltung` · `Praxisorganisation › Patientenzugriffsprofile` | Rechte-/Rollenfragen, Service-Nutzer-Design (§ 5) |
| `Skripte (Python- und AppleScripts)` · `API-Verwaltung` · `Menü-Buttons` | Automatisierung → `references/scriptability.md` |
| `Kalender › Kalenderverwaltungen` → Gruppe **Sperrtage** (`Urlaubs- und Sperrtagstypen`, `Sperrtage`) | Sperrtag-Themen (lesend: `tomedo-statistik-hql`, `terminkalendertag`) |
| `Kalender › Kalenderverwaltungen` → Gruppe **Terminbenachrichtigungen** (Terminerinnerungen, Terminänderungsbenachrichtigungen) | Terminerinnerungen (unten) |

Unter `Verwaltung` (nicht `Admin`) liegen dagegen die **Arbeits**-Fenster, u.a.:
`Textbausteine/Makros` (zweiter Zugang), `Verwaltung Nachrichtenvorlagen` (zweiter Zugang),
`Statistiken ⌥⌘S`, `Auto-Statistik-Export-Verwaltung` (nur wenn eingeschaltet),
`Gespeicherte Statistikergebnisse`, `Cockpit` (dasselbe wie Admin › Cockpit › Cockpit 4.0),
`Favoritenlisten ›` (ICD-10/Hausdiagnosen, EBM, EBM-Zusatzangaben, GOÄ, UV-GOÄ, KV-Schein u. a.),
`KI-Assistenten ›` (neue Sprechstunde · Aufnahmeverwaltung · **KI-Assistenten-Verwaltung** —
Konfigurationsort der KI-Assistenten → `tomedo-karteichat-prompting`; im Fenster die Gruppen
Sprechstunden-Assistent, Chat-Assistent, Intelligentes Diktat, Dokumentenassistent, Erweitert),
`KV ›` (KV-Abrechnung, Budgetrechner, Chroniker-Prüfung, **Budgetübersicht** (frueher „RLV"),
EBM-Fachgruppendurchschnitt u. a.).

Zwei getrennte Wege bei Formularen: `Formular › Patientenformulare ›` **oeffnet** ein Formular
fuer den aktiven Patienten (ob direkt gedruckt oder erst angezeigt wird, **[ungeprueft]**),
`Aktion › Patientenformulare anfordern` **fordert beim Patienten an**.


### Pflegeort Terminerinnerungen — Stufen und Kanaele (Realbefund 2026-08-26)

Pflegeort: **Admin › Kalender › Kalenderverwaltungen → Gruppe Terminbenachrichtigungen →
Terminerinnerungen** (an v1.169 noch eigener Menueeintrag „Kalender → Terminerinnerung"; nach
aktuellem Stand (10/2026) nur noch im Fenster **[ungeprueft]**). Datenmodell dahinter:

```
terminerinnerungplan      Plan: aktiv, → Terminarten, → Kalender
  └─ terminerinnerungart      Stufe: listenposition, min/maxdaysbeforetermin,
      │                              emailvorlage_ident, smsvorlage_ident
      └─ terminerinnerungartmodus  Kanal: priority, inactive, type
terminerinnerung          Versandprotokoll: status, errormsg, senddate, → email/smsnachricht
```

**Email und SMS in einer Stufe sind eine Kaskade, kein Parallelversand.** Die gemeinsame Belegung
von `emailvorlage_ident` und `smsvorlage_ident` in einer Stufe bedeutet Kanalpriorisierung: der
zweite Kanal greift nur, wenn der hoeher priorisierte scheitert (`terminerinnerungartmodus.priority`).
Aus einer belegten Feldkombination darf **nicht** auf Versandverhalten geschlossen werden — immer
die Modus-/Prioritaetstabelle mitlesen.

**Parallelversand braucht je eine Stufe pro Kanal.** Zwei Stufen mit identischem Tagesfenster feuern
beide (produktiv belegt an der Referenzinstallation 2026-08-26). Damit sind Muster baubar, die das System nicht als eigenes
Feature anbietet:

- **Terminbestaetigung bei Buchung** = Stufe mit sehr grosser Vorlaufzeit (`maxdaysbeforetermin`
  groesser als der laengste Buchungsvorlauf). Achtung Randfall: liegt ein Termin **jenseits** des
  Fensters, wird nicht bei Buchung bestaetigt, sondern erst beim Hineinrutschen — also ggf. Wochen
  spaeter. Fenster darum grosszuegig setzen (365 Tage statt 100).
- **Mehrkanalige Bestaetigung** = zwei Stufen mit demselben Fenster, eine je Kanal.

Dies ist zugleich der Weg, Kommunikation an Terminereignisse zu haengen, **ohne** Aktionskette —
und der einzige, der bei serverseitig erzeugten Objekten ueberhaupt funktioniert
(Skill `tomedo-aktionsketten`: „Kein Arbeitsplatz, keine Kette").

## 3 · Struktur des Menues `Admin`

Das Admin-Menue ist **flach mit Trennlinien**; die Blocknamen unten sind eine Ordnungshilfe,
keine Menuetitel. Reihenfolge wie im Menue.

| Block | Inhalt |
|---|---|
| **Nutzerverwaltung ›** | Nutzer · Nutzergruppen |
| **Praxisorganisation ›** | Betriebsstätten · ClientKonfiguration · ToDos · ToDo-Ketten · Arbeitsplätze · Arbeitsplatzgruppen · Raumverwaltung · Betten · Bettenstationen · Docboxeinstellungen (CH) · Praxisnotruf · Rechteverwaltung · Patienten nach DSGVO suchen und löschen · Patientenzugriffsprofile · Servernachrichtenverwaltung · Zertifikateverwaltung |
| **Geräteeinstellungen ›** | Drucker · Seriell · GDT · Labor · TI-Verwaltung · e-card System (AT) · arzt-direkt (nur Umleitung) · Zahlungsterminals · tomedo.LINK |
| **Einzeln** | Laboreinstellungen · Warenwirtschaft |
| **Inhalts-/Vorlagenpflege** | Vorlagen (Briefe, Rechnungen, PDF-Formulare) · Formulare · Patientenformulare · Karteieintragstypen · Kommandos · Textbausteine/Makros · Marker · Skripte (Python- und AppleScripts) · Webformulare · Metadaten verwalten (Dental) · Menü-Buttons · Favoritenlisten › |
| **Aktionsketten ›** | Aktionsketten · Aktionsketten-Auslöser · Aktionsketten-Bedingungen · Aktionsketten-Fragen |
| **Kalender ›** | **Kalenderverwaltungen** · TSSKontoverwaltung (nur mit TSS-Abrechnung) · *Alte Kalenderverwaltungsfenster ›* (nur noch Online-Terminkalender · Online-Terminkalender 2). Alles Weitere ist im Fenster Kalenderverwaltungen, siehe unten **[ungeprueft]** |
| **arzt-direkt ›** | Instanzkonten · Nutzerkonten · Automatisierte Nachrichten · Nachrichtenvorlagen (arzt-direkt) · Zeitversetzte Nachrichten |
| **Schnittstellen** | API-Verwaltung · API-Partner-Chat-Schnellantworten · Karteiversandprofile · E-Mail-/KIM-Konten · E-Mail-/KIM-Vorlagen · Kontenverwaltung E-Porto/Internetmarke · Verwaltung Nachrichtenvorlagen · SMS-Vorlagen · ePA |
| **Exporte** | Normdatensatz Export / Import · DIFA Export · TumorScout Export erzeugen (je nach Einstellung) |
| **Abrechnung/Kataloge** | (AT: Blanko-e-Rezeptverwaltung, Impf-Doku-Verwaltung, Patientenkontakte) · Früherkennungsverwaltung · Abrechnungsvorschläge · Leistungszähler · Custom-Karteieintrag CSV Export · Privat (GOÄ) / BG (UV-GOÄ) › mit Katalogen, Sachkosten, Begründungen, Rabatten, Rechnungskreisen/Kostenstellen, Rechnungstypen, PAD-/PVS-/Sammelrechnungstypen, Umsatzsteuerfavoriten · KV (EBM) › mit KV-Abrechnung, Strukturzuschlag (nur Psychotherapie-Modul), EBM-Katalog, Zifferneinschränkungen, Heilmittel-Katalog, OPS-Katalog, QZV (pro Nutzer/Betriebsstätte/praxisweit), KBV-Kodierregelwerk · KZV › (Dental) · ASV · CH-Tarife · Delegierte Leistungen · Heilmittelpositionen · DALE-UV › · DMP › (Datenannahmestellen) |
| **Diagnosen** | ICD10-Katalog · ICD10-Auto-Ersetzungen · ICPC2-Katalog (+ Länder- und Dental-Kataloge, Arbeitsmedizin ›) |
| **Auswertung** | Statistikverwaltung · Cockpit › (1.0/2.0 veraltet, 3.0, 4.0) |
| **Sonstiges** | Tausch-Center · Marktplatz (je nach Einstellung) · Server-Tools Webinterface |

### Kalenderverwaltungen (Fenster „Kalenderverwaltung")

Seit dem Umbau sind die frueheren Einzelfenster Ansichten eines Fensters mit Navigation links
(Stand 10/2026 **[ungeprueft]**):

| Gruppe | Inhalt |
|---|---|
| Kalender | Kalender, Kalenderfavoriten |
| Ressourcen und Schemata | Ressourcen, Lokalitäten, Schemata |
| Sperrtage | **Urlaubs- und Sperrtagstypen**, **Sperrtage** (Jahresansicht je Kalender, Feiertage, Feiertagsbereiche, „Sperrtage kopieren", Liste der Termine auf gesperrten Tagen) |
| Terminarten | Terminarten, Terminlimits |
| Terminsuchen | Terminsuche, Terminkettensuche |
| Terminänderungen | Lösch- und Verschiebegründe |
| Terminbenachrichtigungen | Terminänderungsbenachrichtigungen, Terminerinnerungen |
| Patientensperrung | automatische Patientensperrung, Blockliste Online-Terminkalender |

Alte Menue-Buttons, die auf die geloeschten Kalender-Menueeintraege zeigten, leitet tomedo auf
die passende Ansicht um. Die Rechte der alten Fenster gelten fuer die Ansichten weiter; eine
gesperrte Ansicht meldet „Der eingeloggte Nutzer hat nicht das Recht, die Verwaltungsansicht
'…' zu betrachten."

## 4 · Migrationsspuren — veraltete Pfade erkennen

tomedo beschriftet Altlasten selbst. **Inaktive** Wegweiser (ausgegraut, ohne Funktion):

- `Aktion › Fokus Tagesliste (jetzt unter Verwaltung)` → korrekt `Verwaltung › Tagesliste ⌘L`
- `Aktion › Kalender (jetzt unter Verwaltung)` → korrekt `Verwaltung › Kalender ⌥⌘K`
- `Admin › ICD-Favoriten (jetzt oben unter Favoritenlisten)`
- `Admin › KV (EBM) › Zusatzangaben (jetzt bei Favoritenlisten)`

**Noch aktiv**, obwohl als alt markiert:

- `Admin › Cockpit › Cockpit 1.0 / 2.0 (veraltet)` — oeffnen den Browser, neben `3.0` und `4.0`
- `Admin › Kalender › Alte Kalenderverwaltungsfenster ›` — enthaelt nur noch die beiden
  Online-Terminkalender. An v1.169 lag hier noch der ganze Kalender-Konfigurationszweig;
  Anleitungen mit `Alte Kalenderverwaltungsfenster › Terminarten` o. ä. sind veraltet, richtig
  ist `Kalenderverwaltungen` (§ 3) **[ungeprueft]**.
- `Admin › Geräteeinstellungen › arzt-direkt` — zeigt einen Hinweis auf den neuen Ort und oeffnet
  das alte Fenster.

Weitere Uebergaenge: `Verwaltung › Tickets (Deprecated)` (fuer tomedo ausgeblendet) ·
`Verwaltung › Privat / BG › Privatrechnungen` neben `Privatabrechnung` (Uebergangsphase zwischen
alter und neuer Ansicht; das Kuerzel `⌥⌃A` folgt der aktiven Ansicht) · `Aktion › Warenausgabe`
neben `Warenausgabe (neu)` · `Verwaltung › KV › Budgetübersicht` (frueher „RLV") ·
`Verwaltung › KI-Assistenten ›` (frueher „Sprechstunden-Assistent").

## 5 · Rechte und Menuesichtbarkeit

- **Admin ist ein Haekchen am Nutzer** (Spalte „Admin" in `Admin › Nutzerverwaltung › Nutzer`),
  kein Recht und keine Gruppe.
- **Das Menue `Admin`** erscheint fuer Admins und fuer jeden Nutzer, dem mindestens ein
  standardmaessig Admins vorbehaltenes Fenster freigegeben ist — dann **vollstaendig**
  **[ungeprueft]**. Einzelne Eintraege blendet tomedo nicht je Recht aus.
- **Fensterrechte greifen beim Oeffnen.** Ein Fenster ohne Recht schliesst sich sofort mit
  „Der eingeloggte Nutzer hat nicht das Recht für das Admin/Verwaltungsfenster.
  Administratoren können Nutzerrechte im Menüpunkt Admin -> Nutzer setzen." Gesetzt werden die
  Rechte aber in `Admin › Praxisorganisation › Rechteverwaltung`, nicht unter „Nutzer". Beim
  Nutzerwechsel schliesst tomedo offene Fenster, fuer die der neue Nutzer kein Recht hat.
- **Rechteverwaltung**: links die Rechtetypen (z. B. „den Menüpunkt Admin -> Nutzerverwaltung
  aufrufen", objektbezogen je Karteieintragstyp, Formulartyp, Statistik, Aufgabenvorlage …),
  rechts die Rechte. Ein Recht gilt fuer eine Kombination aus **Nutzer oder Nutzergruppe** und
  **Arbeitsplatz oder Arbeitsplatzgruppe**, jeweils auch verneint. Ohne eigenes Recht gilt die
  Voreinstellung des Rechtetyps („alle", „nur Admins", „nur Leistungserbringer", „nur
  Vertragsärzte"). Das erste Recht schraenkt bei Voreinstellung „alle" ein und erweitert bei
  „nur Admins". Admins duerfen immer. Die Liste der Rechtetypen kommt vom Server.
- **Patientenzugriffsprofile** (`Admin › Praxisorganisation`) steuern, **welche Patienten**
  sichtbar sind bzw. welche Kartei sich oeffnen laesst (je Nutzer, Nutzergruppe, Betriebsstaette;
  am Patienten „Generelles Verbot" oder „Karteiverbot"), nicht Menues oder Fenster. Das Recht
  „Zugriffsrechte ignorieren" uebersteuert sie.
- **Meiste Ausblendungen sind keine Rechte**, sondern Land, Fachrichtung (Dental), Module (z. B.
  CRM) und Systemeinstellungen. Ein Menue-Dump zweier Praxen ist deshalb nur bedingt vergleichbar.

## 6 · Menueanpassung „ausgeblendet…"

Seit 08/2026 kann eine Praxis einzelne Menueeintraege ausblenden. Ist die Funktion
eingeschaltet (Fachgruppen-Assistent unter „Erste Schritte", z. B. Psychotherapie-
Vorkonfiguration „Nicht benötigte Menüeinträge ausblendbar machen"), bekommt jedes Menue am Ende
den Eintrag **„ausgeblendet…"**: darin stehen die ausgeblendeten Eintraege (weiter nutzbar) und
**„bearbeiten…"** (Fenster „Menüeinträge ausblenden", Haken „sichtbar"). Die Auswahl gilt
**praxisweit**, an anderen Arbeitsplaetzen nach einem Neustart. Formular- und Arztbrief-Menue
sind ausgenommen. Wer den Editor bedienen darf, ist am Arbeitsplatz nicht eingeschraenkt; ob der
Server das begrenzt, ist offen.

Folge fuer Anleitungen und Dumps: Ein „fehlender" Eintrag liegt vielleicht nur unter
„ausgeblendet…".

## 7 · Einstellungen `⌘,`

Fenster „Einstellungen" mit Suchfeld und drei Gruppen:

| Gruppe | Wer sieht sie | Gespeichert | Bereiche (Deutschland) |
|---|---|---|---|
| **Nutzer** | alle | je Nutzer | Grundeinstellungen · Anmeldung · Sichtbarkeit · Sonstiges |
| **Arbeitsplatz** | Admins und Nutzer mit dem Recht, Arbeitsplatz-Einstellungen zu bearbeiten | je Rechner (auf den Server sicherbar) | Grundeinstellungen (u. a. Abschnitt **„Steuerung von außen"**, `references/scriptability.md` § 5a) · Kartenlesegerät · GDT-Import · HZV · Karteieinträge · Druckprofile · Brief/Fax/Mail · CSV-Import/Export · Labor Zahntechnik · Extern · Bildarchiv · Telefon · Kiosk · Warteschlange · Kalender · Warenwirtschaft · Abrechnung · Sonstiges |
| **Praxis** | nur Admins | praxisweit (Systemeinstellungen) | Tagesliste · Kartei · Besuch · Patientendetails · Mediks · Kalender · Statistik · Abrechnung · Fall-Einstellungen · Befunde · HZV · Diagnosen · DMP/eDoku · KRM · Brief/Fax/Tel · E-Mail · KIM-Dienste · Labor · Labor Zahntechnik · Kompaktansicht · Protokollo · **Login & Sicherheit** (u. a. Login-/Logout-Skripte) · Warenwirtschaft · Datenschutz · Sonstiges |

Einzelne Bereiche erscheinen nur mit passendem Modul; Schweiz und Oesterreich haben kuerzere
Listen. **Abgrenzung:** `Einstellungen` = Nutzer, Rechner **und** praxisweite Schalter;
`Admin` = Stammdaten, Kataloge, Vorlagen, Rechte und Verwaltungsfenster.

### Ergaenzungen (Fassung 1.6)

- **KI praxisweit an/aus:** Einstellungen › Praxis › Datenschutz, Schalter „tomedo Intelligence nutzen“. Die
  Registrierung fuer den KI-Dienst laeuft ueber „Ueber tomedo“. Das KI-Cockpit (Budget, Modelle) ist zollsoft
  vorbehalten. **[ungeprüft]**
- **KarteiChat** hat keinen eigenen Menueeintrag; **Format › LLM-Textgenerator** ist standardmaessig ausgeblendet
  (Menueanpassung, Abschnitt 6). **[ungeprüft]**
- **Marker:** Kartei-Menue Patient › Marker; Arbeitsplatz-Einstellung „keine Aktualisierung von Markern an diesem
  Arbeitsplatz“; Fenster „Markeraktualisierung“ fuer die Vorberechnung (Skill `tomedo-marker`). **[ungeprüft]**
- **Patientenformulare:** Fenster „Patientenformular-Einstellungen“; Formular-Inbox mit den Reitern „Eingereicht“
  und „Angefordert“ (Skill `tomedo-patientenformulare`). **[ungeprüft]**

## 8 · Tastenkuerzel (Ergaenzung zu SKILL.md Merkregel 2)

| Menue | Kuerzel |
|---|---|
| tomedo | `⌥⌘I` Über tomedo · `⌘,` Einstellungen |
| Verwaltung | `⌃⇧P` Patientenübersicht (nur wenn eingeschaltet) · `⌘L` Tagesliste · `⌃⇧I` Inbox · `⌃⇧E` E-Mail / KIM E-Mail · `⌃⇧B` DaMe-Nachrichten (AT) · `⌃⇧N` Nachrichten · `⌃⇧A` Aufgaben · `⌥⌘K` Kalender · `⇧⌘K` Kassenbuch · `⌥⌘S` Statistiken · `⌥⌃A` Privatabrechnung bzw. Privatrechnungen |
| Aktion | `⇧⌘N` Neue Nachricht… · `⇧⌘E` Neue Erinnerung… · `⇧⌘T` Neue Aufgabe… · `⌃⌥T` Neuer Termin (ohne Patient) · `⌃⌥⌘D` Leseaufforderungen/Dokumente · `⌃⌘W` Warenausgabe **und** Gruppenbehandlung |
| Formular | `⌃⌥⌘R/B/G` Rotes/Blaues/Grünes Rezept · `⌃⌥⇧⌘R/G/B` dieselben „(direkt)" · je nach Formularbestand `⌥⌘A` AU, `⌥⌘R` Rezept, `⌥⌘Ü` Überweisung, `⌥⇧⌘S` Sehhilfeverordnung, `⌃⌥⌘A` Private AU, `⌃⌥⌘Ü` Überweisung privat, `⌃⌥⌘K` Körperstempel |
| Patient (Tagesliste) | `⇧⌘F` Patient finden · `⌥⌘N` Neuer Patient · `⌘D` Patientendetails · `⌘K` Kartei · `⌃⌘M` Medikamentenverordnung · `⇧⌘B` BMP · `⌃⌥⌘C` Medizinische CAVE · `⌃⌥⌘T` Neuer Termin · `⌃⌘T` Terminübersicht · `⌃⌥⌘L` Laborwerteverlauf · `⌥⌘←`/`⌥⌘→` Nächstes ToDo / Aktuelles ToDo zurückschieben · `⌥⌘E` Besuchsende setzen · `⇧⌘D`/`⇧⌘A` Auf Dokumentiert/Abgerechnet setzen/löschen |
| Patient (Kartei) | wie oben, dazu `⌘K` Kommandozeile fokussieren · `⇧⌘P` Kartei drucken · `⇧⌘U` Kartei exportieren · `⇧⌘2` Karteieintrag duplizieren · `⌘E` Karteieintrag extern öffnen · `⌃⇧⌘M` Marker · `⌃⌥⌘I` Impfungen · `⌥⌘L` Zur Tagesliste hinzufügen |
| Hilfe | `⌘?` Hilfe zum aktuellen Fenster · `⌘ß` Teamviewer starten **und** status.tomedo.de · `⌥ Leertaste` tomedo-Suche |

`⌘K` heisst also je nach Fenster „Kartei oeffnen" (Tagesliste) oder „Kommandozeile
fokussieren" (Kartei).

## 9 · Bekannte Luecken (nicht erhoben — nicht raten)

1. **Kontextmenues** (Rechtsklick in Kartei, Tagesliste, Kalender) — oft der eigentliche
   Arbeitsweg der Nutzer, per Menueleisten-Dump nicht erreichbar.
2. **Verwaltungsfenster-Innenleben** — fuer die meisten Fenster nur Titel und Zweck erfasst.
   Guenstigster Einstieg: `Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht` (zeigt interne
   Fensterbezeichnungen, keine Menuepfade).
3. **Gekuerzte Untermenues** — Auto-Dump begrenzt auf 12 Eintraege je Untermenue
   (`Custom-Formulare` +78, `Arztbrief` +49, `KV` +36, `Patientenformulare` +33).
4. **Weitere Rollen** — im Dump erfasst sind genau zwei Zustaende (ohne/mit Adminrecht). Wie
   Rollen wirken, steht in § 5; ein Dump fuer eine typische MFA-Rolle fehlt weiter.
5. **Fenstertitel weichen vom Menuetext ab**, z. B. Menue „Aktionsketten" → Fenster „Verwaltung
   Aktionsketten", Menue „Statistikverwaltung" → „Verwaltung - Statistikabfragen", Menue
   „Skripte (Python- und AppleScripts)" → „Skriptverwaltung", Menue „Nutzergruppen" →
   „Verwaltung der Nutzergruppen".

Frueher offen, jetzt geklaert: `Skripte (Python- und AppleScripts)` (`references/scriptability.md`
§ 3), `API-Verwaltung` (Freigabe externer Partner-Software fuer die **Server-API** mit Lese- und
**Schreib**rechten je Ressource, Partnergruppen, installierbare Vorlagen, Schalter „Partner darf
API verwenden"; die Annahme „tomedo hat kein Schreib-API" gilt nur fuer AppleScript), `Urlaubs-
und Sperrtagesverwaltung` (jetzt Kalenderverwaltungen › Sperrtage, § 3), `Einstellungen ⌘,` (§ 7).

## 10 · Erhebung wiederholen

```bash
osascript dump_menus.applescript          # alle Menues, Untermenues auf 12 gekuerzt
osascript dump_menus.applescript 0        # vollstaendig, ohne Kuerzung
osascript dump_menus.applescript 12 Verwaltung Admin   # nur bestimmte Menues
```

Nach jedem tomedo-Update sinnvoll, weil Pfade umziehen. Das Werkzeug ist rein lesend und
ueberspringt `Fenster` im Auto-Modus (PHI). Ist die Menueanpassung eingeschaltet, auch die
Untermenues „ausgeblendet…" mitnehmen. Rohdumps und Erhebungswerkzeug liegen bewusst
**ausserhalb jedes Git-Repos**, weil Vorlagenlisten Klinik-, Kollegen- und Vorlagennamen
tragen.
