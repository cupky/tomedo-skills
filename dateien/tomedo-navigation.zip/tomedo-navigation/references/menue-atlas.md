# Menue-Atlas tomedo v1.169.0.21

Quelle: Accessibility-Auslesung der Menueleiste der laufenden Instanz (zwei Dumps derselben
Instanz: ohne und mit Adminrecht). Werkzeug `dump_menus.applescript`, rein lesend.

---

## 1 · Ordnungslogik aller Menues

| Menue | Rolle | Merkregel |
|---|---|---|
| `tomedo` | App + Infrastruktur: `Einstellungen ⌘,`, `Serveradresse aendern`, `Server-Tools Webinterface`, Logs | Alles ueber *das Programm* |
| `Bearbeiten` | Text: Suchen/Ersetzen, Rechtschreibung, Apple-`Schreibtools` | macOS-Standard + Textwerkzeuge |
| `Format` | Schrift/Absatz im Brief- und Karteitext | nur beim Schreiben relevant |
| `Verwaltung` | Listen und Verwaltungsfenster **oeffnen** | „Ich will eine Uebersicht" |
| `Formular` | Formulare/Vordrucke **drucken** im Patientenkontext | „Ich will ein Vordruck-Dokument" |
| `Aktion` | Neue Objekte **anlegen** im Patientenkontext | „Ich will etwas erzeugen" |
| `Panel` | Seiten-/Dock-Panels ein- und ausblenden | „Ich will ein Dauer-Fenster daneben" |
| `Fenster` | macOS-Fensterverwaltung + Liste der offenen Fenster | ⚠ enthaelt PHI |
| `Hilfe` | Handbuch, Campus, Forum, **Logs**, **Hilfswerkzeuge** | Support + Diagnose |
| `Admin` | Konfiguration des Systems | „Ich will festlegen, wie tomedo arbeitet" (nur mit Adminrecht sichtbar) |

## 2 · Pflegeort → Org-Skill

Die wichtigste Tabelle fuer Skills, die erklaeren sollen, **wo** etwas eingerichtet wird.

| Pfad unter `Admin` | Zustaendiger Skill |
|---|---|
| `Kommandos` | `tomedo-kommandos` — Pflegeort der Briefkommandos/Platzhalter |
| `Aktionsketten ›` (Aktionsketten · -Ausloeser · -Bedingungen · -Fragen) | `tomedo-aktionsketten` — genau die vier Objekttypen des Skills, 1:1 |
| `Patientenformulare` · `Webformulare` · `Geraeteeinstellungen › arzt-direkt` · `arzt-direkt ›` (Instanzkonten, Nutzerkonten, Automatisierte Nachrichten, Nachrichtenvorlagen) | `tomedo-patientenformulare` — Formularpflege **und** Ausspielkanal |
| `Textbausteine/Makros` · `Marker` · `Karteieintragstypen` | `tomedo-textbausteine` |
| `Statistikverwaltung` · `Cockpit 3.0/4.0` | `tomedo-statistik-hql`, `tomedo-metabase-migration` |
| `Vorlagen (Briefe, Rechnungen, PDF-Formulare)` · `Formulare` | `tomedo-kommandos` (Briefvorlagen und Platzhalter) |
| `KV (EBM) ›` · `Privat (GOAe)/BG (UV-GOAe) ›` | `tomedo-statistik-hql` (Leistungsauswertung) |
| `Nutzerverwaltung ›` · `Praxisorganisation › Rechteverwaltung` · `Patientenzugriffsprofile` | Rechte-/Rollenfragen, Service-Nutzer-Design |
| `Skripte (Python- und AppleScripts)` · `API-Verwaltung` · `Menue-Buttons` | Automatisierung → `references/scriptability.md` |
| `Kalender › Urlaubs- und Sperrtagestypen` / `Urlaubs- und Sperrtagesverwaltung` | Sperrtag-Themen (lesend: `tomedo-statistik-hql`, `terminkalendertag`) |

Unter `Verwaltung` (nicht `Admin`) liegen dagegen die **Arbeits**-Fenster, u.a.:
`Textbausteine/Makros` (zweiter Zugang), `Verwaltung Nachrichtenvorlagen`,
`Statistiken ⌘⌥S`, `Auto-Statistik-Export-Verwaltung`, `Gespeicherte Statistikergebnisse`,
`Cockpit`, `Favoritenlisten` (ICD-10/Hausdiagnosen, EBM, EBM-Zusatzangaben nach Art, GOAe,
UV-GOAe, KV-Schein), `Sprechstunden-Assistent › KI-Assistenten-Verwaltung`
(Konfigurationsort der KI-Assistenten → `tomedo-karteichat-prompting`), `KV ›` (KV-Abrechnung,
Budgetrechner, Chroniker-Pruefung, RLV, EBM-Fachgruppendurchschnitt).

Zwei getrennte Wege bei Formularen: `Formular › Patientenformulare` **druckt**,
`Aktion › Patientenformulare anfordern` **fordert beim Patienten an**.


### Pflegeort Terminerinnerungen — Stufen und Kanaele (Realbefund 2026-08-26)

Pflegeort: **Kalender → Terminerinnerungen**. Datenmodell dahinter:

```
terminerinnerungplan      Plan: aktiv, → Terminarten, → Kalender
  └─ terminerinnerungart      Stufe: listenposition, min/maxdaysbeforetermin,
      │                              emailvorlage_ident, smsvorlage_ident
      └─ terminerinnerungartmodus  Kanal: priority, inactive, type
terminerinnerung          Versandprotokoll: status, errormsg, senddate, → email/smsnachricht
```

**Email und SMS in einer Stufe sind eine Kaskade, kein Parallelversand.** Die gemeinsame Belegung
von `emailvorlage_ident` und `smsvorlage_ident` in einer Stufe bedeutet Kanalpriorisierung: der
zweite Kanal greift nur, wenn der hoeher priorisierte scheitert (`terminerinnerungartmodus.priority`).
Aus einer belegten Feldkombination darf **nicht** auf Versandverhalten geschlossen werden — immer
die Modus-/Prioritaetstabelle mitlesen.

**Parallelversand braucht je eine Stufe pro Kanal.** Zwei Stufen mit identischem Tagesfenster feuern
beide (produktiv belegt an der Referenzinstallation 2026-08-26). Damit sind Muster baubar, die das System nicht als eigenes
Feature anbietet:

- **Terminbestaetigung bei Buchung** = Stufe mit sehr grosser Vorlaufzeit (`maxdaysbeforetermin`
  groesser als der laengste Buchungsvorlauf). Achtung Randfall: liegt ein Termin **jenseits** des
  Fensters, wird nicht bei Buchung bestaetigt, sondern erst beim Hineinrutschen — also ggf. Wochen
  spaeter. Fenster darum grosszuegig setzen (365 Tage statt 100).
- **Mehrkanalige Bestaetigung** = zwei Stufen mit demselben Fenster, eine je Kanal.

Dies ist zugleich der Weg, Kommunikation an Terminereignisse zu haengen, **ohne** Aktionskette —
und der einzige, der bei serverseitig erzeugten Objekten ueberhaupt funktioniert
(Skill `tomedo-aktionsketten`: „Kein Arbeitsplatz, keine Kette").

## 3 · Struktur des Menues `Admin` (vollstaendig erfasst)

| Block | Inhalt |
|---|---|
| **Nutzerverwaltung** | Nutzer · Nutzergruppen |
| **Praxisorganisation** | Betriebsstaetten · ToDos · ToDo-Ketten · Arbeitsplaetze/-gruppen · Raumverwaltung · Betten/Bettenstationen · Praxisnotruf · Rechteverwaltung · Patienten nach DSGVO suchen und loeschen · Patientenzugriffsprofile · Servernachrichtenverwaltung · Zertifikateverwaltung |
| **Geraeteeinstellungen** | Drucker · Seriell · GDT · Labor · TI-Verwaltung · arzt-direkt · Zahlungsterminals · tomedo.LINK |
| **Inhalts-/Vorlagenpflege** | Vorlagen (Briefe, Rechnungen, PDF-Formulare) · Formulare · Patientenformulare · Karteieintragstypen · Kommandos · Textbausteine/Makros · Marker · Skripte (Python- und AppleScripts) · Webformulare · Menue-Buttons · Favoritenlisten |
| **Aktionsketten** | Aktionsketten · -Ausloeser · -Bedingungen · -Fragen |
| **Kalender** | Kalenderverwaltungen · *Alte Kalenderverwaltungsfenster* → Kalender · Kalender-Favoriten · Lokalitaeten · Loeschungs-/Verschiebungsgruende · Ressourcen · Terminarten · Terminlimits · Urlaubs- und Sperrtagestypen · Urlaubs- und Sperrtagesverwaltung · Schemaverwaltung · Terminsuche-/Terminkettensuche-Favoriten · Online-Terminkalender (1+2) · Patientensperrung · Automatische Patientensperrung · Terminerinnerung · Terminaenderungsbenachrichtigungen |
| **arzt-direkt** | Instanzkonten · Nutzerkonten · Automatisierte Nachrichten · Nachrichtenvorlagen (arzt-direkt) |
| **Schnittstellen** | API-Verwaltung · API-Partner-Chat-Schnellantworten · Karteiversandprofile · E-Mail-/KIM-Konten · E-Mail-/KIM-Vorlagen · Kontenverwaltung E-Porto/Internetmarke · Verwaltung Nachrichtenvorlagen · SMS-Vorlagen · ePA |
| **Abrechnung/Kataloge** | Frueherkennungsverwaltung · Abrechnungsvorschlaege · Leistungszaehler · Privat (GOAe)/BG (UV-GOAe) mit Katalogen, Sachkosten, Begruendungen, Rabatten, Rechnungskreisen/Kostenstellen, Rechnungstypen, Umsatzsteuerfavoriten · KV (EBM) mit KV-Abrechnung, Strukturzuschlag, EBM-Katalog, Zifferneinschraenkungen, Heilmittel-Katalog, OPS-Katalog, QZV (pro Nutzer/Betriebsstaette/praxisweit), KBV-Kodierregelwerk · Delegierte Leistungen · Heilmittelpositionen · DALE-UV |
| **Diagnosen** | ICD10-Katalog · ICD10-Auto-Ersetzungen · ICPC2-Katalog |
| **Auswertung** | Statistikverwaltung · Cockpit (1.0/2.0 veraltet, 3.0, 4.0) |
| **Sonstiges** | Tausch-Center · Server-Tools Webinterface · Laboreinstellungen · Warenwirtschaft/-bestellung |

## 4 · Migrationsspuren — veraltete Pfade erkennen

tomedo beschriftet Altlasten selbst und laesst sie als **inaktive** Wegweiser stehen:

- `Aktion › Fokus Tagesliste (jetzt unter Verwaltung)` → korrekt `Verwaltung › Tagesliste ⌘L`
- `Aktion › Kalender (jetzt unter Verwaltung)` → korrekt `Verwaltung › Kalender ⌘⌥K`
- `Admin › ICD-Favoriten (jetzt oben unter Favoritenlisten)` — reiner Wegweiser
- `Admin › KV (EBM) › Zusatzangaben (jetzt bei Favoritenlisten)`
- `Admin › Kalender › Alte Kalenderverwaltungsfenster ›` — der **gesamte** Kalender-
  Konfigurationszweig (inkl. `Terminarten`, `Urlaubs- und Sperrtagestypen`) liegt in einem
  als „alt" markierten Untermenue; der neue Weg heisst `Kalenderverwaltungen`.
  **Beide existieren parallel** — bei Anleitungen den neuen nennen, den alten als Fussnote.
- `Admin › Cockpit › Cockpit 1.0 / 2.0 (veraltet)` neben `3.0` und `4.0`

## 5 · Bekannte Luecken (nicht erhoben — nicht raten)

1. **`Einstellungen ⌘,`** — Dialoginneres nicht erfasst. Nach `Admin` der groesste
   verbleibende Block. Abgrenzung: `Admin` = systemweit, `Einstellungen` = Arbeitsplatz/Nutzer.
2. **Kontextmenues** (Rechtsklick in Kartei, Tagesliste, Kalender) — oft der eigentliche
   Arbeitsweg der Nutzer, per Menueleisten-Dump nicht erreichbar.
3. **Verwaltungsfenster-Innenleben** — die Fensterliste ist erfasst, ihre Bedienelemente nicht.
   Guenstigster Einstieg: `Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht`.
4. **Gekuerzte Untermenues** — Auto-Dump begrenzt auf 12 Eintraege je Untermenue
   (`Custom-Formulare` +78, `Arztbrief` +49, `KV` +36, `Patientenformulare` +33).
   Der **Admin-Dump ist vollstaendig**.
5. **Weitere Rollen** — erfasst sind genau zwei Zustaende (ohne/mit Adminrecht). Ein Dump
   fuer eine typische MFA-Rolle wuerde zeigen, was diese Nutzer *nicht* sehen.
6. **Drei Menueeintraege, deren Funktion unbestaetigt ist:** `Skripte (Python- und
   AppleScripts)` (Hosting/Ausfuehrung — teilweise geklaert, s. `scriptability.md`),
   `API-Verwaltung` (die verbreitete Annahme „tomedo hat kein Schreib-API" ist damit
   mindestens nachzupruefen), `Kalender › Urlaubs- und Sperrtagesverwaltung`.

## 6 · Erhebung wiederholen

```bash
osascript dump_menus.applescript          # alle Menues, Untermenues auf 12 gekuerzt
osascript dump_menus.applescript 0        # vollstaendig, ohne Kuerzung
osascript dump_menus.applescript 12 Verwaltung Admin   # nur bestimmte Menues
```

Nach jedem tomedo-Update sinnvoll, weil Pfade umziehen. Das Werkzeug ist rein lesend und
ueberspringt `Fenster` im Auto-Modus (PHI). Rohdumps und Erhebungswerkzeug liegen bewusst
**ausserhalb jedes Git-Repos**, weil Vorlagenlisten Klinik-, Kollegen- und Vorlagennamen
tragen.
