---
name: tomedo-navigation
description: >-
  Belegte Navigationswege, Pflegeorte und Automatisierungsgrenzen der tomedo-Oberflaeche. Verwende
  diesen Skill IMMER wenn gefragt wird, WO in tomedo etwas eingestellt, gepflegt, gefunden oder
  geoeffnet wird — "wo stelle ich X ein", "wo finde ich Y", "welches Menue", "Pflegeort", "Admin-
  Bereich", "Tastenkuerzel", "Verwaltungsfenster", "Menuepfad", "Einstellungen vs. Admin". Auch
  bei: Klickstrecke oder Schulungsunterlage schreiben, Menuepfad pruefen, Menuesichtbarkeit je
  Rolle, Sperrtage- und Kalenderverwaltung finden. Ebenso bei tomedo-Automatisierung von aussen:
  AppleScript, tomedo.sdef, call aktionskette, call statistik, Ereignis-Hooks, Toolbar-Buttons,
  Skript-Platzhalter, tomedo-Deeplinks, HTTP-Steuerung, API-Verwaltung. Und beim LLM-Aufruf
  aus tomedo: llmservice-Endpunkt, userIdent ermitteln, Modellname setzen, Prompt per Env-Variable, HTTP 422
  Unbekanntes Modell, Budget per cost. NICHT fuer die Konfiguration selbst (→ tomedo-aktionsketten,
  tomedo-kommandos, tomedo-statistik-hql, tomedo-marker).
metadata:
  version: 1.6
---

# tomedo-Navigation, Pflegeorte und Scriptability

Erhoben per Accessibility-Auslesung der laufenden Instanz (nicht aus der Doku),
tomedo **v1.169.0.21** (`com.zollsoft.tomedo-macOS`), Stand 07–08/2026.
Bundle-Analyse aus `tomedo.app` und dem lokalen Core-Data-Cache.
**Seit Fassung 1.5 systematisch ueberprueft** (Oktober 2026):
Menues, Kuerzel, Rechte, Einstellungen, AppleScript, Skripte, Deeplinks, HTTP-Steuerung. Wo sich
tomedo seit der Erhebung an v1.169 geaendert hat (vor allem Kalender und Menueanpassung), gilt der
neuere Stand. **[ungeprueft]** = noch nicht in der Oberflaeche nachgestellt — vor dem Einsatz an
einer Testakte pruefen.

> **Drei Vorbehalte, die fuer jede Auskunft gelten:**
> 1. **Rollenabhaengig.** Das Top-Level-Menue `Admin` erscheint fuer Nutzer mit dem
>    Haekchen „Admin" (Admin › Nutzerverwaltung › Nutzer) **und** fuer jeden Nutzer, dem in
>    der Rechteverwaltung mindestens ein sonst Admins vorbehaltenes Fenster freigegeben ist —
>    dann sieht er das **ganze** Admin-Menue **[ungeprueft]**. Einzelne Eintraege werden nicht
>    je Recht ausgeblendet; gesperrt wird erst beim Oeffnen: das Fenster schliesst sich sofort
>    wieder mit der Meldung „Der eingeloggte Nutzer hat nicht das Recht für das
>    Admin/Verwaltungsfenster. …". Die meisten ausgeblendeten Eintraege haengen nicht an
>    Rechten, sondern an Land, Fachrichtung, Modulen und Systemeinstellungen.
> 2. **Kontextabhaengig.** Viele Eintraege sind nur mit selektiertem Patienten oder
>    offener Kartei aktiv. `(inaktiv)` heisst „hier nicht verfuegbar", nicht
>    „existiert nicht". Die Menues `Patient` und `Eintrag` erscheinen nur, wenn
>    Tagesliste, Kartei oder Patientendetails im Vordergrund sind.
> 3. **Praxisweit umgebaut.** Seit 08/2026 kann eine Praxis Menueeintraege ausblenden
>    (Menueanpassung). Sie verschwinden nicht, sondern wandern in ein Untermenue
>    **„ausgeblendet…"** am Ende des jeweiligen Menues (darin „bearbeiten…"). Fehlt ein
>    Eintrag, zuerst dort nachsehen.

## Referenzdateien (bei Bedarf laden)

| Datei | Inhalt |
|---|---|
| `references/menue-atlas.md` | Ordnungslogik aller Menues, vollstaendige `Admin`-Struktur, Kalenderverwaltung, Pflegeort-Tabelle je Skill, Migrationsspuren, Rechte und Menuesichtbarkeit, Bereiche der Einstellungen, Tastenkuerzel, bekannte Luecken |
| `references/scriptability.md` | `tomedo.sdef`-Kommandoinventar, Skript-Feature (Aktivierung je Rechner, Intervall, Start, Login/Logout, Symbolleisten, Ausloeser, Platzhalter), Deeplinks (alle 17 Ziele), Steuerung von aussen per HTTP, was **nicht** geht, Sicherheitsbefunde |
| `references/applescript-rezeptbuch.md` | LLM-Aufruf per AppleScript: `llmservice`-Endpunktschema, `userIdent`-Ermittlung, Kartei-Uebergabe per Briefkommando, Env-Variablen-Muster, Rueckkanal, Fehlerdiagnose inkl. HTTP 422, Budget ueber `cost`, Pruefliste |
| `references/llm-toolebene.md` | Der dritte Automatisierungskanal: der Kartei-Chat als Agent mit Werkzeugen — warum hier nicht der Aufrufer bestimmt, was ausgeführt wird, und welche Pflegeorte es dafür gibt (und welche nicht) |

## Die vier Merkregeln

**1 · Menue nach Handlungsabsicht.**

| Menue | Absicht |
|---|---|
| `Verwaltung` | „Ich will eine **Uebersicht**" — Listen und Verwaltungsfenster oeffnen (der Haupt-Hub) |
| `Aktion` | „Ich will **etwas erzeugen**" — neue Objekte im Patientenkontext |
| `Format` | Textauszeichnung — **und, unerwartet, der `LLM-Textgenerator`** (unterhalb `Schrift` und `Text`; nur sichtbar, wenn die Praxis ihn per Systemeinstellung einschaltet) |
| `Formular` | „Ich will ein **Vordruck-Dokument**" — Formulare oeffnen im Patientenkontext |
| `Patient` / `Eintrag` | erscheinen nur mit Tagesliste, Kartei oder Patientendetails im Vordergrund; `Patient` traegt die meisten Patientenkuerzel (`⌘K` Kartei, `⌘D` Patientendetails, `⌃⌥⌘T` Neuer Termin, `⌃⌘M` Medikamentenverordnung, `⇧⌘B` BMP) |
| `Panel` | „Ich will ein **Dauer-Fenster daneben**" |
| `Admin` | „Ich will **festlegen, wie tomedo arbeitet**" — Kataloge, Vorlagen, Rechte, Automatisierung |
| `tomedo › Einstellungen ⌘,` | drei Gruppen: **Nutzer** (alle) · **Arbeitsplatz** (Admins und Nutzer mit Recht dafuer) · **Praxis** (nur Admins, praxisweit) |

**2 · Das Kuerzel-Muster** — die halbe Navigation in einem Satz:

- **`⇧⌃` + Buchstabe = Liste OEFFNEN** (alle liegen unter `Verwaltung`) · `⇧⌃P` Patientenuebersicht ·
  `⇧⌃I` Inbox · `⇧⌃N` Nachrichten · `⇧⌃A` Aufgaben · `⇧⌃E` E-Mail / KIM E-Mail
- **Die drei Neu-Befehle im Menue `Aktion` liegen auf `⌘⇧`** · `⌘⇧N` Neue Nachricht… ·
  `⌘⇧E` Neue Erinnerung… · `⌘⇧T` Neue Aufgabe… — als allgemeine Regel taugt `⌘⇧` aber nicht:
  `⌘⇧K` oeffnet das Kassenbuch (eine Liste), `⇧⌘F` Patient finden, `⇧⌘B` BMP, `⇧⌘P` Kartei drucken.

Weitere belegte Kuerzel: `⌘L` Tagesliste · `⌘⌥K` Kalender · `⌘⌥S` Statistiken ·
`⌘⇧K` Kassenbuch · `⌥⌃A` Privatabrechnung · `⌥⌃T` Neuer Termin (ohne Patient) ·
`⌘⌥A` Arbeitsunfaehigkeit (1/E) · `⌘⌥⌃R/B/G` Rotes/Blaues/Gruenes Rezept ·
`⌥⌘I` Ueber tomedo.

Einschraenkungen: `⇧⌃P` gibt es nur, wenn die Patientenuebersicht per Systemeinstellung
eingeschaltet ist; `⇧⌃I` fehlt, wenn die Inbox als Panel laeuft; `⌘⇧K` nur mit aktiviertem
Kassenbuch. `⌥⌃A` wandert: je nach Ansicht und Recht auf Privatabrechnung oder Privatrechnungen,
in der Schweiz auf Abrechnung. `⌘⌥A` und viele Formular-Kuerzel (z. B. `⌥⌘Ü` Ueberweisung)
haengen an den Formularen der Installation. Doppelt belegt: `⌃⌘W` (Warenausgabe und
Gruppenbehandlung), `⌘ß` (Teamviewer starten und status.tomedo.de). Vollstaendige Liste:
`references/menue-atlas.md` § 8.

**3 · Die Pflegeorte liegen fast alle unter `Admin`, nicht unter `Verwaltung`.**
Wer erklaeren soll, *wo etwas eingerichtet wird*, sucht in `Admin`. Die vollstaendige
Zuordnung Admin-Pfad → Org-Skill steht in `references/menue-atlas.md`.

**4 · Klammerzusatz = umgezogen.** Findet sich „jetzt …", „alte …" oder „(veraltet)",
ist der Pfad umgezogen. Die vier „(jetzt …)"-Eintraege stehen als **inaktive** Wegweiser
(`Aktion › Kalender (jetzt unter Verwaltung)`); „Cockpit 1.0/2.0 (veraltet)" und
„Alte Kalenderverwaltungsfenster" sind dagegen noch **aktiv**. Anleitungen, die den alten
Pfad nennen, sind veraltet. **Gegenprobe lohnt bei jeder Pfadangabe in einem Skill.**
Groesster Umbau 2026: Terminarten, Sperrtage, Sperrtagstypen, Terminerinnerungen,
Ressourcen und Patientensperrung sind keine Menueeintraege mehr, sondern Gruppen im Fenster
`Admin › Kalender › Kalenderverwaltungen` (Stand 10/2026 **[ungeprueft]**; an v1.169 waren die alten
Eintraege noch da; Details `references/menue-atlas.md` § 3).

## Der schnellste Einstieg bei Navigationsfragen

`Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht` — tomedo hat eine **eingebaute**
Liste der Verwaltungsfenster; das Zahnrad je Zeile oeffnet das Fenster. Grenzen: sie zeigt
die **interne Fensterbezeichnung** (z. B. „Skriptverwaltung", „Verwaltung Kalendermodul"),
**keinen Menuepfad und keine Rechte**, und Rechteverwaltung, Patientenzugriffsprofile,
Menue-Buttons und KI-Assistenten-Verwaltung fehlen darin. Dieselbe Liste durchsucht
`Hilfe › tomedo-Suche` (`⌥ Leertaste`).
Fuer Diagnose: `Hilfe › Logs ›` (`tomedo.log öffnen`, `tomedo.extra.log öffnen`, **Loglevels
Feinschaltung**, `plistHistory.log öffnen`).

## Automatisierung: was geht, was nicht

tomedo ist offiziell scriptbar (`NSAppleScriptEnabled = true`, `Resources/tomedo.sdef`) —
ein vom Hersteller vorgesehener Erweiterungspunkt, kategorial etwas anderes als ein
nicht unterstuetzter Direkt-Write in die Datenbank. Das Dictionary ist aber **minimal**:

| Kommando | Wirkung |
|---|---|
| `call aktionskette` | ruft eine Kette per **Kuerzel** auf — **ohne Parameter**, Kuerzel exakt mit Gross-/Kleinschreibung. Braucht eine **offene Kartei** (sonst Hinweis „Es existiert keine geöffnete Kartei.") und nimmt die zuletzt aktive. Kehrt sofort zurueck. Der Hebel. Mit Patient und Werten: URL `tomedo://aktionskette?…` (siehe unten). |
| `call statistik <csv>` | zeigt eine **CSV** im Statistikfenster an (Semikolon, erste Zeile = Spaltennamen). Anzeige-, kein Abfragekanal. |
| `search patient` | oeffnet die Patientensuche mit einem Suchtext (im Kioskmodus wirkungslos) |
| `call number`, `handle … call event` | Telefonie; die `handle`-Kommandos sind der Rueckkanal der Telefon-Clients (Starface, NFON, Agfeo, Swyx, direct/Teamcall), nicht fuer eigene Skripte gedacht |

Kein Kommando liefert dem Skript einen Rueckgabewert. **Kein Kommando erzeugt tomedo-Objekte
direkt** — kein Termin, kein Sperrtag, keine Aufgabe, kein Karteieintrag. Schreibende Wirkung
nur **indirekt** ueber eine Aktionskette. Und: kein Aktionstyp legt einen Termin, Sperrtag oder
Urlaubstag an (Terminsuche (Definiert), Terminsuche (Kette) und Sprechstundenassistent sind
interaktiv) — Ganztags-Abwesenheiten laufen ueber das Arbeitszeitkonto, nicht ueber eine Kette.
Details und die Gegenprobe: `references/scriptability.md`.

**Zwei weitere Wege von aussen** (Details `references/scriptability.md` § 5 und § 5a):

- **Deeplinks** `tomedo://…` — 17 Ziele, darunter `patient#`, `termin#`, `karteieintrag#`,
  `aktionskette?…` und `menu#<Menuetitel>`, das einen beliebigen sichtbaren Menueeintrag
  ausloest. Aus AppleScript per `open location`.
- **Steuerung von aussen per HTTP** — tomedo lauscht auf Port 8070 und startet Ketten ueber
  `/aktionskette?…`. Pflegeort: `Einstellungen › Arbeitsplatz › Grundeinstellungen`,
  Abschnitt „Steuerung von außen" (Modus, Token, freigegebene Adressen; nur Deutschland).

**Drei harte Grenzen, die jede Planung fruehzeitig kennen muss:**

1. `call aktionskette` nimmt **keine** Parameter. Auswege: die URL
   `tomedo://aktionskette?<Kuerzel>&patientident=<ident>&<name>=<wert>#variable` bzw. derselbe
   Aufruf per HTTP (Patient bzw. Besuch und beliebige Werte; Details im Skill
   `tomedo-aktionsketten`), die Aktion „Aktionskette für alle Listeneinträge nacheinander
   auslösen" im Statistik-Ergebnisfenster oder dort „Listeneinträge alle einzeln mit
   (Serien-)AppleScript aufrufen", das jede Spalte als `$[spalte]$` ans Skript gibt.
2. Eine Aktionskette laeuft **am ausloesenden Arbeitsplatz** — UI-Effekte passieren nur dort.
3. **`$[arbeitsplatz]$`** (Kuerzel des dem Rechner zugeordneten Arbeitsplatzes, leer ohne
   Zuordnung) und `$[nutzerkuerzel]$` loesen das Mehrfachausfuehrungs-Problem periodischer
   Skripte. Einfacher: ein Skript nur an dem einen Rechner aktivieren — die Aktivierung gilt
   je Rechner.


### Login-Historie: sichtbar, nicht exportierbar, nicht abfragbar

**Pfad:** Admin › Nutzerverwaltung › Nutzer → Nutzer auswaehlen → Knopf „Login Historie". Fenstertitel „LoginLogout fuer Nutzer: '<Kuerzel>'". Die Daten holt tomedo beim Oeffnen vom Server (eine Aenderungshistorie mit Revisionsnummer, daher die Spalte „Revision"); bei vielen Eintraegen dauert das.

**Angezeigte Spalten:** Login (Zeitstempel), Logout (Zeitstempel, bei offenen Sitzungen leer), Client, Revision. Das Client-Feld traegt drei Angaben in einem String: Rechnername, Hardware-UUID und den Pfad des lokalen Benutzerordners, zum Beispiel `<rechnername> <hardware-uuid> /Users/<benutzer>/Library`.

**Grenzen (alle belegt 2026-08-23):**

- Kein Export, kein Multi-Select, kein Kopieren per Tastatur. Das Fenster gibt nichts heraus.
- **Kein bekannter Tabellenname.** Zwoelf Kandidaten geprueft (`loginlogout`, `nutzerloginlogout`, `loginhistorie`, `anmeldung`, `clientsession`, `serveronlyloginlogout`, `zsloginlogout`, `clientinfo`, `client`, `nutzersitzung`, `logineintrag`, `nutzeranmeldung`) — jeder mit `relation does not exist`.
- Der ZOLLSOFT-DB-Dump enthaelt keine passende Tabelle. `sitzung` ist die **Therapiesitzung** (FK auf `behandlungsfallelement`), nicht die Anmeldesitzung. Das Wort „Lizenz" kommt im Dump nicht vor.
- Im Nutzer stehen nur die letzten Zeitstempel `lastlogin` und `lastlogout` — **Werte, die bei jedem Login bzw. Logout ueberschrieben werden**, ohne Historie und ohne Arbeitsplatzangabe. Die Historie im Fenster liefert der Server aus seiner Aenderungshistorie, nicht aus einer eigenen Tabelle.

**Konsequenz.** Arbeitsplatzbezogene Nutzungsdauern sind nicht auswertbar, obwohl die Daten sichtbar vorliegen. Zwei Wege bleiben:

1. **Supportanfrage beim Hersteller**, wie die Login-Historie aus der Aenderungshistorie abgefragt werden kann. Praezise formulieren („woher kommen die Daten in Admin › Nutzerverwaltung › Nutzer › Login Historie"), nicht als Exportwunsch.
2. **Eigener Heartbeat** ueber das Skript-Feature: `skript` fuehrt `runonstartup`, `runwithtimeinterval`, `timeinterval` (in **Minuten**) und `sourcecode`; der Arbeitsplatz-Platzhalter steht zur Verfuegung. Ein Skript schreibt Arbeitsplatz und Zeitstempel in eine Logdatei; aktiviert wird es an den gewuenschten Rechnern, eine geaenderte Intervallzeit wirkt erst nach einem Neustart von tomedo **[ungeprueft]**. **Ohne Nutzerbezug** — dann ist es keine Leistungs- und Verhaltenskontrolle nach § 87 Abs. 1 Nr. 6 BetrVG, und fuer eine Lizenzfrage wird der Nutzer nicht gebraucht. In eine Datei schreiben, nicht in die Datenbank, sonst verfaelscht der Heartbeat die eigenen Statistiken. Fuer genaue An- und Abmeldezeiten gibt es eigene Login-/Logout-Skripte (`references/scriptability.md` § 3) — die tragen aber den Nutzer.


**Hintergrund-AX neben einem tippenden Nutzer** (belegt 28.09.2026, CKE-Editor): Ein per AX
geöffnetes Einblendmenü fängt Tastendrücke ab, ein `AXPress` auf eine Checkbox holt tomedo
nach vorn, per AX gesetzte einzeilige Textfelder werden nicht gespeichert. Menüaktionen nur
bei `HIDIdleTime` ≥ 8 s und tomedo im Hintergrund. Details:
`references/scriptability.md` § 8.

## Drei Sicherheits- und Datenschutzregeln dieser Erhebung

1. **Menue `Fenster` traegt PHI.** Fenstertitel enthalten Patientendaten (beobachtet:
   `Nachricht bzgl. <patient_id> - <Nachname Vornamen>`; nach aktuellem Stand tragen ueber 45 Fensterarten
   den Patientennamen im Titel, z. B. Mutterpass, Notfalldaten, Krebsregistermeldung). Jedes
   Dump-Werkzeug muss `Fenster` und jede Abfrage von Fenstertiteln ueberspringen oder
   redigieren. AX-Dumps immer auf die Zielperson filtern — ein unfilterter Button-Dump zieht
   den kompletten Mitarbeiter-Roster mit Klarnamen.
2. **Skripttexte sind kein Ort fuer Geheimnisse.** Der Skripttext liegt im
   **Klartext** in der Server-DB *und* im lokalen Cache **jedes** Arbeitsplatzes. Der
   **aufgeloeste** Skripttext — mit eingesetzten Patientendaten — wird bei jedem Lauf
   protokolliert, vermutlich in `tomedo.log` **[ungeprueft]**.
3. **Erhebung rein lesend.** Menues per Accessibility-API abfragen: kein Klick, kein
   `activate`, kein Fokuswechsel. Wer im Produktivsystem klickt, aendert es.

## Wenn ein Pfad nicht belegt ist

Nicht raten. Die Erhebung hat dokumentierte Luecken — Kontextmenues (Rechtsklick), das
Innenleben der meisten Verwaltungsfenster, und je Untermenue maximal 12 Eintraege im
Auto-Dump (`Custom-Formulare` +78, `Arztbrief` +49, `KV` +36, `Patientenformulare` +33).
Die Bereiche von `Einstellungen ⌘,` stehen inzwischen in `references/menue-atlas.md` § 7.
Fehlt ein Pfad: zuerst unter „ausgeblendet…" am Ende des Menues nachsehen (Menueanpassung),
dann im Fenster Kalenderverwaltungen (bei Kalenderthemen), sonst ist die ehrliche Antwort
„nicht erhoben, hier ist der Nachbarpfad" plus der Hinweis auf
`Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht` bzw. `Hilfe › tomedo-Suche`.

---

*Stand 2026-10-22 · Quellen: Menueleisten-Dumps (ohne/mit Adminrecht) v1.169.0.21,
`tomedo.sdef`, `ZSKRIPT`-Bestand (30 Skripte), Deeplink-Pilot 08/2026; ueberarbeitet
im Oktober 2026.*


### Konfigurator als Übersetzer

Wo eine tomedo-Oberfläche eine **Textsyntax erzeugt**, ist sie zugleich das zuverlässigste
Nachschlagewerk für diese Syntax. Statt Keywords aus Foren oder Handbuchfragmenten zu raten:

1. Wegwerf-Objekt anlegen (Textbaustein, Kommando, Aktionskette)
2. **Eine** Option im Dialog setzen, mit OK bestätigen
3. Rohtext im Programmier- bzw. Expertenmodus ablesen
4. Differenz zur Vorfassung ist das gesuchte Keyword

Belegt an der Textbaustein-Makroverwaltung 2026-09-15: sieben unbekannte Optionen wurden so
in einem Durchgang entschlüsselt, darunter drei, die in der Onlinehilfe nicht auftauchen.
Eindeutige Marker als Werte verwenden (`SUFFIXTEST`), damit sie im Rohtext auffindbar sind.

**Grenze:** Was der Dialog **nicht** in den Rohtext schreibt, ist auch nicht per Syntax
steuerbar. Zeichenformatierung erzeugte keinen Zuwachs — sie liegt in der RTF-Ebene und
lässt sich nur im Editor setzen, nicht im generierten Text.

