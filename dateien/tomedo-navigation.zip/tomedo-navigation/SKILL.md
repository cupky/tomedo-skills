---
name: tomedo-navigation
description: >-
  Belegte Navigationswege, Pflegeorte und Automatisierungsgrenzen der tomedo-Oberflaeche. Verwende
  diesen Skill IMMER wenn gefragt wird, WO in tomedo etwas eingestellt, gepflegt, gefunden oder
  geoeffnet wird — "wo stelle ich X ein", "wo finde ich Y", "welches Menue", "Pflegeort", "Admin-
  Bereich", "Tastenkuerzel", "Verwaltungsfenster", "Menuepfad", "Einstellungen vs. Admin". Auch
  bei: Klickstrecke oder Schulungsunterlage schreiben, Menuepfad pruefen, Menuesichtbarkeit je
  Rolle, Sperrtage- und Kalenderverwaltung finden. Ebenso bei tomedo-Automatisierung von aussen:
  AppleScript, tomedo.sdef, call aktionskette, call statistik, Ereignis-Hooks, Toolbar-Buttons,
  Skript-Platzhalter, tomedo-Deeplinks, API-Verwaltung. Und beim LLM-Aufruf aus tomedo:
  llmservice-Endpunkt, userIdent ermitteln, Modellname setzen, Prompt per Env-Variable, HTTP 422
  Unbekanntes Modell, Budget per cost. NICHT fuer die Konfiguration selbst: Aktionsketten baut
  tomedo-aktionsketten, Kommandos tomedo-kommandos, Queries tomedo-statistik-hql.
metadata:
  version: 1.1
---

# tomedo-Navigation, Pflegeorte und Scriptability

Erhoben per Accessibility-Auslesung der laufenden Instanz (nicht aus der Doku),
tomedo **v1.169.0.21** (`com.zollsoft.tomedo-macOS`), Stand 07–08/2026.
Bundle-Analyse aus `tomedo.app` und dem lokalen Core-Data-Cache.

> **Zwei Vorbehalte, die fuer jede Auskunft gelten:**
> 1. **Rollenabhaengig.** Die Menueleiste haengt an den Rechten des eingeloggten Nutzers.
>    Das Top-Level-Menue `Admin` erscheint nur mit Adminberechtigung. Erfasst sind genau
>    zwei Zustaende (ohne / mit Adminrecht) — fuer eine MFA-Rolle fehlt die Erhebung.
> 2. **Kontextabhaengig.** Viele Eintraege sind nur mit selektiertem Patienten oder
>    offener Kartei aktiv. `(inaktiv)` heisst „hier nicht verfuegbar", nicht
>    „existiert nicht".

## Referenzdateien (bei Bedarf laden)

| Datei | Inhalt |
|---|---|
| `references/menue-atlas.md` | Ordnungslogik aller Menues, Kuerzel-Muster, vollstaendige `Admin`-Struktur, Pflegeort-Tabelle je Skill, Migrationsspuren, bekannte Luecken |
| `references/scriptability.md` | `tomedo.sdef`-Kommandoinventar, Skript-Feature (Intervall/Startup/Toolbar/Ereignis-Hooks/Platzhalter), Deeplinks, was **nicht** geht, Sicherheitsbefunde |
| `references/applescript-rezeptbuch.md` | LLM-Aufruf per AppleScript: `llmservice`-Endpunktschema, `userIdent`-Ermittlung, Kartei-Uebergabe per Briefkommando, Env-Variablen-Muster, Rueckkanal, Fehlerdiagnose inkl. HTTP 422, Budget ueber `cost`, Pruefliste |
| `references/llm-toolebene.md` | Der dritte Automatisierungskanal: der Kartei-Chat als Agent mit Werkzeugen — warum hier nicht der Aufrufer bestimmt, was ausgeführt wird, und welche Pflegeorte es dafür gibt (und welche nicht) |

## Die vier Merkregeln

**1 · Menue nach Handlungsabsicht.**

| Menue | Absicht |
|---|---|
| `Verwaltung` | „Ich will eine **Uebersicht**" — Listen und Verwaltungsfenster oeffnen (der Haupt-Hub) |
| `Aktion` | „Ich will **etwas erzeugen**" — neue Objekte im Patientenkontext |
| `Format` | Textauszeichnung — **und, unerwartet, der `LLM-Textgenerator`** (unterhalb `Schrift` und `Text`) |
| `Formular` | „Ich will ein **Vordruck-Dokument**" — Formulare drucken im Patientenkontext |
| `Panel` | „Ich will ein **Dauer-Fenster daneben**" |
| `Admin` | „Ich will **festlegen, wie tomedo arbeitet**" — Kataloge, Vorlagen, Rechte, Automatisierung |
| `tomedo › Einstellungen ⌘,` | **Arbeitsplatz**-Einstellungen, nicht Systemkonfiguration |

**2 · Das Kuerzel-Muster** — die halbe Navigation in einem Satz:

- **`⇧⌃` + Buchstabe = Liste OEFFNEN** · `⇧⌃P` Patientenuebersicht · `⇧⌃I` Inbox ·
  `⇧⌃N` Nachrichten · `⇧⌃A` Aufgaben · `⇧⌃E` E-Mail/KIM
- **`⌘⇧` + Buchstabe = NEUES Objekt ANLEGEN** · `⌘⇧N` Nachricht · `⌘⇧E` Erinnerung ·
  `⌘⇧T` Aufgabe

Weitere belegte Kuerzel: `⌘L` Tagesliste · `⌘⌥K` Kalender · `⌘⌥S` Statistiken ·
`⌘⇧K` Kassenbuch · `⌥⌃A` Privatabrechnung · `⌥⌃T` Neuer Termin (ohne Patient) ·
`⌘⌥A` Arbeitsunfaehigkeit (1/E) · `⌘⌥⌃R/B/G` Rotes/Blaues/Gruenes Rezept.

**3 · Die Pflegeorte liegen fast alle unter `Admin`, nicht unter `Verwaltung`.**
Wer erklaeren soll, *wo etwas eingerichtet wird*, sucht in `Admin`. Die vollstaendige
Zuordnung Admin-Pfad → Org-Skill steht in `references/menue-atlas.md`.

**4 · Klammerzusatz = umgezogen.** Findet sich „jetzt …", „alte …" oder „(veraltet)",
ist der Pfad umgezogen; tomedo laesst den alten Eintrag als **inaktiven** Wegweiser
stehen (`Aktion › Kalender (jetzt unter Verwaltung)`). Anleitungen, die den alten Pfad
nennen, sind veraltet. **Gegenprobe lohnt bei jeder Pfadangabe in einem Skill.**

## Der schnellste Einstieg bei Navigationsfragen

`Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht` — tomedo hat eine **eingebaute**
Uebersicht aller Verwaltungsfenster. Erste Anlaufstelle, bevor geraten wird.
Fuer Diagnose: `Hilfe › Logs ›` (`tomedo.log`, `tomedo.extra.log`, **Loglevels
Feinschaltung**, `plistHistory.log`).

## Automatisierung: was geht, was nicht

tomedo ist offiziell scriptbar (`NSAppleScriptEnabled = true`, `Resources/tomedo.sdef`) —
ein vom Hersteller vorgesehener Erweiterungspunkt, kategorial etwas anderes als ein
nicht unterstuetzter Direkt-Write in die Datenbank. Das Dictionary ist aber **minimal**:

| Kommando | Wirkung |
|---|---|
| `call aktionskette` | ruft eine Kette per **Kuerzel** auf — **ohne Parameter**. Der Hebel. |
| `call statistik <csv>` | zeigt eine **CSV** im Statistikfenster an. Anzeige-, kein Abfragekanal. |
| `search patient` | oeffnet die Patientensuche mit einem Suchtext |

**Kein Kommando erzeugt tomedo-Objekte direkt** — kein Termin, kein Sperrtag, keine
Aufgabe, kein Karteieintrag. Schreibende Wirkung nur **indirekt** ueber
`call aktionskette`. Und: kein Aktionstyp der Kategorie „Termin & Kalender" schreibt
(alle drei sind interaktiv) — Ganztags-Abwesenheiten laufen ueber das Arbeitszeitkonto,
nicht ueber eine Kette. Details und die Gegenprobe: `references/scriptability.md`.

**Drei harte Grenzen, die jede Planung fruehzeitig kennen muss:**

1. `call aktionskette` nimmt **keine** Parameter. Ausweg: die Aktion „Aktionskette fuer
   alle Listeneintraege nacheinander ausfuehren" iteriert eine Statistik-Ergebnisliste;
   der Kontext kommt aus der Zeile.
2. Eine Aktionskette laeuft **am ausloesenden Arbeitsplatz** — UI-Effekte passieren nur dort.
3. **`$[arbeitsplatz]$`** und `$[nutzerkuerzel]$` loesen das Mehrfachausfuehrungs-Problem
   periodischer Skripte (arbeitsplatzweite Aktivierung → Selbstbeschraenkung im Skript).


### Login-Historie: sichtbar, nicht exportierbar, nicht abfragbar

**Pfad:** Admin → Nutzer → selektierter Nutzer → Login-Historie. Fenstertitel „LoginLogout fuer Nutzer: '<Kuerzel>'".

**Angezeigte Spalten:** Login (Zeitstempel), Logout (Zeitstempel, bei offenen Sitzungen leer), Client, Revision. Das Client-Feld traegt drei Angaben in einem String: Rechnername, Hardware-UUID und den Pfad des lokalen Benutzerordners, zum Beispiel `<rechnername> <hardware-uuid> /Users/<benutzer>/Library`.

**Grenzen (alle belegt 2026-08-23):**

- Kein Export, kein Multi-Select, kein Kopieren per Tastatur. Das Fenster gibt nichts heraus.
- **Kein bekannter Tabellenname.** Zwoelf Kandidaten geprueft (`loginlogout`, `nutzerloginlogout`, `loginhistorie`, `anmeldung`, `clientsession`, `serveronlyloginlogout`, `zsloginlogout`, `clientinfo`, `client`, `nutzersitzung`, `logineintrag`, `nutzeranmeldung`) — jeder mit `relation does not exist`.
- Der ZOLLSOFT-DB-Dump enthaelt keine passende Tabelle. `sitzung` ist die **Therapiesitzung** (FK auf `behandlungsfallelement`), nicht die Anmeldesitzung. Das Wort „Lizenz" kommt im Dump nicht vor.
- `nutzer.lastlogin` ist der einzige Login-Zeitstempel im dokumentierten Modell — **ein Wert, der bei jedem Login ueberschrieben wird**, ohne Historie und ohne Arbeitsplatzangabe.

**Konsequenz.** Arbeitsplatzbezogene Nutzungsdauern sind nicht auswertbar, obwohl die Daten sichtbar vorliegen. Zwei Wege bleiben:

1. **Supportanfrage beim Hersteller** nach Tabellen- und Spaltennamen. Praezise formulieren („in welcher Tabelle liegen die Daten aus Admin → Nutzer → Login-Historie"), nicht als Exportwunsch.
2. **Eigener Heartbeat** ueber das Skript-Feature: `skript` fuehrt `runonstartup`, `runwithtimeinterval`, `timeinterval` und `sourcecode`; der Arbeitsplatz-Platzhalter steht zur Verfuegung. Ein Skript schreibt Arbeitsplatz und Zeitstempel in eine Logdatei. **Ohne Nutzerbezug** — dann ist es keine Leistungs- und Verhaltenskontrolle nach § 87 Abs. 1 Nr. 6 BetrVG, und fuer eine Lizenzfrage wird der Nutzer nicht gebraucht. In eine Datei schreiben, nicht in die Datenbank, sonst verfaelscht der Heartbeat die eigenen Statistiken.

## Drei Sicherheits- und Datenschutzregeln dieser Erhebung

1. **Menue `Fenster` traegt PHI.** Fenstertitel enthalten Patientendaten (beobachtet:
   `Nachricht bzgl. <patient_id> - <Nachname Vornamen>`). Jedes Dump-Werkzeug muss
   `Fenster` ueberspringen oder redigieren. AX-Dumps immer auf die Zielperson filtern —
   ein unfilterter Button-Dump zieht den kompletten Mitarbeiter-Roster mit Klarnamen.
2. **Skript-Quelltexte sind kein Ort fuer Geheimnisse.** Der Quelltext liegt im
   **Klartext** in der Server-DB *und* im lokalen Cache **jedes** Arbeitsplatzes.
3. **Erhebung rein lesend.** Menues per Accessibility-API abfragen: kein Klick, kein
   `activate`, kein Fokuswechsel. Wer im Produktivsystem klickt, aendert es.

## Wenn ein Pfad nicht belegt ist

Nicht raten. Die Erhebung hat dokumentierte Luecken — `Einstellungen ⌘,` (Dialoginneres),
Kontextmenues (Rechtsklick), das Innenleben der Verwaltungsfenster, und je Untermenue
maximal 12 Eintraege im Auto-Dump (`Custom-Formulare` +78, `Arztbrief` +49, `KV` +36,
`Patientenformulare` +33; der **Admin-Dump ist vollstaendig**). Fehlt ein Pfad, ist die
ehrliche Antwort „nicht erhoben, hier ist der Nachbarpfad" plus der Hinweis auf
`Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht`.

---

*Stand 2026-08-11 · Quellen: Menueleisten-Dumps (ohne/mit Adminrecht) v1.169.0.21,
`tomedo.sdef`, `ZSKRIPT`-Bestand (30 Skripte), Deeplink-Pilot 08/2026.*


### Konfigurator als Übersetzer

Wo eine tomedo-Oberfläche eine **Textsyntax erzeugt**, ist sie zugleich das zuverlässigste
Nachschlagewerk für diese Syntax. Statt Keywords aus Foren oder Handbuchfragmenten zu raten:

1. Wegwerf-Objekt anlegen (Textbaustein, Kommando, Aktionskette)
2. **Eine** Option im Dialog setzen, mit OK bestätigen
3. Rohtext im Programmier- bzw. Expertenmodus ablesen
4. Differenz zur Vorfassung ist das gesuchte Keyword

Belegt an der Textbaustein-Makroverwaltung 2026-09-15: sieben unbekannte Optionen wurden so
in einem Durchgang entschlüsselt, darunter drei, die in der Onlinehilfe nicht auftauchen.
Eindeutige Marker als Werte verwenden (`SUFFIXTEST`), damit sie im Rohtext auffindbar sind.

**Grenze:** Was der Dialog **nicht** in den Rohtext schreibt, ist auch nicht per Syntax
steuerbar. Zeichenformatierung erzeugte keinen Zuwachs — sie liegt in der RTF-Ebene und
lässt sich nur im Editor setzen, nicht im generierten Text.

