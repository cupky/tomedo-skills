# Testprotokoll

> Teil des Skills `karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

Für jeden neuen Prompt, der produktiv gehen soll.

1. **Erwartungsanker vorab notieren** — Sollwert plus Fundstelle, **vor** dem ersten Lauf. Ohne das ist nach drei Läufen nicht entscheidbar, ob eine Abweichung ein Modellfehler oder eine Fehlannahme des Auswerters ist.
2. **Anker-Auflösungsprobe** — jedes Kommando einzeln (B.0).
3. **Aufgelösten Prompt-Text sichern**, bevor abgesendet wird. Sonst ist der Ankerwert im Nachhinein nicht auditierbar.
4. **Drei Läufe minimum**, vier bei Verdichtungsaufgaben. Vier der wichtigsten Befunde dieses Skills wären bei einem einzigen Lauf unsichtbar geblieben.
5. **Eine Variable pro Prompt-Variante.** Guard und Typdefinition getrennt zuschalten, sonst ist die Wirkung nicht zuzuordnen.
6. **Prompts absichtlich einfach halten.** Ein komplexer Prompt scheitert an der Prompt-Komplexität, und man schreibt es dem Kontext zu.
7. **Gegen die Anker auswerten**, nicht gegen den Eindruck. Reproduzierbar falsch ist gefährlicher als streuend falsch — es besteht jede Stichprobe.

---
