# Die LLM-Toolebene des KarteiChats

Was der Chat tatsaechlich kann, woher das belegt ist, und welche Grenzen der
Hersteller selbst zieht.

**Statuskennzeichnung mit Quellendatum.**
`[Hersteller, TT.MM.JJJJ]` = Onlinehilfe oder zollsoft-Aussage ·
`[Export, TT.MM.JJJJ]` = Tool-Export der eigenen Installation ·
`[Referenzinstallation, TT.MM.JJJJ]` = eigene Messung · `[plausibel]` = abgeleitet.

---

## 1 · Der Chat ist ein Agent, kein Modell mit vorgeladener Akte

Der KarteiChat entscheidet selbst, ob er die Kartei durchsucht, einen Anhang
liest oder etwas schreibt. Er tut das ueber ein Werkzeuginventar, das der
Client an das Modell uebergibt.

**Konsequenz fuers Prompting:** Ein Prompt steuert nicht nur den Text, sondern
auch die **Werkzeugwahl**. Die im Skill dokumentierte Ankerverengung ist genau
das — ein Volltext-Anker im Prompt laesst das Modell den History-Aufruf
ueberspringen, weil es die Frage schon beantwortet glaubt.

---

## 2 · Inventar der eigenen Installation

Export der Toolebene, 113 Eintraege, davon 112 benannt.
[Export, 13.09.2026 — tomedo v1.170.0.16]

### Kartei lesen (7)
`LLMToolGetPatientsHistory`, `LLMToolGetPatientsLaborData`,
`LLMToolGetPatientsMedicationHistory`, `LLMToolListKEAttachments`,
`LLMToolgetValidKarteiEintragTypen`, `Diagnosensuche`, `MedikamentInfoSearch`

### Anhaenge und Dokumente (14)
`LLMToolAttachmentAgent`, `LLMToolAttachmentExtractAgent`,
`LLMToolExtrahiereDokumentDaten`, `LLMToolExtrahiereAnerkennungsbescheid`,
`LLMToolExtrahiereHeilmittelverordnung`, `LLMToolExtrahierePatientStammdaten`,
`LLMToolExtrahiereFormularAgent`, `erkenneVerordnung`, `Dokument-Downloader`,
`LLMToolImportLabFromPDF`, `LLMToolLabPDFImportWorkflow`,
`LLMToolMatchLabTestsToFLTs`, `LLMToolCreateMissingFLTs`,
`LLMToolListFavoritLaborTests`

### Kartei schreiben (9)
`LLMToolCreateKarteieintrag`, `LLMToolEditKarteieintrag`,
`LLMToolCreateAufgabe`, `LLMToolCreateErinnerung`, `LLMToolCreateNachricht`,
`LLMToolPostMessage`, `LLMToolCreateEBM`, `LLMToolCreateGOZ`,
`LLMToolCreateBEMA`

### Briefkommandos (4)
`list_briefkommandos`, `run_briefkommando`, `LLMToolMatchBriefkommandosAgent`,
`LLMToolCreateBriefkommando`

### Textgenerierung (4)
`LLMToolGenerateArztbrief`, `LLMToolGenerateBefundbericht`,
`LLMToolGenerateZusammenfassung`, `LLMToolGenerateContextText`

### Formulare (7)
`LLMToolCreateFormular`, `LLMToolShowForm`, `LLMToolFillAndOpenFormularAgent`,
`LLMToolFormularBefuellerAgent`, `LLMToolListFieldsInFormularAgent`,
`LLMToolListFormularTypes`, `LLMToolMatchFormularAgent`

### Generischer Datenbankzugriff (8)
`LLMToolListEntities`, `LLMToolDescribeEntitySchema`,
`LLMToolFindEntityByProperty`, `LLMToolCreateManagedObject`,
`LLMToolUpdateManagedObjectProperty`, `LLMToolManagedObjectAgent`,
`LLMToolListCreatableEntities`, `LLMToolGetCreateSignatureForEntity`

### Diktat und Spracherkennung (12)
sieben `LLMToolASR*`-Tools, dazu `LLMToolReadDiktatVorlagen`,
`LLMToolSaveDiktatVorlage`, `LLMToolGenerateDiktatVorlageAgent`,
`LLMToolGenerateDiktatVorlageFormular`,
`LLMToolOpenIntelligentDiktatVorlagenVerwaltung`

### Oberflaeche und Navigation (14)
`LLMToolMenu`, `LLMToolGetMenuItems`, `LLMToolGetOpenWindows`,
`LLMToolOpenPatientDetails`, `LLMToolUIAutomationAgent`,
`LLMToolUIAutomationHinweis`, `LLMToolSelectFavorit`, `LLMToolFindFavorit`,
vier `Open*Katalog`- und `Open*Verwaltung`-Tools, zwei Katalog-Lesetools

### Support und Systemdiagnose (13)
`LLMToolSupportAgent`, `LLMToolCreateTicket`, `LLMToolServerStatus`,
`LLMToolTIConnector`, `LLMToolTIVerbNeustart`, `LLMToolReadLogs`,
`LLMToolTeamViewer`, `LLMToolTomedoIntelligenceRegistration` und weitere

### Uebrige (20)
zehn `LLMToolCameraLogin*`, zwei ePA-Tools, zwei Dental-Tools sowie
`LLMToolDate`, `LLMToolEcho`, `LLMToolSleep`, `LLMToolTrimChat`,
`LLMToolAmbossAIModeAsText`, `LLMToolValmed`

---

## 3 · Die fuenf Tools, die das Prompting am staerksten praegen

### `LLMToolGetPatientsHistory`

Durchsucht die Patientenhistorie: Dokumentation, Diagnosen, Leistungen, Briefe,
gespeicherte Formulare und **Pfade zu Dateianhaengen**. Einziger Parameter ist
ein optionaler `minDate`-Filter. [Export, 13.09.2026]

Die Beschreibung weist das Modell an, bei relativen Zeitangaben („die letzten
drei Jahre") **vorher** das aktuelle Datum zu bestimmen. [Export, 13.09.2026]

> **Fuers Prompting:** Es gibt keinen inhaltlichen Filter — nur ein
> Mindestdatum. Eine Zeitkappung im Prompt zu verlangen, steuert also nicht den
> Abruf, sondern nur die Auswahl danach. Wer wirklich kappen will, muss den
> Zeitraum explizit nennen, damit `minDate` gesetzt wird.

### `run_briefkommando` und `list_briefkommandos`

`run_briefkommando` wertet ein oder mehrere Briefkommandos im Kontext des
aktuellen Patienten aus. `list_briefkommandos` listet die verfuegbaren
Kommandos samt Name, Beschreibung und Kontext — **wertet sie aber nicht aus**;
dafuer ist danach das Auswertungstool noetig. Die Beschreibung empfiehlt
ausdruecklich, diese Liste auch dann zu konsultieren, wenn kein anderes
Informationstool die Antwort liefert. [Export, 13.09.2026]

> **Fuers Prompting:** Das erklaert, warum Anker funktionieren — und dass das
> Modell auch **von sich aus** Kommandos auswerten kann. Ein Anker ist damit
> nicht der einzige Weg zu einem Feldwert, aber der einzige **kontrollierte**.

### `LLMToolAttachmentAgent`

Liest und fasst Dateien, Bilder und Anhaenge zusammen; findet die Datei bei
Bedarf selbst anhand von Pfad oder Namen. **Entscheidend:** Das Tool hat
*keinen* Zugriff auf den bisherigen Chat — alle relevanten Informationen muessen
ihm explizit mitgegeben werden. [Export, 13.09.2026]

> **Fuers Prompting:** Bestaetigt die Kontextisolation der Sub-Agenten. Kein
> Verlass auf Vorwissen aus fruehen Turns. Wer einen Anhang auswerten laesst,
> muss die Frage im selben Auftrag vollstaendig formulieren.

### `LLMToolManagedObjectAgent` und die generische Objektebene

Der Agent legt beliebige Core-Data-Objekte an, sucht und aendert sie — er kennt
die verfuegbaren Datentypen, fragt Pflichtangaben per Formular ab und schreibt
tatsaechlich in die Datenbank. Die Beschreibung weist das Modell explizit an,
solche Aufgaben **nicht selbst herzuleiten**, sondern zu delegieren. Auch
dieser Agent sieht den bisherigen Chatverlauf nicht. [Export, 13.09.2026]

Darunter liegen `ListEntities`, `DescribeEntitySchema`, `FindEntityByProperty`,
`CreateManagedObject` und `UpdateManagedObjectProperty`. Erzeugbar sind laut
Beschreibung unter anderem Nutzer, Patienten sowie GOAE- und
EBM-Katalogeintraege. Was erzeugt werden darf, steuert eine generierte Registry
ueber Header-Tags; ohne hinterlegte Signatur darf eine Entitaet nicht per LLM
erstellt werden. [Export, 13.09.2026]

> ⚠️ **Das ist die weitreichendste Faehigkeit im ganzen Inventar.** Der Chat
> kann nicht nur Karteieintraege schreiben, sondern generisch
> Datenbankobjekte anlegen und Felder aendern. Fuer Prompts heisst das:
> **jede Formulierung, die als Auftrag zum Anlegen oder Aendern lesbar ist,
> kann tatsaechlich schreiben.** Abfrage-Prompts muessen entsprechend
> formuliert sein. [plausibel]

### `LLMToolCreateKarteieintrag` und `LLMToolEditKarteieintrag`

Beide Beschreibungen enthalten dieselbe Auflage: Der uebergebene Inhalt darf
**keine Quellenverweise mehr enthalten** (Form `[1235, &diag1224…]`).
`EditKarteieintrag` ersetzt den Inhalt **vollstaendig**; Typ und Datum bleiben.
Die ID stammt aus einer vorherigen Historienabfrage. [Export, 13.09.2026]

> **Fuers Prompting:** Wer einen Eintrag schreiben laesst, muss die
> Quellenmarker vorher entfernen lassen — sonst landen sie im Text oder der
> Aufruf scheitert. Und: „bearbeiten" heisst hier **ueberschreiben**, nicht
> ergaenzen.

---

## 4 · Quellenverknuepfung als Verifikationsregel

Jede Information, die der Chat liefert, wird mit ihrer Quelle in der Kartei
verknuepft, dargestellt als Kuerzel in eckigen Klammern wie `[ANA]`; ein Klick
oeffnet den Eintrag. Der Hersteller leitet daraus eine Arbeitsregel ab: Laesst
sich eine Information **nicht** mit einer Quelle verknuepfen, muss der Nutzer
sie zusaetzlich verifizieren. [Hersteller, 11.09.2026]

> **Einordnung.** Das ist die offizielle Halluzinations-Erkennungsregel und ein
> echter Gewinn. Sie ersetzt den Wiederhollauf aber **nicht**: Ein falsch
> zugeordneter Eintrag traegt ebenfalls eine Quellenangabe. Die belegte
> Konfabulationsklasse der Behandler-Attribution ist genau von dieser Art.
> [Referenzinstallation, 08.09.2026]

---

## 5 · Zweckbestimmung — die Grenze, die der Hersteller zieht

Der KarteiChat unterstuetzt beim **Auffinden vorhandener Informationen**. Er
dient ausdruecklich **nicht** der Unterstuetzung bei Diagnose und Therapie
durch Auswertung und Interpretation der vorhandenen Daten.
[Hersteller, 11.09.2026]

Fuer den Sprechstunden-Assistenten gilt dieselbe Abgrenzung.
[Hersteller, 11.09.2026]

| Prompt-Vorhaben | Innerhalb der Zweckbestimmung? |
|---|---|
| Wertabfrage, Verlaufszusammenfassung | ja |
| Fremdbefund in feste Rubriken ueberfuehren | ja |
| Gespraech in Anamnese, Befund, Therapie gliedern | ja |
| Mehrjahres-Akte zu einem Verlaufsnarrativ verdichten | **fraglich** — enthaelt Auswahl, Gewichtung, Kausalzuschreibung |
| Therapievorschlag ableiten | **nein** |

Keine Rechtsauskunft. Aber die Stelle, an der ein Prompt-Vorhaben eine
Begruendung braucht. [Referenzinstallation, 13.09.2026]

---

## 6 · Prompts als Textbausteine — Pflegeort und Grenze

**Pflegeort:** Verwaltung › Sprechstunden-Assistent › KI-Assistenten-Verwaltung.
Dort liegt die Uebersicht aller als Prompt nutzbaren Textbausteine, samt Anlage
neuer Prompts, Schnell-Button-Anzeige und Buttonfarbe.
[Hersteller, 11.09.2026]

Alternativ ueber die Textbaustein-Makroverwaltung, Reiter **Sichtbarkeit**,
Freigabe getrennt fuer KarteiChat und Support-Chat. Die Einstellung gilt
**nutzeruebergreifend**. [Hersteller, 11.09.2026]

Der Platzhalter `___` laesst eine Stelle offen, an der vor dem Absenden
ergaenzt werden kann. [Hersteller, 11.09.2026]

> ⚠️ **Nur reine Textbausteine.** Makros zur Auswahl von Karteieintraegen,
> Diagnosen oder Medikamenten sowie Frage-Antwort-Makros werden **nicht
> ausgefuehrt**, sondern als reiner Text an den Chatbot weitergereicht.
> [Hersteller, 11.09.2026]
>
> Ein Textbaustein mit Frage-Antwort-Dialog ist als Chat-Prompt damit
> **unbrauchbar**. Wer beides braucht, pflegt zwei Fassungen.

> ⚠️ **Loeschen wirkt durch.** Ein in der Promptverwaltung geloeschter Eintrag
> loescht den **Textbaustein**. [Hersteller, 11.09.2026]

---

## 7 · Modellwahl

Standardmaessig verwendet der KarteiChat ein Sprachmodell von Google Gemini.
**Bei Bedarf stehen andere Modelle zur Verfuegung; fuer einen Wechsel ist der
zollsoft-Support zu kontaktieren.** [Hersteller, 11.09.2026]

> **Widerrufen:** Die Annahme, im Chat entscheide eine Checkbox
> „experimentelle Features" zwischen Flash und Mistral, stammt aus einem
> Forumskommentar vom 17.10.2025 und ist ueberholt.

> **Widerrufen:** Die Skill-Formulierung „einfaches Gemini-Modell" ist keine
> Systemeigenschaft, sondern eine Voreinstellung. Vor jeder
> Modellgrenzen-Analyse pruefen, welches Modell tatsaechlich antwortet.

**Nicht ueber den Prompt steuerbar** — in keinem Pfad. Das Modell ist ein
Transportparameter, kein Inhalt. Ein Satz wie „antworte als Pro" bewirkt nichts.

### Was ein Modellwechsel bringt — gemessen

A/B-Messung am LLM-Service-Endpunkt, `gemini-2.5-flash` gegen `gemini-2.5-pro`,
je fuenf Laeufe, identischer Fachprompt ohne Personenbezug, Blindbewertung
nach sechs Kriterien. [Referenzinstallation, 13.09.2026]

| Kennzahl | Flash | Pro |
|---|---|---|
| Erfuellte Kriterien | 28 von 30 | 29 von 30 |
| Fachlich falsche Aussagen | 0 | 0 |
| Laengenspanne der Ausgaben | 2444 Zeichen | 142 Zeichen |
| Latenz, Mittel | 16,1 s | 16,6 s |
| Latenzspanne | 5,3 – 35,2 s | 15,2 – 17,6 s |
| Kosten je Lauf | 0,0008 $ | 0,0014 $ |

**Befund: kein Qualitaetssprung, sondern ein Konstanzsprung.** Beide Modelle
waren fachlich fehlerfrei; der Abstand von 29 zu 28 liegt bei n=5 im Rauschen.
Was Pro deutlich besser kann, ist Wiederholbarkeit — Ausgabelaenge und Latenz
streuen um eine Groessenordnung weniger.

**Der wichtigste Einzelbefund steht ausserhalb des Rasters:** Ein Flash-Lauf
erfuellte formal alle sechs Kriterien und **liess trotzdem einen von drei
geforderten Inhaltsbloecken komplett weg**, weil er die Rubriken anders
schnitt. Pro legte die Struktur in 5 von 5 Laeufen wie beabsichtigt aus, Flash
in 2 von 5 anders. [Referenzinstallation, 13.09.2026]

> **Fuers Prompting, zwei Lehren:**
> 1. **Strukturvorgaben muessen die Gliederungsachse benennen**, nicht nur die
>    Anzahl der Abschnitte. „Drei Rubriken" reicht nicht — es muss stehen,
>    **wonach** gegliedert wird.
> 2. **Vollstaendigkeit gehoert ins Pruefraster.** Ein Kriterienkatalog, der
>    nur Form und Fachlichkeit prueft, laesst fehlende Inhalte durch. Siehe
>    `testprotokoll.md`.

Latenz war **nicht** der erwartete Nachteil von Pro. Die aeltere
Hersteller-Aussage, Pro rechne durch staendiges Nachdenken sehr lange
[Hersteller, 18.09.2025], hat sich in dieser Messung nicht bestaetigt.

---

## 8 · Backlog: die generische Objektebene austesten

Der Export belegt, **dass** es die Tools gibt, nicht **wie weit** sie reichen.
Die Beschreibung nennt als erzeugbare Objekte Nutzer, Patienten sowie GOAE- und
EBM-Katalogeintraege — und verweist fuer die Schranke auf eine generierte
Registry: Ohne hinterlegte Create-Signatur darf eine Entitaet nicht per LLM
erstellt werden. [Export, 13.09.2026]

**Ob Custom-Karteieintraege, Textbausteine, Aktionsketten, Formulare oder
Statistiken darunter fallen, ist unbekannt.** Eine Changelog-Recherche zu
dieser Faehigkeit blieb ohne Treffer; ob es sich um eine ausgereifte oder eine
vorbereitete Funktion handelt, ist offen. [Referenzinstallation, 13.09.2026]

### Testreihe, gefahrlos und in dieser Reihenfolge

Alle Schritte **lesend** beginnen. Erst wenn das Schema bekannt ist, schreiben —
und dann nur an einem Wegwerf-Objekt, nie an Katalogen oder Stammdaten.

| Nr. | Anfrage im Chat | Erwartung |
|---|---|---|
| G1 | Welche Entitaeten kannst du anlegen? | Liste aus `ListCreatableEntities` — der Moeglichkeitsraum |
| G2 | Zeige das Schema der Entitaet `<CKE-Typ>` | `DescribeEntitySchema` liefert Attribute und Relationen, oder faellt aus |
| G3 | Gibt es eine Create-Signatur fuer `<Entitaet>`? | `GetCreateSignatureForEntity` — die eigentliche Schranke |
| G4 | Lege einen Testeintrag mit genau einem Feld an | schreibt oder scheitert; **nur an einem Testobjekt** |
| G5 | Aendere ein Feld dieses Testobjekts | `UpdateManagedObjectProperty` |
| G6 | Dasselbe mit einem geschuetzten Objekt (Katalogeintrag) | **erwartet: Ablehnung.** Faellt sie aus, ist das ein Befund fuer zollsoft |

### Warum das dringlich ist

Die Schreibfaehigkeit besteht **unabhaengig davon, ob wir sie nutzen**. Ein
Prompt, der als Anlege- oder Aenderungsauftrag lesbar ist, kann bereits heute
schreiben. Solange die Reichweite unbekannt ist, gilt:

> **Abfrage-Prompts duerfen keinen Satz enthalten, der als Auftrag zum Anlegen,
> Ergaenzen oder Aktualisieren lesbar ist.** Formulierungen wie „trage
> zusammen", „erfasse", „lege dar" sind harmlos gemeint und potenziell als
> Schreibauftrag lesbar. Sicher sind Frageformen und „nenne", „liste auf",
> „gib zurueck". [plausibel]

---

## 9 · Was das Inventar nicht verraet

- **Welches Modell** antwortet. Der Export enthaelt die Modellidentitaet nicht.
  [Export, 13.09.2026]
- **Wann der Bestaetigungsdialog** beim KI-Prompt in der Aktionskette erscheint.
  Dass er erscheinen kann und manuell zu bestaetigen ist, ist belegt
  [Hersteller, 11.09.2026] — die Bedingung nicht.
- **Ob das Inventar installationsabhaengig ist.** Dieser Export stammt aus einer
  Installation mit tomedo v1.170.0.16. Ob Rechte, Module oder Version die Liste
  veraendern, ist nicht geprueft.

---

*Erhoben 09/2026. Quellen: Tool-Export der eigenen Installation (113 Eintraege,
tomedo v1.170.0.16), Onlinehilfe tomedo Intelligence Stand 11.09.2026,
A/B-Messreihe am LLM-Service-Endpunkt vom 13.09.2026.*
