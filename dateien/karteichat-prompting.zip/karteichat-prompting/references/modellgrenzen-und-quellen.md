# Modellgrenzen

> Teil des Skills `karteichat-prompting`. Der Navigator ist `SKILL.md`.

---

Konsistent beobachtet, Stand 09/2026.

| Limit | Auswirkung | Workaround | Status |
|---|---|---|---|
| Vorgegebene Werte schlagen die Aktenlage | Anker wird ausgegeben, auch wenn die Kartei widerspricht | Guard + Typdefinition | belegt |
| Leerer Anker beendet die Recherche | „Feld leer" statt Antwort aus dem Fließtext | Guard-Satz zur Leere | belegt |
| Anker ohne Auftrag wird interpretiert | Harter Wert wird zu einer Aussage über den Wert | Immer Aufgabe mitgeben | belegt |
| Zeichen- und Längenvorgaben | 0/8 innerhalb der Vorgabe (207–392 statt 200) | Nicht auf Zeichenzahl verlassen; Lückentext mit Platzhalter-Längen | belegt |
| Asymmetrischer Informationsverlust bei Verdichtung | Nutzenaussage wird übernommen, Vorbehalt im selben Satz nicht (4/4) | Vorbehalt als eigene Instruktion, nicht auf Übernahme hoffen | belegt |
| Kausalbehauptung unter Kompression | 2/8 behaupteten eine Wirkung, die die Akte ausschließt | Kausalverbot explizit; Ausgabe gegen Quelleintrag prüfen | belegt |
| Attributionsdrift im Einstiegssatz | Mehrstufige Vorgänge werden zu einer Ursache verkürzt | Nach Ursachen getrennt fragen | belegt |
| Systemdatum als Befund | Antwort auf „wann" kann der Anfragezeitpunkt sein | Bei Datumsfragen Erwartungsanker prüfen | belegt |
| Anlagen nicht im Kontext | PDF-Inhalte existieren für den Chat nicht | Zitierfähiges in den Eintragstext | belegt |
| Trade-off Struktur ↔ Filter | Verschärft man eines, rutscht das andere | Multi-Turn, eine Aufgabe pro Prompt | belegt |
| Abstrakte Strukturvorgaben werden ignoriert | Modell erfindet eigene Headlines | Wörtlicher Lückentext mit `{Platzhaltern}` | belegt |
| Selbst-Audits sind performativ | ✅ ohne tatsächliche Prüfung | Externe Endkontrolle | belegt |
| Konsolidierung (50+ IDs → 4 Slots) kollabiert | Output bleibt leer | Aufgabe splitten | belegt |
| Stilistische Variabilität | Drei Läufe, drei Formulierungen | Mehrfach laufen, besten wählen | belegt |
| Filter-Inkonsistenz | Mal sauber, mal Blacklist-Schmuggel | Sanity-Check durch den Anwender | belegt |
| Verarbeitungs-Queue | Zu schnelle Folge-Prompts → leere Outputs | ≥30 Sekunden warten | zu evaluieren |

## C.1 Was der KarteiChat gut kann

Diese Stärken gehören in jede Bewertung, sonst entstehen falsche Erwartungen in beide Richtungen.

- **Retrieval über die ganze Akte.** Positionsprobe an Anfang, Mitte und letztem Eintrag einer Akte mit 108 Einträgen: 4/4 korrekt, alle Läufe. Keine erkennbare Kürzung. **belegt**
- **Korrekte Abstinenz statt Erfindung.** Frage, deren Antwort nur in einer PDF-Anlage stand: 4/4 „nicht dokumentiert", obwohl der Suchbegriff mehrfach in der Kartei vorkommt. In rund 40 Läufen **keine** frei erfundene Zahl. **belegt**
- **Freitext-Extraktion.** Drei über 15 Einträge verstreute Messwerte, chronologisch, mit Datum: 3/3 vollständig richtig, ohne jeden Anker. **belegt**
- **Alltagsfragen.** „Was ist seit dem letzten ärztlichen Kontakt passiert, welche Wiedervorstellungskriterien gelten?": 4/4 sachlich richtig, inklusive Trennung ärztlich / physiotherapeutisch. **belegt**
- **Quellenanker als Hyperlinks** je Aussage, mit Sprung in den Karteieintrag. Prüfbarkeit am Einzelsatz — das kann kein Modell außerhalb von tomedo. **belegt**

## C.2 Quellengrenzen

| Quelle | Im Chatkontext | Status |
|---|---|---|
| Karteieintragstext, alle Typen, gesamter Zeitraum | ja | belegt |
| Typ-Bezeichnung je Eintrag | ja | belegt |
| Datum je Eintrag | ja | belegt |
| Stammdaten (Name, Geburtsdatum, Geschlecht, Beruf) | ja | belegt |
| Systemdatum und -uhrzeit | ja | belegt |
| **PDF-Anlagen an Karteieinträgen** | **nein** | belegt |
| Diagnose-ICD-Codes, wenn nicht im Text | nein | belegt |
| Dokumentierender Nutzer je Eintrag | unbekannt | zu evaluieren |
| Leistungen (EBM/GOÄ) | unbekannt | zu evaluieren |

**Doku-Konsequenz:** Was zitierfähig sein muss — fremde Indikationsstellungen, Zweitmeinungsergebnisse, Klinikbefunde — muss als **Text im Karteieintrag** stehen, nicht nur als Anlage. Nur dann ist es gleichzeitig für den Chat lesbar, per `$[x SCAN …]$` kommandierbar und für HQL auswertbar. Ein Textlayer im PDF nützt keinem der drei Wege.

---
