# Praxis-Interna dieser Installation

**Diese Datei ist absichtlich leer ausgeliefert.** Sie ist der vorgesehene Ort für die
Aktenkennungen, Kürzel und Pflegestände **Ihrer** Installation. Der übrige Skill nennt
dieselben Sachverhalte generisch — mit einer Anleitung, wie Sie den eigenen Wert ermitteln.
Tragen Sie die Ergebnisse hier ein, dann arbeitet die KI mit Ihren Werten statt mit
Vermutungen.

**Warum getrennt:** So lässt sich der Skill weitergeben, ohne dass Praxisinterna mitwandern —
und eine neue Fassung überschreibt Ihre Erhebung nicht, solange Sie diese Datei beim
Aktualisieren stehen lassen.

**Nicht hierher gehören die gemessenen Quoten** aus `modellgrenzen-und-quellen.md`. Die sind
an synthetischen Demoakten erhoben und Teil des Skills.

**Erhebungsstand:** _(Datum eintragen)_

---

## 1 · Kommando-Inventur — welche Anker bei Ihnen tatsächlich tragen

**Das ist der wichtigste Abschnitt dieser Datei.** Ein Briefkommando ist so stark wie die
strukturierte Pflege Ihrer Akte. Ein Kommando, das ins Leere greift, liefert **lautlos
nichts** — und Ihr verankerter Prompt ist dann wieder ein unverankerter, ohne dass es jemand
merkt.

**So erheben Sie es:** `Admin › Kommandos` → Kommando anlegen oder auswählen →
**[Ausführen]** gegen eine echte Akte. Kein Briefvorlagen-Bau nötig, nichts wird gesendet.

Prüfen Sie mindestens diese, bevor Sie einen verankerten Baustein ausliefern:

| Kommando | Status | gelieferter Wert |
|---|---|---|
| `$[beruf]$` | | |
| `$[adressfeld_patient]$` | | |
| `$[x DDI …]$` Dauerdiagnosen | | |
| `$[x ANA 1 …]$` Anamnese | | |
| `$[x THE 3 …]$` Therapie | | |
| `$[medikamenteVorhanden]$` | | |
| `$[medikamentenplan]$` | | |
| `$[x AU …]$` Arbeitsunfähigkeit | | |
| `$[l]$` · `$[l_alle]$` Leistungen | | |
| `$[letzteLaborwerte 1]$` | | |
| `$[patientenTermine]$` | | |
| `$[x DIA …]$` Scheindiagnosen | | |

> ⚠️ **Tragen Sie bei `OK` auch den gelieferten Wert ein.** Der gefährlichste Fall ist nicht
> das leere Kommando, sondern das, welches einen **gültigen Wert 0** liefert, obwohl der
> Sachverhalt existiert — etwa eine Medikationsabfrage an einer Akte, in der die Präparate
> nur als Fließtext stehen. Ein solcher Anker ist schlechter als kein Anker.

**Halten Sie fest, welche Datenklassen bei Ihnen strukturiert gepflegt sind.** Verankerte
Bausteine dürfen nur auf diese bauen.

---

## 2 · Aktenkennungen Ihrer Testakten

| Akte | Nummer | Rolle |
|---|---|---|
| | | |

Verwenden Sie für Messreihen **synthetische** Akten. Achten Sie darauf, was im
Kurzinfo-/Patienteninfo-Feld steht: Der Chat liest dieses Feld, obwohl es nicht Teil des
Kartei-Exports ist, und mischt den Inhalt gelegentlich in Verdichtungen.

---

## 3 · Rollout- und Kontostand

| Befund | Wert bei Ihnen |
|---|---|
| Rollout des KarteiChat | |
| Testkonten, die keine Behandlerkonten sind | |
| Karteieinträge mit `autoquelle IS NOT NULL` | |

Solange nur Testkonten schreiben, verzerrt eine Auswertung je Behandler das Bild. Und solange
der einzige KI-Eintrag an einer Demoakte hängt, entfernt ihn die übliche Demo-Exklusion —
während der Testphase deshalb ohne Demo-Filter auswerten.

Die Query dazu steht in `tomedo-statistik-hql`, Query-Baustein „Maschinell erzeugte
Karteieinträge je Nutzer und Quartal".

---

## 4 · Eigene Messbefunde

Hierher gehört alles, was nur bei Ihnen gilt: eigene Typkürzel, abweichende
Karteieintragstypen, Besonderheiten Ihrer Dokumentationsdisziplin. Ein Muster je Befund:

### `<Gegenstand>`

_Messung vom TT.MM.JJJJ: …_

_Konsequenz für den Prompt-Bau: …_
