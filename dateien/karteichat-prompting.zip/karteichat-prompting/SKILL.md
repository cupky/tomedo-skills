---
name: karteichat-prompting
description: >-
  Erstellt und debuggt Prompts und Prompt-Ketten fuer den tomedo KarteiChat (Agent mit
  Werkzeugebene; Modell wechselbar ueber den zollsoft-Support). Verwende diesen Skill IMMER wenn
  KarteiChat-Prompts, Multi-Turn-Prompts in tomedo, Briefe via KarteiChat, Berichte aus
  Karteieintraegen, Kurzberichte, Arztbriefe oder Antraege automatisiert generiert werden sollen.
  Auch bei: Prompt rutscht, Modell ignoriert Vorgaben, Filter-Bruch trotz Regeln, Output zu lang
  oder leer, Briefkommando im Prompt, harte Fakten verankern, Anker, Guard-Satz, Typdefinition,
  Modell nennt falsches Datum, Kartei wird nicht durchsucht, Anlage wird nicht gelesen, Vorbehalt
  geht verloren, KarteiChat testen, Testprotokoll. Ebenso bei: welche Tools hat der KarteiChat,
  LLMTool, Toolebene, Werkzeugzugriff, Quellenverknuepfung, Zweckbestimmung, Promptverwaltung,
  Textbaustein als Prompt, Modellwahl im Chat, Flash gegen Pro. Der Skill ist ein Navigator; die
  Inhalte liegen in references/.
metadata:
  version: 1.1
---

# tomedo KarteiChat Prompting Skill

Best Practices für Prompts und Prompt-Ketten im tomedo KarteiChat. **Navigator** — die Inhalte liegen in `references/`.

> **Belegbasis:** Prompt-Engineering-Session psychotherapeutischer Kurzbericht (05/2026) und eine kontrollierte Testserie an einer synthetischen Demoakte mit 108 Karteieinträgen (09/2026, 8 Prompt-Varianten, je 3–4 Läufe, rund 40 protokollierte Antworten, Gegenvergleich gegen ein großes Modell bei identischem Input).

**Statuskennzeichnung:** **belegt** = mehrfach beobachtet, Läufe protokolliert · **plausibel** = einmal beobachtet oder abgeleitet · **zu evaluieren** = Vermutung.

---

## Wann diesen Skill verwenden

- Neue KarteiChat-Prompts für strukturierte Outputs (Berichte, Briefe, Anträge)
- Debugging bestehender Prompts, die unzuverlässig laufen
- Prompts, in die Briefkommandos eingebettet werden
- Multi-Turn-Prompt-Ketten entwerfen
- Testprotokolle für KarteiChat-Verhalten aufsetzen
- Vorbereitung von Forumsbeiträgen / Erfahrungsaustausch

**Nicht für:** den Bau von Briefvorlagen selbst (→ `tomedo-kommandos`), statische Textbausteine (→ `tomedo-textbausteine`), HQL-Auswertungen (→ `tomedo-statistik-hql`).

---

## Der Kern in fünf Sätzen

**Briefkommandos werden im KarteiChat-Eingabefeld aufgelöst** — etwa eine Sekunde nach dem Einfügen steht anstelle von `$[…]$` der Datenbankwert. Damit lässt sich eine Tatsache **vorgeben** („Anker"), statt sie das Modell erschließen zu lassen. Ein Anker bringt aber nur einen **Wert** mit, keine **Bedeutung**: die Beschriftung daneben prüft niemand, und ein vorgegebener Wert schlägt die Aktenlage. Gegen diesen Effekt wirken zwei Zusätze — ein **Guard-Satz**, der dem Anker die Unantastbarkeit nimmt, und eine **Typdefinition**, die den Fachbegriff der Frage in Karteieintragstypen ausdrückt. Die Typdefinition ist der wirksamste Baustein, der Guard der billigste, ein **leerer Anker** der gefährlichste Fehler. Ein vierter Baustein kommt hinzu, sobald man den Chat als **Agenten mit Werkzeugen** versteht: die **Werkzeuganweisung** — dem Modell sagen, *welches* Werkzeug es für eine Teilfrage benutzen soll. Der stärkste Fall ist das Umleiten einer strukturierten Frage auf ein Spezialwerkzeug statt auf den Karteivolltext, der billigste das Setzen eines Datumsfilters. Inventar und Formulierungen: `references/toolinventar-und-hebel.md`.

> ⚠️ **Widerrufen:** die Skill-v1-Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat" ist falsch und entfernt.

> ⚠️ **Widerrufen:** „einfaches Gemini-Modell" als Systemeigenschaft. Der Chat nutzt
> standardmaessig ein Google-Gemini-Modell; andere Modelle stehen auf Anfrage beim
> zollsoft-Support zur Verfuegung [Hersteller, 11.09.2026]. Vor jeder Modellgrenzen-Analyse
> pruefen, **welches** Modell antwortet. Eigene A/B-Messung: der Sprung Flash → Pro bringt
> keinen Qualitaets-, sondern einen **Konstanzsprung** — Laengenstreuung 142 statt 2444
> Zeichen bei gleicher Fachqualitaet [Referenzinstallation, 13.09.2026]. Details in `references/llm-toolebene.md`.

> ⚠️ **Zweckbestimmung.** Der Hersteller grenzt den Chat auf das *Auffinden vorhandener*
> Informationen ein; Auswertung und Interpretation zur Diagnose- und Therapieunterstuetzung
> sind ausgeschlossen [Hersteller, 11.09.2026]. Verdichtungs-Prompts brauchen eine Begruendung.

### Der belegte Fehlerkatalog

| Konstellation | Guard | Typdefinition | Ergebnis (3 Läufe) |
|---|---|---|---|
| Anker falsch beschriftet | – | – | **3/3 falsch**, identisch |
| Anker leer, Nebenfrage | – | – | **3/3 Recherche abgebrochen** |
| Anker löst nicht auf (`-`), Antwortslot | – | – | **3/3 falsch**, lautlos gefüllt |
| Anker falsch beschriftet | ✓ | – | **1/3 richtig**, Streuung inkl. Systemdatum |
| Anker falsch beschriftet | ✓ | ✓ | **3/3 richtig**, Abweichung benannt |
| Kein Anker, Freitext-Extraktion | – | – | **3/3 vollständig richtig** |

### Der stille Inhaltsverlust

Die gefährlichste Abweichung ist die, die **formal korrekt aussieht**. In der A/B-Messreihe
am LLM-Endpunkt erfüllte ein Lauf **alle sechs Prüfkriterien** — drei Rubriken, korrekte
Zeilenanfänge, je zwei Merkmale, keine Formatierungszeichen, fachlich richtig,
literaturgedeckt — und **ließ trotzdem einen von drei geforderten Inhaltsblöcken
vollständig weg**. Ursache: Das Modell schnitt die Rubriken nach einer anderen Achse
(Vergleichsdimensionen statt Sachtypen) und füllte die geforderte Rubrikzahl damit auf.
Das schwächere Modell tat das in 2 von 5 Läufen, das stärkere in 0 von 5.
[Referenzinstallation, 13.09.2026]

**Zwei Regeln folgen daraus:**

1. **Die Gliederungsachse gehört in die Strukturvorgabe.** „Bilde drei Rubriken" reicht
   nicht — es muss stehen, **wonach** gegliedert wird. Eine Zahl allein ist erfüllbar,
   ohne die Aufgabe zu erfüllen.
2. **Vollständigkeit ist ein eigenes Prüfkriterium.** Ein Raster aus Form und Fachlichkeit
   lässt fehlende Inhalte durch. Jeder Testkatalog braucht die Frage: *Kommt jeder
   geforderte Gegenstand im Ergebnis vor?* — getrennt von der Frage, ob das Ergebnis
   richtig ist.

Besonders scharf wird der Effekt, wenn eine **Mengenkappung** auf einen
**Vollständigkeitsanspruch** trifft — etwa im LLM-Textgenerator, dessen ausgelieferte
Vorlage auf 30 Karteieinträge kappt, während der System-Prompt Vollständigkeit verlangt
(`references/llm-textgenerator.md`).

### Der Prompt-Rahmen

```
Harte Fakten aus tomedo:
Aktive Diagnosen: $[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$
Letzter ärztlicher Kontakt: $[d E MN <TYP>]$

Die Angaben oben stammen aus einzelnen Feldern und können veraltet oder leer sein.
Prüfe sie gegen die Kartei. Weiche ab, wenn die Kartei etwas anderes zeigt, und
benenne die Abweichung. Ein leeres Feld bedeutet nicht, dass es den Sachverhalt
nicht gibt.

Ärztliche Kontakte sind Einträge der Typen Anamnese und Therapie. Einträge vom
Typ „Verlauf Physio" und „Verlauf Psychosomatik" sind keine ärztlichen Kontakte.

Aufgabe: <genau eine Aufgabe>. Verwende ausschließlich Daten und Zahlen aus den
Fakten oben und aus der Kartei. Füge keine eigenen Zahlen, Werte oder Zeitangaben
hinzu. Wenn die Akte eine Einschränkung zur Aussagekraft enthält, übernimm sie
wörtlich.
```

Herleitung, Wirkungsnachweise und die Entscheidungsregel „verankern oder nicht" → `references/anker-guard-typdefinition.md`.

---


### Emoji dürfen keine Semantik tragen

> Die Baustein-Seite dieser Regel — Zeichensatzfalle beim Export, `___`-Notation,
> Sichtbarkeitsstufen — steht im Skill `tomedo-textbausteine`. Hier geht es nur darum,
> was das für den Prompt-Bau bedeutet.

Prompt-Bausteine setzen gern `✅ / ⚠️ / ❌` als Phasenmarker ein. Das ist lesefreundlich und
funktional riskant: diese Zeichen liegen ausserhalb von cp1252 und werden im RTF-Langtext eines
Textbausteins als `\uN?`-Escape gespeichert. Bei Export/Reimport, Encoding-Wechsel oder Copy-Paste
ueber Systemgrenzen kann der Escape verloren gehen — dann bleibt das Fallback-Zeichen stehen und
die Regel wird stillschweigend bedeutungslos.

**Regel:** Jede Zeile, deren Bedeutung an einem Emoji haengt, bekommt ein ASCII-Label als
Redundanz. Das Emoji bleibt Dekoration.

```text
# schlecht — Bedeutung haengt am Zeichen
PHASE-C:
❌ ANA, T, SCHMA, BEF

# gut — Bedeutung steht im Text, Emoji ist optional
PHASE-C (VERBOTEN, auch wenn der Inhalt passt):
- VERBOTEN: ANA, T, SCHMA, BEF
```

Gleiches gilt fuer `→` in Begruendungs-Templates (durch `=>` oder `:` ersetzbar) und fuer
typografische Striche in Zahlenbereichen (`150–250 Wörter` → `150-250 Wörter`).

**Pruefschritt vor Auslieferung:** Baustein einmal exportieren, reimportieren und die
Nicht-ASCII-Zeichen zaehlen. Weicht die Zahl ab, ist der Baustein nicht transportsicher.

### Markdown hat zwei Adressaten

> Wie Markdown im Textbaustein selbst behandelt wird, regelt `tomedo-textbausteine`.
> Hier steht nur die Folge für den Prompt.

Der Lueckentext arbeitet mit `**Fett**`-Headlines. Die werden an **zwei** Stellen wirksam und
verhalten sich dort unterschiedlich:

| Ziel | Verhalten |
|---|---|
| Chat-Fenster | Markdown-Rendering ist laut zollsoft-Forum-Antwort inzwischen moeglich — `**` wird zu Fettschrift |
| Karteieintrag nach Copy-Paste | Markdown wird **nicht** interpretiert; `**` landet als Literal im Text |

**Konsequenz fuer den Prompt-Bau:** Entscheide vor dem Bau, wohin der Output geht.

- **Ziel Karteieintrag:** Headlines ohne `**` vorgeben (`Therapierelevante Diagnosen:`). Sonst muss
  jede Ausgabe manuell nachgeputzt werden — und in einer Messreihe wird der Putzaufwand faelschlich
  dem Modell zugerechnet.
- **Ziel Brief/Weiterverarbeitung:** `**` ist unschaedlich, solange die Zielpipeline Markdown kennt.
- **Bei Messungen:** vorher festlegen, ob Markdown-Reste als Formatfehler zaehlen. Ohne diese
  Festlegung ist ein Score zwischen zwei tomedo-Versionen nicht vergleichbar, weil sich das
  Rendering-Verhalten geaendert hat.

XML-Tags (`<diagnosen>…</diagnosen>`) sind gegen dieses Problem immun — sie werden in keinem der
beiden Ziele gerendert und sind deterministisch per Regex abgreifbar. Fuer maschinelle
Weiterverarbeitung deshalb vorzuziehen.

### Das Modell ist keine Konstante

Laut Onlinehilfe verarbeitet der Kartei-Chat Karteiinhalte mit einem LLM; **standardmaessig Google
Gemini**, andere Modelle sind **auf Anfrage beim zollsoft-Support verfuegbar**. Daraus folgen drei
Arbeitsregeln:

1. **Keine Prompt-Version ohne Modellstempel.** Wer eine Prompt-Kette dokumentiert oder ihre
   Ergebnisse zitiert, notiert tomedo-Version, Datum und — soweit ermittelbar — die Modellkennung.
   Ohne Stempel sind Aussagen wie „v7 haelt die Struktur zu 90 %" nicht reproduzierbar.
2. **Modellidentitaet ist erfragbar, nicht nur erratbar.** Ein Probe-Prompt zeigt nur den
   Ist-Zustand. Fuer die Historie (welches Modell lief zu welchem Zeitpunkt im eigenen Account)
   ist der Support die Quelle.
3. **Patterns dieses Skills sind an eine Modellklasse gebunden, nicht an „den KarteiChat".**
   Nach einem Modellwechsel gelten sie als unbestaetigt, bis sie neu gemessen wurden. Insbesondere
   koennen Multi-Turn-Aufteilung und Anti-Schmuggel-Liste bei einem stärkeren Backend zu
   ueberfluessigem Aufwand werden.

**Quellenverknuepfung ist Backend-Eigenschaft, nicht Prompt-Leistung.** Die Onlinehilfe beschreibt,
dass jede Information, die der Chat liefert, mit ihrer Quelle in der Kartei verknuepft wird. Wer
in einem Prompt zusaetzlich „gib Datum und KE-ID an" fordert, misst also nicht nur das Modell,
sondern auch dieses Retrieval. Bei Vergleichsmessungen ueber Versionsgrenzen hinweg ist das ein
Confounder und gehoert ins Protokoll.

**Bekannte Grenze:** Laborbefunde sind laut zollsoft-Antwort im Forum nicht durchsuchbar. Prompts,
die Laborverlaeufe auswerten sollen, scheitern nicht am Prompt-Design.


## Transportkanal: Prompt als Textbaustein

Ein Prompt ist im Kartei-Chat kein Freitext, sondern ein Artefakt mit Pflegeort und
Ausspielungsweg. Die folgenden Punkte sind aus der Onlinehilfe bzw. aus zollsoft-Antworten im
Forum belegt.

**Was zollsoft vorgibt**

| Punkt | Beleg |
|---|---|
| Textbausteine dienen als vorkonfigurierte Prompts; mehrere werden mitgeliefert, eigene sind ergaenzbar | Onlinehilfe, Kartei-Chat |
| Freigabe ueber Reiter *Sichtbarkeit* (Kartei-Chat oder Support-Chat), **nutzeruebergreifend** | Onlinehilfe |
| Pflegeort ohne Umweg ueber die Makroverwaltung: Verwaltung → Sprechstunden-Assistent → KI-Assistenten-Verwaltung; dort auch Schnell-Button ein/aus und Buttonfarbe | Onlinehilfe |
| Platzhalter `___` im Baustein erlaubt, vor dem Absenden an dieser Stelle Text zu ergaenzen | Onlinehilfe |
| Schnell-Buttons loesen den Prompt **direkt** aus | Onlinehilfe |

**Es gibt kein zollsoft-Regelwerk zur inhaltlichen Prompt-Formulierung.** Die einzige
Schreibempfehlung des Herstellers steht auf der Sprechstunden-Assistent-Seite: in der Beschreibung
angeben, welche Inhalte dokumentiert werden sollen, inklusive Formatierungshinweisen (Beispiel dort:
Bewegungsmaße immer als drei Winkelwerte, getrennt durch Schrägstriche). Die Patterns dieses Skills
stehen also nicht in Konkurrenz zu einer Hersteller-Konvention, sondern fuellen eine Luecke.

**Ausloeseweg ist verhaltensrelevant.** Aus einem Forum-Fall: wird ein Prompt per Schnell-Button
ausgeloest, verliert das Modell den Bezug zu einem vorher per Drag&Drop eingefuegten PDF. Nur
gemeinsames Senden von Anhang und Prompt-Text funktioniert — also Prompt aus dem Textbaustein
kopieren und einfuegen statt den Button zu klicken.

**Regeln fuer den Skill-Einsatz**

1. **Ein Ausloeseweg pro Arbeitsablauf.** Button oder Paste, nicht gemischt. Bei Anhaengen (PDF,
   gescannter Brief) zwingend Paste.
2. **`___` fuer variable Anteile nutzen**, statt fuer jede Adressatenvariante einen eigenen
   Baustein zu pflegen. Bei Multi-Turn-Ketten aber sparsam — jede Fuellstelle ist eine
   Fehlerquelle im Ablauf.
3. **Kuerzel-Konvention und Reihenfolge dokumentieren.** Bei Multi-Turn muss aus dem Kuerzel die
   Schrittnummer hervorgehen (`v7.1` vor `v7.3`), sonst wird die Kette falsch bedient.
4. **Nutzeruebergreifende Freigabe bedenken.** Eine Sichtbarkeitsaenderung wirkt fuer alle
   Nutzer; Testbausteine gehoeren nicht in die Chat-Freigabe.

## Referenz-Routing

| Frage | Datei |
|---|---|
| Was sind Anker, Guard, Typdefinition? Welche Regeln gelten? Verankern oder nicht? | `references/anker-guard-typdefinition.md` |
| Welches Kommando liefert Diagnosen, Daten, Volltexte, CKE- und Formularwerte? Praxiseigene Typkürzel? | `references/kommando-bibliothek.md` |
| Was kann das Modell nicht? Was kann es gut? Was ist überhaupt im Chatkontext? | `references/modellgrenzen-und-quellen.md` |
| Lückentext, Anti-Schmuggel-Liste, Multi-Turn, Arbeitsteilung Kommando ↔ Modell, Anti-Patterns | `references/patterns.md` |
| Wie teste ich einen neuen Prompt, bevor er produktiv geht? | `references/testprotokoll.md` |
| Welche Tools hat der Chat? Was darf er laut Hersteller? Welches Modell antwortet? Was bringt ein Modellwechsel? | `references/llm-toolebene.md` |
| Welches Werkzeug holt welche Daten? Wie lenke ich eine Teilfrage gezielt auf ein Tool statt auf den Karteivolltext? | `references/toolinventar-und-hebel.md` |
| Wie baue ich einen Kontext im LLM-Textgenerator? Wo liegt er? Welche Kappungen hat die Auslieferung? | `references/llm-textgenerator.md` |

---

## Praxis-Workflow für strukturierte Outputs

1. **Zonen festlegen:** welche Inhalte per Kommando, welche vom Modell (`patterns.md`, Pattern 9)
2. **Anker-Block bauen** und jedes Kommando einzeln auf Auflösung prüfen (`kommando-bibliothek.md`, Abschnitt „Pflichtschritt")
3. **Guard- und Typdefinitions-Block einsetzen** (`anker-guard-typdefinition.md`)
4. **Klassifikations-Prompt** mit Whitelist/Conditional/Blacklist-Trias
5. **Generierungs-Prompt** mit Lückentext, Anti-Schmuggel-Liste und Vorbehalts-Auftrag
6. **Im KarteiChat ausprobieren** (Chat leeren, Prompt 1, ≥30 s, Prompt 2)
7. **Testprotokoll fahren** (`testprotokoll.md`)
8. **Bei Versagen** Pattern-Analyse: welcher Constraint ist gerutscht, welcher Baustein fehlt
9. **Bei Erfolg** Prompt-Strang dokumentieren, ggf. als Textbaustein hinterlegen — **mit** Guard- und Definitionsblock, sonst geht die Wirkung beim Kopieren verloren

---

## Verifikations-Checkliste

```
[ ]  1. Eine Aufgabe pro Prompt
[ ]  2. Lückentext wörtlich, Inhaltsangaben in den Platzhaltern
[ ]  3. Anti-Schmuggel-Liste mit konkreten Begriffen
[ ]  4. Begründungs-Templates wörtlich vorgegeben
[ ]  5. Kein interner Self-Check als Qualitätssicherung
[ ]  6. Mehrfachlauf für produktionskritische Outputs
[ ]  7. Jeder Anker einzeln auf Auflösung geprüft
[ ]  8. Beschriftung des Ankers beschreibt die Kommando-Semantik, nicht den Wunsch
[ ]  9. Guard-Block vorhanden, inklusive Leerfeld-Satz
[ ] 10. Typdefinition über Eintrags-Bezeichnungen vorhanden, wo ein Fachbegriff vorkommt
[ ] 11. Jeder Anker hat eine begleitende Aufgabe
[ ] 12. Keine absolute Zeichenzahl als Vorgabe
[ ] 13. Vorbehalts-Auftrag im Prompt, wenn die Ausgabe nach außen geht
[ ] 14. Keine Abhängigkeit von Anlageninhalten
[ ] 15. Erwartungsanker vor dem ersten Lauf notiert
[ ] 16. Aufgelöster Prompt-Text gesichert
[ ] 17. Strukturvorgabe benennt die Gliederungsachse, nicht nur die Anzahl
[ ] 18. Vollständigkeit ist eigenes Prüfkriterium, nicht nur Form und Fachlichkeit
[ ] 19. Kein Satz im Prompt, der als Schreibauftrag lesbar ist, wenn nur gelesen werden soll
```

---

## Referenzen auf andere Skills

- `tomedo-kommandos` — vollständige Kommando- und Konfigurator-Syntax; verbindlich bei allen `$[…]$`-Fragen
- `tomedo-statistik-hql` — dieselben Definitionen als Query; Quelle der Typ-Abgrenzungen
- `tomedo-textbausteine` — statische Bausteine, in denen Prompt-Stränge hinterlegt werden
- `tomedo-patientenformulare` — CKE- und PatF-Felder anlegen, um Werte über die Verankerungslinie zu schieben

---

## Versionsverlauf

- **v1 (05/2026):** Initialversion nach Prompt-Engineering-Session „Psychotherapeutischer Kurzbericht v7". Patterns 1–7, Modellgrenzen-Tabelle, Anti-Patterns. Monolithisch.
- **v2 (09/2026):** Vollständige Neufassung nach Testserie an synthetischer Demoakte, zugleich Umbau auf Navigator plus `references/` (ADR-SKILL-01).
  - **Widerrufen:** die Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat".
  - **Neu:** Anker-Guard-Typdefinition-Architektur mit belegtem Fehlerkatalog, Kommando-Bibliothek mit praxiseigenen Typkürzeln, belegte Stärken, Quellengrenzen-Tabelle inklusive Anlagen, vollständiger Prompt-Rahmen, Arbeitsteilung Kommando ↔ Modell, Testprotokoll.
  - **Ergänzt:** sechs neue Modellgrenzen (Ankerbindung, Leerfeld-Kollaps, Anker ohne Auftrag, Zeichenvorgaben, asymmetrischer Informationsverlust, Systemdatum), fünf Anti-Patterns, Checkliste von 6 auf 16 Punkte.
  - **Offen:** Trägerkürzel der „Therapie"-Einträge (praxiseigen, mehrere Kürzel unter einer Bezeichnung), Nutzer-Attribution im Chatkontext, Leistungen im Chatkontext.
- **Stand 09/2026, ausgeliefert als Fassung 1.1:** Toolebene ergänzt.
  - **Neu:** `references/toolinventar-und-hebel.md` (Inventar der Werkzeuge, die der Chat
    aufruft); **Werkzeuganweisung** als vierter Prompt-Baustein neben Anker, Guard und
    Typdefinition; Querverweise auf `tomedo-textbausteine` für die Baustein-Seite der
    Markdown- und Emoji-Regeln.
  - **Checkliste auf 19 Punkte.** Aus der Toolebene stammen Punkt 17 (Gliederungsachse statt
    blosser Anzahl) und Punkt 19 (kein Satz, der als Schreibauftrag lesbar ist — es gibt
    schreibende Werkzeuge). Punkt 18 (Vollständigkeit als eigenes Prüfkriterium) stammt aus
    der Arbeit an `anker-guard-typdefinition.md`; wann genau er dazukam, ist nicht mehr
    rekonstruierbar.
  - **Zur Zählung:** Die Fassung steht im Frontmatter unter `metadata.version`. Die frühere
    Fußzeile führte eine zweite, abweichende Zählung und ist deshalb entfallen.

---

*Belegbasis: Testserien 1–3 an Demoakte 03 (108 Karteieinträge, 6 Anlagen), Modellvergleich unter Bedingung A (Kartei-Volltext ohne Anlagen, ohne Spezifikations-Metaebenen). Kernaussage: der wirksamste Prompt-Baustein ist die Typdefinition, der billigste der Guard-Satz, der gefährlichste ein leerer Anker.*
