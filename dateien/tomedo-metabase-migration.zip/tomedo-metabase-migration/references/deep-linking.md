# Deep-Linking Metabase ↔ tomedo

Bidirektionale Verlinkung: aus einer Metabase-Patientenliste in die tomedo-Kartei
springen und umgekehrt aus tomedo ins Patientendashboard.

**Teststand:** 30.07.2026 · Metabase v0.59.4 · macOS · Safari + Chrome ·
Testpatient Max Mustermann, ID 90000005

## Statusübersicht

| Befund | Status |
|---|---|
| `tomedo://patient#<ident>` springt in die Kartei, Safari **und** Chrome | **belegt** |
| `patient.ident` == in tomedo angezeigte Patientennummer | **belegt** |
| Briefkommando für die ID: `$[pid]$` | **belegt** (Kommando-Katalog) |
| Variante A (Tabellenspalte `view_as: link`) funktioniert | **belegt** |
| Cross-Column-Templating (Link auf Spalte X, `{{spalte_y}}` derselben Zeile) | **belegt** |
| `visualization_settings` überleben SQL-Rewrites | **belegt** |
| Text-Card-Markdown wird sanitisiert → Sprung auf `/` statt tomedo | **belegt (negativ)** |
| URL in Notiz-Karteieintrag: klickbar nur im aktivierten Popover, nicht in der Listenansicht | **belegt** |
| Slug wird aus Filter-Label abgeleitet | **belegt** |
| URL-Round-Trip (Parameter treibt Daten) | **offen** |
| Kommando-Auflösung in Notiz-KE / Textbaustein | **offen** |
| AppleScript-Feld löst `$[pid]$` auf | **offen** |
| Guest-Embed: Deep-Link aus sandboxed iframe | **offen** |
| `semantic_type: type/URL` als JSON-freie Alternative | **offen** |
| Variante B (`click_behavior`) | **ungetestet** — nicht nötig, A trägt |
| `tomedo://termin#<ident>` springt in Kalender + Termindetail | **belegt** (Pilot 08/2026) |
| `tomedo://karteieintrag#<ident>` springt in Akte + Eintrag | **belegt** |
| Handler ist REST-Client → 404 erscheint als „Internetverbindung pruefen" | **belegt** |
| `termin.ident`/`karteieintrag.ident` sind 58 Bit → nie durch float | **belegt** |
| `view_as` ohne `link_url` = stumme Spalte | **belegt (negativ)** |
| Klickbarer Link in einem tomedo-**Formularfeld** | **belegt (negativ)**, s. `tomedo-patientenformulare/references/permalink-api.md` |

## Richtung 1 · Metabase → tomedo

### URL-Schema

```
tomedo://patient#<patient.ident>
```

Quelle: forum.tomedo.de/index.php/88760, Antwort zollsoft (M. Pamperin,
17.09.2024), vom Fragesteller bestätigt — und hier eigenständig reproduziert.

**Nur das Fragment (`#`) wird ausgewertet.** `tomedo://patient?patientID=42`
funktioniert nicht.

Weitere in `tomedo.app/Contents/Info.plist` (`CFBundleURLTypes`) registrierte
Schemata: `dokument`, `aufgabe`, `patient`, Familienmitglieder (`mutter`, `vater`,
`sohn`, `tochter`, `ehemann`, `ehefrau`, `grossvater`, `grossmutter`, `bruder`,
`schwester`, `enkelsohn`, `enkeltochter`) sowie `tomedo`. Für `dokument://` und
`aufgabe://` ist **keine Syntax dokumentiert** — ob dort analog `#<ident>` greift,
ist ungetestet.

### SQL-Konvention

```sql
SELECT
    P.ident::text AS patient_id,          -- ::text, siehe Fallstrick 2
    'Kartei öffnen' AS aktion,
    ...
FROM patient P
```

Deep-Links gehören nur in Detail-/Patientenlisten. In aggregierten Zeilen
(`GROUP BY` über mehrere Patienten) existiert keine eindeutige ID.

### Variante A — Spalten-Link (Hausstandard)

UI: Visualisierung → Zahnrad an der Spalte → **Anzeigen als** = `Link` →
**Link-URL** eintragen.

Empfohlene Form mit **Cross-Column-Templating**: Link auf die Klicktext-Spalte
legen, ID aus der Nachbarspalte ziehen. Der Klicktext bleibt lesbar, die rohe URL
steht nicht in der Liste, und die ID-Spalte kann sogar ausgeblendet werden,
solange sie im Result bleibt.

```json
{
  "table.pivot": false,
  "column_settings": {
    "[\"name\",\"aktion\"]": {
      "view_as": "link",
      "link_url": "tomedo://patient#{{patient_id}}"
    }
  }
}
```

### Variante B — click_behavior (Fallback)

Nur auf Dashboard-Ebene, navigiert programmatisch statt über `<a href>`:

```json
{
  "click_behavior": {
    "type": "link",
    "linkType": "url",
    "linkTemplate": "tomedo://patient#{{patient_id}}"
  }
}
```

Variante A wirkt auch in der gespeicherten Frage ohne Dashboard, B nur auf dem
Dashboard. Deshalb ist A der Default; B ist die zweite Chance, falls ein
Sanitizer den `<a href>`-Pfad blockiert.

### Fallstricke

1. **Text-Cards funktionieren nicht.** `[Text](tomedo://patient#42)` in einer
   Dashboard-Text-Card wird vom Markdown-Renderer sanitisiert; der leere Link
   wird vom SPA-Router als Relativpfad gelesen und man landet auf der Metabase-
   Startseite. **Wichtig:** Text-Card und Tabellenspalte sind verschiedene
   Code-Pfade — aus dem Fehlschlag der einen folgt nichts für die andere.
2. **Bei numerischen Spalten fehlt „Link" im Dropdown.** Deshalb `::text` casten.
   Zusätzlich beobachtet: das Dropdown rendert gelegentlich unvollständig (nur
   „Text" sichtbar) und zeigt nach erneutem Öffnen alle Optionen — Browser-
   Rendering-Bug, kein Metabase-Fehler. Wer das umgehen will, setzt die Settings
   per API (`import-scripts.md`).
3. **Spaltenname exakt treffen.** Postgres lowercased unquoted Aliase:
   `AS patientID` landet als `patientid`. Falsches Template = leerer Platzhalter
   = toter Link, ohne Fehlermeldung.
4. **Der Browser löst den Link auf, nicht Metabase.** Funktioniert nur an
   Arbeitsplätzen mit lokal installiertem tomedo (macOS); beim ersten Klick
   bestätigt der Browser einmalig.

5. **`view_as` ohne `link_url` ist stumm.** „Anzeigen als = Link" allein macht **nichts**
   klickbar. Die grauen Texte in *Link-URL* und *Link-Text* sind Metabase-**Beispiele**
   (`Link to {{bird_id}}`, `http://toucan.example/…`), keine Werte. Bleibt *Link-URL* leer,
   ist die Spalte als Link markiert und reagiert trotzdem nicht — erkennbar daran, dass in
   den gespeicherten `visualization_settings` `view_as` steht und `link_url` fehlt.
   Kostet erfahrungsgemaess eine Stunde Suche; der API-Weg (`import-scripts.md`) umgeht die UI.

### Drei belegte Sprungziele

```
tomedo://patient#<patient.ident>              → Kartei des Patienten
tomedo://termin#<termin.ident>                → Kalender auf den Tag + Termin-Detailansicht
tomedo://karteieintrag#<karteieintrag.ident>  → Akte + Eintrag selektiert
```

`termin` und `karteieintrag` loesen den Patientenkontext **selbst** auf — eine zusaetzliche
Patienten-ID im Link ist unnoetig. Die Host-Liste ist eine **handgepflegte Whitelist im
Client**, keine Ableitung aus dem Datenmodell: sieben weitere in `Info.plist` registrierte
Hosts erzeugen mit gueltigen Idents **keinen** Sprung.

### Der Handler ist ein REST-Client, kein lokaler Aufruf

Bei ungueltiger Ident erscheint der Serverfehler im Klartext:

```
Serverfehler 404 ; URL http://<server>:8080/tomedo_live/Termin/<ident> (GET)
```

- **Ohne Serververbindung ist die Navigationsschicht tot**, auch wenn tomedo laeuft.
- **Die Fehlermeldung fuehrt in die Irre:** dem Nutzer wird „Bitte ueberpruefen Sie Ihre
  Internetverbindung" gezeigt. Bei einem toten Link ist die naheliegende Diagnose (Netz)
  fast immer falsch — Ursache ist eine nicht existierende Ident.
- **Folge fuer Tests:** mit erfundenen Idents ist eine Klickstrecke **nicht** pruefbar, weil
  404 und geloeschtes Objekt ununterscheidbar sind. Jeder Deeplink-Test braucht eine echte
  Ident aus der Zieltabelle; `MAX(ident)` ist wegen der Zeitstempel-Basis das neueste Objekt
  und damit der beste Kandidat.

### Ident-Breite: 58 Bit — niemals durch float

`termin.ident` und `karteieintrag.ident` sind 58 Bit breit, Muster `zeitstempel << 19`.
IEEE-754-Double hat 53 Bit Mantisse.

```python
termin_id = int(float(wert))        # FALSCH — rundet, sobald ein tiefes Bit gesetzt ist
termin_id = int(str(wert).strip())  # RICHTIG — Python-int ist beliebig genau
```

Die Falle ist tueckisch, **weil sie heute noch nicht zuschlaegt**: durch die 19 Nullbits am
Ende sind die aktuellen Idents *zufaellig* exakt darstellbar. Der Code funktioniert im Test
und bricht erst, wenn sich die Ident-Vergabe aendert; der Schaden ist dann der irrefuehrende
404 von oben. `patient.ident` ist mit 27 Bit unkritisch. In SQL fuer die Anzeige daher
`T.ident::text` — der Cast hat damit **zwei** Gruende, nicht nur das Link-Dropdown.

### Update-Nachsorge nach jedem tomedo-Update

Die Hosts sind undokumentiert und koennen ohne Ankuendigung entfallen:

```zsh
open 'tomedo://patient#<gueltige-ident>'
open 'tomedo://termin#<gueltige-ident>'
open 'tomedo://karteieintrag#<gueltige-ident>'
```

Ein Fehlschlag heisst: tote Links ohne Fehlermeldung. **Nutzer melden das nicht, sie hoeren
auf zu klicken.** Der Check gehoert in die Update-Nachsorge, nicht in die Bug-Bearbeitung.

### Testleiter (Fehlerursachen isolieren)

Jede Stufe eliminiert genau einen Verdächtigen. Bei direktem Einstieg in Stufe 3
hat man vier gleichzeitig: falsche ID, Template-Schreibweise, Browser-Handler,
Renderer-Sanitizing.

| Stufe | Test | Schließt aus | Ergebnis 30.07.2026 |
|---|---|---|---|
| 0 | Adressleiste / `open 'tomedo://patient#90000005'` | Schema + ID-Semantik | **ok** (Safari, Chrome) |
| 1 | Dashboard-Text-Card mit Markdown-Link | Browser-Handoff aus der Metabase-Seite | **fehlgeschlagen** (Sanitizer) |
| 2 | Card `SELECT 90000005::text AS patient_id, 'öffnen' AS aktion` + Spalten-Link | Tabellen-Renderer + Templating | **ok** |
| 3 | echte Patientenliste | Produktionspfad | offen |
| 4 | dieselbe Card im Guest-Embed | iframe-Sandbox | offen |

## Richtung 2 · tomedo → Metabase

### Korrektur am Projektwissen

`README_Patientendashboard.md`, Schritt 5 nennt
`$[klickbar "…" url="…?patient_id=$[patientenNr]$"]$`. **Beide Kommandos
existieren nicht** — weder `klickbar` noch `patientenNr` stehen im
Kommando-Katalog (~580 Kommandos). Nicht nachbauen.

Korrekt ist:

```
$[pid]$      Patienten-Nummer bzw. Patienten-Id bzw. Patienten-Ident
$[pid_plus X]$        mit Offset
$[pid_infoelement N]$ aus Infoelement, sonst Fallback auf die tomedo-ID
```

Ein Kommando, das Text in einen echten Hyperlink verwandelt, gibt es nicht —
Klickbarkeit kommt von der Umgebung, nicht vom Kommando.

### Vier Wege

**A · Aktionskette + AppleScript** (Ein-Klick, Symbolleisten-Button oder
Tastenkürzel, läuft gegen den selektierten Patienten):

```applescript
do shell script "open " & quoted form of "http://METABASE-HOST:3000/dashboard/7?patient_id=$[pid]$"
```

Offen: ob das Script-Text-Feld Briefkommandos auflöst. Dokumentiert ist
Kommando-Auflösung nur für Aktionsketten-**Bedingungen** (Kommando-Spalte).
Test: Aktionskette mit `display dialog "$[pid]$"` — zeigt der Dialog die Nummer,
trägt der Weg; zeigt er den Rohtext, kennt AppleScript den Patientenkontext nicht.

**B · Karteieintrag-Textbaustein** — Kommando-Auflösung hier gesichert (in
Textbausteinen und Aktionsketten, **nicht** bei handgetipptem Text). Klickbarkeit
belegt, aber zweistufig: erst Karteieintrag aktivieren, dann Link im Popover
klicken. In der Listenansicht ist die URL nur Text. Nebenwirkung: erzeugt pro
Aufruf einen Karteieintrag — als Routine müllt das die Kartei zu. Variante für
Dauerhaftigkeit: einmalig pro Patient als `CAVE` im Patientenkopf statt
wiederholt in der Zeitachse (Klickbarkeit von CAVE-Text ungetestet).

**C · Brief-Vorlage** mit `$[pid]$` — im Textprogramm klickbar, für den Alltag zu
schwer. Verworfen.

**D · Ohne tomedo-Konfiguration** — Nummer kopieren, im Dashboard einfügen.
Als Übergang brauchbar, als Zielzustand verworfen.

### Constraints

- **Guest-Embeds vertragen `?patient_id=` nicht.** Bei gesperrten Embeds steckt
  der Parameter signiert im JWT; ein angehängter Query-String wird ignoriert oder
  abgelehnt. Der Absprung aus tomedo braucht die normale Metabase-URL mit Login —
  oder einen Dienst, der signierte Embed-URLs erzeugt. Für Dashboards in
  Embed-Architektur ist das die härtere Hürde als die Kommando-Frage.
- **`localhost:3000` gilt nur auf dem Docker-Host.** In Kommandos, die an
  mehreren Arbeitsplätzen ausgelöst werden, muss der Servername stehen.

## Plan C — HTTP-Brücke (Reserve)

Falls ein Metabase-Update den Protokoll-Pfad schließt oder Embeds blockieren:
statische Seite auf dem Metabase-Host, z.B. `…:8080/t?p=90000005`, die per JS
`location.href = 'tomedo://patient#' + p` setzt. Der Metabase-Link ist dann
`http`/`https` und passiert jeden Sanitizer; `http`-Navigation aus iframes ist
zudem erlaubt. Kosten: ein zusätzlicher Dienst — ADR-pflichtig, weil es
Infrastruktur hinzufügt. Aktuell nicht nötig, weil Variante A trägt.
