# Query-Übersetzung tomedo HQL → Metabase

Validiert 31.03.2026, ergänzt 30.07.2026.

## 1 · CTE statt TEMPORARY TABLE (Pflicht)

Metabase erlaubt **nur 1 SQL-Statement pro Card**.

```sql
-- FALSCH (Multi-Statement → Metabase-Fehler):
CREATE TEMPORARY TABLE tempEBM AS SELECT ...;
SELECT ... FROM tempEBM;

-- RICHTIG (Single-Statement CTE):
WITH tempEBM AS (
  SELECT ...
)
SELECT ... FROM tempEBM;
```

Mehrstufige Aggregationen als Kette:

```sql
WITH stufe1 AS (...),
     stufe2 AS (SELECT ... FROM stufe1)
SELECT ... FROM stufe2;
```

## 2 · Keine `{{}}` in SQL-Kommentaren

Metabase verarbeitet `{{var}}` **auch in `--`-Kommentaren** → ungewollte
Pflichtfilter und verschobene Fehlerpositionen.

```sql
-- FALSCH: Metabase-Variablen {{jahr}} und {{quartal}} erzeugen Filter-Widgets
-- RICHTIG: Filter: Jahr und Quartal als optionale Widgets
```

Einzige erlaubte Stelle für `{{}}` ist der SQL-Code selbst, meist innerhalb `[[ … ]]`.

## 3 · Tabellen- und Spaltennamen

| Falsch (HQL-Alias, existiert nicht) | Richtig | Pfad |
|---|---|---|
| `leistung.abrechnungscode` | `ebmkatalogeintrag.code` | `A.ebmkatalogeintrag_ident = B.ident` |
| `leistung_leistungsdetails` | `ebmKatalogEintrag_ebmKatalogEintragDetails` | Bridge: `B.ident = J.ebmKatalogEintrag_ident` |
| `leistungsdetail` | `ebmKatalogEintragDetails` | `DET.ident = J.ebmKatalogEintragDetails_ident` + Gültigkeits-JOIN |
| `leistung.stpisstorniert` | `leistung.visible` | HQL-Alias ≠ DB-Spalte |
| `karteieintrag.dtype = 'PHY'` | `karteieintragtyp.kuerzel = 'PHY'` | `KE.karteieintragtyp_ident = KET.ident` |
| `patient.stpistinaktiv` | `patient.gesperrt` | 0/NULL=aktiv, 1=gesperrt |
| `mv.atcbeiverschreibung` | `medikamentenverordnung.atcbeiverordnung` | — |

**EBM-Euro, vollständiger JOIN-Pfad (CTE-kompatibel):**

```sql
LEFT JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
```

**Berechnung (innerhalb `GROUP BY A.ident`):**

```sql
CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
     THEN (A.anzahl * MAX(DET.euroWertInCent)) / 100.0
     ELSE (A.anzahl * A.prozentDerLeistung5013 * MAX(DET.euroWertInCent)) / 10000.00
END::numeric AS euro
```

## 4 · ZS-Filter → Metabase-Variablen

| tomedo ZS-Filter | Metabase | Widget |
|---|---|---|
| `/*{{Tag:NAME;DATE;DEFAULT}}*/` | `{{name}}` (Typ date) | Datepicker |
| `/*{{Tag:NAME;TEXT;DEFAULT}}*/` | `{{name}}` (Typ text) | Texteingabe |
| `/*{{Tag:NAME;TEXT;1}}*/` (Zahl) | `{{name}}` (Typ number) | Zahleneingabe |
| hardcoded, kein ZS-Filter | `[[ AND col = {{var}} ]]` | optional machen |

### Kritische Unterschiede

| Aspekt | tomedo HQL | Metabase |
|---|---|---|
| Multi-Statement | mehrere SELECTs (`-- HIER TRENNEN`) | **nur 1** → CTE |
| ZS-Tags in Temp-Tabellen | werden gelöscht | entfällt |
| `{{}}` in Kommentaren | ignoriert | **werden verarbeitet** |
| Optionale Filter | nur via Default-Wert | `[[ AND … ]]` |
| Dashboard-übergreifend | jede Query eigene Filter | ein Filter → alle Cards |
| Mehrfachauswahl | nicht möglich | `IN ({{var}})` |
| Field Filter (Dropdown) | nicht möglich | `WHERE {{var}}` (ohne Spalte davor!) |
| Tabellennamen | case-insensitive | **case-sensitive** |

### Variablen-Konvention

Lowercase mit Underscore: `{{jahr}}`, `{{quartal}}`, `{{datum_von}}`,
`{{datum_bis}}`, `{{arzt}}`, `{{patient_id}}`.

### Standardmuster optionaler Filter

```sql
WHERE TRUE
  [[ AND EXTRACT(YEAR FROM A.datum)::int = {{jahr}} ]]
  [[ AND S.quartal = {{quartal}} ]]
  [[ AND A.datum >= {{datum_von}} ]]
  [[ AND A.datum <= {{datum_bis}} ]]
```

Ohne führendes `WHERE TRUE` erzeugt die erste optionale Klausel `WHERE AND …`.

## 5 · Dateiformat mit Meta-Header

```sql
-- name: Anzeigename in Metabase
-- description: Was die Kennzahl misst
-- display: bar
-- tags: jahr:number, quartal:number
-- deeplink: patient_id

WITH cte AS (
  SELECT ...
  FROM leistung A
  JOIN kvschein S ON A.invkvschein_ident = S.ident
  LEFT JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
  WHERE A.dtype = 'EBMLeistung' AND A.visible = true AND S.visible = true
  GROUP BY ...
)
SELECT ...
FROM cte
WHERE TRUE
  [[ AND jahr = {{jahr}} ]]
```

| Feld | Pflicht | Werte |
|---|---|---|
| `name` | ja | Anzeigename der Card |
| `description` | nein | Beschreibungstext |
| `display` | nein | `table`, `bar`, `line`, `pie`, `scalar`, `row`, `combo` |
| `tags` | nein | `varname:type`, kommasepariert; `-` wenn keine Filter |
| `deeplink` | nein | Spaltenname für den tomedo-Deep-Link (siehe `import-scripts.md`) |

### Display-Typ nach Kennzahl-Art

| Kennzahl | Display | Grund |
|---|---|---|
| Zeitreihe | `line` | Trend |
| Kategorienvergleich | `bar` | Balken nebeneinander |
| Anteil am Ganzen | `pie` | Verteilung |
| Einzel-KPI | `scalar` | prominente Zahl |
| Detailtabelle | `table` | alle Spalten, Voraussetzung für Deep-Links |
| Ranking/Top-N | `row` | horizontal sortiert |
| Zwei Metriken | `combo` | Balken + Linie |

## 6 · Validierte Cards K01–K12 (31.03.2026)

| Datei | Card | Display | Filter |
|---|---|---|---|
| `00_ebm_leistungen_quartal.sql` | EBM-Leistungen pro Quartal | bar | jahr, quartal |
| `01a_altersstruktur.sql` | K01 Altersstruktur | pie | jahr |
| `01b_neupatienten_bestand.sql` | K01 Neupatienten vs. Bestand | bar | jahr |
| `02_chroniker_segmente.sql` | K02 Chroniker-Segmentierung | pie | jahr |
| `03_aktive_patienten_quartal.sql` | K03 Aktive Patienten pro Quartal | line | jahr |
| `04_interdisziplinaere_quote.sql` | K04 Interdisziplinäre Quote | bar | jahr |
| `05_top_diagnosen.sql` | K05 Top-Diagnosen | row | jahr |
| `06_psych_komorbiditaeten.sql` | K06 Psychische Komorbiditäten | bar | jahr |
| `07_langzeit_chroniker.sql` | K07 Langzeit-Chroniker | scalar | — |
| `08_interventionelle_rate.sql` | K08 Interventionelle Rate | bar | jahr |
| `09_umsatz_segment.sql` | K09 Umsatz pro Segment | bar | jahr |
| `10_wiedervorstellungsrate.sql` | K10 Wiedervorstellungsrate | bar | jahr, quartal |
| `11_goae_umsatz.sql` | K11 GOÄ Privat-Umsatz | table | jahr, quartal |
| `12a_datenqualitaet_medikamente.sql` | K12 Medikamenten-Datenqualität | table | — |
| `12b_top_medikamente.sql` | K12 Top-20 Medikamente | row | — |

## 7 · Die acht häufigen Fehler

1. **Multi-Statement statt CTE** — häufigster Fehler.
2. **Template-Tags in Kommentaren** → Phantom-Filter.
3. **HQL-Alias als DB-Spalte** (`A.abrechnungscode = '30700'` statt Katalog-JOIN auf `B.code`).
4. **ZS-Filter nicht konvertiert** (`/*{{Tag:QUARTAL;TEXT;1}}*/` bleibt stehen).
5. **Optionale Klammern fehlen** → Query bricht ohne Filterwert ab.
6. **Field Filter mit Spalte davor** — richtig ist `WHERE {{geschlecht}}`.
7. **Variable in Großbuchstaben** (`{{QUARTAL}}`).
8. **`database_id` fehlt, ist String oder NULL** → HTTP 500.

Neu ergänzt (30.07.2026):

9. **Spaltenname im Link-Template falsch geschrieben.** `AS patientID` wird von
   Postgres zu `patientid`; das Template muss den Result-Namen exakt treffen,
   sonst bleibt der Platzhalter leer und der Link ist tot — ohne Fehlermeldung.
10. **Dashboard-Filter ohne `parameter_mappings`.** Der Filter erscheint, setzt
    URL-Parameter, filtert aber nichts. Sieht funktionierend aus, ist es nicht.
