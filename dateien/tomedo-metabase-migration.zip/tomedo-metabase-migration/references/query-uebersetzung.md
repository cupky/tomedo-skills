# Query-Übersetzung tomedo HQL → Metabase

Validiert 31.03.2026, ergänzt 30.07.2026; tomedo-Seite (ZS-Tags, Ergebnisfenster)
überarbeitet im Oktober 2026. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz prüfen.

## 1 · CTE statt TEMPORARY TABLE (Pflicht)

Metabase erlaubt **nur 1 SQL-Statement pro Card**.

```sql
-- FALSCH (Multi-Statement → Metabase-Fehler):
CREATE TEMPORARY TABLE tempEBM AS SELECT ...;
SELECT ... FROM tempEBM;

-- RICHTIG (Single-Statement CTE):
WITH tempEBM AS (
  SELECT ...
)
SELECT ... FROM tempEBM;
```

Mehrstufige Aggregationen als Kette:

```sql
WITH stufe1 AS (...),
     stufe2 AS (SELECT ... FROM stufe1)
SELECT ... FROM stufe2;
```

## 2 · Keine `{{}}` in SQL-Kommentaren

Metabase verarbeitet `{{var}}` **auch in `--`-Kommentaren** → ungewollte
Pflichtfilter und verschobene Fehlerpositionen.

```sql
-- FALSCH: Metabase-Variablen {{jahr}} und {{quartal}} erzeugen Filter-Widgets
-- RICHTIG: Filter: Jahr und Quartal als optionale Widgets
```

Einzige erlaubte Stelle für `{{}}` ist der SQL-Code selbst, meist innerhalb `[[ … ]]`.

## 3 · Tabellen- und Spaltennamen

| Falsch (HQL-Alias, existiert nicht) | Richtig | Pfad |
|---|---|---|
| `leistung.abrechnungscode` | `ebmkatalogeintrag.code` | `A.ebmkatalogeintrag_ident = B.ident` |
| `leistung_leistungsdetails` | `ebmKatalogEintrag_ebmKatalogEintragDetails` | Bridge: `B.ident = J.ebmKatalogEintrag_ident` |
| `leistungsdetail` | `ebmKatalogEintragDetails` | `DET.ident = J.ebmKatalogEintragDetails_ident` + Gültigkeits-JOIN |
| `leistung.stpisstorniert` | `leistung.visible` | HQL-Alias ≠ DB-Spalte |
| `karteieintrag.dtype = 'PHY'` | `karteieintragtyp.kuerzel = 'PHY'` | `KE.karteieintragtyp_ident = KET.ident` |
| `patient.stpistinaktiv` | `patient.gesperrt` | 0/NULL=aktiv, 1=gesperrt |
| `mv.atcbeiverschreibung` | `medikamentenverordnung.atcbeiverordnung` | — |

**EBM-Euro, vollständiger JOIN-Pfad (CTE-kompatibel):**

```sql
LEFT JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
```

**Berechnung (innerhalb `GROUP BY A.ident`):**

```sql
CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
     THEN (A.anzahl * MAX(DET.euroWertInCent)) / 100.0
     ELSE (A.anzahl * A.prozentDerLeistung5013 * MAX(DET.euroWertInCent)) / 10000.00
END::numeric AS euro
```

### Cards, die ein Programm liest

**Spaltennamen sind ein Vertrag, sobald eine Card per API gelesen wird.** Beim Zugriff ueber
`POST /api/card/<id>/query/json` sind die Aliase eine Schnittstelle, kein Layout — Umbenennen bricht
den Konsumenten still. Alias einmal festlegen, im Meta-Header dokumentieren, danach nicht mehr
anfassen. Auch dann nicht, wenn der Name ungluecklich ist: ein Alias wie `zeitkonto_kuerzel` fuer
`nutzer.kuerzel` bleibt, wenn er schon gelesen wird.

Drei Folgeregeln fuer maschinell gelesene Cards:

- **`timestamp` mit `::date` casten**, wenn tagesweise verglichen wird. Ohne Cast liefert der
  JSON-Export einen Zeitstempel; der Vergleich gegen eine Tagesliste scheitert dann an der Uhrzeit,
  nicht am Datum. Betrifft u. a. `terminkalendertag.tag`, `termin.beginn`, `leistung.datum`.
- **Zeilenlimit pruefen.** Dashboard-Cards leben mit einer Kappung, ein Abgleich nicht: eine
  abgeschnittene Liste sieht wie ein Zustand aus. Vor Inbetriebnahme gegen die erwartete
  Zeilenzahl pruefen und den Wachstumspfad abschaetzen (Realfall: heute <400 Zeilen, ueber ein
  Jahr einige Tausend).
- **Kein abschliessendes Semikolon** — native Fragen stolpern darueber (gilt ohnehin, hier aber
  ohne Mensch, der die Fehlermeldung liest).

Traegt das Ergebnis Personenbezug ohne Patientenbezug (Mitarbeiterkuerzel, Abwesenheitstage,
Dokumentationsverzug), gehoert die Card in eine **Sammlung mit eingeschraenktem Zugriff**, und beim
Entwickeln werden **Zaehlungen statt Einzelzeilen** geprueft.

## 4 · ZS-Filter → Metabase-Variablen

tomedo-Statistiken tragen ihre Filter als **ZS-Tags** im SQL: `<ZS:bezeichner> TYP;Feld;…;Feld </ZS>`.
Die vollständige Syntax steht im Skill `tomedo-statistik-hql` (`references/zs-filter.md`). Für die Übersetzung
reicht: Jeder Tag ist **ein Filter mit Checkbox** im Statistikfenster. Ist er angehakt, setzt tomedo an seiner
Stelle ein SQL-Stück ein, sonst verschwindet der ganze Tag. Darum steht das verbindende `and` meist **im** Tag.
In Metabase wird daraus eine optionale Klausel `[[ AND … {{var}} ]]`.

Eine Schreibweise `/*{{Tag:NAME;TYP;DEFAULT}}*/` gibt es in tomedo nicht; tomedo verarbeitet `{{…}}` überhaupt
nicht. Der Bezeichner hinter `<ZS:` besteht nur aus Buchstaben und Ziffern — für die Metabase-Variable nicht
übernehmen, sondern nach der Konvention unten neu benennen.

Typen, Bedienelemente und eingesetztes SQL nach aktuellem Stand **[ungeprüft]**; die Spalte Metabase ist der
Übersetzungsvorschlag.

| tomedo-Typ (Bedienelement) | was tomedo einsetzt | Metabase |
|---|---|---|
| `DATE` (Datumsfeld, Start immer heute) | `(<Spalte> <Operator> 'Datum Uhrzeit')` + `and` | `[[ AND <Spalte> >= {{datum_von}} ]]`, Typ Datum |
| `DAY` (ein Tag) | ganzer Tag 00:00 bis 23:59 | `[[ AND <Spalte>::date = {{tag}} ]]`, Typ Datum |
| `QUARTAL`, `QUARTAL2` …, `QUARTALORCURRENT` (Klappmenü, Start aktuelles Quartal) | Datumsbereich bzw. Vergleich mit Quartal- und Jahresspalte | `{{jahr}}` + `{{quartal}}` (Zahl) oder `{{datum_von}}`/`{{datum_bis}}`; „aktuelles Quartal“ als Start nur mit Field Filter auf eine Datumsspalte |
| `MONAT` (Monat + Jahr) | Monatsbereich | `{{jahr}}` + `{{monat}}` (Zahl) |
| `STRING` (Textfeld mit Operator: enthält, ist, beginnt mit, „ist einer der folgenden“ …) | `ilike`-Ausdruck | `[[ AND <Spalte> ILIKE '%' \|\| {{text}} \|\| '%' ]]`, Typ Text; den Operator legt das SQL fest |
| `NUMBER` (Zahl mit =, >, <) | `<Spalte> = n` | `[[ AND <Spalte> = {{zahl}} ]]`, Typ Zahl |
| `SELECTION` (Klappmenü, jede Option bringt ihr eigenes SQL-Stück mit) | SQL der gewählten Option | Metabase setzt keine SQL-Stücke ein: Textvariable mit fester Werteliste, das SQL wertet den Wert aus, z. B. `[[ AND (({{privat}} = 'Ja' AND PD.privatpatient) OR ({{privat}} = 'Nein' AND NOT PD.privatpatient)) ]]` |
| `NUTZERSELECTION` (Klappmenü Nutzerkürzel) | Kürzel im SQL | Textvariable `{{arzt}}` oder Field Filter auf die Kürzelspalte |
| `BETRIEBSSTAETTENSELECTION` (Mehrfachauswahl) | `<Spalte> IN (…)` | Field Filter auf die Betriebsstätten-Spalte: `[[ AND {{bs}} ]]` |
| `TAG` (Marker, Mehrfachauswahl mit UND/ODER) | Vergleich mit der Markerliste | Zahlvariable `[[ AND {{marker}} = ANY(<Markerspalte>) ]]` — nur ein Marker |
| `CUSTOM` (Klappmenü Karteieintragstyp) | `<Spalte> = 'Kürzel'` | Textvariable `{{typ}}` |
| `VOLLTEXT` | `to_tsquery('german', …)` | `[[ AND <tsvector-Ausdruck> @@ to_tsquery('german', {{suche}}) ]]` |
| `LIMIT` | ` limit n ` | weglassen (Metabase begrenzt selbst) oder `[[ LIMIT {{limit}} ]]` am Ende |
| `HINWEIS` | nur Text im Dialog | Beschreibung der Card |
| `IDLIST`, `ONLYONJOIN` | nur bei verknüpften Listen, sonst nichts | streichen; Verknüpfung über Dashboard-Filter bzw. Klick auf `{{patient_id}}` |
| `<ZSBLOCK>…</ZSBLOCK>` | leer → `true`, sonst Klammer ohne führendes/abschließendes `and`/`or` | Bedingungen ausschreiben |
| `<ZSPLACEHOLDER>name;…` und `name;INSERT` | denselben Text mehrfach einsetzen | dieselbe Variable mehrfach verwenden (erlaubt) |
| `NUMBERPARAMETER`, `SELECTIONPARAMETER`, `STRINGPARAMETER` | Werte für eine Nachbearbeitung in tomedo bzw. roher Text | keine Entsprechung; Logik ins SQL holen oder weglassen |
| hart codierter Wert, kein Tag | – | `[[ AND col = {{var}} ]]`, optional machen |

**Statistiktyp „Patientbezogen“** (Statistikverwaltung, Auswahl neben „SQL“) enthält kein SQL, sondern eine Formel
aus den Kürzeln anderer Statistiken (Vereinigung, Schnitt, Differenz) **[ungeprüft]**. Nicht direkt übersetzbar:
die Einzelstatistiken als SQL holen und mit `UNION` / `INTERSECT` / `EXCEPT` in CTEs nachbauen.

### Kritische Unterschiede

| Aspekt | tomedo-Statistik | Metabase |
|---|---|---|
| Anweisungen | mehrere Anweisungen mit `;` in einer Statistik (z. B. Temp-Tabellen); tomedo schickt den Text am Stück | **nur 1** → CTE |
| Filter im Temp-Tabellen-Teil | ZS-Tags wirken an ihrer Stelle, auch dort | Bedingung in die passende CTE schreiben |
| Platzhalter in Kommentaren | `{{}}` kennt tomedo nicht; ein `<ZS…>`-Tag wird **auch in `--`-Kommentaren** erkannt **[ungeprüft]** | `{{}}` wird **auch in Kommentaren** verarbeitet |
| Optionale Filter | Checkbox je Filter; Pflicht über eine Kennziffer im Tag | `[[ AND … ]]`; Pflicht über den Schalter der Variable |
| Startwert | fest: heute, aktuelles Quartal, aktueller Monat; benannte Vorauswahlen merken ein Datum relativ zu heute | fester Wert; relativ nur über Field Filter auf Datumsspalten |
| Klappmenü | `SELECTION` u. a.; jede Option bringt SQL mit | Werteliste; das SQL wertet den Wert aus |
| Mehrfachauswahl | Betriebsstätten, Marker, Text „ist einer der folgenden“ | Field Filter `WHERE {{var}}` (ohne Spalte davor!) |
| Dashboard-übergreifend | jede Statistik eigene Filter | ein Filter → alle Cards |
| Tabellennamen | Schreibweise egal (Messbefund; tomedo schickt den Text unverändert, aufgelöst wird am Server) | **case-sensitive** |
| Gesperrte Patienten | blendet tomedo nach dem Abruf aus **[ungeprüft]** | sichtbar (§8) |

### Variablen-Konvention

Lowercase mit Underscore: `{{jahr}}`, `{{quartal}}`, `{{datum_von}}`,
`{{datum_bis}}`, `{{arzt}}`, `{{patient_id}}`.

### Standardmuster optionaler Filter

```sql
WHERE TRUE
  [[ AND EXTRACT(YEAR FROM A.datum)::int = {{jahr}} ]]
  [[ AND S.quartal = {{quartal}} ]]
  [[ AND A.datum >= {{datum_von}} ]]
  [[ AND A.datum <= {{datum_bis}} ]]
```

Ohne führendes `WHERE TRUE` erzeugt die erste optionale Klausel `WHERE AND …`.

## 5 · Dateiformat mit Meta-Header

```sql
-- name: Anzeigename in Metabase
-- description: Was die Kennzahl misst
-- display: bar
-- tags: jahr:number, quartal:number
-- deeplink: patient_id

WITH cte AS (
  SELECT ...
  FROM leistung A
  JOIN kvschein S ON A.invkvschein_ident = S.ident
  LEFT JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
  WHERE A.dtype = 'EBMLeistung' AND A.visible = true AND S.visible = true
  GROUP BY ...
)
SELECT ...
FROM cte
WHERE TRUE
  [[ AND jahr = {{jahr}} ]]
```

| Feld | Pflicht | Werte |
|---|---|---|
| `name` | ja | Anzeigename der Card |
| `description` | nein | Beschreibungstext |
| `display` | nein | `table`, `bar`, `line`, `pie`, `scalar`, `row`, `combo` |
| `tags` | nein | `varname:type`, kommasepariert; `-` wenn keine Filter |
| `deeplink` | nein | Spaltenname für den tomedo-Deep-Link (siehe `import-scripts.md`) |

### Display-Typ nach Kennzahl-Art

| Kennzahl | Display | Grund |
|---|---|---|
| Zeitreihe | `line` | Trend |
| Kategorienvergleich | `bar` | Balken nebeneinander |
| Anteil am Ganzen | `pie` | Verteilung |
| Einzel-KPI | `scalar` | prominente Zahl |
| Detailtabelle | `table` | alle Spalten, Voraussetzung für Deep-Links |
| Ranking/Top-N | `row` | horizontal sortiert |
| Zwei Metriken | `combo` | Balken + Linie |

## 6 · Validierte Cards K01–K12 (31.03.2026)

| Datei | Card | Display | Filter |
|---|---|---|---|
| `00_ebm_leistungen_quartal.sql` | EBM-Leistungen pro Quartal | bar | jahr, quartal |
| `01a_altersstruktur.sql` | K01 Altersstruktur | pie | jahr |
| `01b_neupatienten_bestand.sql` | K01 Neupatienten vs. Bestand | bar | jahr |
| `02_chroniker_segmente.sql` | K02 Chroniker-Segmentierung | pie | jahr |
| `03_aktive_patienten_quartal.sql` | K03 Aktive Patienten pro Quartal | line | jahr |
| `04_interdisziplinaere_quote.sql` | K04 Interdisziplinäre Quote | bar | jahr |
| `05_top_diagnosen.sql` | K05 Top-Diagnosen | row | jahr |
| `06_psych_komorbiditaeten.sql` | K06 Psychische Komorbiditäten | bar | jahr |
| `07_langzeit_chroniker.sql` | K07 Langzeit-Chroniker | scalar | — |
| `08_interventionelle_rate.sql` | K08 Interventionelle Rate | bar | jahr |
| `09_umsatz_segment.sql` | K09 Umsatz pro Segment | bar | jahr |
| `10_wiedervorstellungsrate.sql` | K10 Wiedervorstellungsrate | bar | jahr, quartal |
| `11_goae_umsatz.sql` | K11 GOÄ Privat-Umsatz | table | jahr, quartal |
| `12a_datenqualitaet_medikamente.sql` | K12 Medikamenten-Datenqualität | table | — |
| `12b_top_medikamente.sql` | K12 Top-20 Medikamente | row | — |

## 7 · Häufige Fehler

1. **Multi-Statement statt CTE** — häufigster Fehler.
2. **Template-Tags in Kommentaren** → Phantom-Filter.
3. **HQL-Alias als DB-Spalte** (`A.abrechnungscode = '30700'` statt Katalog-JOIN auf `B.code`).
4. **ZS-Tag nicht konvertiert** (`<ZS:q> QUARTAL;Quartal;A.datum;and </ZS>` bleibt stehen → Syntaxfehler bei `<`).
5. **Optionale Klammern fehlen** → Query bricht ohne Filterwert ab.
6. **Field Filter mit Spalte davor** — richtig ist `WHERE {{geschlecht}}`.
7. **Variable in Großbuchstaben** (`{{QUARTAL}}`).
8. **`database_id` fehlt, ist String oder NULL** → HTTP 500.

Neu ergänzt (30.07.2026):

9. **Spaltenname im Link-Template falsch geschrieben.** `AS patientID` wird von
   Postgres zu `patientid`; das Template muss den Result-Namen exakt treffen,
   sonst bleibt der Platzhalter leer und der Link ist tot — ohne Fehlermeldung.
10. **Dashboard-Filter ohne `parameter_mappings`.** Der Filter erscheint, setzt
    URL-Parameter, filtert aber nichts. Sieht funktionierend aus, ist es nicht.

Neu ergänzt (22.10.2026):

11. **`patientid` und `patient_id` vermischt.** tomedo erkennt nur `patientid`, die
    Metabase-Konvention ist `patient_id` (§8). Wer die tomedo-Fassung umbenennt, verliert dort
    den Sprung in die Kartei; wer die Metabase-Fassung nicht umbenennt, bricht die Link-Templates.
12. **Zahlenvergleich ohne gesperrte Patienten.** tomedo blendet Zeilen gesperrter Patienten aus,
    Metabase nicht (§8). Eine Abweichung der Zeilenzahl ist dann kein Übersetzungsfehler.

## 8 · Ergebnisspalten: was tomedo daraus macht

Wer eine Kennzahl in tomedo prüft (Phase 1) und in Metabase nachbaut, vergleicht zwei Darstellungen derselben
Daten. Die folgenden Unterschiede kommen vom tomedo-Statistikfenster, nicht von der Datenbank. Alles in diesem
Abschnitt ist **[ungeprüft]**, soweit nicht anders vermerkt.

### Sonderspalten

Das Ergebnisfenster wertet bestimmte Spaltennamen aus — **kleingeschrieben, ohne Unterstrich**:

| Spalte | in tomedo (Doppelklick, Knopf „Aktionen…“) | in Metabase |
|---|---|---|
| `patientid` | öffnet die Kartei; Patientenliste, Marker, Serienbrief, Serien-AppleScript, verknüpfte Listen | Link `tomedo://patient#{{patientid}}` |
| `karteieintragid` (zusammen mit `patientid`) | öffnet die Kartei am Eintrag | Link `tomedo://karteieintrag#{{karteieintragid}}` |
| `terminid` | öffnet den Termin | Link `tomedo://termin#{{terminid}}` |
| `besuchid`, `scheinid`, `privatrechnungid`, `formular_ident`, `aufgabeid` … | öffnen Besuch, Schein, Rechnung, Formular, Aufgabe | meist nicht nötig |

`patient_id` erkennt tomedo **nicht**. Die Metabase-Konvention dieses Skills (`patient_id`, SKILL.md
„ID-Namenskonvention“) und die tomedo-Konvention (`patientid`) widersprechen sich. Regel: In der tomedo-Fassung heißt
die Spalte `patientid` und bleibt eine Zahl; beim Übersetzen bewusst in `patient_id` (als `::text`) umbenennen und die
Umbenennung im Meta-Header vermerken. Nie stillschweigend mischen.

### Gesperrte Patienten

Enthält das Ergebnis `patientid`, entfernt tomedo nach dem Abruf alle Zeilen, die der angemeldete Nutzer wegen
Patientenzugriffsrechten nicht sehen darf. Metabase kennt diese Rechte nicht: Zeilenzahlen und Summen können höher
liegen, und die Liste zeigt Patienten, die in tomedo verborgen sind. Darum gehören Patientenlisten in eine Sammlung
mit eingeschränktem Zugriff (SKILL.md „Datenschutz by Design“).

### Spaltentypen

Das tomedo-Statistikfenster versteht nur `bool`, `int2`/`int4`/`int8`, `float4`/`float8`, `numeric`, `timestamp`,
`date`, `text`/`varchar`, `interval` und `money`. Soll dieselbe Abfrage in beiden Systemen laufen, andere Typen
casten: `now()` liefert `timestamptz` → `now()::timestamp`; Arrays und `json` → `::text`.

### Darstellung in tomedo (für den Zahlenvergleich)

- Datum `dd.MM.yyyy HH:mm:ss` bzw. `dd.MM.yyyy`; Wahrheitswerte `J`/`N`; Zahlen ohne Tausenderpunkt; `money` ohne
  Währungszeichen; Dezimalzahlen auf 6 Nachkommastellen gerundet.
- Spaltenüberschrift = Alias mit großem Anfangsbuchstaben, `_` wird Leerzeichen.
- **Summenzeile automatisch** für Zahlenspalten — außer Spalten, deren Name auf `id` endet, sowie `jahr`, `quartal`,
  `bsnr`, `lanr`, `steigerungsfaktor`; für `jahre` steht dort der Mittelwert. Eine Metabase-Tabelle hat keine solche
  Zeile: Summen als eigene `scalar`-Card.
- Bei einer Spalte `geburtsdatum` fügt tomedo selbst die Spalten `jahre` und `alter_exakt` hinzu. Die gibt es in
  Metabase nicht (und `geburtsdatum` gehört ohnehin nicht ins Ergebnis).
- Keine Diagramme und kein Zeilenlimit: tomedo zeigt alles, was zurückkommt.
- Einige mitgelieferte Statistiken werden nach dem Abruf in tomedo weiterverarbeitet (z. B. Summen- und
  Zeitbedarfslisten, OP-Plan). Ihr SQL liefert in Metabase andere Zahlen als das tomedo-Fenster — Prüfwerte dann
  aus dem SQL-Ergebnis ableiten, nicht aus der Anzeige.

### Export als Prüfwert-Quelle

„Aktionen… › Export › CSV-Datei“ schreibt die Kopfzeile mit den **rohen Spaltennamen** (Aliase), Trennzeichen
wählbar (Standard Semikolon), Kodierung wählbar, Summenzeile optional, nur sichtbare Spalten, Werte wie angezeigt
(Datum deutsch, `J`/`N`). Der Excel-Export schreibt Datumswerte als Text. Ein Auto-Statistik-Export schreibt nur CSV
in einen Ordner und läuft nur auf dem Arbeitsplatz, an dem er eingerichtet ist, solange tomedo dort läuft — kein
Ersatz für eine Metabase-Abfrage.
