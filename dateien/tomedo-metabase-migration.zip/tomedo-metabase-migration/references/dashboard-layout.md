# Dashboard-Layout, Filter und URL-Parameter

## Grid und Kartengrößen

Metabase-Grid: **24 Spalten** breit, beliebig viele Zeilen (~55 px pro Zeile).

| Layout-Typ | size_x | size_y | Verwendung |
|---|---|---|---|
| Volle Breite | 24 | 8 | Hauptchart, Tabelle |
| Halbe Breite | 12 | 8 | zwei Charts nebeneinander |
| Drittel | 8 | 6 | drei KPIs |
| KPI-Kachel | 6 | 4 | Einzelzahl |

### Layout-Algorithmus (Import-Skript)

Ableitung aus `-- display:`:

- `scalar` → 6×4 (vier passen nebeneinander)
- `pie`, `bar` → 12×8
- `line`, `table`, `row`, `combo` → 24×8

Cards werden zeilenweise aufgefüllt; passt eine Card nicht mehr in die Zeile,
beginnt eine neue. Für One-Pager (1920×1080) gilt: ~21 Zeilen × 55 px plus
60 px Topbar; mit `?fullscreen=true` ohne Scrollen darstellbar.

## Dashboard-Filter

```json
{
  "parameters": [
    { "id": "jahr_filter",    "name": "Jahr",    "slug": "jahr",    "type": "number/=", "default": null },
    { "id": "quartal_filter", "name": "Quartal", "slug": "quartal", "type": "number/=", "default": null }
  ]
}
```

Verbindung zur Card:

```json
{
  "parameter_mappings": [
    { "parameter_id": "jahr_filter", "card_id": 1, "target": ["variable", ["template-tag", "jahr"]] }
  ]
}
```

## Slug-Mechanik (belegt 30.07.2026)

- Der **Slug wird aus dem Filter-Label abgeleitet** und ist im UI nicht direkt
  editierbar. Label „Patient" → Slug `patient`, Label „Patient ID" → `patient_id`.
  Wer einen bestimmten Slug braucht, benennt das Label entsprechend — oder setzt
  den Slug per API, muss dann aber mit auseinanderlaufendem Label und Slug leben
  (nicht empfohlen, kostet spätere Debugging-Zeit).
- Slug deterministisch auslesen statt aus der Adressleiste raten:
  `GET /api/dashboard/{id}` im eingeloggten Browser → `parameters[].slug`.
- Filtertyp für Patienten-IDs: `number/=`.
- URL-Form: `…/dashboard/7?patient_id=90000005`. Der **numerische Präfix
  genügt** (`dashboard/7`); der Titel-Teil im Pfad ändert sich beim Umbenennen,
  die ID nicht — für Links aus Fremdsystemen immer nur die ID verwenden.

## Drei Parameter-Fallen

**1 · `default` maskiert den Test.** Steht auf dem Parameter ein
`"default":[90000005]`, startet das Dashboard immer mit diesem Wert — auch bei
URL ohne Parameter. Ein „Widget war vorbefüllt" beweist dann nichts. Zum Testen
Default löschen **oder** mit einem anderen Wert prüfen (besser, weil es
Kausalität zeigt statt Abwesenheit).

**2 · Leeres `parameter_mappings`.** Ist der Filter keiner Card zugeordnet
(`"parameter_mappings": []`, dashboardseitig `"param_fields": {}`), setzt die URL
den Parameter, aber nichts filtert. Für Absprünge aus Fremdsystemen ist das der
gefährlichste Zustand: sieht funktionierend aus, liefert falsche Daten.

**3 · Inline-Parameter der Karte.** Filter können auch an einer Dashcard hängen
(`inline_parameters: ["<id>"]`) statt am Dashboard-Kopf. Sie erscheinen mit in der
URL, auch leer (`?id=&patient_id=…`). Leere Parameter sind wirkungslos und
gehören aus Links entfernt.

## Selbstbeweisender Round-Trip-Test

Eine URL, die einen Filter setzt, der nichts filtert, ist der Standardfehler.
Deshalb so testen, dass der angezeigte Wert *der* Parameter ist:

```sql
SELECT {{patient_id}}::text AS patient_id, 'Sprungziel' AS aktion
```

1. Variablentyp `Zahl`, Card speichern.
2. Dashboard-Filter mit der Card-Variable verbinden, `default` löschen.
3. `…/dashboard/7?patient_id=90000006` in einem frischen Fenster aufrufen.
4. Zeigt die Zelle `90000006`, treibt der URL-Parameter die Daten.
