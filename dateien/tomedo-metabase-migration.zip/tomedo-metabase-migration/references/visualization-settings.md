# visualization_settings — Templates und Semantik

Metabase setzt brauchbare Defaults; leeres `{}` funktioniert fast immer.
Diese Referenz für Feintuning und für alles, was per API gesetzt wird.

## Grundsemantik

`visualization_settings` ist ein flaches JSON-Objekt auf der Card. Zwei Ebenen sind
zu unterscheiden:

- **Card-Ebene** — hängt an der gespeicherten Frage, wirkt überall.
- **Dashcard-Ebene** — hängt am Dashboard-Element. Hat eine Dashcard eigene
  Settings, **gewinnen diese** über die Card-Settings. Häufige Ursache für
  „meine Einstellung wirkt nicht".

### Spaltenbezug: `column_settings`

Schlüssel ist ein **JSON-String** mit dem Result-Spaltennamen:

```json
{
  "column_settings": {
    "[\"name\",\"umsatz_euro\"]": { "number_style": "currency", "currency": "EUR" }
  }
}
```

Drei Konsequenzen, alle 30.07.2026 belegt:

1. **Byteidentisch wiederverwendbar.** Der Key referenziert keine Card-ID →
   ein Snippet passt auf jede Card, sofern der Spaltenname gleich ist. Grundlage
   der projektweiten `patient_id`-Konvention.
2. **Sticky über SQL-Rewrites.** Settings bleiben erhalten, wenn die Query
   geändert wird. Beleg: nach mehreren Rewrites stand in einer Test-Card noch
   `"table.cell_column":"nachname"` — eine Spalte, die die Query längst nicht
   mehr lieferte.
3. **Bricht still beim Umbenennen.** Ändert sich der Spaltenname, greift der Key
   nicht mehr; die Formatierung verschwindet ohne Fehlermeldung.

### Merge, nicht ersetzen

Beim Setzen per API immer erst GET, dann `dict`-Merge. Ein Überschreiben von
`column_settings` löscht Ampelfarben, Suffixe und Währungsformate mit
(siehe `import-scripts.md`).

## Templates pro Chart-Typ

### Balken (bar)
```json
{
  "graph.dimensions": ["quartal"],
  "graph.metrics": ["anzahl_leistungen"],
  "graph.x_axis.title_text": "Quartal",
  "graph.y_axis.title_text": "Anzahl",
  "graph.show_values": true,
  "graph.label_values_frequency": "fit",
  "stackable.stack_type": null
}
```

### Linie (line)
```json
{
  "graph.dimensions": ["quartal"],
  "graph.metrics": ["patienten"],
  "graph.x_axis.title_text": "Quartal",
  "graph.y_axis.title_text": "Patienten",
  "graph.show_goal": false,
  "graph.show_trendline": true
}
```

### Kreis (pie)
```json
{
  "pie.show_legend": true,
  "pie.show_total": true,
  "pie.percent_visibility": "inside"
}
```

### Einzelzahl (scalar)
```json
{
  "scalar.field": "umsatz_euro",
  "scalar.switch_positive_negative": false,
  "column_settings": {
    "[\"name\",\"umsatz_euro\"]": { "number_style": "currency", "currency": "EUR" }
  }
}
```

### Tabelle (table)
```json
{
  "table.pivot": false,
  "column_settings": {
    "[\"name\",\"umsatz_euro\"]": { "number_style": "currency", "currency": "EUR", "decimals": 2 },
    "[\"name\",\"quote_pct\"]":   { "number_style": "percent", "decimals": 1 }
  }
}
```

Für klickbare Patientenlisten siehe `deep-linking.md` → Variante A.

### Combo
```json
{
  "graph.dimensions": ["quartal"],
  "graph.metrics": ["anzahl", "umsatz_euro"],
  "series_settings": {
    "anzahl": { "display": "bar" },
    "umsatz_euro": { "display": "line", "axis": "right" }
  }
}
```

### Horizontale Balken (row)
```json
{
  "graph.dimensions": ["goae_code"],
  "graph.metrics": ["umsatz_euro"],
  "graph.show_values": true
}
```

### Ampelfarben in Zellen (column_formatting)
```json
{
  "column_settings": {
    "[\"name\",\"NRS aktuell\"]": {
      "column_formatting": [
        { "operator": "<=", "value": 3, "color": "#84BB4C" },
        { "operator": "between", "min_value": 4, "max_value": 6, "color": "#F9D45C" },
        { "operator": ">=", "value": 7, "color": "#ED6E6E" }
      ]
    }
  }
}
```

### Gauge-Segmente
```json
{
  "gauge.segments": [
    { "min": 0, "max": 1, "color": "#84BB4C", "label": "latent" },
    { "min": 1, "max": 2, "color": "#F9D45C", "label": "moderat" },
    { "min": 2, "max": 3, "color": "#ED6E6E", "label": "manifest" }
  ]
}
```

## Semantischer Feldtyp als Alternative

Statt `column_settings` kann ein Feld über `result_metadata[].semantic_type`
(z.B. `type/URL`) typisiert werden. Status: **ungetestet**. Der Verdacht ist,
dass Metabase `result_metadata` bei nativen Queries neu ableitet und den manuell
gesetzten Typ verwirft — was die Variante für Produktion disqualifizieren würde,
weil der Link bei jeder SQL-Änderung still ausfällt. Testprotokoll in
`deep-linking.md`.
