# Import- und Settings-Automatisierung (Metabase API)

Ziel: Cards, Layouts und `visualization_settings` sind Teil des Deployments, nicht
Handarbeit im UI. Nebeneffekt: umgeht UI-Rendering-Bugs (siehe `deep-linking.md`,
Fallstrick 2).

## Bestehende Scripts

| Script | Zweck |
|---|---|
| `metabase_import.py` | liest alle `.sql` aus `queries/`, erstellt Cards, nutzt die Meta-Header (`-- name:`, `-- display:`, `-- tags:`) zur Konfiguration |
| `metabase_update_viz.py` | wendet `visualization_settings_per_card` aus dem Layout-JSON auf bestehende Cards an |

## Pflichtvalidierung: database_id

```python
DB_ID = config["database_id"]
assert isinstance(DB_ID, int) and DB_ID >= 1, f"database_id muss int >= 1 sein, ist: {DB_ID!r}"
```

NULL oder String → HTTP 500 `NULL not allowed for column "DATABASE_ID"`.
Zu finden unter Admin → Databases → DB anklicken → URL zeigt `/admin/databases/N`.

## Partielles PUT statt Vollobjekt

`PUT /api/card/{id}` akzeptiert Teilobjekte. Immer nur das Feld senden, das
geändert wird — ein Vollobjekt-PUT riskiert, `result_metadata` oder
`dataset_query` zu beschädigen.

## Deep-Link per Script setzen

```python
import json

def apply_deeplink(session, base, card_id, id_col="patient_id", text_col=None):
    """Setzt den tomedo-Deeplink auf eine Spalte. Idempotent, merge-sicher.

    id_col   = Spalte mit patient.ident (liefert den Template-Wert)
    text_col = Spalte, die klickbar wird; None => id_col selbst
    """
    card = session.get(f"{base}/api/card/{card_id}").json()
    assert card.get("display") == "table", f"Card {card_id}: display={card.get('display')}"

    names = [c["name"] for c in card.get("result_metadata") or []]
    target = text_col or id_col
    for col in {id_col, target}:
        assert col in names, f"Spalte {col} nicht im Result: {names}"

    vs = dict(card.get("visualization_settings") or {})
    cs = dict(vs.get("column_settings") or {})            # MERGE, nicht ersetzen
    key = json.dumps(["name", target], separators=(",", ":"))

    cs[key] = {
        "view_as": "link",
        "link_url": "tomedo://patient#{{" + id_col + "}}",
    }
    vs["column_settings"] = cs

    r = session.put(f"{base}/api/card/{card_id}", json={"visualization_settings": vs})
    r.raise_for_status()

    back = r.json()["visualization_settings"]["column_settings"]
    assert back.get(key, {}).get("view_as") == "link", "Settings nicht übernommen"
    return True
```

Aufruf aus dem Import-Workflow über den Meta-Header:

```sql
-- deeplink: patient_id
```

bzw. mit separater Klicktext-Spalte:

```sql
-- deeplink: patient_id -> aktion
```

## Vier Fallstricke

1. **`column_settings` überschreiben löscht Formatierung.** Ampelfarben,
   Währungs- und Prozentformate stecken im selben Dict. Immer GET → `dict()`-Merge
   → PUT.
2. **Dashcard schlägt Card.** Hat die Card auf einem Dashboard eigene
   `visualization_settings`, gewinnen die. Nach dem Card-Update prüfen, ob eine
   konkurrierende Dashcard-Konfiguration existiert.
3. **Spaltennamen sind der Vertrag.** Der Settings-Key referenziert den
   Result-Spaltennamen. Umbenennen killt Formatierung und Links still — deshalb
   projektweit ein Token (`patient_id`).
4. **`result_metadata` nicht blind mitsenden.** Bei nativen Queries leitet
   Metabase die Metadaten neu ab; manuell gesetzte `semantic_type`-Werte können
   dabei verloren gehen (ungetestet, siehe `visualization-settings.md`).

## Slug und Parameter deterministisch auslesen

```
GET /api/dashboard/{id}     -> parameters[].slug, parameters[].default,
                               dashcards[].parameter_mappings, dashcards[].inline_parameters
```

Im eingeloggten Browser aufrufbar (Session-Cookie). Zuverlässiger als das Ablesen
der Adressleiste — und deckt die drei Parameter-Fallen aus `dashboard-layout.md`
auf, die per Auge nicht sichtbar sind.

## Fallback ohne API

Referenz-Card mit gesetztem Link aufbewahren und **duplizieren** statt neu
anlegen; Duplikate erben `visualization_settings`, danach nur das SQL austauschen.
Bedingung: Spaltennamen unverändert lassen.
