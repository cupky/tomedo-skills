# Import- und Settings-Automatisierung (Metabase API)

Ziel: Cards, Layouts und `visualization_settings` sind Teil des Deployments, nicht
Handarbeit im UI. Nebeneffekt: umgeht UI-Rendering-Bugs (siehe `deep-linking.md`,
Fallstrick 2).

## Das Import-Skript

`scripts/metabase_dashboard_import.py` liegt fest im Skill. **Jedem Paket unverändert
beilegen, nicht neu schreiben** — ein je Paket neu erzeugtes Skript ist ungetestet.
Getestet am 23.09.2026 gegen Metabase v0.63.3: sieben Fragen, 13 Kacheln inklusive
Textkacheln, alle vier Prüfwerte gleich, zweiter Lauf aktualisiert statt zu verdoppeln.

```
export MB_URL="http://<metabase>:<port>"
export MB_API_KEY="$(security find-generic-password -s '<eintrag>' -a 'api key' -w)"
python3 metabase_dashboard_import.py --config dashboard.json --db <id> --dry-run
python3 metabase_dashboard_import.py --config dashboard.json --db <id> [--ersetzen]
```

| Option | Wirkung |
|---|---|
| `--db` | `database_id`, überschreibt den Platzhalter `0` in der Konfiguration |
| `--dry-run` | prüft SQL, Layout und Verweise, sendet nichts |
| `--ersetzen` | Fragen und Dashboards der Sammlung, die **nicht** in der Konfiguration stehen, per `PUT {"archived": true}` in den Papierkorb |
| `--ohne-pruefung` | Prüfwerte nicht abgleichen |

**Warum `--ersetzen`:** Das Skript erkennt Bestand nur am Namen. Wird eine Frage zwischen
zwei Paketen umbenannt, entstünde sonst eine zweite neben der alten. Der Papierkorb ist
wiederherstellbar; endgültig löscht erst, wer ihn in Metabase leert — das bleibt Handarbeit.

**Rechte des API-Keys:** Schreibrecht auf die Ziel-Sammlung und native Abfragen auf der
Datenbank. Ein Dienst-Key mit reinem Leserecht (z. B. für `query/json`) reicht nicht und
soll dafür auch nicht umgewidmet werden. Beim Ablegen im Schlüsselbund fragt `security … -w`
zweimal — je Frage **einmal** einfügen; ein doppelt eingefügter Key ergibt HTTP 401.

## Format der `dashboard.json`

```json
{
  "database_id": 0,
  "collection": "<Sammlung>",
  "dashboard": {"name": "…", "description": "…"},
  "cards": {
    "<schluessel>": {"name": "…", "description": "…", "file": "queries/30_x.sql",
                     "display": "scalar|row|bar|table|…",
                     "visualization_settings": {},
                     "columns": {"<spalte>": {"number_style": "percent", "decimals": 1}}}
  },
  "layout": [
    {"card": "<schluessel>", "col": 0, "row": 0, "size_x": 6, "size_y": 3},
    {"text": "<textschluessel>", "col": 6, "row": 0, "size_x": 18, "size_y": 3}
  ],
  "texte": {"<textschluessel>": "Markdown"},
  "pruefwerte": {
    "_quelle": "tomedo-Export vom <Datum>",
    "<name>": {"card": "<schluessel>", "spalten": ["a", "b"], "agg": "summe|erste", "soll": 123}
  }
}
```

- `file` gilt relativ zur `dashboard.json`. Mehrere Kacheln dürfen dieselbe Datei nutzen
  (eine Kennzahlen-Zeile, je Kachel ein anderes `scalar.field`).
- `columns` wird zu `column_settings` mit Schlüssel `["name","<spalte>"]`.
- `pruefwerte`: `summe` addiert die Spalten über alle Zeilen, `erste` nimmt die erste Zeile.
  Abweichungen werden gemeldet, nicht als Fehler gewertet.
- Das Skript prüft vorab: kein `{{` in der Datei, kein Semikolon, keine Spalten `vorname`
  oder `geburtsdatum`, keine Überlappung im 24er-Raster.

## Pflichtvalidierung: database_id

```python
DB_ID = config["database_id"]
assert isinstance(DB_ID, int) and DB_ID >= 1, f"database_id muss int >= 1 sein, ist: {DB_ID!r}"
```

NULL oder String → HTTP 500 `NULL not allowed for column "DATABASE_ID"`.
Zu finden unter Admin → Databases → DB anklicken → URL zeigt `/admin/databases/N`.

## Partielles PUT statt Vollobjekt

`PUT /api/card/{id}` akzeptiert Teilobjekte. Immer nur das Feld senden, das
geändert wird — ein Vollobjekt-PUT riskiert, `result_metadata` oder
`dataset_query` zu beschädigen.

## Deep-Link per Script setzen

```python
import json

def apply_deeplink(session, base, card_id, id_col="patient_id", text_col=None):
    """Setzt den tomedo-Deeplink auf eine Spalte. Idempotent, merge-sicher.

    id_col   = Spalte mit patient.ident (liefert den Template-Wert)
    text_col = Spalte, die klickbar wird; None => id_col selbst
    """
    card = session.get(f"{base}/api/card/{card_id}").json()
    assert card.get("display") == "table", f"Card {card_id}: display={card.get('display')}"

    names = [c["name"] for c in card.get("result_metadata") or []]
    target = text_col or id_col
    for col in {id_col, target}:
        assert col in names, f"Spalte {col} nicht im Result: {names}"

    vs = dict(card.get("visualization_settings") or {})
    cs = dict(vs.get("column_settings") or {})            # MERGE, nicht ersetzen
    key = json.dumps(["name", target], separators=(",", ":"))

    cs[key] = {
        "view_as": "link",
        "link_url": "tomedo://patient#{{" + id_col + "}}",
    }
    vs["column_settings"] = cs

    r = session.put(f"{base}/api/card/{card_id}", json={"visualization_settings": vs})
    r.raise_for_status()

    back = r.json()["visualization_settings"]["column_settings"]
    assert back.get(key, {}).get("view_as") == "link", "Settings nicht übernommen"
    return True
```

Aufruf aus dem Import-Workflow über den Meta-Header:

```sql
-- deeplink: patient_id
```

bzw. mit separater Klicktext-Spalte:

```sql
-- deeplink: patient_id -> aktion
```

## Vier Fallstricke

1. **`column_settings` überschreiben löscht Formatierung.** Ampelfarben,
   Währungs- und Prozentformate stecken im selben Dict. Immer GET → `dict()`-Merge
   → PUT.
2. **Dashcard schlägt Card.** Hat die Card auf einem Dashboard eigene
   `visualization_settings`, gewinnen die. Nach dem Card-Update prüfen, ob eine
   konkurrierende Dashcard-Konfiguration existiert.
3. **Spaltennamen sind der Vertrag.** Der Settings-Key referenziert den
   Result-Spaltennamen. Umbenennen killt Formatierung und Links still — deshalb
   projektweit ein Token (`patient_id`).
4. **`result_metadata` nicht blind mitsenden.** Bei nativen Queries leitet
   Metabase die Metadaten neu ab; manuell gesetzte `semantic_type`-Werte können
   dabei verloren gehen (ungetestet, siehe `visualization-settings.md`).

## Slug und Parameter deterministisch auslesen

```
GET /api/dashboard/{id}     -> parameters[].slug, parameters[].default,
                               dashcards[].parameter_mappings, dashcards[].inline_parameters
```

Im eingeloggten Browser aufrufbar (Session-Cookie). Zuverlässiger als das Ablesen
der Adressleiste — und deckt die drei Parameter-Fallen aus `dashboard-layout.md`
auf, die per Auge nicht sichtbar sind.

## Fallback ohne API

Referenz-Card mit gesetztem Link aufbewahren und **duplizieren** statt neu
anlegen; Duplikate erben `visualization_settings`, danach nur das SQL austauschen.
Bedingung: Spaltennamen unverändert lassen.
