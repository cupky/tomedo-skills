#!/usr/bin/env python3
"""Legt ein Metabase-Dashboard samt Fragen aus einer dashboard.json an.

Erstellt oder aktualisiert (idempotent, per Name in der Sammlung):
  - eine Sammlung
  - je Eintrag unter "cards" eine native SQL-Frage
  - ein Dashboard mit Text- und Frage-Kacheln im 24er-Raster
Mit --ersetzen wandern Fragen und Dashboards der Sammlung, die nicht in der
Konfiguration stehen, in den Metabase-Papierkorb (wiederherstellbar, nie endgültig).

Aufruf:
  export MB_URL="https://metabase.example.local"
  export MB_API_KEY="mb_..."            # Admin > Einstellungen > Authentifizierung > API-Schlüssel
  python3 metabase_dashboard_import.py --db 2            # database_id der tomedo-Replika
  python3 metabase_dashboard_import.py --db 2 --dry-run  # nur prüfen, nichts senden
  python3 metabase_dashboard_import.py --db 2 --ersetzen # Altbestand der Sammlung in den Papierkorb

Benötigt: Python 3.8+, requests.
"""
import argparse
import copy
import json
import os
import sys
from pathlib import Path

HIER = Path(__file__).resolve().parent


# ---------------------------------------------------------------- Laden und Prüfen
def lade_konfig(pfad):
    cfg = json.loads(Path(pfad).read_text(encoding="utf-8"))
    return cfg


def lade_sql(datei, basis=HIER):
    text = (basis / datei).read_text(encoding="utf-8")
    kopf = {}
    for zeile in text.splitlines():
        if zeile.startswith("-- ") and ":" in zeile:
            k, v = zeile[3:].split(":", 1)
            kopf.setdefault(k.strip(), v.strip())
    code = "\n".join(z for z in text.splitlines() if not z.startswith("--"))
    assert "{{" not in text, f"{datei}: Template-Tag gefunden, dieses Paket arbeitet ohne Variablen"
    assert ";" not in code, f"{datei}: Semikolon im SQL, Metabase erlaubt nur eine Anweisung ohne Abschluss"
    for verboten in ("vorname", "geburtsdatum"):
        assert verboten not in code.lower(), f"{datei}: personenbezogene Spalte {verboten}"
    return text.strip(), kopf


def column_settings(spalten):
    return {json.dumps(["name", k], separators=(",", ":")): v for k, v in (spalten or {}).items()}


def baue_cards(cfg, db_id, basis=HIER):
    cards = {}
    for key, c in cfg["cards"].items():
        sql, kopf = lade_sql(c["file"], basis)
        vs = copy.deepcopy(c.get("visualization_settings", {}))
        if c.get("columns"):
            vs["column_settings"] = column_settings(c["columns"])
        cards[key] = {
            "name": c.get("name") or kopf.get("name") or key,
            "description": c.get("description") or kopf.get("description"),
            "display": c["display"],
            "visualization_settings": vs,
            "dataset_query": {
                "type": "native",
                "native": {"query": sql, "template-tags": {}},
                "database": db_id,
            },
        }
    return cards


def text_dashcard(i, text, pos):
    return {
        "id": -i, "card_id": None,
        "row": pos["row"], "col": pos["col"], "size_x": pos["size_x"], "size_y": pos["size_y"],
        "parameter_mappings": [], "series": [],
        "visualization_settings": {
            "virtual_card": {"name": None, "display": "text", "visualization_settings": {},
                             "dataset_query": {}, "archived": False},
            "text": text,
            "text.align_vertical": "top",
        },
    }


def card_dashcard(i, card_id, pos):
    return {
        "id": -i, "card_id": card_id,
        "row": pos["row"], "col": pos["col"], "size_x": pos["size_x"], "size_y": pos["size_y"],
        "parameter_mappings": [], "series": [], "visualization_settings": {},
    }


def pruefe_layout(layout):
    belegt = {}
    for e in layout:
        assert 0 <= e["col"] and e["col"] + e["size_x"] <= 24, f"Layout ausserhalb des 24er-Rasters: {e}"
        for r in range(e["row"], e["row"] + e["size_y"]):
            for c in range(e["col"], e["col"] + e["size_x"]):
                assert (r, c) not in belegt, f"Überlappung {e} mit {belegt[(r, c)]}"
                belegt[(r, c)] = e.get("card") or e.get("text")


# ---------------------------------------------------------------- API
class Metabase:
    def __init__(self, url, key, session=None):
        import requests
        self.base = url.rstrip("/")
        self.s = session or requests.Session()
        self.s.headers.update({"x-api-key": key, "Content-Type": "application/json"})

    def _r(self, methode, pfad, **kw):
        r = self.s.request(methode, self.base + pfad, **kw)
        if r.status_code >= 400:
            raise SystemExit(f"{methode} {pfad} -> HTTP {r.status_code}: {r.text[:500]}")
        return r.json() if r.text else None

    def get(self, p, **kw):  return self._r("GET", p, **kw)
    def post(self, p, body): return self._r("POST", p, json=body)
    def put(self, p, body):  return self._r("PUT", p, json=body)

    def sammlung(self, name):
        for c in self.get("/api/collection"):
            if c.get("name") == name and not c.get("archived") and not c.get("personal_owner_id"):
                return c["id"], False
        return self.post("/api/collection", {"name": name, "parent_id": None})["id"], True

    def inhalte(self, coll_id):
        res = self.get(f"/api/collection/{coll_id}/items", params=[("models", "card"), ("models", "dashboard")])
        daten = res.get("data", res) if isinstance(res, dict) else res
        return {(d["model"], d["name"]): d["id"] for d in daten}

    def card_upsert(self, vorhanden, coll_id, body):
        cid = vorhanden.get(("card", body["name"]))
        if cid is None:
            neu = self.post("/api/card", dict(body, collection_id=coll_id))
            return neu["id"], "angelegt"
        alt = self.get(f"/api/card/{cid}")
        vs = dict(alt.get("visualization_settings") or {})          # Merge, nicht ersetzen
        cs = dict(vs.get("column_settings") or {})
        cs.update(body["visualization_settings"].get("column_settings", {}))
        vs.update({k: v for k, v in body["visualization_settings"].items() if k != "column_settings"})
        if cs:
            vs["column_settings"] = cs
        teil = {"description": body["description"], "display": body["display"],
                "visualization_settings": vs, "dataset_query": body["dataset_query"]}
        self.put(f"/api/card/{cid}", teil)                           # partielles PUT
        return cid, "aktualisiert"

    def ergebnis(self, card_id):
        res = self._r("POST", f"/api/card/{card_id}/query/json", json={})
        if not isinstance(res, list):                               # Fehler kommt als Objekt
            raise SystemExit(f"Card {card_id} liefert Fehler: {json.dumps(res)[:500]}")
        return [{k.lower(): v for k, v in z.items()} for z in res]


# ---------------------------------------------------------------- Ablauf
def main(argv=None, session=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--config", default="dashboard.json", help="Pfade der SQL-Dateien gelten relativ hierzu")
    ap.add_argument("--url", default=os.environ.get("MB_URL"))
    ap.add_argument("--key", default=os.environ.get("MB_API_KEY"))
    ap.add_argument("--db", type=int, help="database_id der tomedo-Replika (überschreibt dashboard.json)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--ohne-pruefung", action="store_true", help="Ergebnisse nicht gegen Prüfwerte abgleichen")
    ap.add_argument("--ersetzen", action="store_true",
                    help="Fragen/Dashboards der Sammlung, die nicht in der Konfiguration stehen, in den Papierkorb")
    a = ap.parse_args(argv)

    cfg = lade_konfig(a.config)
    db_id = a.db if a.db is not None else cfg.get("database_id")
    assert isinstance(db_id, int) and db_id >= 1, f"database_id muss int >= 1 sein, ist: {db_id!r} (Option --db)"
    cards = baue_cards(cfg, db_id, Path(a.config).resolve().parent)
    pruefe_layout(cfg["layout"])
    for e in cfg["layout"]:
        assert ("card" in e and e["card"] in cards) or ("text" in e and e["text"] in cfg["texte"]), f"Unbekannt: {e}"
    print(f"Geprüft: {len(cards)} Fragen, {len(cfg['layout'])} Kacheln, database_id {db_id}")
    if a.dry_run:
        for k, c in cards.items():
            print(f"  {k:15s} {c['display']:7s} {c['name']}")
        return 0

    assert a.url and a.key, "MB_URL und MB_API_KEY setzen (oder --url / --key)"
    mb = Metabase(a.url, a.key, session=session)

    coll_id, neu = mb.sammlung(cfg["collection"])
    print(f"Sammlung {cfg['collection']!r}: id {coll_id} ({'angelegt' if neu else 'vorhanden'})")
    vorhanden = mb.inhalte(coll_id)

    ids = {}
    for k, body in cards.items():
        ids[k], status = mb.card_upsert(vorhanden, coll_id, body)
        print(f"  Frage {body['name']!r}: id {ids[k]} ({status})")

    dname = cfg["dashboard"]["name"]
    dash_id = vorhanden.get(("dashboard", dname))
    if dash_id is None:
        dash_id = mb.post("/api/dashboard", {"name": dname, "description": cfg["dashboard"]["description"],
                                              "collection_id": coll_id})["id"]
        print(f"Dashboard angelegt: id {dash_id}")
    else:
        print(f"Dashboard vorhanden: id {dash_id}, Kacheln werden ersetzt")

    dashcards = []
    for i, e in enumerate(cfg["layout"], start=1):
        if "card" in e:
            dashcards.append(card_dashcard(i, ids[e["card"]], e))
        else:
            dashcards.append(text_dashcard(i, cfg["texte"][e["text"]], e))
    mb.put(f"/api/dashboard/{dash_id}", {"description": cfg["dashboard"]["description"],
                                          "width": "full", "dashcards": dashcards, "tabs": []})
    print(f"Layout gesetzt: {len(dashcards)} Kacheln")

    if a.ersetzen:
        behalten = {("card", i) for i in ids.values()} | {("dashboard", dash_id)}
        for (modell, name), iid in sorted(vorhanden.items()):
            if (modell, iid) not in behalten:
                mb.put(f"/api/{modell}/{iid}", {"archived": True})    # Papierkorb, nicht DELETE
                print(f"  in den Papierkorb: {modell} {iid} {name!r}")

    pw = cfg.get("pruefwerte", {})
    if pw and not a.ohne_pruefung:
        print(f"Abgleich mit {pw.get('_quelle', 'den Prüfwerten')}:")
        cache = {}
        for name, p in pw.items():
            if name.startswith("_"):
                continue
            if p["card"] not in cache:
                cache[p["card"]] = mb.ergebnis(ids[p["card"]])
            zeilen = cache[p["card"]]
            spalten = [sp.lower() for sp in p["spalten"]]
            if p.get("agg", "summe") == "erste":
                ist = sum(float(zeilen[0][sp]) for sp in spalten)
            else:
                ist = sum(float(z[sp]) for z in zeilen for sp in spalten)
            mark = "gleich" if abs(ist - float(p["soll"])) < p.get("toleranz", 0.05) else "ABWEICHUNG"
            print(f"  {name:26s} soll {p['soll']:>8}  ist {ist:>8g}  {mark}")

    print(f"Fertig: {mb.base}/dashboard/{dash_id}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
