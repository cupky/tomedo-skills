---
name: tomedo-metabase-migration
version: 1.0
description: >-
  Übersetzt tomedo HQL-Statistik-Queries in metabase-kompatible native SQL-Fragen
  mit Filter-Widgets und Dashboard-Konfiguration. Verwende diesen Skill IMMER
  wenn tomedo-Queries nach Metabase migriert, Metabase-Dashboards aus HQL gebaut,
  ZS-Filter in Metabase-Variablen konvertiert, Metabase-Cards per API erstellt,
  Dashboard-Layouts konfiguriert, oder visualization_settings definiert werden
  sollen. Auch verwenden bei: Query für Metabase anpassen, Dashboard in Metabase
  bauen, HQL nach Metabase übersetzen, Metabase-Import vorbereiten, Filter-Widget
  konfigurieren, Kennzahl in Metabase abbilden, Metabase API nutzen, Patientenliste
  klickbar machen, Deep-Link nach tomedo, tomedo://patient, Absprung aus Metabase
  in die Kartei, Absprung aus tomedo ins Dashboard, Card-Settings per Script
  setzen, oder jede Frage zu tomedo→Metabase Migration. Der Skill ist ein
  Navigator; Übersetzungsworkflow, visualization_settings-Templates,
  Dashboard-Layout, Deep-Linking und Import-Automatisierung liegen in references/.
---

# tomedo HQL → Metabase Migration Skill

Navigator-Skill: übersetzt validierte tomedo HQL-Queries in metabase-kompatible
native SQL-Fragen mit Filter-Widgets, Visualisierungen, Dashboard-Layout und
bidirektionalem Deep-Linking. Detailwissen liegt in `references/` — dort
nachschlagen, **bevor** gebaut wird.

**Stand:** 30.07.2026 · Skill v2.0 · getestet gegen **Metabase v0.59.4** (Docker, OSS)

## Referenzdateien

| Datei | Inhalt | Wann lesen |
|---|---|---|
| `references/query-uebersetzung.md` | CTE-Pflicht, ZS-Filter→Variablen, Meta-Header, Display-Typen, 8 häufige Fehler, validierte Cards K01–K12 | Query übersetzen oder debuggen |
| `references/visualization-settings.md` | JSON-Templates pro Chart-Typ, `column_settings`-Semantik, Merge-Regeln | Card-Aussehen konfigurieren |
| `references/dashboard-layout.md` | 24-Spalten-Grid, Layout-Algorithmus, Dashboard-Filter, Slug-Mechanik, Parameter-Fallen | Dashboard bauen, Filter verbinden |
| `references/deep-linking.md` | Beide Richtungen (Metabase↔tomedo), Statustabelle belegt/offen, Testleiter, Fallstricke | Klickbare Listen, Absprünge |
| `references/import-scripts.md` | API-Patterns, `apply_deeplink()`, partielles PUT, `result_metadata`-Schutz | Cards/Settings per Script setzen |

## Datenschutz by Design

Gilt 1:1 wie im HQL-Skill, in Metabase **verschärft**, weil Ergebnisse direkt im
Browser stehen und Collections geteilt werden:

- Kein `nachname`, `vorname`, `geburtsdatum` im finalen SELECT
- Nur `patient_id` (= `patient.ident`) und aggregierte Werte
- Deep-Links transportieren ausschließlich die interne ID — zulässig, aber eine
  klickbare Patientenliste ist faktisch ein Kartei-Zugriffswerkzeug.
  Collection-Rechte auf den Kreis beschränken, der ohnehin Kartei-Zugriff hat.
- Ausnahme mit Ansage: das Header-Card-Muster des Patientendashboards (P00)
  enthält bewusst Klarnamen, weil der Arzt den Patienten identifizieren muss.

## Workflow: HQL → Metabase (3 Phasen)

**Phase 1 — in tomedo validieren.** Query mit `tomedo-statistik-hql` bauen, in
tomedo ausführen, Ergebnisse prüfen. Erst bei reproduzierbaren Zahlen weiter.

**Phase 2 — übersetzen** (Details: `references/query-uebersetzung.md`):
TEMP TABLE → CTE · ZS-Filter → `[[ AND … {{var}} ]]` · Spaltennamen gegen das
Datenmodell prüfen · Meta-Header setzen · keine `{{}}` in Kommentaren ·
`visualization_settings` aus der Referenz wählen.

**Phase 3 — importieren** (Details: `references/import-scripts.md`):
SQL nach `queries/`, `metabase_import.py`, Dashboard-Filter verbinden,
Viz-Settings per Script setzen statt per UI-Klick.

## Kritische Regeln (Kurzfassung)

Die Langfassung samt Falsch/Richtig-Beispielen steht in den Referenzen.

1. **Nur 1 Statement pro Card** → CTEs ketten, nie `CREATE TEMPORARY TABLE`.
2. **Keine `{{}}` in SQL-Kommentaren** — Metabase parst sie und erzeugt
   Phantom-Pflichtfilter.
3. **Tabellennamen sind case-sensitive**, anders als in tomedo-HQL
   (`ebmKatalogEintrag_ebmKatalogEintragDetails`).
4. **Optionale Filter immer `WHERE TRUE [[ AND … ]]`** — ohne führendes
   `WHERE TRUE` entsteht `WHERE AND …`.
5. **`database_id` muss int ≥ 1 sein** — sonst HTTP 500 beim API-Import.
6. **Spaltennamen sind der Vertrag.** `column_settings` referenzieren
   Result-Spaltennamen (`["name","patient_id"]`). Sie überleben SQL-Rewrites
   (belegt), brechen aber **still** beim Umbenennen einer Spalte. Postgres
   lowercased unquoted Aliase: `AS patientID` landet als `patientid`.

### Ergebnisse per Card-API holen, nicht per Datenbankpasswort

```
POST {metabase}/api/card/<id>/query/json
Header: x-api-key: <API-Key>
Body:   {}
→ Array von Objekten, Schluessel = Spalten-Aliase (kleingeschrieben!)
```

- **API-Key statt Session.** Einzeln widerrufbar, ohne Passwortwechsel, und er erzeugt keine
  14 Tage gueltige Session. Der Session-Weg (`POST /api/session` → `X-Metabase-Session`)
  funktioniert, ist aber der schlechtere Tausch. Key in den Login-Schluesselbund, nie ins Repo.
- **Kein Datenbankpasswort noetig:** Metabase fuehrt die Query aus, das Werkzeug holt nur das
  Ergebnis. Damit ist eine bestaetigte Card ein vollwertiger, protokollierter Leseendpunkt.
- **Erfolgspruefung:** Fehler liefert Metabase als **Objekt**, Erfolg immer als **Array**.
- **Public Links bleiben verworfen** — unauthentifizierter Endpunkt, zufaellige UUID als
  einziger Schutz, **kein** Zugriffsprotokoll, ausgeliefert wuerden Patienten-IDs und Termine.
- **Spaltenschluessel immer kleingeschrieben vergleichen** (Postgres faltet unquotierte Aliase).
- **Idents nie durch `float`/JS-Number** parsen (58 Bit), in der Card `ident::text`.

## ID-Namenskonvention (ein Token für alles)

Drei Schreibweisen desselben Begriffs sind die teuerste Fehlerquelle im
Zusammenspiel Metabase↔tomedo, weil jede Abweichung **still** scheitert:
Filter-Label `Patient ID` → Slug `patient_id` → SQL-Variable `{{patient_id}}`
→ Result-Spalte `patient_id` → Link-Template `{{patient_id}}`.

Status: **vorgeschlagen**, ADR-METABASE-01 offen bis der URL-Round-Trip
gemessen ist. Bestand, der dafür spricht: die 22 Cards P00–P21 des
Patientendashboards sind bereits auf `{{patient_id}}` ausgelegt.

## Abhängigkeiten

- **tomedo-statistik-hql** — Query-Erstellung und -Validierung (Phase 1)
- **tomedo-kommandos** — für den Absprung aus tomedo (`$[pid]$`)
- **Python 3.8+** mit `requests` — API-Import
- **Metabase OSS** — Zielsystem; Versionsverhalten bei Sanitizing und
  Feldtypen kann zwischen Minor-Versionen abweichen, deshalb Version
  mitdokumentieren
