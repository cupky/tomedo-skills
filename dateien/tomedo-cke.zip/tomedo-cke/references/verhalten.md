# CKE-Verhalten beim Ausfüllen: Vorauswahl, Formeln, Karteitext, Zusammenspiel

Überarbeitet im Oktober 2026. **[ungeprüft]** heißt: noch nicht in der Oberfläche nachgestellt. Vor dem Einsatz an
einem Testpatienten prüfen.

## 1. Vorauswahl

- Ausgewertet wird sie **nur beim Anlegen** eines neuen Eintrags. Erlaubt sind fester Text, Briefkommandos und
  Textbausteine. `\n` wird zu einem Zeilenumbruch. **[ungeprüft]**
- Verweise auf andere Felder desselben CKE (`$[v1]$`) gehen in der Vorauswahl normaler Felder **nicht**; tomedo liest sie
  als Briefkommando und meldet „Die Sequenz … konnte nicht aufgelöst werden.“ Feldverweise gibt es nur in Formeln (§2).
- **Kontrollkästchen:** Der Haken wird gesetzt, wenn das Ergebnis genau `1` ist (Programmtext im Editor).
- **Auswahl:** Der Wert wird ungeprüft übernommen. Ein Wert außerhalb der Liste landet im Karteitext; ob das Auswahlmenü
  ihn zeigt, ist offen. **[ungeprüft]**
- **Datum:** `$[d]$` steht für heute mit Uhrzeit; `$[d X]$` mit Versatz. Ein drittes Argument (eigenes Format) wird
  ersetzt, weil tomedo das Ergebnis selbst als Datum liest. **[ungeprüft]**
- **Leere Datum- und Zeitfelder** bekommen beim Öffnen des Eintrags „jetzt“. Nur „Datum, das auch leer bleiben kann“
  bleibt leer. **[ungeprüft]**
- **Zahl nicht editierbar, Textfeld nicht editierbar:** bekommen nur beim Anlegen das Ergebnis ihrer Vorauswahl
  (Briefkommandos, Textbausteine). Sie **rechnen nicht** und aktualisieren sich nicht.
- **BMI:** Die Vorauswahl hat zwei Felder „Größe“ und „Gewicht“ (je Briefkommando). Ohne Vorauswahl nimmt tomedo die
  Größe des Patienten (über 17 Jahre) und Größe und Gewicht eines BMI-Eintrags, der höchstens einen Tag alt ist.
  Ist nur eines der beiden Vorauswahlfelder gefüllt, kann das andere leer überschrieben werden – beide setzen. **[ungeprüft]**
- **Blutdruck** übernimmt die Werte eines höchstens einen Tag alten Blutdruck-Eintrags, **Eltern-Körpergröße** immer die
  des letzten Eintrags. **[ungeprüft]**
- **Laufende Nummer:** wird erst beim Speichern vergeben, vom Server, als **ein Zähler je Variablenname** für die ganze
  Installation – nicht je Patient. Zwei Typen mit gleichem Variablennamen teilen sich den Zähler, ein umbenanntes Feld
  beginnt einen neuen. **[ungeprüft]**

## 2. Formeln

**Welche Arten rechnen:** „Score nicht editierbar“, „Gruppe nicht editierbar“, „Datum bei Änderung neu berechnet“,
„Zeit bei Änderung neu berechnet“ und „Text zusammengesetzt nicht editierbar“. Die Formel steht im Feld **Vorauswahl**.
Die Altformen „(alt)“ und „(v3)“ bietet tomedo nur mit zollsoft-Anmeldung an; nicht verwenden.

**Ablauf** (Score, Gruppe nicht editierbar, Datum/Zeit neu berechnet):
1. Jedes `$[Variablenname]$` wird durch den Wert des Feldes ersetzt (Zahl mit Punkt, Komma wird umgewandelt).
2. Danach laufen die Briefkommandos über die ganze Formel (`$[if …]$`, `$[karteiEintragWert …]$` gehen also).
3. Dann rechnet die Formelauswertung von macOS (NSExpression). **[ungeprüft]**: `+ - * /`, Klammern, Potenz `**`,
   Dezimalpunkt; Funktionen wie `sqrt(x)`, `abs(x)`, `floor(x)`, `ceiling(x)`, `ln(x)`, `log(x)`, `exp(x)`,
   Listen `max({a,b})`, `min({…})`, `sum({…})`, `average({…})`. Vergleiche wie `a > b` sind dort keine Rechenausdrücke.
4. Ergebnis: Score mit den eingestellten Nachkommastellen (0–4, gespeichert mit Punkt, im Karteitext mit Komma).
   Datum/Zeit: das Ergebnis gilt als Sekunden seit 1970 – `$[geburt]$ + 14*86400` ist „14 Tage nach geburt“. **[ungeprüft]**
   Gruppe nicht editierbar: Ergebnis 0 → zugeklappt, sonst aufgeklappt.

**Wenn/Dann und Hilfsfunktionen** (tomedo-Erweiterung, Werte in Hochkommas) **[ungeprüft]**:

| Aufruf | Ergebnis |
|---|---|
| `FUNCTION('$[a]$','ifGreaterAs:yes:no:','140','1','0')` | 1, wenn a > 140, sonst 0 |
| `FUNCTION('$[a]$','ifSmallerAs:yes:no:','18','0','2')` | 0, wenn a < 18, sonst 2 |
| `FUNCTION('$[a]$','ifEqualTo:yes:no:','ja','3','0')` | 3 bei Gleichheit (Zahlen numerisch, sonst Text genau, mit Groß-/Kleinschreibung) |
| `FUNCTION('$[a]$,$[b]$,$[c]$','maxNumeric')` / `'minNumeric'` | größter / kleinster Wert |
| `FUNCTION('$[x]$','round')` | auf ganze Zahl gerundet |
| `FUNCTION('1.0','trigSin')` (`trigCos`, `trigTan`, `trigArcTan`) | Winkelfunktion im Bogenmaß |

Die Ja/Nein-Werte müssen Zahlen oder Rechenausdrücke sein, kein Text. FUNCTION-Aufrufe lassen sich addieren:
`FUNCTION(…) + FUNCTION(…)` ist ein Punktescore. Als Grenze besser eine feste Zahl verwenden als einen Rechenausdruck
wie `'3+4'`; das kann je nach Wert anders gelesen werden als erwartet (vor dem Einsatz testen).

**Werte anderer Arten in Formeln** **[ungeprüft]**:
- Kontrollkästchen: 1 bei Haken, sonst 0 → Punktescore aus Haken: `$[a]$*2 + $[b]$`.
- Datum, Zeit: Sekunden seit 1970; Zeit mit Start&Stopp: Dauer in Sekunden.
- **BMI-Feld liefert die Größe** (cm), nicht den BMI; **Blutdruck nur den systolischen Wert**; Eltern-Körpergröße die
  Größe der Mutter. Den BMI selbst liefert `$[karteiEintragWert …]$` mit dem Format „BMI“ (→ tomedo-kommandos).
- Text, Auswahl, Mehrfachauswahl: der Text. Für einen Vergleich in Hochkommas setzen: `'$[auswahl]$'`.

**Leere Felder und Fehler** **[ungeprüft]**: Ein leeres Zahlfeld hinterlässt eine Lücke in der Formel. Dann steht im Score
„Der Score ist logisch falsch definiert oder die Werte sind nicht gesetzt.“ – auch im Karteitext. Abhilfe: Zahlfelder als
Pflichtfeld oder in der Formel abfangen, z. B. `FUNCTION('$[a]$','ifEqualTo:yes:no:','','0','$[a]$')`. Bei Datum/Zeit
bleibt das Feld leer, eine bedingte Gruppe bleibt offen.

**Wann neu gerechnet wird** **[ungeprüft]**: nach jeder Änderung eines Feldes, auf das die Formel verweist, und **bei jedem
Öffnen eines gespeicherten Eintrags**. Briefkommandos in der Formel werden dann mit dem aktuellen Besuch neu ausgewertet –
ein alter Eintrag kann so einen anderen Wert bekommen. Für feste Werte keine zeitabhängigen Briefkommandos in Formeln.
tomedo meldet Verweise auf Formelfelder, die weiter unten stehen („… greift auf einen Score o.ä. zu, der erst später
berechnet wird …“), Selbstbezüge und Endlosschleifen.

**Gruppe nicht editierbar (bedingte Gruppe):** Programmtext: „Die bedingte Gruppe wird genau dann zugeklappt, wenn der hier
berechnete Wert 0 ist.“ Nur eine normale „Gruppe“ lässt sich von Hand auf- und zuklappen. Mit **„Titel verbergen“** ist
eine zugeklappte bedingte Gruppe ganz unsichtbar, ohne Titelzeile. **[ungeprüft]**: Pflichtfelder in einer zugeklappten
bedingten Gruppe werden nicht verlangt; ausgefüllte Felder darin kommen trotzdem in den Karteitext.

**Text zusammengesetzt nicht editierbar** **[ungeprüft]**: Fließtext mit `$[v1]$`. Aufzählungen:
`$($[v1]$,$[v2]$,$[v3]$,KOMMAUND)$` → „a, b und c“; leere Teile fallen weg. Modi: KOMMA, KOMMAUND, KOMMAODER,
LEERZEICHEN, BINDESTRICH, LEERSTRICHLEER, UNTERSTRICH, NEWLINE. Text davor und danach nur bei Inhalt:
`KOMMA_BEGIN"Befund: "_ENDE"."` (ohne `_` im Text). **Das letzte Element ist immer der Modus** – fehlt er, verschwindet das
letzte Element. Kontrollkästchen erscheinen hier mit ihrem Anzeigenamen, wenn angehakt. Briefkommandos laufen danach.

Im Editor legt der Rechtsklick „selektierte Zeilen (n) in als Summe der Variablen für SCORE“ die Summe
`$[v1]$+$[v2]$+…` der markierten Felder in die Zwischenablage.

## 3. Karteitext

**Automatisch („autom. generieren“ an):** alle Felder nach ihrer Nummer, auch die in Gruppen, ohne Trennlinie und Leerzeile,
verbunden mit dem Trennzeichen aus *Einstellungen › Praxis › Kartei › „Trennzeichen im Karteieintragstext“* (Vorgabe
„ ◉ “). Je Feld gilt „Im Karteitext“:

| Einstellung | Textstück |
|---|---|
| Niemals | nichts |
| Immer | `Anzeigename: Wert` (BMI: `Anzeigename = Wert`) |
| Nur wenn der Wert nicht leer ist | wie Immer, nur mit Wert |
| Immer, aber ohne die Anzeigenamen | `Wert` |
| Nur wenn der Wert nicht leer ist und ohne Anzeigenamen | `Wert`, nur mit Wert |
| Anzeige nur vom Anzeigenamen ohne Wert, wenn Wert nicht leer ist | `Anzeigename` |

- **Kontrollkästchen** schreiben bei „Immer“, „Nur wenn nicht leer“ und „ohne Anzeigenamen“ **`1` oder `0`**, kein
  ja/nein. Für „nur bei Haken den Anzeigenamen“ die letzte Einstellung wählen. **[ungeprüft]**
- Zahlen erscheinen mit Komma und den eingestellten Nachkommastellen, Datum als `dd.MM.yyyy`, Zeit `HH:mm`,
  Mehrfachauswahl mit „, “, Puls mit „/min“, Körpertemperatur ohne Einheit. **[ungeprüft]**
- „Karteidatum verschieben“ mit „+10 Jahre“ erzeugt keinen Text (vor dem Einsatz testen). **[ungeprüft]**

**Eigenes Format („autom. generieren“ aus, Text im Feld „Karteitext“):**
- `$[Variablenname]$` wird **durch das Textstück aus der Tabelle oben** ersetzt, nicht durch den reinen Wert. Bei „Immer“
  und „Nur wenn nicht leer“ steht also „Anzeigename: Wert“ an der Stelle. Für den reinen Wert das Feld auf
  **„Nur wenn der Wert nicht leer ist und ohne Anzeigenamen“** (Spec: `wenn nicht leer ohne anzeigename`) oder „Immer,
  aber ohne die Anzeigenamen“ stellen. **[ungeprüft]**
- Danach laufen Briefkommandos über den ganzen Text (mit dem letzten Besuch des Patienten). Unbekannte `$[…]$` werden als
  Briefkommando gelesen und gemeldet.
- `cke.py pruefen` warnt bei Platzhaltern, deren Feld „Anzeigename: Wert“, nichts oder nur den Anzeigenamen liefert.
- Der Text wird beim Speichern erzeugt. Ein geändertes Format wirkt nicht auf alte Einträge, bis man sie neu speichert.

## 4. Vitalwerte

- tomedo erkennt Vitalwerte an der **Art**, nicht am Variablennamen. Größe, Gewicht und BMI des Patienten,
  Perzentilen, DMP und Medikationsplan lesen das **neueste Feld der Art „BMI“**; Blutdruck und Eltern-Körpergröße ebenso
  über ihre Art. Eigene Zahlfelder „Größe“ oder „Gewicht“ zählen dafür nicht. **[ungeprüft]**
- Beim BMI ist der erste Wert die Größe in cm, der zweite das Gewicht in kg; tomedo rechnet den BMI und die
  Körperoberfläche (Vorschrift unter *Einstellungen › Praxis › Kartei › BMI-Eintrag*).
- Eingabegrenzen sind fest (z. B. Größe 1–300 cm, Gewicht 0–400 kg, Temperatur −50–100 °C). Die Art „Zahl“ hat keine
  Grenzen, nur die Nachkommastellen werden geprüft.
- Bei Kindern schreibt tomedo Perzentilen in den Karteitext, wenn das Alter im Bereich der Studie liegt.

## 5. Typ ändern, wenn es schon Einträge gibt

- Jeder Karteieintrag bekommt beim Anlegen eine **eigene Kopie** aller Felder. **[ungeprüft]**:
  - Später hinzugefügte Felder fehlen in alten Einträgen.
  - Gelöschte Felder bleiben in alten Einträgen sichtbar (Löschen im Editor markiert das Feld nur).
  - Anzeigeoptionen („Im Karteitext“, Nachkommastellen, Ausrichtung) holt tomedo über den **Variablennamen** vom Typ –
    eine Änderung wirkt also auch auf alte Einträge, solange der Name gleich bleibt.
  - Ein neues Feld kann den Namen `vN` eines gelöschten erben; alte Einträge übernehmen dann dessen Einstellungen.
- Umbenennen eines Variablennamens: keine Warnung, keine Anpassung von `$[alt]$` im Karteitext, in Formeln oder Briefvorlagen.
- Eine Warnung „Typ hat schon Einträge“ gibt es nicht. Die Spaltenanzahl zu ändern fragt nach und passt alle Feldbreiten an.

## 6. Aktionsketten

- **CKE per Kette anlegen** (Schritt „Karteieintrag anlegen“ mit dem CKE-Typ, auch „Lege Karteieintrag direkt an (zeige
  kein Popover)“): Der Schritt selbst gibt bei CKE keine Vorbefüllung mit. Die Vorauswahl der Felder sieht aber die
  Briefkommandos der laufenden Kette – etwa das Ergebnis-Briefkommando eines vorherigen Schritts „KI-Prompt“
  (`$[kiErgebnis]$` als Vorauswahl). **[ungeprüft]**
- Wird die Kette per URL mit Variablen aufgerufen, ersetzt eine Variable **mit demselben Namen wie ein Variablenname** die
  Vorauswahl dieses Feldes (→ tomedo-navigation, URL-Aufruf). **[ungeprüft]**
- **In ein CKE-Feld zurückschreiben:** Schritt „Zurückschreiben“, Zielfeld „Karteieintrag (nimmt den aktuellsten)“, CKE-Typ
  und Feld wählen (Liste „Anzeigename - Variablenname“). **[ungeprüft]**:
  - Wählbar sind nur Kontrollkästchen (beide), Textfeld, Zahl, Zahl mit Vorzeichen, Auswahl, Mehrfachauswahl, Datum,
    Datum (darf leer bleiben), Zeit.
  - Ziel ist der Eintrag des Typs mit dem **neuesten Karteidatum**, nicht unbedingt der zuletzt angelegte.
  - Der Wert wird als Text übernommen, ohne Prüfung: Kontrollkästchen nur mit genau `1` anhaken (`0` hakt ab), Datum im
    Format `dd.MM.yyyy HH:mm`, Auswahl genau wie in der Liste.
  - Scores und zusammengesetzte Texte rechnet tomedo danach **nicht** neu (erst beim nächsten Öffnen).
  - „Ersetzen“ mit leerem Ergebnis leert das Feld; für KI-Ergebnisse besser „Setzen nur wenn Feld leer“ oder „Anhängen …“.
- **Element „Aktionskette aufrufen“** im CKE: Der Knopf prüft die Pflichtfelder, speichert den Eintrag und schiebt die Kette
  direkt hinter die laufende ein (oder startet sie). Ohne gewählte Kette: „Es wurde keine Aktionskette in der Verwaltung
  angegeben!“ Die Warteschlangen-Optionen der Kettenschritte („auf Platz 1“, „nur einmal“, „aktive Kette abbrechen“) gibt es
  hier nicht. Keine Kette aufrufen, die diesen CKE wieder anlegt (Schleife). **[ungeprüft]**
- **Formular aufrufen:** öffnet ein neues Formular des gewählten Formulartyps, vorbefüllt aus diesem Eintrag; der CKE wird
  dabei nicht gespeichert. **[ungeprüft]**
- **Script:** führt das gewählte Skript aus und übergibt alle Felder als Variablenname → Wert. **[ungeprüft]**
- **SmED/SMASS-Aufruf:** hat keinen Knopf. Beim Öffnen eines neuen Eintrags holt tomedo sofort eine Sitzung und öffnet den
  Browser (SmED-Zugang nötig). Nicht in CKE einbauen, die oft ohne SmED gebraucht werden. **[ungeprüft]**

## 7. KI (Sprechstunden-Assistent, KarteiChat)

- Der **Sprechstunden-Assistent** (*Verwaltung › KI-Assistenten*, Vorlage je Karteieintragstyp) beschreibt einen CKE dem
  Modell mit **Variablenname, Anzeigename, Formathinweis und Auswahlliste**. Tooltipp, Vorauswahl und Pflichtfeld gehen
  nicht mit. Die Beschreibung entsteht beim Wählen des Typs und lässt sich ändern – ein erneuter Typwechsel überschreibt sie.
- Nur Typen mit „auswählbar in Dropdowns/Kommandozeile der Kartei“ lassen sich dort wählen.
- Befüllbar sind Textfeld, Zahl, Zahl mit Vorzeichen, Datum, Zeit, Kontrollkästchen, Auswahl, Mehrfachauswahl und die
  Vitalwerte; nicht die „nicht editierbar“-Arten, Scores, Nur Anzeigetext, Laufende Nummer, Knöpfe.
- **[ungeprüft]**: Felder **in Gruppen** werden dem Modell beschrieben, im Sprechstunden-Assistenten aber nicht übernommen –
  KI-Felder dort nicht in Gruppen legen (vor dem Einsatz testen).
- **KarteiChat** liest bestehende CKE nur über den **Karteitext**. Was „Im Karteitext = Niemals“ hat, sieht er nicht.
- Für KI-taugliche CKE: sprechende, eindeutige Variablennamen; Einheit und Bezug im Anzeigenamen („Gewicht (kg)“);
  geschlossene Antworten als Auswahl mit fester Liste ohne Briefkommandos; Zahlen ohne Einheit im Wert.
