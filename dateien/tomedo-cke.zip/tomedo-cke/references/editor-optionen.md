# CKE-Editor: Optionen je Art

AX-Auslesung des Detailfelds, tomedo-Referenzinstallation, 28.09.2026, überarbeitet im Oktober 2026.
**[ungeprüft]** = noch nicht in der Oberfläche nachgestellt. „Auswahl AycanGDT“ fehlt in der Tabelle,
weil sie dort nicht wählbar war (Arten mit Einstellung: unten).

Öffnen: *Admin › Karteieintragstypen* → Typ wählen → Zeile „CustomKarteieintrag“ › **„Editieren“**. Fenstertitel
„CustomKarteieintragVerwaltung - ‹Name›“.

Immer vorhanden: Anzeigename, Variablenname, Tooltipp, Exportname (Feldname für den DART-Export), Hintergrundfarbe,
Breite Wert. Bei Vitalwert-Arten sind Variablenname, Tooltipp und Exportname gesperrt.

| Art (Menü) | `modus` | zusätzliche Optionen | Vorgabe-Variablenname |
|---|---|---|---|
| Trennlinie | `Trennlinie` | Breite Anzeigename |  |
| Leerzeile | `leer` | Breite Anzeigename |  |
| Gruppe | `Gruppe` | Einrückung, Im Karteitext, ☐ Ausgeklappt |  |
| Gruppe nicht editierbar | `Gruppe nicht editierbar` | Einrückung, Im Karteitext, ☐ Titel verbergen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Nur Anzeigetext | `TextLabel` | Breite Anzeigename, Im Karteitext, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Laufende Nummer | `LaufendeNummer` | Breite Anzeigename, Im Karteitext |  |
| Kontrollkästchen | `Checkbox` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration (Ankreuzkette), Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Kontrollkästchen mit Text | `Checkbox mit Text` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Textfeld | `Text` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Textfeld nicht editierbar | `Text nicht editierbar` | Breite Anzeigename, Im Karteitext, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Text zusammengesetzt nicht editierbar | `Text zusammengesetzt nicht editierbar new` | Breite Anzeigename, Im Karteitext, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl | `Zahl` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl nicht editierbar | `Zahl nicht editierbar` | Breite Anzeigename, Im Karteitext, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Score nicht editierbar | `Score nicht editierbar new` | Breite Anzeigename, Im Karteitext, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl mit Vorzeichen | `Zahl mit Vorzeichen` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl mit Vorzeichen nicht editierbar | `Zahl mit Vorzeichen nicht editierbar` | Breite Anzeigename, Im Karteitext, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Auswahl | `Auswahl` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Mehrfachauswahl | `Mehrfachauswahl` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zeit | `Zeit` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zeit bei Änderung neu berechnet | `ZeitGenerate v2` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zeit mit Start&Stopp | `Zeit Start&Stop` | Breite Anzeigename, Im Karteitext |  |
| Datum | `Datum` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Datum, das auch leer bleiben kann | `DatumMitNil` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Datum bei Änderung neu berechnet | `DatumGenerate v2` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Karteidatum verschieben | `DatumMove` | Breite Anzeigename, Im Karteitext |  |
| Eltern-Körpergröße | `ELKG` | ELKG, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | ELKG |
| Gestationsalter | `Gestationsalter` | Gestationsalter, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Gestationsalter |
| Skelettalter/Knochenalter | `Knochenalter` | Knochenalter, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Knochenalter |
| BMI | `BMI` | BMI, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Vorauswahl, Größe, Gewicht, Schriftgröße f. Vorauswahlkonfig. | BMI |
| Taillenumfang | `Taille` | Taille, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Taille |
| Hautfaltendicke Rücken | `Rückenfalte` | Rückenfalte, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Rückenfalte |
| Hautfaltendicke Trizeps | `Trizepsfalte` | Trizepsfalte, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Trizepsfalte |
| Summe der Hautfaltendicken | `Hautfaltensumme` | Hautfaltensumme, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Hautfaltensumme |
| Geschätzter Körperfettanteil | `Körperfettanteil` | Körperfettanteil, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Körperfettanteil |
| Kopfumfang | `Kopfumfang` | Kopfumfang, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Kopfumfang |
| Hüftumfang | `Hüftumfang` | Hüftumfang, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Hüftumfang |
| Bauchumfang | `Bauchumfang` | Bauchumfang, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Bauchumfang |
| Blutdruck | `Blutdruck` | Blutdruck, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Blutdruck |
| Puls | `Puls` | Puls, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Puls |
| Körpertemperatur | `Körpertemperatur` | Körpertemperatur, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Körpertemperatur |
| SmED/SMASS-Aufruf | `SmED` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Formular aufrufen | `Formular` | Breite Anzeigename, Im Karteitext, Konfiguration |  |
| Aktionskette aufrufen | `Aktionskette` | Breite Anzeigename, Im Karteitext, Konfiguration |  |
| Script | `Skript-Knopf` | Breite Anzeigename, Im Karteitext, Konfiguration | Skript-Knopf |
| Kartei Anhänge | `Anhang` | Breite Anzeigename, Konfiguration, Zeilen |  |

## Menüwerte

- **Breite Anzeigename / Breite Wert / Einrückung:** automatische Breite (−1), 0–12
- **Im Karteitext:** 0 Niemals · 1 Immer · 2 Nur wenn der Wert nicht leer ist · 3 Immer, aber ohne die Anzeigenamen · 4 Nur wenn nicht leer und ohne Anzeigenamen · 5 Nur Anzeigename, wenn Wert nicht leer
- **Konfiguration (Text-Arten, Nur Anzeigetext):** linksbündig · rechtsbündig · zentriert (`alignment` 0/1/2), dazu Feld „Zeilen“
- **Konfiguration (Zahl-Arten, Score):** 0–4 Nachkommastellen (`digets`)
- **Konfiguration (Kontrollkästchen und Kontrollkästchen mit Text):** Ausrichtung und **Ankreuzkette** – Auswahl des
  nächsten Kontrollkästchens (Kein Wert, v2 …), Pfeilknopf springt zum nächsten Glied. Schließt sich die Kette zum Ring,
  wirken die Kästchen wie Optionsknöpfe (ein Haken nimmt die anderen weg), und „Pflichtfeld“ gilt für die ganze Kette.
  Schneller: mehrere Kontrollkästchen markieren → Rechtsklick „selektierte Einträge als Ankreuzkette“. Bei „Kontrollkästchen
  mit Text“ steht der Anzeigename als Beschriftung am Kästchen; die Ausrichtung wirkt nur dort. **[ungeprüft]**
- **Konfiguration (Script):** Auswahl des Skripts. **(Formular aufrufen):** Auswahl des Formulartyps. **(Aktionskette
  aufrufen):** Auswahl der Kette, Knopf „Zur Aktionskettenverwaltung…“. Der Knopf im Eintrag trägt den Anzeigenamen.
- **Konfiguration (BMI):** Vorauswahl getrennt für Größe und Gewicht.
- **Ausgeklappt** (nur Gruppe) und **Titel verbergen** (nur Gruppe nicht editierbar): Programmtext zu „Titel verbergen“:
  „Wenn dieses Feld angehakt ist, wird der Titel dieser bedingten Gruppe nur angezeigt, wenn die bedingte Gruppe
  ausgeklappt ist.“
- **Pflichtfeld** bietet tomedo nur bei Kontrollkästchen (beide), Textfeld, Zahl, Zahl mit Vorzeichen, Auswahl,
  Mehrfachauswahl, „Datum, das auch leer bleiben kann“ und den Vitalwerten an. Fehlt ein Pflichtwert, meldet tomedo
  beim Speichern „Es sind nicht alle Pflichtfelder angegeben.“ und umrandet die Felder rot.
- **Konfiguration (Auswahl, Mehrfachauswahl, Kontrollkästchen):** Token-Feld für die Auswahlwerte (`auswahl`)
- Programmtext zu „Gruppe nicht editierbar“: Die bedingte Gruppe wird zugeklappt, wenn der berechnete Wert 0 ist. Zu Kontrollkästchen mit Vorauswahl: Der Haken wird gesetzt, wenn der finale Text genau `1` ist.

## Arten nur mit Einstellung oder Modul **[ungeprüft]**

Auswahl AycanGDT, Chargendokumentation, Gravidogramm, Arbeitsmedizin, U-Heft-Untersuchung abschließen erscheinen im
Art-Menü nur, wenn die zugehörige Einstellung bzw. das Modul aktiv ist (das Menü wird beim Öffnen des Editors
aufgebaut). OP-Feldarten gibt es nur bei Typen mit Medientyp OP. Altformen „(alt)“, „(v3)“, HL7, REST und Mowoli nur mit
zollsoft-Anmeldung. `python3 scripts/cke.py arten` listet alle.

## Weitere Bedienelemente des Editors **[ungeprüft]**

- **„Allgemeine Einstellungen“** (ausklappbar): Popoverbreite (mindestens 500), Popoverhöhe (leer = automatisch,
  höchstens 750), Spaltenanzahl (Vorgabe 12; eine Änderung fragt nach und passt alle Feldbreiten an), Feld „Karteitext“ mit
  Haken „autom. generieren“. Text- und Hintergrundfarbe des Typs stellt man in der Karteieintragstypenverwaltung ein,
  „auswählbar in Dropdowns/Kommandozeile der Kartei“ ebenfalls dort.
- **Vorschau** rechts („Voransicht des Karteieintrages“) mit „Autom. Neumalen“, „Zeige Felder farbig“, „Zeige
  Pflichtfelder“. Bereich **„TestPatient“**: Patient suchen, „Neumalen mit Vorbefüllung“ wertet die Vorauswahl mit diesem
  Patienten aus, „Karteieintragstext generieren“ zeigt das Feld „zu erwartender Karteieintragstext“. So lässt sich der
  Karteitext prüfen, ohne einen Eintrag anzulegen.
- **Fußleiste:** „+“ (neues Feld, Art Textfeld, Name `vN`, „Im Karteitext“ = Immer), „–“ (löscht nach Rückfrage; das Feld
  wird nur ausgeblendet, alte Einträge behalten es), „Kopie“ (kopiert die markierten Zeilen samt Untergruppen),
  „alle Gruppen zu“, „ in Gruppe“ (neues Feld in der markierten Gruppe). Suchfeld durchsucht Anzeigename, Variablenname,
  Tooltipp und Vorauswahl.
- **Rechtsklick in der Feldliste:** Variablennamen nach Nr. oder fortlaufend ab 1 neu vergeben (überschreibt Namen –
  nur bei neuen Typen!), „selektierte Einträge als Ankreuzkette“, „… als Summe der Variablen für SCORE“ (legt
  `$[v1]$+$[v2]$…` in die Zwischenablage), Zeilen in einen Zwischenspeicher kopieren und in einem **anderen** Typ einsetzen,
  Zeilen einer Gruppe hinzufügen oder herausnehmen. Ziehen ordnet um und verschiebt in Gruppen.
- **„OK“** schließt den Editor. Gespeichert wird sofort; die Prüfungen danach sind nur Hinweise und blockieren nicht:
  „Der Variablenname "…" wurde … mal vergeben.“, „Ein Feld hat keinen Variablennamen. Das kann zu Formatfehlern führen.“
  Zeichen im Variablennamen prüft tomedo nicht.
- **In der Kartei:** Rechtsklick auf einen CKE-Eintrag → „Alle CustomEintrags-Variablennamen“ zeigt Nr., Anzeigename,
  Variablenname und Exportname – praktisch für Briefkommandos.
