# CKE-Editor: Optionen je Art

AX-Auslesung des Detailfelds, tomedo-Referenzinstallation, 28.09.2026. „Auswahl AycanGDT“ fehlt, weil sie dort nicht wählbar war.

Immer vorhanden: Anzeigename, Variablenname, Tooltipp, Exportname, Hintergrundfarbe, Breite Wert.

| Art (Menü) | `modus` | zusätzliche Optionen | Vorgabe-Variablenname |
|---|---|---|---|
| Trennlinie | `Trennlinie` | Breite Anzeigename |  |
| Leerzeile | `leer` | Breite Anzeigename |  |
| Gruppe | `Gruppe` | Einrückung, Im Karteitext, ☐ Ausgeklappt |  |
| Gruppe nicht editierbar | `Gruppe nicht editierbar` | Einrückung, Im Karteitext, ☐ Titel verbergen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Nur Anzeigetext | `TextLabel` | Breite Anzeigename, Im Karteitext, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Laufende Nummer | `LaufendeNummer` | Breite Anzeigename, Im Karteitext |  |
| Kontrollkästchen | `Checkbox` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Kontrollkästchen mit Text | `Checkbox mit Text` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Textfeld | `Text` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Textfeld nicht editierbar | `Text nicht editierbar` | Breite Anzeigename, Im Karteitext, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Text zusammengesetzt nicht editierbar | `Text zusammengesetzt nicht editierbar new` | Breite Anzeigename, Im Karteitext, Konfiguration, Zeilen, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl | `Zahl` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl nicht editierbar | `Zahl nicht editierbar` | Breite Anzeigename, Im Karteitext, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Score nicht editierbar | `Score nicht editierbar new` | Breite Anzeigename, Im Karteitext, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl mit Vorzeichen | `Zahl mit Vorzeichen` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zahl mit Vorzeichen nicht editierbar | `Zahl mit Vorzeichen nicht editierbar` | Breite Anzeigename, Im Karteitext, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Auswahl | `Auswahl` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Mehrfachauswahl | `Mehrfachauswahl` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Konfiguration, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zeit | `Zeit` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zeit bei Änderung neu berechnet | `ZeitGenerate v2` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Zeit mit Start&Stopp | `Zeit Start&Stop` | Breite Anzeigename, Im Karteitext |  |
| Datum | `Datum` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Datum, das auch leer bleiben kann | `DatumMitNil` | Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Datum bei Änderung neu berechnet | `DatumGenerate v2` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Karteidatum verschieben | `DatumMove` | Breite Anzeigename, Im Karteitext |  |
| Eltern-Körpergröße | `ELKG` | ELKG, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | ELKG |
| Gestationsalter | `Gestationsalter` | Gestationsalter, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Gestationsalter |
| Skelettalter/Knochenalter | `Knochenalter` | Knochenalter, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Knochenalter |
| BMI | `BMI` | BMI, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld, Vorauswahl, Größe, Gewicht, Schriftgröße f. Vorauswahlkonfig. | BMI |
| Taillenumfang | `Taille` | Taille, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Taille |
| Hautfaltendicke Rücken | `Rückenfalte` | Rückenfalte, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Rückenfalte |
| Hautfaltendicke Trizeps | `Trizepsfalte` | Trizepsfalte, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Trizepsfalte |
| Summe der Hautfaltendicken | `Hautfaltensumme` | Hautfaltensumme, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Hautfaltensumme |
| Geschätzter Körperfettanteil | `Körperfettanteil` | Körperfettanteil, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Körperfettanteil |
| Kopfumfang | `Kopfumfang` | Kopfumfang, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Kopfumfang |
| Hüftumfang | `Hüftumfang` | Hüftumfang, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Hüftumfang |
| Bauchumfang | `Bauchumfang` | Bauchumfang, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Bauchumfang |
| Blutdruck | `Blutdruck` | Blutdruck, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Blutdruck |
| Puls | `Puls` | Puls, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Puls |
| Körpertemperatur | `Körpertemperatur` | Körpertemperatur, Breite Anzeigename, Im Karteitext, ☐ Pflichtfeld | Körpertemperatur |
| SmED/SMASS-Aufruf | `SmED` | Breite Anzeigename, Im Karteitext, Vorauswahl, Schriftgröße f. Vorauswahlkonfig. |  |
| Formular aufrufen | `Formular` | Breite Anzeigename, Im Karteitext, Konfiguration |  |
| Aktionskette aufrufen | `Aktionskette` | Breite Anzeigename, Im Karteitext, Konfiguration |  |
| Script | `Skript-Knopf` | Breite Anzeigename, Im Karteitext, Konfiguration | Skript-Knopf |
| Kartei Anhänge | `Anhang` | Breite Anzeigename, Konfiguration, Zeilen |  |

## Menüwerte

- **Breite Anzeigename / Breite Wert / Einrückung:** automatische Breite (−1), 0–12
- **Im Karteitext:** 0 Niemals · 1 Immer · 2 Nur wenn der Wert nicht leer ist · 3 Immer, aber ohne die Anzeigenamen · 4 Nur wenn nicht leer und ohne Anzeigenamen · 5 Nur Anzeigename, wenn Wert nicht leer
- **Konfiguration (Text-Arten, Nur Anzeigetext):** linksbündig · rechtsbündig · zentriert (`alignment` 0/1/2), dazu Feld „Zeilen“
- **Konfiguration (Zahl-Arten, Score):** 0–4 Nachkommastellen (`digets`)
- **Konfiguration (Kontrollkästchen mit Text):** Auswahl einer anderen Variable (Kein Wert, v2 …)
- **Konfiguration (Auswahl, Mehrfachauswahl, Kontrollkästchen):** Token-Feld für die Auswahlwerte (`auswahl`)
- Programmtext zu „Gruppe nicht editierbar“: Die bedingte Gruppe wird zugeklappt, wenn der berechnete Wert 0 ist. Zu Kontrollkästchen mit Vorauswahl: Der Haken wird gesetzt, wenn der finale Text genau `1` ist.
