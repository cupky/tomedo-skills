# CKE-Exportformat (.dict)

**Belege**

| Quelle | Stand | Was sie belegt |
|---|---|---|
| Export eines Praxis-CKE (Aufgabenliste, 22 Felder) | 25.09.2026 | Grundformat, 4 Arten |
| Import `TESTCKE` (vom Skript gebaut) | 28.09.2026 | Import klappt, sprechende Variablennamen werden angenommen |
| Export `TESTCKE` mit je einem Feld pro Art und Markierungswerten | 28.09.2026 | alle `modus`-Werte, `showInKarteitext` 0–5, Optionsschlüssel |
| Import `TESTCKE2` (vom Skript gebaut) | 28.09.2026 | Gruppe mit Unterfeldern, Popovergröße 700 × 600, Karteitext mit `$[variable]$`, Vorauswahl, Zahl/Auswahl/Datum-leer werden angenommen und in der Vorschau richtig gezeigt; Anlage am Testpatienten ohne Fehler |
| 21 Hersteller-Vorlagen aus `tomedo.app/Contents/Resources/customKarteieintrag_*.dict` | tomedo v1.170 | Gruppen-Verschachtelung, Popovergröße, Spaltenanzahl, Altformen |

Alle 23 Dateien laufen durch `cke.py rundlauf` identisch.
**Belegt** heißt: im Export gesehen und an der Oberfläche zugeordnet. **Abgeleitet** heißt: gesehen, aber die Zuordnung zur Oberfläche ist geschlossen und nicht geprüft.

## Hülle

Apple-Property-List, XML, UTF-8, Tabulator-Einzug, Schlüssel alphabetisch sortiert.
`plistlib.dump(..., fmt=FMT_XML, sort_keys=True)` erzeugt sie byte-identisch.
**Keine internen Kennungen**: Der Typ hängt nur am Kürzel.
Beim Export schreibt tomedo `~/Desktop/customKarteieintrag_<KÜRZEL>.dict`, ohne Speicherdialog,
und meldet das in einem Hinweisfenster.

## Kopf (Karteieintragstyp)

| Schlüssel | Oberfläche | Status |
|---|---|---|
| `kuerzel`, `name` | Kürzel, Name | belegt |
| `standardMediaTyp` = `Custom`, `custom` = 1 | Standardmedientyp | belegt |
| `farbe` / `backgroundColor` | Textfarbe / Hintergrundfarbe | belegt |
| `customKarteitextFormat` | Karteitext (mit `$[variable]$`) | belegt |
| `popoverWidth` / `popoverHeight` / `columnCount` | Popoverbreite / -höhe / Spaltenanzahl | belegt (Import TESTCKE2: Breite 700 und Höhe 600 erscheinen im Editor) |
| `inKarteiToolbar` | in der Kartei-Toolbar | abgeleitet |
| `visible` | auswählbar in Dropdowns/Kommandozeile | abgeleitet |
| `customKarteitextFormatEdit` | ? („autom. generieren“ aus?) | unklar, 1 lassen |
| `lastUsage` | letzte Nutzung | belegt; Bau setzt „jetzt“ |
| `nutzerdefiniert`, `listenposForKartei`, `standardAuswahl`, `hasBriefMergeTyp`, `hasBriefVorlageFormular`, `shouldCreateMetadaten`, `zahn…` | – | Vorgabewerte übernehmen |

Nicht im Export: Sichtbarkeit „für x-Kommandos“, Vidierbarkeit, ePA-Angaben, Toolbar-Icon.

## Feldzeile (`customKarteiEintragEntries[]`)

| Schlüssel | Oberfläche | Status |
|---|---|---|
| `listenpos` | Nr. (eindeutig; Lücken erlaubt) | belegt |
| `anzeigeName` | Anzeigename (`---` bei Layout-Arten) | belegt |
| `name` | Variablenname (auch sprechend, z. B. `bemerkung`) | belegt |
| `modus` | Art, Tabelle unten | belegt |
| `inv_children_listenpos` | `listenpos` der Elterngruppe, −1 = oberste Ebene | belegt (Hersteller-Vorlagen, Import TESTCKE2) |
| `auswahl` | Auswahlwerte, kommagetrennt; bei Zahl-, Score- und „nicht editierbar“-Arten Vorgabe `1` | belegt / Bedeutung der `1` unklar |
| `tooltip` | Tooltipp | belegt |
| `vorauswahl` | Vorauswahl | belegt |
| `isMandatory` | Pflichtfeld | belegt |
| `showInKarteitext` | Im Karteitext (0–5, unten) | belegt |
| `widthLabel` / `widthValue` | Breite Anzeigename / Breite Wert; −1 = automatische Breite | belegt |
| `widthLabel` / `widthValue` bei Gruppen | Einrückung n → `n` / `12−n` | belegt (Einrückung 2 → widthLabel 2, widthValue 10) |
| `alignment` | Konfiguration links/rechts/zentriert = 0/1/2 | belegt für 0 und 1 |
| `digets` (sic) | Nachkommastellen | abgeleitet (Vorgabe 0 bei Zahl-Arten) |
| `numberOfLines` | Zeilen | belegt |
| `color` | Hintergrundfarbe des Feldes | belegt |
| `value` bei `Gruppe` | Ausgeklappt `"1"` / zugeklappt `"0"` | belegt |
| `customKarteiEintragEntry_listenpos` | vermutlich die Kopplung bei „Kontrollkästchen mit Text“ | unklar, in keiner Datei gesetzt |
| `callKetteAtFirstPos`, `callKetteOnlyOnce`, `stopActiveKette`, `removed` | – | 0 lassen |

**Nicht im Export gefunden:** Exportname und „Titel verbergen“ (Gruppe nicht editierbar). Entweder
exportiert tomedo sie nicht, oder der per AX gesetzte Wert wurde nicht übernommen. Beides ist
ungeprüft.

**Messfehler-Hinweis:** Werte in einzeiligen Textfeldern (Popoverbreite, Exportname), die per AX
gesetzt wurden, fehlen im Export. Werte in mehrzeiligen Textbereichen (Tooltipp, Vorauswahl,
Karteitext) sind angekommen. Wahrscheinlich übernimmt tomedo Textfeldwerte erst beim
Verlassen des Feldes.

## Im Karteitext → `showInKarteitext`

| Wert | Menüeintrag | Spec (`im_karteitext`) |
|---|---|---|
| 0 | Niemals | `niemals` (Vorgabe bei Gruppen) |
| 1 | Immer | `immer` (Vorgabe bei Trennlinie/Leerzeile) |
| 2 | Nur wenn der Wert nicht leer ist | `wenn nicht leer` (Vorgabe des Skripts für Felder) |
| 3 | Immer, aber ohne die Anzeigenamen | `immer ohne anzeigename` |
| 4 | Nur wenn der Wert nicht leer ist und ohne Anzeigenamen | `wenn nicht leer ohne anzeigename` |
| 5 | Anzeige nur vom Anzeigenamen ohne Wert, wenn Wert nicht leer ist | `nur anzeigename wenn nicht leer` |

tomedo selbst setzt bei neuen Feldern 1 („Immer“). Das Skript nimmt 2, damit leere Felder den
Karteitext nicht füllen.

## Art (Menü) ↔ `modus` (alle belegt, 28.09.2026)

| Art | `modus` | Art | `modus` |
|---|---|---|---|
| Trennlinie | `Trennlinie` | Zeit | `Zeit` |
| Leerzeile | `leer` | Zeit bei Änderung neu berechnet | `ZeitGenerate v2` |
| Gruppe | `Gruppe` | Zeit mit Start&Stopp | `Zeit Start&Stop` |
| Gruppe nicht editierbar | `Gruppe nicht editierbar` | Datum | `Datum` |
| Nur Anzeigetext | `TextLabel` | Datum, das auch leer bleiben kann | `DatumMitNil` |
| Laufende Nummer | `LaufendeNummer` | Datum bei Änderung neu berechnet | `DatumGenerate v2` |
| Kontrollkästchen | `Checkbox` | Karteidatum verschieben | `DatumMove` |
| Kontrollkästchen mit Text | `Checkbox mit Text` | Eltern-Körpergröße | `ELKG` |
| Textfeld | `Text` | Gestationsalter | `Gestationsalter` |
| Textfeld nicht editierbar | `Text nicht editierbar` | Skelettalter/Knochenalter | `Knochenalter` |
| Text zusammengesetzt nicht editierbar | `Text zusammengesetzt nicht editierbar new` | BMI | `BMI` |
| Zahl | `Zahl` | Taillenumfang | `Taille` |
| Zahl nicht editierbar | `Zahl nicht editierbar` | Hautfaltendicke Rücken / Trizeps | `Rückenfalte` / `Trizepsfalte` |
| Score nicht editierbar | `Score nicht editierbar new` | Summe der Hautfaltendicken | `Hautfaltensumme` |
| Zahl mit Vorzeichen | `Zahl mit Vorzeichen` | Geschätzter Körperfettanteil | `Körperfettanteil` |
| Zahl mit Vorzeichen nicht editierbar | `Zahl mit Vorzeichen nicht editierbar` | Kopf-/Hüft-/Bauchumfang | `Kopfumfang` / `Hüftumfang` / `Bauchumfang` |
| Auswahl | `Auswahl` | Blutdruck / Puls / Körpertemperatur | gleichnamig |
| Mehrfachauswahl | `Mehrfachauswahl` | SmED/SMASS-Aufruf | `SmED` |
| Formular aufrufen | `Formular` | Aktionskette aufrufen | `Aktionskette` |
| Script | `Skript-Knopf` | Kartei Anhänge | `Anhang` |

- **Vitalwert-Arten** und `Skript-Knopf` setzen den Anzeige- und Variablennamen auf den `modus`.
  Die Hersteller-Vorlagen überschreiben ihn aber (z. B. `u1_kopfumfang`), also ist das nur eine Vorgabe.
- **Auswahl AycanGDT**: lässt sich an der Referenzinstallation nicht wählen (Modul fehlt?), `modus` unbelegt.
- **Altformen**, nur in Hersteller-Vorlagen: `Score nicht editierbar` (ohne *new*), `Gewicht`, `Größe`,
  `uheftabschliessen`. Das Skript liest sie, erzeugt sie aber nicht neu.
- **Formular, Aktionskette, Skript, SmED, Kontrollkästchen mit Text**: Das Ziel (welches Formular,
  welche Kette, welches Feld) ist nicht aus einem Export belegt. Nach dem Import in tomedo einstellen.

## Farbe

`"r#g#b#a"`, vier Kommazahlen 0–1 mit sechs Nachkommastellen, Trenner `#`.
Das Skript nimmt auch `#RRGGBB` an.

## Offene Fragen

1. Was passiert beim Import, wenn das Kürzel schon existiert: überschreiben, doppeln oder abweisen?
2. Schlüssel für Exportname und „Titel verbergen“.
3. Bedeutung der Vorgabe `auswahl = "1"` bei Zahl-, Score- und „nicht editierbar“-Arten
   (Formel? Laut Programmtext klappt eine bedingte Gruppe zu, wenn der berechnete Wert 0 ist).
4. Kopplung bei „Kontrollkästchen mit Text“ und die Konfiguration von Formular, Aktionskette und Skript.
5. `alignment` 2 = zentriert ist nur abgeleitet.
