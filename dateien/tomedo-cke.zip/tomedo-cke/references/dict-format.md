# CKE-Exportformat (.dict)

**Belege**

| Quelle | Stand | Was sie belegt |
|---|---|---|
| Export eines Praxis-CKE (Aufgabenliste, 22 Felder) | 25.09.2026 | Grundformat, 4 Arten |
| Import `TESTCKE` (vom Skript gebaut) | 28.09.2026 | Import klappt, sprechende Variablennamen werden angenommen |
| Export `TESTCKE` mit je einem Feld pro Art und Markierungswerten | 28.09.2026 | alle `modus`-Werte, `showInKarteitext` 0–5, Optionsschlüssel |
| Zweitimport `TESTCKE2` bei vorhandenem Kürzel | 29.09.2026 | kein Überschreiben: neuer Typ `TESTCKE2_import`, gleicher Name, Hinweisfenster |
| Import `TESTCKE2` (vom Skript gebaut) | 28.09.2026 | Gruppe mit Unterfeldern, Popovergröße 700 × 600, Karteitext mit `$[variable]$`, Vorauswahl, Zahl/Auswahl/Datum-leer werden angenommen und in der Vorschau richtig gezeigt; Anlage am Testpatienten ohne Fehler |
| 21 Hersteller-Vorlagen aus `tomedo.app/Contents/Resources/customKarteieintrag_*.dict` | tomedo v1.170 | Gruppen-Verschachtelung, Popovergröße, Spaltenanzahl, Altformen |
| Systematische Überprüfung | Oktober 2026 | Export- und Importregeln, Bedeutung der Schlüssel, weitere Arten |

Alle 23 Dateien laufen durch `cke.py rundlauf` identisch.
**Belegt** heißt: im Export gesehen und an der Oberfläche zugeordnet. **Abgeleitet** heißt: gesehen, aber die Zuordnung zur Oberfläche ist geschlossen und nicht geprüft. **[ungeprüft]** heißt: noch nicht in der Oberfläche nachgestellt — vor dem Einsatz an einer Testakte prüfen.

## Hülle

Apple-Property-List, XML, UTF-8, Tabulator-Einzug, Schlüssel alphabetisch sortiert.
`plistlib.dump(..., fmt=FMT_XML, sort_keys=True)` erzeugt sie byte-identisch.
**Keine internen Kennungen**: Der Typ hängt nur am Kürzel.
Beim Export schreibt tomedo `~/Desktop/customKarteieintrag_<KÜRZEL>.dict`, ohne Speicherdialog,
und meldet das in einem Hinweisfenster („Export wurde nach … geschrieben.“). Leerzeichen und `/ \ ? % * | " < >` fallen
aus dem Dateinamen. **[ungeprüft]**: Eine gleichnamige Datei auf dem Schreibtisch wird ohne Rückfrage überschrieben.

**Was exportiert wird:** jede **gesetzte** Einstellung des Typs und jedes nicht gelöschten Feldes, außer der internen
Kennung. Was nie gesetzt wurde, fehlt in der Datei. **Nicht** exportiert werden Verknüpfungen zu anderen Objekten: das
Ziel von „Formular aufrufen“ und „Aktionskette aufrufen“, Chargen, Brief- und Formularvorlagen des Typs. Das gilt auch
für „Karteieintragstyp kopieren“ in der Verwaltung, das intern denselben Weg nimmt. **[ungeprüft]**

**Import** (Knopf „Import“, eine Datei, kein Dateifilter): Ohne Feldliste meldet tomedo „Die ausgewählte Datei enthält
keinen Karteieintragstypen.“, eine unlesbare Datei „Die Datei ist entweder veraltet oder passt nicht zu diesem Import.“
Gelesen wird jeder Schlüssel, den tomedo kennt; unbekannte werden übergangen. Fehlt `anzeigeName`, nimmt tomedo den
Variablennamen. Ein exportierter **gelöschter** Typ (`visible` = 0) kommt gelöscht an. **[ungeprüft]**

## Kopf (Karteieintragstyp)

| Schlüssel | Oberfläche | Status |
|---|---|---|
| `kuerzel`, `name` | Kürzel, Name | belegt |
| `standardMediaTyp` = `Custom`, `custom` = 1 | Standardmedientyp | belegt |
| `farbe` / `backgroundColor` | Textfarbe / Hintergrundfarbe | belegt |
| `customKarteitextFormat` | Karteitext (mit `$[variable]$`) | belegt |
| `popoverWidth` / `popoverHeight` / `columnCount` | Popoverbreite / -höhe / Spaltenanzahl | belegt (Import TESTCKE2: Breite 700 und Höhe 600 erscheinen im Editor) |
| `inKarteiToolbar` | in der Kartei-Toolbar | Wirkung für CKE-Typen nicht belegt, 0 lassen |
| `visible` | Typ ist nicht gelöscht (0 = gelöscht, in der Liste nur bei „gelöschte anzeigen“) | belegt (Programm) |
| `hiddenForSelection` | **„auswählbar in Dropdowns/Kommandozeile der Kartei“ verneint** (1 = nicht auswählbar). Spec `auswaehlbar` | belegt (Programm); fehlt in Exporten, wenn nie gesetzt |
| `customKarteitextFormatEdit` | „autom. generieren“ **verneint**: 1 = eigenes Format im Feld „Karteitext“ gilt (wenn es nicht leer ist), 0 = automatisch aus „Im Karteitext“ | belegt (Programm); `cke.py` setzt 1 |
| `lastUsage` | letzte Nutzung | belegt; Bau setzt „jetzt“ |
| `nutzerdefiniert`, `listenposForKartei`, `standardAuswahl`, `hasBriefMergeTyp`, `hasBriefVorlageFormular`, `shouldCreateMetadaten`, `zahn…` | – | Vorgabewerte übernehmen |

Sichtbarkeit, Vidierbarkeit, ePA-Angaben und Bild des Typs stehen nur im Export, wenn sie gesetzt sind (im
Test-Export vom 28.09. waren sie es nicht). **[ungeprüft]**

## Feldzeile (`customKarteiEintragEntries[]`)

| Schlüssel | Oberfläche | Status |
|---|---|---|
| `listenpos` | Nr. (eindeutig; Lücken erlaubt) | belegt |
| `anzeigeName` | Anzeigename (`---` bei Layout-Arten) | belegt |
| `name` | Variablenname (auch sprechend, z. B. `bemerkung`) | belegt |
| `modus` | Art, Tabelle unten | belegt |
| `inv_children_listenpos` | `listenpos` der Elterngruppe, −1 = oberste Ebene | belegt (Hersteller-Vorlagen, Import TESTCKE2) |
| `auswahl` | Auswahlwerte, kommagetrennt. Bei Text-, Zahl- und Score-Arten setzt tomedo `1` als Platzhalter ohne Wirkung. Bei „Gruppe nicht editierbar“ = **„Titel verbergen“** (`1`/`0`, tomedo-Vorgabe `0`). Bei „Script“ = Nummer des Skripts **der Quellinstallation**. Bei BMI, Blutdruck, Eltern-Körpergröße, Skelettalter im Eintrag der zweite Wert | belegt (Programm) |
| `tooltip` | Tooltipp | belegt |
| `vorauswahl` | Vorauswahl | belegt |
| `isMandatory` | Pflichtfeld | belegt |
| `showInKarteitext` | Im Karteitext (0–5, unten) | belegt |
| `widthLabel` / `widthValue` | Breite Anzeigename / Breite Wert; −1 = automatische Breite | belegt |
| `widthLabel` / `widthValue` bei Gruppen | Einrückung n → `n` / `12−n` | belegt (Einrückung 2 → widthLabel 2, widthValue 10) |
| `alignment` | Konfiguration links/rechts/zentriert = 0/1/2 | belegt (Programm) |
| `digets` (sic) | Nachkommastellen 0–4 | belegt (Programm) |
| `numberOfLines` | Zeilen | belegt |
| `color` | Hintergrundfarbe des Feldes | belegt |
| `value` bei `Gruppe` | Ausgeklappt `"1"` / zugeklappt `"0"` | belegt |
| `customKarteiEintragEntry_listenpos` | **Ankreuzkette**: `listenpos` des nächsten Kontrollkästchens (beide Kontrollkästchen-Arten), −1 = keine. Wirkt nur als geschlossener Ring, dann wie Optionsknöpfe. Spec `ankreuzkette` | belegt; wird exportiert und importiert **[ungeprüft]** |
| `exportName` | **Exportname** = Feldname für den DART-Export | belegt (Programm) |
| `textSyntax` | Textaufbau der Art „Text zusammengesetzt (v3)“ (nur mit zollsoft-Anmeldung) | belegt (Programm), nicht erzeugen |
| `callKetteAtFirstPos`, `callKetteOnlyOnce`, `stopActiveKette`, `removed` | ohne Bedienung und ohne Wirkung im CKE | 0 lassen |

**Exportname und „Titel verbergen“** werden exportiert, wenn sie gesetzt sind: Exportname als `exportName`,
„Titel verbergen“ als `auswahl` der bedingten Gruppe. Der Test-Export vom 28.09. zeigte bei „Gruppe nicht editierbar“
`auswahl = 1`, weil dort „Titel verbergen“ angeklickt worden war. `cke.py` setzt seitdem `0` (tomedo-Vorgabe). **[ungeprüft]**

**Messfehler-Hinweis:** Werte in einzeiligen Textfeldern (Popoverbreite, Exportname), die per AX
gesetzt wurden, fehlen im Export. Werte in mehrzeiligen Textbereichen (Tooltipp, Vorauswahl,
Karteitext) sind angekommen. Wahrscheinlich übernimmt tomedo Textfeldwerte erst beim
Verlassen des Feldes.

## Im Karteitext → `showInKarteitext`

| Wert | Menüeintrag | Spec (`im_karteitext`) |
|---|---|---|
| 0 | Niemals | `niemals` (Vorgabe bei Gruppen) |
| 1 | Immer | `immer` (Vorgabe bei Trennlinie/Leerzeile) |
| 2 | Nur wenn der Wert nicht leer ist | `wenn nicht leer` (Vorgabe des Skripts für Felder) |
| 3 | Immer, aber ohne die Anzeigenamen | `immer ohne anzeigename` |
| 4 | Nur wenn der Wert nicht leer ist und ohne Anzeigenamen | `wenn nicht leer ohne anzeigename` |
| 5 | Anzeige nur vom Anzeigenamen ohne Wert, wenn Wert nicht leer ist | `nur anzeigename wenn nicht leer` |

tomedo selbst setzt bei neuen Feldern 1 („Immer“). Das Skript nimmt 2, damit leere Felder den
Karteitext nicht füllen, bei Kontrollkästchen 5 (sonst steht „Anzeigename: 1“ im Text). Wie die Werte im eigenen
Karteitext-Format wirken: `references/verhalten.md` §3.

## Art (Menü) ↔ `modus` (alle belegt, 28.09.2026)

| Art | `modus` | Art | `modus` |
|---|---|---|---|
| Trennlinie | `Trennlinie` | Zeit | `Zeit` |
| Leerzeile | `leer` | Zeit bei Änderung neu berechnet | `ZeitGenerate v2` |
| Gruppe | `Gruppe` | Zeit mit Start&Stopp | `Zeit Start&Stop` |
| Gruppe nicht editierbar | `Gruppe nicht editierbar` | Datum | `Datum` |
| Nur Anzeigetext | `TextLabel` | Datum, das auch leer bleiben kann | `DatumMitNil` |
| Laufende Nummer | `LaufendeNummer` | Datum bei Änderung neu berechnet | `DatumGenerate v2` |
| Kontrollkästchen | `Checkbox` | Karteidatum verschieben | `DatumMove` |
| Kontrollkästchen mit Text | `Checkbox mit Text` | Eltern-Körpergröße | `ELKG` |
| Textfeld | `Text` | Gestationsalter | `Gestationsalter` |
| Textfeld nicht editierbar | `Text nicht editierbar` | Skelettalter/Knochenalter | `Knochenalter` |
| Text zusammengesetzt nicht editierbar | `Text zusammengesetzt nicht editierbar new` | BMI | `BMI` |
| Zahl | `Zahl` | Taillenumfang | `Taille` |
| Zahl nicht editierbar | `Zahl nicht editierbar` | Hautfaltendicke Rücken / Trizeps | `Rückenfalte` / `Trizepsfalte` |
| Score nicht editierbar | `Score nicht editierbar new` | Summe der Hautfaltendicken | `Hautfaltensumme` |
| Zahl mit Vorzeichen | `Zahl mit Vorzeichen` | Geschätzter Körperfettanteil | `Körperfettanteil` |
| Zahl mit Vorzeichen nicht editierbar | `Zahl mit Vorzeichen nicht editierbar` | Kopf-/Hüft-/Bauchumfang | `Kopfumfang` / `Hüftumfang` / `Bauchumfang` |
| Auswahl | `Auswahl` | Blutdruck / Puls / Körpertemperatur | gleichnamig |
| Mehrfachauswahl | `Mehrfachauswahl` | SmED/SMASS-Aufruf | `SmED` |
| Formular aufrufen | `Formular` | Aktionskette aufrufen | `Aktionskette` |
| Script | `Skript-Knopf` | Kartei Anhänge | `Anhang` |

- **Vitalwert-Arten** und `Skript-Knopf` setzen den Anzeige- und Variablennamen auf den `modus`.
  Die Hersteller-Vorlagen überschreiben ihn aber (z. B. `u1_kopfumfang`), also ist das nur eine Vorgabe.
- **Arten nur mit Einstellung oder Modul** (in keinem Export gesehen) **[ungeprüft]**:

  | Art (Menü) | `modus` | erscheint, wenn |
  |---|---|---|
  | Auswahl AycanGDT | `TextAycanGDT` | immer (an der Referenzinstallation war sie trotzdem nicht wählbar); liest einen Wert aus einer GDT-Datei, Vorauswahl „Kennung Separator Position“ |
  | Chargendokumentation | `Chargendokumentation` | Chargen-Modul aktiv |
  | Gravidogramm | `Gravidogramm` | Gravidogramm im Mutterpass aktiv |
  | Arbeitsmedizin | `Arbeitsmedizin` | Arbeitsmedizin-Modul auf diesem Rechner aktiv |
  | U-Heft-Untersuchung abschließen | `uheftabschliessen` | Einstellung U-Heft-Knopf für CKE aktiv; Untersuchung in tomedo wählen |

- **Nur für Typen mit Medientyp OP:** OP-Bemerkung, OP Operateur 1/2, OP-Anästhesist, OP-Termin, OP-Überweiser,
  OP-Weiterbehandler, OP-Termininfo.
- **Altformen**, für Praxen nicht mehr wählbar (nur mit zollsoft-Anmeldung): `Score nicht editierbar` (ohne *new*,
  „Score nicht editierbar (alt)“), `Text zusammengesetzt nicht editierbar` („(alt)“) und `… v3`, `DatumGenerate`,
  `ZeitGenerate` („(alt)“), HL7, REST, Mowoli („nicht mehr unterstützt“). Ganz ohne Eingabe: `Gewicht`, `Größe` – tomedo
  meldet dann „… nicht kompatibel …“. Das Skript liest sie, erzeugt sie aber nicht neu.
- **Formular aufrufen, Aktionskette aufrufen**: Das Ziel ist eine Verknüpfung und geht beim Export verloren – nach dem
  Import in tomedo wählen. **Script**: Die Skriptnummer der Quelle passt in einer anderen Installation nicht – Skript neu
  wählen. **SmED** hat kein Ziel, braucht aber einen SmED-Zugang. **Kontrollkästchen mit Text** hat kein Ziel; der
  Anzeigename steht als Beschriftung am Kästchen.

## Farbe

`"r#g#b#a"`, vier Kommazahlen 0–1 mit sechs Nachkommastellen, Trenner `#`.
Das Skript nimmt auch `#RRGGBB` an.

## Offene Fragen

1. ~~Import bei vorhandenem Kürzel?~~ **Belegt 29.09.2026:** tomedo überschreibt nicht, sondern legt einen zweiten Typ `KÜRZEL_import` mit gleichem Namen an und zeigt den Hinweis „Das Kürzel existiert schon, es wurde unter … angelegt.“ (Test mit TESTCKE2). **[ungeprüft]**: Gibt es `KÜRZEL_import` schon, heißt der nächste `KÜRZEL_import_2`; ein gelöschter Typ mit dem Kürzel zählt nicht. Vorhandene Karteieinträge bleiben beim alten Typ.
2. ~~Schlüssel für Exportname und „Titel verbergen“~~ → `exportName`, `auswahl` (oben).
3. ~~Bedeutung von `auswahl = "1"`~~ → Platzhalter ohne Wirkung; bei der bedingten Gruppe „Titel verbergen“.
4. ~~Kopplung bei „Kontrollkästchen mit Text“~~ → Ankreuzkette (`customKarteiEintragEntry_listenpos`). Formular- und
   Kettenziel werden nicht exportiert, das Skript nur als Nummer.
5. ~~`alignment` 2~~ → zentriert, belegt.
6. Ob ein exportierter Typ mit gesetzten Vidierungs- und ePA-Angaben diese beim Import übernimmt (noch nicht nachgestellt).
