# Praxis-Interna dieser Installation

**Diese Datei ist absichtlich leer ausgeliefert.** Sie ist der vorgesehene Ort für die
Kürzel und eigenen CKE **Ihrer** Installation. Der übrige Skill arbeitet ohne sie; mit ihr
warnt die Prüfung, bevor ein neuer CKE ein schon vergebenes Kürzel bekommt.

**Warum getrennt:** So lässt sich der Skill weitergeben, ohne dass Praxisinterna
mitwandern.

**Beim Aktualisieren:** Ein neues ZIP ersetzt beim Hochladen den ganzen Skill, auch diese
Datei — sie kommt wieder leer an. Wer sie ausgefüllt hat, sichert sie vorher und legt die
eigene Fassung vor dem Hochladen in das neue ZIP, an dieselbe Stelle
(`references/praxis-interna.md`).

**Erhebungsstand:** _(Datum eintragen)_

---

## Vergebene Karteieintragstyp-Kürzel

Die Liste steht in der Karteieintragstypenverwaltung, Spalte „Kürzel". Eintragen als eine
Zeile, kommagetrennt — das Skript liest genau diese Form:

```
KUERZEL:
```

## Eigene CKE als Vorlage

_(Welche eigenen CKE es gibt, wofür sie stehen und wo ihr Export liegt.)_
