#!/usr/bin/env python3
"""tomedo Custom-Karteieintrag (CKE): Beschreibung (JSON-Spec) <-> Exportdatei (.dict).

Die Exportdatei der Karteieintragstypenverwaltung ist eine Apple-Property-List (XML).

  python3 cke.py zu-spec  <export.dict>            -> JSON-Spec auf stdout
  python3 cke.py bauen    <spec.json> -o <aus.dict> -> importfähige .dict, danach Prüfung
  python3 cke.py pruefen  <datei.dict>              -> Befund, Exitcode 1 bei ERROR
  python3 cke.py rundlauf <export.dict> ...         -> zu-spec + bauen, Vergleich mit Original
  python3 cke.py arten                              -> alle Arten (Menüname -> modus)

Nur Standardbibliothek. Belegstand: references/dict-format.md.
"""
import argparse
import datetime as dt
import json
import os
import plistlib
import re
import sys

HIER = os.path.dirname(os.path.abspath(__file__))

# UI-Bezeichnung (Spalte "Art")  ->  interner Wert "modus".
# Belegt: Export eines CKE mit je einem Feld pro Art, Referenzinstallation 28.09.2026.
ART_ZU_MODUS = {
    "Trennlinie": "Trennlinie",
    "Leerzeile": "leer",
    "Gruppe": "Gruppe",
    "Gruppe nicht editierbar": "Gruppe nicht editierbar",
    "Nur Anzeigetext": "TextLabel",
    "Laufende Nummer": "LaufendeNummer",
    "Kontrollkästchen": "Checkbox",
    "Kontrollkästchen mit Text": "Checkbox mit Text",
    "Textfeld": "Text",
    "Textfeld nicht editierbar": "Text nicht editierbar",
    "Text zusammengesetzt nicht editierbar": "Text zusammengesetzt nicht editierbar new",
    "Zahl": "Zahl",
    "Zahl nicht editierbar": "Zahl nicht editierbar",
    "Score nicht editierbar": "Score nicht editierbar new",
    "Zahl mit Vorzeichen": "Zahl mit Vorzeichen",
    "Zahl mit Vorzeichen nicht editierbar": "Zahl mit Vorzeichen nicht editierbar",
    "Auswahl": "Auswahl",
    "Mehrfachauswahl": "Mehrfachauswahl",
    "Zeit": "Zeit",
    "Zeit bei Änderung neu berechnet": "ZeitGenerate v2",
    "Zeit mit Start&Stopp": "Zeit Start&Stop",
    "Datum": "Datum",
    "Datum, das auch leer bleiben kann": "DatumMitNil",
    "Datum bei Änderung neu berechnet": "DatumGenerate v2",
    "Karteidatum verschieben": "DatumMove",
    "Eltern-Körpergröße": "ELKG",
    "Gestationsalter": "Gestationsalter",
    "Skelettalter/Knochenalter": "Knochenalter",
    "BMI": "BMI",
    "Taillenumfang": "Taille",
    "Hautfaltendicke Rücken": "Rückenfalte",
    "Hautfaltendicke Trizeps": "Trizepsfalte",
    "Summe der Hautfaltendicken": "Hautfaltensumme",
    "Geschätzter Körperfettanteil": "Körperfettanteil",
    "Kopfumfang": "Kopfumfang",
    "Hüftumfang": "Hüftumfang",
    "Bauchumfang": "Bauchumfang",
    "Blutdruck": "Blutdruck",
    "Puls": "Puls",
    "Körpertemperatur": "Körpertemperatur",
    "SmED/SMASS-Aufruf": "SmED",
    "Formular aufrufen": "Formular",
    "Aktionskette aufrufen": "Aktionskette",
    "Script": "Skript-Knopf",
    "Kartei Anhänge": "Anhang",
}
MODUS_ZU_ART = {v: k for k, v in ART_ZU_MODUS.items()}
# Arten, die tomedo nur anbietet, wenn eine Einstellung oder ein Modul aktiv ist
# (Stand 22.10.2026, in keinem Export gesehen): bauen mit Warnung.
ART_BEDINGT = {
    "Auswahl AycanGDT": "TextAycanGDT",
    "Chargendokumentation": "Chargendokumentation",
    "Gravidogramm": "Gravidogramm",
    "Arbeitsmedizin": "Arbeitsmedizin",
    "U-Heft-Untersuchung abschließen": "uheftabschliessen",
}
MODUS_BEDINGT = {v: k for k, v in ART_BEDINGT.items()}
# Im Art-Menü für Praxen nicht wählbar: lesen ja, erzeugen nein.
_ALT = "stammt aus einer älteren Fassung, in tomedo nur noch mit zollsoft-Anmeldung wählbar"
_OP = "gibt es nur bei Karteieintragstypen mit Medientyp OP"
MODUS_ALT = {
    "Gewicht": "älteste Fassung, tomedo zeigt dafür keine Eingabe mehr",
    "Größe": "älteste Fassung, tomedo zeigt dafür keine Eingabe mehr",
    "Score nicht editierbar": _ALT, "Text zusammengesetzt nicht editierbar": _ALT,
    "Text zusammengesetzt nicht editierbar v3": _ALT, "DatumGenerate": _ALT,
    "ZeitGenerate": _ALT, "HL7": _ALT, "REST": _ALT, "AuswahlMowoli": _ALT,
    "OP Bemerkung": _OP, "OP Arzt1": _OP, "OP Arzt2": _OP, "OP Anästhesist": _OP,
    "OP Termin": _OP, "OP Überweiser": _OP, "OP Weiterbehandler": _OP, "OP Termininfo": _OP,
}

GRUPPEN = {"Gruppe", "Gruppe nicht editierbar"}
LAYOUT = {"Trennlinie", "leer"}
CHECKBOX = {"Checkbox", "Checkbox mit Text"}
# Arten, die Anzeige- und Variablenname selbst setzen (= modus).
FESTNAME = {"ELKG", "Gestationsalter", "Knochenalter", "BMI", "Taille", "Rückenfalte",
            "Trizepsfalte", "Hautfaltensumme", "Körperfettanteil", "Kopfumfang", "Hüftumfang",
            "Bauchumfang", "Blutdruck", "Puls", "Körpertemperatur", "Skript-Knopf"}
# Arten, deren Ziel nach dem Import in tomedo gewählt werden muss.
NACHKONFIG = {
    "Formular": "Formulartyp in tomedo wählen: das Ziel wird weder exportiert noch importiert",
    "Aktionskette": "Aktionskette in tomedo wählen: das Ziel wird weder exportiert noch importiert",
    "Skript-Knopf": "Skript in tomedo wählen: eine mitgebrachte Skriptnummer zeigt in einer "
                    "anderen Installation auf ein fremdes oder kein Skript",
    "uheftabschliessen": "U-Untersuchung in tomedo wählen",
}
# Pflichtfeld bietet tomedo nur bei diesen Arten an (Stand 22.10.2026).
PFLICHT_MOEGLICH = CHECKBOX | {
    "Text", "Zahl", "Zahl mit Vorzeichen", "Auswahl", "Mehrfachauswahl", "DatumMitNil",
    "ELKG", "Gestationsalter", "Knochenalter", "BMI", "Taille", "Rückenfalte", "Trizepsfalte",
    "Hautfaltensumme", "Körperfettanteil", "Kopfumfang", "Hüftumfang", "Bauchumfang",
    "Blutdruck", "Puls", "Körpertemperatur"}
# Arten mit Formel in der Vorauswahl; Feldverweise als $[variablenname]$.
FORMEL = {"Score nicht editierbar new", "Gruppe nicht editierbar", "DatumGenerate v2",
          "ZeitGenerate v2", "Text zusammengesetzt nicht editierbar new"}
# Arten, deren Vorauswahl nur beim Anlegen ausgewertet wird (keine Feldverweise).
NUR_VORAUSWAHL = {"Zahl nicht editierbar", "Text nicht editierbar",
                  "Zahl mit Vorzeichen nicht editierbar"}
ZAHLARTEN = {"Zahl", "Zahl nicht editierbar", "Zahl mit Vorzeichen",
             "Zahl mit Vorzeichen nicht editierbar"}
PLATZHALTER = re.compile(r"\$\[([^\[\]$]+)\]\$")

# "Im Karteitext" -> showInKarteitext (belegt 28.09.2026)
IM_KARTEITEXT = {
    "niemals": 0,
    "immer": 1,
    "wenn nicht leer": 2,
    "immer ohne anzeigename": 3,
    "wenn nicht leer ohne anzeigename": 4,
    "nur anzeigename wenn nicht leer": 5,
}
IM_KARTEITEXT_REV = {v: k for k, v in IM_KARTEITEXT.items()}
AUSRICHTUNG = {"links": 0, "rechts": 1, "zentriert": 2}
AUSRICHTUNG_REV = {v: k for k, v in AUSRICHTUNG.items()}

FELD_PFLICHT = [
    "anzeigeName", "callKetteAtFirstPos", "callKetteOnlyOnce",
    "customKarteiEintragEntry_listenpos", "inv_children_listenpos", "isMandatory",
    "listenpos", "modus", "name", "removed", "showInKarteitext", "stopActiveKette",
    "widthLabel", "widthValue",
]
FELD_NULL = {"callKetteAtFirstPos": 0, "callKetteOnlyOnce": 0, "isMandatory": 0, "removed": 0,
             "stopActiveKette": 0, "customKarteiEintragEntry_listenpos": -1,
             "inv_children_listenpos": -1}

KOPF_VORGABE = {
    "backgroundColor": "1.000000#1.000000#1.000000#1.000000",
    "custom": 1,
    "customKarteitextFormatEdit": 1,
    "farbe": "0.000000#0.000000#0.000000#1.000000",
    "hasBriefMergeTyp": 0,
    "hasBriefVorlageFormular": 0,
    "inKarteiToolbar": 0,
    "listenposForKartei": 0.0,
    "nutzerdefiniert": 1,
    "shouldCreateMetadaten": 0,
    "standardAuswahl": "",
    "standardMediaTyp": "Custom",
    "visible": 1,
    "zahnauswahlPopoverAnzeigen": 0,
    "zahnschemaAnzeigen": 0,
}
KOPF_MODELL = {"kuerzel", "name", "farbe", "backgroundColor", "inKarteiToolbar", "visible",
               "popoverWidth", "popoverHeight", "columnCount", "customKarteitextFormat",
               "lastUsage", "customKarteiEintragEntries", "hiddenForSelection"}

def bekannte_kuerzel():
    """Vergebene Kürzel der eigenen Installation aus references/praxis-interna.md.

    Erwartet eine Zeile `KUERZEL: A, B, C`. Fehlt sie (ausgelieferte Leerfassung),
    prüft das Skript ohne diese Warnung.
    """
    p = os.path.join(HIER, "..", "references", "praxis-interna.md")
    try:
        with open(p, encoding="utf-8") as fh:
            for zeile in fh:
                m = re.match(r"^\s*KUERZEL:\s*(.*)$", zeile)
                if m:
                    return {k.strip() for k in m.group(1).split(",") if k.strip()}
    except OSError:
        pass
    return set()


FARBE_ROH = re.compile(r"^\d\.\d{6}#\d\.\d{6}#\d\.\d{6}#\d\.\d{6}$")
FARBE_HEX = re.compile(r"^#?([0-9A-Fa-f]{6})$")
VARIABLE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


def modus_vorgaben():
    p = os.path.join(HIER, "..", "references", "modus_vorgaben.json")
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def farbe_nach_roh(wert):
    if wert is None:
        return None
    if FARBE_ROH.match(wert):
        return wert
    m = FARBE_HEX.match(wert)
    if not m:
        raise ValueError(f"Farbe nicht lesbar: {wert!r} (erwartet #RRGGBB oder r#g#b#a)")
    h = m.group(1)
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return f"{r:.6f}#{g:.6f}#{b:.6f}#1.000000"


def roh_nach_hex(roh):
    r, g, b, _ = (float(x) for x in roh.split("#"))
    return "#" + "".join(f"{round(c * 255):02X}" for c in (r, g, b))


def std_karteitext(modus):
    if modus in GRUPPEN:
        return 0
    if modus in LAYOUT:
        return 1
    # Kontrollkästchen schreiben sonst "Anzeigename: 1" (Stand 22.10.2026)
    if modus in CHECKBOX:
        return 5
    return 2


def ankreuzketten(ents):
    """Geschlossene Ringe aus customKarteiEintragEntry_listenpos in listenpos-Reihenfolge.

    Liefert {listenpos: kettenname}. Ringe in anderer Reihenfolge bleiben roh erhalten.
    """
    ziel = {e["listenpos"]: e.get("customKarteiEintragEntry_listenpos", -1) for e in ents}
    modus = {e["listenpos"]: e.get("modus") for e in ents}
    gesehen, namen = set(), {}
    for start in sorted(ziel):
        if start in gesehen or ziel[start] == -1:
            continue
        ring, p = [], start
        while p in ziel and p not in ring and ziel[p] != -1:
            ring.append(p)
            p = ziel[p]
        gesehen.update(ring)
        if p != start or len(ring) < 2 or any(modus[r] not in CHECKBOX for r in ring):
            continue
        s = sorted(ring)
        if all(ziel[s[i]] == s[(i + 1) % len(s)] for i in range(len(s))):
            for r in s:
                namen[r] = f"kette{len(set(namen.values())) + 1}" if r == s[0] else namen[s[0]]
    return namen


# ---------------------------------------------------------------- dict -> spec
def zu_spec(plist):
    spec = {"kuerzel": plist.get("kuerzel"), "name": plist.get("name")}
    if "farbe" in plist:
        spec["textfarbe"] = plist["farbe"]
    if "backgroundColor" in plist:
        spec["hintergrundfarbe"] = plist["backgroundColor"]
    spec["in_toolbar"] = bool(plist.get("inKarteiToolbar", 0))
    spec["sichtbar"] = bool(plist.get("visible", 1))
    if "hiddenForSelection" in plist:
        spec["auswaehlbar"] = not bool(plist["hiddenForSelection"])
    for k, s in (("popoverWidth", "popover_breite"), ("popoverHeight", "popover_hoehe"),
                 ("columnCount", "spalten"), ("customKarteitextFormat", "karteitext")):
        if k in plist:
            spec[s] = plist[k]
    rest = {k: v for k, v in plist.items()
            if k not in KOPF_MODELL and KOPF_VORGABE.get(k, object()) != v}
    if rest:
        spec["kopf_roh"] = rest
    ohne = sorted(k for k in list(KOPF_VORGABE) + ["farbe", "backgroundColor", "inKarteiToolbar",
                                                   "visible"] if k not in plist)
    if ohne:
        spec["kopf_ohne"] = sorted(set(ohne))
    if "lastUsage" not in plist:
        spec.setdefault("kopf_ohne", []).append("lastUsage")

    vorg = modus_vorgaben()
    ents = sorted(plist["customKarteiEintragEntries"], key=lambda e: e["listenpos"])
    kinder = {}
    for e in ents:
        kinder.setdefault(e.get("inv_children_listenpos", -1), []).append(e)
    positionen = {e["listenpos"] for e in ents}
    ketten = ankreuzketten(ents)

    def feld(e):
        modus = e["modus"]
        if modus in MODUS_ZU_ART:
            f = {"art": MODUS_ZU_ART[modus]}
        elif modus in MODUS_BEDINGT:
            f = {"art": MODUS_BEDINGT[modus]}
        else:
            f = {"modus": modus}
        if not (modus in LAYOUT and e.get("anzeigeName") == "---"):
            f["anzeige"] = e.get("anzeigeName")
        f["variable"] = e.get("name")
        basis = dict(vorg.get(modus, {}))
        gemacht = set(FELD_PFLICHT)
        if e["listenpos"] in ketten:
            f["ankreuzkette"] = ketten[e["listenpos"]]
        if modus == "Gruppe nicht editierbar" and e.get("auswahl") in ("0", "1"):
            if e["auswahl"] != basis.get("auswahl"):
                f["titel_verbergen"] = e["auswahl"] == "1"
        elif "auswahl" in e and not (basis.get("auswahl") == e["auswahl"]):
            f["werte"] = e["auswahl"].split(",") if e["auswahl"] else []
        gemacht.add("auswahl")
        if "auswahl" not in e and "auswahl" in basis:
            f.setdefault("feld_ohne", []).append("auswahl")
        for k, s in (("color", "farbe"), ("numberOfLines", "zeilen"), ("tooltip", "tooltip"),
                     ("vorauswahl", "vorauswahl"), ("digets", "nachkommastellen")):
            gemacht.add(k)
            if k in e and basis.get(k, object()) != e[k]:
                f[s] = e[k]
            elif k not in e and k in basis:
                f.setdefault("feld_ohne", []).append(k)
        gemacht.add("alignment")
        if "alignment" in e and basis.get("alignment", object()) != e["alignment"]:
            f["ausrichtung"] = AUSRICHTUNG_REV.get(e["alignment"], e["alignment"])
        elif "alignment" not in e and "alignment" in basis:
            f.setdefault("feld_ohne", []).append("alignment")
        if modus == "Gruppe":
            gemacht.add("value")
            if "value" in e and e["value"] != basis.get("value"):
                f["ausgeklappt"] = e["value"] == "1"
            elif "value" not in e:
                f.setdefault("feld_ohne", []).append("value")
        if e.get("isMandatory"):
            f["pflicht"] = True
        if modus in GRUPPEN and e["widthLabel"] >= 0 and e["widthLabel"] + e["widthValue"] == 12:
            f["einrueckung"] = e["widthLabel"]
        elif (e["widthLabel"], e["widthValue"]) != (-1, -1):
            f["breite"] = [e["widthLabel"], e["widthValue"]]
        kt = e["showInKarteitext"]
        if kt != std_karteitext(modus):
            f["im_karteitext"] = IM_KARTEITEXT_REV.get(kt, kt)
        roh = {k: v for k, v in e.items() if k not in gemacht and basis.get(k, object()) != v}
        roh.update({k: e[k] for k, n in FELD_NULL.items()
                    if k in e and e[k] != n and k != "inv_children_listenpos"
                    and k != "isMandatory"
                    and not (k == "customKarteiEintragEntry_listenpos"
                             and e["listenpos"] in ketten)})
        # Elternverweis auf eine Position, die es nicht gibt: roh erhalten
        p = e.get("inv_children_listenpos", -1)
        if p != -1 and p not in positionen:
            roh["inv_children_listenpos"] = p
        if roh:
            f["feld_roh"] = roh
        fehlt = [k for k in list(FELD_PFLICHT) + list(basis) if k not in e]
        if fehlt:
            f.setdefault("feld_ohne", []).extend(fehlt)
        if "feld_ohne" in f:
            f["feld_ohne"] = sorted(set(f["feld_ohne"]))
        if e["listenpos"] in kinder:
            f["felder"] = [feld(c) for c in kinder[e["listenpos"]]]
        return f

    wurzel = [e for e in ents if e.get("inv_children_listenpos", -1) in (-1,)
              or e.get("inv_children_listenpos") not in positionen]
    spec["felder"] = [feld(e) for e in wurzel]
    # Reihenfolge merken, falls tomedo Kinder nicht direkt hinter die Gruppe gelegt hat
    reihenfolge = []

    def sammle(e):
        reihenfolge.append(e["listenpos"])
        for c in kinder.get(e["listenpos"], []):
            sammle(c)
    for e in wurzel:
        sammle(e)
    if reihenfolge != list(range(1, len(ents) + 1)):
        spec["_positionen"] = reihenfolge
    return spec


# ---------------------------------------------------------------- spec -> dict
def bauen(spec, zeitstempel=None):
    fehler = []
    vorg = modus_vorgaben()
    kopf = dict(KOPF_VORGABE)
    kopf.update(spec.get("kopf_roh", {}))
    kopf["kuerzel"] = spec["kuerzel"]
    kopf["name"] = spec["name"]
    kopf["farbe"] = farbe_nach_roh(spec.get("textfarbe") or "#000000")
    kopf["backgroundColor"] = farbe_nach_roh(spec.get("hintergrundfarbe") or "#FFFFFF")
    kopf["inKarteiToolbar"] = int(bool(spec.get("in_toolbar", False)))
    kopf["visible"] = int(bool(spec.get("sichtbar", True)))
    if "auswaehlbar" in spec:
        kopf["hiddenForSelection"] = int(not spec["auswaehlbar"])
    for s, k in (("popover_breite", "popoverWidth"), ("popover_hoehe", "popoverHeight"),
                 ("spalten", "columnCount"), ("karteitext", "customKarteitextFormat")):
        if s in spec:
            kopf[k] = spec[s]
    kopf["lastUsage"] = zeitstempel or dt.datetime.now(dt.timezone.utc).replace(
        microsecond=0, tzinfo=None)
    for k in spec.get("kopf_ohne", []):
        kopf.pop(k, None)

    alle = []

    def sammeln(fs):
        for f in fs:
            alle.append(f)
            sammeln(f.get("felder", []))
    sammeln(spec["felder"])
    belegt = {f["variable"] for f in alle if f.get("variable")}
    positionen = spec.get("_positionen") or list(range(1, len(alle) + 1))
    zaehler = iter(positionen)
    naechste = [1]
    eintraege = []
    kettenglieder = {}

    def neue_var():
        while f"v{naechste[0]}" in belegt:
            naechste[0] += 1
        v = f"v{naechste[0]}"
        belegt.add(v)
        return v

    def eintrag(f, eltern):
        pos = next(zaehler)
        art = f.get("art") or f.get("modus")
        modus = f.get("modus") or ART_ZU_MODUS.get(art) or ART_BEDINGT.get(art)
        if modus is None:
            if art in MODUS_ZU_ART or art in MODUS_ALT or f.get("unbelegt_zulassen"):
                modus = art
            else:
                fehler.append(f"Feld {pos}: Art {art!r} ist nicht belegt. `cke.py arten` zeigt die Liste.")
                return
        etikett = f"Feld {pos} ({f.get('anzeige') or art})"
        var = f.get("variable")
        if modus in FESTNAME:
            var = var or modus
        if not var:
            var = neue_var()
        e = {k: v for k, v in FELD_NULL.items()}
        e.update(vorg.get(modus, {}))
        e.update({
            "anzeigeName": f.get("anzeige") or (modus if modus in FESTNAME else "---"),
            "listenpos": pos,
            "modus": modus,
            "name": var,
            "showInKarteitext": std_karteitext(modus),
            "widthLabel": -1,
            "widthValue": -1,
        })
        if eltern is not None:
            e["inv_children_listenpos"] = eltern
        if f.get("pflicht"):
            if modus not in PFLICHT_MOEGLICH:
                fehler.append(f"{etikett}: Pflichtfeld bietet tomedo bei Art {art!r} nicht an")
            e["isMandatory"] = 1
        if "im_karteitext" in f:
            w = f["im_karteitext"]
            if isinstance(w, str):
                if w not in IM_KARTEITEXT:
                    fehler.append(f"{etikett}: im_karteitext {w!r} unbekannt. Erlaubt: "
                                  + ", ".join(IM_KARTEITEXT))
                    w = 2
                else:
                    w = IM_KARTEITEXT[w]
            e["showInKarteitext"] = w
        if "breite" in f:
            b = f["breite"]
            e["widthLabel"], e["widthValue"] = (-1, -1) if b == "auto" else b
        if "einrueckung" in f:
            if modus not in GRUPPEN:
                fehler.append(f"{etikett}: einrueckung gibt es nur bei Gruppen")
            e["widthLabel"], e["widthValue"] = f["einrueckung"], 12 - f["einrueckung"]
        if "werte" in f:
            e["auswahl"] = ",".join(f["werte"])
        if f.get("farbe"):
            e["color"] = farbe_nach_roh(f["farbe"])
        for s, k in (("zeilen", "numberOfLines"), ("tooltip", "tooltip"),
                     ("vorauswahl", "vorauswahl"), ("nachkommastellen", "digets")):
            if s in f:
                e[k] = f[s]
        if "ausrichtung" in f:
            a = f["ausrichtung"]
            e["alignment"] = AUSRICHTUNG[a] if isinstance(a, str) else a
        if "ausgeklappt" in f:
            if modus != "Gruppe":
                fehler.append(f"{etikett}: ausgeklappt gibt es nur bei Art 'Gruppe'")
            e["value"] = "1" if f["ausgeklappt"] else "0"
        if "titel_verbergen" in f:
            if modus != "Gruppe nicht editierbar":
                fehler.append(f"{etikett}: titel_verbergen gibt es nur bei Art 'Gruppe nicht editierbar'")
            e["auswahl"] = "1" if f["titel_verbergen"] else "0"
        if "ankreuzkette" in f:
            if modus not in CHECKBOX:
                fehler.append(f"{etikett}: ankreuzkette gibt es nur bei Kontrollkästchen")
            kettenglieder.setdefault(f["ankreuzkette"], []).append(pos)
        e.update(f.get("feld_roh", {}))
        for k in f.get("feld_ohne", []):
            e.pop(k, None)
        eintraege.append(e)
        if f.get("felder"):
            if modus not in GRUPPEN:
                fehler.append(f"{etikett}: Unterfelder gibt es nur bei Gruppen")
            for c in f["felder"]:
                eintrag(c, pos)

    for f in spec["felder"]:
        eintrag(f, None)
    # Ankreuzkette: Ring in listenpos-Reihenfolge, das letzte Glied zeigt auf das erste
    nach_pos = {e["listenpos"]: e for e in eintraege}
    for kette, glieder in kettenglieder.items():
        if len(glieder) < 2:
            fehler.append(f"Ankreuzkette {kette!r}: braucht mindestens zwei Kontrollkästchen")
            continue
        g = sorted(glieder)
        for i, p in enumerate(g):
            nach_pos[p]["customKarteiEintragEntry_listenpos"] = g[(i + 1) % len(g)]
    kopf["customKarteiEintragEntries"] = eintraege
    return kopf, fehler


# ---------------------------------------------------------------- Prüfung
def pruefen(plist):
    befund = []
    E, W = "ERROR", "WARN"
    for k in ("kuerzel", "name", "standardMediaTyp", "customKarteiEintragEntries"):
        if k not in plist:
            befund.append((E, f"Kopfschlüssel fehlt: {k}"))
    if plist.get("standardMediaTyp") != "Custom":
        befund.append((E, "standardMediaTyp ist nicht 'Custom'"))
    if plist.get("custom") != 1:
        befund.append((E, "custom ist nicht 1"))
    kz = plist.get("kuerzel", "")
    if not kz:
        befund.append((E, "Kürzel ist leer"))
    elif kz in bekannte_kuerzel():
        befund.append((W, f"Kürzel {kz!r} ist in praxis-interna.md als vergeben eingetragen. "
                          "Der Import überschreibt nicht: tomedo legt dann einen zweiten Typ "
                          f"{kz}_import an."))
    for k in ("farbe", "backgroundColor"):
        if k in plist and not FARBE_ROH.match(plist[k]):
            befund.append((E, f"{k}: Farbformat {plist[k]!r} ungültig"))

    ents = plist.get("customKarteiEintragEntries", [])
    if not ents:
        befund.append((E, "keine Felder"))
    by = {e.get("listenpos"): e for e in ents}
    if len(by) != len(ents):
        befund.append((E, "listenpos doppelt vergeben"))
    elif sorted(by) != list(range(1, len(ents) + 1)):
        befund.append((W, "listenpos mit Lücken (kommt in Hersteller-Vorlagen vor, unkritisch)"))
    namen = {}
    einsen = []
    for e in ents:
        p = e.get("listenpos")
        etikett = f"Feld {p} ({e.get('anzeigeName')!r})"
        for k in FELD_PFLICHT:
            if k not in e:
                befund.append((W, f"{etikett}: Schlüssel {k} fehlt (tomedo-Exporte haben ihn)"))
        m = e.get("modus")
        if m in MODUS_ALT:
            befund.append((W, f"{etikett}: modus {m!r} {MODUS_ALT[m]}"))
        elif m in MODUS_BEDINGT:
            befund.append((W, f"{etikett}: Art {MODUS_BEDINGT[m]!r} bietet tomedo nur an, wenn die "
                              "zugehörige Einstellung bzw. das Modul aktiv ist; nach dem Import prüfen"))
        elif m not in MODUS_ZU_ART:
            befund.append((E, f"{etikett}: modus {m!r} ist unbekannt"))
        if m in NACHKONFIG:
            befund.append((W, f"{etikett}: {NACHKONFIG[m]}"))
        if m == "SmED":
            befund.append((W, f"{etikett}: SmED/SMASS öffnet beim Öffnen eines neuen Eintrags sofort "
                              "den Browser und braucht einen SmED-Zugang"))
        if e.get("isMandatory") and m not in PFLICHT_MOEGLICH:
            befund.append((W, f"{etikett}: Pflichtfeld ist gesetzt, tomedo prüft es bei dieser Art nicht"))
        ziel = e.get("customKarteiEintragEntry_listenpos", -1)
        if ziel != -1:
            if m not in CHECKBOX:
                befund.append((E, f"{etikett}: Ankreuzkette gibt es nur bei Kontrollkästchen"))
            elif ziel not in by or by[ziel].get("modus") not in CHECKBOX:
                befund.append((E, f"{etikett}: Ankreuzkette zeigt auf Feld {ziel}, das kein Kontrollkästchen ist"))
        n = e.get("name", "")
        ohne_wert = m in LAYOUT or m in ("TextLabel",) or n == "---"
        if not ohne_wert and m not in FESTNAME and not VARIABLE.match(n):
            befund.append((E, f"{etikett}: Variablenname {n!r} ungültig"))
        if n in namen and not ohne_wert:
            befund.append((E, f"{etikett}: Variablenname {n!r} doppelt (auch Feld {namen[n]})"))
        if not ohne_wert:
            namen[n] = p
        eltern = e.get("inv_children_listenpos", -1)
        if eltern != -1:
            if eltern not in by:
                befund.append((E, f"{etikett}: Elterngruppe {eltern} existiert nicht"))
            elif by[eltern].get("modus") not in GRUPPEN:
                befund.append((E, f"{etikett}: Eltern {eltern} ist keine Gruppe"))
        a = e.get("anzeigeName", "")
        if a != a.strip():
            befund.append((W, f"{etikett}: Anzeigename mit Leerzeichen am Rand"))
        if m in ("Mehrfachauswahl", "Auswahl"):
            werte = e.get("auswahl", "").split(",") if e.get("auswahl") else []
            if not werte or werte == ["1"]:
                befund.append((E, f"{etikett}: {MODUS_ZU_ART[m]} ohne Werte"))
            if any(not w.strip() for w in werte):
                befund.append((E, f"{etikett}: leerer Auswahlwert (doppeltes Komma?)"))
            rand = [w for w in werte if w != w.strip()]
            if rand:
                befund.append((W, f"{etikett}: Auswahlwerte mit Leerzeichen am Rand: {rand}"))
            doppelt = sorted({w for w in werte if werte.count(w) > 1})
            if doppelt:
                befund.append((W, f"{etikett}: doppelte Auswahlwerte: {doppelt}"))
        if "color" in e and not FARBE_ROH.match(e["color"]):
            befund.append((E, f"{etikett}: Farbformat {e['color']!r} ungültig"))
        kt = e.get("showInKarteitext")
        if kt not in IM_KARTEITEXT_REV:
            befund.append((W, f"{etikett}: showInKarteitext {kt!r} unbekannt"))
        wl, wv = e.get("widthLabel"), e.get("widthValue")
        if isinstance(wl, int) and isinstance(wv, int) and wl >= 0 and wl + wv > 12:
            befund.append((W, f"{etikett}: Breite {wl}+{wv} > 12 Spalten"))
        if m in CHECKBOX and kt in (1, 2, 3):
            einsen.append(p)
    if einsen:
        befund.append((W, f"Kontrollkästchen in Feld {', '.join(map(str, einsen))} schreiben „1“ bzw. „0“ "
                          "in den Karteitext; nur den Anzeigenamen bei Haken: im_karteitext "
                          "'nur anzeigename wenn nicht leer'"))
    befund += ketten_pruefen(ents, by)
    befund += karteitext_pruefen(plist, ents)
    befund += formeln_pruefen(ents)
    return befund


def ketten_pruefen(ents, by):
    """Ankreuzketten wirken nur als geschlossener Ring."""
    befund = []
    for e in ents:
        start = e.get("listenpos")
        p, schritte = e.get("customKarteiEintragEntry_listenpos", -1), 0
        if p == -1:
            continue
        while p != start and p in by and schritte <= len(by):
            p = by[p].get("customKarteiEintragEntry_listenpos", -1)
            schritte += 1
        if p != start:
            befund.append(("WARN", f"Feld {start}: Ankreuzkette ist nicht geschlossen und wirkt deshalb nicht"))
    return befund


def karteitext_pruefen(plist, ents):
    """Eigenes Karteitext-Format: $[name]$ liefert das Textstück laut „Im Karteitext“."""
    befund = []
    fmt = plist.get("customKarteitextFormat") or ""
    if not fmt:
        return befund
    if not plist.get("customKarteitextFormatEdit", 1):
        befund.append(("WARN", "Karteitext-Format ist gesetzt, wird aber nicht benutzt "
                               "(„autom. generieren“ ist an, customKarteitextFormatEdit = 0)"))
        return befund
    felder = {e.get("name"): e for e in ents if e.get("name")}
    for t in dict.fromkeys(x.strip() for x in PLATZHALTER.findall(fmt)):
        e = felder.get(t)
        if e is None:
            if VARIABLE.match(t):
                befund.append(("WARN", f"Karteitext: $[{t}]$ ist kein Variablenname dieses CKE; "
                                       "tomedo liest es als Briefkommando"))
            continue
        kt, a = e.get("showInKarteitext"), e.get("anzeigeName") or t
        wert = "1“ bzw. „0" if e.get("modus") in CHECKBOX else "Wert"
        if kt in (1, 2):
            befund.append(("WARN", f"Karteitext: $[{t}]$ wird zu „{a}: {wert}“; für den reinen Wert "
                                   f"im_karteitext 'wenn nicht leer ohne anzeigename' setzen"))
        elif kt == 0:
            befund.append(("WARN", f"Karteitext: $[{t}]$ bleibt leer, weil „Im Karteitext“ = Niemals"))
        elif kt == 5:
            befund.append(("WARN", f"Karteitext: $[{t}]$ liefert nur den Anzeigenamen „{a}“"))
    return befund


def formeln_pruefen(ents):
    """Feldverweise in Vorauswahl und Formeln (Stand 22.10.2026)."""
    befund = []
    pos = {e.get("name"): e for e in ents if e.get("name")}
    for e in ents:
        m, v = e.get("modus"), e.get("vorauswahl") or ""
        refs = [x.strip() for x in PLATZHALTER.findall(v)]
        eigene = [r for r in refs if r in pos]
        etikett = f"Feld {e.get('listenpos')} ({e.get('anzeigeName')!r})"
        if m in NUR_VORAUSWAHL and eigene:
            befund.append(("WARN", f"{etikett}: {MODUS_ZU_ART[m]!r} rechnet nicht, Feldverweise "
                                   f"{eigene} bleiben unaufgelöst; für Formeln 'Score nicht editierbar' nehmen"))
        if m not in FORMEL:
            continue
        leer = [r for r in eigene if pos[r].get("modus") in ZAHLARTEN and not pos[r].get("isMandatory")]
        if m == "Score nicht editierbar new" and leer:
            befund.append(("WARN", f"{etikett}: bleibt {leer} leer, zeigt der Score einen Fehlertext; "
                                   "Pflichtfeld setzen oder in der Formel abfangen"))
        for r in refs:
            if r not in pos:
                if VARIABLE.match(r):
                    befund.append(("WARN", f"{etikett}: Formel nennt $[{r}]$, kein Variablenname dieses "
                                           "CKE; tomedo liest es als Briefkommando"))
                continue
            z = pos[r]
            if z.get("modus") == "BMI":
                befund.append(("WARN", f"{etikett}: $[{r}]$ ist ein BMI-Feld und liefert in Formeln die Größe"))
            elif z.get("modus") == "Blutdruck":
                befund.append(("WARN", f"{etikett}: $[{r}]$ ist ein Blutdruck-Feld und liefert nur den "
                                       "systolischen Wert"))
            elif z.get("modus") in FORMEL and z.get("listenpos", 0) >= e.get("listenpos", 0):
                befund.append(("WARN", f"{etikett}: $[{r}]$ wird erst später berechnet"))
    return befund


def spec_pruefen(spec):
    fehler = []

    def lauf(fs, pfad):
        for i, f in enumerate(fs, start=1):
            for w in f.get("werte", []):
                if "," in w:
                    fehler.append(f"Feld {pfad}{i}: Auswahlwert {w!r} enthält ein Komma – tomedo "
                                  "trennt die Liste an Kommata")
            lauf(f.get("felder", []), f"{pfad}{i}.")
    lauf(spec.get("felder", []), "")
    return fehler


def schreiben(plist, pfad):
    with open(pfad, "wb") as fh:
        plistlib.dump(plist, fh, fmt=plistlib.FMT_XML, sort_keys=True)


def lesen(pfad):
    with open(pfad, "rb") as fh:
        return plistlib.load(fh)


def ausgeben(befund):
    for stufe, text in befund:
        print(f"{stufe:5} {text}")
    n_err = sum(1 for s, _ in befund if s == "ERROR")
    n_warn = sum(1 for s, _ in befund if s == "WARN")
    print(f"-- {n_err} ERROR, {n_warn} WARN")
    return n_err


def rundlauf(pfad):
    orig = lesen(pfad)
    neu, fehler = bauen(zu_spec(orig), zeitstempel=orig.get("lastUsage"))
    if fehler:
        return False, fehler
    if "lastUsage" not in orig:
        neu.pop("lastUsage", None)
    ab = []
    for k in sorted(set(orig) | set(neu)):
        if k != "customKarteiEintragEntries" and orig.get(k) != neu.get(k):
            ab.append(f"Kopf {k}: {orig.get(k)!r} -> {neu.get(k)!r}")
    eo = sorted(orig["customKarteiEintragEntries"], key=lambda e: e["listenpos"])
    en = sorted(neu["customKarteiEintragEntries"], key=lambda e: e["listenpos"])
    if len(eo) != len(en):
        ab.append(f"Feldzahl {len(eo)} -> {len(en)}")
    for a, b in zip(eo, en):
        if a != b:
            d = {k: (a.get(k), b.get(k)) for k in set(a) | set(b) if a.get(k) != b.get(k)}
            ab.append(f"Feld {a['listenpos']}: {d}")
    return not ab, ab


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("zu-spec"); s.add_argument("dict")
    s.add_argument("--hex", action="store_true", help="Farben als #RRGGBB (verliert Nachkommastellen)")
    s = sub.add_parser("bauen"); s.add_argument("spec"); s.add_argument("-o", required=True)
    s = sub.add_parser("pruefen"); s.add_argument("dict")
    s = sub.add_parser("rundlauf"); s.add_argument("dict", nargs="+")
    sub.add_parser("arten")
    a = ap.parse_args()

    if a.cmd == "arten":
        for art, m in ART_ZU_MODUS.items():
            zusatz = " (Name fest)" if m in FESTNAME else ""
            zusatz += " (in tomedo nachkonfigurieren)" if m in NACHKONFIG else ""
            zusatz += " (Formel in der Vorauswahl)" if m in FORMEL else ""
            print(f"{art:40} -> {m}{zusatz}")
        print("\nnur mit Einstellung oder Modul (nicht aus einem Export belegt):")
        for art, m in ART_BEDINGT.items():
            zusatz = " (in tomedo nachkonfigurieren)" if m in NACHKONFIG else ""
            print(f"{art:40} -> {m}{zusatz}")
    elif a.cmd == "zu-spec":
        spec = zu_spec(lesen(a.dict))
        if a.hex:
            for k in ("textfarbe", "hintergrundfarbe"):
                if k in spec:
                    spec[k] = roh_nach_hex(spec[k])

            def hexen(fs):
                for f in fs:
                    if "farbe" in f:
                        f["farbe"] = roh_nach_hex(f["farbe"])
                    hexen(f.get("felder", []))
            hexen(spec["felder"])
        json.dump(spec, sys.stdout, ensure_ascii=False, indent=2, default=str)
        print()
    elif a.cmd == "bauen":
        with open(a.spec, encoding="utf-8") as fh:
            spec = json.load(fh)
        fehler = spec_pruefen(spec)
        plist, bau_fehler = bauen(spec)
        fehler += bau_fehler
        if fehler:
            for t in fehler:
                print("ERROR", t)
            sys.exit(1)
        schreiben(plist, a.o)
        print(f"geschrieben: {a.o}")
        sys.exit(1 if ausgeben(pruefen(lesen(a.o))) else 0)
    elif a.cmd == "pruefen":
        sys.exit(1 if ausgeben(pruefen(lesen(a.dict))) else 0)
    elif a.cmd == "rundlauf":
        alle_ok = True
        for p in a.dict:
            ok, ab = rundlauf(p)
            alle_ok &= ok
            print(("identisch   " if ok else "WEICHT AB   ") + os.path.basename(p))
            for z in ab[:8]:
                print("   ", z)
        sys.exit(0 if alle_ok else 1)


if __name__ == "__main__":
    main()
