#!/usr/bin/env python3
"""tomedo Custom-Karteieintrag (CKE): Beschreibung (JSON-Spec) <-> Exportdatei (.dict).

Die Exportdatei der Karteieintragstypenverwaltung ist eine Apple-Property-List (XML).

  python3 cke.py zu-spec  <export.dict>            -> JSON-Spec auf stdout
  python3 cke.py bauen    <spec.json> -o <aus.dict> -> importfähige .dict, danach Prüfung
  python3 cke.py pruefen  <datei.dict>              -> Befund, Exitcode 1 bei ERROR
  python3 cke.py rundlauf <export.dict> ...         -> zu-spec + bauen, Vergleich mit Original
  python3 cke.py arten                              -> alle belegten Arten

Nur Standardbibliothek. Belegstand: references/dict-format.md.
"""
import argparse
import datetime as dt
import json
import os
import plistlib
import re
import sys

HIER = os.path.dirname(os.path.abspath(__file__))

# UI-Bezeichnung (Spalte "Art")  ->  interner Wert "modus".
# Belegt: Export eines CKE mit je einem Feld pro Art, Referenzinstallation 28.09.2026.
ART_ZU_MODUS = {
    "Trennlinie": "Trennlinie",
    "Leerzeile": "leer",
    "Gruppe": "Gruppe",
    "Gruppe nicht editierbar": "Gruppe nicht editierbar",
    "Nur Anzeigetext": "TextLabel",
    "Laufende Nummer": "LaufendeNummer",
    "Kontrollkästchen": "Checkbox",
    "Kontrollkästchen mit Text": "Checkbox mit Text",
    "Textfeld": "Text",
    "Textfeld nicht editierbar": "Text nicht editierbar",
    "Text zusammengesetzt nicht editierbar": "Text zusammengesetzt nicht editierbar new",
    "Zahl": "Zahl",
    "Zahl nicht editierbar": "Zahl nicht editierbar",
    "Score nicht editierbar": "Score nicht editierbar new",
    "Zahl mit Vorzeichen": "Zahl mit Vorzeichen",
    "Zahl mit Vorzeichen nicht editierbar": "Zahl mit Vorzeichen nicht editierbar",
    "Auswahl": "Auswahl",
    "Mehrfachauswahl": "Mehrfachauswahl",
    "Zeit": "Zeit",
    "Zeit bei Änderung neu berechnet": "ZeitGenerate v2",
    "Zeit mit Start&Stopp": "Zeit Start&Stop",
    "Datum": "Datum",
    "Datum, das auch leer bleiben kann": "DatumMitNil",
    "Datum bei Änderung neu berechnet": "DatumGenerate v2",
    "Karteidatum verschieben": "DatumMove",
    "Eltern-Körpergröße": "ELKG",
    "Gestationsalter": "Gestationsalter",
    "Skelettalter/Knochenalter": "Knochenalter",
    "BMI": "BMI",
    "Taillenumfang": "Taille",
    "Hautfaltendicke Rücken": "Rückenfalte",
    "Hautfaltendicke Trizeps": "Trizepsfalte",
    "Summe der Hautfaltendicken": "Hautfaltensumme",
    "Geschätzter Körperfettanteil": "Körperfettanteil",
    "Kopfumfang": "Kopfumfang",
    "Hüftumfang": "Hüftumfang",
    "Bauchumfang": "Bauchumfang",
    "Blutdruck": "Blutdruck",
    "Puls": "Puls",
    "Körpertemperatur": "Körpertemperatur",
    "SmED/SMASS-Aufruf": "SmED",
    "Formular aufrufen": "Formular",
    "Aktionskette aufrufen": "Aktionskette",
    "Script": "Skript-Knopf",
    "Kartei Anhänge": "Anhang",
}
MODUS_ZU_ART = {v: k for k, v in ART_ZU_MODUS.items()}
# Nur in Hersteller-Vorlagen gesehen, im Art-Menü nicht (mehr) wählbar: lesen ja, erzeugen nein.
MODUS_ALT = {"Gewicht", "Größe", "uheftabschliessen", "Score nicht editierbar",
             "Text zusammengesetzt nicht editierbar", "Text zusammengesetzt nicht editierbar v3"}

GRUPPEN = {"Gruppe", "Gruppe nicht editierbar"}
LAYOUT = {"Trennlinie", "leer"}
# Arten, die Anzeige- und Variablenname selbst setzen (= modus).
FESTNAME = {"ELKG", "Gestationsalter", "Knochenalter", "BMI", "Taille", "Rückenfalte",
            "Trizepsfalte", "Hautfaltensumme", "Körperfettanteil", "Kopfumfang", "Hüftumfang",
            "Bauchumfang", "Blutdruck", "Puls", "Körpertemperatur", "Skript-Knopf"}
# Arten, die in tomedo nachkonfiguriert werden müssen (Ziel ist im Export nicht belegt).
NACHKONFIG = {"Formular", "Aktionskette", "Skript-Knopf", "SmED", "Checkbox mit Text"}

# "Im Karteitext" -> showInKarteitext (belegt 28.09.2026)
IM_KARTEITEXT = {
    "niemals": 0,
    "immer": 1,
    "wenn nicht leer": 2,
    "immer ohne anzeigename": 3,
    "wenn nicht leer ohne anzeigename": 4,
    "nur anzeigename wenn nicht leer": 5,
}
IM_KARTEITEXT_REV = {v: k for k, v in IM_KARTEITEXT.items()}
AUSRICHTUNG = {"links": 0, "rechts": 1, "zentriert": 2}
AUSRICHTUNG_REV = {v: k for k, v in AUSRICHTUNG.items()}

FELD_PFLICHT = [
    "anzeigeName", "callKetteAtFirstPos", "callKetteOnlyOnce",
    "customKarteiEintragEntry_listenpos", "inv_children_listenpos", "isMandatory",
    "listenpos", "modus", "name", "removed", "showInKarteitext", "stopActiveKette",
    "widthLabel", "widthValue",
]
FELD_NULL = {"callKetteAtFirstPos": 0, "callKetteOnlyOnce": 0, "isMandatory": 0, "removed": 0,
             "stopActiveKette": 0, "customKarteiEintragEntry_listenpos": -1,
             "inv_children_listenpos": -1}

KOPF_VORGABE = {
    "backgroundColor": "1.000000#1.000000#1.000000#1.000000",
    "custom": 1,
    "customKarteitextFormatEdit": 1,
    "farbe": "0.000000#0.000000#0.000000#1.000000",
    "hasBriefMergeTyp": 0,
    "hasBriefVorlageFormular": 0,
    "inKarteiToolbar": 0,
    "listenposForKartei": 0.0,
    "nutzerdefiniert": 1,
    "shouldCreateMetadaten": 0,
    "standardAuswahl": "",
    "standardMediaTyp": "Custom",
    "visible": 1,
    "zahnauswahlPopoverAnzeigen": 0,
    "zahnschemaAnzeigen": 0,
}
KOPF_MODELL = {"kuerzel", "name", "farbe", "backgroundColor", "inKarteiToolbar", "visible",
               "popoverWidth", "popoverHeight", "columnCount", "customKarteitextFormat",
               "lastUsage", "customKarteiEintragEntries"}

def bekannte_kuerzel():
    """Vergebene Kürzel der eigenen Installation aus references/praxis-interna.md.

    Erwartet eine Zeile `KUERZEL: A, B, C`. Fehlt sie (ausgelieferte Leerfassung),
    prüft das Skript ohne diese Warnung.
    """
    p = os.path.join(HIER, "..", "references", "praxis-interna.md")
    try:
        with open(p, encoding="utf-8") as fh:
            for zeile in fh:
                m = re.match(r"^\s*KUERZEL:\s*(.*)$", zeile)
                if m:
                    return {k.strip() for k in m.group(1).split(",") if k.strip()}
    except OSError:
        pass
    return set()


FARBE_ROH = re.compile(r"^\d\.\d{6}#\d\.\d{6}#\d\.\d{6}#\d\.\d{6}$")
FARBE_HEX = re.compile(r"^#?([0-9A-Fa-f]{6})$")
VARIABLE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


def modus_vorgaben():
    p = os.path.join(HIER, "..", "references", "modus_vorgaben.json")
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def farbe_nach_roh(wert):
    if wert is None:
        return None
    if FARBE_ROH.match(wert):
        return wert
    m = FARBE_HEX.match(wert)
    if not m:
        raise ValueError(f"Farbe nicht lesbar: {wert!r} (erwartet #RRGGBB oder r#g#b#a)")
    h = m.group(1)
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return f"{r:.6f}#{g:.6f}#{b:.6f}#1.000000"


def roh_nach_hex(roh):
    r, g, b, _ = (float(x) for x in roh.split("#"))
    return "#" + "".join(f"{round(c * 255):02X}" for c in (r, g, b))


def std_karteitext(modus):
    if modus in GRUPPEN:
        return 0
    if modus in LAYOUT:
        return 1
    return 2


# ---------------------------------------------------------------- dict -> spec
def zu_spec(plist):
    spec = {"kuerzel": plist.get("kuerzel"), "name": plist.get("name")}
    if "farbe" in plist:
        spec["textfarbe"] = plist["farbe"]
    if "backgroundColor" in plist:
        spec["hintergrundfarbe"] = plist["backgroundColor"]
    spec["in_toolbar"] = bool(plist.get("inKarteiToolbar", 0))
    spec["sichtbar"] = bool(plist.get("visible", 1))
    for k, s in (("popoverWidth", "popover_breite"), ("popoverHeight", "popover_hoehe"),
                 ("columnCount", "spalten"), ("customKarteitextFormat", "karteitext")):
        if k in plist:
            spec[s] = plist[k]
    rest = {k: v for k, v in plist.items()
            if k not in KOPF_MODELL and KOPF_VORGABE.get(k, object()) != v}
    if rest:
        spec["kopf_roh"] = rest
    ohne = sorted(k for k in list(KOPF_VORGABE) + ["farbe", "backgroundColor", "inKarteiToolbar",
                                                   "visible"] if k not in plist)
    if ohne:
        spec["kopf_ohne"] = sorted(set(ohne))
    if "lastUsage" not in plist:
        spec.setdefault("kopf_ohne", []).append("lastUsage")

    vorg = modus_vorgaben()
    ents = sorted(plist["customKarteiEintragEntries"], key=lambda e: e["listenpos"])
    kinder = {}
    for e in ents:
        kinder.setdefault(e.get("inv_children_listenpos", -1), []).append(e)
    positionen = {e["listenpos"] for e in ents}

    def feld(e):
        modus = e["modus"]
        f = {"art": MODUS_ZU_ART[modus]} if modus in MODUS_ZU_ART else {"modus": modus}
        if not (modus in LAYOUT and e.get("anzeigeName") == "---"):
            f["anzeige"] = e.get("anzeigeName")
        f["variable"] = e.get("name")
        basis = dict(vorg.get(modus, {}))
        gemacht = set(FELD_PFLICHT)
        if "auswahl" in e and not (basis.get("auswahl") == e["auswahl"]):
            f["werte"] = e["auswahl"].split(",") if e["auswahl"] else []
        gemacht.add("auswahl")
        if "auswahl" not in e and "auswahl" in basis:
            f.setdefault("feld_ohne", []).append("auswahl")
        for k, s in (("color", "farbe"), ("numberOfLines", "zeilen"), ("tooltip", "tooltip"),
                     ("vorauswahl", "vorauswahl"), ("digets", "nachkommastellen")):
            gemacht.add(k)
            if k in e and basis.get(k, object()) != e[k]:
                f[s] = e[k]
            elif k not in e and k in basis:
                f.setdefault("feld_ohne", []).append(k)
        gemacht.add("alignment")
        if "alignment" in e and basis.get("alignment", object()) != e["alignment"]:
            f["ausrichtung"] = AUSRICHTUNG_REV.get(e["alignment"], e["alignment"])
        elif "alignment" not in e and "alignment" in basis:
            f.setdefault("feld_ohne", []).append("alignment")
        if modus == "Gruppe":
            gemacht.add("value")
            if "value" in e and e["value"] != basis.get("value"):
                f["ausgeklappt"] = e["value"] == "1"
            elif "value" not in e:
                f.setdefault("feld_ohne", []).append("value")
        if e.get("isMandatory"):
            f["pflicht"] = True
        if modus in GRUPPEN and e["widthLabel"] >= 0 and e["widthLabel"] + e["widthValue"] == 12:
            f["einrueckung"] = e["widthLabel"]
        elif (e["widthLabel"], e["widthValue"]) != (-1, -1):
            f["breite"] = [e["widthLabel"], e["widthValue"]]
        kt = e["showInKarteitext"]
        if kt != std_karteitext(modus):
            f["im_karteitext"] = IM_KARTEITEXT_REV.get(kt, kt)
        roh = {k: v for k, v in e.items() if k not in gemacht and basis.get(k, object()) != v}
        roh.update({k: e[k] for k, n in FELD_NULL.items()
                    if k in e and e[k] != n and k != "inv_children_listenpos"
                    and k != "isMandatory"})
        # Elternverweis auf eine Position, die es nicht gibt: roh erhalten
        p = e.get("inv_children_listenpos", -1)
        if p != -1 and p not in positionen:
            roh["inv_children_listenpos"] = p
        if roh:
            f["feld_roh"] = roh
        fehlt = [k for k in list(FELD_PFLICHT) + list(basis) if k not in e]
        if fehlt:
            f.setdefault("feld_ohne", []).extend(fehlt)
        if "feld_ohne" in f:
            f["feld_ohne"] = sorted(set(f["feld_ohne"]))
        if e["listenpos"] in kinder:
            f["felder"] = [feld(c) for c in kinder[e["listenpos"]]]
        return f

    wurzel = [e for e in ents if e.get("inv_children_listenpos", -1) in (-1,)
              or e.get("inv_children_listenpos") not in positionen]
    spec["felder"] = [feld(e) for e in wurzel]
    # Reihenfolge merken, falls tomedo Kinder nicht direkt hinter die Gruppe gelegt hat
    reihenfolge = []

    def sammle(e):
        reihenfolge.append(e["listenpos"])
        for c in kinder.get(e["listenpos"], []):
            sammle(c)
    for e in wurzel:
        sammle(e)
    if reihenfolge != list(range(1, len(ents) + 1)):
        spec["_positionen"] = reihenfolge
    return spec


# ---------------------------------------------------------------- spec -> dict
def bauen(spec, zeitstempel=None):
    fehler = []
    vorg = modus_vorgaben()
    kopf = dict(KOPF_VORGABE)
    kopf.update(spec.get("kopf_roh", {}))
    kopf["kuerzel"] = spec["kuerzel"]
    kopf["name"] = spec["name"]
    kopf["farbe"] = farbe_nach_roh(spec.get("textfarbe") or "#000000")
    kopf["backgroundColor"] = farbe_nach_roh(spec.get("hintergrundfarbe") or "#FFFFFF")
    kopf["inKarteiToolbar"] = int(bool(spec.get("in_toolbar", False)))
    kopf["visible"] = int(bool(spec.get("sichtbar", True)))
    for s, k in (("popover_breite", "popoverWidth"), ("popover_hoehe", "popoverHeight"),
                 ("spalten", "columnCount"), ("karteitext", "customKarteitextFormat")):
        if s in spec:
            kopf[k] = spec[s]
    kopf["lastUsage"] = zeitstempel or dt.datetime.now(dt.timezone.utc).replace(
        microsecond=0, tzinfo=None)
    for k in spec.get("kopf_ohne", []):
        kopf.pop(k, None)

    alle = []

    def sammeln(fs):
        for f in fs:
            alle.append(f)
            sammeln(f.get("felder", []))
    sammeln(spec["felder"])
    belegt = {f["variable"] for f in alle if f.get("variable")}
    positionen = spec.get("_positionen") or list(range(1, len(alle) + 1))
    zaehler = iter(positionen)
    naechste = [1]
    eintraege = []

    def neue_var():
        while f"v{naechste[0]}" in belegt:
            naechste[0] += 1
        v = f"v{naechste[0]}"
        belegt.add(v)
        return v

    def eintrag(f, eltern):
        pos = next(zaehler)
        art = f.get("art") or f.get("modus")
        modus = f.get("modus") or ART_ZU_MODUS.get(art)
        if modus is None:
            if art in MODUS_ZU_ART or art in MODUS_ALT or f.get("unbelegt_zulassen"):
                modus = art
            else:
                fehler.append(f"Feld {pos}: Art {art!r} ist nicht belegt. `cke.py arten` zeigt die Liste.")
                return
        etikett = f"Feld {pos} ({f.get('anzeige') or art})"
        var = f.get("variable")
        if modus in FESTNAME:
            var = var or modus
        if not var:
            var = neue_var()
        e = {k: v for k, v in FELD_NULL.items()}
        e.update(vorg.get(modus, {}))
        e.update({
            "anzeigeName": f.get("anzeige") or (modus if modus in FESTNAME else "---"),
            "listenpos": pos,
            "modus": modus,
            "name": var,
            "showInKarteitext": std_karteitext(modus),
            "widthLabel": -1,
            "widthValue": -1,
        })
        if eltern is not None:
            e["inv_children_listenpos"] = eltern
        if f.get("pflicht"):
            e["isMandatory"] = 1
        if "im_karteitext" in f:
            w = f["im_karteitext"]
            if isinstance(w, str):
                if w not in IM_KARTEITEXT:
                    fehler.append(f"{etikett}: im_karteitext {w!r} unbekannt. Erlaubt: "
                                  + ", ".join(IM_KARTEITEXT))
                    w = 2
                else:
                    w = IM_KARTEITEXT[w]
            e["showInKarteitext"] = w
        if "breite" in f:
            b = f["breite"]
            e["widthLabel"], e["widthValue"] = (-1, -1) if b == "auto" else b
        if "einrueckung" in f:
            if modus not in GRUPPEN:
                fehler.append(f"{etikett}: einrueckung gibt es nur bei Gruppen")
            e["widthLabel"], e["widthValue"] = f["einrueckung"], 12 - f["einrueckung"]
        if "werte" in f:
            e["auswahl"] = ",".join(f["werte"])
        if f.get("farbe"):
            e["color"] = farbe_nach_roh(f["farbe"])
        for s, k in (("zeilen", "numberOfLines"), ("tooltip", "tooltip"),
                     ("vorauswahl", "vorauswahl"), ("nachkommastellen", "digets")):
            if s in f:
                e[k] = f[s]
        if "ausrichtung" in f:
            a = f["ausrichtung"]
            e["alignment"] = AUSRICHTUNG[a] if isinstance(a, str) else a
        if "ausgeklappt" in f:
            if modus != "Gruppe":
                fehler.append(f"{etikett}: ausgeklappt gibt es nur bei Art 'Gruppe'")
            e["value"] = "1" if f["ausgeklappt"] else "0"
        e.update(f.get("feld_roh", {}))
        for k in f.get("feld_ohne", []):
            e.pop(k, None)
        eintraege.append(e)
        if f.get("felder"):
            if modus not in GRUPPEN:
                fehler.append(f"{etikett}: Unterfelder gibt es nur bei Gruppen")
            for c in f["felder"]:
                eintrag(c, pos)

    for f in spec["felder"]:
        eintrag(f, None)
    kopf["customKarteiEintragEntries"] = eintraege
    return kopf, fehler


# ---------------------------------------------------------------- Prüfung
def pruefen(plist):
    befund = []
    E, W = "ERROR", "WARN"
    for k in ("kuerzel", "name", "standardMediaTyp", "customKarteiEintragEntries"):
        if k not in plist:
            befund.append((E, f"Kopfschlüssel fehlt: {k}"))
    if plist.get("standardMediaTyp") != "Custom":
        befund.append((E, "standardMediaTyp ist nicht 'Custom'"))
    if plist.get("custom") != 1:
        befund.append((E, "custom ist nicht 1"))
    kz = plist.get("kuerzel", "")
    if not kz:
        befund.append((E, "Kürzel ist leer"))
    elif kz in bekannte_kuerzel():
        befund.append((W, f"Kürzel {kz!r} ist in praxis-interna.md als vergeben eingetragen. "
                          "Der Import überschreibt nicht: tomedo legt dann einen zweiten Typ "
                          f"{kz}_import an."))
    for k in ("farbe", "backgroundColor"):
        if k in plist and not FARBE_ROH.match(plist[k]):
            befund.append((E, f"{k}: Farbformat {plist[k]!r} ungültig"))

    ents = plist.get("customKarteiEintragEntries", [])
    if not ents:
        befund.append((E, "keine Felder"))
    by = {e.get("listenpos"): e for e in ents}
    if len(by) != len(ents):
        befund.append((E, "listenpos doppelt vergeben"))
    elif sorted(by) != list(range(1, len(ents) + 1)):
        befund.append((W, "listenpos mit Lücken (kommt in Hersteller-Vorlagen vor, unkritisch)"))
    namen = {}
    for e in ents:
        p = e.get("listenpos")
        etikett = f"Feld {p} ({e.get('anzeigeName')!r})"
        for k in FELD_PFLICHT:
            if k not in e:
                befund.append((W, f"{etikett}: Schlüssel {k} fehlt (tomedo-Exporte haben ihn)"))
        m = e.get("modus")
        if m in MODUS_ALT:
            befund.append((W, f"{etikett}: modus {m!r} stammt aus einer älteren Fassung"))
        elif m not in MODUS_ZU_ART:
            befund.append((E, f"{etikett}: modus {m!r} ist unbekannt"))
        if m in NACHKONFIG:
            befund.append((W, f"{etikett}: Art {MODUS_ZU_ART.get(m, m)!r} nach dem Import in tomedo "
                              "konfigurieren (Ziel nicht aus dem Export belegt)"))
        n = e.get("name", "")
        ohne_wert = m in LAYOUT or m in ("TextLabel",) or n == "---"
        if not ohne_wert and m not in FESTNAME and not VARIABLE.match(n):
            befund.append((E, f"{etikett}: Variablenname {n!r} ungültig"))
        if n in namen and not ohne_wert:
            befund.append((E, f"{etikett}: Variablenname {n!r} doppelt (auch Feld {namen[n]})"))
        if not ohne_wert:
            namen[n] = p
        eltern = e.get("inv_children_listenpos", -1)
        if eltern != -1:
            if eltern not in by:
                befund.append((E, f"{etikett}: Elterngruppe {eltern} existiert nicht"))
            elif by[eltern].get("modus") not in GRUPPEN:
                befund.append((E, f"{etikett}: Eltern {eltern} ist keine Gruppe"))
        a = e.get("anzeigeName", "")
        if a != a.strip():
            befund.append((W, f"{etikett}: Anzeigename mit Leerzeichen am Rand"))
        if m in ("Mehrfachauswahl", "Auswahl"):
            werte = e.get("auswahl", "").split(",") if e.get("auswahl") else []
            if not werte or werte == ["1"]:
                befund.append((E, f"{etikett}: {MODUS_ZU_ART[m]} ohne Werte"))
            if any(not w.strip() for w in werte):
                befund.append((E, f"{etikett}: leerer Auswahlwert (doppeltes Komma?)"))
            rand = [w for w in werte if w != w.strip()]
            if rand:
                befund.append((W, f"{etikett}: Auswahlwerte mit Leerzeichen am Rand: {rand}"))
            doppelt = sorted({w for w in werte if werte.count(w) > 1})
            if doppelt:
                befund.append((W, f"{etikett}: doppelte Auswahlwerte: {doppelt}"))
        if "color" in e and not FARBE_ROH.match(e["color"]):
            befund.append((E, f"{etikett}: Farbformat {e['color']!r} ungültig"))
        kt = e.get("showInKarteitext")
        if kt not in IM_KARTEITEXT_REV:
            befund.append((W, f"{etikett}: showInKarteitext {kt!r} unbekannt"))
        wl, wv = e.get("widthLabel"), e.get("widthValue")
        if isinstance(wl, int) and isinstance(wv, int) and wl >= 0 and wl + wv > 12:
            befund.append((W, f"{etikett}: Breite {wl}+{wv} > 12 Spalten"))
    return befund


def spec_pruefen(spec):
    fehler = []

    def lauf(fs, pfad):
        for i, f in enumerate(fs, start=1):
            for w in f.get("werte", []):
                if "," in w:
                    fehler.append(f"Feld {pfad}{i}: Auswahlwert {w!r} enthält ein Komma – tomedo "
                                  "trennt die Liste an Kommata")
            lauf(f.get("felder", []), f"{pfad}{i}.")
    lauf(spec.get("felder", []), "")
    return fehler


def schreiben(plist, pfad):
    with open(pfad, "wb") as fh:
        plistlib.dump(plist, fh, fmt=plistlib.FMT_XML, sort_keys=True)


def lesen(pfad):
    with open(pfad, "rb") as fh:
        return plistlib.load(fh)


def ausgeben(befund):
    for stufe, text in befund:
        print(f"{stufe:5} {text}")
    n_err = sum(1 for s, _ in befund if s == "ERROR")
    n_warn = sum(1 for s, _ in befund if s == "WARN")
    print(f"-- {n_err} ERROR, {n_warn} WARN")
    return n_err


def rundlauf(pfad):
    orig = lesen(pfad)
    neu, fehler = bauen(zu_spec(orig), zeitstempel=orig.get("lastUsage"))
    if fehler:
        return False, fehler
    if "lastUsage" not in orig:
        neu.pop("lastUsage", None)
    ab = []
    for k in sorted(set(orig) | set(neu)):
        if k != "customKarteiEintragEntries" and orig.get(k) != neu.get(k):
            ab.append(f"Kopf {k}: {orig.get(k)!r} -> {neu.get(k)!r}")
    eo = sorted(orig["customKarteiEintragEntries"], key=lambda e: e["listenpos"])
    en = sorted(neu["customKarteiEintragEntries"], key=lambda e: e["listenpos"])
    if len(eo) != len(en):
        ab.append(f"Feldzahl {len(eo)} -> {len(en)}")
    for a, b in zip(eo, en):
        if a != b:
            d = {k: (a.get(k), b.get(k)) for k in set(a) | set(b) if a.get(k) != b.get(k)}
            ab.append(f"Feld {a['listenpos']}: {d}")
    return not ab, ab


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("zu-spec"); s.add_argument("dict")
    s.add_argument("--hex", action="store_true", help="Farben als #RRGGBB (verliert Nachkommastellen)")
    s = sub.add_parser("bauen"); s.add_argument("spec"); s.add_argument("-o", required=True)
    s = sub.add_parser("pruefen"); s.add_argument("dict")
    s = sub.add_parser("rundlauf"); s.add_argument("dict", nargs="+")
    sub.add_parser("arten")
    a = ap.parse_args()

    if a.cmd == "arten":
        for art, m in ART_ZU_MODUS.items():
            zusatz = " (Name fest)" if m in FESTNAME else ""
            zusatz += " (in tomedo nachkonfigurieren)" if m in NACHKONFIG else ""
            print(f"{art:40} -> {m}{zusatz}")
    elif a.cmd == "zu-spec":
        spec = zu_spec(lesen(a.dict))
        if a.hex:
            for k in ("textfarbe", "hintergrundfarbe"):
                if k in spec:
                    spec[k] = roh_nach_hex(spec[k])

            def hexen(fs):
                for f in fs:
                    if "farbe" in f:
                        f["farbe"] = roh_nach_hex(f["farbe"])
                    hexen(f.get("felder", []))
            hexen(spec["felder"])
        json.dump(spec, sys.stdout, ensure_ascii=False, indent=2, default=str)
        print()
    elif a.cmd == "bauen":
        with open(a.spec, encoding="utf-8") as fh:
            spec = json.load(fh)
        fehler = spec_pruefen(spec)
        plist, bau_fehler = bauen(spec)
        fehler += bau_fehler
        if fehler:
            for t in fehler:
                print("ERROR", t)
            sys.exit(1)
        schreiben(plist, a.o)
        print(f"geschrieben: {a.o}")
        sys.exit(1 if ausgeben(pruefen(lesen(a.o))) else 0)
    elif a.cmd == "pruefen":
        sys.exit(1 if ausgeben(pruefen(lesen(a.dict))) else 0)
    elif a.cmd == "rundlauf":
        alle_ok = True
        for p in a.dict:
            ok, ab = rundlauf(p)
            alle_ok &= ok
            print(("identisch   " if ok else "WEICHT AB   ") + os.path.basename(p))
            for z in ab[:8]:
                print("   ", z)
        sys.exit(0 if alle_ok else 1)


if __name__ == "__main__":
    main()
