---
name: tomedo-cke
description: >-
  Erzeugt und ändert tomedo Custom-Karteieinträge (CKE) als importfähige Exportdatei
  (customKarteieintrag_KUERZEL.dict, Apple-Property-List). Verwende diesen Skill IMMER, wenn ein
  neuer Custom-Karteieintrag, ein CKE, ein strukturierter Karteieintrag, eine Eingabemaske für
  die Kartei oder ein Karteieintragstyp mit Feldern gebaut werden soll, oder wenn eine
  exportierte .dict-Datei aus der Karteieintragstypenverwaltung gelesen, umgebaut, geprüft oder
  kopiert werden soll. Auch bei: CustomKarteieintragVerwaltung, Mehrfachauswahl-Feld,
  Kontrollkästchen, Trennlinie, Gruppe, Zahl, Datum, Score, BMI/Vitalwerte im CKE, Variablenname
  im CKE, Auswahlwerte pflegen, Feldfarbe, Im-Karteitext-Einstellung, Popovergröße, Karteitext
  des CKE, CKE importieren, CKE exportieren, CKE aus Feldliste, CKE aus Papierbogen,
  Hersteller-CKE (U-Untersuchungen, Wells-Score, CHA2DS2) als Vorlage. NICHT für Briefkommandos,
  die CKE-Werte auslesen (→ tomedo-kommandos), und nicht für Patientenformulare
  (→ tomedo-patientenformulare).
metadata:
  version: 1.0
---

# tomedo Custom-Karteieinträge (CKE)

Ein CKE ist ein Karteieintragstyp mit dem Standardmedientyp **Custom**. Er zeigt beim
Anlegen ein Popover mit Feldern (Auswahllisten, Textfelder, Kontrollkästchen …) und erfasst
so strukturierte Daten. In tomedo entsteht er unter *Karteieintragstypenverwaltung → Typ
wählen → CustomKarteieintrag „Editieren“*. Über *Export* und *Import* wandert er als
`.dict`-Datei zwischen Installationen.

Der Weg Spec → `cke.py bauen` → Import ist an der Referenzinstallation belegt
(Test-CKE `TESTCKE` und `TESTCKE2` mit Gruppe, Zahl, Auswahl, Datum und Karteitext, 28.09.2026). Dieser Skill schreibt solche Dateien nicht von Hand. Er
beschreibt den CKE als JSON und lässt `scripts/cke.py` daraus die Datei bauen und prüfen.

## Geltungsregel

**Der Export sticht.** Das Format ist an 23 echten Dateien belegt: einem Praxis-CKE,
einem Export mit je einem Feld pro Art und 21 Hersteller-Vorlagen. Alle laufen durch
`cke.py rundlauf` verlustfrei. Was darüber hinausgeht, steht in `references/dict-format.md`
als *abgeleitet* oder *unklar*.
Unbelegte Schlüssel und Feldarten werden **nicht erfunden**: Die Frage wird gestellt, und bis
zur Antwort bleibt die Lücke offen.

## Ablauf

1. **Anforderung klären.** Zweck des Eintrags, Kürzel (kurz, eindeutig, in Großbuchstaben
   üblich), Name, Felder in Reihenfolge. Für jedes Feld: Art, Anzeigename, bei Auswahlfeldern
   die Werte. Fehlt etwas davon, nachfragen und nicht selbst ausdenken. Fachliche Inhalte
   (Auswahlwerte, Skalen) kommen vom Anwender.
2. **Spec schreiben**, ein JSON nach dem Schema unten, Dateiname `<KÜRZEL>.spec.json`.
3. **Bauen und prüfen:**
   ```bash
   python3 scripts/cke.py bauen <KÜRZEL>.spec.json -o customKarteieintrag_<KÜRZEL>.dict
   ```
   Der Bau prüft die Datei danach selbst. Jedes `ERROR` wird behoben, jedes `WARN` dem
   Anwender genannt.
4. **Übergeben** mit der Import-Anleitung (unten) und den offenen Punkten, die dieser CKE
   berührt.

**Bestehenden CKE ändern:** Den Export einlesen (`cke.py zu-spec export.dict > x.spec.json`),
das JSON ändern und neu bauen. Unbekannte Schlüssel des Exports bleiben dabei unter
`kopf_roh` bzw. `feld_roh` erhalten.

## Spec-Schema

```json
{
  "kuerzel": "BEISPIEL",
  "name": "Beispieleintrag",
  "hintergrundfarbe": "#CCE5FF",
  "popover_breite": 700, "popover_hoehe": 600,
  "karteitext": "Schmerz $[nrs]$/10, Ort: $[ort]$",
  "felder": [
    {"art": "Gruppe", "anzeige": "Schmerz", "variable": "g_schmerz", "felder": [
      {"art": "Zahl", "anzeige": "NRS", "variable": "nrs", "nachkommastellen": 0, "pflicht": true},
      {"art": "Mehrfachauswahl", "anzeige": "Ort", "variable": "ort", "werte": ["Kopf", "Rücken"]}
    ]},
    {"art": "Trennlinie"},
    {"art": "Textfeld", "anzeige": "Bemerkung", "variable": "bemerkung", "zeilen": 3},
    {"art": "Kontrollkästchen", "anzeige": "Erledigt", "variable": "erledigt"}
  ]
}
```

**Kopf:** `kuerzel`, `name` (Pflicht); `textfarbe`, `hintergrundfarbe`, `in_toolbar`, `sichtbar`,
`popover_breite`, `popover_hoehe`, `spalten`, `karteitext`.

| Feldschlüssel | Wirkung |
|---|---|
| `art` | Menüname der Art. Alle 45 Arten: `python3 scripts/cke.py arten` |
| `anzeige` | Anzeigename (Layout-Arten brauchen keinen) |
| `variable` | Variablenname; fehlt er, vergibt das Skript `v1`, `v2` … |
| `werte` | Auswahlwerte bei Auswahl/Mehrfachauswahl, **kein Komma in einem Wert** |
| `felder` | Unterfelder, nur bei `Gruppe` / `Gruppe nicht editierbar` |
| `im_karteitext` | `niemals`, `immer`, `wenn nicht leer` (Vorgabe), `immer ohne anzeigename`, `wenn nicht leer ohne anzeigename`, `nur anzeigename wenn nicht leer` |
| `tooltip`, `vorauswahl` | Tooltipp, Vorauswahl (Text, Briefkommandos, Textbausteine) |
| `pflicht` | Pflichtfeld |
| `zeilen` | Zeilenzahl (Text-Arten) |
| `nachkommastellen` | 0–4 (Zahl-Arten) |
| `ausrichtung` | `links`, `rechts`, `zentriert` |
| `breite` | `[Label, Wert]` im 12er-Raster oder `"auto"` (Vorgabe) |
| `einrueckung` | nur Gruppen: 0–12 |
| `ausgeklappt` | nur `Gruppe`: `true` (Vorgabe) / `false` |
| `farbe` | Feldhintergrund `#RRGGBB` |

`zu-spec` erzeugt dazu noch `modus` (Altform ohne Menüeintrag), `feld_roh`/`kopf_roh`
(unbekannte Schlüssel), `feld_ohne`/`kopf_ohne` (Schlüssel, die im Original fehlen) und
`_positionen`. Diese nur durchreichen und nicht selbst schreiben.

**Vorlagen vom Hersteller:** tomedo liefert fertige CKE in
`/…/tomedo.app/Contents/Resources/customKarteieintrag_*.dict` mit (U1–U11, J1/J2, Wells-Score,
CHA2DS2, HAS-BLED, KAI). Mit `zu-spec` werden sie zum Ausgangspunkt eigener Einträge.
Kürzel und Namen vorher ändern.

## Regeln, an denen es sonst schiefgeht

- **Variablennamen sind die Schnittstelle.** Briefkommandos, Statistik und KarteiChat greifen
  über sie auf die Werte zu. Nach dem ersten Produktiveinsatz werden sie nicht mehr
  umbenannt. **Sprechende Namen verwenden** (`schmerzort`, `erledigt_rezept`), sie werden
  beim Import angenommen (belegt 28.09.2026) und machen Kommandos lesbar. Muster
  `[A-Za-z][A-Za-z0-9_]*`, keine Umlaute. `vN` nur, wenn man an einen bestehenden CKE anschließt.
- **Auswahlwerte sind eine Kommaliste.** Ein Komma im Wert teilt ihn in zwei Werte. Das Skript
  weist so etwas ab.
- **Einzelwahl heißt „Auswahl“**, Mehrfachwahl „Mehrfachauswahl“. Eine Skala (NRS 0–10) ist eine
  `Zahl` mit `nachkommastellen: 0` oder eine `Auswahl` mit den Stufen als Werte.
- **Vitalwert-Arten** (BMI, Blutdruck, Puls, Umfänge …) und `Script` bringen einen eigenen
  Variablennamen mit. Mehrere davon im selben CKE brauchen verschiedene `variable`.
- **Nachkonfigurieren in tomedo:** Formular aufrufen, Aktionskette aufrufen, Script, SmED und
  die Kopplung bei „Kontrollkästchen mit Text“. Deren Ziel ist aus keinem Export belegt. Die
  Prüfung weist darauf hin.
- **„Nicht editierbar“-Arten und Score** rechnen mit Formeln. Deren Syntax ist hier nicht
  belegt, sie steht in der tomedo-Hilfe (Konfiguration im Detailfeld).
- **Kürzel nicht doppelt.** Die Prüfung warnt bei Kürzeln, die in
  `references/praxis-interna.md` als vergeben eingetragen sind. Was beim Import mit einem
  vorhandenen Kürzel passiert, ist
  ungeprüft. Zum Testen immer ein neues Kürzel nehmen und nie ein produktives überschreiben.
- **Muster für Aufgabenlisten** (belegt an einem Praxis-CKE): Gruppe = Mehrfachauswahl (farbig) → Textfeld
  „Freitext“ → Kontrollkästchen „Erledigt“ → Trennlinie.

## Import-Anleitung für den Anwender

1. tomedo → *Karteieintragstypenverwaltung* öffnen.
2. Unten rechts *Import* → die `.dict`-Datei wählen.
3. Den neuen Typ in der Liste suchen, *CustomKarteieintrag → Editieren* öffnen und die
   Vorschau rechts ansehen.
4. An einem Testpatienten einmal anlegen und den erzeugten Karteitext prüfen.
5. Gibt es Abweichungen oder eine Fehlermeldung, den Typ wieder exportieren und die Datei
   zurückgeben. Dann wird der Unterschied zum Bau sichtbar.

## Wann welche Datei lesen

- **Vor jedem Bau:** `python3 scripts/cke.py arten`, damit die Art-Namen stimmen. Mehr braucht ein
  einfacher CKE nicht.
- **`references/dict-format.md`:** wenn eine Option gebraucht wird, die im Spec-Schema oben fehlt,
  wenn eine fremde `.dict` merkwürdig aussieht oder wenn ein Import scheitert.
- **`references/editor-optionen.md`:** wenn der Anwender fragt, was eine Art in tomedo alles
  einstellen lässt, oder wenn er eine Einstellung nach dem Import von Hand setzen soll.
- **`beispiele/*.spec.json`:** als Vorlage für den eigenen Spec, TESTCKE2 für Gruppen.
- **`references/modus_vorgaben.json`:** nur das Skript liest es, nicht von Hand ändern.

## Dateien

| Datei | Inhalt |
|---|---|
| `scripts/cke.py` | `bauen`, `pruefen`, `zu-spec`, `rundlauf`, `arten`. Nur Standardbibliothek |
| `references/dict-format.md` | alle Schlüssel mit Belegstatus, Art ↔ `modus`, offene Fragen |
| `references/editor-optionen.md` | welche Optionen der Editor je Art anbietet |
| `references/modus_vorgaben.json` | Schlüssel, die tomedo je Art von sich aus setzt (vom Skript genutzt) |
| `beispiele/TESTCKE.spec.json` | erster Importtest (4 Arten) |
| `beispiele/TESTCKE2.spec.json` | Gruppe mit Unterfeldern, Zahl, Auswahl, Datum, Karteitext; importiert und am Testpatienten angelegt |
| `references/praxis-interna.md` | vergebene Kürzel der eigenen Installation (leer ausgeliefert, selbst befüllen) |
