---
name: tomedo-cke
description: >-
  Erzeugt und ändert tomedo Custom-Karteieinträge (CKE) als importfähige Exportdatei
  (customKarteieintrag_KUERZEL.dict). Verwende diesen Skill IMMER, wenn ein CKE, ein strukturierter
  Karteieintrag, eine Eingabemaske für die Kartei oder ein Karteieintragstyp mit Feldern gebaut werden
  soll, oder wenn eine exportierte .dict-Datei gelesen, umgebaut, geprüft oder kopiert werden soll.
  Auch bei: CustomKarteieintragVerwaltung, Mehrfachauswahl, Kontrollkästchen, Gruppe, Zahl, Datum,
  Score, Score-Formel, bedingte Gruppe, Ankreuzkette, BMI/Vitalwerte, Variablenname, Auswahlwerte,
  Im-Karteitext-Einstellung, Karteitext zeigt doppelte Anzeigenamen, CKE importieren/exportieren, CKE
  aus Papierbogen, CKE-Feld per Aktionskette zurückschreiben, Hersteller-CKE als Vorlage. NICHT für
  Briefkommandos, die CKE-Werte auslesen (→ tomedo-kommandos), und nicht für Patientenformulare
  (→ tomedo-patientenformulare).
metadata:
  version: 1.2
---

# tomedo Custom-Karteieinträge (CKE)

Ein CKE ist ein Karteieintragstyp mit dem Standardmedientyp **Custom**. Er zeigt beim
Anlegen ein Popover mit Feldern (Auswahllisten, Textfelder, Kontrollkästchen …) und erfasst
so strukturierte Daten. In tomedo entsteht er unter *Karteieintragstypenverwaltung → Typ
wählen → CustomKarteieintrag „Editieren“*. Über *Export* und *Import* wandert er als
`.dict`-Datei zwischen Installationen.

Der Weg Spec → `cke.py bauen` → Import ist an der Referenzinstallation belegt
(Test-CKE `TESTCKE` und `TESTCKE2` mit Gruppe, Zahl, Auswahl, Datum und Karteitext, 28.09.2026). Dieser Skill schreibt solche Dateien nicht von Hand. Er
beschreibt den CKE als JSON und lässt `scripts/cke.py` daraus die Datei bauen und prüfen.
Fassung 1.2 ist im Oktober 2026 systematisch überprüft. **[ungeprüft]** = noch nicht in der Oberfläche
nachgestellt — vor dem Einsatz an einer Testakte prüfen.

## Geltungsregel

**Der Export sticht.** Das Format ist an 23 echten Dateien belegt: einem Praxis-CKE,
einem Export mit je einem Feld pro Art und 21 Hersteller-Vorlagen. Alle laufen durch
`cke.py rundlauf` verlustfrei. Was darüber hinausgeht, steht in `references/dict-format.md`
als *abgeleitet* oder *unklar*.
Unbelegte Schlüssel und Feldarten werden **nicht erfunden**: Die Frage wird gestellt, und bis
zur Antwort bleibt die Lücke offen.

## Ablauf

1. **Anforderung klären.** Zweck des Eintrags, Kürzel (kurz, eindeutig, in Großbuchstaben
   üblich), Name, Felder in Reihenfolge. Für jedes Feld: Art, Anzeigename, bei Auswahlfeldern
   die Werte. Fehlt etwas davon, nachfragen und nicht selbst ausdenken. Fachliche Inhalte
   (Auswahlwerte, Skalen) kommen vom Anwender.
2. **Spec schreiben**, ein JSON nach dem Schema unten, Dateiname `<KÜRZEL>.spec.json`.
3. **Bauen und prüfen:**
   ```bash
   python3 scripts/cke.py bauen <KÜRZEL>.spec.json -o customKarteieintrag_<KÜRZEL>.dict
   ```
   Der Bau prüft die Datei danach selbst. Jedes `ERROR` wird behoben, jedes `WARN` dem
   Anwender genannt.
4. **Übergeben** mit der Import-Anleitung (unten) und den offenen Punkten, die dieser CKE
   berührt.

**Bestehenden CKE ändern:** Den Export einlesen (`cke.py zu-spec export.dict > x.spec.json`),
das JSON ändern und neu bauen. Unbekannte Schlüssel des Exports bleiben dabei unter
`kopf_roh` bzw. `feld_roh` erhalten.

## Spec-Schema

```json
{
  "kuerzel": "BEISPIEL",
  "name": "Beispieleintrag",
  "hintergrundfarbe": "#CCE5FF",
  "popover_breite": 700, "popover_hoehe": 600,
  "karteitext": "Schmerz $[nrs]$/10, Ort: $[ort]$",
  "felder": [
    {"art": "Gruppe", "anzeige": "Schmerz", "variable": "g_schmerz", "felder": [
      {"art": "Zahl", "anzeige": "NRS", "variable": "nrs", "nachkommastellen": 0, "pflicht": true,
       "im_karteitext": "wenn nicht leer ohne anzeigename"},
      {"art": "Mehrfachauswahl", "anzeige": "Ort", "variable": "ort", "werte": ["Kopf", "Rücken"],
       "im_karteitext": "wenn nicht leer ohne anzeigename"}
    ]},
    {"art": "Trennlinie"},
    {"art": "Textfeld", "anzeige": "Bemerkung", "variable": "bemerkung", "zeilen": 3},
    {"art": "Kontrollkästchen", "anzeige": "Erledigt", "variable": "erledigt"}
  ]
}
```

**Kopf:** `kuerzel`, `name` (Pflicht); `textfarbe`, `hintergrundfarbe`, `popover_breite` (mindestens 500),
`popover_hoehe` (weglassen = automatisch), `spalten`, `karteitext` (eigenes Format, siehe Regeln), `auswaehlbar`
(`false` = nicht „auswählbar in Dropdowns/Kommandozeile der Kartei“; auch der Sprechstunden-Assistent bietet den Typ
dann nicht an). `sichtbar: false` importiert den Typ als gelöscht, `in_toolbar` hat für CKE keine belegte Wirkung.

| Feldschlüssel | Wirkung |
|---|---|
| `art` | Menüname der Art. Alle 45 Arten und fünf weitere, die tomedo nur mit Einstellung oder Modul anbietet: `python3 scripts/cke.py arten` |
| `anzeige` | Anzeigename (Layout-Arten brauchen keinen) |
| `variable` | Variablenname; fehlt er, vergibt das Skript `v1`, `v2` … |
| `werte` | Auswahlwerte bei Auswahl/Mehrfachauswahl, **kein Komma in einem Wert** |
| `felder` | Unterfelder, nur bei `Gruppe` / `Gruppe nicht editierbar` |
| `im_karteitext` | `niemals`, `immer`, `wenn nicht leer` (Vorgabe), `immer ohne anzeigename`, `wenn nicht leer ohne anzeigename`, `nur anzeigename wenn nicht leer` |
| `tooltip`, `vorauswahl` | Tooltipp, Vorauswahl (Text, Briefkommandos, Textbausteine; beim Anlegen ausgewertet). Bei Score, Gruppe nicht editierbar, Datum/Zeit neu berechnet und Text zusammengesetzt steht hier die **Formel** |
| `pflicht` | Pflichtfeld; nur bei Kontrollkästchen, Textfeld, Zahl, Zahl mit Vorzeichen, Auswahl, Mehrfachauswahl, „Datum, das auch leer bleiben kann“ und Vitalwerten |
| `zeilen` | Zeilenzahl (Text-Arten) |
| `nachkommastellen` | 0–4 (Zahl-Arten) |
| `ausrichtung` | `links`, `rechts`, `zentriert` |
| `breite` | `[Label, Wert]` im 12er-Raster oder `"auto"` (Vorgabe) |
| `einrueckung` | nur Gruppen: 0–12 |
| `ausgeklappt` | nur `Gruppe`: `true` (Vorgabe) / `false` |
| `titel_verbergen` | nur `Gruppe nicht editierbar`: `true` = zugeklappt ganz unsichtbar; Vorgabe `false` |
| `ankreuzkette` | nur Kontrollkästchen: gleicher Name bei mindestens zwei Kästchen → sie wirken wie Optionsknöpfe **[ungeprüft]** |
| `farbe` | Feldhintergrund `#RRGGBB` |

`zu-spec` erzeugt dazu noch `modus` (Altform ohne Menüeintrag), `feld_roh`/`kopf_roh`
(unbekannte Schlüssel), `feld_ohne`/`kopf_ohne` (Schlüssel, die im Original fehlen) und
`_positionen`. Diese nur durchreichen und nicht selbst schreiben.

**Vorlagen vom Hersteller:** tomedo liefert fertige CKE in
`/…/tomedo.app/Contents/Resources/customKarteieintrag_*.dict` mit (U1–U11, J1/J2, Wells-Score,
CHA2DS2, HAS-BLED, KAI). Mit `zu-spec` werden sie zum Ausgangspunkt eigener Einträge.
Kürzel und Namen vorher ändern. Die U- und J-Vorlagen spielt das U-Heft selbst ein (Rückfrage „U-Heft Vorbefüllung
einrichten?“ oder Knopf im U-Heft-Fenster, vorhandene werden übersprungen); die übrigen bietet tomedo nirgends an, sie
gehen nur über *Import*. **[ungeprüft]**

## Regeln, an denen es sonst schiefgeht

- **Variablennamen sind die Schnittstelle.** Briefkommandos, Formeln, Karteitext, Statistik, das
  Zurückschreiben aus Aktionsketten und der Sprechstunden-Assistent greifen über sie auf die Werte zu. Nach dem
  ersten Produktiveinsatz werden sie nicht mehr umbenannt. **Sprechende Namen verwenden** (`schmerzort`,
  `erledigt_rezept`), sie werden beim Import angenommen (belegt 28.09.2026) und machen Kommandos lesbar. Muster
  `[A-Za-z][A-Za-z0-9_]*`, keine Umlaute, jeder Name nur einmal – tomedo selbst prüft keine Zeichen und meldet doppelte
  Namen nur als Hinweis. `vN` nur, wenn man an einen bestehenden CKE anschließt.
- **Auswahlwerte sind eine Kommaliste.** Ein Komma im Wert teilt ihn in zwei Werte. Das Skript
  weist so etwas ab.
- **Einzelwahl heißt „Auswahl“**, Mehrfachwahl „Mehrfachauswahl“. Eine Skala (NRS 0–10) ist eine
  `Zahl` mit `nachkommastellen: 0` oder eine `Auswahl` mit den Stufen als Werte.
- **Vitalwert-Arten** (BMI, Blutdruck, Puls, Umfänge …) und `Script` bringen einen eigenen
  Variablennamen mit. Mehrere davon im selben CKE brauchen verschiedene `variable`.
- **Karteitext mit eigenem Format:** `$[variable]$` setzt **nicht den reinen Wert** ein, sondern das Textstück, das das
  Feld laut „Im Karteitext“ erzeugt – bei „Immer“ und „wenn nicht leer“ also „Anzeigename: Wert“. Felder, die im Format
  vorkommen, deshalb auf `wenn nicht leer ohne anzeigename` stellen. Danach laufen Briefkommandos über den Text.
  `cke.py` warnt. **[ungeprüft]** Ohne eigenes Format verbindet tomedo die Felder mit dem Trennzeichen aus den
  Kartei-Einstellungen (Vorgabe „ ◉ “). Details: `references/verhalten.md` §3.
- **Kontrollkästchen** schreiben bei „Immer“ und „wenn nicht leer“ `Anzeigename: 1`; das Skript stellt sie deshalb von
  sich aus auf `nur anzeigename wenn nicht leer`. **[ungeprüft]**
- **Formeln** gibt es nur bei *Score nicht editierbar*, *Gruppe nicht editierbar* (0 = zugeklappt), *Datum/Zeit bei Änderung
  neu berechnet* und *Text zusammengesetzt nicht editierbar*. Die Formel steht in `vorauswahl`, Felder als
  `$[variable]$`, Wenn/Dann über `FUNCTION('$[a]$','ifGreaterAs:yes:no:','140','1','0')`. Ein leeres Zahlfeld ergibt
  einen Fehlertext im Score; tomedo rechnet bei jedem Öffnen des Eintrags neu. Syntax und Fallen:
  `references/verhalten.md` §2. **[ungeprüft]**
- **„Zahl nicht editierbar“ und „Textfeld nicht editierbar“ rechnen nicht.** Sie bekommen nur beim Anlegen das Ergebnis
  ihrer Vorauswahl (Briefkommandos). Für Rechnungen „Score nicht editierbar“ nehmen.
- **Nachkonfigurieren in tomedo:** Bei *Formular aufrufen* und *Aktionskette aufrufen* geht das Ziel beim Export und beim
  Kopieren eines Typs verloren; *Script* bringt die Skriptnummer der Quellinstallation mit; *U-Heft-Untersuchung
  abschließen* braucht die Untersuchung. Nach dem Import in tomedo wählen. *SmED/SMASS-Aufruf* öffnet beim Anlegen sofort
  den Browser und braucht einen SmED-Zugang. Die Prüfung weist darauf hin. **[ungeprüft]**
- **Vitalwerte erkennt tomedo an der Art, nicht am Namen.** Größe, Gewicht und BMI des Patienten kommen aus dem neuesten
  Feld der Art „BMI“; ein eigenes Zahlfeld „Gewicht“ zählt dafür nicht. In Formeln liefert ein BMI-Feld die Größe, ein
  Blutdruck-Feld nur den systolischen Wert. **[ungeprüft]**
- **Ein Import überschreibt nie** (belegt 29.09.2026). Gibt es das Kürzel schon, legt tomedo
  einen **zweiten** Typ `KÜRZEL_import` mit demselben Namen an und meldet das in einem Hinweis
  („Das Kürzel existiert schon, es wurde unter … angelegt.“; beim nächsten Mal `KÜRZEL_import_2` **[ungeprüft]**).
  Ein geänderter CKE ersetzt den alten also nicht; danach stehen zwei Typen in der Liste. Wer
  umstellen will, entscheidet in tomedo, welcher Typ sichtbar bleibt. Vorhandene Karteieinträge bleiben beim alten Typ
  **[ungeprüft]** — vor dem Umstellen an einem Testpatienten nachsehen. Die Prüfung warnt bei Kürzeln, die in
  `references/praxis-interna.md` als vergeben eingetragen sind.
- **Einen Typ mit vorhandenen Einträgen ändern:** Jeder Eintrag trägt eine eigene Kopie der Felder. Neue Felder fehlen in
  alten Einträgen, gelöschte bleiben dort sichtbar; Anzeigeoptionen wirken über den Variablennamen auch rückwirkend.
  Umbenennen passt Karteitext, Formeln und Briefvorlagen nicht an und warnt nicht. **[ungeprüft]**
- **Aktionsketten und KI:** Eine Kette schreibt mit dem Schritt „Zurückschreiben“ in ausgewählte CKE-Felder des neuesten
  Eintrags (Wert ohne Prüfung, Kontrollkästchen nur mit `1`, Scores werden erst beim nächsten Öffnen neu berechnet). Der
  Sprechstunden-Assistent sieht je Feld nur Variablenname, Anzeigename und Auswahlliste, KarteiChat nur den Karteitext.
  Details und Tipps: `references/verhalten.md` §6–7. **[ungeprüft]**
- **Muster für Aufgabenlisten** (belegt an einem Praxis-CKE): Gruppe = Mehrfachauswahl (farbig) → Textfeld
  „Freitext“ → Kontrollkästchen „Erledigt“ → Trennlinie.

## Import-Anleitung für den Anwender

1. tomedo → *Karteieintragstypenverwaltung* öffnen.
2. Unten rechts *Import* → die `.dict`-Datei wählen.
3. Den neuen Typ in der Liste suchen, *CustomKarteieintrag → Editieren* öffnen und die
   Vorschau rechts ansehen. War das Kürzel schon vergeben, heißt der neue Typ
   `KÜRZEL_import` — der alte bleibt unverändert daneben stehen. Rechts unter „TestPatient“ einen
   Testpatienten wählen, „Neumalen mit Vorbefüllung“ und „Karteieintragstext generieren“ klicken: Das Feld
   „zu erwartender Karteieintragstext“ zeigt den Text, ohne dass ein Eintrag entsteht. **[ungeprüft]**
4. Ziele von *Formular aufrufen*, *Aktionskette aufrufen* und *Script* im Detailfeld wählen, falls vorhanden.
5. An einem Testpatienten einmal anlegen und den erzeugten Karteitext prüfen.
6. Gibt es Abweichungen oder eine Fehlermeldung, den Typ wieder exportieren und die Datei
   zurückgeben. Dann wird der Unterschied zum Bau sichtbar. Achtung: Der Export überschreibt eine gleichnamige
   Datei auf dem Schreibtisch ohne Rückfrage.

## Wann welche Datei lesen

- **Vor jedem Bau:** `python3 scripts/cke.py arten`, damit die Art-Namen stimmen. Mehr braucht ein
  einfacher CKE nicht.
- **`references/dict-format.md`:** wenn eine Option gebraucht wird, die im Spec-Schema oben fehlt,
  wenn eine fremde `.dict` merkwürdig aussieht oder wenn ein Import scheitert.
- **`references/editor-optionen.md`:** wenn der Anwender fragt, was eine Art in tomedo alles
  einstellen lässt, oder wenn er eine Einstellung nach dem Import von Hand setzen soll.
- **`references/verhalten.md`:** bei Formeln und Scores, bedingten Gruppen, Vorauswahl, Karteitext-Format, Vitalwerten,
  beim Ändern eines Typs mit vorhandenen Einträgen und beim Zusammenspiel mit Aktionsketten und KI.
- **`beispiele/*.spec.json`:** als Vorlage für den eigenen Spec, TESTCKE2 für Gruppen.
- **`references/modus_vorgaben.json`:** nur das Skript liest es, nicht von Hand ändern.

## Dateien

| Datei | Inhalt |
|---|---|
| `scripts/cke.py` | `bauen`, `pruefen` (auch Karteitext-Platzhalter, Formelverweise, Pflichtfeld, Ankreuzkette), `zu-spec`, `rundlauf`, `arten`. Nur Standardbibliothek |
| `references/dict-format.md` | alle Schlüssel mit Belegstatus, Art ↔ `modus`, offene Fragen |
| `references/editor-optionen.md` | welche Optionen der Editor je Art anbietet, weitere Bedienelemente |
| `references/verhalten.md` | Vorauswahl, Formeln, Karteitext, Vitalwerte, Typänderung, Aktionsketten, KI |
| `references/modus_vorgaben.json` | Schlüssel, die tomedo je Art von sich aus setzt (vom Skript genutzt) |
| `beispiele/TESTCKE.spec.json` | erster Importtest (4 Arten) |
| `beispiele/TESTCKE2.spec.json` | Gruppe mit Unterfeldern, Zahl, Auswahl, Datum, Karteitext; importiert und am Testpatienten angelegt (28.09.2026). In 1.2 stehen die Karteitext-Felder auf „ohne Anzeigename“ |
| `references/praxis-interna.md` | vergebene Kürzel der eigenen Installation (leer ausgeliefert, selbst befüllen) |
