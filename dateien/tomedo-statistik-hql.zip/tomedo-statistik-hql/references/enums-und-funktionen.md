# Enums (v10), Bitfelder & tomedo-Funktionen

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v11 (2026-10-22, Fassung 1.9): Alle Wertelisten überarbeitet im Oktober 2026.
  Berichtigt: `statuspsychotherapiefall`, `therapieart`, `therapieverfahren`, `goaekatalogeintrag.typ`, `musternummer` 14,
  `aufgabe.availability`/`status`, `customstatistikelement.elementtyp`, Sperrtag-Abfrage (`kalendersperrtag` gibt es nicht),
  OTK-Status; ergänzt: fehlende Werte in fast allen Listen, `nutzertyp`, `qualification_type`, `sqlTyp`-Operatoren,
  Bezugsraum, `patienttyp`, `recalltermin`. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz prüfen.
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- v8 (2026-04-27): keine inhaltlichen Änderungen, nur Versionsstempel-Sync

> Stand: 16.04.2026 · Neu ggü. v6: `nutzer.nutzertyp`, `nutzer.qualification_type` (beide an der Referenzinstallation weitgehend leer).

## Enum-Werte

### Leistung.dtype (Diskriminator)
| Wert | Bedeutung |
|------|-----------|
| `'EBMLeistung'` | EBM-Kassenleistung |
| `'GOAELeistung'` | GOÄ-Privatleistung |
| `'HZVLeistung'` | HZV-Selektivvertragsleistung |
| weitere | `HeilmittelLeistung`, `SammelLeistung`, `BEMALeistung`, `ZahnarztLaborkosten`, `BefundGruppenLeistung`, `DVPLeistung` (AT), `DRGLeistung`; Unter-Unterarten `S3CLeistung` (erbt von EBM, **nicht** von `= 'EBMLeistung'` erfasst) und `RALeistung` (erbt von GOÄ) **[ungeprüft]** |

### Karteieintrag.dtype
| Wert | Bedeutung |
|------|-----------|
| `'Formular'` | Formular-Karteieintrag |
| `'CustomKarteiEintrag'` | Custom-Karteieintrag (CKE) |
| `'OPKarteiEintrag'`, `'ENachricht'`, `'EArztbrief'`, `'WebFormular'`, `'AugendruckEintrag'`, `'KeratometerEintrag'`, `'RefraktionEintrag'` | weitere Unterarten mit eigenen Spalten **[ungeprüft]** |
| `'KarteiEintrag'` | Standard-Karteieinträge |

### Karteieintrag.abrechnungstyp
| Wert | Bedeutung |
|------|-----------|
| 1 | KV / GKV |
| 2 | Privat **[ungeprüft]** |
| 3 | BG **[ungeprüft]** |
| 4 | HZV |

Nur bei `dtype = 'Formular'` sinnvoll; ein Wert 5 wird wie BG behandelt, Bedeutung unklar.

### Diagnose.typ (Diagnosesicherheit)
| Wert | Bedeutung |
|------|-----------|
| A | Ausschluss |
| G | Gesichert |
| V | Verdacht |
| Z | Zustand nach |

tomedo vergleicht in Großbuchstaben und wertet leer wie G — robust `upper(trim(typ))` **[ungeprüft]**.

### Diagnose.abgesetzt **[ungeprüft]**
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | nein |
| 100 | ja, manuell abgesetzt |
| 50 | ja, beim Klonen |
| 51 | ja, beim Löschen vom Schein |
| −100 | nein, manuell (Akutdiagnose bleibt dauerhaft aktiv) |

Regel: ≤ 0 nein, ≥ 1 ja.

### Diagnose.lokalisation
| Wert | Bedeutung |
|------|-----------|
| R | Rechts |
| L | Links |
| B | Beidseitig |

### Medikamentenverordnung.rezepttyp
| Wert | Bedeutung |
|------|-----------|
| 0 | nicht definiert |
| 1 | rot (Kassenrezept) |
| 2 | grün (Empfehlungsrezept, kein GKV-Rezept) |
| 3 | blau (Privatrezept) |
| 4 | BTM |
| 5 | Sprechstundenbedarf (16a) |
| 6 | BTM-Rezept ohne Rand **[ungeprüft]** |
| 7 | T-Rezept **[ungeprüft]** |

### Medikamentenverordnung.absetzungsgrund
| Wert | Bedeutung |
|------|-----------|
| 0 | inaktiv |
| 1 | Unverträglichkeit |
| 2 | automatisch abgesetzt **[ungeprüft]** |

### Privatrechnung.status
| Wert | Bedeutung |
|------|-----------|
| 0 | offen |
| 1 | in Korrektur |
| 2 | in Prüfung |
| 3 | geprüft (mit CRM-Modul „freigegeben“) |
| 4 | zweiter Prüflauf (Anzeige „geprüft“) **[ungeprüft]** |

Prüfstatus, kein Zahlstatus — bezahlt steht in `bezahlt`.

### Privatrechnung.nichtambulant
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | ambulant |
| 1 | belegärztlich |
| 2 | stationär |
| 3 | konsiliarisch **[ungeprüft]** |

### Privatrechnung.behandlungsgrund / auswahladressat / versandtansteuerberater **[ungeprüft]**
- `behandlungsgrund`: 0 Krankheit, 1 Unfall, 2 Schwangerschaft, 3 Vorsorge, 4 Geburtsgebrechen, 5 unbekannt
- `auswahladressat`: 0 Patient, 1 Versicherung, 2 Arbeitgeber
- `versandtansteuerberater`: 0 nicht versandt, 1 manuell, 2 DATEV-Export, 3 XML erzeugt, 4 OSG-Export, 5 OSG-Export nach Storno erneut nötig

### KVSchein.vermittlungsart4103
| Wert | Bedeutung |
|------|-----------|
| 0 | (leer) |
| 1 | TSS-Terminfall |
| 2 | TSS-Akutfall |
| 3 | HA-Vermittlungsfall |
| 4 | Offene Sprechstunde |
| 5 | Neupatient (ab 2023 nicht mehr angeboten) |
| 6 | TSS-Routinefall **[ungeprüft]** |

Dieselben Werte nutzen `termin.tsvgkontaktart` und `terminart.tsvgkontaktart` **[ungeprüft]**.

### GOAEKatalogEintrag.typ **[ungeprüft]**
Tarif der Ziffer. Berichtigt 10/2026: **5 ist UV-GOÄ** (BG-Tarif), nicht „besondere Kosten“.
| Wert | Bedeutung |
|------|-----------|
| 0 | unbekannt |
| 3 | GOÄ |
| 4 | GOÄ/UV-GOÄ |
| 5 | UV-GOÄ |
| 6 | Sachkosten |
| 7 | Zahnarzt (GOZ) |
| 8 | Heilmittelposition |
| 9 | Zahnarzt BU |
| 18 | GOP (Psychotherapeuten privat) |
| 30 | Arbeitsmedizin |
| 40 | UV-GOP (Psychotherapeutenverfahren der DGUV) |
| 10–23 | Schweiz (TARMED, TARDOC, Analysenliste, MiGeL …) |
| 51–70 | Österreich |

Besondere Kosten (`goaekatalogeintrag.besonderekostenincent`) rechnet tomedo nur auf BG-Rechnungen und nur bei aktiver
Systemeinstellung ab.

### Kostentraegergruppe.code
| Wert | Bedeutung |
|------|-----------|
| 01 | AOK |
| 02 | SVLFG |
| 03 | IKK |
| 04 | BKK |
| 05 | Knappschaft |
| 11 | VdEk |
| 12 | VdEk |

### HZVDetails.statusteilnahme
| Wert | Bedeutung |
|------|-----------|
| 0 | keine Teilnahme **[ungeprüft]** |
| 1 | beantragt **[ungeprüft]** |
| 2 | aktiv (aktiviert) |
| 3 | beendet **[ungeprüft]** |
| 100 | nur erzeugt (Formulare gedruckt, noch nicht beantragt) **[ungeprüft]** |

„Aktiv am Datum X“ in tomedo: Status 2 mit X zwischen `beginnteilnahme` und `endeteilnahme`, **oder** Status 3 mit gesetztem
`endeteilnahme` und X im Zeitraum — dazu `statusfavdirektaktivierung` nicht 4/5 **[ungeprüft]**.

### HZVDetails.statusteilnahmeerklaerung **[ungeprüft]**
1 erzeugt, 2 gedruckt, 3 fehlgeschlagen, 4 erfolgreich, 5 Direkteinschreibung, 6 bearbeitet, 7 teilweise versendet.

### HZVDetails.statusFAVDirektaktivierung
| Wert | Bedeutung |
|------|-----------|
| 1 | Sofortabrechnung aktiv **[ungeprüft]** |
| 2 | ab Folgequartal **[ungeprüft]** |
| 3 | ausgeschrieben **[ungeprüft]** |
| 4, 5 | Pseudo-Teilnahme (ausfiltern!) — 4 Einschreibung über den Hausarzt, 5 zwischengespeicherte Teilnahmeinfo |

### SVTeilnahme.status
| Wert | Bedeutung |
|------|-----------|
| 0 | keine **[ungeprüft]** |
| 1 | beantragt **[ungeprüft]** |
| 2 | aktiv (eingeschrieben) |
| 3 | beendet **[ungeprüft]** |
| 4 | gelöscht **[ungeprüft]** |
| 5 | abgelehnt **[ungeprüft]** |
| 6 | fremdeingeschrieben **[ungeprüft]** |

„Aktiv am Datum“ = Status 2 **oder 3** und Datum zwischen `teilnahmebeginn` und `teilnahmeende` **[ungeprüft]**.

### HZVVertrag.typ **[ungeprüft]**
1 HZV, 2 FAV (Facharztvertrag), 3 KV-Vertrag, 4 IV Hausarzt, 5 IV Facharzt.

### Formulartyp.musternummer (Heilmittel)
Die Spalte ist **Text** (`musternummer = '13'`) **[ungeprüft]**.
| Wert | Bedeutung |
|------|-----------|
| 13 | Physiotherapie bzw. seit dem einheitlichen Muster alle Heilmittel |
| 14 | Stimm-, Sprech- und Sprachtherapie (berichtigt 10/2026, nicht Podologie) **[ungeprüft]** |
| 18 | Ergotherapie (ältere Formulare) |

### Formulartyp.name
| Wert | Bedeutung |
|------|-----------|
| `'Heilmittelverordnung'` | Standard-Heilmittel |
| `'PrivateHeilmittelverordnung'` | Privat-Heilmittel |
| `'EntlassmanagementHeilmittelverordnung'` | Entlassmanagement |
| `'F2400'` | BG-Heilmittelverordnung Physiotherapie **[ungeprüft]** |
| `'F2402'` | BG-Heilmittelverordnung Ergotherapie **[ungeprüft]** |
| `'HeilmittelverordnungErgo'`, `'HeilmittelverordnungPhysio'`, `'HeilmittelverordnungStimm'` | ältere Einzelmuster **[ungeprüft]** |
| `'Heilmittelverordnung Zahnarzt'` | Zahnarzt (ignorieren) |

### Patient.gesperrt
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | nicht gesperrt |
| 1 | gesperrt |
| 10 | Mitarbeiterkartei **[ungeprüft]** |
| 20 | Autor (Pseudo-Patient) **[ungeprüft]** |
| 100 | zur Löschung markiert **[ungeprüft]** |

### PatientTyp.patienttyp **[ungeprüft]**
Tabelle `patienttyp` (`patient_ident`, `patienttyp`): 0 Patient, 1 Arbeitgeber, 2 Kontaktperson, 3 Angestellter, 4 Autor,
5 Kanzlei-Akte, 6 Gericht, 7 Sonstiger; keine Zeile = Patient.

### Patientendetails.geschlecht
| Wert | Bedeutung |
|------|-----------|
| `'M'` | männlich |
| `'W'` | weiblich |
| `'D'` | divers **[ungeprüft]** |
| `'X'` | unbestimmt **[ungeprüft]** |
| `'U'` | unbekannt |

Österreich zusätzlich `'I'`, `'K'`. tomedo vergleicht nur den ersten Buchstaben ohne Groß-/Kleinschreibung; Altdaten `'0'`/`'1'`
gelten als männlich/weiblich. Bei `nutzer.geschlecht` Kleinbuchstaben **[ungeprüft]**.

### Patientendetails.statuspsychotherapiefall **[ungeprüft]**
Berichtigt 10/2026: Es sind die Listen der Psychotherapie-Verwaltung.
| Wert | Bedeutung |
|------|-----------|
| NULL / 0 | Archiv |
| 1 | Patientenpool (Warteliste) |
| 2 | Liste der aktiven Behandlungen |
| 3 | aktive Privatpatienten (definiert, nach aktuellem Stand nirgends gesetzt) |

Die Werte 5 „beantragt“ und 10 „aktiv“ aus der Hersteller-Doku gelten nach aktuellem Stand nicht. ⚠ tomedo setzt 2 **automatisch**,
sobald an einem KV-Schein des laufenden Quartals eine EBM-Leistung geändert oder ein Anerkennungsbescheid angelegt wird —
unabhängig vom Fachgebiet. Vor jeder Nutzung die Werteverteilung messen.

### Kartendaten.ersatzverfahrentyp
| Wert | Bedeutung |
|------|-----------|
| 0 | kein Ersatzverfahren |
| 1 | KVK |
| 2 | EGK |
| 3 | Überweisungsschein |
| 4 | Sonstiger Behandlungsausweis (Polizei, Bundeswehr, Asyl) |
| 5 | HzV **[ungeprüft]** |
| 6 | EHIC (europäische Krankenversicherungskarte) **[ungeprüft]** |
| 7 | e-card Österreich (Offline-Fall) **[ungeprüft]** |
| 8 | kein direkter Arzt-Patienten-Kontakt (Zahnarzt) **[ungeprüft]** |

### Terminart.typ
| Wert | Bedeutung |
|------|-----------|
| 0 | Termin (Patiententermin) |
| 1 | Ressource (= infotermin=true) |
| 2 | Sperrbereich |
| 3 | Ganztagsart |

`typ = 3` setzt tomedo automatisch bei `laenge = 10000` (ganztägig); `typ = 2` setzt tomedo nie **[ungeprüft]**. `laenge = 0` heißt
variabel.

### Psychotherapie.therapieart **[ungeprüft]**
Berichtigt 10/2026: nur zwei Werte. Gültig ist `COALESCE(therapieartuserdefined, therapieart)`.
| Wert | Bedeutung |
|------|-----------|
| 0 | Einzeltherapie |
| 1 | Gruppentherapie oder Kombinationsbehandlung |

### Psychotherapie.therapieverfahren **[ungeprüft]**
Berichtigt 10/2026 nach der Auswahlliste der Oberfläche. tomedo schreibt nur `therapieverfahrenuserdefined`;
gültig ist `COALESCE(therapieverfahrenuserdefined, therapieverfahren)`. Welche Kodierung der Server in `therapieverfahren`
schreibt, ist offen.
| Wert | Bedeutung |
|------|-----------|
| 0 | Tiefenpsychologisch fundierte Psychotherapie |
| 1 | Verhaltenstherapie |
| 2 | Analytische Psychotherapie |
| 3 | Systemische Therapie |

### PsychotherapieZaehlerTyp.context **[ungeprüft]**
0 Tag, 1 Quartal (≈ Behandlungsfall), 4 Krankheitsfall, 8 zwei Jahre, 99 seit Therapieende; einen Wert 2 gibt es nicht.

### AnerkennungsbescheidPsychotherapie.statustherapieverlaengerung **[ungeprüft]**
0 unbekannt, 1 beantragbar, 2 beantragt, 3 bewilligt, 4 Rezidiv möglich, 5 beantragbar, aber nicht gewollt.

### Hausarzt.typ
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | Arzt / MVZ / Zahnarzt |
| 1 | Apotheke |
| 2 | Pflegeheim **[ungeprüft]** |
| 3 | Sonstige **[ungeprüft]** |

### Zuzahlungsbefreiung.befreiungtyp
| Wert | Bedeutung |
|------|-----------|
| 1 | allgemein |
| 2 | „nur Praxisgebühr“ (veraltet) |
| 3 | Schwangerschaft |
| 11, 12 | Österreich: Rezeptgebühren, Kostenanteil **[ungeprüft]** |

### Karteieintrag.status (kontextabhängig)
Bedeutung variiert je nach dtype. Für EArztbriefe und eNachrichten (1 = versandt **oder empfangen**) **[ungeprüft]**:
| Wert | Bedeutung |
|------|-----------|
| -1 | Sendefehler |
| 0 | Neu |
| 1 | Versandt |
| 2 | Bestätigt |
| 3 | wird versendet |

Bei BG-Formularen (DALE-UV) ist `status` ein Bitfeld: 1 geprüft, 2 versendet, 4 fehlerhaft, 8 Warnung, 16 Duplikat, 32 akzeptiert,
64 konvertiert, 128 ignorieren **[ungeprüft]**.

### Formular.jsonformsource / jsonformrueckschriebstatus **[ungeprüft]**
- `jsonformsource`: 0 unbekannt, 1 online (Link/arzt-direkt), 2 iPad, 3 am Mac in tomedo ausgefüllt
- `jsonformrueckschriebstatus`: −1 nicht zugeordnet, 0 ungeprüft, 1 geprüft

### OTK-Status-Werte (OtkEvent)
> **Ergänzung 10/2026 **[ungeprüft]**:** `otkevent` hat **keine** Text-Statusspalte, nur die Ganzzahlen `eventstatus`, `inboxstatus`,
> `lastprocessedstatusnumber` und den Text `eventtype`. Die folgenden Zeichenketten sind keine Spaltenwerte; wenn es sie gibt,
> stehen sie im JSON `queuepayload`. Die Liste bleibt Herstellerangabe — vor Nutzung im eigenen Bestand nachsehen.

| Status-String | Bedeutung |
|------|-----------|
| `requested_by_client` | Von Kunde angefordert |
| `pending` | Terminanfrage offen |
| `confirmed_by_host` | Automatisch bestätigt |
| `cancel_requested_by_client` | Stornierung angefragt |
| `cancel_confirmed_by_host` | Stornierung bestätigt |
| `cancelled_by_host` | Von Praxis storniert |
| `move_requested_by_client` | Verschiebung angefragt |
| `move_confirmed_by_host` | Verschiebung bestätigt |
| `moved_by_host` | Von Praxis verschoben |
| `failed` | Technischer Fehler |
| `rejected` | Kunde gesperrt |
| `rejected_manual` | Manuell abgelehnt |
| `unavailable` | Nicht mehr verfügbar |

### Sperrzeiten-Terminarten (infotermin=false, patient_ident IS NULL)
| Kürzel | Bezeichnung | Rolle |
|------|-----------|-------|
| `UNBEKANNT` | UNBEKANNT | **Hauptblocker**: Feiertage (720min Ganztag), Urlaub, individuelle Sperren. `info`-Feld enthält Sperrgrund |
| `Blocker` | Blocker | Expliziter Blocker-Typ |
| `IMPORT_GANZTAG` | IMPORT_GANZTAG | Import-bedingte Ganztagsblöcke |
| `Urlaub` | Urlaub | Explizite Urlaubseinträge |
| `Ü-Abbau` | Überstundenabbau | Abwesenheit durch Überstundenabbau |

Erkennung gesperrter Tag: Dauer ≥300 min + obige Terminart + kein Patient.

### terminkalendertag.sperrmodus

| Wert | Bedeutung |
|---|---|
| 0 | Tag nicht gesperrt (Regelfall — Tabelle enthaelt jeden Kalendertag) |
| 1 | Tag gesperrt; Grund in `kalendersperrmodus_ident` |
| 2 | Feiertag; `sperrname` = Name des Feiertags, `kalendersperrmodus_ident` = Feiertags-Modus **[ungeprüft]** |

Nur 0 und 1 beobachtet (689 Zeilen, 07/2026). Bei `sperrmodus = 1` ist `kalendersperrmodus_ident` immer gesetzt. Den Wert 2
schreibt ein älterer Weg der Feiertagspflege; Altbestände können ihn enthalten. Robust:
`sperrmodus > 0 AND removed = false` — `removed = true` sind zusammengeführte Doppel **[ungeprüft]**.

### kalendersperrmodus — Beispielkatalog einer Installation (Stand 07/2026)

> Die kleinen `ident`-Werte waren an der Referenzinstallation die Grundmodi (feste ident-Werte gibt es nicht;
> verwendet wird der erste sichtbare Modus mit bzw. ohne `isfeiertag` **[ungeprüft]**), die grossen sind praxisseitig angelegt —
> **Namen und Anzahl unterscheiden sich je Installation.** Der Katalog zeigt, welche Form
> die Eintraege haben, nicht welche bei Ihnen existieren.

| ident | name | isfeiertag | visible |
|---|---|---|---|
| 1 | Feiertag | **true** | true |
| 2 | Sperrtag | false | true |
| 3 | Arzeko_Urlaub | false | true |
| 4 | Arzeko_Krank | false | true |
| 5 | Arzeko_Kindkrank | false | true |
| 6 | Arzeko_Sonstige_Abwesenheit | false | true |
| 1813059… | Urlaub | false | true |
| 1813107… | Weiterbildung | false | true |
| 1813107… | Elternzeit | false | true |
| 1813114… | Überstundenabbau ganztags | false | true |
| 1813119… | Teamtag | false | true |
| 1836233… | – kein Name – | false | **false** |

`isfeiertag = true` nur bei `Feiertag` — der Rest ist personenbezogene Abwesenheit. Fuer „echte Abwesenheit ohne Organisationstage" filtern auf `name NOT IN ('Feiertag','Teamtag')`.

**Welche Modi tatsaechlich benutzt werden, ist je Installation verschieden** und vor jeder
Auswertung zu messen — typischerweise ist nur ein Teil des Katalogs in Gebrauch, und mehrere
Modi bedeuten dasselbe (eine native und eine aus der Zeitwirtschaft stammende Urlaubsvariante
nebeneinander). Belegung der eigenen Installation:

```sql
SELECT M.name, count(*) AS tage, count(DISTINCT K.nutzer_ident) AS mitarbeiter
FROM terminkalendertag S
JOIN kalendersperrmodus M ON M.ident = S.kalendersperrmodus_ident
JOIN kalender K ON K.ident = S.kalender_ident
WHERE S.tag >= current_date
  AND S.sperrmodus > 0
  AND S.removed = false
GROUP BY M.name ORDER BY tage DESC;
```

Berichtigt 10/2026: Die frühere Fassung las aus einer Tabelle `kalendersperrtag` mit Spalte `datum` — beides gibt es nicht.
Sperrtage stehen in `terminkalendertag` (Spalte `tag`) **[ungeprüft]**.

> ⚠️ **Das Ergebnis ist personenbezogen.** Ein Modus mit vielen Tagen bei **einem** Mitarbeiter
> ist eine Aussage ueber diese Person — bei Krankheits- und Elternzeitmodi eine ueber ihre
> Gesundheit oder Familienlage. Zaehlungen bleiben lokal; nichts davon gehoert in ein Ticket,
> einen Chat oder eine Anleitung. Gehoert der Befund festgehalten, dann in
> `references/praxis-interna.md`.

**Zwei Lehren, die unabhaengig von der Installation gelten:**

- **Krankheit wird nicht im Voraus gepflegt.** Ein Zukunftsfenster zeigt Urlaub und Elternzeit,
  aber praktisch keine Krankheitstage. Wer Ausfallzeiten vollstaendig braucht, muss rueckwaerts
  auswerten.
- **Praxisweite Schliesstage sehen aus wie Abwesenheit jedes Einzelnen.** Ein Modus, der bei
  *allen* Mitarbeitern am selben Tag steht, ist ein Schliesstag. Wer nach *personenbezogener*
  Abwesenheit fragt, muss ihn ausschliessen — wer nach *Erreichbarkeit* fragt, einschliessen.

### Nicht-Patientenzeit-Terminarten (Ressourcen, die NICHT als Therapie-Kapazität zählen)
| Kürzel | Rolle |
|------|-------|
| `Doku` | Dokumentationszeit (Befundung, Telefonate, Anträge) |
| `Pau`, `Pause` | Pausenzeiten |
| `Urlaub` | Urlaub |
| `Org` | Organisation |
| `Test` | Testeinträge |
| Praefix fuer Besprechungen | Teambesprechungen |

> **Die Kuerzel sind Beispiele einer Installation, keine tomedo-Vorgabe.** Jede Praxis benennt
> ihre Terminarten selbst; eigene Liste vor dem Bau ermitteln:
> `SELECT kuerzel, bezeichnung, infotermin, count(*) FROM terminart … GROUP BY 1,2,3;`
> Praxiseigene Abkuerzungen gehoeren in `references/praxis-interna.md`, nicht hierher.

**Achtung bei Sammelterminarten.** In vielen Katalogen gibt es eine Terminart, die sowohl
Patiententermine als auch Teambesprechungen traegt — erkennbar daran, dass ein Teil der Zeilen
`patient_ident` fuehrt und ein anderer gar keines. Solche Kuerzel sind ein brauchbares
**Kapazitaetssignal**, aber **kein** patientenbezogener Verlaufsmarker: Die belegten Zeilen
verteilen sich meist auf sehr wenige Koepfe (Serientermine). Vor der Verwendung pruefen:

```sql
SELECT count(*) AS zeilen,
       count(patient_ident) AS mit_patient,
       count(DISTINCT patient_ident) AS koepfe
FROM termin WHERE terminart_kuerzel = '<KUERZEL>';
```

### Kalender-Typen
| Bedingung | Typ | Beispiele |
|------|------|------|
| `kalender.nutzer_ident IS NOT NULL` | Therapeuten-Kalender | Kalender je Behandler |
| `kalender.nutzer_ident IS NULL` | Raum-/Gruppenkalender | Raum-, Geräte-, Gruppenkalender |

### nutzer.nutzertyp **[ungeprüft]**
| Wert | Bedeutung |
|------|-----------|
| 0 | Arzt (Vorgabe) |
| 1 | Praktischer Arzt |
| 2 | Andere |
| 3 | Psychologe in Weiterbildung |
| 4 | Psychologe |
| 5 | Physiotherapeut |
| 6 | Chiropraktiker |

Auswahl in der Nutzerverwaltung; fachlich ausgewertet nur in der Schweizer Abrechnung. An der Referenzinstallation nur `0`
beobachtet — das ist die Vorgabe, also „nie gepflegt“. Als Disziplinsignal nur, wenn die Praxis es pflegt.

### nutzer.qualification_type **[ungeprüft]**
Text, Code der KBV-Berufsgruppe: "00" Arzt, "01" Zahnarzt, "02" Hebamme, "03" Arzt in Weiterbildung (oder
Sicherstellungsassistent ohne LANR), "04" Arzt als Vertreter (oder Sicherstellungsassistent mit LANR), leer = keine Angabe.
Je Betriebsstätte übersteuerbar. An der Referenzinstallation nur bei einem Nutzer befüllt ("03").

### termin.warda (No-Show-Signal)
Boolean NOT NULL. `true` = Patient war da. Gesetzt, wenn aus dem Termin ein Besuch angelegt wird, beim Kiosk-Check-in oder von
Hand („war da“) **[ungeprüft]**. Zuverlässigkeit variiert nach Disziplin:
- Ärzteschaft: ~95 % (93–97 %) → belastbar
- Psychotherapie: streut stark je Behandler, ~50 bis ~92 %
- Physiotherapie: ~21–42 %, einzelne Ausreißer bis 80 % → unzuverlässig

Die Streuung verläuft **nach Disziplin und Dokumentationsworkflow**, nicht nach Person; die Zahlen stammen von einer Installation und sind lokal nachzumessen.
- Gruppentermine: ~15 % → separater Ansatz nötig

Nur bei hoher Pflegequote direkt als No-Show-Indikator nutzbar (Stufe 1; Referenzinstallation: ≥85 %). Ein KE-basiertes Ersatzsignal über `karteieintrag.termin_ident` gibt es **nicht** — die Spalte gehört nur zu OP-Einträgen **[ungeprüft]**. Zweites Signal: `patientverstoss` (siehe `datenmodell.md` §7). Die Quote je Behandler ist vorab zu messen, nicht zu schätzen.

---

### Aufgabe.availability (oeffentlich-Flag) **[ungeprüft]**
Berichtigt 10/2026 — die frühere Zuordnung war vertauscht.
| Wert | Bedeutung |
|------|-----------|
| 0 | privat |
| 1 | öffentlich |
| NULL | wie 0; an der Referenzinstallation bei System-Vorlagen (z.B. „Aufgabe aus Nachricht") |

Aufgaben, die aus Karteieinträgen entstehen, legt tomedo öffentlich an.

### Aufgabe.status / Aufgabenempfaenger.status
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | Offen **[ungeprüft]** |
| 1 | Fertig (erledigt) |
| 2 | In Bearbeitung **[ungeprüft]** |

Validiert 2026-06-19: Abhaken einer Aufgabe setzt status NULL->1 (+ `laststatuschange`). Neue Empfänger bekommen 0;
`aufgabenempfaenger.laststatuschange` ist bei Status 1 das Erledigt-Datum des Empfängers.

### Aufgabe.erdedigungstyp
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | von einem |
| 1 | von allen (Erledigt-Zustand pro Empfaenger in aufgabenempfaenger.status) |

### customstatistikelement.elementtyp (Bausteine der Statistik „Patientbezogen“) **[ungeprüft]**

Vollständige Liste, Stand 10/2026 (Werte unveränderlich). Die früheren Lesarten „0 = Platzhalter“,
„5/7 ungeklärt“ sind damit ersetzt.

| Wert | Kriteriumsart | Beleg im `suchfreitext` (Referenzinstallation) |
|------|---------------|-------------------------|
| 0 | Hauptbehandler (Vorgabe jedes neuen Elements, daher oft leer) | leer, Bezugsraum `0/0..0/0` |
| 1 | EBM-Ziffer | `<ZS:suchText1>30704</ZS>`, `30731,30760` |
| 2 | GOÄ-Ziffer | |
| 3 | ICD-Code | `M53.86 M17.9` |
| 4 | Karteieintrag | |
| 5 | Besuch | Filter leer |
| 6 | Stammdaten | `<ZS:stammdatenTyp>14</ZS><ZS:suchText1>m</ZS>` (Geschlecht) |
| 7 | Schein/Rechnung | Filter leer |
| 8 | Termin | |
| 9 | Medikament | `<ZS:medikTyp>2</ZS><ZS:suchText1>…</ZS>` |
| 10 | HZV-/SV-Ziffer | |
| 11 | Patientenliste | |
| 12 | HZV-Teilnahme | |
| 13 | DVP-Ziffer (AT) | |
| 14 | Diagnose (AT) | |
| 15 | Hybrid-DRG | |
| 16 | SV-Teilnahme | |

**Vergleichsmodus `<ZS:sqlTyp1>`** **[ungeprüft]**: 0 enthält, 1 enthält nicht, 2 beginnt mit, 3 endet mit, 4 enthält eines, 5 enthält alle,
6 enthält keines, 7 ist, 8 gleich (ja/nein), 9 gleich (Zahl), 10 gleich (Text), 11 vor, 12 nach, 13 größer, 14 größer gleich,
15 kleiner, 16 kleiner gleich.

**Weitere Schlüssel** **[ungeprüft]**: `stammdatenTyp` 0 Patienteninfo, 1 Privatpatient, 2 Geburtstag, 3 Straße, 4 Ort, 5 PLZ, 6 Beruf,
7/8 Freitext 1/2, 9/10 Ja/Nein 1/2, 11 verstorben, 12 Marker, 13 Alter in Jahren, 14 Geschlecht, 15 Krankenkasse,
16–18 Alter in Monaten/Wochen/Tagen · `medikTyp` 0 ATC, 1 PZN, 2 Name · `scheinTyp` 0 KV-Schein, 1 Privatrechnung,
2 HZV-Schein, 3/4 KV-/HZV-Schein Quartal, 5 DVP.

**Bezugsraum** (`vonbezugsraumtyp`, `bisbezugsraumtyp`) **[ungeprüft]**: −1 aus, 0 Jahresanfang, 1 Quartalsanfang, 2 Monatsanfang,
3 Wochenanfang, 4 Tagesanfang, 5 Tagesende, 6 Wochenende, 7 Monatsende, 8 Quartalsende, 9 Jahresende (bezogen auf heute);
`…anzahltyp` 0 Jahr, 1 Quartal, 2 Monat, 3 Woche, 4 Tag; `…anzahl` = Versatz (negativ = zurück). `von2…`/`bis2…` filtern
nur bei HZV- und SV-Teilnahme das Teilnahmeende.

Das eingebaute Kriterium „verstorben“ prüft nur das † im Nachnamen, nicht das Sterbedatum **[ungeprüft]**.


## Bitfeld: Kontaktdaten.dsinfo

```sql
(D.dsinfo IS NOT NULL AND (D.dsinfo & 1) != 0)     -- will keine Anrufe
(D.dsinfo IS NOT NULL AND (D.dsinfo & 2) != 0)     -- will keine SMS (zusätzlich kontaktdaten.willkeinesms) [ungeprüft]
(D.dsinfo IS NOT NULL AND (D.dsinfo & 4) != 0)     -- will kein Fax
(D.dsinfo IS NOT NULL AND (D.dsinfo & 8) != 0)     -- will keine Emails
(D.dsinfo IS NOT NULL AND (D.dsinfo & 256) != 0)   -- will keine Newsletter
(D.dsinfo IS NOT NULL AND (D.dsinfo & 512) != 0)   -- verbietet Versand Termindetails
(D.dsinfo IS NOT NULL AND (D.dsinfo & 1024) != 0)  -- verbietet Versand med. Doku
(D.dsinfo IS NOT NULL AND (D.dsinfo & 2048) != 0)  -- verbietet Versand Rechnungen
(D.dsinfo IS NOT NULL AND (D.dsinfo & 8192) != 0)  -- keine arbeitsmed. Bescheinigung an Probanden [ungeprüft]
(D.dsinfo IS NOT NULL AND (D.dsinfo & 16384) != 0) -- keine arbeitsmed. Bescheinigung an Arbeitgeber [ungeprüft]
(D.dsinfo IS NOT NULL AND (D.dsinfo & 32768) != 0) -- will keinen Recall
```

Gesetztes Bit = Verbot. `termin.dsinfo` nutzt dasselbe Bitfeld (Kopie vom Patienten bzw. Praxisvorgabe) **[ungeprüft]**.

---

## tomedo-eigene SQL-Funktionen

| Funktion | Beschreibung |
|----------|-------------|
| `zs_try_read_json(text)` | Parst JSON-String, gibt JSON-Objekt zurück |
| `zs_try_extract_json_array(json)` | Extrahiert JSON-Array für `unnest()` |
| `zs_bigIntString_or_dateString_to_timestamp(text)` | Konvertiert BigInt- oder Datumsstring zu Timestamp |
| `zs_read_bigint_string_negative_one_on_failure(text)` | Liest BigInt, -1 bei Fehler |
| `zs_calendar_read_us_or_de_date(text)` | Liest US- oder DE-Datumsformat |

Diese Funktionen liegen auf dem Server. Existenz und Verhalten nur am Server prüfbar
**[ungeprüft]**.

---

## Array-Operatoren für Tags

```sql
-- Prüfen ob EINER von mehreren Markern vorhanden (OR):
ARRAY[marker_id_1, marker_id_2] && T.tags_idents

-- Prüfen ob ALLE Marker vorhanden (AND):
T.tags_idents @> ARRAY[marker_id_1, marker_id_2]

-- Einzelner Marker (für ZS:TAG):
marker_id = ANY(T.tags_idents)
```

`tags_idents` ist keine Spalte, sondern ein selbst gebildetes `array_agg(tag.ident)` über `patientendetails_tags` (Muster in
`zs-filter.md`).

---

## Nützliche SQL-Techniken

### Fensterfunktionen (Alternative zu PL/pgSQL-Cursor)
```sql
ROW_NUMBER() OVER (PARTITION BY patient_ident ORDER BY datum DESC) AS rn
```
Dann `WHERE rn = 1` für den jeweils neuesten Eintrag pro Patient.

### bool_or() für Boolean-Aggregation
```sql
bool_or(A.wiederholungsuntersuchung5020) AS wiederholungsuntersuchung
```
Statt `max()` für Booleans.

### Verstorbenen-Erkennung
```sql
RIGHT(TRIM(P.nachname), 1) <> '†'          -- ohne Prozentzeichen (SKILL.md Regel 1)
AND PD.sterbedatum IS NULL
```
tomedo markiert Verstorbene mit „ †“ am Nachnamensende. tomedo selbst wertet als verstorben: † **oder** gesetztes
Sterbedatum; beim Markieren als verstorben trägt es kein Sterbedatum ein **[ungeprüft]**. Das † ist also das zuverlässigere
Merkmal, für einen vollständigen Ausschluss beide Bedingungen nehmen.

### ROUND() mit Dezimalstellen
```sql
ROUND(wert::numeric, 2)
```
PostgreSQL kennt kein `ROUND(double precision, integer)`. Immer erst `::numeric` casten.

### TRIM() bei Terminart-Kürzeln
```sql
TRIM(TA.kuerzel) NOT IN ('Doku', 'Pau', 'Pause')
```
Terminart-Kürzel haben teils trailing Spaces → bei Vergleichen immer `TRIM()` verwenden.

### Gesperrte Patienten ausschließen
```sql
AND (P.gesperrt IS NULL OR P.gesperrt = 0)
```
Schließt gesperrte (1), Mitarbeiter- (10), Autoren- (20) und zur Löschung markierte Akten (100) aus **[ungeprüft]** — für
Patientenpopulationen meist richtig. Wer gesperrte echte Patienten zählen will, braucht `gesperrt = 1`. Für echte Patienten
zusätzlich `patienttyp` prüfen.

> **Ergebnisfenster filtert selbst** **[ungeprüft]**: Enthält das Ergebnis eine Spalte `patientid`, entfernt tomedo im Ergebnisfenster
> still die Zeilen von Patienten, auf die der angemeldete Nutzer keinen Zugriff hat (Patientenzugriffsrechte). Zeilenzahlen
> können deshalb unter denen der Datenbank (Metabase) liegen; Aggregate ohne `patientid` sind nicht betroffen.


## ⛔ Verbotene Abfragen in tomedo HQL

Die folgenden PostgreSQL-System-Katalog-Tabellen dürfen in tomedo HQL **NICHT** abgefragt werden. Sie verursachen einen **sofortigen Crash** der tomedo-Anwendung mit Datenbankfehler und erfordern ein Neuladen der lokalen Datenbank (Messbefund):

- `pg_tables`
- `pg_catalog.*`
- `information_schema.*` (inkl. `information_schema.columns`)
- `pg_stat_*`
- `pg_class`, `pg_attribute`, `pg_namespace`

**Alternative:** Tabellenstruktur über den Zollsoft-Datenmodell-Dump nachschlagen oder explorative `SELECT *`-Queries mit `LIMIT 1` gegen bekannte Tabellen verwenden.

**Einordnung 10/2026 **[ungeprüft]**:** Wahrscheinlicher Mechanismus: Katalogspalten
haben Datentypen, die das Ergebnisfenster nicht kennt (`name`, `oid`, `char`, Arrays). Das Verbot bleibt bis zur Klärung
bestehen; Katalogfragen in der Metabase-Replika stellen.
