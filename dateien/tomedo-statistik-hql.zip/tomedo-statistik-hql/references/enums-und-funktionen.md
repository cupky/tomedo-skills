# Enums (v10), Bitfelder & tomedo-Funktionen

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- v8 (2026-04-27): keine inhaltlichen Änderungen, nur Versionsstempel-Sync

> Stand: 16.04.2026 · Neu ggü. v6: `nutzer.nutzertyp`, `nutzer.qualification_type` (beide an der Referenzinstallation weitgehend leer).

## Enum-Werte

### Leistung.dtype (Diskriminator)
| Wert | Bedeutung |
|------|-----------|
| `'EBMLeistung'` | EBM-Kassenleistung |
| `'GOAELeistung'` | GOÄ-Privatleistung |
| `'HZVLeistung'` | HZV-Selektivvertragsleistung |

### Karteieintrag.dtype
| Wert | Bedeutung |
|------|-----------|
| `'Formular'` | Formular-Karteieintrag |
| (andere Werte) | Standard-Karteieinträge |

### Karteieintrag.abrechnungstyp
| Wert | Bedeutung |
|------|-----------|
| 1 | KV |
| 4 | HZV |

### Diagnose.typ (Diagnosesicherheit)
| Wert | Bedeutung |
|------|-----------|
| A | Ausschluss |
| G | Gesichert |
| V | Verdacht |
| Z | Zustand nach |

### Diagnose.lokalisation
| Wert | Bedeutung |
|------|-----------|
| R | Rechts |
| L | Links |
| B | Beidseitig |

### Medikamentenverordnung.rezepttyp
| Wert | Bedeutung |
|------|-----------|
| 0 | nicht definiert |
| 1 | rot (Kassenrezept) |
| 2 | grün (Privatrezept) |
| 3 | blau (Privatrezept) |
| 4 | BTM |
| 5 | Sprechstundenbedarf (16a) |
| 6 | BTM |

### Medikamentenverordnung.absetzungsgrund
| Wert | Bedeutung |
|------|-----------|
| 0 | inaktiv |
| 1 | Unverträglichkeit |

### Privatrechnung.status
| Wert | Bedeutung |
|------|-----------|
| 0 | offen |
| 1 | in Korrektur |
| 2 | in Prüfung |
| 3 | geprüft |

### Privatrechnung.nichtambulant
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | ambulant |
| 1 | belegärztlich |
| 2 | stationär |

### KVSchein.vermittlungsart4103
| Wert | Bedeutung |
|------|-----------|
| 0 | (leer) |
| 1 | TSS-Terminfall |
| 2 | TSS-Akutfall |
| 3 | HA-Vermittlungsfall |
| 4 | Offene Sprechstunde |
| 5 | Neupatient |
| 6 | Routinefall |

### GOAEKatalogEintrag.typ
| Wert | Bedeutung |
|------|-----------|
| 5 | Besondere Kosten |

### Kostentraegergruppe.code
| Wert | Bedeutung |
|------|-----------|
| 01 | AOK |
| 02 | SVLFG |
| 03 | IKK |
| 04 | BKK |
| 05 | Knappschaft |
| 11 | VdEk |
| 12 | VdEk |

### HZVDetails.statusteilnahme
| Wert | Bedeutung |
|------|-----------|
| 2 | aktiv |

### HZVDetails.statusFAVDirektaktivierung
| Wert | Bedeutung |
|------|-----------|
| 4, 5 | Pseudo-Teilnahme (ausfiltern!) |

### SVTeilnahme.status
| Wert | Bedeutung |
|------|-----------|
| 2 | aktiv |

### Formulartyp.musternummer (Heilmittel)
| Wert | Bedeutung |
|------|-----------|
| 13 | Physiotherapie |
| 14 | Podologie |
| 18 | Ergotherapie |

### Formulartyp.name
| Wert | Bedeutung |
|------|-----------|
| `'Heilmittelverordnung'` | Standard-Heilmittel |
| `'PrivateHeilmittelverordnung'` | Privat-Heilmittel |
| `'EntlassmanagementHeilmittelverordnung'` | Entlassmanagement |
| `'F2400'` | Formular 2400 |
| `'F2402'` | Formular 2402 |
| `'Heilmittelverordnung Zahnarzt'` | Zahnarzt (ignorieren) |

### Patient.gesperrt
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | nicht gesperrt |
| 1 | gesperrt |

### Patientendetails.geschlecht
| Wert | Bedeutung |
|------|-----------|
| `'M'` | männlich |
| `'W'` | weiblich |
| `'U'` | unbekannt |

### Patientendetails.statuspsychotherapiefall
| Wert | Bedeutung |
|------|-----------|
| NULL / 0 | abgeschlossen |
| 1 | Warteliste |
| 5 | beantragt |
| 10 | aktiv |

### Kartendaten.ersatzverfahrentyp
| Wert | Bedeutung |
|------|-----------|
| 0 | kein Ersatzverfahren |
| 1 | KVK |
| 2 | EGK |
| 3 | Überweisungsschein |
| 4 | Sonstiger Behandlungsausweis (Polizei, Bundeswehr, Asyl) |

### Terminart.typ
| Wert | Bedeutung |
|------|-----------|
| 0 | Termin (Patiententermin) |
| 1 | Ressource (= infotermin=true) |
| 2 | Sperrbereich |
| 3 | Ganztagsart |

### Psychotherapie.therapieart
| Wert | Bedeutung |
|------|-----------|
| 0 | Einzeltherapie |
| 1 | Gruppentherapie |
| 2 | Kombinationsbehandlung überwiegend Einzel |
| 3 | Kombinationsbehandlung überwiegend Gruppe |

### Psychotherapie.therapieverfahren
| Wert | Bedeutung |
|------|-----------|
| 0 | Analytische Psychotherapie |
| 1 | Tiefenpsychologisch fundierte Psychotherapie |
| 2 | Verhaltenstherapie |
| 3 | Systemische Therapie |

### Hausarzt.typ
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | Arzt |
| 1 | Apotheke |

### Zuzahlungsbefreiung.befreiungtyp
| Wert | Bedeutung |
|------|-----------|
| 1 | allgemein |
| 2 | teilweise (deprecated) |
| 3 | Schwangerschaft |

### Karteieintrag.status (kontextabhängig)
Bedeutung variiert je nach dtype. Für EArztbriefe:
| Wert | Bedeutung |
|------|-----------|
| -1 | Sendefehler |
| 0 | Neu |
| 1 | Versandt |
| 2 | Bestätigt |
| 3 | wird versendet |

### OTK-Status-Werte (OtkEvent)
| Status-String | Bedeutung |
|------|-----------|
| `requested_by_client` | Von Kunde angefordert |
| `pending` | Terminanfrage offen |
| `confirmed_by_host` | Automatisch bestätigt |
| `cancel_requested_by_client` | Stornierung angefragt |
| `cancel_confirmed_by_host` | Stornierung bestätigt |
| `cancelled_by_host` | Von Praxis storniert |
| `move_requested_by_client` | Verschiebung angefragt |
| `move_confirmed_by_host` | Verschiebung bestätigt |
| `moved_by_host` | Von Praxis verschoben |
| `failed` | Technischer Fehler |
| `rejected` | Kunde gesperrt |
| `rejected_manual` | Manuell abgelehnt |
| `unavailable` | Nicht mehr verfügbar |

### Sperrzeiten-Terminarten (infotermin=false, patient_ident IS NULL)
| Kürzel | Bezeichnung | Rolle |
|------|-----------|-------|
| `UNBEKANNT` | UNBEKANNT | **Hauptblocker**: Feiertage (720min Ganztag), Urlaub, individuelle Sperren. `info`-Feld enthält Sperrgrund |
| `Blocker` | Blocker | Expliziter Blocker-Typ |
| `IMPORT_GANZTAG` | IMPORT_GANZTAG | Import-bedingte Ganztagsblöcke |
| `Urlaub` | Urlaub | Explizite Urlaubseinträge |
| `Ü-Abbau` | Überstundenabbau | Abwesenheit durch Überstundenabbau |

Erkennung gesperrter Tag: Dauer ≥300 min + obige Terminart + kein Patient.

### terminkalendertag.sperrmodus

| Wert | Bedeutung |
|---|---|
| 0 | Tag nicht gesperrt (Regelfall — Tabelle enthaelt jeden Kalendertag) |
| 1 | Tag gesperrt; Grund in `kalendersperrmodus_ident` |

Nur diese zwei Werte beobachtet (689 Zeilen, 07/2026). Bei `sperrmodus = 1` ist `kalendersperrmodus_ident` immer gesetzt — die beiden Filter sind aequivalent.

### kalendersperrmodus — Beispielkatalog einer Installation (Stand 07/2026)

> Die kleinen `ident`-Werte sind ueberall gleich, die grossen sind praxisseitig angelegt —
> **Namen und Anzahl unterscheiden sich je Installation.** Der Katalog zeigt, welche Form
> die Eintraege haben, nicht welche bei Ihnen existieren.

| ident | name | isfeiertag | visible |
|---|---|---|---|
| 1 | Feiertag | **true** | true |
| 2 | Sperrtag | false | true |
| 3 | Arzeko_Urlaub | false | true |
| 4 | Arzeko_Krank | false | true |
| 5 | Arzeko_Kindkrank | false | true |
| 6 | Arzeko_Sonstige_Abwesenheit | false | true |
| 1813059… | Urlaub | false | true |
| 1813107… | Weiterbildung | false | true |
| 1813107… | Elternzeit | false | true |
| 1813114… | Überstundenabbau ganztags | false | true |
| 1813119… | Teamtag | false | true |
| 1836233… | – kein Name – | false | **false** |

`isfeiertag = true` nur bei `Feiertag` — der Rest ist personenbezogene Abwesenheit. Fuer „echte Abwesenheit ohne Organisationstage" filtern auf `name NOT IN ('Feiertag','Teamtag')`.

**Welche Modi tatsaechlich benutzt werden, ist je Installation verschieden** und vor jeder
Auswertung zu messen — typischerweise ist nur ein Teil des Katalogs in Gebrauch, und mehrere
Modi bedeuten dasselbe (eine native und eine aus der Zeitwirtschaft stammende Urlaubsvariante
nebeneinander). Belegung der eigenen Installation:

```sql
SELECT M.name, count(*) AS tage, count(DISTINCT K.nutzer_ident) AS mitarbeiter
FROM kalendersperrtag S
JOIN kalendersperrmodus M ON M.ident = S.kalendersperrmodus_ident
JOIN kalender K ON K.ident = S.kalender_ident
WHERE S.datum >= current_date
GROUP BY M.name ORDER BY tage DESC;
```

> ⚠️ **Das Ergebnis ist personenbezogen.** Ein Modus mit vielen Tagen bei **einem** Mitarbeiter
> ist eine Aussage ueber diese Person — bei Krankheits- und Elternzeitmodi eine ueber ihre
> Gesundheit oder Familienlage. Zaehlungen bleiben lokal; nichts davon gehoert in ein Ticket,
> einen Chat oder eine Anleitung. Gehoert der Befund festgehalten, dann in
> `references/praxis-interna.md`.

**Zwei Lehren, die unabhaengig von der Installation gelten:**

- **Krankheit wird nicht im Voraus gepflegt.** Ein Zukunftsfenster zeigt Urlaub und Elternzeit,
  aber praktisch keine Krankheitstage. Wer Ausfallzeiten vollstaendig braucht, muss rueckwaerts
  auswerten.
- **Praxisweite Schliesstage sehen aus wie Abwesenheit jedes Einzelnen.** Ein Modus, der bei
  *allen* Mitarbeitern am selben Tag steht, ist ein Schliesstag. Wer nach *personenbezogener*
  Abwesenheit fragt, muss ihn ausschliessen — wer nach *Erreichbarkeit* fragt, einschliessen.

### Nicht-Patientenzeit-Terminarten (Ressourcen, die NICHT als Therapie-Kapazität zählen)
| Kürzel | Rolle |
|------|-------|
| `Doku` | Dokumentationszeit (Befundung, Telefonate, Anträge) |
| `Pau`, `Pause` | Pausenzeiten |
| `Urlaub` | Urlaub |
| `Org` | Organisation |
| `Test` | Testeinträge |
| Praefix fuer Besprechungen | Teambesprechungen |

> **Die Kuerzel sind Beispiele einer Installation, keine tomedo-Vorgabe.** Jede Praxis benennt
> ihre Terminarten selbst; eigene Liste vor dem Bau ermitteln:
> `SELECT kuerzel, bezeichnung, infotermin, count(*) FROM terminart … GROUP BY 1,2,3;`
> Praxiseigene Abkuerzungen gehoeren in `references/praxis-interna.md`, nicht hierher.

**Achtung bei Sammelterminarten.** In vielen Katalogen gibt es eine Terminart, die sowohl
Patiententermine als auch Teambesprechungen traegt — erkennbar daran, dass ein Teil der Zeilen
`patient_ident` fuehrt und ein anderer gar keines. Solche Kuerzel sind ein brauchbares
**Kapazitaetssignal**, aber **kein** patientenbezogener Verlaufsmarker: Die belegten Zeilen
verteilen sich meist auf sehr wenige Koepfe (Serientermine). Vor der Verwendung pruefen:

```sql
SELECT count(*) AS zeilen,
       count(patient_ident) AS mit_patient,
       count(DISTINCT patient_ident) AS koepfe
FROM termin WHERE terminart_kuerzel = '<KUERZEL>';
```

### Kalender-Typen
| Bedingung | Typ | Beispiele |
|------|------|------|
| `kalender.nutzer_ident IS NOT NULL` | Therapeuten-Kalender | Anja Baier, Tobias Walter |
| `kalender.nutzer_ident IS NULL` | Raum-/Gruppenkalender | Fabrik, Studio, Diagnostik, Basisgruppen |

### nutzer.nutzertyp
Bisher nur Wert `0` beobachtet (alle Therapeuten an der Referenzinstallation). Enum-Mapping unbekannt — Feld praktisch nicht zur Unterscheidung nutzbar.

### nutzer.qualification_type
Text-Feld. An der Referenzinstallation nur bei einem einzigen Nutzer befüllt (Wert: "03"). Bedeutung unbekannt. Nicht als Qualifikations-Marker verwenden.

### termin.warda (No-Show-Signal)
Boolean NOT NULL. `true` = Patient war da (gesetzt via Todo-Workflow / MFA-Besuch). Zuverlässigkeit variiert nach Disziplin:
- Ärzteschaft: ~95 % (93–97 %) → belastbar
- Psychotherapie: streut stark je Behandler, ~50 bis ~92 %
- Physiotherapie: ~21–42 %, einzelne Ausreißer bis 80 % → unzuverlässig

Die Streuung verläuft **nach Disziplin und Dokumentationsworkflow**, nicht nach Person; die Zahlen stammen von einer Installation und sind lokal nachzumessen.
- Gruppentermine: ~15 % → separater Ansatz nötig

Nur bei hoher Pflegequote direkt als No-Show-Indikator nutzbar (Stufe 1; Referenzinstallation: ≥85 %). Darunter KE-basiertes Ersatzsignal über `karteieintrag.termin_ident` (Stufe 2). Die Quote je Behandler ist vorab zu messen, nicht zu schätzen.

---

### Aufgabe.availability (oeffentlich-Flag)
| Wert | Bedeutung |
|------|-----------|
| 0 | oeffentlich (Checkbox „oeffentlich" im Aufgaben-Dialog) |
| 1 | persoenlich |
| NULL | System-Vorlage (z.B. „Aufgabe aus Nachricht") |

### Aufgabe.status / Aufgabenempfaenger.status
| Wert | Bedeutung |
|------|-----------|
| NULL | offen |
| 1 | erledigt (Fertig) |
| 0 / 2 | selten, Sonderzustaende (unbestaetigt) |

Validiert 2026-06-19: Abhaken einer Aufgabe setzt status NULL->1 (+ `laststatuschange`).

### Aufgabe.erdedigungstyp
| Wert | Bedeutung |
|------|-----------|
| 0 / NULL | von einem |
| 1 | von allen (Erledigt-Zustand pro Empfaenger in aufgabenempfaenger.status) |

### customstatistikelement.elementtyp (Statistik-Kriterien, plausibel)

Aus dem Realbestand der Referenzinstallation 08/2026 rueckgeschlossen (14 kombinierte Statistiken).
**Status: plausibel, nicht gegen die Oberflaeche verifiziert.**

| Wert | Kriteriumsart | Beleg im `suchfreitext` |
|------|---------------|-------------------------|
| 0 | unbenutzter Platzhalter | leer, Bezugsraum `0/0..0/0` |
| 1 | EBM-Ziffer | `<ZS:suchText1>30704</ZS>`, `30731,30760` |
| 3 | ICD-Diagnose | `M53.86 M17.9` |
| 5 | ungeklaert | Filter leer |
| 6 | Stammdaten | `<ZS:stammdatenTyp>14</ZS><ZS:suchText1>m</ZS>` (Geschlecht) |
| 7 | ungeklaert, tritt nur begleitend auf | Filter leer |
| 9 | Medikament | `<ZS:medikTyp>2</ZS><ZS:suchText1>Qutenza</ZS>` |

`<ZS:sqlTyp1>` im selben Feld steuert den Vergleichsmodus (beobachtet: 0, 1, 4, 5, 6, 7);
die Zuordnung zu Operatoren ist offen.


## Bitfeld: Kontaktdaten.dsinfo

```sql
(D.dsinfo IS NOT NULL AND (D.dsinfo & 1) != 0)     -- will keine Anrufe
(D.dsinfo IS NOT NULL AND (D.dsinfo & 4) != 0)     -- will kein Fax
(D.dsinfo IS NOT NULL AND (D.dsinfo & 8) != 0)     -- will keine Emails
(D.dsinfo IS NOT NULL AND (D.dsinfo & 256) != 0)   -- will keine Newsletter
(D.dsinfo IS NOT NULL AND (D.dsinfo & 512) != 0)   -- verbietet Versand Termindetails
(D.dsinfo IS NOT NULL AND (D.dsinfo & 1024) != 0)  -- verbietet Versand med. Doku
(D.dsinfo IS NOT NULL AND (D.dsinfo & 2048) != 0)  -- verbietet Versand Rechnungen
(D.dsinfo IS NOT NULL AND (D.dsinfo & 32768) != 0) -- will keinen Recall
```

---

## tomedo-eigene SQL-Funktionen

| Funktion | Beschreibung |
|----------|-------------|
| `zs_try_read_json(text)` | Parst JSON-String, gibt JSON-Objekt zurück |
| `zs_try_extract_json_array(json)` | Extrahiert JSON-Array für `unnest()` |
| `zs_bigIntString_or_dateString_to_timestamp(text)` | Konvertiert BigInt- oder Datumsstring zu Timestamp |
| `zs_read_bigint_string_negative_one_on_failure(text)` | Liest BigInt, -1 bei Fehler |
| `zs_calendar_read_us_or_de_date(text)` | Liest US- oder DE-Datumsformat |

---

## Array-Operatoren für Tags

```sql
-- Prüfen ob EINER von mehreren Markern vorhanden (OR):
ARRAY[marker_id_1, marker_id_2] && T.tags_idents

-- Prüfen ob ALLE Marker vorhanden (AND):
T.tags_idents @> ARRAY[marker_id_1, marker_id_2]

-- Einzelner Marker (für ZS:TAG):
marker_id = ANY(T.tags_idents)
```

---

## Nützliche SQL-Techniken

### Fensterfunktionen (Alternative zu PL/pgSQL-Cursor)
```sql
ROW_NUMBER() OVER (PARTITION BY patient_ident ORDER BY datum DESC) AS rn
```
Dann `WHERE rn = 1` für den jeweils neuesten Eintrag pro Patient.

### bool_or() für Boolean-Aggregation
```sql
bool_or(A.wiederholungsuntersuchung5020) AS wiederholungsuntersuchung
```
Statt `max()` für Booleans.

### Verstorbenen-Erkennung
```sql
P.nachname NOT ILIKE '%†'
```
tomedo markiert Verstorbene mit † am Nachnamensende.

**Alternative:** `patientendetails.sterbedatum IS NOT NULL` (zuverlässiger, wenn gepflegt).

### ROUND() mit Dezimalstellen
```sql
ROUND(wert::numeric, 2)
```
PostgreSQL kennt kein `ROUND(double precision, integer)`. Immer erst `::numeric` casten.

### TRIM() bei Terminart-Kürzeln
```sql
TRIM(TA.kuerzel) NOT IN ('Doku', 'Pau', 'Pause')
```
Terminart-Kürzel haben teils trailing Spaces → bei Vergleichen immer `TRIM()` verwenden.

### Gesperrte Patienten ausschließen
```sql
AND (P.gesperrt IS NULL OR P.gesperrt = 0)
```
Gesperrte Patienten (`gesperrt = 1`) sollten bei Populations-Analysen ggf. gefiltert werden.


## ⛔ Verbotene Abfragen in tomedo HQL

Die folgenden PostgreSQL-System-Katalog-Tabellen dürfen in tomedo HQL **NICHT** abgefragt werden. Sie verursachen einen **sofortigen Crash** der tomedo-Anwendung mit Datenbankfehler und erfordern ein Neuladen der lokalen Datenbank:

- `pg_tables`
- `pg_catalog.*`
- `information_schema.*` (inkl. `information_schema.columns`)
- `pg_stat_*`
- `pg_class`, `pg_attribute`, `pg_namespace`

**Alternative:** Tabellenstruktur über den Zollsoft-Datenmodell-Dump nachschlagen oder explorative `SELECT *`-Queries mit `LIMIT 1` gegen bekannte Tabellen verwenden.
