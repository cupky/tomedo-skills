# ZS-Filter — Dynamische Benutzerfilter

## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- (2026-04-27): keine inhaltlichen Änderungen

ZS-Tags werden clientseitig durch UI-Elemente ersetzt. Sie müssen direkt in einer WHERE-Klausel platziert werden.

**Best Practice: ZS-Filter sollten in jede Statistik-Query eingebaut werden**, da sie dem Nutzer ermöglichen, Parameter manuell feinzujustieren, ohne die Query ändern zu müssen. Standard-Set:
- `DATE` für Zeiträume (von/bis)
- `STRING` für Freitext-Suche (Therapeut, Kalender, Patient etc.)
- `SELECTION` für kategoriale Filter (Ja/Nein, Typ-Auswahl)
- `TAG` für Marker-basierte Filterung

## Best Practice: Robuste WHERE-Klausel

```sql
WHERE
    true
    AND <ZS:queryParam1>STRING;Vorname;A.vorname;</ZS>
    AND <ZS:queryParam2>DATE;-1;Geburtsdatum ab;A.geburtsdatum >=;</ZS>
    AND <ZS:queryParam3>SELECTION;0;Privatpatient;Ja; B.privatpatient = true;Nein; B.privatpatient = false</ZS>
```

Immer mit `WHERE true` beginnen, jedes Tag mit `AND` einleiten, kein abschließendes `and` im Tag selbst.

> **Beachten:** Bei `DATE` tragen Spalte **und** Operator gemeinsam die dritte
> Komponente (`A.geburtsdatum >=`) — siehe Abschnitt „DATE". Wird ein Tag nicht
> angehakt, bleibt in dieser Schreibweise ein haengendes `AND` stehen; die robuste
> Variante steht unter „Opt-in-Falle".

### Werksschreibweise: das `and` steht im Tag

Die mitgelieferten Zollsoft-Statistiken — von tomedo selbst ausgefuehrter Code und damit
die belastbarste Referenz — verwenden eine andere Konvention als die oben gezeigte:

```sql
where
    <ZS:queryParameter2> STRING;Vorname;A.vorname;and </ZS>
    <ZS:queryParameterPrivat> SELECTION;0;Privatpatient;Ja; B.privatpatient = true and;Nein; B.privatpatient = false and</ZS>
    true
```

Das `and` gehoert **in** das Tag, die WHERE-Klausel endet auf `true`. Vorteil: bei leerer
Eingabe verschwindet das Tag rueckstandsfrei. Die Variante `WHERE true AND <ZS:...>`
hinterlaesst dagegen ein haengendes `AND`, sobald ein Tag entfaellt — genau der Effekt,
vor dem die Projektregel „SELECTION statt STRING fuer optionale Bedingungen" warnt.

**Beobachtung 2026-08-19, Status plausibel:** ZS-Tags scheinen im Ad-hoc-SQL-Fenster gar
nicht aufgeloest zu werden. Ein Statement mit zwei SELECTION-Tags brach dort mit
`syntax error at or near "<"` ab, wobei die Fehlerposition exakt auf dem schliessenden
`</ZS>` des ersten Tags lag — oeffnendes Tag verarbeitet, Endtag stehengeblieben. Naheliegende
Erklaerung: der Client baut die Filter-Oberflaeche aus dem **gespeicherten** `sqlquery`
eines Statistik-Elements; ad hoc gibt es keinen Dialog und damit keinen einzusetzenden Wert.
Konsequenz fuer die Praxis: ZS-Filter erst testen, nachdem die Query in der
Statistikverwaltung gespeichert wurde.


## Filtertypen

### STRING
```
<ZS:id>STRING;Label;SQL_Spalte;</ZS>
```
Erzeugt: `( SQL_Spalte ILIKE '%[Eingabe]%' )`

### NUMBER
```
<ZS:id>NUMBER;Label;SQL_Spalte;</ZS>
```
Erzeugt: `( SQL_Spalte = [Eingabe] )`

### DATE
```
<ZS:id>DATE;VonBis;Label;SQL_vor_Datum;SQL_nach_Klammer</ZS>
```
Erzeugt: `( SQL_vor_Datum 'YYYY-MM-DD HH24:MI:SS' ) SQL_nach_Klammer`

Belegt am 2026-09-19 an vier permutierten Varianten, zwei Laeufe (Referenzinstallation,
Stand 09/2026).

- **Genau vier Semikolons.** Die Assertion `[comps count] == 5` zaehlt den Typ-Token `DATE`
  mit. Ein trailing `;` ergibt sechs Komponenten → Abbruch.
- **c1 (VonBis) ist KEIN Tagesoffset.** Ausgewertet wird nur das Vorzeichen, und zwar auf die
  **Uhrzeit**: ≤ 0 → aktuelle Uhrzeit, > 0 → 23:59. Das **Datum steht immer auf heute**.
  Getestet mit 0, -18, -365, +1 — alle vier zeigten dasselbe Datum.
  → **Eine relative Vorbelegung (Monatsanfang, Quartalsanfang) ist mit DATE nicht moeglich.
  Dafuer `SELECTION` verwenden.**
- **c3 traegt Spalte UND Operator**: `P.geburtsdatum >=`. Die frueher hier dokumentierte Form
  `DATE;Offset;Label;Spalte;Operator` expandiert zu `( P.geburtsdatum '…' ) >=` und ist
  **immer** ungueltiges SQL.
- **c4 steht hinter der Klammer.** Leer lassen — oder `AND` fuer optionale Filter
  (siehe Opt-in-Falle).
- **Uhrzeit-Falle:** Das Literal traegt eine Uhrzeit. Eine DATE-Spalte liegt auf Mitternacht
  und faellt bei `>=` gegen die aktuelle Uhrzeit durch — **der heutige Tag verschwindet
  lautlos aus dem Ergebnis**. Bei Von-Feldern die Uhrzeit auf 00:00 setzen oder die Spalte
  casten.
- **Ungeklaert:** der Haekchen-Default. In zwei Laeufen war c1 = -18 vorselektiert, c1 = 0,
  -365 und +1 nicht; ein Muster ist daraus nicht ableitbar.

### SELECTION (Dropdown)
```
<ZS:id>SELECTION;Default_Index;Label;Opt1_Label; Opt1_SQL;Opt2_Label; Opt2_SQL</ZS>
```
- Default_Index: 0-basiert
- SQL-Teile: Vollständige Bedingung ohne abschließendes AND
- Erzeugt: Die SQL-Bedingung der gewählten Option

**Verifiziert 2026-09-19:** Einfache Anfuehrungszeichen, Kommata und `AND` innerhalb eines
Options-Segments sind unproblematisch; nur `;` trennt. Damit nimmt SELECTION vollwertiges SQL
auf und ist der **Traeger jeder relativen Zeitraumlogik** — inklusive `date_trunc`, auch im
finalen SELECT einer CTE-Kette. Default-Index 0 liefert dann z.B. den aktuellen Monat, bei
jedem Start neu gerechnet, ohne die Drift eines festen „minus 30 Tage".

### TAG (Marker)
```
<ZS:id>TAG;Label;ANY(T.tags_idents);</ZS>
```
- Erfordert vorbereitete `array_agg()`-Spalte (siehe Tag-Aggregation)
- Dritter Parameter: `ANY(spalte)`, NICHT nur `spalte`
- Erzeugt: `( (marker_id_1 = ANY(T.tags_idents)) AND (marker_id_2 = ANY(T.tags_idents)) )`

### LIMIT
```
<ZS:id>LIMIT;Label;Default_Wert</ZS>
```

**Nicht hinter ORDER BY platzieren.** Die alte Empfehlung („am Ende der Query, nach
ORDER BY") hat am 2026-08-19 reproduzierbar `syntax error at or near "<"` erzeugt. In den
mitgelieferten Zollsoft-Statistiken steht das LIMIT-Tag **ausnahmslos direkt hinter dem
abschliessenden `true` der WHERE-Klausel**, nie nach einem ORDER BY:

```
<ZS:queryParameterLimit> LIMIT;J;100000 </ZS>
```

Wird ein ORDER BY gebraucht, ist die risikoarme Variante, das LIMIT-Tag wegzulassen und
die Begrenzung dem Aufrufer zu ueberlassen — bei einem Export ist eine Kappung ohnehin
unerwuenscht.

### ZSBLOCK (OR-Verknüpfung)
Umschließt mehrere ZS-Tags die mit OR verknüpft werden.

### ZSPLACEHOLDER (Wiederverwendung)
```
<ZSPLACEHOLDER>name;<ZS:...></ZS></ZSPLACEHOLDER>  -- Definition
<ZSPLACEHOLDER>name;INSERT</ZSPLACEHOLDER>           -- Einsetzen
```

## Ausfuehrungsweg — Voraussetzung fuer alles Weitere

ZS-Tags werden **clientseitig** ersetzt. Im DB-Connector, in Metabase oder in der
Editor-Vorschau geht der Rohtext an PostgreSQL:

```
ERROR: syntax error at or near "<"
```

Aufloesung passiert ausschliesslich in einer **gespeicherten Statistik vom Typ SQL**, die aus
der Statistikliste gestartet wird. Das ist der Grund fuer Arbeitsregel 4.1: erst ohne
ZS-Filter bauen und gegen Echtdaten testen, ZS zuletzt nachruesten — und den Nachruest-Test
dann in der Statistikverwaltung fahren, nicht dort, wo entwickelt wurde.

**Debug-Kniff:** Das tomedo-Log zeigt die **expandierte** Query. Bei unklarer Tag-Semantik
mehrere Varianten in eine Query legen und die Expansion lesen — ob sie laeuft, ist dabei
egal. Das klaert Template-Fragen in einem Lauf statt in fuenf.

## Opt-in-Falle (alle Filtertypen)

Jeder Parameter hat links ein Haekchen und ist **teils standardmaessig inaktiv**. Ein
inaktives Tag expandiert zu Leerstring — das vorangestellte `AND` bleibt stehen:

```
ERROR: syntax error at end of input
```

Robustes Muster: das verbindende `AND` wandert in **c4** des Tags, im Quelltext folgt ein
`true` als Anker. Dann ist die Query in beiden Zustaenden gueltig.

```sql
    AND <ZS:von>DATE;-1;Datum ab (optional);T.datum >=;AND</ZS> true
```

- angehakt → `AND ( T.datum >= '2026-09-19 05:14:00' ) AND true`
- nicht angehakt → `AND  true`

`SELECTION` hat kein c4 — dort endet **jedes** Options-SQL auf `AND`.

## Referenzmuster: relativer Zeitraum mit optionaler Verfeinerung

Selbsttragend, ohne Patientendaten. Als Statistik vom Typ SQL speichern und aus der
Statistikliste starten.

```sql
WITH kal AS (
    SELECT (CURRENT_DATE - (gs.n * 5))::date AS datum
    FROM generate_series(0, 24) AS gs(n)
)
SELECT to_char(kal.datum, 'YYYY-MM-DD') AS testdatum
FROM kal
WHERE
    true
    AND <ZS:zr>SELECTION;0;Zeitraum;Aktueller Monat; kal.datum >= date_trunc('month', CURRENT_DATE) AND;Vormonat; kal.datum >= date_trunc('month', CURRENT_DATE - interval '1 month') AND kal.datum < date_trunc('month', CURRENT_DATE) AND;Freier Zeitraum; true AND</ZS> true
    AND <ZS:von>DATE;-1;Datum ab (optional);kal.datum >=;AND</ZS> true
    AND <ZS:bis>DATE;1;Datum bis (optional);kal.datum <=;AND</ZS> true
ORDER BY 1 DESC;
```

Abnahme (2026-09-19): nichts angehakt → 25 Zeilen · nur „Zeitraum" auf Default → 4 Zeilen ·
alle drei angehakt → 1 Zeile.

## Beispiel: Komplette Patientensuche mit Filtern

> ⚠ **Datenschutz-Hinweis:** Dieses Beispiel ist ein tomedo-Standard-Pattern für die
> lokale Patientensuche und enthält `nachname`, `vorname`, `geburtsdatum` im Ergebnis.
> Das ist korrekt — ZS-Filter und ihre Ergebnisse laufen vollständig lokal in tomedo.
> **Die Ergebnisdaten dieser Query dürfen jedoch nicht an die KI übermittelt werden.**
> Für KI-gestützte Analysen die personenbezogenen Spalten im finalen SELECT durch
> `patientID` und ggf. berechnetes `alter_jahre` ersetzen.
> Siehe auch: SKILL.md → Datenschutz by Design.

```sql
DROP TABLE IF EXISTS tempPatientTable;
CREATE TEMPORARY TABLE tempPatientTable AS
SELECT
    P.ident AS patientID,
    P.patientendetails_ident AS patientendetailsID,
    P.nachname,
    P.vorname,
    CAST(P.geburtsdatum AS date) AS geburtsdatum,
    PD.geschlecht,
    PD.privatpatient
FROM patient P
LEFT JOIN patientendetails PD ON P.patientendetails_ident = PD.ident
WHERE
    true
    AND <ZS:nachname>STRING;Nachname;P.nachname;</ZS>
    AND <ZS:vorname>STRING;Vorname;P.vorname;</ZS>
    AND <ZS:gebVon>DATE;-1;Geburtsdatum ab;P.geburtsdatum >=;</ZS>
    AND <ZS:gebBis>DATE;1;Geburtsdatum bis;P.geburtsdatum <=;</ZS>
    AND <ZS:privat>SELECTION;0;Privatpatient;Ja; PD.privatpatient = true;Nein; PD.privatpatient = false</ZS>
;

DROP TABLE IF EXISTS tempTagTable;
CREATE TEMPORARY TABLE tempTagTable AS
SELECT
    A.patientID,
    string_agg(C.beschreibung, ', ' ORDER BY C.beschreibung) AS tags,
    array_agg(C.ident) AS tags_idents
FROM tempPatientTable A
JOIN patientendetails_tags B ON A.patientendetailsID = B.patientendetails_ident
JOIN tag C ON B.tags_ident = C.ident
WHERE C.gruppe = false AND C.visible = true
GROUP BY A.patientID;

SELECT
    A.patientID,
    A.nachname,
    A.vorname,
    A.geburtsdatum,
    A.geschlecht,
    T.tags AS marker
FROM tempPatientTable A
LEFT JOIN tempTagTable T ON T.patientID = A.patientID
WHERE
    true
    AND <ZS:marker>TAG;Patienten-Marker;ANY(T.tags_idents);</ZS>
;
```
