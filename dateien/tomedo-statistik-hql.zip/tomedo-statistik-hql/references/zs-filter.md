# ZS-Filter — Dynamische Benutzerfilter

## CHANGELOG
- v11 (2026-10-22, Fassung 1.9): Überarbeitet im Oktober 2026. Berichtigt:
  DATE-Code c1 (Ziffern-Code statt Vorzeichen), SELECTION-c1 (Häkchen statt Index), LIMIT-c1, Beispiel-Uhrzeit
  05:14, ZSBLOCK, Patientensuche-Beispiel. Neu: Kennungsregel, Operatoren von STRING/NUMBER, weitere Typen
  (QUARTAL, MONAT, DAY, Nutzer- und Betriebsstättenauswahl, HINWEIS, VOLLTEXT), Pflichtfilter,
  Platzhalter-Varianten. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz prüfen.
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- (2026-04-27): keine inhaltlichen Änderungen

ZS-Tags werden clientseitig durch Filterzeilen im Statistikfenster ersetzt (Reiter „Parameter“). Die Ersetzung ist
**reine Textersetzung an beliebiger Stelle** des gespeicherten Querytexts — WHERE-Klausel, LIMIT, Unterabfrage,
auch in `CREATE TEMPORARY TABLE … AS SELECT` und sogar in SQL-Kommentaren **[ungeprüft]**. Üblich und empfohlen
ist trotzdem die WHERE-Klausel.

**Best Practice: ZS-Filter sollten in jede Statistik-Query eingebaut werden**, da sie dem Nutzer ermöglichen, Parameter manuell feinzujustieren, ohne die Query ändern zu müssen. Standard-Set:
- `DATE` für Zeiträume (von/bis), `QUARTAL`/`MONAT` für „aktuelles Quartal/aktueller Monat“ als Vorgabe
- `STRING` für Freitext-Suche (Therapeut, Kalender, Patient etc.)
- `SELECTION` für kategoriale Filter (Ja/Nein, Typ-Auswahl, relative Zeiträume)
- `TAG` für Marker-basierte Filterung

## Syntaxregeln für alle Tags

- Form: `<ZS:kennung>TYP;c1;c2;…</ZS>`. Getrennt wird **nur am `;`**. Leerzeichen nach `<ZS:kennung>` sind erlaubt
  (Herstellerform `<ZS:x> STRING;…`); der Typ wird ohne Rücksicht auf Groß-/Kleinschreibung erkannt.
- **Kennung nur aus Buchstaben (auch Umlaute) und Ziffern.** Mit `_` oder `-` wird das Tag nicht erkannt und geht
  roh an PostgreSQL (`syntax error at or near "<"`) **[ungeprüft]**. Jede Kennung nur einmal je Statistik.
  Kennungen mit Umlaut meiden, wenn die Liste später über „Neue Liste erstellen…“ verknüpft werden soll — dort
  werden nur ASCII-Kennungen erkannt **[ungeprüft]**.
- Ein Tag endet am **ersten** `</ZS>`; Tags lassen sich nicht verschachteln.
- Ein falsch geschriebener Typ (z. B. `SELECTON`) erzeugt keine Filterzeile; das Öffnen der Statistik kann dann
  scheitern **[ungeprüft]**. Vor dem Speichern Typnamen prüfen.

## Best Practice: Robuste WHERE-Klausel

```sql
WHERE
    true
    AND <ZS:queryParam1>STRING;Vorname;A.vorname;</ZS>
    AND <ZS:queryParam2>DATE;-1;Geburtsdatum ab;A.geburtsdatum >=;</ZS>
    AND <ZS:queryParam3>SELECTION;0;Privatpatient;Ja; B.privatpatient = true;Nein; B.privatpatient = false</ZS>
```

Immer mit `WHERE true` beginnen, jedes Tag mit `AND` einleiten, kein abschließendes `and` im Tag selbst.

> **Beachten:** Bei `DATE` tragen Spalte **und** Operator gemeinsam die dritte
> Komponente (`A.geburtsdatum >=`) — siehe Abschnitt „DATE". Wird ein Tag nicht
> angehakt, bleibt in dieser Schreibweise ein haengendes `AND` stehen; die robuste
> Variante steht unter „Opt-in-Falle". Im Beispiel oben sind **alle drei** Tags anfangs
> nicht angehakt — so wie es dasteht, bricht die Query beim ersten Start ab **[ungeprüft]**.

### Werksschreibweise: das `and` steht im Tag

Die mitgelieferten Zollsoft-Statistiken — von tomedo selbst ausgefuehrter Code und damit
die belastbarste Referenz — verwenden eine andere Konvention als die oben gezeigte:

```sql
where
    <ZS:queryParameter2> STRING;Vorname;A.vorname;and </ZS>
    <ZS:queryParameterPrivat> SELECTION;0;Privatpatient;Ja; B.privatpatient = true and;Nein; B.privatpatient = false and</ZS>
    true
```

Das `and` gehoert **in** das Tag, die WHERE-Klausel endet auf `true`. Vorteil: bei leerer
Eingabe verschwindet das Tag rueckstandsfrei. Die Variante `WHERE true AND <ZS:...>`
hinterlaesst dagegen ein haengendes `AND`, sobald ein Tag entfaellt — genau der Effekt,
vor dem die Projektregel „SELECTION statt STRING fuer optionale Bedingungen" warnt.

**Beobachtung 2026-08-19 (Messung):** Ein Statement mit zwei SELECTION-Tags brach mit
`syntax error at or near "<"` ab, die Fehlerposition lag auf dem schliessenden `</ZS>` des ersten Tags.
**Einordnung [ungeprüft]:** Das Statistikfenster hat neben „Parameter“ einen Reiter
**„SQL“**. Er zeigt den **bereits ersetzten** Text und ist (mit dem Fensterrecht „Statistikverwaltung aufrufen“)
editierbar; ausgeführt wird genau dieser Text. Wer dort eine Query **mit** ZS-Tags einfügt, schickt sie
unverarbeitet an den Server. Die Ersetzung verarbeitet nie nur das öffnende Tag; eine Fehlerposition am `</ZS>`
spricht eher dafür, dass der Server den Text am `;` innerhalb des Tags zerlegt. Konsequenz unverändert:
ZS-Filter erst testen, nachdem die Query in der Statistikverwaltung gespeichert wurde, und aus der
Statistikliste starten.


## Filtertypen

### STRING
```
<ZS:id>STRING;Label;SQL_Spalte;c3</ZS>
```
Erzeugt: ` c3 ( SQL_Spalte ilike '%Eingabe%' ) ` mit dem Standardoperator „enthält“.

**Operatoren [ungeprüft]:** Das Klappmenü neben dem Eingabefeld bietet elf Vergleiche: enthält (Standard), ist,
enthält nicht, beginnt mit, beginnt nicht mit, endet mit, endet nicht mit, enthält einen / alle / keinen der
folgenden Texte (Trennung an Komma und Leerzeichen), ist einer der folgenden Texte (Trennung am Komma). Die
„nicht“-Varianten schließen leere Spalten (`NULL`, `''`) mit ein.
- Nur das Hochkomma `'` wird in der Eingabe verdoppelt. **`%` und `_` in der Eingabe wirken als Platzhalter.**
- Das Häkchen setzt sich beim Tippen automatisch.
- Mehrere Spalten [ungeprüft]: `STRING;Label;OR;spalteA;spalteB;…;c_letzte` durchsucht alle genannten Spalten,
  verknüpft mit `AND` oder `OR`, und klammert das Ganze.
- Die erzeugte Bedingung enthält selbst `%` in Stringliteralen. Zum Verbot „kein `%` im Query-Text“ siehe SKILL.md §3,
  Regel 1.

### NUMBER
```
<ZS:id>NUMBER;Label;SQL_Spalte;c3</ZS>
```
Erzeugt: ` SQL_Spalte = Zahl c3 ` — **ohne Klammern** **[ungeprüft]**. Operator wählbar `=`, `>`, `<`
(Vorgabe `=`); ein Dezimalkomma wird zum Punkt. Anfangs nicht angehakt, das Häkchen kommt mit der Eingabe.

### DATE
```
<ZS:id>DATE;Code;Label;SQL_vor_Datum;SQL_nach_Klammer</ZS>
```
Erzeugt: `( SQL_vor_Datum 'YYYY-MM-DD HH:MI:00' ) SQL_nach_Klammer` — Minutenauflösung, Sekunden immer `:00`.

Belegt am 2026-09-19 an vier permutierten Varianten, zwei Laeufe (Referenzinstallation,
Stand 09/2026); Bedeutung von c1 ergänzt 10/2026.

- **Genau vier Semikolons.** Erwartet werden fünf Komponenten (Typ mitgezählt). Bei einem
  überzähligen `;` am Ende wird die letzte Komponente ignoriert und meist eine Warnung protokolliert; hart
  scheitert die Zeile erst bei **weniger** als fünf Komponenten **[ungeprüft]**. Trotzdem: kein `;` am Ende.
- **c1 ist ein Ziffern-Code, kein Tagesoffset [ungeprüft].** Gelesen wird von rechts:
  - **letzte Ziffer `1`** = Tagesgrenze: mit vorangestelltem `-` **heute 00:00:00** (Von-Feld), ohne `-`
    **Tagesende** — im Datumsfeld steht 23:59, im SQL-Literal aber **morgen 00:00:00** (eine Minute addiert).
    Mit `<` ist das die saubere exklusive Obergrenze (Herstellerform `DATE; 1; bis;T.datum <;`), mit `<=`
    zählt Mitternacht des Folgetags mit.
  - **vorletzte Ziffer `1`** = Häkchen gesetzt **und gesperrt** (Pflichtfilter, der Nutzer kann ihn nicht abwählen).
  - **drittletzte Ziffer `1`** = ohne Klammern um den Ausdruck.
  - jede andere Ziffer = 0: aktuelle Uhrzeit, nicht angehakt.
  Damit: `-1` → heute 00:00 · `1`/`+1` → Tagesende · `0`, `-365` → jetzt, nicht angehakt · `-18`, `-10` → jetzt,
  **Pflicht** · `11` → Tagesende, Pflicht. Das erklärt die Messung „-18 war vorselektiert“. Das **Datum steht
  immer auf heute**; eine relative Vorbelegung (Monats-, Quartalsanfang) geht mit DATE nicht — dafür
  `QUARTAL`, `MONAT` oder `SELECTION` verwenden.
- **c3 traegt Spalte UND Operator**: `P.geburtsdatum >=`. Die frueher hier dokumentierte Form
  `DATE;Offset;Label;Spalte;Operator` expandiert zu `( P.geburtsdatum '…' ) >=` und ist
  **immer** ungueltiges SQL.
- **c4 steht hinter der Klammer.** Leer lassen — oder `AND` fuer optionale Filter
  (siehe Opt-in-Falle).
- **Uhrzeit-Falle:** Gilt nur für Codes **ohne** Tagesgrenze (0, -18, -365 …): Das Literal trägt die aktuelle
  Uhrzeit, eine DATE-Spalte liegt auf Mitternacht und fällt bei `>=` durch — **der heutige Tag verschwindet
  lautlos**. Abhilfe: Code `-1` für Von-Felder, `1` für Bis-Felder, oder die Spalte casten.

### SELECTION (Dropdown)
```
<ZS:id>SELECTION;Häkchen;Label;Opt1_Label; Opt1_SQL;Opt2_Label; Opt2_SQL</ZS>
```
- **c1 ist der Anfangszustand des Häkchens, kein Index [ungeprüft]:** `1` = angehakt, `2` = angehakt **und
  gesperrt** (Pflichtfilter), jeder andere Wert (auch `0`) = nicht angehakt. **Vorausgewählt ist immer die
  erste Option.** Die frühere Lesart „0-basierter Default-Index“ passte nur zufällig, weil 0 die erste Option
  traf.
- Optionen paarweise (Beschriftung; SQL). Gleiche Beschriftungen überschreiben sich — beide Menüeinträge
  liefern dann das SQL der letzten **[ungeprüft]**. Beschriftungen eindeutig halten.
- SQL-Teile: vollständige Bedingung; das verbindende `AND` steht im Options-SQL (SELECTION hat kein c4).
- Erzeugt: das SQL der gewählten Option, unverändert.

**Verifiziert 2026-09-19:** Einfache Anfuehrungszeichen, Kommata und `AND` innerhalb eines
Options-Segments sind unproblematisch; nur `;` trennt. Damit nimmt SELECTION vollwertiges SQL
auf und ist ein **Traeger relativer Zeitraumlogik** — inklusive `date_trunc`, auch im
finalen SELECT einer CTE-Kette. Die erste Option liefert dann z.B. den aktuellen Monat, bei
jedem Start neu gerechnet, ohne die Drift eines festen „minus 30 Tage". Damit sie ohne Klick gilt,
c1 = `1` oder `2` setzen.

### QUARTAL, MONAT und Verwandte [ungeprüft]
Relative Vorbelegung **ohne** SELECTION:
- `QUARTAL;Label;spalte;c` bzw. `QUARTAL;Häkchen;Label;spalte;c` → `( spalte >= 'Quartalsanfang 00:00:00' and
  spalte <= 'Quartalsende 23:59:59' ) c`. Auswahl: nächstes bis 23 zurückliegende Quartale, **vorausgewählt das
  aktuelle Quartal**. Häkchen-Code wie bei SELECTION (`1`/`2`), nur in der Form mit fünf Komponenten.
- `MONAT;[Häkchen;]Label;spalte;c` → Monatsgrenzen, vorausgewählt aktueller Monat und aktuelles Jahr; Eintrag
  „alle Monate“ → ganzes Jahr.
- `QUARTAL2;Label;quartalsspalte;jahresspalte;c` → `( q = Q and j = J )` für Tabellen mit getrennten Spalten
  `quartal`/`jahr`; `QUARTAL3;Label;Vergleich;q;j;c` mit wählbarem Vergleich (gleich, kleiner, kleiner gleich,
  größer gleich, größer, ungleich).
- `DAY;Code;Label;spalte;c` → ein ganzer Kalendertag (`spalte >= 'Tag 00:00:00' AND spalte <= 'Tag 23:59:59'`);
  Code mit führender `1` = Pflicht.

### Nutzer- und Betriebsstättenauswahl [ungeprüft]
- `NUTZERSELECTION;Häkchen;Nutzerkreis;Label;vorText;nachText` bietet die Nutzerkürzel zur Auswahl und setzt
  `vorText + Kürzel + nachText` ein (Nutzerkreis 0 = sichtbare Nutzer, 1 = Leistungserbringer,
  2 = Vertragsärzte, 3 = alle inkl. gelöschter). Passt zur Regel „über `TRIM(kuerzel)` statt `nutzer.ident`“.
- `NUTZERDEPENDENTSELECTION;Häkchen;Label;Titel;Recht;SQL;…` (Dreiergruppen Titel/Recht/SQL) zeigt Optionen je
  Nutzerrecht; im SQL steht `<ZSNUTZERIDENT>` für die `nutzer.ident` des angemeldeten Nutzers und `<ZSSEMIKOLON>`
  für ein `;`.
- `BETRIEBSSTAETTENSELECTION;Häkchen;–;Label;spalte;c` erlaubt Mehrfachauswahl und erzeugt `spalte = ident` bzw.
  `(spalte IN (…))`; keine oder alle gewählt → keine Einschränkung.

### Weitere Typen [ungeprüft]
- `HINWEIS;Text` — nur eine Textzeile im Parameterbereich, erzeugt nichts.
- `VOLLTEXT;Label;Spalte;c` — immer angehakt, erzeugt eine Volltextsuche (`to_tsquery('german', …)`).
- `STRINGPARAMETER` setzt die Eingabe **ohne Maskierung** zwischen Vor- und Nachtext ein — nur für vertrauenswürdige
  Nutzer.
- Weitere Typen (`NUMBERPARAMETER`, `SELECTIONPARAMETER`, `IDLIST`, `ONLYONJOIN`, `QUARTAL4`,
  `QUARTALORCURRENT`, `OPPLAN`, `CUSTOM`) gehören zu Herstellerstatistiken und eignen sich nicht für eigene
  Queries.

### TAG (Marker)
```
<ZS:id>TAG;Label;ANY(T.tags_idents);c3</ZS>
```
- `tags_idents` ist **keine Spalte**, sondern ein in der eigenen Query gebildetes `array_agg(tag.ident)` (Marker
  hängen über die Brücke `patientendetails_tags` am Patienten, siehe Tag-Aggregation unten). Jeder Array-Ausdruck
  geht, auch ein Unter-SELECT mit `ARRAY(…)` **[ungeprüft]**.
- Dritter Parameter: `ANY(spalte)`, NICHT nur `spalte`
- Erzeugt: ` (  id1 = ANY(…)  AND  id2 = ANY(…)  ) c3 `. Verknüpfung über ein Optionsfeld **„und“/„oder“**
  wählbar (Standard „und“); angeboten werden nur Patientenmarker, keine Gruppen; ohne gewählten Marker entfällt
  der Ausdruck **[ungeprüft]**.

### LIMIT
```
<ZS:id>LIMIT;c1;Default_Wert</ZS>
```
c1 wird nicht ausgewertet (früher „J“ = angehakt); LIMIT ist **immer zunächst nicht angehakt** und erzeugt
` limit N ` **[ungeprüft]**.

**Platzierung (Messung 2026-08-19):** Hinter ORDER BY erschien reproduzierbar `syntax error at or near "<"`. In den
mitgelieferten Zollsoft-Statistiken steht das LIMIT-Tag **ausnahmslos direkt hinter dem abschliessenden `true` der
WHERE-Klausel**:

```
<ZS:queryParameterLimit> LIMIT;J;100000 </ZS>
```

**Einordnung [ungeprüft]:** Das Tag wird unabhängig von der Position ersetzt, und ` limit N ` hinter ORDER BY
ist gültiges SQL. `syntax error at or near "<"` heißt also, dass das Tag **gar nicht** ersetzt wurde (Ausführung
außerhalb einer gespeicherten SQL-Statistik, Kennung mit `_`/`-`). Bis das geprüft ist: Wird ein ORDER BY
gebraucht, ist die risikoarme Variante, das LIMIT-Tag wegzulassen und die Begrenzung dem Aufrufer zu
ueberlassen — bei einem Export ist eine Kappung ohnehin unerwuenscht.

### ZSBLOCK [ungeprüft]
`<ZSBLOCK> … </ZSBLOCK>` fasst mehrere ZS-Tags zu einem Klammerausdruck zusammen; er verknüpft **nicht selbst**
mit OR. Nach der Ersetzung gilt: leerer Block → `true`; sonst entfernt tomedo eine äußere Klammer sowie **ein**
führendes oder abschließendes `OR`/`AND` und setzt das Ganze in `( … )`. Das `or` gehört also in die Tags,
z. B. `STRING;…;spalte; or `. Ein **führendes** `AND` im Block wird nicht sauber entfernt — Blöcke mit `OR`
schreiben und vor dem Einsatz testen.

### ZSPLACEHOLDER (Wiederverwendung)
```
<ZSPLACEHOLDER>name;<ZS:...></ZS></ZSPLACEHOLDER>  -- Definition
<ZSPLACEHOLDER>name;INSERT</ZSPLACEHOLDER>           -- Einsetzen
<ZSPLACEHOLDER>name;REPLACE;alt;neu</ZSPLACEHOLDER>  -- Einsetzen mit Textersatz [ungeprüft]
```
Ergänzungen [ungeprüft]: Die Definition wird nur **bis zum ersten `;` nach dem Namen** übernommen und an ihrer
Stelle durch ein Leerzeichen ersetzt. Reihenfolge der Ersetzung: erst ZS-Tags, dann ZSBLOCK, dann Platzhalter —
ein ZS-Tag in der Definition ist beim Einsetzen schon ersetzt. Für Verschachtelung gibt es `<ZSPLACEHOLDER1>` bis
`<ZSPLACEHOLDER3>`. Enthält der Definitionstext die Wörter `insert` oder `replace` (etwa `regexp_replace(…)`),
wird er als Einsetzung missverstanden — solche Funktionen nicht in Platzhalter-Definitionen schreiben.

## Ausfuehrungsweg — Voraussetzung fuer alles Weitere

ZS-Tags werden **clientseitig** ersetzt. Im DB-Connector, in Metabase oder in der
Editor-Vorschau geht der Rohtext an PostgreSQL:

```
ERROR: syntax error at or near "<"
```

Aufloesung passiert in einer **gespeicherten Statistik vom Typ SQL**, die aus der Statistikliste gestartet wird
(dazu im Auto-Statistik-Export). Statistiken vom Typ „Patientbezogen“ und SQL-Bedingungen von
Aktionskettenauslösern verarbeiten **keine** ZS-Tags **[ungeprüft]**. Das ist der Grund fuer Arbeitsregel 4.1:
erst ohne ZS-Filter bauen und gegen Echtdaten testen, ZS zuletzt nachruesten — und den Nachruest-Test
dann in der Statistikverwaltung fahren, nicht dort, wo entwickelt wurde.

**Debug-Kniff:** Der Reiter „SQL“ im Statistikfenster zeigt die **expandierte** Query live, das Ergebnisfenster
protokolliert sie beim Start („Starte Ergebnisempfang für Abfrage …“), ebenso das tomedo-Log. Bei unklarer
Tag-Semantik mehrere Varianten in eine Query legen und die Expansion lesen — ob sie laeuft, ist dabei
egal. Das klaert Template-Fragen in einem Lauf statt in fuenf.

**Gespeicherte Vorauswahl:** tomedo merkt sich die zuletzt gesetzten Filter je Statistik (Spalte
`savedpreselections` in `outlineviewelement`) und die letzte Ausführung (`usagetracking`) **[ungeprüft]**.

## Opt-in-Falle (alle Filtertypen)

Jeder Parameter hat links ein Haekchen. **Anfangs nicht angehakt** sind STRING, NUMBER, LIMIT, TAG, QUARTAL und
MONAT (ohne Häkchen-Code), DATE und SELECTION ohne Pflicht-Code **[ungeprüft]**. Eine Eingabe oder Auswahl setzt
das Häkchen meist automatisch. Ein inaktives Tag wird durch ein Leerzeichen ersetzt — das vorangestellte `AND`
bleibt stehen:

```
ERROR: syntax error at end of input
```

Robustes Muster: das verbindende `AND` wandert in **c4** des Tags, im Quelltext folgt ein
`true` als Anker. Dann ist die Query in beiden Zustaenden gueltig.

```sql
    AND <ZS:von>DATE;-1;Datum ab (optional);T.datum >=;AND</ZS> true
```

- angehakt → `AND ( T.datum >= '2026-09-19 00:00:00' ) AND true` (Code `-1` = Tagesanfang; die früher hier
  gezeigte Uhrzeit 05:14 entstand durch eine Datumswahl von Hand)
- nicht angehakt → `AND  true`

`SELECTION` hat kein c4 — dort endet **jedes** Options-SQL auf `AND`.

**Pflichtfilter:** Ein Filter, der immer gelten muss, bekommt den Pflicht-Code (SELECTION c1 = `2`, DATE mit
vorletzter Ziffer `1`, z. B. `-11`); dann kann der Nutzer ihn nicht abwählen **[ungeprüft]**.

## Referenzmuster: relativer Zeitraum mit optionaler Verfeinerung

Selbsttragend, ohne Patientendaten. Als Statistik vom Typ SQL speichern und aus der
Statistikliste starten.

```sql
WITH kal AS (
    SELECT (CURRENT_DATE - (gs.n * 5))::date AS datum
    FROM generate_series(0, 24) AS gs(n)
)
SELECT to_char(kal.datum, 'YYYY-MM-DD') AS testdatum
FROM kal
WHERE
    true
    AND <ZS:zr>SELECTION;0;Zeitraum;Aktueller Monat; kal.datum >= date_trunc('month', CURRENT_DATE) AND;Vormonat; kal.datum >= date_trunc('month', CURRENT_DATE - interval '1 month') AND kal.datum < date_trunc('month', CURRENT_DATE) AND;Freier Zeitraum; true AND</ZS> true
    AND <ZS:von>DATE;-1;Datum ab (optional);kal.datum >=;AND</ZS> true
    AND <ZS:bis>DATE;1;Datum bis (optional);kal.datum <;AND</ZS> true
ORDER BY 1 DESC;
```

Abnahme (2026-09-19): nichts angehakt → 25 Zeilen · nur „Zeitraum" auf Default → 4 Zeilen ·
alle drei angehakt → 1 Zeile. (Bis-Feld jetzt mit `<`, weil Code `1` morgen 00:00 einsetzt **[ungeprüft]**.)

## Beispiel: Patientensuche mit Filtern

> ⚠ **Datenschutz-Hinweis:** Dieses Beispiel ist ein tomedo-Standard-Pattern für die
> lokale Patientensuche und enthält `nachname`, `vorname`, `geburtsdatum` im Ergebnis.
> Das ist korrekt — ZS-Filter und ihre Ergebnisse laufen vollständig lokal in tomedo.
> **Die Ergebnisdaten dieser Query dürfen jedoch nicht an die KI übermittelt werden.**
> Für KI-gestützte Analysen die personenbezogenen Spalten im finalen SELECT durch
> `patientID` und ggf. berechnetes `alter_jahre` ersetzen.
> Siehe auch: SKILL.md → Datenschutz by Design.

Berichtigt 10/2026: Die frühere Fassung mit zwei Temp-Tabellen und `WHERE true AND <ZS…>` brach im Grundzustand
ab (alle Filter anfangs nicht angehakt → `AND AND`) und widersprach den Regeln 2 und 6 in SKILL.md. Diese Fassung
kommt mit **einem** SELECT aus und nutzt die Werksschreibweise **[ungeprüft]**.

```sql
WITH tagagg AS (
    SELECT B.patientendetails_ident,
           string_agg(C.beschreibung, ', ' ORDER BY C.beschreibung) AS tags,
           array_agg(C.ident) AS tags_idents
    FROM patientendetails_tags B
    JOIN tag C ON B.tags_ident = C.ident
    WHERE C.gruppe = false AND C.visible = true
    GROUP BY B.patientendetails_ident
)
SELECT
    P.ident AS patientID,
    P.nachname,
    P.vorname,
    CAST(P.geburtsdatum AS date) AS geburtsdatum,
    PD.geschlecht,
    T.tags AS marker
FROM patient P
LEFT JOIN patientendetails PD ON P.patientendetails_ident = PD.ident
LEFT JOIN tagagg T ON T.patientendetails_ident = PD.ident
WHERE
    <ZS:nachname> STRING;Nachname;P.nachname;and </ZS>
    <ZS:vorname> STRING;Vorname;P.vorname;and </ZS>
    <ZS:gebVon> DATE;-1;Geburtsdatum ab;P.geburtsdatum >=;and </ZS>
    <ZS:gebBis> DATE;1;Geburtsdatum bis;P.geburtsdatum <;and </ZS>
    <ZS:privat> SELECTION;0;Privatpatient;Ja; PD.privatpatient = true and;Nein; PD.privatpatient = false and</ZS>
    <ZS:marker> TAG;Patienten-Marker;ANY(T.tags_idents);and </ZS>
    true;
```
