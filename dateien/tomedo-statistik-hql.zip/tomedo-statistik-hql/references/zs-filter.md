# ZS-Filter — Dynamische Benutzerfilter

## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- (2026-04-27): keine inhaltlichen Änderungen

ZS-Tags werden clientseitig durch UI-Elemente ersetzt. Sie müssen direkt in einer WHERE-Klausel platziert werden.

**Best Practice: ZS-Filter sollten in jede Statistik-Query eingebaut werden**, da sie dem Nutzer ermöglichen, Parameter manuell feinzujustieren, ohne die Query ändern zu müssen. Standard-Set:
- `DATE` für Zeiträume (von/bis)
- `STRING` für Freitext-Suche (Therapeut, Kalender, Patient etc.)
- `SELECTION` für kategoriale Filter (Ja/Nein, Typ-Auswahl)
- `TAG` für Marker-basierte Filterung

## Best Practice: Robuste WHERE-Klausel

```sql
WHERE
    true
    AND <ZS:queryParam1>STRING;Vorname;A.vorname;</ZS>
    AND <ZS:queryParam2>DATE;-1;Geburtsdatum ab;A.geburtsdatum;>=</ZS>
    AND <ZS:queryParam3>SELECTION;0;Privatpatient;Ja; B.privatpatient = true;Nein; B.privatpatient = false</ZS>
```

Immer mit `WHERE true` beginnen, jedes Tag mit `AND` einleiten, kein abschließendes `and` im Tag selbst.

### Werksschreibweise: das `and` steht im Tag

Die mitgelieferten Zollsoft-Statistiken — von tomedo selbst ausgefuehrter Code und damit
die belastbarste Referenz — verwenden eine andere Konvention als die oben gezeigte:

```sql
where
    <ZS:queryParameter2> STRING;Vorname;A.vorname;and </ZS>
    <ZS:queryParameterPrivat> SELECTION;0;Privatpatient;Ja; B.privatpatient = true and;Nein; B.privatpatient = false and</ZS>
    true
```

Das `and` gehoert **in** das Tag, die WHERE-Klausel endet auf `true`. Vorteil: bei leerer
Eingabe verschwindet das Tag rueckstandsfrei. Die Variante `WHERE true AND <ZS:...>`
hinterlaesst dagegen ein haengendes `AND`, sobald ein Tag entfaellt — genau der Effekt,
vor dem die Projektregel „SELECTION statt STRING fuer optionale Bedingungen" warnt.

**Beobachtung 2026-08-19, Status plausibel:** ZS-Tags scheinen im Ad-hoc-SQL-Fenster gar
nicht aufgeloest zu werden. Ein Statement mit zwei SELECTION-Tags brach dort mit
`syntax error at or near "<"` ab, wobei die Fehlerposition exakt auf dem schliessenden
`</ZS>` des ersten Tags lag — oeffnendes Tag verarbeitet, Endtag stehengeblieben. Naheliegende
Erklaerung: der Client baut die Filter-Oberflaeche aus dem **gespeicherten** `sqlquery`
eines Statistik-Elements; ad hoc gibt es keinen Dialog und damit keinen einzusetzenden Wert.
Konsequenz fuer die Praxis: ZS-Filter erst testen, nachdem die Query in der
Statistikverwaltung gespeichert wurde.


## Filtertypen

### STRING
```
<ZS:id>STRING;Label;SQL_Spalte;</ZS>
```
Erzeugt: `( SQL_Spalte ILIKE '%[Eingabe]%' )`

### NUMBER
```
<ZS:id>NUMBER;Label;SQL_Spalte;</ZS>
```
Erzeugt: `( SQL_Spalte = [Eingabe] )`

### DATE
```
<ZS:id>DATE;Default_Offset;Label;SQL_Spalte;Operator</ZS>
```
- Default_Offset: Tage relativ zu heute (-1 = gestern, 1 = morgen)
- Operator: `>=`, `<=`, `>`, `<`
- Erzeugt: `( SQL_Spalte [Operator] '[Datum]' )`
- **WICHTIG: Kein abschließendes Semikolon!** tomedo erwartet exakt 5 Komponenten. Ein trailing `;` erzeugt einen Assertion-Fehler (`[comps count] == 5`).

### SELECTION (Dropdown)
```
<ZS:id>SELECTION;Default_Index;Label;Opt1_Label; Opt1_SQL;Opt2_Label; Opt2_SQL</ZS>
```
- Default_Index: 0-basiert
- SQL-Teile: Vollständige Bedingung ohne abschließendes AND
- Erzeugt: Die SQL-Bedingung der gewählten Option

### TAG (Marker)
```
<ZS:id>TAG;Label;ANY(T.tags_idents);</ZS>
```
- Erfordert vorbereitete `array_agg()`-Spalte (siehe Tag-Aggregation)
- Dritter Parameter: `ANY(spalte)`, NICHT nur `spalte`
- Erzeugt: `( (marker_id_1 = ANY(T.tags_idents)) AND (marker_id_2 = ANY(T.tags_idents)) )`

### LIMIT
```
<ZS:id>LIMIT;Label;Default_Wert</ZS>
```

**Nicht hinter ORDER BY platzieren.** Die alte Empfehlung („am Ende der Query, nach
ORDER BY") hat am 2026-08-19 reproduzierbar `syntax error at or near "<"` erzeugt. In den
mitgelieferten Zollsoft-Statistiken steht das LIMIT-Tag **ausnahmslos direkt hinter dem
abschliessenden `true` der WHERE-Klausel**, nie nach einem ORDER BY:

```
<ZS:queryParameterLimit> LIMIT;J;100000 </ZS>
```

Wird ein ORDER BY gebraucht, ist die risikoarme Variante, das LIMIT-Tag wegzulassen und
die Begrenzung dem Aufrufer zu ueberlassen — bei einem Export ist eine Kappung ohnehin
unerwuenscht.

### ZSBLOCK (OR-Verknüpfung)
Umschließt mehrere ZS-Tags die mit OR verknüpft werden.

### ZSPLACEHOLDER (Wiederverwendung)
```
<ZSPLACEHOLDER>name;<ZS:...></ZS></ZSPLACEHOLDER>  -- Definition
<ZSPLACEHOLDER>name;INSERT</ZSPLACEHOLDER>           -- Einsetzen
```

## Beispiel: Komplette Patientensuche mit Filtern

> ⚠ **Datenschutz-Hinweis:** Dieses Beispiel ist ein tomedo-Standard-Pattern für die
> lokale Patientensuche und enthält `nachname`, `vorname`, `geburtsdatum` im Ergebnis.
> Das ist korrekt — ZS-Filter und ihre Ergebnisse laufen vollständig lokal in tomedo.
> **Die Ergebnisdaten dieser Query dürfen jedoch nicht an die KI übermittelt werden.**
> Für KI-gestützte Analysen die personenbezogenen Spalten im finalen SELECT durch
> `patientID` und ggf. berechnetes `alter_jahre` ersetzen.
> Siehe auch: SKILL.md → Datenschutz by Design.

```sql
DROP TABLE IF EXISTS tempPatientTable;
CREATE TEMPORARY TABLE tempPatientTable AS
SELECT
    P.ident AS patientID,
    P.patientendetails_ident AS patientendetailsID,
    P.nachname,
    P.vorname,
    CAST(P.geburtsdatum AS date) AS geburtsdatum,
    PD.geschlecht,
    PD.privatpatient
FROM patient P
LEFT JOIN patientendetails PD ON P.patientendetails_ident = PD.ident
WHERE
    true
    AND <ZS:nachname>STRING;Nachname;P.nachname;</ZS>
    AND <ZS:vorname>STRING;Vorname;P.vorname;</ZS>
    AND <ZS:gebVon>DATE;-1;Geburtsdatum ab;P.geburtsdatum;>=</ZS>
    AND <ZS:gebBis>DATE;1;Geburtsdatum bis;P.geburtsdatum;<=</ZS>
    AND <ZS:privat>SELECTION;0;Privatpatient;Ja; PD.privatpatient = true;Nein; PD.privatpatient = false</ZS>
;

DROP TABLE IF EXISTS tempTagTable;
CREATE TEMPORARY TABLE tempTagTable AS
SELECT
    A.patientID,
    string_agg(C.beschreibung, ', ' ORDER BY C.beschreibung) AS tags,
    array_agg(C.ident) AS tags_idents
FROM tempPatientTable A
JOIN patientendetails_tags B ON A.patientendetailsID = B.patientendetails_ident
JOIN tag C ON B.tags_ident = C.ident
WHERE C.gruppe = false AND C.visible = true
GROUP BY A.patientID;

SELECT
    A.patientID,
    A.nachname,
    A.vorname,
    A.geburtsdatum,
    A.geschlecht,
    T.tags AS marker
FROM tempPatientTable A
LEFT JOIN tempTagTable T ON T.patientID = A.patientID
WHERE
    true
    AND <ZS:marker>TAG;Patienten-Marker;ANY(T.tags_idents);</ZS>
;
```
