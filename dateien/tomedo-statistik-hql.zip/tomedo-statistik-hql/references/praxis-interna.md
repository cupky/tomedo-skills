# Praxis-Interna dieser Installation

**Diese Datei ist absichtlich leer ausgeliefert.** Sie ist der vorgesehene Ort für die
Kürzel, Namen und gemessenen Werte **Ihrer** Installation. Der übrige Skill nennt
dieselben Sachverhalte generisch — mit Platzhalter und einer Query, mit der Sie den
eigenen Wert ermitteln. Tragen Sie die Ergebnisse hier ein, dann arbeitet die KI mit
Ihren Werten statt mit Vermutungen.

**Warum getrennt:** So lässt sich der Skill weitergeben, ohne dass Praxisinterna
mitwandern — und eine neue Fassung des Skills überschreibt Ihre Erhebung nicht, solange
Sie diese Datei beim Aktualisieren stehen lassen.

**Erhebungsstand:** _(Datum eintragen)_ · Einzelne Befunde tragen ihr eigenes Messdatum.

---

## 1 · Auflösung der Platzhalter im Rumpf

| Platzhalter im Rumpf | Fundstelle | Wert bei Ihnen |
|---|---|---|
| `<TYP-A>` — Alt-Typ Therapiezeile | `datenmodell.md` §Therapiezeilen-Kürzel | |
| `<TYP-B>` — Nachfolger | dieselben | |
| `<TYP-C>` — Paralleltyp | dieselben | |
| `<Gruppe>_<Kürzel>_<Jahr>` — Kalendername mit Unterstrichen | `lessons-learned.md` §Regex-Wortgrenze | |
| „eigene Praxiskontext-Datei" | `datenmodell.md` | |
| „Opener-Skill" | `SKILL.md` §Lese-Routing | |

Die Therapiezeilen-Kürzel ermitteln Sie mit der Query im Abschnitt
„Therapiezeilen-Kürzel" in `datenmodell.md`. Eine Umstellung des
Dokumentationsworkflows hinterlässt regelmäßig mehrere parallele Typen — prüfen Sie
deshalb auf mehr als einen.

---

## 2 · Gemessene Befunde Ihrer Installation

Hierher gehört alles, was nur bei Ihnen gilt: leere oder ungepflegte Felder,
Epochengrenzen aus Migrationen, Terminart- und Karteieintrags-Kürzel, Fallzahlen,
Behandlerkürzel. Ein Muster je Befund:

### `<Tabelle>.<Feld>`

_Messung vom TT.MM.JJJJ: X von Y befüllt._

_Konsequenz für Auswertungen: …_

Die Grundmessung für „ist dieses Feld überhaupt brauchbar":

```sql
SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;
```

---

## 3 · Nicht vergessen

Prüfen Sie einmalig, ob Kürzel oder Namen aus Ihrer Praxis in den übrigen Dateien des
Skills gelandet sind — etwa wenn Sie den Skill selbst erweitert haben. Solche Angaben
gehören hierher, im Rumpf bleibt der Platzhalter. Nur dann können Sie den Skill
weitergeben, ohne ihn erneut durchsehen zu müssen.
