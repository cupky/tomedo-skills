# Query-Bausteine (v10) — Bewährte Patterns

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- v8 (2026-04-27): + § 29 Formular-Karteieintrag-Dual-Bridge, + § 32 mutabo-Detection, + § 33 PatF-Zählung-Minimal-Pattern (von SKILL→hierhin geroutet), Cleanup: Duplikat-§20–§22-Block entfernt

> Stand: 16.04.2026 · Neu ggü. v6: §20 Quartals-Segmentierung, §21 Haupttherapeut-Ermittlung, §22 Jahresübergangs-Analyse, §29 Hauptbehandler via 30700-Häufigkeit, §30 No-Show-Basistabelle, §31 EBM-Euro pro Terminart.

## 1. EBM-Euro-Berechnung (mit Gültigkeits-JOIN)

```sql
LEFT JOIN ebmKatalogEintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
```

Euro-Berechnung:
```sql
(CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
      THEN (A.anzahl * DET.euroWertInCent) / 100.0
      ELSE (A.anzahl * A.prozentDerLeistung5013 * DET.euroWertInCent) / 10000.00
END)::numeric::money AS euro
```

Punktwert-Berechnung:
```sql
CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
     THEN A.anzahl * DET.punktwert
     ELSE (A.anzahl * A.prozentDerLeistung5013 * DET.punktwert) / 100.00
END AS punkte
```

Bei GROUP BY A.ident: `max(...)` um alle Werte wrappen (wegen möglicher Duplikate bei Details).

## 2. GOÄ-Euro-Berechnung (vereinfacht, ohne MwSt)

```sql
(A.kostenInCent * A.anzahl / 100.00)::numeric::money AS euro
```

Mit Teilleistungs-Divisor:
```sql
(A.kostenInCent * A.anzahl / GREATEST(COALESCE(A.anzahlNenner, 1.0), 1) / 100.00)::numeric::money AS euro
```

Besondere Kosten (bei typ=5):
```sql
(CASE WHEN B.typ = 5 THEN (A.anzahl * B.besonderekostenincent / 100.00) ELSE 0 END)::numeric::money AS besondere_kosten
```

## 3. Privatrechnungs-Standardfilter

```sql
WHERE
    A.dtype = 'GOAELeistung'
    AND I.visible = true
    AND A.visible = true
    AND COALESCE(PT.iskostenvoranschlag, false) = false
    AND NOT EXISTS (SELECT 1 FROM privatrechnungvorlage V WHERE V.vorlage_ident = I.ident)
```

⚠ **NULL-Sicherheit (Korrektur 2026-07):** `PT.iskostenvoranschlag = false` verliert alle Zeilen mit NULL
(kein Privatrechnungstyp gesetzt), und `NOT IN (subquery)` wird bei einem einzigen NULL in der Subquery
komplett unwahr — Ergebnis dann leer. Daher `COALESCE(...) = false` und `NOT EXISTS`. Der `privatrechnungtyp`
wird per `LEFT JOIN` angebunden: `LEFT JOIN privatrechnungtyp PT ON PT.ident = I.privatrechnungtyp_ident`.

## 4. EBM-Standardfilter

```sql
WHERE
    A.dtype = 'EBMLeistung'
    AND S.visible = true
    AND A.visible = true
    AND (S.ignoriertFuerAbrechnung IS NULL OR S.ignoriertFuerAbrechnung = false)
```

## 5. Termin-Dauer berechnen

```sql
ROUND((EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 3600.0)::numeric, 2) AS stunden
ROUND((EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 60.0)::numeric, 0) AS dauer_in_min
```
**Wichtig:** `ROUND(double precision, integer)` existiert in PostgreSQL nicht. Immer `::numeric` casten vor `ROUND()`.

## 6. Termin-Standardfilter

```sql
WHERE TA.infotermin = false
  AND (T.removed IS NULL OR T.removed = false)
```
**Hinweis:** `infotermin = false` filtert auf Patiententermine. `infotermin = true` sind Ressourcen/Kapazitätsblöcke (siehe §18).
**Hinweis:** Terminart-Kürzel haben teils trailing Spaces → bei Vergleichen immer `TRIM(TA.kuerzel)` verwenden.

## 7. Aktive Dauerdiagnosen

```sql
WHERE A.isddi = true
  AND A.visible = true
  AND (A.abgesetzt IS NULL OR A.abgesetzt < 1)
```

## 8. Karteieintragtyp-Lookup per Kürzel

```sql
ke.karteieintragtyp_ident = (SELECT ident FROM karteieintragtyp WHERE kuerzel = 'BES')
```

## 9. Zeitfenster-Aggregation (Umsatz pro Periode)

```sql
DROP TABLE IF EXISTS tempZeitfenster;
CREATE TEMP TABLE tempZeitfenster AS
SELECT DISTINCT date_trunc('month', datum) AS zeitfenster FROM tempLeistung;

DROP TABLE IF EXISTS tempSummen;
CREATE TEMP TABLE tempSummen AS
SELECT date_trunc('month', datum) AS zeitfenster, SUM(euro) AS summe
FROM tempLeistung
GROUP BY zeitfenster;

SELECT
    to_char(Z.zeitfenster, 'YYYY-MM') AS intervall,
    CAST(Z.zeitfenster AS date) AS startdatum,
    COALESCE(S.summe, '0'::numeric::money) AS summe
FROM tempZeitfenster Z
LEFT JOIN tempSummen S ON Z.zeitfenster = S.zeitfenster
ORDER BY startdatum;
```

## 10. NULL-sichere Vorfilterung (COALESCE-Pattern)

```sql
DROP TABLE IF EXISTS temp_nutzer;
CREATE TEMP TABLE temp_nutzer AS SELECT * FROM nutzer;
INSERT INTO temp_nutzer (ident) VALUES (0);

WHERE COALESCE(A.betriebsstaette_ident, 0) IN (SELECT ident FROM temp_betriebsstaette WHERE true)
```

## 11. Quartals-Berechnung aus Datum

```sql
CAST(to_char(datum, 'Q') AS integer) AS quartal
CAST(to_char(datum, 'YYYY') AS integer) AS jahr
to_char(datum, 'Q/YYYY') AS quartal_text
```

## 12. Arzt-Ermittlung bei Verordnungen (Fallback-Kette)

```sql
COALESCE(N3.kuerzel, N.kuerzel, N2.kuerzel) AS arzt
-- N3 = abweichender Verordner
-- N  = Arzt vom Karteieintrag
-- N2 = Arzt vom eRezept
```

## 13. ATC-Level-Parsing (Medikamente)

```sql
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 1) AS ATC_Level_1
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 3) AS ATC_Level_2
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 4) AS ATC_Level_3
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 5) AS ATC_Level_4
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 7) AS ATC_Level_5
```

## 14. IN/NOT IN für Mengenvergleiche

Pattern "hat X aber nicht Y":
```sql
WHERE P.ident IN (
    SELECT P.ident FROM karteieintrag ke
    JOIN patientendetailsrelationen_karteieintraege pdrke ON pdrke.karteieintraege_ident = ke.ident
    JOIN patientendetails pd ON pd.patientendetailsrelationen_ident = pdrke.patientendetailsrelationen_ident
    JOIN patient p ON p.patientendetails_ident = pd.ident
    WHERE ...
    GROUP BY P.ident
)
AND NOT P.ident IN (
    SELECT P.ident FROM ...
    WHERE ke.karteieintragtyp_ident = (SELECT ident FROM karteieintragtyp WHERE kuerzel = 'BES')
    GROUP BY P.ident
)
```

## 15. Empfänger-Aggregation (Nachrichten)

```sql
DROP TABLE IF EXISTS tempEmpfaenger;
CREATE TEMPORARY TABLE tempEmpfaenger AS
SELECT A.nachrichten_ident,
       ARRAY_TO_STRING(array_agg(ARRAY_TO_STRING(ARRAY[D.kuerzel, E.name], ' ')), ' ') AS empfaenger
FROM tempNachrichten A
JOIN Nachricht_empfaenger B ON A.nachrichten_ident = B.nachricht_ident
LEFT JOIN Nachrichtempfaenger C ON B.empfaenger_ident = C.ident
LEFT JOIN Nutzer D ON C.nutzer_ident = D.ident
LEFT JOIN Arbeitsplatz E ON C.arbeitsplatz_ident = E.ident
GROUP BY A.nachrichten_ident;
```

## 16. Selektivverträge eines Patienten aggregieren

```sql
DROP TABLE IF EXISTS tempSV;
CREATE TEMPORARY TABLE tempSV AS
SELECT A.patientID,
       ARRAY_TO_STRING(ARRAY_AGG(A.name), '; ') AS vertraege
FROM (
    SELECT HZVV.name, P.ident AS patientID
    FROM patient P
    JOIN patientendetails PD ON PD.ident = P.patientendetails_ident
    JOIN patientendetails_hzvDetails JT ON PD.ident = JT.patientendetails_ident
    JOIN hzvdetails HZVD ON JT.hzvdetails_ident = HZVD.ident
    LEFT JOIN hzvvertrag HZVV ON HZVD.hzvvertrag_ident = HZVV.ident
    WHERE HZVD.statusteilnahme = 2
      AND ((HZVD.statusFAVDirektaktivierung != 4 AND HZVD.statusFAVDirektaktivierung != 5)
           OR HZVD.statusFAVDirektaktivierung IS NULL)
    UNION ALL
    SELECT V.name, P.ident AS patientID
    FROM patient P
    JOIN patientendetails PD ON PD.ident = P.patientendetails_ident
    JOIN patientendetails_sonstigeSVTeilnahmen JT ON JT.patientendetails_ident = PD.ident
    JOIN svteilnahme T ON JT.sonstigeSVTeilnahmen_ident = T.ident
    LEFT JOIN selektivvertrag V ON V.ident = T.selektivvertrag_ident
    WHERE T.status = 2
) A
GROUP BY A.patientID;
```

## 17. Gesperrte Tage erkennen (Sperrzeiten)

Sperrzeiten sind Termine mit `infotermin=false`, `patient_ident IS NULL` und bestimmten Terminarten. Ein Tag gilt als gesperrt bei Dauer ≥300 Minuten.

```sql
DROP TABLE IF EXISTS tempGesperrteTage;
CREATE TEMPORARY TABLE tempGesperrteTage AS
SELECT DISTINCT
    kalenderID,
    tag
FROM tempTermine
WHERE infotermin = false
    AND patient_ident IS NULL
    AND terminart_kuerzel IN ('UNBEKANNT', 'Blocker', 'IMPORT_GANZTAG', 'Urlaub', 'Ü-Abbau')
    AND dauer_min >= 300
;
```

Anwendung: Per `LEFT JOIN` und `IS NULL` gesperrte Tage aus Kapazitätsberechnung ausschließen:
```sql
FROM tempTermine A
LEFT JOIN tempGesperrteTage G ON A.kalenderID = G.kalenderID AND A.tag = G.tag
WHERE ...
    AND G.kalenderID IS NULL
```

Zwei Varianten, je nach Epoche. **Variante A ist ab Migration (Nov 2025) die Leitquelle.**

### Variante A (Primaer, ab Migration) — terminkalendertag

```sql
DROP TABLE IF EXISTS tempGesperrteTage;
CREATE TEMPORARY TABLE tempGesperrteTage AS
SELECT
    TKT.kalender_ident      AS kalenderID,
    TKT.tag::date           AS tag,
    KSM.name                AS sperrgrund,
    KSM.isfeiertag          AS ist_feiertag
FROM terminkalendertag TKT
JOIN kalendersperrmodus KSM ON KSM.ident = TKT.kalendersperrmodus_ident
WHERE TKT.removed = false
    AND TKT.sperrmodus = 1          -- PFLICHT: Tabelle enthaelt auch freie Tage
;
```

`TKT.beginn IS NULL` = Ganztags-Sperre (Normalfall). Gefuellte `beginn`/`ende` = Teilsperre → Zeitueberlappung pruefen statt Tagesgleichheit.

### Variante B (Alt-Pfad, Pre-Migration) — Blocker-Termine

```sql
SELECT DISTINCT kalenderID, tag
FROM tempTermine
WHERE infotermin = false
    AND patient_ident IS NULL
    AND terminart_kuerzel IN ('UNBEKANNT','Blocker','IMPORT_GANZTAG','Urlaub','Ü-Abbau')
    AND dauer_min >= 300
;
```

### Anwendung: gesperrte Tage aus der Kapazitaet ausschliessen

```sql
FROM tempTermine A
LEFT JOIN tempGesperrteTage G ON A.kalenderID = G.kalenderID AND A.tag = G.tag
WHERE ...
    AND G.kalenderID IS NULL
```

### §17a — Konflikt: Sperrtag UND Patiententermin

Umkehrung des LEFT JOIN. tomedo raeumt bestehende Termine beim Sperren **nicht** auf, Serientermine bleiben stehen. Ein `INNER JOIN` statt Ausschluss liefert die Aufraeumliste:

```sql
SELECT
    TKT.tag::date                                       AS sperrtag,
    K.name                                              AS kalender,
    TRIM(N.kuerzel)                                     AS nutzer_kuerzel,
    KSM.name                                            AS sperrgrund,
    KSM.isfeiertag                                      AS ist_feiertag,
    T.ident                                             AS terminID,
    T.beginn                                            AS termin_beginn,
    (EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 60)::int  AS dauer_min,
    TRIM(TA.kuerzel)                                    AS terminart,
    T.patient_ident                                     AS patientID
FROM terminkalendertag TKT
JOIN kalender           K   ON K.ident   = TKT.kalender_ident
JOIN kalendersperrmodus KSM ON KSM.ident = TKT.kalendersperrmodus_ident
LEFT JOIN nutzer        N   ON N.ident   = K.nutzer_ident
JOIN termin_kalender    TK  ON TK.kalender_ident = K.ident
JOIN termin             T   ON T.ident   = TK.termin_ident
JOIN terminart          TA  ON TA.ident  = T.terminart_ident
WHERE TKT.removed   = false
    AND TKT.sperrmodus = 1
    AND T.removed     = false
    AND T.patient_ident IS NOT NULL     -- nur echter Patientenbezug
    AND TA.infotermin = false           -- keine Ressourcenbloecke
    AND T.beginn::date = TKT.tag::date
    AND TKT.tag >= CURRENT_DATE         -- nur offene Konflikte
    AND K.visible = true
    AND K.name NOT ILIKE 'Outlook%'
ORDER BY TKT.tag, K.name, T.beginn;
```

Kein CTE, keine Aggregation → direkt Metabase-faehig, 1 Zeile pro Konflikt-Termin.

**Falsch-Positiv-Filter:** `dauer_min = 1` sind Gruppen-1-Min-Slots (Gruppen-Workaround), kein Einzelkonflikt → `AND (EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 60) > 1`.

**Falsch-Positiv-Filter (Q-KAL-01, Erstlauf 07/2026):** Treffer mit `dauer_min = 1` sind Gruppen-Slot-Header aus
dem Raumkalender-Workaround, keine echten Patiententermine — ausschließen. Hauptursache echter Konflikte sind
**Serientermine**, die beim Sperren stehen bleiben (20 offene Fälle im Erstlauf). Siehe ADR-KAL-01.

### §17b — Sperrtage tagweise je Person (Metabase-Kontrakt)

Dritter Anwendungsfall: **Export an ein lesendes Programm**, das gegen eine externe Abwesenheitsliste
vergleicht. Eine Zeile je Mitarbeiter und gesperrtem Tag, keine Aggregation, keine Zeitraumbildung.

```sql
SELECT
    n.kuerzel                AS zeitkonto_kuerzel,
    ksm.name                 AS sperrgrund,
    tkt.tag::date            AS tag
FROM terminkalendertag tkt
JOIN kalender k                  ON k.ident = tkt.kalender_ident
JOIN nutzer n                    ON n.ident = k.nutzer_ident
LEFT JOIN kalendersperrmodus ksm ON ksm.ident = tkt.kalendersperrmodus_ident
WHERE tkt.sperrmodus = 1
  AND COALESCE(tkt.removed, false) = false
  AND tkt.beginn IS NULL
  AND tkt.ende   IS NULL
  AND tkt.tag::date >= CURRENT_DATE
ORDER BY n.kuerzel, tkt.tag::date
```

Vier bewusste Abweichungen von Variante A, jede mit Grund:

- **`LEFT JOIN kalendersperrmodus`** statt INNER. Bei `sperrmodus = 1` ist der Grund heute immer
  gesetzt, der INNER JOIN von Variante A ist also faktisch aequivalent — aber er *ist* ein Filter auf
  den Sperrgrund. Wenn die Frage „ist dieser Tag ueberhaupt gesperrt" lautet, darf eine Sperre ohne
  Grund nicht verschluckt werden.
- **`JOIN nutzer`** statt `LEFT JOIN`. Kalender ohne `nutzer_ident` (Raum-/Sammelkalender) haben kein
  Kuerzel und sind keiner Person zuordenbar; im Personenvergleich erzeugen sie nur Rauschen.
  Groessenordnung 08/2026: 7 von 374 Sperrzeilen.
- **`COALESCE(tkt.removed, false) = false`** statt `removed = false`. NULL-sicher; bei einer
  gemessenen Nullmenge an `removed`-Zeilen sonst nicht unterscheidbar, ob der Filter greift oder das
  Feld leer ist.
- **`tag::date` auch in der Ausgabe**, nicht nur im Vergleich — `tag` ist `timestamp`.

**Kein `DISTINCT`.** Geprueft: 374 Sperrzeilen = 374 verschiedene `(kalender_ident, tag)`; die Tabelle
fuehrt faktisch eine Zeile je Kalender und Tag.

**Tagweise, nicht als Zeitraum.** Tage zu Zeitraeumen zu verketten verschmilzt zwei aneinandergrenzende
Abwesenheiten zu einer und erfindet damit eine Abweichung. Der Vergleich loest umgekehrt auf: das Soll
wird in Tage zerlegt (ADR-KAL-02).

**Regressionsanker anlegen, bevor die Query produktiv geht.** Notieren Sie einmalig
Zeilenzahl, Zahl der Mitarbeiter und Zahl der Sperrgruende im gewaehlten Fenster, dazu die
Randfaelle: Kalender ohne Nutzer, als entfernt markierte Zeilen, Teilsperren. Weicht ein
spaeterer Lauf ab, sehen Sie es an diesen Zahlen — und nur an ihnen.

> ⚠️ **Keine Einzelzeilen kopieren**, nicht in Terminal, Chat oder Ticket. Das Ergebnis traegt
> Mitarbeiterkuerzel und Abwesenheitstage. Schon die Aufschluesselung je Sperrgrund ist
> heikel: ein Grund mit vielen Tagen bei **einem** Mitarbeiter benennt diese Person. Die
> eigenen Ankerwerte gehoeren nach `references/praxis-interna.md`.

## 18. Auslastungsberechnung (Kapazität vs. Belegung)

**Formel:** Auslastung = Belegung / Netto-Kapazität × 100

- **Kapazität** = `infotermin=true`, exkl. Nicht-Patientenzeit. Die Kuerzelliste ist **je Installation verschieden** — die eigene aus `terminart` ziehen und in `references/praxis-interna.md` festhalten. Beispielhafte Liste: `Doku, Pau, Pause, Urlaub, Org, Test` plus alle mit einem gemeinsamen Besprechungs-Praefix. Praefixpruefung **ohne Wildcard**: `LEFT(TRIM(kuerzel),5) = 'Bespr'` — `ILIKE 'Bespr…'` mit Prozentzeichen bricht in der Ausfuehrung ab (Abgabecheck-Regel 1).
- **Belegung** = `infotermin=false` mit `patient_ident IS NOT NULL`
- **Netto-Kapazität** = Kapazität abzgl. gesperrte Tage (siehe §17)

Nicht-Patientenzeit-Ausschluss:
```sql
WHERE A.infotermin = true
    -- eigene Kuerzel einsetzen, siehe praxis-interna.md
    AND TRIM(A.terminart_kuerzel) NOT IN ('Doku', 'Pau', 'Pause', 'Urlaub', 'Org', 'Test')
    AND LEFT(TRIM(A.terminart_kuerzel),5) <> 'Bespr'
```
**Ausnahme pruefen:** Sammelterminarten, die Patienten- **und** Teamzeit tragen, gehoeren
**nicht** in die Ausschlussliste — sonst verschwindet echte Patientenzeit aus der Kapazitaet.
Erkennung siehe `enums-und-funktionen.md`, Abschnitt Nicht-Patientenzeit.

## 19. Therapeut-Ermittlung bei Terminen

```sql
COALESCE(T.behandler, KN.kuerzel) AS therapeut
```
Wobei `KN` der Nutzer des Kalenders ist (Fallback wenn `behandler` leer).

## 20. Jahresscharfer Diagnose-JOIN (Pflicht bei Jahresvergleichen)

**Problem:** Wenn Diagnosen ohne Jahresfilter auf die Patientenpopulation gejoint werden, können Patienten eines Jahres Diagnosen aus anderen Jahren beitragen → Prozente >100%.

**Falsch (>100%-Bug):**
```sql
WHERE P.ident IN (SELECT patientID FROM tempPat30700)
```

**Richtig:**
```sql
JOIN tempPat30700 T ON T.patientID = P.ident AND T.jahr = S.jahr
```

Immer wenn `tempPat30700` eine `jahr`-Spalte hat, muss der JOIN auf **beide** Spalten (patientID + jahr) erfolgen.

## 21. 2-Stufen EBM-Euro-Aggregation

**Problem:** `MAX(DET.euroWertInCent)` innerhalb von `SUM()` funktioniert nicht in einer einzigen Aggregationsstufe, weil die Details-Tabelle über eine Bridge gejoint wird und Duplikate erzeugen kann.

**Pattern:**
```sql
-- Stufe 1: Euro pro Leistung (GROUP BY A.ident)
DROP TABLE IF EXISTS tempEBMperLeistung;
CREATE TEMPORARY TABLE tempEBMperLeistung AS
SELECT
    P.ident AS patientID,
    A.ident AS leistungID,
    CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
         THEN (A.anzahl * MAX(DET.euroWertInCent)) / 100.0
         ELSE (A.anzahl * A.prozentDerLeistung5013 * MAX(DET.euroWertInCent)) / 10000.00
    END AS euro
FROM leistung A
LEFT JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
JOIN kvschein S ON A.invkvschein_ident = S.ident
-- ... Patient-JOINs ...
WHERE A.dtype = 'EBMLeistung' AND A.visible = true AND S.visible = true
GROUP BY P.ident, A.ident, A.anzahl, A.prozentDerLeistung5013
;

-- Stufe 2: Aggregation pro Patient
SELECT patientID, SUM(euro) AS ebm_euro
FROM tempEBMperLeistung
GROUP BY patientID
;
```

## 22. GOÄ-Explorer (alle Codes einer Population)

**Zweck:** Explorativ alle GOÄ-Codes sichten, bevor man gezielt filtert. Vermeidet blinde Flecken.

```sql
SELECT
    G.code AS "GOÄ-Code",
    MAX(G.kurztext) AS "Bezeichnung",
    COUNT(DISTINCT P.ident) AS "Patienten",
    COUNT(*) AS "Leistungen",
    ROUND(COUNT(DISTINCT P.ident) * 100.0
        / NULLIF((SELECT COUNT(*) FROM tempPat30700), 0), 1) AS "% der Population"
FROM leistung A
JOIN goaekatalogeintrag G ON A.goaekatalogeintrag_ident = G.ident
LEFT JOIN privatrechnung_goaeleistungen J ON J.goaeleistungen_ident = A.ident
JOIN privatrechnung I ON I.ident = J.privatrechnung_ident
LEFT JOIN patient P ON P.ident = I.patient_ident
WHERE A.dtype = 'GOAELeistung'
    AND A.visible = true
    AND I.visible = true
    AND EXTRACT(YEAR FROM A.datum) = 2025
    AND P.ident IN (SELECT patientID FROM tempPat30700)
GROUP BY G.code
ORDER BY COUNT(DISTINCT P.ident) DESC
LIMIT 40
;
```

**Erkenntnis:** GOÄ 470/490/491/493/497/498 werden in der Praxis nicht verwendet. Immer erst explorieren, dann filtern.

## 23. Quartals-Segmentierung (Chroniker-Analyse)

Dynamische Erkennung auswertbarer Quartale:
```sql
SELECT LEAST(4, EXTRACT(QUARTER FROM LEAST(CURRENT_DATE, DATE '2025-12-31'))::integer) AS max_q;
```

Segmentierung mit dynamischen Labels:
```sql
CASE
    WHEN quartale_count >= max_q THEN '1_Chroniker (' || max_q || '/' || max_q || ' Q)'
    WHEN quartale_count = 1 THEN '4_Einmalig (1/' || max_q || ' Q)'
    WHEN quartale_count >= max_q - 1 THEN '2_Regelmaessig (' || (max_q - 1) || '/' || max_q || ' Q)'
    ELSE '3_Gelegentlich (' || quartale_count || '/' || max_q || ' Q)'
END AS segment
```
Sortierreihenfolge durch Nummernprefix (1_, 2_, 3_, 4_) sichergestellt.

## 24. Haupttherapeut-Ermittlung (DISTINCT ON)

Wer die meisten Karteieinträge der Therapiezeilen-Typen für einen Patienten geschrieben hat
(Kürzel praxiseigen, hier als `<TYP-A>`/`<TYP-B>`/`<TYP-C>`):
```sql
SELECT DISTINCT ON (patientID)
    patientID, therapeut
FROM (
    SELECT patientID, therapeut, COUNT(*) AS cnt
    FROM tempTherapiezeilen
    GROUP BY patientID, therapeut
) sub
ORDER BY patientID, cnt DESC
;
```
Bei Gleichstand gewinnt der alphabetisch erste (PostgreSQL-Determinismus).
DISTINCT ON ist performanter als ROW_NUMBER() für diesen Anwendungsfall.

## 25. Seltene Ereignisse je Behandler: Erwartungsband und indirekte Standardisierung

Bei Quoten je Behandler mit wenigen Ereignissen ist die rohe Quote irrefuehrend: bei einer
Basisrate von 5 Prozent und 80 Faellen je Behandler liegt die Zwei-Sigma-Streuung bei etwa
plus/minus 5 Prozentpunkten. Zwei Bausteine dagegen.

**Zufallsband auf der Rohquote** (Binomial, je Behandler mit dessen eigenem Nenner):

```sql
ROUND(100.0 * (PRX.basisrate - 2.0 * sqrt(PRX.basisrate * (1.0 - PRX.basisrate)
      / JA.nenner::numeric)), 1) AS band_unten,
CASE WHEN JA.ereignisse::numeric / JA.nenner::numeric
          > PRX.basisrate + 2.0 * sqrt(PRX.basisrate * (1.0 - PRX.basisrate)
            / JA.nenner::numeric) THEN 'ueber Band' ELSE 'im Band' END AS bewertung
```

**Indirekte Standardisierung** gegen einen Confounder (Alter, Diagnosetyp): praxisweite
Schichtraten auf den Mix des Behandlers anwenden, Kennzahl ist beobachtet zu erwartet.

```sql
rate AS (SELECT schicht, SUM(ev)::numeric / COUNT(*)::numeric AS r
         FROM basis GROUP BY schicht),
erw  AS (SELECT B.behandler, SUM(R.r) AS erwartet
         FROM basis B JOIN rate R ON R.schicht = B.schicht
         GROUP BY B.behandler)
-- Verhaeltnis und Poisson-Band:
--   beobachtet / erwartet ; auffaellig wenn beobachtet > erwartet + 2 * sqrt(erwartet)
```

Warum indirekt und nicht direkt: die direkte Standardisierung braucht behandlerspezifische
Schichtraten. Bei ein bis drei Ereignissen je Zelle rechnet sie Einzelfaelle hoch und erzeugt mehr
Rauschen als sie Verzerrung entfernt. Die standardisierte Quote ist dann Basisrate mal Verhaeltnis.

**Mehrfachvergleich mitdenken:** bei zehn parallel geprueften Behandlern und einseitigem
Zwei-Sigma-Kriterium ist eine einzelne Ueberschreitung mit rund 20 Prozent Wahrscheinlichkeit
Zufall. Erst zwei gleichzeitige Ueberschreitungen oder eine Ueberschreitung auf zwei unabhaengigen
Adjustierungsachsen sind ein Befund.

## 25. Jahresübergangs-Analyse (Kohortenvergleich)

Pattern: Patienten eines Jahres mit Segmentierung in beiden Jahren vergleichen.
Basis: tempPQ2024 (Quartale Jahr 1), tempPQ2025 (Quartale Jahr 2), LEFT JOIN.
`COALESCE(q2025, 0) = 0 → '5_Weg'` für abgewanderte Patienten.
Sortierung: Abwanderung % DESC zeigt Problemsegmente zuerst.

## 26. Wiedervorstellungs-Logik (30700-Tag als Anker)

**Pattern:** 30700-Tag = Erstkontakt im Quartal. Alle anderen Leistungstage = Wiedervorstellung.
```sql
-- Ankertag
MIN(CAST(A.datum AS date)) AS tag_30700  -- pro Patient×Quartal
-- Klassifikation
CASE WHEN E.leistungstag = D.tag_30700 THEN 'Beileistung' ELSE 'WV' END
```
**Bestätigte Beileistungen:** 30704 (99,7% am 30700-Tag). 30702 implizit.
**Administrativ (kein Kontakt):** 40110 (Versandmaterial), 86901 (Labor-Kosten).

## 27. GOÄ-Quartal-Ableitung

GOÄ-Leistungen haben kein `kvschein.quartal`. Quartal wird aus Datum abgeleitet:
```sql
CAST(to_char(A.datum, 'Q') AS integer) AS quartal
```

---

## 28. Patientenliste als Filter (Panel → Patientenliste)

Lädt alle Patienten einer manuell angelegten Liste aus dem Panel → Patientenliste-Feature in eine Temp-Tabelle zur Weiterverarbeitung.

```sql
DROP TABLE IF EXISTS tempListePat;
CREATE TEMPORARY TABLE tempListePat AS
SELECT DISTINCT
    PSE.patient_ident AS patientID
FROM patientenschlange PS
JOIN patientenschlange_schlange PSS 
    ON PS.ident = PSS.patientenschlange_ident
JOIN patientenschlangeelement PSE 
    ON PSS.schlange_ident = PSE.ident
WHERE PS.removed = false
  AND PSE.removed = false
  AND PS.dtype = 'Patientenschlange'
  AND PS.name = 'DEIN_LISTENNAME'   -- ← anpassen
;

-- Weiterverarbeitung in beliebigem Query:
-- WHERE P.ident IN (SELECT patientID FROM tempListePat)
```

**Variante mit Kommentar:**
```sql
DROP TABLE IF EXISTS tempListePat;
CREATE TEMPORARY TABLE tempListePat AS
SELECT DISTINCT
    PSE.patient_ident AS patientID,
    PSE.infotext      AS kommentar,
    PSE.checked        AS abgehakt,
    PSE.datum::date    AS hinzugefuegt_am
FROM patientenschlange PS
JOIN patientenschlange_schlange PSS 
    ON PS.ident = PSS.patientenschlange_ident
JOIN patientenschlangeelement PSE 
    ON PSS.schlange_ident = PSE.ident
WHERE PS.removed = false
  AND PSE.removed = false
  AND PS.dtype = 'Patientenschlange'
  AND PS.name = 'DEIN_LISTENNAME'   -- ← anpassen
;
```

**Explorer: Alle Listen mit Patientenzahl anzeigen:**
```sql
SELECT
    PS.name                           AS "Listenname",
    PS.dtype                          AS "Typ",
    COUNT(DISTINCT PSE.patient_ident) AS "Anzahl Pat"
FROM patientenschlange PS
LEFT JOIN patientenschlange_schlange PSS 
    ON PS.ident = PSS.patientenschlange_ident
LEFT JOIN patientenschlangeelement PSE 
    ON PSS.schlange_ident = PSE.ident
    AND PSE.removed = false
WHERE PS.removed = false
GROUP BY PS.name, PS.dtype
ORDER BY PS.name
;
```

## 29. Hauptbehandler via EBM-30700-Häufigkeit

Ermittelt pro Patient den Arzt mit den meisten EBM 30700 als Hauptbehandler. Robuster als `PD.arzt_ident` (Praxisinhaber-Bias).

```sql
DROP TABLE IF EXISTS temp30700ProArzt;
CREATE TEMPORARY TABLE temp30700ProArzt AS
SELECT
    P.ident                         AS patientID,
    A.leistungserbringer_ident      AS arzt_ident,
    COUNT(*)                        AS anz_30700
FROM leistung A
JOIN ebmkatalogeintrag B    ON A.ebmkatalogeintrag_ident = B.ident
JOIN kvschein S             ON A.invkvschein_ident = S.ident
JOIN patientendetailsrelationen_kvscheine PDRK
                            ON S.ident = PDRK.kvscheine_ident
LEFT JOIN patientendetails PD
                            ON PD.patientendetailsrelationen_ident = PDRK.patientendetailsrelationen_ident
LEFT JOIN patient P         ON P.patientendetails_ident = PD.ident
WHERE A.dtype = 'EBMLeistung'
  AND A.visible = true AND S.visible = true
  AND B.code = '30700'
  AND S.jahr >= 2024   -- Zeitraum anpassen
  AND P.nachname NOT ILIKE '%†'
GROUP BY P.ident, A.leistungserbringer_ident;

DROP TABLE IF EXISTS tempHauptbehandler;
CREATE TEMPORARY TABLE tempHauptbehandler AS
SELECT DISTINCT ON (patientID)
    patientID, arzt_ident, anz_30700
FROM temp30700ProArzt
ORDER BY patientID, anz_30700 DESC, arzt_ident ASC;
```

**Anwendung:** JOIN auf `tempHauptbehandler HB` + `nutzer N ON HB.arzt_ident = N.ident` für Arzt-Kürzel.

---

## 30. No-Show-Basistabelle (Termin-Level mit Therapeut und Alter)

Alle vergangenen Patiententermine mit Therapeut, Altersgruppe und warda-Flag. Nur Therapeuten-Kalender (Outlook-Schatten raus), nur echte Patiententermine.

```sql
DROP TABLE IF EXISTS tempNS_Termine;
CREATE TEMPORARY TABLE tempNS_Termine AS
SELECT
    T.ident                  AS terminID,
    T.patient_ident          AS patientID,
    T.beginn,
    CAST(T.beginn AS date)   AS tag,
    TRIM(TA.kuerzel)         AS terminart,
    COALESCE(T.behandler, KN.kuerzel) AS therapeut,
    T.warda,
    EXTRACT(YEAR FROM AGE(T.beginn, P.geburtsdatum))::integer AS alter_jahre,
    CASE WHEN EXTRACT(YEAR FROM AGE(T.beginn, P.geburtsdatum))::integer <= 67
         THEN 'Erwerbsfähig' ELSE 'Rentner' END AS altersgruppe
FROM termin T
JOIN terminart TA       ON T.terminart_ident = TA.ident
JOIN patient P          ON P.ident = T.patient_ident
LEFT JOIN termin_kalender TK ON TK.termin_ident = T.ident
LEFT JOIN kalender K        ON K.ident = TK.kalender_ident
LEFT JOIN nutzer KN         ON KN.ident = K.nutzer_ident
WHERE TA.infotermin = false
    AND T.patient_ident IS NOT NULL
    AND (T.removed IS NULL OR T.removed = false)
    AND T.beginn >= '2025-11-01'
    AND T.beginn < CURRENT_DATE
    AND P.nachname NOT ILIKE '%†'
    AND K.nutzer_ident IS NOT NULL    -- nur Therapeuten-Kalender
;
```

**Hinweis:** Therapeuten-Kalender-Filter (`K.nutzer_ident IS NOT NULL`) schließt Outlook-Schattenkalender und Raumkalender aus. Für Gruppen-Analysen Raumkalender separat einbeziehen.

**Stufe 1 (warda-basiert):** auf `tempNS_Termine` nach Therapeuten-Whitelist filtern (siehe SKILL §No-Show: Zwei-Stufen-Modell).

---

## 31. EBM-Euro pro Terminart (über Abrechnungsdaten)

## 32. mutabo-Rückschrieb-Detection (zweigleisig)

Das mutabo-Alt-System (pre-11/2025) hat drei Epochen mit unterschiedlichen Markern. Robuste Detection kombiniert Marker-Match (Phase A/B) und Syntax-Match (Phase C). `<FRAGEBOGEN-DOMAENE>` ist die Domäne des Alt-Systems — Auflösung in `praxis-interna.md` §1, im Regex mit escapten Punkten einsetzen:

```sql
-- Klassifikations-Flag pro Karteieintrag
CASE
  -- Phase A + B: explizite Marker
  WHEN ke.text ~ 'XD:MUTABO\.'           THEN 'mutabo_marker'
  -- <FRAGEBOGEN-DOMAENE> regex-escapt einsetzen, siehe praxis-interna.md §1
  WHEN ke.text ~ '<FRAGEBOGEN-DOMAENE>'
    AND kt.kuerzel NOT IN ('DOK','MAIL-Ein','MAIL-Aus')  -- E-Mail-FP ausschließen
                                         THEN 'mutabo_url'
  -- Phase C: Kurzform-Syntax (PSY + kurz + Korff-Score oder MFH-Score-Kopf)
  WHEN kt.kuerzel = 'PSY'
    AND LENGTH(COALESCE(ke.text,'')) < 50
    AND (ke.text ~* 'Korff\s+[0-9]+\.[0-9]+'
      OR ke.text ~* '^MFHW?\s*[-0-9]')  THEN 'mutabo_kurzform'
  -- MPSS-Zeile (separate Zeile pro Rückschrieb-Set)
  WHEN kt.kuerzel = 'PSY'
    AND LENGTH(COALESCE(ke.text,'')) < 40
    AND ke.text ~* '^MPSS\s+([0-9]|[IVX]+|Gesamtstadium)'
                                         THEN 'mutabo_mpss'
  ELSE NULL
END AS mutabo_klass
```

**Header-Identifikation für Set-Aggregation** (nur Phase A + B):
```sql
ke.text ~* '(Schmerz|Quartals)fragebogen abgeschlossen'
```
Phase C hat keinen Header — Sets dort werden nur über Patient + Kalendertag + `mutabo_klass IS NOT NULL` zusammengefasst.

**Volumen-Kalibrierung:** 
- Phase-A-Header: ~Einzel-Dutzend pro Patient, 2022
- Phase-B-Header: ~Einzelstück pro Patient, 11–12/2022
- Phase-C-Einträge: Hauptvolumen, ~4/Jahr pro Stammpatient (Quartalstakt)

Wenn `terminart_ebmleistungen` leer ist, Euro-Wert über tatsächliche Abrechnungen ableiten (Patient × Tag-Matching). Alle 3 Blöcke (2× CREATE + SELECT) müssen in **einem** Batch ausgeführt werden — Temp-Tables überleben nicht zwischen Runs.

```sql
-- Temp 1: Patiententermine
DROP TABLE IF EXISTS tempTerminLeistung;
CREATE TEMPORARY TABLE tempTerminLeistung AS
SELECT T.ident AS termin_id, T.patient_ident,
    TRIM(TA.kuerzel) AS terminart, CAST(T.beginn AS date) AS termin_tag,
    COALESCE(T.behandler, N.kuerzel) AS therapeut
FROM termin T
JOIN termin_kalender TK ON T.ident = TK.termin_ident
JOIN kalender K ON TK.kalender_ident = K.ident
LEFT JOIN nutzer N ON K.nutzer_ident = N.ident
JOIN terminart TA ON T.terminart_ident = TA.ident
WHERE (T.removed IS NULL OR T.removed = false)
    AND TA.infotermin = false AND T.patient_ident IS NOT NULL
    AND K.nutzer_ident IS NOT NULL;

-- Temp 2: EBM-Leistungen (Pfad über kvschein!)
DROP TABLE IF EXISTS tempEBMperTag;
CREATE TEMPORARY TABLE tempEBMperTag AS
SELECT S.patient_ident, CAST(A.datum AS date) AS leistungs_tag,
    B.code AS ebm_code, A.ident AS leistung_id,
    CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
         THEN (A.anzahl * MAX(DET.euroWertInCent)) / 100.0
         ELSE (A.anzahl * A.prozentDerLeistung5013 * MAX(DET.euroWertInCent)) / 10000.00
    END AS euro
FROM leistung A
JOIN kvschein S ON A.invkvschein_ident = S.ident
JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum))
WHERE A.dtype = 'EBMLeistung' AND A.visible = true AND S.visible = true
GROUP BY S.patient_ident, CAST(A.datum AS date), B.code, A.ident, A.anzahl, A.prozentDerLeistung5013;

-- Ergebnis: Euro pro Terminart
SELECT TL.terminart,
    COUNT(DISTINCT TL.termin_id) AS termine,
    ROUND((SUM(COALESCE(E.euro, 0)) / NULLIF(COUNT(DISTINCT TL.termin_id), 0))::numeric, 2) AS euro_pro_termin
FROM tempTerminLeistung TL
LEFT JOIN tempEBMperTag E ON TL.patient_ident = E.patient_ident AND TL.termin_tag = E.leistungs_tag
GROUP BY TL.terminart HAVING COUNT(DISTINCT TL.termin_id) >= 5
ORDER BY euro_pro_termin DESC NULLS LAST;
```

**Verknüpfungslogik:** Patient×Tag-Match — alle EBM-Leistungen eines Patienten am Termintag werden dem Termin zugeordnet. Bei mehreren Terminen am gleichen Tag gibt es Doppelzählungen (an der Referenzinstallation valide, weil Tagesklinik-Charakter selten).

## §29 — Formular-Karteieintrag via Dual-Bridge (Patient-Einstieg)

Für Karteieinträge mit `dtype='Formular'` funktioniert der Standard-Pfad über
`_karteieintraege` nicht — beide Bridges müssen gejoint und per `GREATEST`
kombiniert werden.

```sql
FROM karteieintrag ke
  LEFT JOIN patientendetailsrelationen_karteieintraege pdrk
         ON pdrk.karteieintraege_ident = ke.ident
  LEFT JOIN patientendetailsrelationen_formulare pdrf
         ON pdrf.formulare_ident = ke.ident
  LEFT JOIN patientendetails pd
         ON pd.patientendetailsrelationen_ident = GREATEST(
              pdrk.patientendetailsrelationen_ident,
              pdrf.patientendetailsrelationen_ident)
  JOIN patient p ON p.patientendetails_ident = pd.ident
WHERE p.ident = :patientId
  AND ke.dtype = 'Formular'
```

Für die Rohantworten zusätzlich:

```sql
JOIN karteieintrag_formularelemente kfe ON kfe.karteieintrag_ident = ke.ident
JOIN formularelement fe                  ON fe.ident = kfe.formularelemente_ident
-- fe.bezeichner, fe.jsonformkey, fe.wert, fe.listenpos
```

Session-Beleg: 21.04.2026, Patient 32385.

## 37. Leistungs-Codes mit Menge (xN) in STRING_AGG

**Problem:** `STRING_AGG(DISTINCT B.code, '; ')` kollabiert Mehrfachabrechnungen
(z.B. 30708 2× am Tag bei Wiedervorstellung im selben Quartal) zu einem einzigen
Code-Eintrag — die Menge geht verloren.

**Lösung:** Zweistufige Aggregation. Stufe 1 summiert `leistung.anzahl`
(Feld 5005, KV-Multiplikator) pro Patient und Code; Stufe 2 hängt die Menge
nur an, wenn sie > 1 ist.

```sql
SELECT
    pc.patientID,
    STRING_AGG(
        pc.code || CASE WHEN pc.menge > 1 THEN 'x' || pc.menge ELSE '' END,
        '; ' ORDER BY pc.code
    ) AS codes
FROM (
    SELECT P.ident AS patientID, B.code AS code, SUM(A.anzahl) AS menge
    FROM leistung A
    JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
    -- ... Standard-Patientenpfad über kvschein + WHERE dtype/visible/datum ...
    GROUP BY P.ident, B.code
) pc
GROUP BY pc.patientID;
```

**Robustheit:** `SUM(anzahl)` fängt beide Erfassungsvarianten ab — eine Zeile
mit `anzahl=2` ODER zwei Zeilen mit `anzahl=1` ergeben beide `x2`.

**GOÄ:** Identisches Pattern mit `goaekatalogeintrag` + GOÄ-Pfad
(`privatrechnung_goaeleistungen → privatrechnung`). `anzahlnenner`
(Teilleistungs-Divisor) hier ignorieren — der ist nur für die Euro-Berechnung
relevant, nicht für „wie oft abgerechnet".

## 33. PatF-Zählung — Minimal-Pattern (kein Join zu karteieintragtyp nötig)

Für die Zählung von arzt-direct-Formular-Rückschrieben reichen drei Filter auf
`karteieintrag` selbst, der Join zu `karteieintragtyp` ist überflüssig und war
in Q-PatF-Count v1 die Fehlerursache (`typ_ident` existiert nicht — korrekter
Spaltenname ist `karteieintragtyp_ident`, aber selbst der wird hier nicht
gebraucht).

**Minimalpattern:**

```sql
FROM karteieintrag k
JOIN formulartyp ft ON ft.ident = k.formulartyp_ident
WHERE k.visible        = true
  AND k.dtype          = 'Formular'
  AND k.jsonformsource = 1                       -- arzt-direct-Rückschrieb
  AND ft.name         LIKE 'Patientenformular_%' -- nur PatF
```

**Zusatzbeobachtung:** `k.dokumentierendernutzer_ident` ist bei arzt-direct-
Rückschrieben systematisch `NULL` (Aggregation liefert `versender = 0`).
Das ist kein Datenfehler, sondern Architektur: der Patient ist „Autor", kein
tomedo-Nutzer hat den Eintrag dokumentiert. Nicht als Filter verwenden.

## 34. Reassessment-/Wiedererhebungs-Zählung (>=N gleichartige Ereignisse pro Patient)

**Zweck:** „Ist ein Patient >=2x re-assessiert/re-erhoben worden?" — für Verlaufs-/Reassessment-Kennzahlen. Zählt gleichartige Ereignisse (Formulare eines Typs, EBM-Ziffer) pro Patient und bucketet nach Anzahl (1 / 2 / >=3).

**Muster (PatF-Quartalsbogen als dokumentierter Reassessment-Proxy):**
```sql
WITH qtyp AS (                        -- Formulartyp-Ident EINMAL vorauflösen
    SELECT ident FROM formulartyp
    WHERE name LIKE 'Patientenformular_psf-quartal%'
),
boegen AS (
    SELECT P.ident AS patientID, COUNT(DISTINCT k.ident) AS anz
    FROM karteieintrag k
    JOIN patientendetailsrelationen_formulare H ON H.formulare_ident = k.ident
    JOIN patientendetails PD ON PD.patientendetailsrelationen_ident = H.patientendetailsrelationen_ident
    JOIN patient P ON P.patientendetails_ident = PD.ident
    WHERE k.visible = true AND k.dtype = 'Formular' AND k.jsonformsource = 1
      AND k.formulartyp_ident IN (SELECT ident FROM qtyp)   -- statt LIKE über name!
      AND k.datum >= DATE '2025-11-01'
    GROUP BY P.ident
)
SELECT CASE WHEN anz=1 THEN '1' WHEN anz=2 THEN '2' ELSE '>=3' END AS bucket,
       COUNT(*) AS patienten
FROM boegen GROUP BY 1 ORDER BY 1;
```

**Performance-Kern:** Formulartyp-Ident **vorauflösen** (CTE `qtyp`) und `karteieintrag` auf `formulartyp_ident IN (...)` filtern — statt `formulartyp` zu joinen und auf `name LIKE ...` zu filtern. Sargable, vermeidet einen `LIKE` über die gesamte (große) `karteieintrag`-Tabelle; senkte eine mehrminütige Laufzeit auf Sekunden.

⚠ **EBM-Verlaufsziffern als Reassessment-Proxy nur mit Vorsicht:** EBM 30702 (Zusatzpauschale Schmerztherapie) wird praktisch für die **gesamte** 30700-Population abgerechnet (~100 % Deckung), ebenso 30704. `>=2x 30702` misst damit Betreuungs-/Abrechnungskontinuität (Obergrenze), NICHT dokumentierte Re-Erhebung. Für einen dokumentierten Reassessment-Nachweis den Formular-Pfad (>=2 Quartalsbögen) verwenden.

## 35. Nutzer-Aktivitaets-Sessionisierung (Arbeitszeit-Korridor)

Zweck: grobe Arbeitszeitschaetzung eines Nutzers aus zeitgestempelten Events. Liefert einen **Korridor**: Session-Modell als Untergrenze, Tages-Span als Obergrenze. Kein Einzelwert — tomedo hat keinen Login-Audit-Trail.

Eventquellen (alle nutzerattribuiert und mit echter Uhrzeit):

```sql
WITH ev_raw AS (
    SELECT K.datum AS ts FROM karteieintrag K
    WHERE K.visible = true AND K.datum IS NOT NULL
      AND K.dokumentierendernutzer_ident = (SELECT ident FROM nutzer WHERE TRIM(kuerzel) = 'XXX')
    UNION ALL
    SELECT A.erstelltam FROM aufgabe A
    WHERE A.removed = false AND A.erstelltam IS NOT NULL
      AND A.ersteller_ident = (SELECT ident FROM nutzer WHERE TRIM(kuerzel) = 'XXX')
    UNION ALL
    SELECT M.erstellt FROM nachricht M
    WHERE M.removed = false AND M.erstellt IS NOT NULL
      AND M.sender_ident = (SELECT ident FROM nutzer WHERE TRIM(kuerzel) = 'XXX')
),
-- Minutengranular deduplizieren: neutralisiert Batch-Stempel UND
-- Doppelzaehlung, wenn derselbe Nutzer dok + letzterNutzer am KE ist
ev_min AS (
    SELECT DISTINCT date_trunc('minute', ts) AS ts_min,
                    date_trunc('minute', ts)::date AS tag
    FROM ev_raw
    WHERE ts >= DATE '<von>' AND ts < DATE '<bis>'
      AND ts::time <> TIME '00:00:00'
),
thr AS (SELECT g FROM (VALUES (30),(45),(60),(90)) v(g)),
ev_gap AS (
    SELECT t.g, e.tag, e.ts_min,
           EXTRACT(EPOCH FROM (e.ts_min - LAG(e.ts_min)
               OVER (PARTITION BY t.g, e.tag ORDER BY e.ts_min))) / 60.0 AS gap_min
    FROM ev_min e CROSS JOIN thr t
),
ev_sess AS (
    SELECT g, tag, ts_min,
           SUM(CASE WHEN gap_min IS NULL OR gap_min > g THEN 1 ELSE 0 END)
               OVER (PARTITION BY g, tag ORDER BY ts_min) AS sess_id
    FROM ev_gap
),
sess AS (
    SELECT g, tag, sess_id, COUNT(*) AS events,
           EXTRACT(EPOCH FROM (MAX(ts_min) - MIN(ts_min))) / 60.0 AS netto_min
    FROM ev_sess GROUP BY g, tag, sess_id
)
-- Untergrenze: SUM(netto_min) pro Tag/Monat
-- Obergrenze: EXTRACT(EPOCH FROM (MAX(ts_min)-MIN(ts_min)))/60 pro Tag aus ev_min
```

**Regeln:**
- Deduplizierung **vor** der Gap-Berechnung, sonst zaehlen Batch-Stempel als Aktivitaet.
- `ts::time <> TIME '00:00:00'` filtert Eintraege ohne Uhrzeit.
- Monatsaggregation **kalendergenau** (`date_trunc('month', tag)`), nicht ueber den Wochenmontag — sonst wandern Events ueber Monatsgrenzen und erzeugen Scheineinbrueche.
- Keine `::time`-Spalte im finalen SELECT (Serializer Typ 92, siehe lessons-learned.md).
- Ab ~9 Events/aktivem Tag belastbar, darunter markieren.
- `letzternutzer_ident`-Eintraege sind **nicht** einbeziehbar (kein Zeitstempel, siehe lessons-learned.md).

## 36. Lesbarkeits- und Stilmetriken aus Freitext (ohne Inhaltsexport)

Zweck: Schreibstil und Lesbarkeit von Emails oder Karteieintraegen vergleichen, **ohne** dass Inhalte die Datenbank verlassen. Alle Ausgaben sind berechnete Kennzahlen.

**LIX** = Woerter/Saetze + 100 × Langwoerter/Woerter (Langwort = >6 Zeichen).
Deutung: <40 leicht · 40–50 mittel · 50–60 schwer · >60 sehr schwer. Normbereich Geschaeftskorrespondenz 45–55.
Sprachunabhaengig, keine Silbenzaehlung noetig — deshalb LIX und nicht Wiener Sachtextformel oder Flesch.

Normalisierungskette, Reihenfolge ist bindend:

```sql
-- 1. Signaturblock ab Grussformel abschneiden (macht 23-28 % der Laenge aus!)
split_part(txt, 'Mit freundlichen', 1)
-- 2. HTML-Tags UND spitze-Klammer-Adressen entfernen
regexp_replace(..., '<[^>]+>', ' ', 'g')
-- 3. Absatzumbrueche als ASCII-Sentinel sichern, dann Whitespace kollabieren
regexp_replace(..., '(\r?\n){2,}', ' @@ABS@@ ', 'g')
regexp_replace(..., '[ \t\r\n]+', ' ', 'g')
-- 4. Fuer die SATZZAEHLUNG separat maskieren (siehe lessons-learned.md)
```

Tokenisierung und Aggregation:

```sql
CROSS JOIN LATERAL regexp_split_to_table(text_clean,'[^[:alnum:]äöüÄÖÜß]+') AS t(tok)
...
COUNT(*) FILTER (WHERE length(tok) > 0) AS woerter,
COUNT(*) FILTER (WHERE length(tok) > 6) AS langwoerter,
AVG(length(tok)) FILTER (WHERE length(tok) > 0) AS wortlaenge
```

**Robustheitsrangfolge der Metriken** (aus Fehlererfahrung):
1. `wortlaenge` — unberuehrt von Satzzaehlungs- und Markup-Fehlern, belastbarster Einzelwert
2. `zeichen`, `woerter`, `absaetze` — nur vom Markup-Strip betroffen
3. `satzlaenge`, `lix` — von der Satzzaehlung abhaengig, ohne Maskierung unbrauchbar

**Stilmarker als Trefferquoten** — reine Vorkommensprueflung, von allen Messfehlern unberuehrt und daher besonders robust: Deeskalation (`bitte`, `gern`, `Verständnis`, `entschuldig`, `leider`), Konkretheit (`€`, `Frist`, `Rechnungsnummer`, `§`), Hedging (`eventuell`, `möglicherweise`), Form (`Sehr geehrte`), Dialogangebot (`Rückfrage`, `melden Sie sich`).

**Fallenkatalog:**
- Gesamtmediane zweier ungleich grosser Gruppen nicht direkt vergleichen — nach Laengenband stratifizieren (siehe ADR-MAILQ-15).
- Bei gepoolten Terzilen bestimmt die groessere Gruppe die Grenzen. Informativ, aber die kleine Gruppe landet ggf. komplett in einem Band.
- Auffaellige Gleichfoermigkeit von Zeichen-, Wort- und Satzmedianen ueber viele Mails = standardisierter Text, kein Freitext. Guter Klassifikator, wenn kein Betreff verfuegbar ist.
- Das aussagekraeftigste Mass ist nicht der absolute LIX, sondern das **Delta zwischen Vorlage und Freitext derselben Person** — es isoliert die eigene Schreibleistung vom Textsortenniveau.


> ## 38. Begriffs-Haeufigkeitsmatrix ueber VALUES-Liste
>
> Für Begriffsvalidierung im Freitext: Begriffsliste als `VALUES`-CTE, Join über `strpos` statt vieler
> `CASE`-Zweige. Gruppenspalte macht die Auswertung lesbar, die Jahresspalten decken Notationsbrüche auf.
> Erst filtern, dann Bridges joinen — die Trefferzahl ist klein, der KE-Bestand nicht.
>
> ```sql
> WITH begriffe (gruppe, begriff) AS (
>     VALUES ('G1'::text, 'op-indikation'::text),
>            ('G1', 'op indikation'),
>            ('G2', 'zweitmeinung')
> ),
> ke AS (
>     SELECT k.ident AS keid,
>            EXTRACT(YEAR FROM k.datum)::integer AS jahr,
>            lower(k.text) AS txt
>     FROM karteieintrag k
>     WHERE k.visible = true AND k.text IS NOT NULL
>       AND k.datum >= DATE '2024-01-01'
> ),
> treffer AS (
>     SELECT bg.gruppe, bg.begriff, ke.keid, ke.jahr
>     FROM ke JOIN begriffe bg ON strpos(ke.txt, bg.begriff) > 0
> )
> SELECT gruppe, begriff,
>        COUNT(DISTINCT keid) AS ke_treffer,
>        COUNT(DISTINCT CASE WHEN jahr = 2025 THEN keid END) AS ke_2025
> FROM treffer GROUP BY gruppe, begriff ORDER BY gruppe, ke_treffer DESC;
> ```
>
> **Variante Token-Frequenz** für Vokabular-Entdeckung, wenn nicht bekannt ist, welche Wörter überhaupt
> vorkommen — Pflichtschritt, bevor eine Begriffsliste geraten wird:
>
> ```sql
> CROSS JOIN LATERAL regexp_split_to_table(
>     regexp_replace(lower(fe.wert), '[^a-zäöüß0-9 -]', ' ', 'g'),
>     '[^a-zäöüß0-9-]+') AS tok(wort)
> ```
>
> Schwelle `HAVING COUNT(*) >= 10` bis `15` hält Eigennamen praktisch vollständig aus dem Ergebnis, ohne das
> Alltagsvokabular zu verlieren. Werden Bridges gebraucht, `COUNT(DISTINCT keid)` statt `COUNT(*)` verwenden —
> die Dual-Bridge kann Zeilen vervielfachen.


## 38. Maschinell erzeugte Karteieintraege je Nutzer und Quartal

Zaehler und Nenner getrennt aggregieren: der Zaehler ist winzig, der Nenner laeuft ueber
Millionen Zeilen. Ein gemeinsames `GROUP BY` mit `FILTER` waere langsamer und macht die
spaetere Demo-Exklusion des Zaehlers unmoeglich.

```sql
WITH nenner AS (
  SELECT EXTRACT(YEAR FROM k.datum)::int || 'Q' || to_char(k.datum, 'Q') AS quartal,
         TRIM(COALESCE(n.kuerzel, '(ohne)'))                             AS dok_nutzer,
         count(*)                                                        AS ke_gesamt
  FROM karteieintrag k
  LEFT JOIN nutzer n ON n.ident = k.dokumentierendernutzer_ident
  WHERE k.visible = true
    AND k.datum >= DATE '2025-11-01' AND k.datum < DATE '2027-01-01'
  GROUP BY 1, 2
),
zaehler AS (
  SELECT EXTRACT(YEAR FROM k.datum)::int || 'Q' || to_char(k.datum, 'Q') AS quartal,
         TRIM(COALESCE(n.kuerzel, '(ohne)'))                             AS dok_nutzer,
         COALESCE(substring(k.autoquelle from '"kuerzel"[^"]*"([^"]+)"'), '?') AS quelle,
         count(*)                                                        AS ke_maschinell
  FROM karteieintrag k
  LEFT JOIN nutzer n ON n.ident = k.dokumentierendernutzer_ident
  WHERE k.visible = true
    AND k.datum >= DATE '2025-11-01' AND k.datum < DATE '2027-01-01'
    AND k.autoquelle IS NOT NULL
  GROUP BY 1, 2, 3
)
SELECT z.quartal, z.dok_nutzer, z.quelle,
       z.ke_maschinell, d.ke_gesamt,
       ROUND(100.0 * z.ke_maschinell / NULLIF(d.ke_gesamt, 0)::numeric, 2) AS anteil_prozent
FROM zaehler z
JOIN nenner d ON d.quartal = z.quartal AND d.dok_nutzer = z.dok_nutzer
ORDER BY z.quartal DESC, z.ke_maschinell DESC
```

Beidseitige Datumsgrenzen sind Pflicht (Datumsausreisser, siehe lessons-learned D).
Die Kennzahl misst nur **geflaggte** KI-Dokumentation — ungeflaggte Pfade fehlen still.

## 38. Schema-Discovery ohne Werteausgabe

Zweck: Spaltennamen einer nicht dokumentierten Tabelle ermitteln, **ohne** deren Inhalte auszugeben. Noetig, sobald die Tabelle Zugangsdaten, Freitext mit Patientenbezug oder anderes Heikles fuehrt. System-Katalog-Abfragen sind bei tomedo verboten (Applikationsabsturz), das etablierte `row_to_json(T)::text` gibt dagegen die kompletten Werte aus.

```sql
WITH eine AS (
    SELECT row_to_json(SK) AS zeile
    FROM skript SK
    LIMIT 1
)
SELECT CAST('skript' AS text) AS tabelle,
       KY                     AS spalte
FROM eine
CROSS JOIN LATERAL json_object_keys(eine.zeile) AS KY
ORDER BY KY;
```

**Realfall 2026-08-23:** Der Skriptbestand fuehrt seinen Quelltext in `skript.sourcecode` — **nicht** in `zsourcecode`, wie an anderer Stelle notiert. Neun von dreissig Skripten enthalten laut Projektwissen Zugangsdaten im Klartext; die keys-only-Variante klaert den Feldnamen, ohne sie anzufassen.

**Faustregel:** `row_to_json(T)::text` nur bei unverdaechtigen Konfigurationstabellen. Sobald Text- oder Codefelder im Spiel sind, keys-only.

### Tabellenexistenz raten, wenn der Katalog gesperrt ist

Steht eine Tabelle weder in `datenmodell.md` noch im DB-Dump, bleibt nur das Probieren von Kandidatennamen — je Kandidat ein eigener Lauf, weil ein `relation does not exist` die ganze Query abbricht. Ein UNION mehrerer Kandidaten ist deshalb **falsch**.

Praxisgrenze: nach etwa zehn erfolglosen Kandidaten lohnt das Raten nicht mehr. Der Realfall 2026-08-23 verbrauchte zwoelf Namen fuer die Login-Historie, ohne Treffer. Guenstiger ist ab da eine Supportanfrage beim Hersteller nach Tabellen- und Spaltennamen.

## 37. Anteilsschlüssel mit Kapazitätsdeckel (Umlage ohne Zeitstempel)

Zweck: eine Ressource auf Gruppen verteilen, wenn die Ressource als **Kapazität** bekannt ist, ihre Nutzung aber keinen Zeitstempel hat. Statt Minuten zu messen, wird der **Ereignisanteil** gemessen und die bekannte Kapazität danach verteilt. Der Validierungsanker („die Summe darf die reale Kapazität nicht überschreiten") ist dadurch konstruktiv erfüllt und nicht nachträglich zu prüfen.

Wann dieses Muster statt einer Sessionisierung (Baustein 35): wenn je Gruppe weniger als etwa neun Ereignisse pro aktivem Tag anfallen. Darunter ist die Sessionisierung nicht belastbar, die Anteilsrechnung schon.

```sql
basis AS (
  SELECT (SELECT SUM(ereignisse) FROM ev_gruppe)                        AS ereignisse_gesamt,
         23000.0 * (CURRENT_DATE - DATE '2025-11-01')::numeric / 365.0  AS kapazitaet_fenster
)
SELECT G.gruppe,
       G.ereignisse,
       ROUND(100.0 * G.ereignisse::numeric / B.ereignisse_gesamt, 1)    AS anteil_pp,
       ROUND(B.kapazitaet_fenster * G.ereignisse::numeric
                                  / B.ereignisse_gesamt, 0)             AS stunden_zugeordnet
FROM ev_gruppe G
CROSS JOIN basis B
ORDER BY G.ereignisse DESC;
```

Drei Regeln, ohne die das Muster täuscht:

1. **Nenner ist die Gesamtheit aller Ereignisse**, auch der nicht zuordenbaren und der nicht gemessenen. Wer nur über die zuordenbaren normiert, verteilt die volle Kapazität auf einen Bruchteil des Signals und überzeichnet jede Gruppe.
2. **Nicht zuordenbar und nicht gemessen sind zwei eigene Ergebniszeilen.** Ihr gemeinsamer Anteil ist der Zuordnungsgrad — die wichtigste Qualitätszahl des Ergebnisses und meist wichtiger als die Gruppenwerte selbst.
3. **Nicht auf den ungemessenen Rest extrapolieren.** Der ungemessene Teil hat regelmäßig einen anderen Gruppenmix als der gemessene; eine Hochrechnung ersetzt einen Befund durch eine Annahme.

Ausgabe als **Relativfaktor** (Gruppenwert gegen Gesamtdurchschnitt), wenn der eigene Nenner vom Nenner des Zielmodells abweicht. Der Index überträgt sich, der Absolutwert nicht.

Realfall: `Q-MFA-01` (MFA-Overhead je Disziplin, 2026-09-08) — Kapazität 23.000 h/Jahr, 19.597 h im Fenster, Zuordnungsgrad 19,9 pp.

## 38. Erstkontaktfenster und lebenslang in einem Lauf

**Problem.** Ein lebenslanges Merkmalsflag, nach Erstkontaktjahr gruppiert, ist als Zeitreihe
nicht lesbar: die frueheste Kohorte hatte Jahre Zeit, das Merkmal zu erwerben, die juengste
Monate (Immortal-Time-Effekt). Wer nur das Fenster rechnet, verliert dafuer die Aussage
„Merkmal entstand im Verlauf".

**Loesung.** Beide Fenster als zwei Flagspalten in derselben Aggregation. Kostet keinen
zweiten Lauf, und der Abstand zwischen den Spalten ist selbst ein Befund.

```sql
erst AS (
    SELECT patid, MIN(ke_datum) AS erstkontakt,
           EXTRACT(YEAR FROM MIN(ke_datum))::int AS erstkontakt_jahr
    FROM ke_pat GROUP BY patid
),
flags AS (
    SELECT e.patid, e.erstkontakt_jahr,
           MAX(CASE WHEN kp.ke_datum <= e.erstkontakt + INTERVAL '6 months'
                     AND kp.merkmal = 1 THEN 1 ELSE 0 END) AS im_fenster,
           MAX(CASE WHEN kp.merkmal = 1 THEN 1 ELSE 0 END) AS lebenslang
    FROM erst e JOIN ke_pat kp ON kp.patid = e.patid
    WHERE e.erstkontakt_jahr BETWEEN 2014 AND 2026
    GROUP BY e.patid, e.erstkontakt_jahr
)
```

**Zwei Pflichthinweise.** Der `INTERVAL`-Ausdruck darf nur im Vergleich stehen, nie in der
Ausgabe (Client-Absturz). Und die jeweils letzten Kohorten sind rechtszensiert: solange das
Fenster nicht abgelaufen ist, gilt `im_fenster = lebenslang`, was ohne Hinweis wie ein
Strukturbruch aussieht. Referenzjahr immer die letzte vollstaendige Kohorte.

**Nenner-Regel dazu.** Der Nenner sind die Patienten, die den **Traegerkanal** ueberhaupt
haben (mindestens ein Objekt des Typs, in dem das Merkmal erscheinen kann). Patienten ohne
Traegerkanal im Nenner senken die Quote mechanisch.

## 38. Zuweiserstruktur: zwei Sichten, Fachgruppe aus der LANR

Praxisweite Zuweiserstruktur je Jahr. Beide Sichten in **einem** SELECT ueber `UNION ALL`,
damit der Connector nur einen Lauf braucht.

```sql
WITH ks AS (                      -- alle Jahre, damit der Erstkontakt korrekt ist
    SELECT PAT.ident AS patid, KVS.jahr, KVS.quartal,
           KVS.jahr * 4 + KVS.quartal                       AS qidx,
           TRIM(COALESCE(KVS.ueberweisenderarzt, ''))       AS lanr,
           TRIM(COALESCE(KVS.ueberweisenderarztname, ''))   AS zuwname
    FROM kvschein KVS
    JOIN patientendetailsrelationen_kvscheine BRK ON BRK.kvscheine_ident = KVS.ident
    JOIN patientendetails PDK
           ON PDK.patientendetailsrelationen_ident = BRK.patientendetailsrelationen_ident
    JOIN patient PAT ON PAT.patientendetails_ident = PDK.ident
    WHERE KVS.visible = true
      AND KVS.ignoriertfuerabrechnung = false
      AND strpos(lower(COALESCE(PAT.nachname, '')), 'demo-') = 0
),
erst AS (   -- Sicht 1: fruehester Schein des Patienten UEBERHAUPT
    SELECT DISTINCT ON (patid) patid, jahr, lanr, zuwname
    FROM ks
    ORDER BY patid, qidx, (CASE WHEN lanr <> '' OR zuwname <> '' THEN 0 ELSE 1 END)
),
jsicht AS ( -- Sicht 2: fruehester Schein IM Berichtsjahr (nur Dokumentationsdiagnostik)
    SELECT DISTINCT ON (patid, jahr) patid, jahr, lanr, zuwname
    FROM ks WHERE jahr BETWEEN 2024 AND 2026
    ORDER BY patid, jahr, quartal, (CASE WHEN lanr <> '' OR zuwname <> '' THEN 0 ELSE 1 END)
),
basis AS (
    SELECT CAST('1_Erstkontakt' AS text) AS sicht, patid, jahr, lanr, zuwname
    FROM erst WHERE jahr BETWEEN 2024 AND 2026
    UNION ALL
    SELECT CAST('2_Jahresschein' AS text) AS sicht, patid, jahr, lanr, zuwname FROM jsicht
)
-- danach eine klass-CTE mit dem Fachgruppen-CASE (LANR Stelle 8-9), dann
-- GROUP BY sicht, jahr, fachgruppe mit COUNT(DISTINCT patid).
```

**Drei Fallstricke:**

1. **Tie-Break ist Pflicht.** Liegen im maßgeblichen Quartal mehrere Scheine, muss der
   Schein **mit** Zuweiserangabe gewinnen — sonst verdeckt ein zufaellig frueherer Schein
   ohne Angabe die vorhandene Information, und die Zuweisung wird einseitig unterschaetzt.
2. **`ks` darf nicht auf das Berichtsjahr eingeschraenkt werden.** Der Erstkontakt braucht
   die volle Historie; die Jahresgrenze gehoert erst in `basis`.
3. **Erfassungsdichte vorher pruefen** (Baustein-Vorstufe): `COUNT(*)` je Jahr gegen
   `SUM(CASE WHEN lanr <> '' OR zuwname <> '' THEN 1 ELSE 0 END)`. Ist das Traegerfeld in
   frueheren Jahren leer, ist die Zeitreihe nicht rechenbar.

Restklassen immer getrennt ausweisen — Pseudo-LANR, Schluessel `00`, Formatfehler und
**Name ohne LANR**. Letztere sind Zuweisungen mit unbestimmter Fachgruppe und duerfen nicht
als Selbstzuweiser zaehlen.

## 38. Ressourcen-Wochenraster, Layout-Treue und Erstkontakt-Ausbeute

Vier Muster, die zusammen ein Ressourcenmodell tragen. Alle an den Echtdaten der Referenzinstallation validiert (2026-09-01).

**a) Wochenraster einer Ressource** — was im Kalender als Wochenmuster hinterlegt ist.
Normierung ueber `COUNT(DISTINCT tag)`, nicht ueber eine gesetzte Wochenzahl, sonst verzerren
Monate mit vier statt fuenf Vorkommen des Wochentags.

```sql
SELECT az.kuerzel, EXTRACT(ISODOW FROM te.beginn)::int AS wochentag,
       TRIM(ta.kuerzel) AS ressource,
       COUNT(DISTINCT te.beginn::date)                                        AS tage_mit_block,
       ROUND(SUM(EXTRACT(EPOCH FROM (te.ende-te.beginn))/60)::numeric
             / GREATEST(COUNT(DISTINCT te.beginn::date),1)::numeric, 0)        AS min_je_tag
FROM termin te
JOIN terminart ta ON ta.ident = te.terminart_ident
JOIN termin_kalender tk ON tk.termin_ident = te.ident
JOIN kalender ka ON ka.ident = tk.kalender_ident
WHERE te.removed = false AND ta.infotermin = true
  AND ka.visible = true AND ka.nutzer_ident IS NOT NULL
GROUP BY 1,2,3
```

Pruefgroesse `tage_mit_block`: liegt der Wert deutlich unter der Zahl der Wochentagsvorkommen
im Quartal, ist der Wochentag nicht durchgaengig belegt und `min_je_tag` verdeckt ein
Zweiwochenraster. Realbefund der Referenzinstallation: 136 von 181 Zeilen mit genau 13 — Raster stabil.

**b) Layout-Treue** — gebuchte Minuten einer Ressource geteilt durch ihre netto verfuegbaren
Minuten. Die Zuordnung Buchung → Ressource laeuft ueber
`terminart.terminresourceverbindung_ident`, ein Selbstjoin auf `terminart`:

```sql
LEFT JOIN terminart re ON re.ident = ta.terminresourceverbindung_ident
...
CASE WHEN ta.terminresourceverbindung_ident IS NULL
     THEN CAST('ohne Bindung' AS text) ELSE CAST(TRIM(re.kuerzel) AS text) END AS ressource
```

Terminarten ohne Bindung **nicht stillschweigend verteilen** — sie sind der Anteil, der gegen
kein Layout pruefbar ist (an der Referenzinstallation: 0,4 bis 11,0 Prozent der gebuchten Minuten).
Auswertung: **nicht der Mittelwert ist die Aussage, sondern die Streuung ueber die Monate.**
Niedrige Streuung bei abweichendem Mittel = falsch eingestellte Ressource, die Buchung weicht
systematisch ab. Hohe Streuung = schwankende Nachfrage, kein Layout-Fehler.

**c) Erstkontakt-Ausbeute je Terminart** — Anteil der Termine, die der erste Kontakt eines
Patienten im Quartal sind. Traegt Kennzahlen wie „Fall je Terminart".

```sql
ROW_NUMBER() OVER (PARTITION BY patient_ident, qidx ORDER BY beginn, ident) AS rang
-- danach: SUM(CASE WHEN rang = 1 THEN 1 ELSE 0 END) / COUNT(*)
```

**d) Quartalsuebergang ohne Datumsarithmetik** — `qidx = jahr*10 + quartal` ist als Ganzzahl
sortierbar und vergleichbar; das Folgequartal ohne Kalenderfunktionen:

```sql
CASE WHEN quartal = 4 THEN (jahr*10 + quartal) + 7 ELSE (jahr*10 + quartal) + 1 END
```

Nur Uebergaenge auswerten, deren Folgequartal abgeschlossen ist — das laufende Quartal
drueckt jede Wiederkehrquote kuenstlich.

## 38. Export der gespeicherten Statistiken (Statistikverwaltung)

Vollexport aller selbst angelegten Statistiken inklusive der Elemente kombinierter
Statistiken. Ergebnis enthaelt keine Patientendaten. Belegt am Realfall der Referenzinstallation 08/2026:
77 Zeilen, 324.265 Zeichen SQL-Text, verlustfrei durch den CSV-Export.

```sql
SELECT  OVE.ident                                                     AS statistikID,
        COALESCE(GPA.name, '')                                        AS ordner_oben,
        COALESCE(PAR.name, '')                                        AS ordner,
        OVE.name                                                      AS bezeichnung,
        CASE WHEN OVE.iscustom     THEN 'eigen'  ELSE 'tomedo'    END AS herkunft,
        CASE WHEN OVE.isgroup      THEN 'Ordner' ELSE 'Statistik' END AS art,
        CASE WHEN OVE.removed      THEN 'ja'     ELSE 'nein'      END AS geloescht,
        CASE WHEN OVE.isgroup                     THEN 'Ordner'
             WHEN COALESCE(OVE.sqlquery, '') = '' THEN 'leer'
             WHEN length(OVE.sqlquery) < 30       THEN 'Mengenalgebra'
             ELSE 'SQL' END                                           AS bauart,
        CASE WHEN strpos(lower(COALESCE(OVE.sqlquery, '')), 'nachname') > 0
             THEN 'ja' ELSE 'nein' END                                AS gibt_namen_aus,
        CAST(OVE.erstellt AS text)                                    AS erstellt,
        OVE.zsident,
        OVE.explanation,
        OVE.sqlquery,
        (SELECT string_agg(
                  concat(CSE.kuerzel, ' typ=', CSE.elementtyp,
                         ' zeit=', CSE.vonbezugsraumtyp, '/', CSE.vonbezugsraumanzahl,
                         '..',     CSE.bisbezugsraumtyp, '/', CSE.bisbezugsraumanzahl,
                         ' filter=', COALESCE(CSE.suchfreitext, '')),
                  ' ;; ' ORDER BY CSE.kuerzel, CSE.listenpos)
           FROM outlineviewelement_customstatistikelemente BRC
           JOIN customstatistikelement CSE
             ON CSE.ident = BRC.customstatistikelemente_ident
          WHERE BRC.outlineviewelement_ident = OVE.ident)              AS elemente
FROM outlineviewelement OVE
LEFT JOIN outlineviewelement_children BRP ON BRP.children_ident = OVE.ident
LEFT JOIN outlineviewelement          PAR ON PAR.ident = BRP.outlineviewelement_ident
LEFT JOIN outlineviewelement_children BRG ON BRG.children_ident = PAR.ident
LEFT JOIN outlineviewelement          GPA ON GPA.ident = BRG.outlineviewelement_ident
WHERE   OVE.dtype = 'StatistikOutlineElement'
    AND OVE.iscustom = true
ORDER BY 2, 3, 4
```

**Optische Trenner fuer die Weiterverarbeitung.** Statt `OVE.sqlquery` einen Block mit
Kopf- und Fussbalken ausgeben — beides gueltige SQL-Kommentare, damit die Spalte direkt
in einen Editor kopierbar ist (gebaut, noch nicht ausgefuehrt):

```sql
        concat(
          '-- ################################################', chr(10),
          '-- #', OVE.name, chr(10),
          '-- ident=', CAST(OVE.ident AS text), chr(10),
          '-- ################################################', chr(10),
          COALESCE(OVE.sqlquery, ''), chr(10),
          '-- ---------------- ENDE: ', OVE.name, ' ----------------', chr(10)
        )                                                             AS sql_block,
```

**Fallstricke:**
- `AND OVE.iscustom = true` weglassen liefert zusaetzlich die Zollsoft-Standardstatistiken.
  Deren `sqlquery` ist Fremdcode — zum Nachschlagen brauchbar, zum Weitergeben nicht.
- Der CSV-Ruecklauf enthaelt Zeilenumbrueche in den Statements. Nur mit echtem CSV-Parser
  lesen, in Python zusaetzlich `csv.field_size_limit` hochsetzen und `utf-8-sig` als
  Encoding waehlen (der Export schreibt ein BOM).
- Keine ZS-Filter einbauen: die Werksstatistiken sind in jeder Instanz identisch, der
  `iscustom`-Filter genuegt.


