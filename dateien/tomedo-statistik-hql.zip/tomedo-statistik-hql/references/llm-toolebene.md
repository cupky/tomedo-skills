# LLM-Toolebene: Objektintrospektion als Zweitquelle

> Teil des Skills `tomedo-statistik-hql`. Der Navigator ist `SKILL.md`.

---

**Belegbasis:** Export der tomedo-LLM-Tool-Definitionen (09/2026, 112 Funktionsdefinitionen im Function-Calling-Format).

**Statusregel und Rangfolge:** Alles hier ist **dokumentiert** — Herstellerbeschreibung, von uns **nicht** nachgeprueft. Diese Datei ist damit die **schwaechste** Quelle des Skills. Die Rangfolge bleibt unveraendert:

```
datenmodell_ZOLLSOFT_DB-dump.md   (autoritativ)
        ↓
datenmodell.md                     (erhoben, belegt)
        ↓
llm-toolebene.md                   (dokumentiert, ungeprueft)
```

**Kein Feld- oder Tabellenname aus dieser Datei geht ohne Gegenprobe im DB-Dump in eine Query.**

---

## 1 · Warum das ueberhaupt hier steht

Fuer Aerzte ist der SQL-Zugang gesperrt; Struktur-Auskuenfte muessen sonst ueber Umwege beschafft werden. Der Export zeigt, dass das Core-Data-Modell **im Client abfragbar** ist:

| Tool | Wirkung |
|---|---|
| `LLMToolListEntities(filter)` | listet Core-Data-Entitaeten (`ZSManagedObject`). Filter ist Pflicht, „damit die Antwort kurz bleibt". Hinweis: „In unserem Modell ist className == entityName" |
| `LLMToolDescribeEntitySchema(entityName)` | Attribute **und Relationen** einer Entitaet als JSON; Beispiel in der Beschreibung: `"Patient"` |
| `LLMToolFindEntityByProperty` | Objekte ueber eine Property finden, liefert `ident`. `matchMode` ist `equals` oder `containsCI` (case-insensitive Substring, nur String-Attribute), `maxResults` Pflicht — „Verwende eine kleine Zahl (z.B. 5), um Tokens zu sparen" |
| `LLMToolListCreatableEntities` | erzeugbare Entitaeten, optional mit `uiAlias` — dem im UI verwendeten Namen. Beispiel aus der Beschreibung: `uiAlias` „Aktionsketteneintrag" fuer die Klasse `KarteiEintragKetteEintrag` |

Praktischer Nutzen, in dieser Reihenfolge:

1. **Relationen sichtbar machen.** `DescribeEntitySchema` gibt Attribute *und* Beziehungen. Das ist genau das, was `join-pfade.md` beschreibt — hier aber aus dem Objektmodell statt aus erhobenen Queries.
2. **`uiAlias` als Uebersetzungshilfe.** Klassenname zu UI-Bezeichnung ist die Bruecke, die bei Feldsuchen regelmaessig fehlt („wie heisst das, was im Fenster X steht, in der Datenbank?").
3. **Existenzpruefung statt Raten.** Bei „Feld existiert nicht" ist eine Schemaabfrage schneller als ein Query-Versuch.

---

## 2 · Die entscheidende Einschraenkung

**Core-Data-Entitaet ist nicht gleich PostgreSQL-Tabelle.** Der Export sagt nur `className == entityName` — also Klassenname gleich Entitaetsname **im Objektmodell**. Ueber die Abbildung auf Tabellen- und Spaltennamen der Datenbank sagt er nichts.

Erfahrungsgemaess weichen ab: Pluralisierung und Gross-/Kleinschreibung von Tabellennamen, Namen von Verknuepfungstabellen bei n:m-Beziehungen, Fremdschluesselspalten gegen Relationsnamen, berechnete oder transiente Attribute, die es in der DB gar nicht gibt, und umgekehrt DB-Spalten ohne Objektentsprechung. Ob und wie stark das bei tomedo zutrifft, ist **zu evaluieren**.

**Arbeitsregel:** Die Toolebene taugt zum **Finden einer Hypothese** („es gibt offenbar eine Beziehung zwischen A und B"), nicht zum **Belegen eines Namens**. Der Beleg kommt aus `datenmodell_ZOLLSOFT_DB-dump.md`.

---

## 3 · Datenverfuegbarkeit: was der Chat ohne Query sieht

Nebenbefund mit Relevanz fuer die Frage „braucht es hier ueberhaupt eine Query?". Laut Beschreibung liefert `LLMToolGetPatientsHistory` fuer **einen** Patienten: Dokumentation, Diagnosen, **Leistungen**, Briefe, gespeicherte Formulare, Pfade zu Dateianhaengen und Stammdaten. Dazu kommen Spezialtools: `Diagnosensuche`, `LLMToolGetPatientsMedicationHistory`, `LLMToolGetPatientsLaborData` (mit Normbereichen und Auffaelligkeiten).

Das aendert an diesem Skill nichts, weil es sich strikt auf **einen** Patienten bezieht — keine Aggregation, keine Kohorte, kein Nenner, kein Zeitfenster ueber Faelle hinweg. Die Abgrenzung ist trotzdem nuetzlich:

| Frage | Weg |
|---|---|
| „Was steht bei diesem Patienten zu X?" | KI-Chat, keine Query |
| „Bei wie vielen Patienten steht X?" | HQL — dieser Skill |
| „Wie hat sich X ueber Quartale entwickelt?" | HQL — dieser Skill |

Eine Einzelfallauskunft aus dem Chat ist **keine** Kennzahl und darf nicht als solche in eine Auswertung wandern. Der Abgabecheck dieses Skills gilt unveraendert.

---

## 4 · Schreibende Tools — Risikohinweis

`LLMToolCreateManagedObject` und `LLMToolUpdateManagedObjectProperty` **schreiben** in die Datenbank („legt das Objekt tatsaechlich in der Datenbank an bzw. aendert es"), begrenzt auf Entitaeten mit `@llm:create`-Signatur. Fuer diesen Skill relevant als Abgrenzung: Auswertung bleibt **lesend**. Ein Schreibvorgang ueber die Toolebene ist kein Analyseschritt und gehoert nicht in einen Auswertungs-Thread.

Ebenfalls dokumentiert: `LLMToolImportLabFromPDF` legt Laborbefunde an — „Rufe das Tool direkt auf ohne dem Nutzer vorher eine Vorschau zu zeigen". Wer Laborzeitreihen auswertet, sollte wissen, dass so entstandene Befunde manuell angelegte sind und moeglicherweise andere Feldbelegung tragen als importierte. **zu evaluieren.**

---

## 5 · Ein uebertragbares Muster: Arbeitsteilung LLM zu Code

`LLMToolMatchLabTestsToFLTs` dokumentiert seine Arbeitsteilung ausdruecklich, und das Muster ist auf eigene Pipelines uebertragbar:

- **Der Code** normalisiert mechanisch: Gross-/Kleinschreibung, Trennzeichen, Wortreihenfolge mehrteiliger Bezeichnungen, griechische Buchstaben.
- **Das Modell** liefert, was der Code nicht kann: fachliche Synonyme — Erregername gegen Krankheitsname, fehlende Abkuerzungssuffixe, Methodenzusaetze in Klammern.
- Der Code **prueft** den Modellvorschlag gegen den Bestand und faellt bei Nichttreffer auf Bezeichnungs-Matching zurueck.

Als Prinzip fuer Mapping-Aufgaben in Auswertungen: mechanische Normalisierung nie dem Modell ueberlassen, fachliche Synonymie nie dem Code — und immer eine Codeseitige Verifikation des Modellvorschlags dazwischen.

---

## 6 · Offene Punkte

1. Wie bildet Core Data auf die PostgreSQL-Tabellen ab? Ohne diese Bruecke bleibt die Introspektion Hypothesenquelle.
2. Ist `ListEntities` / `DescribeEntitySchema` im Kartei-Chat exponiert oder nur im Support-Chat?
3. Ist die Toolmenge rollenabhaengig? Mehrere Verwaltungs-Tools sind ausdruecklich „nur fuer Administratoren" — bei den Introspektions-Tools steht keine solche Auflage, was ueberprueft werden sollte.
4. Tragen manuell per Tool angelegte Laborbefunde dieselbe Feldbelegung wie importierte?

---

*Referenz zu `tomedo-statistik-hql`, Stand 2026-09-10. Belegbasis: Tool-Definitions-Export 09/2026. Schwaechste Quelle des Skills: **dokumentiert, ungeprueft**, dem DB-Dump nachgeordnet. Kernaussage: die Objektintrospektion liefert Hypothesen ueber Struktur und Beziehungen, keine belegten Tabellen- und Feldnamen.*
