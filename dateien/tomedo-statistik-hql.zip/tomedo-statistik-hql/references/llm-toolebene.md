# LLM-Toolebene: Objektintrospektion als Zweitquelle

> Teil des Skills `tomedo-statistik-hql`. Der Navigator ist `SKILL.md`.

---

**Belegbasis:** Export der tomedo-LLM-Tool-Definitionen (09/2026, 112 Funktionsdefinitionen im Function-Calling-Format).

**Statusregel und Rangfolge:** Alles hier ist **dokumentiert** — Herstellerbeschreibung, von uns **nicht** nachgeprueft. Diese Datei ist damit die **schwaechste** Quelle des Skills. Die Rangfolge bleibt unveraendert:

```
datenmodell_ZOLLSOFT_DB-dump.md   (autoritativ)
        ↓
datenmodell.md                     (erhoben, belegt)
        ↓
llm-toolebene.md                   (dokumentiert, ungeprueft)
```

**Kein Feld- oder Tabellenname aus dieser Datei geht ohne Gegenprobe im DB-Dump in eine Query.**

---

## 1 · Warum das ueberhaupt hier steht

Fuer Aerzte ist der SQL-Zugang gesperrt; Struktur-Auskuenfte muessen sonst ueber Umwege beschafft werden. Der Export zeigt, dass das Objektmodell **ueber die KI-Werkzeuge abfragbar** ist:

| Tool | Wirkung |
|---|---|
| `LLMToolListEntities(filter)` | listet Entitaeten. Filter ist laut Beschreibung Pflicht, „damit die Antwort kurz bleibt"; nach aktuellem Stand liefert ein leerer Filter aber **alle** nicht-abstrakten Entitaeten, abstrakte Oberklassen fehlen immer **[ungeprüft]**. Hinweis: „In unserem Modell ist className == entityName" |
| `LLMToolDescribeEntitySchema(entityName)` | Attribute **und Relationen** einer Entitaet als JSON; Beispiel in der Beschreibung: `"Patient"`. Je Attribut nur Name, Typ, optional; je Relation Name, Mehrfach ja/nein, Ziel — keine Gegenrichtung, keine Oberklasse; enthält auch Felder ohne Datenbankspalte (Präfix `ign_`) **[ungeprüft]** |
| `LLMToolFindEntityByProperty` | Objekte ueber eine Property finden, liefert `ident`. `matchMode` ist `equals` oder `containsCI` (case-insensitive Substring, nur String-Attribute), `maxResults` Pflicht — „Verwende eine kleine Zahl (z.B. 5), um Tokens zu sparen". Sucht nach aktuellem Stand **nur im lokal geladenen Bestand** und nur in freigegebenen Entitaeten, nicht in der Datenbank **[ungeprüft]** |
| `LLMToolListCreatableEntities` | erzeugbare Entitaeten, optional mit `uiAlias` — dem im UI verwendeten Namen. Beispiel aus der Beschreibung: `uiAlias` „Aktionsketteneintrag" fuer die Klasse `KarteiEintragKetteEintrag` |

Praktischer Nutzen, in dieser Reihenfolge:

1. **Relationen sichtbar machen.** `DescribeEntitySchema` gibt Attribute *und* Beziehungen. Das ist genau das, was `join-pfade.md` beschreibt — hier aber aus der Toolebene statt aus erhobenen Queries.
2. **`uiAlias` als Uebersetzungshilfe.** Klassenname zu UI-Bezeichnung ist die Bruecke, die bei Feldsuchen regelmaessig fehlt („wie heisst das, was im Fenster X steht, in der Datenbank?").
3. **Existenzpruefung statt Raten.** Bei „Feld existiert nicht" ist eine Schemaabfrage schneller als ein Query-Versuch.

---

## 2 · Die entscheidende Einschraenkung

**Entitaet der Toolebene ist nicht gleich PostgreSQL-Tabelle.** Der Export sagt nur `className == entityName` — also Klassenname gleich Entitaetsname **auf der Toolebene**. Ueber die Abbildung auf Tabellen- und Spaltennamen der Datenbank sagt er nichts.

Erfahrungsgemaess weichen ab: Pluralisierung und Gross-/Kleinschreibung von Tabellennamen, Namen von Verknuepfungstabellen bei n:m-Beziehungen, Fremdschluesselspalten gegen Relationsnamen, berechnete oder transiente Attribute, die es in der DB gar nicht gibt, und umgekehrt DB-Spalten ohne Objektentsprechung.

**Evaluiert 10/2026:** Die Abbildung ist regelhaft — Tabelle = Entitaet klein, Spalte = Attribut klein,
Einzelbeziehung → `<beziehung>_ident`, Mehrfachbeziehung → Brücke `<tabelle>_<beziehung>`, Vererbung mit `dtype`, `ign_` = ohne
Datenbankspalte. Rund 4.200 Spalten des DB-Dumps liessen sich so ohne Ausnahme bis auf reine Server-Spalten (`serveronly…`) und
`leistung.invkvschein_ident` zuordnen. Details: `datenmodell.md` §0. Mit dieser Regel wird eine Schemaabfrage zur **starken**
Hypothese; der Beleg bleibt der DB-Dump bzw. eine Probequery.

**Arbeitsregel:** Die Toolebene taugt zum **Finden einer Hypothese** („es gibt offenbar eine Beziehung zwischen A und B"), nicht zum **Belegen eines Namens**. Der Beleg kommt aus `datenmodell_ZOLLSOFT_DB-dump.md`.

---

## 3 · Datenverfuegbarkeit: was der Chat ohne Query sieht

Nebenbefund mit Relevanz fuer die Frage „braucht es hier ueberhaupt eine Query?". Laut Beschreibung liefert `LLMToolGetPatientsHistory` fuer **einen** Patienten: Dokumentation, Diagnosen, **Leistungen**, Briefe, gespeicherte Formulare, Pfade zu Dateianhaengen und Stammdaten. Dazu kommen Spezialtools: `Diagnosensuche`, `LLMToolGetPatientsMedicationHistory`, `LLMToolGetPatientsLaborData` (mit Normbereichen und Auffaelligkeiten).

Das aendert an diesem Skill nichts, weil es sich strikt auf **einen** Patienten bezieht — keine Aggregation, keine Kohorte, kein Nenner, kein Zeitfenster ueber Faelle hinweg. Die Abgrenzung ist trotzdem nuetzlich:

| Frage | Weg |
|---|---|
| „Was steht bei diesem Patienten zu X?" | KI-Chat, keine Query |
| „Bei wie vielen Patienten steht X?" | HQL — dieser Skill |
| „Wie hat sich X ueber Quartale entwickelt?" | HQL — dieser Skill |

Eine Einzelfallauskunft aus dem Chat ist **keine** Kennzahl und darf nicht als solche in eine Auswertung wandern. Der Abgabecheck dieses Skills gilt unveraendert.

---

## 4 · Schreibende Tools — Risikohinweis

`LLMToolCreateManagedObject` und `LLMToolUpdateManagedObjectProperty` **schreiben** in die Datenbank („legt das Objekt tatsaechlich in der Datenbank an bzw. aendert es"), begrenzt auf Entitaeten mit `@llm:create`-Signatur. Fuer diesen Skill relevant als Abgrenzung: Auswertung bleibt **lesend**. Ein Schreibvorgang ueber die Toolebene ist kein Analyseschritt und gehoert nicht in einen Auswertungs-Thread.

Ebenfalls dokumentiert: `LLMToolImportLabFromPDF` legt Laborbefunde an — „Rufe das Tool direkt auf ohne dem Nutzer vorher eine Vorschau zu zeigen". Wer Laborzeitreihen auswertet, sollte wissen, dass so entstandene Befunde manuell angelegte sind und moeglicherweise andere Feldbelegung tragen als importierte. **zu evaluieren.**

---

## 5 · Ein uebertragbares Muster: Arbeitsteilung LLM zu Code

`LLMToolMatchLabTestsToFLTs` dokumentiert seine Arbeitsteilung ausdruecklich, und das Muster ist auf eigene Pipelines uebertragbar:

- **Der Code** normalisiert mechanisch: Gross-/Kleinschreibung, Trennzeichen, Wortreihenfolge mehrteiliger Bezeichnungen, griechische Buchstaben.
- **Das Modell** liefert, was der Code nicht kann: fachliche Synonyme — Erregername gegen Krankheitsname, fehlende Abkuerzungssuffixe, Methodenzusaetze in Klammern.
- Der Code **prueft** den Modellvorschlag gegen den Bestand und faellt bei Nichttreffer auf Bezeichnungs-Matching zurueck.

Als Prinzip fuer Mapping-Aufgaben in Auswertungen: mechanische Normalisierung nie dem Modell ueberlassen, fachliche Synonymie nie der Programmlogik — und immer eine Codeseitige Verifikation des Modellvorschlags dazwischen.

---

## 6 · Offene Punkte

1. ~~Wie bilden die Entitaeten auf die PostgreSQL-Tabellen ab?~~ Beantwortet in §2 (10/2026).
2. Ist `ListEntities` / `DescribeEntitySchema` im Kartei-Chat exponiert oder nur im Support-Chat? Stand 10/2026 **[ungeprüft]**:
   weder noch direkt — beide gehören einem Unteragenten der KI-Soforthilfe (Support-Chat), den der Kartei-Chat seinerseits
   als Werkzeug erreicht; nach aktuellem Stand im Versuchsstadium.
3. Ist die Toolmenge rollenabhaengig? Mehrere Verwaltungs-Tools sind ausdruecklich „nur fuer Administratoren" — bei den
   Introspektions-Tools ist nach aktuellem Stand keine Rechteprüfung bekannt **[ungeprüft]**.
4. Tragen manuell per Tool angelegte Laborbefunde dieselbe Feldbelegung wie importierte?

---

*Referenz zu `tomedo-statistik-hql`, Stand 2026-09-10, überarbeitet 2026-10-22. Belegbasis: Tool-Definitions-Export 09/2026. Schwaechste Quelle des Skills: **dokumentiert, ungeprueft**, dem DB-Dump nachgeordnet. Kernaussage: die Objektintrospektion liefert Hypothesen ueber Struktur und Beziehungen, keine belegten Tabellen- und Feldnamen.*
