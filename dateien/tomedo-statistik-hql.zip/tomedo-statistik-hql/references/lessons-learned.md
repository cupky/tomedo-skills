# Lessons Learned — dokumentierte Fehlerquellen (v10)

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Neu angelegt. 46 Lessons aus SKILL.md v9 ausgelagert und thematisch gruppiert; Inhalt unverändert übernommen. SKILL.md enthält nur noch Verbote und Lese-Routing.

> Diese Datei sammelt die reproduzierten Fehler aus der Referenzinstallation. Jeder Abschnitt beschreibt einen Fehler, der mindestens einmal Zeit oder falsche Zahlen gekostet hat. Vor dem Bau einer Query den Abschnitt zur jeweiligen Domäne lesen.

## Inhalt

- **[A. tomedo-Ausführungsumgebung](#a-tomedoausführungsumgebung)** — Was die tomedo-Statistik-Engine anders macht als eine normale psql-Session.
  - Temp-Tabellen sterben zwischen Runs
  - ZS-Tags nur im finalen SELECT
  - Query-Text-Regeln fuer tomedo-Statistiken: kein Prozentzeichen, ein Semikolon
  - System-Katalog-Queries verboten
  - tomedo-Serializer: TIME-Spalten (Typ 92) brechen den Export
  - Unplausible Fehlerposition = abgeschnittenes Statement
- **[B. PostgreSQL-Fallen](#b-postgresqlfallen)** — Dialekt- und Typprobleme, die als Abbruch oder als stiller Zahlenfehler auftreten.
  - ::numeric Cast bei ROUND
  - `percentile_cont()` braucht Cast vor `ROUND`
  - GROUP BY ROLLUP wird nicht unterstützt
  - unknown-Typ bei string_agg ueber UNION-Literale
  - Alias-Kollision: PostgreSQL ist case-insensitiv
  - Dynamisches aktuelles Quartal & Alias-Kollision
  - Quartalsindex `qidx` — Projektstandard
  - Regex-Wortgrenze `\y` scheitert an Unterstrichen
  - LIKE und Backslash: Steuerzeichen nie per LIKE suchen
  - HTML-Erkennung: `%<%>%` ist untauglich
- **[C. Datenmodell-Fallen: Pfade, Bridges, Geldwerte](#c-datenmodellfallen-pfade-bridges-geldwerte)** — Falsche Pfade und Aggregationen. Häufigste Ursache für Prozente >100 % und für leere Ergebnisse.
  - Jahresscharfer Diagnose-JOIN
  - 2-Stufen EBM-Euro-Aggregation
  - Geldwerte: `eurowertincent`, nicht `eurowertahincent`
  - EBM-Codes tragen nichtnumerische Suffixe
  - Patientenliste ≠ Patientengruppe
  - Gruppenpsychotherapie & Patientenschlange (Lessons)
  - Patientenformulare (arzt-direct)
  - PatF-Zählung: kein JOIN zu karteieintragtyp nötig
  - `formulartyp`-Filter: idents vorauflösen, nie `LIKE` im JOIN
  - Textanalysen auf karteieintrag: Basistabelle, nicht View
- **[D. Epochen und Feldrealität der Referenzinstallation](#d-epochen-und-feldrealität-der-referenzinstallation)** — Welche Felder ab wann befüllt sind. Ein Feld im DB-Dump ist keine Zusage, dass Daten drinstehen.
  - Termin-Tabelle erst ab Nov 2025
  - Sperrtage: terminkalendertag statt Dauer-Heuristik
  - Bearbeitungszeitpunkte existieren an der Referenzinstallation nicht
  - Medikamentenverordnung: strukturierte Felder nur Post-Migration
  - Freie Kapazität (forward-looking) — keine Dienstplan-Tabelle
  - Aufgaben-System (aufgabe-Tabelle): oeffentlich/offen sauber filtern
  - Aktivitaets-Sessionisierung: Dichte-Untergrenze beachten
  - Nützliche neue Felder (Zollsoft 03/2026)
- **[E. Fachliche Marker, Codes und Auswahlregeln](#e-fachliche-marker-codes-und-auswahlregeln)** — Wie eine Fragestellung korrekt auf Codes, Kürzel und Kalender abgebildet wird.
  - Echter Behandler ≠ Abrechnungsarzt
  - Code-Discovery empirisch, nicht per Keyword
  - KH-Einweisung: Freitext-Detektor vs. Formular
  - MPSS: `%Chronifizierung%` ist kein Suchkriterium
  - AU-Formulare erkennen
  - Administrative Codes ohne Patientenkontakt
  - GOÄ-Quartal aus Datum ableiten
  - Outlook- und Raumkalender ausschließen
  - Verstorbene Patienten ausschließen
  - TRIM bei Terminart-Kürzel
  - Satzzaehlung in Rechnungs- und Abrechnungstexten
  - DATE-ZS-Filter: Komponenten, Uhrzeit und Opt-in

---

## A. tomedo-Ausführungsumgebung

*Was die tomedo-Statistik-Engine anders macht als eine normale psql-Session.*

### Temp-Tabellen sterben zwischen Runs

tomedo HQL löscht temp-Tabellen zwischen Ausführungen. **Jede SQL-Datei MUSS selbstständig sein** — alle benötigten temps neu aufbauen. Kein Chaining über mehrere Dateien.

### ZS-Tags nur im finalen SELECT

ZS-Filter-Tags (`/*{{Tag:...}}*/`) innerhalb von `CREATE TEMPORARY TABLE` werden von tomedo komplett entfernt (nicht aufgelöst), was zu ungültigem SQL führt (z.B. aufeinanderfolgende AND-Keywords). ZS-Tags dürfen **nur im finalen SELECT** stehen.

### Query-Text-Regeln fuer tomedo-Statistiken: kein Prozentzeichen, ein Semikolon

Im Text einer als tomedo-Statistik hinterlegten Query gilt:

1. **Kein Prozentzeichen — auch nicht in Kommentaren.** Sonst bricht die Ausfuehrung ab mit
   `ERROR: syntax error at or near "%"` samt Positionsangabe. Belegt zweimal in Folge, Ursache waren
   `%(kuerzel)s` (psycopg-Bindparameter) und `LIKE 'Arzeko%'` in **Kommentarzeilen**.
   Wildcards daher ueber `LEFT(TRIM(x), n) = '…'` statt `LIKE`.
2. **Nur ein Semikolon**, das Statement-Ende. Semikolons in Kommentaren sind riskant, falls tomedo den
   Text an `;` in Statements zerlegt.

**Vor der Abgabe pruefen:** Prozentzeichen-Anzahl = 0, Semikolon-Anzahl = 1.

**Konsequenz fuer Python-Queries:** `%(name)s`-Platzhalter sind ausschliesslich im psycopg-Pfad gueltig.
Eine parametrisierte Query kann nicht ohne Umbau in eine Statistik uebernommen werden — sie muss
parameterlos werden (Werte selbst aus der DB holen, z.B. per `EXISTS`/`JOIN`).

### System-Katalog-Queries verboten

`pg_tables`, `information_schema`, `pg_catalog` und andere PostgreSQL-System-Katalog-Tabellen dürfen in tomedo HQL **NIEMALS** abgefragt werden. Sie verursachen einen sofortigen Absturz der tomedo-Anwendung mit Datenbankfehler und erfordern ein Neuladen der lokalen Datenbank. Für Tabellen-/Spaltenexploration stattdessen explorative Queries gegen die bekannten Tabellen verwenden oder im Zollsoft-Datenmodell-Dump nachschlagen.

**Der erlaubte Ersatz: `row_to_json` als Sonde.** Das Verbot der Katalog-Tabellen heisst
nicht, dass ein unbekanntes Schema unzugaenglich waere. Eine Datenzeile als JSON liefert
alle Feldnamen **und** ihre Werte in einem Lauf — und weil das Ergebnis `text` ist,
umgeht es zugleich den Connector-Abbruch bei `boolean`-Rueckgaben (Kategorie A):

```sql
SELECT row_to_json(T)::text AS zeile
FROM unbekannte_tabelle T
LIMIT 3
```

Bei breiten Tabellen gezielt nach Inhalt filtern statt blind `LIMIT` zu nehmen — hier die
Suche nach dem Feld, das ein SQL-Statement traegt, in einer Tabelle mit 108 Spalten:

```sql
SELECT row_to_json(OVE)::text AS zeile
FROM outlineviewelement OVE
WHERE strpos(lower(row_to_json(OVE)::text), 'select ') > 0
LIMIT 2
```

Realfall 2026-08-19: Feldkatalog von `outlineviewelement`, `customstatistikelement` und
beider Bruecken in zwei Laeufen erhoben, ohne Katalogzugriff. Grenze: bei `bytea`- oder
`xml`-Spalten kann die Serialisierung abbrechen — dann ueber Einzel-Idents statt `LIMIT`.


### tomedo-Serializer: TIME-Spalten (Typ 92) brechen den Export

Ein `::time`-Wert im finalen SELECT fuehrt zum Abbruch mit
`Wie serialisieren?  Typ: 92  <spaltenname>` (= `java.sql.Types.TIME`).

Workaround — Tageszeit als Minuten seit Mitternacht rechnen und als Text bauen:

```sql
-- in der CTE:
(EXTRACT(HOUR FROM MIN(ts)) * 60 + EXTRACT(MINUTE FROM MIN(ts)))::int AS start_mod
-- im finalen SELECT:
LPAD((MIN(start_mod) / 60)::text, 2, '0') || ':' ||
  LPAD(MOD(MIN(start_mod), 60)::text, 2, '0')                          AS startzeit
```

Fallback (rein numerisch, garantiert serialisierbar): `ROUND((MIN(start_mod) / 60.0)::numeric, 2)` — Lesart 8.5 = 08:30.

Betrifft `::time`, nicht `::date` und nicht `timestamp` — die serialisieren normal.

### Unplausible Fehlerposition = abgeschnittenes Statement

`ERROR: syntax error at or near "GROUP", Position: 6` bei einer 100-Zeilen-Query ist **kein** Syntaxfehler. Position 6 kann nicht auf ein `GROUP BY` am Ende zeigen. In diesem Fall war das Statement beim Einfuegen in tomedo abgeschnitten worden und begann mitten in der Abfrage.

Regel: passt die gemeldete Position nicht zum gemeldeten Token, **erst die Vollstaendigkeit des eingefuegten Statements pruefen**, bevor Konstrukte verdaechtigt werden. Ich hatte stattdessen `ntile(3) OVER (...)` verdaechtigt und einen Workaround ohne Fensterfunktion gebaut — die Originalabfrage lief beim zweiten Versuch fehlerfrei. Fensterfunktionen sind in tomedo unproblematisch.

---


### Zeitzonenversatz: `NOW()` ist UTC, gespeicherte Zeitstempel sind Lokalzeit

**NOW() liefert UTC, gespeicherte Zeitstempel sind Lokalzeit** — im Sommer ein Versatz von +2 Stunden.
Belegt 2026-08-26 in zwei unabhaengigen Laeufen: `to_char(NOW(),'HH24:MI:SS')` = `19:06:48`,
gleichzeitig `MAX(termin.angelegt)` = `21:02:06`; zweiter Lauf: `karteieintrag.datum` = `12:01`
bei UTC-Uhrzeit `10:04`. Betroffen sind mindestens `termin.angelegt`, `termin.beginn`,
`karteieintrag.datum`, `smsnachricht.timestamp`.

Folge: jedes `WHERE feld >= NOW() - INTERVAL '60 seconds'` ist faktisch ein 2-Stunden-Fenster.
Der Fehler ist **still** — die Query laeuft, liefert aber zu viele Zeilen, und bei
Frische-Pruefungen (Ausloeser-Bedingungen, Monitoring-Cards) ist genau das fatal.

**Regel:** rollende Zeitfenster nie gegen `NOW()`. Stattdessen

- **gespeicherte Zeitstempel gegeneinander vergleichen** (zeitzonenfest, weil aus derselben Uhr):
  `AND k.datum BETWEEN t.angelegt AND t.angelegt + INTERVAL '60 seconds'`
- **Frische ueber den Maximalwert der eigenen Quelle** ankern statt ueber die Systemuhr:
  `AND k.datum >= (SELECT MAX(k2.datum) FROM ... WHERE k2.datum >= CURRENT_DATE) - INTERVAL '60 seconds'`
- **Duplikatsperren an das fachliche Ereignis binden**, nicht an ein Zeitfenster:
  `NOT EXISTS (SELECT 1 FROM smsnachricht s WHERE s.patient_ident = p.ident AND s.timestamp >= t.angelegt)`

`CURRENT_DATE` bleibt als Tagesgrenze brauchbar (der Versatz verschiebt sie nur um zwei Stunden,
was bei `>=`-Vergleichen keine Zeilen verliert). Diagnose in jeder verdaechtigen Query:
`to_char(NOW(),'YYYY-MM-DD HH24:MI:SS')` neben `MAX(<zeitfeld>)` ausgeben und die Differenz ansehen.

## B. PostgreSQL-Fallen

*Dialekt- und Typprobleme, die als Abbruch oder als stiller Zahlenfehler auftreten.*

### ::numeric Cast bei ROUND

`ROUND(double precision, n)` existiert in PostgreSQL nicht. Immer `::numeric` casten:
```sql
ROUND(value::numeric, 2)
-- oder direkt in Temp-Tabelle: END::numeric AS euro
```

### `percentile_cont()` braucht Cast vor `ROUND`

`percentile_cont()` liefert `double precision`:

```sql
ROUND((percentile_cont(0.5) WITHIN GROUP (ORDER BY x))::numeric, 1)
```

### GROUP BY ROLLUP wird nicht unterstützt

`GROUP BY ROLLUP(...)` (und analog `GROUPING SETS`, `CUBE`) wird von tomedos SQL-Schicht **nicht** durchgereicht — sie interpretiert `ROLLUP` als Funktionsaufruf und wirft `ERROR: function rollup(text) does not exist`. Für Zwischen-/Gesamtsummen stattdessen `UNION ALL`: Detailzeilen per `GROUP BY`, Summenzeile als zweiter SELECT ohne `GROUP BY` (mit Konstanten-Label als Gruppen-Spalte), beide über dieselbe CTE. `ORDER BY` per Spaltenposition (`ORDER BY 2 DESC`), da Alias-Bezug über die UNION-Grenze uneinheitlich aufgelöst wird.

### unknown-Typ bei string_agg ueber UNION-Literale

`ERROR: failed to find conversion function from unknown to text`

Ursache: Ein String-**Literal** in einem CTE bleibt untypisiert (`unknown`). Wird die Spalte per `UNION ALL` aus zwei solchen Literalen gebildet, bleibt der Typ `unknown` — beim direkten `SELECT` faellt das nicht auf, aber jede Funktion mit Typ-Auflösung (`string_agg`, `concat_ws`, Vergleiche) bricht ab.

```sql
-- BRICHT
WITH a AS (SELECT 'quelle_a' AS q FROM t1
           UNION ALL SELECT 'quelle_b' FROM t2)
SELECT string_agg(DISTINCT q, ' + ') FROM a;

-- KORREKT
WITH a AS (SELECT 'quelle_a'::text AS q FROM t1
           UNION ALL SELECT 'quelle_b'::text FROM t2)
```

**Regel:** Jedes konstante String-Literal, das als Spalte aus einem CTE/UNION herausgeht, mit `::text` casten. Gleiches Muster fuer `::integer` / `::boolean` bei NULL-Literalen (`NULL::integer AS typ`).

### Alias-Kollision: PostgreSQL ist case-insensitiv

Unquotierte Aliase werden in der FROM-Klausel case-insensitiv behandelt — `L` und `l` sind dieselbe Referenz.
In langen CTE-Ketten durchgängig **mehrzeichige, eindeutige Aliase** verwenden (`LST`, `KVS`, `PDR`).


**Reservierte Wörter als Alias (reproduziert 2026-09-08).** `LEFT JOIN tkowner TO ON TO.tid = T.ident` bricht mit `syntax error at or near "TO"`. `TO` ist reserviertes Schlüsselwort (`GRANT … TO`) und als unquotierter Alias nicht zulässig — obwohl es mehrzeichig und im Statement eindeutig ist, die Regel „mehrzeichige, eindeutige Aliase" also erfüllt. Gleiches gilt für `AS`, `IN`, `IS`, `ON`, `OR`, `ALL`, `END`, `USER`, `ORDER`, `TABLE`.

Die Fehlerposition zeigt auf das **erste** Vorkommen im Statement, nicht auf die fehlerhafte Zeile im Sinne der Lesbarkeit — bei mehrfach verwendetem Alias also weit vor der Stelle, an der man sucht. Abhilfe: dreibuchstabige Sprechkürzel (`TOW`, `KAL`, `TKO`). Nie durch Quoting lösen — `"TO"` funktioniert, macht den Alias aber case-sensitiv und bricht die Konvention.

### Dynamisches aktuelles Quartal & Alias-Kollision

- **Aktuelles Quartal ohne ZS/Datum:** `EXTRACT(QUARTER FROM CURRENT_DATE)::int`, `EXTRACT(YEAR FROM CURRENT_DATE)::int`, Quartalsende `(DATE_TRUNC('quarter', CURRENT_DATE) + INTERVAL '3 months')::date`. Zeitfenster „heute..Quartalsende": `T.beginn >= CURRENT_DATE AND T.beginn < q_ende_excl`. Ideal für selbst-aktualisierende Management-Cards.
- **Alias-Kollision (PostgreSQL/tomedo):** unquotierte Aliase sind case-insensitiv -> `zeitraum Z` und `zuschlag z` kollidieren im finalen FROM: `ERROR: table name "z" specified more than once`. Regel: in Multi-CTE-Joins eindeutige, mehrbuchstabige Aliase (`zr`, `zu`, `i`) vergeben.
- **30700-Prognose-Pattern:** Ist (distinkte abgerechnete Ziffer) + geplanter Zuschlag (distinkte Patienten ohne Ziffer, `NOT EXISTS` gegen die Ziffer-Menge). Übertragbar auf jede „einmal je Quartal"-Pauschale.

### Quartalsindex `qidx` — Projektstandard

Für quartalsübergreifende Sortierung, Differenzen und Lückenerkennung immer ein einziger Integer:

```sql
(EXTRACT(YEAR FROM datum)::int * 4 + CAST(to_char(datum, 'Q') AS int)) AS qidx
```

Jahr und Quartal getrennt zu sortieren bricht über die Jahresgrenze.

### Regex-Wortgrenze `\y` scheitert an Unterstrichen

`\y` behandelt `_` als Wortzeichen — in Kalender- und Listennamen der Form
`<Gruppe>_<Kürzel>_<Jahr>` findet `\y<Kürzel>\y` daher nichts. Explizite Trennerklasse verwenden:

```sql
name ~ ('(^|[ _./-])' || kuerzel || '([ _./-]|$)')
```

### LIKE und Backslash: Steuerzeichen nie per LIKE suchen

In PostgreSQL ist der Backslash das **Standard-Escape-Zeichen fuer LIKE**. `LIKE '%\par%'` degeneriert zu `%par%` und trifft „Sparkasse", „separat", „Apartment". Ebenso unbrauchbar: `LIKE '%{\rtf%'`.

Korrekt ueber `strpos` mit `chr()`-Aufbau:

```sql
strpos(txt, chr(92) || 'par')            > 0   -- \par
strpos(txt, chr(123) || chr(92) || 'rtf') > 0   -- {\rtf
```

### HTML-Erkennung: `%<%>%` ist untauglich

`LIKE '%<%>%'` trifft **E-Mail-Adressen in spitzen Klammern** (`<buchhaltung@...>`), also jede Signatur — gemessene „100 % HTML" waren dadurch bedeutungslos. Echte Tags per Regex pruefen:

```sql
txt ~* '<[[:space:]]*(br|p|div|span|table|tr|td|font|html|body|head|style|img|a[[:space:]]|/)'
```

Zusaetzlich Entities (`&nbsp;`, `&amp;`) und zur Gegenprobe das Adressmuster `<[^<>[:space:]]+@[^<>[:space:]]+>` separat zaehlen.

---

### Idents sind 58 Bit breit — `::text` fuer jeden externen Konsumenten

`termin.ident` und `karteieintrag.ident` folgen `zeitstempel << 19` und sind 58 Bit breit.
Jeder Konsument mit IEEE-754-Double (JavaScript, `float()` in Python, viele BI-Werkzeuge) hat
53 Bit Mantisse und rundet. **Deshalb in jeder Query, deren Ergebnis ein Werkzeug weiterliest
oder verlinkt, `T.ident::text` ausgeben** — nicht nur wegen des Metabase-Link-Dropdowns.

Die Falle schlaegt **heute noch nicht** zu: durch die 19 Nullbits am Ende sind die aktuellen
Idents *zufaellig* exakt darstellbar. Der Fehler wird erst mit einer geaenderten Ident-Vergabe
sichtbar, und dann als Folgefehler an ganz anderer Stelle. `patient.ident` (27 Bit) ist
unkritisch. Konsumentenseitig: `int(str(wert))`, nie `int(float(wert))`.


### Fensterfunktionen: im Connector validiert (31.08.2026)

Der ZSStatistikFetchSQLConnector vertraegt Fensterfunktionen vollstaendig. Am Realfall
Q-ZUW-2026-01/-02/-03 gegen Echtdaten belegt:

| Konstrukt | Beispiel | Status |
|---|---|---|
| Fenster **ueber einem Aggregat** | `SUM(COUNT(DISTINCT patid)) OVER (PARTITION BY sicht, jahr)` | laeuft |
| kumulative Summe | `SUM(x) OVER (ORDER BY x DESC, key ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)` | laeuft |
| `ROW_NUMBER()` mit `PARTITION BY` als Per-Group-Limit | `ROW_NUMBER() OVER (PARTITION BY jahr ORDER BY patienten DESC, key)` + `WHERE rang <= 25` | laeuft |
| `DISTINCT ON` mit **Ausdruck** | `DISTINCT ON (TRIM(lanr)) … ORDER BY TRIM(lanr), (CASE WHEN visible THEN 0 ELSE 1 END), ident` | laeuft |
| bedingtes DISTINCT-Zaehlen | `COUNT(DISTINCT CASE WHEN jahr = 2025 THEN patid END)` | laeuft |
| Aggregat **ueber** Fensterwert | `MIN(CASE WHEN kum_pct >= 80 THEN rang END)` in aeusserem `GROUP BY` | laeuft |

Zwei Anwendungsregeln:

- **Boolean nur in `CASE`, nie in `ORDER BY`-Ausgabe und nie als Spalte** — der Serializer
  bricht weiter an Boolean-Spalten. Im `ORDER BY` einer `DISTINCT ON`-Klausel ist
  `(CASE WHEN visible THEN 0 ELSE 1 END)` der sichere Weg.
- **Prozentspalten sind der fragilste Teil.** Wenn eine Query mit Fenster-ueber-Aggregat
  bricht, zuerst die Prozentspalten streichen und die Anteile im Konsumenten rechnen — die
  Zaehlspalten allein laufen praktisch immer.

Achtung Leseartefakt: Ein Fenster ueber `PARTITION BY` liefert fuer **jede** Gruppenzeile
einen Wert, auch fuer Zeilen, die nicht in den Nenner gehoeren. Bei einem Nenner
„Zugewiesene" erhaelt die Zeile „Selbstzuweiser" dadurch einen Prozentwert ueber 100 — das
ist kein Fehler, sondern eine Spalte, die fuer diese Zeile nicht gilt. Entweder per `CASE`
auf NULL setzen oder im Konsumenten ignorieren.

### `TRIM()` entfernt keine Zeilenumbrüche

`TRIM(x)` schneidet **nur Leerzeichen** ab. Ein `\n` am Anfang oder Ende bleibt stehen. Wer
`length(TRIM(x))` als Kürze-Kriterium und gleichzeitig `strpos(x, chr(10)) > 0` als
Mehrzeiligkeits-Kriterium benutzt, klassifiziert Fünf-Zeichen-Texte als mehrzeilig.

Zwei Konsequenzen:

- Mehrzeiligkeit erst ab einer Mindestlänge prüfen: `strpos(x, chr(10)) > 0 AND length(x) > 60`
- Wirklich alles wegschneiden: `TRIM(both E' \t\r\n' FROM x)`

`chr(10)` ist der zuverlässige Zeilenumbruch-Detektor in der tomedo-Statistik — Literale mit
Escape-Sequenzen sind es nicht.

### Regex-Operator `~` läuft im tomedo-Connector

Belegt am 2026-08-25: `t ~ '[0-9]{4}'` und `t ~ '[0-9]{1,2}/[0-9]{2}'` liefen ohne Abbruch in
einer Statistik-Query. Der Operator ist damit als Alternative zu langen `strpos`-Ketten
verfügbar. Weiterhin gilt aber: kein Prozentzeichen im Query-Text, und die Wortgrenze `\y`
scheitert an Unterstrichen (siehe unten).

Vorsichtsregel für den Bau: einen Block mit dem einzigen Regex-Operator **zuletzt** stellen und
eine operatorfreie Ersatzvariante auskommentiert daneben legen. Bricht er ab, kosten die
vorherigen Blöcke nichts.


### `ORDER BY` mit Alias-Arithmetik bricht ab

```
ERROR: column "termine" does not exist
```

bei einer Query, in der `termine` sichtbar als Alias im SELECT steht. Ursache:
**Ausgabe-Alias in ORDER BY nur als nackte Spaltenreferenz** erlaubt — sobald er in einem
**Ausdruck** steht, gilt der Namensraum der Eingangsrelation, und dort existiert der Alias nicht.

```sql
-- bricht ab
SELECT COUNT(*) AS termine, COUNT(x.ident) AS mit_protokoll
...
ORDER BY termine - mit_protokoll DESC

-- korrekt: Ausdruck ausschreiben
ORDER BY COUNT(*) - COUNT(x.ident) DESC

-- ebenfalls korrekt: Alias nackt
ORDER BY termine DESC
```

Gleiches gilt für `GROUP BY`. Wer die Differenz sortieren **und** anzeigen will, gibt sie als
eigene Spalte aus (`COUNT(*) - COUNT(x.ident) AS luecke`) und sortiert über den ausgeschriebenen
Ausdruck — nicht über `luecke` in einem Ausdruck.

**Diagnosehinweis:** meldet PostgreSQL eine Spalte als nicht existent, die im SELECT sichtbar
ist, ist fast immer ein Alias an einer Stelle verwendet, an der er nicht sichtbar ist. Nicht die
Spalte suchen, sondern die Verwendungsstelle.

## C. Datenmodell-Fallen: Pfade, Bridges, Geldwerte

*Falsche Pfade und Aggregationen. Häufigste Ursache für Prozente >100 % und für leere Ergebnisse.*

### Jahresscharfer Diagnose-JOIN

Wenn Diagnosen auf eine Patientenpopulation mit Jahresspalte gejoint werden, MUSS der JOIN auf **beide** Spalten erfolgen:
```sql
-- RICHTIG:
JOIN tempPat30700 T ON T.patientID = P.ident AND T.jahr = S.jahr
-- FALSCH (>100%-Bug):
WHERE P.ident IN (SELECT patientID FROM tempPat30700)
```

### 2-Stufen EBM-Euro-Aggregation

`MAX(DET.euroWertInCent)` in `SUM()` funktioniert nicht in einer Stufe wegen Bridge-Duplikaten. Pattern: Stufe 1 = Euro pro Leistung (GROUP BY A.ident), Stufe 2 = SUM pro Patient. Siehe `references/query-bausteine.md` §21.

### Geldwerte: `eurowertincent`, nicht `eurowertahincent`

`leistung.eurowertahincent` existiert an der Referenzinstallation **nicht** — korrektes Feld ist `eurowertincent`.
GOÄ-Eurobetrag pro Leistungszeile:

```sql
kostenincent::numeric * anzahl / GREATEST(COALESCE(anzahlnenner, 1), 1) / 100
```

`GREATEST(COALESCE(...,1),1)` ist Pflicht: `anzahlnenner` ist teils NULL, teils 0 — sonst Division durch Null.

### EBM-Codes tragen nichtnumerische Suffixe

Codes wie `35176H` verschwinden still bei `code IN ('35176', ...)`. Robust immer über den numerischen Stamm:

```sql
substring(code from '^[0-9]+') IN ('35173','35176','35225')
```

### Patientenliste ≠ Patientengruppe

Die in tomedo unter **Panel → Patientenliste** sichtbaren manuellen Listen (Wartelisten, Gruppentherapie-Teilnehmer, Arbeitslisten) stecken in `patientenschlange` + `patientenschlangeelement` (Bridge: `patientenschlange_schlange`). NICHT in `patientengruppe` — das ist ein separates Abrechnungsgruppen-Feature. Filter für manuelle Listen: `PS.dtype = 'Patientenschlange'`.

### Gruppenpsychotherapie & Patientenschlange (Lessons)

- **EBM-H-Suffix:** Grundversorgungs-/Probatorik-Gruppencodes treten mit Suffix auf (`35176H`). Exaktes `IN ('35176',…)` verfehlt sie → auf führende Ziffern matchen: `substring(B.code from '^[0-9]+') IN (...)`.
- **Gruppen-Code-Set (Tier 1 = „Sitzung abgerechnet"):** Probatorik-Gruppe `3516x` (letzte Ziffer = TN), Grundversorgung `3517x`, KZT-VT-Gruppe `3554x` (+ Zuschlag `3559x`). Tier 2 (Vorphase, NICHT zählen): 35140/41/50/51/52, 35600. Ausschluss Einzel: 35421, 35591. Referenz: `EBM-Gruppenpsychotherapie-Codeset.md`.
- **Regex-Wortgrenze `\y` scheitert am Unterstrich** (Underscore ist ein Wortzeichen) → für Kürzel-Parse aus Freitext explizite Trennklasse: `~* '(^|[ _./-])ruw([ _./-]|$)'`.
- **Datum aus Freitext-Namen:** `substring(name from '\d{1,2}\.\d{1,2}\.\d{2,4}')` + `to_date(...,'DD.MM.YY'|'DD.MM.YYYY')`; fehlendes Jahr aus `element.datum` ergänzen.
- **Leiterzuordnung von Gruppen:** `termin.behandler` ist bei Gruppenterminen leer (0%), `termin.dokumentierendernutzer_ident` = Anleger/MFA (nicht Leiter). Kalender-Parallel-Slot ist Artefakt (freie-Zeit statt Leitung). **Verlässliche Leiterquelle = `patientenschlange.name`.**

### Patientenformulare (arzt-direct)

Antworten in `formularelement` (bezeichner=Feldname, wert=Antwort), NICHT in CustomKarteiEintragEntry. Pfad: angefordertesjsonformular → karteieintrag (dtype=Formular, KE-Typ FOR) → karteieintrag_formularelemente → formularelement.


#### tagbox-Felder: Mehrfachauswahl steht kommagetrennt in einem Wert

Ein `formularelement.wert` eines tagbox-Feldes enthaelt **alle** gewaehlten Tags als
kommagetrennte Liste in einer Zelle, nicht als mehrere Zeilen. Realbefund `vorop-kh-reha`:
`ops` 273 · `ops, krankenhausaufenthalte, rehabilitationen` 271 · `ops, krankenhausaufenthalte`
182 · `ops, rehabilitationen` 77 · `keine` 236 · leer 247.

Ein Gleichheitsvergleich `wert = 'ops'` findet also 273 von 804 Faellen mit diesem Tag.
Richtig ist Teilstringpruefung: `strpos(lower(wert), 'ops') > 0`. Vorsicht bei kurzen Tags,
die in anderen Tags vorkommen — Tagliste vorher per Frequenzabfrage erheben, nicht raten.

Zweite Regel aus demselben Befund: **Freitextfelder neben der tagbox tragen die
Spezifikation.** `vorop-kh-reha` sagt nur „operiert", die Koerperregion steht in `op1`–`op4`
als Freitext (`blinddarm`, `galle`, `lws 4/5`). Wer die tagbox allein als Kriterium nimmt,
misst eine viel breitere Menge als beabsichtigt.

### PatF-Zählung: kein JOIN zu karteieintragtyp nötig

Für die Zählung von arzt-direct-Formular-Rückschrieben reichen drei Filter auf `karteieintrag` selbst, der JOIN zu `karteieintragtyp` ist überflüssig und war in Q-PatF-Count v1 die Fehlerursache (`typ_ident` existiert nicht — korrekter Spaltenname wäre `karteieintragtyp_ident`, aber selbst der wird hier nicht gebraucht).

**Minimalpattern:**

```sql
FROM karteieintrag k
JOIN formulartyp ft ON ft.ident = k.formulartyp_ident
WHERE k.visible        = true
  AND k.dtype          = 'Formular'
  AND k.jsonformsource = 1                       -- arzt-direct-Rückschrieb
  AND ft.name         LIKE 'Patientenformular_%' -- nur PatF
```

**Zusatzbeobachtung:** `k.dokumentierendernutzer_ident` ist bei arzt-direct-Rückschrieben systematisch `NULL` (Aggregation liefert `versender = 0`). Das ist kein Datenfehler, sondern Architektur: der Patient ist „Autor", kein tomedo-Nutzer hat den Eintrag dokumentiert. Nicht als Filter verwenden.

### `formulartyp`-Filter: idents vorauflösen, nie `LIKE` im JOIN

Ein `formulartyp.name LIKE '...'` im JOIN gegen `karteieintrag` kostet mehrere Minuten Laufzeit. Stattdessen die
idents in einem CTE vorauflösen und mit `IN` filtern:

```sql
WITH ft AS (SELECT ident FROM formulartyp WHERE name LIKE 'Patientenformular_%')
SELECT ... FROM karteieintrag k WHERE k.formulartyp_ident IN (SELECT ident FROM ft)
```

### Textanalysen auf karteieintrag: Basistabelle, nicht View

**Die View `karteieintragwithplaintext` hat nur 15 Spalten**, die Basistabelle rund 40. `datenmodell.md` fuehrt beide unter einer gemeinsamen Ueberschrift mit **einer** Spaltenliste — die Liste gehoert zur Basistabelle. Wer sie auf die View bezieht, laeuft in `ERROR: column ... does not exist`. Gegenprobe: der DB-Dump nennt fuer die View explizit „15 Spalten".

**`karteieintrag.serveronlyplaintext` ist praktisch unbrauchbar.** Das Feld existiert auf der Basistabelle, ist aber im **aeusseren SELECT nicht projizierbar** (`ERROR: column k.serveronlyplaintext does not exist`, Position zeigt auf die Projektion). Innerhalb eines CTE funktioniert es. Passend zum Namen „serveronly". Regel: gar nicht verwenden, Nutzlast steht in `karteieintrag.text`.

---


### Clientname ist nicht Arbeitsplatzname

`nachricht.absenderarbeitsplatz` traegt den vom Client gemeldeten Rechnernamen, `arbeitsplatz.name` den gepflegten Inventarnamen. Beide folgen derselben Konvention, sind aber **nicht identisch**: der Client meldet ohne Gruppenpraefix und ohne Rollensuffix.

| gemeldet | im Inventar |
|---|---|
| `SZW-B-061` | `IND-SZW-B-061` |
| `SZW-A-000` | `COT-SZW-A-000-ANM` |

Ein Gleichheits-Join auf `name` liefert dadurch fast nur Nulltreffer — **ohne Fehlermeldung**. Die Query laeuft durch und meldet ein plausibel aussehendes Ergebnis, in dem alle Arbeitsplaetze unbenutzt wirken.

Korrekt ueber den Kern-Token verbinden:

```sql
COALESCE(
  substring(upper(TRIM(feld)) from 'SZ[WN]-[A-Z0-9]+-[A-Z0-9]+'),
  upper(TRIM(feld))) AS ap_key
```

Der `COALESCE`-Zweig faengt Werte ohne Token ab (Pseudo-Eintraege wie `Standard`), damit sie nicht stillschweigend verschwinden.

**Gegenprobe nicht vergessen:** gemeldete Namen, zu denen kein Inventareintrag existiert, sind Geraete, die tomedo nutzen und in keiner Bestandsrechnung auftauchen. Beide Richtungen pruefen, nicht nur die vom Inventar aus.

## D. Epochen und Feldrealität der Referenzinstallation

*Welche Felder ab wann befüllt sind. Ein Feld im DB-Dump ist keine Zusage, dass Daten drinstehen.*

### Termin-Tabelle erst ab Nov 2025

Die Termin-Tabelle (`termin`) ist erst seit der tomedo-Migration (November 2025) befüllt. Alle historischen Aktivitätsanalysen müssen über EBM-Leistungen und KV-Scheine laufen.

### Sperrtage: terminkalendertag statt Dauer-Heuristik

Ganztags-Sperren (Urlaub, Krank, Feiertag, Teamtag, Elternzeit) liegen ab Migration in `terminkalendertag.sperrmodus = 1`, **nicht** als 300-min-Blocker-Termin. Die alte Heuristik (`patient_ident IS NULL` + Dauer ≥300 min) findet moderne Sperren nicht und ist nur fuer Pre-Migrations-Epochen zu verwenden.

Zwei Fallen:
- **`terminkalendertag` hat eine Zeile pro Kalender × Tag, auch fuer freie Tage** (`sperrmodus=0`, `info='serverseitig'`). Ohne `sperrmodus = 1` matcht jeder Tag.
- **Die Tabelle fehlt in `datenmodell.md`-Altversionen** und stand nur im ZOLLSOFT-DB-Dump. Bei „Feld/Tabelle nicht gefunden" immer gegen `datenmodell_ZOLLSOFT_DB-dump.md` gegenpruefen.

Sperrgrund kommt aus `kalendersperrmodus.name`, Feiertag/Abwesenheit trennt `kalendersperrmodus.isfeiertag`.

**Die Sackgasse `termin` + `terminart.typ = 3` nicht erneut betreten.** Eine fruehere Fassung suchte
Sperrtage als Ganztagstermine und lieferte immer null Zeilen — unentdeckt falsch, weil ein leeres
Ergebnis von einem korrekten „nichts gesperrt" nicht zu unterscheiden ist. Gemessen (08/2026):
genau **1** `terminart` mit `typ = 3` (`visible = false`), **keine** mit einer Bezeichnung im
`Arzeko`-Namensraum, **0** zukuenftige Ganztagstermine bei **59.570** zukuenftigen Terminen.
Sperrtage sind in `termin` gar nicht modelliert.

Konsequenz fuer jede Sperr-Query: **Sollwerte vor dem Lauf festlegen** und gegen Zaehlungen pruefen,
nicht gegen den Augenschein einer Ergebnisliste (siehe `daten-opener`, Nullmengen-Blindheit).

### Bearbeitungszeitpunkte existieren an der Referenzinstallation nicht

tomedo protokolliert an der Referenzinstallation **nur Anlagezeitpunkte, keine Bearbeitungszeitpunkte**. Zwei Felder, die das leisten sollten, sind leer — beide 2026-07-29 auf Echtdaten validiert:

- **`karteieintrag.letzteaenderungam` = NULL, ausnahmslos.** Geprueft an 1.024/1.024 Zeilen. Das Feld ist in `datenmodell.md` als „Letzte Aenderung (fuer Dokumentationsanalysen)" beschrieben — fuer die Referenzinstallation ist das **falsifiziert**. Nie als Zeitachse verwenden.
- **`karteieintrag.druckdatum` = NULL bei 616/617** bearbeiteten Eintraegen (RECHN, MAIL-Ein, NACHR, ABR-ALT, DIA). Einziger Treffer: 1 MED-Eintrag. Als Erzeugungs-Proxy unbrauchbar.

**Konsequenz fuer Nutzer-Aktivitaetsanalysen:** Eintraege, bei denen ein Nutzer nur `letzternutzer_ident` ist (nicht `dokumentierendernutzer_ident`), sind **zeitlich nicht verortbar**. Man weiss *dass*, nicht *wann*. Bei rechnungsnahen Rollen betrifft das die Kerntaetigkeit — jede Arbeitszeitschaetzung ist dadurch systematisch nach unten verzerrt.

**Zeitachse quellenspezifisch waehlen, nicht einheitlich `datum`:**

| Rolle des Nutzers am KE | Korrekte Zeitachse | Warum |
|---|---|---|
| `dokumentierendernutzer_ident` | `karteieintrag.datum` | Anlagezeitpunkt, traegt echte Uhrzeit |
| `letzternutzer_ident` (nur bearbeitet) | keine verfuegbar | `datum` waere das Rechnungs-/Dokumentdatum, nicht die Bearbeitung |


**`karteieintrag.termin_ident` ist leer — dritter Non-Find derselben Familie.** Validiert 2026-09-08 über alle 49 Nutzerkürzel: **0 von 281.034** Karteieinträgen im Fenster 11/2025–09/2026 tragen einen Terminbezug, auch bei Disziplinen, die ihre Termine selbst anlegen. Das Feld ist damit weder für Attributionsfragen (welche Disziplin verursacht einen Karteieintrag) noch für Anwesenheitssignale nutzbar.

Praktische Regel für Nutzer- und Attributionsanalysen an der Referenzinstallation: von den drei naheliegenden Verknüpfungen zwischen Dokumentation und Zeitachse — `letzteaenderungam`, `druckdatum`, `termin_ident` — trägt **keine**. Verwertbar bleiben nur `datum` bei `dokumentierendernutzer_ident` sowie die Zeitstempel auf `termin` selbst (`angelegt`, `geaendert`, jeweils mit `dokumentierendernutzer_ident` bzw. `aenderndernutzer_ident`). Letztere sind das einzige Ereignispaar, an dem administrative Arbeit mit intrinsischem Disziplinbezug hängt.

### Medikamentenverordnung: strukturierte Felder nur Post-Migration

Die strukturierten Felder von `medikamentenverordnung` sind ein **Post-Migrations-Artefakt** (ab Nov 2025):
- `avpbeiverordnung` > 0: nur ~34 % (2023–25), 82 % (2026).
- `wirkstaerkebeiverordnung`, `mengebeiverordnung`, `atcbeiverordnung`: ~0 % (2023/24), ~5 % (2025), ~82 % (2026).
- `pzn`: nur ~16–20 % historisch. `wirkstoffnamebeiverordnung`: ~5 %.
- **`namebeiverordnung`: 98–100 % über alle Jahre** → einziger historisch tragfähiger Medikamenten-Schlüssel.

**Konsequenz für Within-Patient-Historie:** rohe AVP/MME über die Migrationsgrenze = Confound.
Pattern **standardisierte Kosten/MME**: Referenzwert je Wirkstoff aus Post-Migration (Median) ×
historische Menge; Wirkstoff-Klassifikation via kuratierter `CASE` auf `lower(namebeiverordnung)`.
Opioid-Detektion historisch über Freitext-Namensmuster (nicht ATC).

**Feld-Korrektur:** `wirkstaerkebeiverordnung` existiert (DB-Dump), fehlt aber in `datenmodell.md` →
DB-Dump ist maßgeblich.

**TEXT-Parser (robust genug für Median):** Stärke `substring(feld from '[0-9]+[.,]?[0-9]*')` + Komma→Punkt;
Menge `substring(feld from '[0-9]+')`, Packungscodes via `trim(feld) ~* '^n[0-9]'` verwerfen.

### Freie Kapazität (forward-looking) — keine Dienstplan-Tabelle

„Freie Stunden / Lücken im Arbeitstag" hat in tomedo **keine eigene Dienstplan-/Sprechzeiten-Tabelle**. Die verfügbare Zeit *sind* die Ressourcen-Termine (`terminart.infotermin=true` / `typ=1`). Rechnung: **freie Minuten = Ressourcen-Minuten − belegte Patientenminuten**, pro (Arzt × Ressource). Forward-looking-Variante von §18 (Auslastung):

- **Fenster vorwärts:** `T.beginn >= CURRENT_DATE AND T.beginn < DATE 'Quartalsende+1'` (statt `< CURRENT_DATE` wie bei No-Show §30).
- **Zukunfts-Sperrzeiten weiterhin abziehen** (§17): Urlaub/Feiertag liegt als Sperrzeit *über* dem bestehenden Ressourcenblock — sonst erscheinen Urlaubstage als „frei".
- **Schlüssel-Alignment (zentrale Falle):** Belegung VOR der Subtraktion über `terminart.terminresourceverbindung_ident` auf die Ressource zurückführen. Mehrere Buchungs-Terminarten zeigen auf eine Ressource (real: `G`,`WV`,`Gespr`,`NTWeichteil` → `SprSt`). Naives Gruppieren beider Seiten nach Kürzel ⇒ Key-Mismatch ⇒ falsche Differenz.
- **Ressource nie über Kürzel filtern:** Paar-Terminarten mit identischem Kürzel existieren (z.B. `AP` als Ressource *und* buchbar). Ressource = `infotermin=true`/`typ=1`.
- **Gruppentherapie-Raumkalender ausschließen** (`kalender.nutzer_ident IS NULL`): 1-Min-Slot-Workaround macht Minuten-Differenz sinnlos (>100% Auslastung systembedingt).
- **Anonym by design:** Auswertung braucht keine Patientenidentität — `patient_ident` nur als `IS NOT NULL`-Flag für „belegt".

### Aufgaben-System (aufgabe-Tabelle): oeffentlich/offen sauber filtern

Die `aufgabe`-Tabelle (Mitarbeiter-Aufgaben/Tickets) hat zwei undokumentierte, aber praxisrelevante Steuerfelder — beide 2026-06-19 per Echtdaten + Abhaken-Test validiert:

- `availability`: **0 = oeffentlich** (Checkbox im Dialog), **1 = persoenlich**, NULL = System-Vorlage. Klarer 31/69-Split (kein Default-Rauschen).
- `status`: **NULL = offen**, **1 = erledigt** (Abhaken setzt NULL->1, protokolliert in `laststatuschange` + Log „Offen->Fertig").
- `erdedigungstyp`: 0 = von einem, 1 = von allen.

**Achtung Datenqualitaet:** `availability=0` enthaelt viel operatives Rauschen (leere Titel, „neue Vorlage", „Aufgabe aus Nachricht", „Bitte Arztbrief…", „Physio Vo erstellen…"). Fuer eine saubere Agenda zusaetzlich `TRIM(aufgabentitle) <> ''` und ggf. Titel-Blacklist setzen.

**Verantwortliche-JOIN** (Kuerzel): `aufgabe -> aufgabe_verantwortliche(aufgabe_ident) -> verantwortliche_ident -> aufgabenempfaenger -> nutzer.kuerzel`. Mehrere Verantwortliche per `string_agg(DISTINCT NV.kuerzel, ', ')`.

**Agenda-Rezeptur (Q-AUFGABE-AGENDA-01):**
```sql
WHERE A.removed = false
  AND A.availability = 0          -- oeffentlich
  AND A.status IS NULL            -- offen
  AND COALESCE(A.archivedinkartei,false) = false
  AND TRIM(A.aufgabentitle) <> ''
ORDER BY A.priority DESC, A.erstelltam DESC   -- priority hoeher = wichtiger
```


**Patientenbezug und Richtung (2026-08-24, 5.144 Aufgaben ab 11/2025):**

- `aufgabe.patient_ident` ist optional, an der Referenzinstallation aber zu **83,5 Prozent befuellt** (Aerzte 96,7 · Physio 94,5 · Psycho 66,7). Patientenebene ist damit gangbar.
- **Selbstaufgaben dominieren den Arzt-an-Arzt-Kanal.** Von 799 Arzt-an-Arzt-Aufgaben bleiben nach `empfaenger <> ersteller` nur wenige uebrig; ein Arzt fiel von 220 auf 4. Ohne diesen Filter misst der Kanal Arbeitsstil, nicht Kollegenkommunikation.
- Eine Aufgabe mit mehreren Empfaengern erscheint im Verantwortlichen-JOIN mehrfach — immer `COUNT(DISTINCT aufgabe.ident)`.
- Richtungsbild an der Referenzinstallation: Therapeut an Arzt 192, Arzt an Therapeut 77. Der groesste Einzelstrom ist Physio an Verwaltung (998, Verordnungsablauf) und damit kein Ruecksprachesignal.

Konsequenz: Als Ruecksprachemass taugt der Kanal nur mit Empfaengerrolle **und** Selbstaufgaben-Ausschluss, und auch dann nur fuer die Richtung Therapeut an Arzt.

### Aktivitaets-Sessionisierung: Dichte-Untergrenze beachten

Sessionisierung von Nutzer-Events (Gap-Schwelle bricht Session) ist nur ab **~9 Events pro aktivem Tag** belastbar. Darunter kollabiert das Modell: bei 5–8 Events/Tag erreicht das Verhaeltnis Tages-Span zu Session-Netto Faktoren bis **15,8** (gemessen: 6 aktive Tage, 20 Events, 2,2 h Session gegen 34,8 h Span). Bei 21 Events/Tag sinkt das Verhaeltnis auf 2,2.

Praxisregel: Monate mit <9 Events/aktivem Tag im Ergebnis als „nicht belastbar" markieren, nicht wegrechnen.

Gap-Schwelle **nicht** auf einen Wert festlegen — Sensitivitaet 30/45/60/90 min mitfuehren. Die Untergrenze variiert dadurch um Faktor 1,7. Engste Konvergenz von Session und Span (und damit realistischste Untergrenze) lag bei G=90.

### Nützliche neue Felder (Zollsoft 03/2026)

- `termin.isneuerpatient` (boolean) — Neupatient-Flag, **an der Referenzinstallation ungepflegt, NICHT als Neupatienten-Kriterium verwenden**: auf der buchbaren Terminart `Neu` (676 Termine/120 Tage) steht es durchgaengig auf `false`, gesetzt ist es stattdessen bei internen Terminarten (Besprechung 194, Org/Doku 81, Blocker 37). Neupatienten-Erkennung stattdessen ueber `terminart` mit `infotermin = false` und Kuerzel `Neu`/`Neu_ÄiW` (Messung 2026-08-26)
- `termin.angelegt` (timestamp) — Erstellungszeitpunkt, für Vorlaufzeit-Analyse
- `nutzer.asrenabled` (boolean) — Spracherkennung aktiviert
- `nutzer.lanr` (text) — LANR direkt auf Nutzer
- `nutzer.leistungserbringer` (boolean) — Ist abrechnungsberechtigter Arzt
- `nutzer.psychotherapiequalifikation_ident` → psychotherapiequalifikation
- `patientendetails.statuspsychotherapiefall` (0/1/5/10) — PT-Fall-Status
- `patientendetails.datumletzterbesuch` (timestamp) — Letzter Besuch
- `patientendetails.beschaeftigungsstatus_ident` → beschaeftigungsstatus (Erwerbsstatus)
- `terminart.typ` (0=Termin, 1=Ressource, 2=Sperrbereich, 3=Ganztagsart) — differenzierter als infotermin
- `terminart.laenge` (integer) — Standard-Terminlänge in Minuten
- `medikamentenverordnung.dokumentierendernutzer_ident` → Verordner
- `besuch.ankunft`/`besuch.ende` (timestamp) — Für Wartezeitanalysen
- ⛔ `karteieintrag.letzteaenderungam` / `.druckdatum` — **an der Referenzinstallation leer** (1024/1024 bzw. 616/617 NULL, gemessen 07/2026).
  tomedo protokolliert keine Bearbeitungszeitpunkte. Dokumentationszeit nur über Sessionisierung von `datum` (query-bausteine §35).

---

### Terminaenderungen sind nur als Untergrenze rekonstruierbar

`termin` fuehrt **keine Aenderungshistorie**. Es gibt genau zwei Ein-Slot-Felder:

| Feld | Inhalt | Fallstrick |
|---|---|---|
| `geaendert` | Zeitpunkt der **letzten** Aenderung | wird bei jeder weiteren Bearbeitung ueberschrieben |
| `aenderndernutzer_ident` | Nutzer der **letzten** Aenderung | dito — der vorherige Bearbeiter ist verloren |
| `angelegt` | Erstellungszeitpunkt | `geaendert - angelegt < 2 min` = Neuanlage, keine Aenderung |
| `verschiebeoderloeschunggrund` | Freitext, nur wenn erfasst | an der Referenzinstallation meist leer |

Konsequenz fuer jede Forensik-Frage („wer hat wann was verschoben"): das Ergebnis ist eine
**Untergrenze**. Jeder Termin, den nach dem gesuchten Nutzer noch jemand angefasst hat, faellt
aus der Treffermenge. Das gehoert in jede Rueckmeldung, sonst wird die Liste als vollstaendig
gelesen.

Ausserdem unterscheiden die Felder **nicht**, *was* geaendert wurde. Zeitverschiebung,
Terminartwechsel, Kalenderwechsel und Notizaenderung sehen identisch aus. Eine Query auf
„verschobene Termine" im engen Sinn ist ueber `termin` nicht formulierbar — nur „von X am Tag Y
angefasste Termine".

**Negativbefund `terminaenderungfuernachricht` (Referenzinstallation, gemessen 2026-08-23).** Die Tabelle traegt
mit `art`, `aenderungsdatum` und `altdatenjson` theoretisch den Vorher-Zustand und waere die
einzige Journalquelle. Fuer die geprueften Aenderungen eines vollen Tages in einem
Behandlerkalender lieferte sie **null Zeilen**. Sie ist an den Versand von
Aenderungsbenachrichtigungen gekoppelt und damit kein Protokoll, sondern ein Postausgang.
Planungsregel: **den Vorher-Zustand nicht ueber diese Tabelle einplanen.** Vor jedem Bau, der
darauf aufsetzt, erst ein Sounding auf Zeilenexistenz fahren.

Wiederherstellung eines verschobenen Termins ist damit aus der Live-DB nicht moeglich. Bleibende
Wege: DB-Backup des Vortags, versendete Terminbestaetigungen an Patienten, Gedaechtnis des
Behandlers.


### Zuweiserfeld auf dem KV-Schein erst ab 2022 (31.08.2026)

`kvschein.ueberweisenderarzt` ist an der Referenzinstallation vor 2022 praktisch unbefuellt — und zwar
**unabhaengig** von der Migration 11/2025, also eine eigene Epochengrenze:

| Jahr | Scheine | mit Zuweiserangabe |
|---|--:|--:|
| 2019 | 8.678 | 2 |
| 2020 | 9.365 | 1 |
| 2021 | 12.695 | **0** |
| 2022 | 12.854 | 431 |
| 2023 | 13.514 | 759 |
| 2024 | 15.246 | 920 |
| 2025 | 16.617 | 1.217 |
| 2026 (bis 08.) | 12.401 | 851 |

Null Treffer bei 12.695 Scheinen heisst **unbefuellt**, nicht „keine Zuweisungen". Jede
Zuweiseraussage vor 2022 ist nicht rechenbar; das auswertbare Fenster ist 2022 bis heute.
Ursache offen (Umstellung der Scheinerfassung gegen Migrationsverlust).

Auch im befuellten Fenster tragen nur **6 bis 7 Prozent aller Scheine** eine
Zuweiserangabe, weil der Zuweiser einmalig auf dem Erstschein erfasst wird. Das ist kein
Pflegemangel, sondern die Erfassungslogik — und der Grund, warum eine Jahresscheinsicht als
Selbstzuweiserquote unbrauchbar ist.

Aufloesungsquote ueber den LANR-Arztgruppenschluessel im befuellten Fenster: 98,6 bis
99,7 Prozent (2022–2025), 2026 auf 96,4 Prozent gefallen — steigende Freitexteingabe statt
Stammsatzauswahl.

### Diagnosetypen: Epochenbrüche und Zukunftsdaten

**DDI war vor 2025 praktisch unbenutzt.** Einträge je Jahr: 2016 = 1 · 2022 = 413 · 2023 = 182 ·
2024 = 91 · 2025 = 4.650 · 2026 = 7.358 (bis August). Der Sprung ist ein Werkzeugwechsel, keine
Zunahme von Dauerdiagnosen. Jede Dauerdiagnosen-Quote über einen Zeitraum vor 2025 misst die
Nichtnutzung des Feldes.

**DIAX hat einen Bruch innerhalb des Typs.** 1998 bis 2024 durchgehend befüllt (1.776 bis 5.825
je Jahr), aber **ohne Diagnose-Satz** — reiner Freitext-Karteieintrag. Erst 2026 tragen 1.094 von
1.586 Einträgen einen Diagnose-Satz. Ein Jahresvergleich 2025 gegen 2026 wäre auf diesem Typ ein
Artefakt.

**Der KE-Typ DIAX trägt eine Snowflake-ident** (`177858585046286336`), DIA und DDI dagegen
Legacy-Idents (13 und 12). Das Typ-Objekt wurde bei der Migration neu angelegt, die Historie
wurde ihm zugeordnet. **Aus einer Snowflake-ident folgt nicht, dass der Typ neu ist** — diese
Fehlannahme hatte im Projektwissen zu der falschen Aussage geführt, DIAX sei mit der Migration
verschwunden.

**Zukunftsdatierte Diagnosen.** Am Stichtag 25.08.2026 lag der letzte DDI-Eintrag auf dem
16.10.2026, der letzte DIA-Eintrag auf dem 28.08.2026. Bei jeder Stichtagsauswertung am
aktuellen Rand eine Obergrenze auf `CURRENT_DATE` setzen.


### Tenure und Eintrittsdatum: kein Feld, drei Proxys, zwei Fallen

**Negativbefund:** `nutzer` hat **kein Eintritts- oder Qualifikationsdatum**; `berufsbezeichnung` ist an der Referenzinstallation durchgehend leer. Beschaeftigungsdauer und Berufserfahrung sind aus tomedo nicht direkt ableitbar. Wer danach sucht, sucht umsonst.

Rekonstruierbar ist die **fruehste Spur**, aus drei Quellen mit unterschiedlicher Reichweite:

| Proxy | Reichweite | Einschraenkung |
|---|---|---|
| erste EBM-Leistung als `leistungserbringer_ident` | volle Historie | verunreinigt durch KV-Fallzahlumschichtung; bei Physio unbrauchbar (4 bis 30 Leistungen) |
| erster klinischer Karteieintrag (`SCHMA`/`THE`/`PHY`/`BEF_PHY`) | fuer Physio durchgehend, fuer Aerzte erst ab 2025 | `SCHMA` ab 09/2025, `THE` ab 06/2025 — als Arzt-Tenure systematisch zu spaet |
| erster Karteieintrag beliebigen Typs | scheinbar am weitesten | **unbrauchbar**, siehe unten |

**Datums-Sentinelwerte 1900-01.** `karteieintrag.datum` enthaelt Import- und Platzhalterwerte: an der Referenzinstallation `1900-01` fuer zwei Aerzte, dazu Migrationsdaten ab 1999 fuer weitere. Ein `MIN(datum)` ohne Typfilter liefert damit systematisch zu frueh. Jede minimumbasierte Erstkontakt- oder Tenure-Bestimmung braucht eine untere Plausibilitaetsschranke, z.B. `datum >= DATE '2015-01-01'`.

**Validierung ist Pflicht, nicht Kosmetik.** Der kombinierte Proxy (Minimum aus EBM- und klinischer KE-Spur, aggregiert ueber `TRIM(kuerzel)`) traf an der Referenzinstallation die Aussenangabe auf Monatsebene: 0,9 gegen 1,0 Jahre und 0,3 gegen 0,5 Jahre bei den beiden jungen Aerzten. Ohne diesen Abgleich ist ein Tenure-Proxy nicht berichtsfaehig.


### MAIL-Aus: kein Termin-Bezug, kein Nutzer-Bezug

**MAIL-Aus traegt keinen Termin-Fremdschluessel** — `karteieintrag.termin_ident` ist bei diesem
KE-Typ zu **0 von 15.556** Einträgen befüllt (07/2026: 0 von 6.392; 08/2026: 0 von 9.164).
Damit ist der einzige validierte Direkt-FK von der Kartei zum Termin für Kommunikations-KE
wertlos. Eine terminscharfe Auswertung von Erinnerungsmails läuft ausschliesslich über
`termin_terminerinnerungen → terminerinnerung`.

**Merksatz:** ein validierter Direkt-FK ist keine Zusage für alle KE-Typen. Befüllungsgrad
immer **je KE-Typ** prüfen, nicht global —
`COUNT(*) FILTER (WHERE k.termin_ident IS NOT NULL)` gegen `COUNT(*)` je `karteieintragtyp`.

**86,9 Prozent der MAIL-Aus haben `dokumentierendernutzer_ident IS NULL`** — in beiden
Messmonaten identisch (5.553 von 6.392 bzw. 7.967 von 9.164). Das ist der automatische
Erinnerungsversand; die restlichen rund 13 Prozent sind manuell verschickte Mails mit
Nutzerzuschreibung. Nutzerbezogene Mailanalysen laufen daher zwangsläufig nur auf dem manuellen
Anteil.

**`termin.behandler` ist praxisweit leer**, nicht nur bei Gruppenterminen: 1.406 von 1.406
geprüften Terminen über alle Terminarten (08/2026). Behandlerzuordnung über
`termin_kalender → kalender.nutzer_ident`.

**`infotermin = false` allein ist kein Patientenfilter.** Im Fenster 21.08.–10.09.2026 trugen
4.060 Termine `infotermin = false`, aber nur **2.524 einen Patienten**. Die Differenz sind
Organisationseinträge (UNBEKANNT 1.057, Org, Blocker, Besprechung, Pause, Tagesliste, Doku),
Gruppenkalender ohne Patientenbindung sowie drei Terminarten, die als Farbmarker missbraucht
werden (Bezeichnung „T-Shirt kurz": `beere`, `türkis`, `hellgrün`). Für Patientenpopulationen
deshalb immer zusätzlich `t.patient_ident IS NOT NULL`.

## E. Fachliche Marker, Codes und Auswahlregeln

*Wie eine Fragestellung korrekt auf Codes, Kürzel und Kalender abgebildet wird.*

### Echter Behandler ≠ Abrechnungsarzt

`leistungserbringer_ident` auf EBM-Leistungen ist der **Abrechnungsarzt**, nicht der behandelnde Arzt. Bis zu 500 Fälle werden wegen KV-Fallzahllimit und Fachgebietsregeln umgeschichtet.

**Echter Behandler** über Karteieintragstyp + `dokumentierenderNutzer_ident`:
- `<TYP-A>` — Alt-Typ, endet mit der Umstellung
- `<TYP-B>` — Nachfolger, ab Umstellung aktiv
- `<TYP-C>` — Paralleltyp, kleiner Bestand

Alle kombinieren, sonst fehlt der Umstellungszeitraum; die eigenen Kürzel vorab ermitteln
(siehe `datenmodell.md`, Abschnitt Therapiezeilen-Kürzel). `arzt_ident` ist bei allen = 0.

**Zwei Ausnahmen, in denen direkt attribuiert werden darf:**
- **GOÄ:** `leistung.leistungserbringer_ident` ist sauber — kein KV-Fallzahllimit, also keine Umschichtung.
- **Psycho-EBM (35xxx / 232xx):** `leistung.dokumentierendernutzer_ident` ist direkt valide, weil PT ihre Sitzungen
  selbst dokumentieren und die Codes rechtlich an die Approbation gebunden sind.


> **mutabo-Stubs blaehen T-basierte Zaehlungen auf (validiert 2026-08-13).** Der KE-Typ `T` enthält an der Referenzinstallation
> nicht nur Therapiezeilen, sondern auch die Fragebogen-Rückschrieb-Stubs des Alt-Systems: 4.783 von 38.213
> T-Einträgen in 2024 sind Stubs, also **12,5 Prozent**. Verlauf 2022–2025: 174 · 5.394 · 4.783 · 3.496, danach
> Abbruch durch die Migration.
>
> Wirkung: Jede Kontakt-, Therapie- oder Behandlerzählung über `T` ist in den Jahren 2022–2025 überhöht und
> zeigt nach 11/2025 einen scheinbaren Aktivitätsrückgang, der reiner Systemwechsel ist. Pflichtausschluss:
>
> ```sql
> AND strpos(lower(k.text), 'mutabo') = 0
> ```
>
> Das gilt auch für die zusammengesetzte Attributionsregel `T` + `SCHMA` + `THE`. Vor jeder Zeitreihe über
> T-Einträge den Stub-Anteil pro Jahr mit ausgeben, nicht nur herausfiltern — sonst ist die Korrektur später
> nicht nachvollziehbar.


### Code-Discovery empirisch, nicht per Keyword

Keyword-Codesets sind systematisch unvollständig. Im B72-Thread fehlte der dominierende spinale Eingriff
(GOÄ **469**, Kaudalanästhesie), weil das Kürzel nichts über den Text verrät. **Regel:** erst die eigenen
Abrechnungsdaten nach Häufigkeit gruppieren (query-bausteine §22 GOÄ-Explorer), dann das Codeset festlegen.
Eigene Abrechnungsdaten schlagen jede Keyword-Heuristik.

### KH-Einweisung: Freitext-Detektor vs. Formular

Für die praxisseitig veranlasste KH-Einweisung gibt es zwei Signale mit klarer Rollenteilung:

- **Muster-2-Formular** (`formulartyp='Krankenhausbehandlung'`) = belastbar, aber erst ab Sep 2025.
- **Freitext Therapiezeile** (die praxiseigenen Therapiezeilen-Typen, Term `%einweis%`/`%eingewiesen%`) = das saubere „wir haben eingewiesen"-Signal, migrationsübergreifend ab 2019. **Negationsrate nur ~1,9 %** (48/2.534 KE) — praktisch frei von „keine Einweisung".

**Nicht** als Detektor verwenden:
- `%krankenhaus%` / `%klinik%` im Freitext — dominiert von False Positives (Anamnese-Historie, verneinte/geplante Fälle, Klinik-Namen in Briefköpfen, eingehende Briefe). In `ANA` (Anamnese, ~9.000 Treffer) und `PSY` (Journal) sitzt fast nur Rauschen → ausschließen.
- KE-Typ `KRH` = eingehende Klinikpost, nicht eigene Einweisung.

**Kalibrierung:** Recall der Therapiezeile gegen das Muster-2-Formular (Overlap ab Sep 2025) = **46 %** (188/406). Historische Rohzahlen sind damit eine **Untergrenze**; der Recall lag vor der Migration vermutlich höher (Therapiezeile oft einziger Dokumentationsort). Korrektur-Korridor bis ~×2,16.

**Zeittrend-Falle:** Freitext-basierte Jahres-Serien steigen mit der Dokumentationsdichte — der Anstieg ist ein Artefakt, kein realer Ereignisanstieg. Nur den Gradient zwischen Gruppen interpretieren, nicht die Trajektorie.

### MPSS: `%Chronifizierung%` ist kein Suchkriterium

`text ILIKE '%Chronifizierung%'` matcht Basisgruppen-Textbausteine und produziert Falsch-Positive.
Für das Mainzer Stadienmodell nur `%MPSS%` und `%Gerbershagen%` (PSY-Freitext 04/2024–10/2025, Regex-Trefferquote
99,7 %) bzw. CKEE `name='MPSS'` (ab ~11/2025).

### AU-Formulare erkennen

```sql
formulartyp.name IN ('AU', 'FortbestehenAU', 'PrivateAU')
```
Ergibt nur **eigene** AUs — Untergrenze.

### Administrative Codes ohne Patientenkontakt

40110 (Versandmaterial), 86901 (Labor-Kostenpauschale) — bei WV-Zählung oder Kontaktzählung ausschließen.

### GOÄ-Quartal aus Datum ableiten

GOÄ-Leistungen haben kein `kvschein.quartal`:
```sql
CAST(to_char(A.datum, 'Q') AS integer) AS quartal
```

### Outlook- und Raumkalender ausschließen

~3.967 importierte Outlook-Termine verfälschen jede Kapazitäts- und Behandlerauswertung.
Therapeutenkalender: `K.nutzer_ident IS NOT NULL`. Raum-/Gruppenkalender (`NULL`) nur bewusst für
Gruppenanalysen zuschalten.

### Verstorbene Patienten ausschließen

```sql
AND P.nachname NOT ILIKE '%†'
```

### TRIM bei Terminart-Kürzel

Terminart-Kürzel haben teils trailing Spaces. Bei Vergleichen immer:
```sql
TRIM(TA.kuerzel) IN ('AP', 'Bespr-Ä', ...)
```

### Satzzaehlung in Rechnungs- und Abrechnungstexten

Satzenden ueber `[.!?]` zu zaehlen ist bei kaufmaennischen Texten **grob dreifach ueberhoeht**. Ursachen: Datumsangaben (`07.07.2026` = zwei Scheingrenzen), Betraege (`1.234,56`), Abkuerzungen (`Nr.`, `z.B.`, `ggf.`, `zzgl.`, `inkl.`).

Belegt an einem realistischen Satz mit Rechnungsnummer, Datum und Betrag: **7 Satzenden ohne Maskierung, 2 mit.** Gemessene Satzlaengen von 5,4 und 8,5 Woertern waren dadurch unplausibel; nach Korrektur 9,0 bis 17,6.

Maskierungskette **nur fuer die Zaehlfassung**, nicht fuer den Analysetext:

```sql
regexp_replace(
  regexp_replace(
    regexp_replace(txt, '([0-9])\.', '\1', 'g'),          -- Punkt nach Ziffer
    '(Nr|z\.B|zB|ggf|bzw|zzgl|inkl|ca|evtl|Dr|Tel|Abs|Str|u\.a|d\.h)\.', '\1', 'gi'),
  '\.\.+', '.', 'g')
```

Kontrolle: bleibt die Satzlaenge unter 8 Woertern, ist die Abkuerzungsliste unvollstaendig. Zeichen, Woerter, Wortlaenge und Absatzzahl duerfen sich durch die Maskierung **nicht** aendern — sonst lief sie faelschlich auf dem Analysetext.

### DATE-ZS-Filter: Komponenten, Uhrzeit und Opt-in

Bei DATE-Typ ZS-Filtern kein trailing Semikolon: die Assertion `[comps count] == 5` zaehlt den
Typ-Token `DATE` mit, also genau vier Semikolons im Tag.

Zwei weitere Fallen, belegt 2026-09-19 (zwei Laeufe):

- **c1 ist kein Tagesoffset, sondern ein Vorzeichenschalter auf die Uhrzeit** (≤ 0 → aktuelle
  Uhrzeit, > 0 → 23:59). Das Datum steht immer auf heute; eine relative Vorbelegung wie
  „Monatsanfang" ist mit DATE nicht moeglich → `SELECTION` mit `date_trunc` verwenden.
- **Expansion ist `( c3 'Datum' ) c4`**, c3 traegt Spalte **und** Operator
  (`P.geburtsdatum >=`). Die Form `…;Spalte;Operator` erzeugt `( Spalte '…' ) >=` und bricht.

Details und Referenzmuster: `references/zs-filter.md`.

---


### Q4/2025: Auslastung und Anlaufkurven sind dort nicht messbar

Ressourcenbloecke sind fuer Q4/2025 vollstaendig vorhanden, Buchungen aber erst ab 11/2025.
Jede Auslastung (gebucht durch Kapazitaet) faellt dort deshalb auf 0,35–0,47 — **bei allen
Behandlern gleichzeitig**. Das ist ein Migrationsartefakt, kein Anlauf und keine Auslastungs-
schwaeche. Gleichmaessigkeit ueber alle Behandler ist das Erkennungsmerkmal: eine echte
Auslastungsaenderung trifft nicht neun Personen im selben Quartal identisch.
Konsequenz: Zeitreihen zur Auslastung erst ab 01/2026 beginnen; das erste vollstaendige
Quartal nach der Migration ist Q1/2026.

### Wiederkehrquote nicht aus dem Beharrungszustand ableiten

Verlockend und falsch: aus konstanter Fallzahl und Neupatientenzahl auf die Wiederkehrquote
schliessen (`r = 1 − Neu·y / (Faelle − Sockel)`). Realbefund der Referenzinstallation 2026-09-01: die so
abgeleiteten Werte lagen **um bis zu gut dreissig Prozentpunkte** ueber den gemessenen
(Einzelwerte je Behandler siehe `praxis-interna.md`). Der Denkfehler ist der fehlende Term
„Rueckkehrer nach Luecke“ — bei einem der geprueften Behandler ist er groesser als der
Wiederkehrterm selbst: eine Wiederkehrquote von rund 0,6 bei zehn Neupatienten je Quartal
und trotzdem stabiler Fallzahl ist unter einem Markov-Modell arithmetisch unmoeglich.
Belastbar ist nur die **direkte Messung** des Quartalsuebergangs (Baustein 38d) oder das
Modell **Panel × Aktivierungsrate**: Panel = distinkte Patienten des Behandlers im Fenster,
p = Faelle je Quartal geteilt durch Panel. Beide Groessen sind behandlerspezifisch und
quasi-fix (Spanne der Referenzinstallation p = 0,40 bis 0,73 bei gleicher Fallzahl).

### Ressourcen-Layout bindet nicht automatisch

Ein Ressourcenblock im Kalender ist eine Absicht, keine Schranke. Realbefund der Referenzinstallation 2026:
die Sprechstundenressource wird zu 51–100 Prozent genutzt, waehrend Neupatienten (bis 226
Prozent) und Behandlungen (bis 732 Prozent) in sie ueberlaufen. Wer aus dem Layout auf den
tatsaechlichen Terminmix schliesst, rechnet mit einer Groesse, die die Anmeldung taeglich
umgeht. Jede Kapazitaets- oder Mixaussage aus Ressourcenbloecken braucht deshalb den
gemessenen Buchungsgrad je Kategorie als Bruecke (Baustein 38b).

### Begriffskataloge im Freitext brauchen Positivkontrolle und Spezifitaetsvergleich

Drei Regeln, jede an einem Fehlschlag belegt:

1. **Positivkontrolle im Katalog.** Immer zwei Begriffe mitfuehren, die in nahezu jedem Eintrag
   vorkommen muessen (fachlich etwa `schmerz`, allgemein `patient`). Schlagen sie nicht an, ist das
   Textfeld nicht als Plaintext lesbar und der ganze Lauf ungueltig — ohne die Kontrolle sieht das
   Ergebnis wie ein inhaltlicher Nullbefund aus. `karteieintrag.text` ist an der Referenzinstallation lesbar
   (Kontrolle `schmerz` bei 93,8 bis 99,7 Prozent der Patienten).
2. **Immer gegen eine Vergleichsgruppe.** Ein Trefferanteil allein ist bedeutungslos. `hausarzt`
   erscheint bei 12,5 Prozent der Zielgruppe und 15,9 Prozent der Vergleichsgruppe — Routine-
   vokabular, kein Signal. Nur der Ueberschuss zaehlt.
3. **Klinische Homonyme ausschliessen.** `beschwerde` trifft die Symptomdokumentation, nicht die
   Reklamation (40,6 gegen 55,6 Prozent). Ebenso unbrauchbar sind `reha`, `stationaer` und
   `empfehlung` als Marker fuer eine Weiterverweisung: alle drei sind Standardvokabular des
   Verlaufs. Bekanntes Gegenstueck: `Chronifizierung` matcht Basisgruppen-Textbausteine und darf
   nie als MPSS-Kriterium dienen.

Negativbefund zur Planung: **eine Fallabschluss- oder Beendigungsentscheidung ist in tomedo an
der Referenzinstallation nirgends strukturiert erfasst** — kein Karteieintragstyp und kein Feld tragen sie, und im
Freitext erscheint sie in unter 10 Prozent der betroffenen Faelle. Auswertungen, die auf
„aktiv beendet gegen abgebrochen" angewiesen sind, muessen das vorab als Nichtverfuegbarkeit
einplanen und nicht als Suchproblem behandeln.


### Terminart-Kürzel sind nicht eindeutig — Ressource vs. buchbarer Termin

**Terminart-Kuerzel existieren doppelt: Ressource und buchbarer Termin** tragen an der Referenzinstallation dasselbe
Kuerzel und unterscheiden sich nur ueber `infotermin`. Messung 2026-08-26 (120 Tage):

| Kuerzel | Bezeichnung | `infotermin` | Anzahl | Rolle |
|---|---|---|---|---|
| `Neu` | Neupatienten | true | 3.843 | Kapazitaetsblock |
| `Neu` | Erstgespraech Schmerztherapeut | false | 676 | buchbarer Patiententermin |
| `Neu_ÄiW` | Erstgespraech Schmerztherapeut ÄiW | false | 163 | buchbarer Patiententermin |
| `EG` | Erstgespraech PSY | true | 1.236 | Kapazitaetsblock |
| `EG` | Erstgespraech Psychotherapie | false | 162 | buchbarer Patiententermin |

Ein Filter `TRIM(ta.kuerzel) IN ('Neu')` ohne `infotermin = false` mischt Kapazitaetsblock und
Patiententermin und ueberzeichnet die Fallzahl um Faktor 6. Umgekehrt gilt: in patientenbezogenen
Kommandos (`patientenTermine`) ist die Dublette unschaedlich, weil Kapazitaetsbloecke keinen
Patienten tragen.


### Negationsphrase enthaelt die Positivphrase — Klassifikation je Objekt, nicht je Patient

Wer `keine op-indikation` und `op-indikation` in derselben Aggregation als zwei Flags
berechnet, erhaelt fuer jeden Verneinungsfall **beide** Flags: die Negationsphrase enthaelt
die Positivphrase als Teilstring. Die Kreuzklasse „beide" wird dadurch bedeutungslos und
faengt in Wahrheit alle Verneinungen ein.

Regel: erst **je Objekt** (Karteieintrag, Leistung, Zeile) klassifizieren, dabei die
Verneinung dominieren lassen, und erst danach je Patient aggregieren.

```
ke_klass: neg = 1 wenn Verneinungsphrase; erw = 1 wenn Positivphrase UND neg = 0
pat_klass: MAX(erw) und MAX(neg) ueber alle Objekte -> vier saubere Klassen
```

Realbefund 2026-08-13 (Kohorte OP-Indikation): mit korrekter Ebene 22 Patienten der Klasse
„beide" statt 308 — die naive Fassung haette jede Verneinung als Widerspruchsfall gemeldet.
Grenze der Methode: stehen Bejahung und Verneinung im **selben** Objekt („NCH stellte die
Indikation, aus unserer Sicht besteht keine"), zaehlt es nur als Verneinung. Satzebene ist mit
`strpos` nicht aufloesbar; das ist als Caveat mitzufuehren.


> ### Freitext-Kennzahlen: Schreibvarianten und Nutzerkonzentration
>
> **Schreibvarianten zusammengesetzter Fachbegriffe immer summieren.** Reproduziert 2026-08-13 am Wortfeld
> OP-Indikation: `op-indikation` fiel 2024→2026 von 213 auf 52, `op indikation` ohne Bindestrich stieg
> gleichzeitig von 37 auf 99; bei der Verneinung 84→17 gegen 18→41. Die Summe läuft glatt. Ursache mutmaßlich
> Diktat- und KI-gestützte Dokumentation, die keine Bindestriche setzt. Eine Einzelvariante hätte einen
> Einbruch von 80 Prozent gezeigt, der nicht existiert.
>
> Regel: Bindestrich-, Getrennt- und Zusammenschreibung sowie Langform gemeinsam messen (`op-indikation`,
> `op indikation`, `operationsindikation`, `indikation zur operation`) und die Variantenverteilung je Jahr
> mit ausgeben, nicht nur die Summe.
>
> **Nutzerkonzentration vor der Verwendung prüfen.** Ein Begriff mit auffälliger Jahreskonzentration ist bis
> zum Gegenbeweis die Wortwahl eines Einzelnen. Realfall: `op-vermeidung` hatte 21 von 22 Treffern in 2024
> und danach null — 17 davon von einem Arzt in einem halben Jahr. Aufschlüsselung nach
> `dokumentierendernutzer_ident` ist deshalb Teil der Begriffsvalidierung, nicht der Nachanalyse.
>
> **Kontaminationsgegenprobe ist Pflicht.** Bei Eingriffs- und Prozedurbegriffen misst man ohne Gegenprobe
> überwiegend die Vorgeschichte. Realfall: Eingriffsnamen (`dekompression` 326 Patienten, `spondylodese` 194)
> lagen in derselben Größenordnung wie die Z.n.-Marker (`z.n. op` 183, `postoperativ` 188, `nach der op` 198).
> Eingriffsnamen taugen daher nicht als Einschlusskriterium ohne Negativbedingung.
>
> **Anhangsinhalte sind nicht erreichbar.** KE-Typen `DOK-ALT`, `SCAN`, `DOK` tragen nur Bildunterschriften
> (76–213 Zeichen); `datei.content` ist an der Referenzinstallation durchgehend NULL, die Binärdateien liegen nur im
> Serverdateisystem. Inhalte eingescannter Fremdbriefe sind per SQL **grundsätzlich** nicht auswertbar — das
> ist eine Blindstelle und darf nicht als Nullbefund gezählt werden. Textführend bei eingehender Post sind
> `MAIL-Ein` (1.800–2.200 Zeichen) und `ÜBW`.


### Zaehleinheitenwechsel verschiebt Ratenverhaeltnisse um eine Groessenordnung

Eine Relation, die auf Karteieintragsebene gemessen wurde, darf nicht als Patientenrelation
berichtet werden — und umgekehrt. Beide Seiten des Verhaeltnisses aendern sich beim
Ebenenwechsel unterschiedlich stark, weil Patienten unterschiedlich viele Eintraege tragen und
Vieltraeger genau die Gruppe sind, in der der Suchbegriff wahrscheinlicher vorkommt.

Realbefund 2026-08-13: „Anteil der Eintraege mit Suchbegriff unter Eintraegen mit
Zuweiserbezug gegen alle Eintraege" ergab 15,7 gegen 0,7 Prozent, also Faktor 22. Dieselbe
Frage auf Patientenebene mit korrektem Nenner ergab 148,8 gegen 64,2 je 1.000, also
**Faktor 2,3**. Die Richtung hielt, die Groessenordnung nicht.

Konsequenz fuer die Praxis: bei jeder Quote die Zaehleinheit **im Kennzahlnamen** fuehren
(„je 1.000 Patienten", „Anteil der Eintraege"), und vor jeder externen Verwendung pruefen, ob
Zaehler und Nenner dieselbe Einheit haben. Exploratorische Zahlen auf Objektebene sind
Hinweise auf eine Richtung, keine berichtsfaehigen Relationen.


### Eingriffsname traegt kein Tempus — Vorgeschichte und Empfehlung sind nicht trennbar

Ein Eingriffsname im Freitext (`spondylodese`, `nukleotomie`, `dekompression`, `versteifung`)
belegt **nicht**, dass der Eingriff stattgefunden hat. In Anamnesen steht er ebenso haeufig
als empfohlener oder geplanter Eingriff. Wer ihn als „voroperiert"-Flag verwendet, zaehlt
geplante Operationen mit.

Realbefund 2026-08-13 in `ANA`: die Spalte Eingriffsname wuchs von 12 (2014) auf 202 (2024)
Treffer pro Jahr, waehrend die Marker-Variante (`z.n. op`, `voroperiert`) bei 4 bis 24 blieb.
Der Anstieg folgt der zunehmenden fachchirurgischen Zuweisung, also den **geplanten**
Eingriffen — nicht einer Zunahme voroperierter Patienten.

Regel: Vergangenheitsbezug braucht einen eigenen Marker im selben Satzkontext
(`z.n.`, `st.p.`, Jahresangabe vor dem Eingriff, `operiert`) oder eine strukturierte Quelle.
Umgekehrt gilt: ein reiner Markerzwang unterzaehlt massiv — `operiert` plus Organkontext fand
35 bis 89 Faelle pro Jahr, `z.n. op` nur 4 bis 24. Beide Arme getrennt ausweisen und den
Abstand als Messfehlerschaetzung berichten.

## F. Praxis-Codetabellen (lokal)

Dekodierte Hauscodes stehen in keinem Herstellerkatalog: eigene GOÄ-Ziffern, Terminarten,
Kalendersperrmodi, Gruppenlisten-Namensschemata. Sie sind **je Praxis verschieden** und
gehören deshalb nicht in ein Referenzkorpus, sondern in eine lokale Datei.

**Vorgehen:** eigene Codes einmal dekodieren und als `references/praxis-lokal.md` neben diesen
Skill legen. Einstieg über die tatsächlich abgerechneten Ziffern statt über den Katalog:

```sql
SELECT g.ziffer, count(*) AS anzahl, round(avg(g.eurowertincent)/100.0, 2) AS eurowert_avg
FROM goaeleistung g
WHERE g.ziffer !~ '^[0-9]{3,5}$'      -- alles, was keine regulaere GOAe-Ziffer ist
GROUP BY g.ziffer
ORDER BY anzahl DESC;
```

Was dabei herauskommt — Bedeutung, Honorar, wer die Ziffer nutzt — ist Praxiswissen und bleibt
lokal. Eine Zuordnung „Ziffer gehört zu Behandler X" sollte dort nur stehen, wenn sie
abrechnungstechnisch nötig ist; als Analysemerkmal genügt die Ziffer.
