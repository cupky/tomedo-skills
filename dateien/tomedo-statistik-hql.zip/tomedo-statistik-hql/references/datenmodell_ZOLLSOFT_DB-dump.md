# tomedo Datenmodell — Tabellenreferenz

> **Automatisch generiert** aus der tomedo-Datenbank.
> Felder in `Backticks` = exakter Bezeichner in der Datenbank. Nicht umbenennen!
> ⚠ **Datenschutz:** `nachname`, `vorname`, `geburtsdatum` NIEMALS im finalen SELECT an die KI zurückmelden.

---

## 1. Patient & Stammdaten

### adresse
> Adressen werden immer nur von einem einzigen Objekt referenziert, auch wenn zum Beispiel die Mitglieder einer Familie
> an derselben Adresse zu finden sind, wird fuer jedes Mitglied der Familie die Adresse separat gespeichert.
> Diese Eigenschaft wird clientseitig ausgenutzt, um das Abgleichen mit der lokalen Datenbank zu beschleunigen.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bundesland` | text |  |
| `land` | text | Laendercode laut Entity "Land". |
| `ort` | text |  |
| `plz` | text |  |
| `postfach` | text |  |
| `strasse` | text | kann Hausnummer bereits enthalten. fuer PD.kontaktdaten.adresse immer ohne Hausnummer |
| `hausnummer` | text |  |
| `adresszusatz` | text |  |

### adressversion
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `dataversion` | text |  |
| `installdate` | timestamp |  |
| `schemaversion` | text |  |

### arbeitgeber
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `berufsgenossenschaft_ident` | bigint | FK → `berufsgenossenschaft` |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `associatedfirma_ident` | bigint | FK → `patient` |
| `freshdeskident` | bigint |  |

### bereinigtetelefonnummer
> serveronly

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `telefonnummer` | text |  |
| `patient_ident` | bigint | FK → `patient` |

### beschaeftigungsstatus
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `erwerbstaetig` | boolean |  |
| `freitext` | text |  |
| `letzteaktualisierung` | timestamp |  |
| `ueberwiegendgeistig` | boolean |  |
| `ueberwiegendsitzend` | boolean |  |
| `woechentlichearbeitszeit` | real |  |
| `arbeitsunfaehig` | boolean |  |
| `berufsunfaehig` | boolean |  |
| `erwerbsgemindert` | boolean |  |

### custompatientrelationship
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `reversename` | text |  |
| `name` | text |  |
| `relayskartei` | boolean | NOT NULL |
| `removed` | boolean | NOT NULL |

### emergencyeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `date` | timestamp |  |
| `info` | text |  |
| `message` | text |  |
| `emergencytype_ident` | bigint | FK → `emergencytype` |

### emergencytype
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `audiosignal` | boolean |  |
| `beschreibung` | text |  |
| `color` | text |  |
| `icon` | text |  |
| `infotemplate` | text |  |
| `name` | text |  |
| `removed` | boolean | NOT NULL |
| `userdefinedinfo` | text |  |
| `audiodatei_ident` | bigint | FK → `datei` |
| `allearbeitsplaetze` | boolean |  |
| `allenutzer` | boolean |  |
| `betriebsstaettenflag` | smallint |  |
| `blockablebyruhemodus` | boolean |  |

### familienversicherung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `hauptversichertergeburt` | timestamp |  |
| `hauptversichertername` | text |  |
| `hauptversicherternamenszusatz` | text |  |
| `hauptversichertertitel` | text |  |
| `hauptversichertervorname` | text |  |
| `removed` | boolean | NOT NULL |
| `adresse_ident` | bigint | FK → `adresse` |
| `hauptversichertergeschlecht` | text |  |
| `hauptversichertervnummer` | text |  |
| `hauptversicherterverwandtschaft` | text |  |

### kartendaten
> Kartendaten und Unterklassen enthalten sowohl orginalgelesenen Daten (soweit nicht anders kommentiert)
> s. Klassendiagramm KVK_EGK

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `geburtstag` | text | Format ist TTMMJJJJ (auch fuer EGKs) wobei auch die Ersatzwerte 00MMJJJJ. und 0000JJJJ fuer unbekannten Tag und unbekannten Monat moeglich sind. aus B02: "Anlass ist die Ausgabe von Versichertenkarten mit unvollstaendigen Geburtsdaten" |
| `gueltigbis4110` | text |  |
| `ik` | text |  |
| `kassenname` | text | fuer EGK ist dies der Wert Versicherungsschutz-Kostentraeger-Name |
| `nachname` | text | ⚠ Nicht im finalen SELECT |
| `namenszusatz` | text |  |
| `ort` | text |  |
| `plz` | text |  |
| `removed` | boolean | NOT NULL |
| `strasse` | text |  |
| `titel` | text |  |
| `versichertennummer` | text | ⚠ Nicht im finalen SELECT. enthaelt Versichterten-ID bei eGK |
| `versichertenstatus4112` | text |  |
| `versichertenstatus_rsa` | text |  |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `zulassungsnummermobileslesegeraet4108` | text |  |
| `statusergaenzungostwest` | text |  |
| `vknrwop` | text |  |
| `ersatzverfahrentyp` | integer | 0 = kein EV, 1 = KVK, 2 = EGK, 3 = Ueberweisungsschein, 4 = Sonstiger Behandlungsausweis (zum Beispiel Polizei). Gibt an, von welcher Quelle die Daten eines evtl. Ersatzverfahrens erhoben wurden.. zu 4: Fuer Patienten, die mit einem Behandlungsausweis der Sonstigen Kostentraeger in die Praxis. kommen (Polizei, Bundeswehr, Asylstelle) bzw. Patienten, die nur eine Ueberweisung dabei haben. |
| `erstelltam` | timestamp |  |
| `geschlecht` | text |  |
| `abrechnenderkostentraeger` | text |  |
| `abrechnenderkostentraegername` | text |  |
| `anschriftzusatz` | text |  |
| `besondere_personengruppe` | text |  |
| `cdmversion` | text |  |
| `dmp_kennzeichnung` | text |  |
| `gueltigbis` | text |  |
| `gueltigvon` | text |  |
| `kartengeneration` | text |  |
| `kostenerstattung_ambulant` | text |  |
| `kostenerstattung_stationaer` | text |  |
| `kostentraeger` | text |  |
| `krankenkassenlaendercode` | text |  |
| `postfachort` | text |  |
| `postfachplz` | text |  |
| `postfachpostfach` | text |  |
| `postfachwohnsitzlaendercode` | text |  |
| `rechtskreis` | text |  |
| `strassenadressehausnummer` | text |  |
| `strassenadressestrasse` | text |  |
| `vorsatzwort` | text |  |
| `wop` | text |  |
| `zuzahlungsstatus` | text |  |
| `zuzahlungsstatus_gueltigbis` | text |  |
| `aktuelleskartenlesedatum_ident` | bigint | FK → `kartenlesedatum` |
| `patient_ident` | bigint | FK → `patient` |
| `privatkasse_ident` | bigint | FK → `krankenkasse` |
| `ersatzverfahrenabgerechnet` | boolean |  |
| `abrechnenderkostentraegerlaendercode` | text |  |
| `kostenerstattung_aerztlicheversorgung` | text |  |
| `kostenerstattung_veranlassteleistungen` | text |  |
| `kostenerstattung_zahnaerztlicheversorgung` | text |  |
| `ruhenderleistungsanspruch_art` | text |  |
| `ruhenderleistungsanspruch_beginn` | text |  |
| `ruhenderleistungsanspruch_ende` | text |  |
| `selektivvertraege_aerztlich` | text |  |
| `selektivvertraege_art` | text |  |
| `selektivvertraege_zahnaerztlich` | text |  |
| `versichertenart` | text |  |
| `xml_gvd` | text |  |
| `xml_pd` | text |  |
| `xml_vd` | text |  |
| `landcode` | text |  |
| `bishernurmobilgelesen` | boolean |  |
| `plzzurbedruckung` | text |  |
| `postfachplzzurbedruckung` | text |  |
| `anschriftabgabestelle` | text |  |
| `anspruchsart` | text |  |
| `hausnummer` | text |  |
| `kartennummer` | text |  |
| `kostenanteilbefreit` | text |  |
| `kostentraegerik` | text |  |
| `kostentraegername` | text |  |
| `postfachnummer` | text |  |
| `postfachtext` | text |  |
| `rezeptgebuehrenbefreit` | text |  |
| `stocktuernummer` | text |  |
| `versichertenkategorie` | text |  |
| `versicherungstraeger` | text |  |
| `kostentraegerlandcode` | text |  |
| `bundeslandkostentraeger` | text |  |
| `hauptversichertergeschlecht` | text |  |
| `hauptversicherternachname` | text |  |
| `hauptversicherternummer` | text |  |
| `hauptversichertervorname` | text |  |
| `hauptversichertergeburtstag` | text |  |
| `ccrcarddata` | text |  |
| `versichertennummeronline` | text |  |

### kartenlesedatum
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `jahr` | integer | NOT NULL |
| `quartal` | integer | NOT NULL |
| `kartendaten_ident` | bigint | FK → `kartendaten` |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `pn_datum` | timestamp |  |
| `pn_ergebnis` | text |  |
| `pn_errorcode` | text |  |
| `pn_pruefziffer` | text |  |
| `xml_pn` | text |  |
| `cardtoken_ident` | bigint | FK (intern) |
| `tikartendaten_ident` | bigint | FK (intern) |

### kontaktdaten
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anschriftenkopf` | text |  |
| `email` | text |  |
| `fax` | text |  |
| `handynummer` | text |  |
| `homepage` | text |  |
| `telefon` | text |  |
| `telefon2` | text |  |
| `telefon3` | text |  |
| `adresse_ident` | bigint | FK → `adresse` |
| `willkeinesms` | boolean | NOT NULL |
| `dsinfo` | integer |  |
| `bezeichnungfax` | text |  |
| `bezeichnunghandynummer` | text |  |
| `bezeichnungtelefon` | text |  |
| `bezeichnungtelefon2` | text |  |
| `kontaktmail` | text |  |
| `kontaktname` | text |  |
| `kontakttel` | text |  |
| `kimdate` | timestamp |  |
| `kimemail` | text |  |
| `kimemailnotused` | boolean |  |
| `kimstatus` | integer |  |
| `kimuid` | text |  |

### land
> Importiert aus Wohnsitzlaendercode_V1.4.csv

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `codedin3166alpha2` | text |  |
| `codedin3166alpha3` | text |  |
| `codedin3166numeric` | text |  |
| `staatsangehoerigkeit` | text |  |
| `staatsangehoerigkeitnumeric` | text |  |
| `visible` | boolean | NOT NULL |

### neupatientendaten
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `geburtsdatum` | timestamp | ⚠ Nicht im finalen SELECT. `CAST(x AS date)` empfohlen |
| `nachname` | text | ⚠ Nicht im finalen SELECT |
| `titel` | text |  |
| `versicherer` | text |  |
| `versichertennummer` | text | ⚠ Nicht im finalen SELECT |
| `versicherungsart` | text | GKV, PKV, SZ, BG, ... |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `zugeordneterpatient_ident` | bigint | FK → `patient` |
| `geschlecht` | text | As for regular patients |

### notfalldaten
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `dpebase64` | text |  |
| `nfdbase64` | text |  |
| `dpebase64backup` | text |  |
| `dpelastread` | timestamp |  |
| `dpelastwrite` | timestamp |  |
| `nfdbase64backup` | text |  |
| `nfdlastread` | timestamp |  |
| `nfdlastwrite` | timestamp |  |

### patient
> nicht ueberfluessig (noetig damit man zu alten Karten den Patienten noch zuordnen kann)

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `geburtsdatum` | timestamp | ⚠ Nicht im finalen SELECT. `CAST(x AS date)` empfohlen |
| `nachname` | text | ⚠ Nicht im finalen SELECT |
| `ort` | text |  |
| `revision` | bigint |  |
| `titel` | text |  |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `zuletztaufgerufen` | timestamp |  |
| `patientendetails_ident` | bigint | FK → `patientendetails` |
| `nachname_phonetic` | text |  |
| `vorname_phonetic` | text |  |
| `gesperrt` | integer | 0 = nil = NO; 1 = YES |
| `geburtsname` | text | ⚠ Nicht im finalen SELECT |

### patientenavatar
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `divers` | text | base64-encoded NSImage |
| `maennlich` | text | base64-encoded NSImage |
| `removed` | boolean | NOT NULL |
| `weiblich` | text | base64-encoded NSImage |
| `abjahre` | integer |  |
| `abmonate` | integer |  |
| `abtage` | integer |  |

### patientendetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beruf` | text |  |
| `datumletzterbesuch` | timestamp |  |
| `dmpfallnummer` | text | systemweit eindeutige dmp-patientenID |
| `ersterbesuch` | timestamp |  |
| `freitext` | text |  |
| `geschlecht` | text | "M","W","U" (Unbekannt) |
| `kilometerzumwohnort` | real | NOT NULL |
| `lastunfallort` | text |  |
| `lastunfalltag` | timestamp |  |
| `namenszusatz` | text |  |
| `nationalitaet` | text | Laendercode des Nationalitaet des Patient (welche sich vom Laendercode. des Wohnsitzes unterscheiden kann). Wird gebraucht fuer BG-Abrechnung. |
| `patientenfoto` | text | base-64-encoded |
| `privatezusatzversicherung` | boolean |  |
| `rechnungsname` | text | Frueher Vor- und Zuname des Rechnungsempfaengers GOAE, heute nur noch Nachname (siehe vornameRechnung). |
| `selbststaendig` | boolean |  |
| `aktuellegvkkartendaten_ident` | bigint | FK → `kartendaten` |
| `aktuellepvkartendaten_ident` | bigint | FK → `kartendaten` |
| `arbeitgeber_ident` | bigint | FK → `arbeitgeber` |
| `berufsgenossenschaft_ident` | bigint | FK → `berufsgenossenschaft` |
| `familienversicherung_ident` | bigint | FK → `familienversicherung` |
| `hausarzt_ident` | bigint | FK → `hausarzt` |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `patientendetailsrelationen_ident` | bigint | FK → `patientendetailsrelationen` |
| `privattarif_ident` | bigint | FK → `steigerungsschema` |
| `rechnungsanschrift_ident` | bigint | FK → `adresse` |
| `dmpfallnummergesendet` | boolean | Wenn ja, darf die DMP-Fallnummer nicht mehr veraendert werden. |
| `titelrechnung` | text |  |
| `vornamerechnung` | text | Der Vorname, der zum Attribut rechnungsName gehoert (rechnungsName war historisch Vor- und Zuname) |
| `amtlichesgeburtsdatumdmp` | timestamp | Fuer Patienten, deren Geburtsdatum unbekannt ist, wird von der Krankenkasse. ein "amtliches" Geburtsdatum vergeben, welches fuer DMP zu verwenden ist. |
| `boolcol1` | boolean | NOT NULL. generischeSpalte (nutzerdefiniert) |
| `boolcol2` | boolean | NOT NULL. generischeSpalte (nutzerdefiniert) |
| `patientennummerhks` | text |  |
| `patientennummerhksgesendet` | boolean | Gibt an, ob die Patientennummer HKS bereits einmal verschickt wurde und damit. nicht mehr veraendert werden darf. |
| `stringcol1` | text | generischeSpalte (nutzerdefiniert) |
| `stringcol2` | text | generischeSpalte (nutzerdefiniert) |
| `datenannahmestelle_ident` | bigint | FK → `datenannahmestelle` |
| `impfplan_ident` | bigint | FK → `impfplan` |
| `folgearzt_ident` | bigint | FK → `hausarzt` |
| `ueberweiser_ident` | bigint | FK → `hausarzt` |
| `arzt_ident` | bigint | FK → `nutzer` |
| `beschaeftigtseit` | text |  |
| `privatpatient` | boolean | NOT NULL |
| `schwangerschaftsdetails_ident` | bigint | FK → `schwangerschaftsdetails` |
| `rechnungsgeschlecht` | text |  |
| `rechnungsnamenszusatz` | text |  |
| `rechnungstitel` | text |  |
| `beschaeftigungsstatus_ident` | bigint | FK → `beschaeftigungsstatus` |
| `stationaerezusatzversicherung` | boolean |  |
| `staatsangehoerigkeit` | text |  |
| `homoeoteilnahme_ident` | bigint | FK → `homoeoteilnahme` |
| `privatezusatzversicherungtext` | text |  |
| `berufseit` | timestamp |  |
| `patientennummerfek` | text |  |
| `patientennummerfekgesendet` | boolean |  |
| `erinnerunggezeigtasthma` | boolean |  |
| `erinnerunggezeigtbrustkrebs` | boolean |  |
| `erinnerunggezeigtcopd` | boolean |  |
| `erinnerunggezeigtdiabetes1` | boolean |  |
| `erinnerunggezeigtdiabetes2` | boolean |  |
| `erinnerunggezeigtkhk` | boolean |  |
| `hasnewpappmessages` | boolean |  |
| `thenasyncstarttime` | timestamp |  |
| `thenasyncstatus` | integer | NOT NULL |
| `rechnungsdaten_ident` | bigint | FK → `rechnungsdaten` |
| `rechnungsemail` | text |  |
| `bgaktenzeichen` | text |  |
| `lokalerhauskometpflegearztwrapper_ident` | bigint | FK → `lokalerhauskometpflegearztwrapper` |
| `freitextinfofeld` | text |  |
| `vorsatzwort` | text |  |
| `stringcol3` | text |  |
| `stringcol4` | text |  |
| `statuspsychotherapiefall` | integer | null oder 0 = abgeschlossen, 1= Warteliste, 5 = beantragt, 10 = aktiv |
| `lastdateptzaehlerrefresh` | timestamp | triggert die serverseitige Neuberechnung der PsychotherapieZaehler |
| `qshgvpatientid` | text |  |
| `qshgvpatientidlocked` | boolean |  |
| `preferredlanguagecode` | text |  |
| `erinnerunggezeigtherzinsuffizienz` | boolean |  |
| `sterbedatum` | timestamp |  |
| `kamerapatientident` | text |  |
| `roentgenpatientident` | text |  |
| `datumtherapieende` | timestamp |  |
| `rufname` | text |  |
| `fiktiverpatientk2_480` | boolean |  |
| `geburtsort` | text |  |
| `personalausweisnummer` | text |  |
| `aktuelleranerkennungsbescheidpsychotherapie_ident` | bigint | FK → `anerkennungsbescheidpsychotherapie` |
| `perzentileneinstellungsjson` | text |  |
| `pflegegrad_ident` | bigint | FK → `pflegegrad` |
| `schwerbehindertenausweis_ident` | bigint | FK → `schwerbehindertenausweis` |
| `dmpkeineteilnahme` | boolean |  |
| `dmpkeineteilnahmegrund` | text |  |
| `asvteam_ident` | bigint | FK → `asvteamnummer` |
| `erinnerunggezeigtosteoporose` | boolean |  |
| `aktuellepsychotherapieinfo_ident` | bigint | FK → `psychotherapieinfo` |
| `beaidentity_ident` | bigint | FK → `beaidentity` |
| `abteilung_ident` | bigint | FK → `abteilung` |
| `apotheke_ident` | bigint | FK → `hausarzt` |
| `letztepvkartendaten_ident` | bigint | FK → `kartendaten` |
| `epadatenschutzangaben_ident` | bigint | FK → `epadatenschutzangaben` |
| `pflegeheim_ident` | bigint | FK → `hausarzt` |
| `verbietemassentransfererlaubnisse` | boolean |  |
| `erlaubtdatentransfer` | integer | In Zukunft abschaffen, nur für iOS-Kompatibilität |
| `rechnungsgeburtsdatum` | timestamp |  |
| `erinnerunggezeigtrheuma` | boolean |  |
| `frueherkennungneedsrefresh` | boolean | NOT NULL |
| `dmpkeineteilnahmeasthma` | boolean |  |
| `dmpkeineteilnahmebrustkrebs` | boolean |  |
| `dmpkeineteilnahmecopd` | boolean |  |
| `dmpkeineteilnahmediabetes1` | boolean |  |
| `dmpkeineteilnahmediabetes2` | boolean |  |
| `dmpkeineteilnahmeherzinsuffizienz` | boolean |  |
| `dmpkeineteilnahmekhk` | boolean |  |
| `dmpkeineteilnahmeosteoporose` | boolean |  |
| `dmpkeineteilnahmerheuma` | boolean |  |

### patientendetailsrelationen
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `medikamentenplan_bmp_ident` | bigint | FK → `medikamentenplan` |
| `medikamentenplan_armin_ident` | bigint | FK → `arminmedikamentenplan` |
| `aktuellenotfalldaten_ident` | bigint | FK → `notfalldaten` |
| `hzvhauskometmedikamentenplan_ident` | bigint | FK → `hzvhauskometmedikamentenplan` |
| `aktuelleepadaten_ident` | bigint | FK → `epadaten` |
| `vitalwerteeinstellung_ident` | bigint | FK → `vitalwerteeinstellung` |
| `gynverlaufeinstellungen_ident` | bigint | FK → `gynverlaufeinstellungen` |
| `feerinnerunggruppe_ident` | bigint | FK → `feerinnerunggruppe` |

### patientengruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `color` | text |  |
| `name` | text |  |
| `rechnungspatientgruppenelement_ident` | bigint | FK → `patientengruppenelement` |
| `summekosten` | double | NOT NULL |

### patientengruppenelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listposition` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `besuchsobjekt_ident` | bigint | FK → `besuch` |
| `patientenobjekt_ident` | bigint | FK → `patient` |

### patientenzeichnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `attr` | integer | NOT NULL |
| `lastchangedate` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `hintergrunddatei_ident` | bigint | FK → `datei` |
| `zeichnungdatei_ident` | bigint | FK → `datei` |

### patientrelationship
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `name` | text |  |
| `toobjecttype` | text |  |
| `aktenident` | bigint |  |
| `beteiligtenaktenzeichen` | text |  |
| `schadensnummer` | text |  |
| `versichertennummer` | text | ⚠ Nicht im finalen SELECT |
| `dualrelationship_ident` | bigint | FK → `patientrelationship` |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `removed` | boolean | NOT NULL |
| `vorsteuerabzug` | boolean |  |
| `toobjectident` | bigint |  |

### patienttyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `patient_ident` | bigint | FK → `patient` |
| `patienttyp` | integer | NOT NULL |

### pflegegrad
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `grad` | integer |  |
| `letzteaenderung` | timestamp |  |
| `modifier` | integer |  |

### postleitzahl
> aus der Datei PLZ74_[V].[QJJ] ausgelesen, welche von der KBV
> in verschluesselter Form im Format xDT zur Verfuegung gestellt wird

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `code` | text |  |
| `gueltigab` | timestamp |  |
| `bezirksstelle` | text | aus performancegruenden nicht als relation modelliert |
| `kvbereich` | text | aus performancegruenden nicht als relation modelliert |
| `orte` | text | kommaseparierte Liste von Orten mit dieser PLZ zwecks Autovervollstaendigung |
| `bundesland` | text |  |
| `country` | text |  |

### schwerbehindertenausweis
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `gradderbehinderung` | integer |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `kriegsgeschaedigt` | boolean |  |
| `letzteaenderung` | timestamp |  |
| `merkzeichen_1kl` | boolean |  |
| `merkzeichen_b` | boolean |  |
| `merkzeichen_bl` | boolean |  |
| `merkzeichen_g` | boolean |  |
| `merkzeichen_gl` | boolean |  |
| `merkzeichen_h` | boolean |  |
| `merkzeichen_rf` | boolean |  |
| `merkzeichen_tbl` | boolean |  |
| `merkzeichen_ag` | boolean |  |

### telefonnummer
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `listenposition` | integer |  |
| `nummer` | text |  |
| `removed` | boolean | NOT NULL |

### wohnhaftinkv
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `ende` | timestamp |  |
| `start` | timestamp |  |
| `kassenaerztlichevereinigung_ident` | bigint | FK → `kassenaerztlichevereinigung` |

### zuzahlungsbefreiung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beginn` | timestamp |  |
| `ende` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `befreiungtyp` | integer | NOT NULL. 1 = allgemein. 2 = teiweis (deprecated). 3 = Schwangerschaft |

## 2. Arzt & Praxisstruktur

### abteilung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kostenstelle` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### arbeitsplatz
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean |  |
| `sichtbarkeitseinstellung_ident` | bigint | FK (intern) |
| `ticardcontent` | text |  |
| `ticarddate` | text |  |
| `ticarderror` | text |  |
| `ticardtype` | integer |  |
| `timodus` | integer |  |

### arbeitsplatzgruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean |  |
| `sichtbarkeitseinstellung_ident` | bigint | FK (intern) |

### arztgruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `arztgruppe` | text |  |
| `ebmkapitel` | text |  |
| `oberefallwert` | real |  |
| `punkte` | real | Bewertung GOP 32001 der Fachgruppe |
| `unterefallwert` | real |  |
| `bezeichnung` | text |  |
| `code` | text |  |

### arzthistorieneintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `fuerwann` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `arzt_ident` | bigint | FK → `nutzer` |

### arztstempel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `removed` | boolean | NOT NULL |
| `stempelblanko` | text |  |
| `stempelnadel` | text |  |
| `fuerbetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `briefkopf` | text |  |
| `stempelbgblanko` | text |  |
| `stempelbgnadel` | text |  |

### arztstempelusage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `arztstempel` | text |  |
| `lastusage` | timestamp |  |
| `usagecount` | integer |  |
| `puretext` | text |  |

### behandelnderarzt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listenposition` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `nutzer_ident` | bigint | FK → `nutzer` |

### betriebsstaette
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abrechnunglaborleistungen0300` | boolean | NOT NULL |
| `isnebenbetriebsstaette` | boolean | NOT NULL |
| `kuerzel` | text |  |
| `name` | text |  |
| `nr` | text |  |
| `verwendungunituse0301` | integer | NOT NULL. fuer rsva (Ringversuchszertifikate). 0 = nein, 1 = ja ausschliesslich, 2 = ja teilweise |
| `visible` | boolean | NOT NULL |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `standardprivatrechnungtyp_ident` | bigint | FK → `privatrechnungtyp` |
| `standardbgprivatrechnungtyp_ident` | bigint | FK → `privatrechnungtyp` |
| `bankname` | text |  |
| `bic` | text |  |
| `iban` | text |  |
| `www` | text |  |
| `hauptbetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `freitext` | text |  |
| `standardvorwahl` | text |  |
| `ssbimpfen_ident` | bigint | FK → `patient` |
| `umsatzsteuerid` | text |  |
| `daleansprechpartner_ident` | bigint | FK → `nutzer` |
| `esrid` | text |  |
| `nifnr` | text |  |
| `color` | text |  |
| `vpnrgruppenpraxis` | text |  |
| `referenznummerid` | text |  |
| `zsr` | text |  |
| `standardsteigerungsschema_ident` | bigint | FK → `steigerungsschema` |
| `emergencystate` | integer | NOT NULL |
| `currentemergencyeintrag_ident` | bigint | FK → `emergencyeintrag` |
| `iban2` | text |  |
| `healthcarefacilitytype` | integer |  |
| `epastatus` | integer | FK 0226 |
| `ueberweisungtyp` | integer |  |
| `adressebank_ident` | bigint | FK → `adresse` |
| `kontoinhaber_ident` | bigint | FK → `kontoinhaber` |
| `statuserezept0226` | integer |  |
| `krebsregisterabsenderid` | text |  |
| `kimemailaccount_ident` | bigint | FK → `emailaccount` |
| `statusemp0226` | integer |  |
| `statusnfdm0226` | integer |  |
| `warenbestellungbereich` | text |  |
| `kzvabrechnungnr` | text |  |
| `kzv_ident` | bigint | FK → `kassenzahnaerztlichevereinigung` |
| `zidzahnarzt_ident` | bigint | FK → `nutzer` |
| `bestellmodus` | integer | NOT NULL |
| `anwaltskammer_ident` | bigint | FK → `anwaltskammer` |
| `statuseau0226` | integer |  |
| `statusearztbrief0226` | integer |  |
| `statusehba0226` | integer |  |
| `statuskim0226` | integer |  |
| `statuskt0226` | integer |  |
| `statussmcb0226` | integer |  |
| `currentlogo_ident` | bigint | FK → `customformularbgimage` |
| `sichtbarkeitseinstellung_ident` | bigint | FK (intern) |
| `statusevdga0226` | integer |  |
| `kvzahlungen` | text |  |
| `regelleistungsvolumen` | text |  |
| `defaultscheintyp` | smallint |  |
| `kzvabrechnung_ident` | bigint | FK → `kassenzahnaerztlichevereinigung` |
| `statustim0226` | integer |  |
| `telematikid` | text |  |
| `ticardid` | text |  |
| `kontoname` | text |  |
| `fachgebietbasfein_ident` | bigint | FK → `fachgebietbasfein` |

### fachgebietbasfein
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |

### fachgebietbasgrob
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |

### fachgruppebar
> Fachgruppenbezeichnung laut Bundesarztregister. Ist 3stellig und damit detaillierter als Fachgruppenbezeichnung der KBV.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `gueltigbis` | timestamp | Falls eine Fachgruppe die Zeichenkette "obsolet" enth?lt, sollte man sie nicht mehr vergeben k?nnen.  |
| `gueltigvon` | timestamp |  |
| `budgetforheilmittel` | text | format:num;num (Mitglied;Rentner) |
| `budgetformediks` | text | format: (num1;num2)*. num1=untere Altersgrenze. num2=Kosten in Euro. Altersgruppentrenner = \| |
| `budgettypeheilmittel` | integer |  |
| `budgettypemediks` | integer |  |
| `land` | integer | null, 49 : Deutschland; 41 : Schweiz - internationale Vorwahlen |
| `arztgruppe_ident` | bigint | FK → `arztgruppe` |

### fachgruppebpl
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |

### fachgruppekbv
> zweistellige Fachgruppennummer
> nicht zu verwechslen mit dreistelliger BARFachgruppennummer

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |

### fachgruppendruchschnitteintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `code` | text |  |
| `fgdinprozent` | real | NOT NULL |
| `listenpos` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `toleranzinprozent` | real | NOT NULL |

### fachgruppendurchschnitt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `jahr` | integer |  |
| `quartal` | integer |  |
| `visible` | boolean | NOT NULL |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `leistungstyp` | smallint |  |

### fachgruppenhinweis
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abdakey` | text | Zaehler_Fachgrquoten |
| `hinweis_ersetzung` | text |  |
| `hinweis_vo_ok` | text | nur bei Eintraegen aus FGQA_ARV vorhanden |
| `quotentyp` | smallint | NOT NULL. 1 = DDD, 2 = Verordnungen, 3 = bruttoumsatz |
| `zielquote` | real | NOT NULL |
| `betroffenefachgruppen` | text | commaseparated list of FachgruppeKBV.code. no direct link to FachgruppeKBV possible, since MedikEntites.sqlite is centrally distributed |

### hausarzt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bsnr` | text | betriebsst?ttennummer |
| `fachgebiet` | text |  |
| `freitext` | text |  |
| `geburtsdatum` | timestamp | ⚠ Nicht im finalen SELECT. `CAST(x AS date)` empfohlen |
| `geschlecht` | text | "M","W","U" (Unbekannt) |
| `kuerzel` | text |  |
| `lanr` | text |  |
| `nachname` | text | ⚠ Nicht im finalen SELECT |
| `revision` | bigint |  |
| `titel` | text |  |
| `visible` | boolean | NOT NULL |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `praxiskontakt_ident` | bigint | FK → `kontaktdaten` |
| `anrede` | text |  |
| `zsr` | text |  |
| `praxisname` | text |  |
| `kimemail` | text |  |
| `kimuid` | text |  |
| `onlineid` | text |  |
| `kimdate` | timestamp |  |
| `kimstatus` | integer |  |
| `kvcdate` | timestamp |  |
| `kvcemail` | text |  |
| `kvcstatus` | integer |  |
| `kvcuid` | text |  |
| `zahnarztnummer` | text |  |
| `emaildidchange` | boolean |  |
| `kimemailnotused` | boolean |  |
| `dameadresse` | text |  |
| `typ` | integer | 0/null = Arzt, 1 = Apotheke |
| `kooperationsvertragsnummer` | text |  |

### hausarztanrede
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anrede` | text |  |
| `hausarzt_ident` | bigint | FK → `hausarzt` |
| `nutzer_ident` | bigint | FK → `nutzer` |

### nutzer
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `erlauterungpseudoarztnummer` | text | muss statt des Namens uebetragen werden wenn lanr = 9999999xx |
| `hinweisordigebuehr` | boolean | NOT NULL. soll Ordinationsgebuer automatisch eingetragen werden? |
| `isadmin` | boolean | NOT NULL |
| `isvertragsarzt` | boolean | NOT NULL |
| `kuerzel` | text |  |
| `lanr` | text |  |
| `leistungserbringer` | boolean | NOT NULL |
| `nachname` | text | ⚠ Nicht im finalen SELECT |
| `praefixebmkatalog` | text | praefix der Ordinationsgebuehr |
| `titel` | text |  |
| `visible` | boolean | NOT NULL |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `abrechnungauf_ident` | bigint | FK → `nutzer` |
| `haevgid` | text | fuer HZV |
| `hinweischronigebuehr` | boolean | NOT NULL |
| `mediverbundid` | text | fuer HZV (Facharztvertraege) |
| `rechte` | text | comma-seperated String |
| `fachgruppefuerbudget_ident` | bigint | FK → `fachgruppebar` |
| `color` | text |  |
| `unterschrift` | text |  |
| `daleik` | text | Institutionskennzeichen fuer den Dale-UV-Arzt |
| `cameraloginid` | integer | NOT NULL. kurze ID fuer cameraLogin |
| `regelleistungsvolumen` | text |  |
| `kvzahlungen` | text |  |
| `zsr` | text |  |
| `kvconnectaccount_ident` | bigint | FK → `emailaccount` |
| `usernamearminwebfrontend` | text |  |
| `standardemailaccount_ident` | bigint | FK → `emailaccount` |
| `tkarztid` | text |  |
| `nutzertyp` | integer | NOT NULL |
| `geschlecht` | text |  |
| `arztgruppe_ident` | bigint | FK → `arztgruppe` |
| `usernamearztdirect` | text |  |
| `labororderentryeinsender` | text |  |
| `laborabruflogin` | text |  |
| `defaulthauskometpflegearzt_ident` | bigint | FK → `nutzer` |
| `patient_ident` | bigint | FK → `patient` |
| `ticonnector_ident` | bigint | FK (intern) |
| `timandant_ident` | bigint | FK (intern) |
| `usetelescan` | boolean | NOT NULL. Im Rahmen von eAV |
| `kimemailaccount_ident` | bigint | FK → `emailaccount` |
| `asrenabled` | boolean | NOT NULL |
| `namenszusatz0221` | text |  |
| `lastlogin` | timestamp |  |
| `vorsatzwort` | text |  |
| `zahnarztnummer` | text |  |
| `comfortsignaturcardhandle` | text |  |
| `comfortsignaturdate` | timestamp |  |
| `comfortsignaturuserid` | text |  |
| `ticardid` | text |  |
| `qualification_type` | text |  |
| `krebsregistermelderid` | text |  |
| `tiarbeitsplatzkontext` | boolean | NOT NULL |
| `datevpersonalnummer` | text |  |
| `unterschriftgeschuetzt` | boolean | NOT NULL |
| `pclockeynumber` | text |  |
| `pclocusername` | text |  |
| `berufsbezeichnung` | text |  |
| `eigenerarztstempelaufformularen` | boolean |  |
| `eigenerarztstempelwelcheformulare` | integer |  |
| `docboxusername` | text |  |
| `epdrole` | integer |  |
| `usecegedim` | boolean | NOT NULL |
| `lastlogout` | timestamp |  |
| `comfortsignaturnutzungallowed` | boolean | NOT NULL |
| `comfortsignaturnutzer_ident` | bigint | FK → `nutzer` |
| `bdocnummer` | text |  |
| `comfortsignaturiccsn` | text |  |
| `perzentileneinstellungsjson` | text |  |
| `avatar_ident` | bigint | FK → `avatar` |
| `beaaccount_ident` | bigint | FK → `beaaccount` |
| `stundensatzincent` | integer |  |
| `daleuvvertreter_ident` | bigint | FK → `nutzer` |
| `testanbieteraccount_ident` | bigint | FK (intern) |
| `abrechnungaufforbs` | text |  |
| `psychotherapiequalifikation_ident` | bigint | FK → `psychotherapiequalifikation` |
| `damesenderadresse` | text |  |
| `favpid` | text | Facharztbezogener Vertragspartneridentifikator (migrierte mediverbundID) |
| `havpid` | text | Hausarztbezogener Vertragspartneridentifikator (migrierte haevgID) |
| `autogenerierterarztstempel` | boolean |  |
| `loginonlyonce` | boolean |  |
| `irdkennzeichen` | text |  |
| `irdticardid` | text |  |
| `sichtbarkeitseinstellung_ident` | bigint | FK (intern) |
| `tagesbudgetgrenzekritisch` | integer |  |
| `tagesbudgetgrenzewarnung` | integer |  |
| `personioid` | text |  |
| `zsident` | integer |  |
| `practicesettingcode` | text |  |
| `customtoolbars` | text |  |
| `letzterstrahlenschutzkurs` | timestamp |  |
| `enabletagesbudgetcritmsg` | boolean |  |
| `enabletagesbudgetwarnmsg` | boolean |  |
| `lasttagesbudgetcritmsg` | timestamp |  |
| `lasttagesbudgetwarnmsg` | timestamp |  |
| `telematikid` | text |  |
| `qualification_type_dental` | text |  |
| `quartalsbudgetgrenzekritisch` | integer |  |
| `quartalsbudgetgrenzewarnung` | integer |  |
| `enablequartalsbudgetcritmsg` | boolean |  |
| `enablequartalsbudgetwarnmsg` | boolean |  |
| `lastquartalsbudgetcritmsg` | timestamp |  |
| `lastquartalsbudgetwarnmsg` | timestamp |  |
| `verschreiberid` | text |  |

### nutzerfoto
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `erstellt` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `datei_ident` | bigint | FK → `datei` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `embeddings` | text |  |
| `thumbnail` | text |  |
| `isdynamic` | boolean | NOT NULL |
| `modelgeneration` | integer | NOT NULL |

### nutzergruppe
> s. Einstellungen-Verwaltung

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `anaesthesisten` | boolean | NOT NULL |
| `operateure` | boolean | NOT NULL |
| `visible` | boolean |  |
| `sichtbarkeitseinstellung_ident` | bigint | FK (intern) |

### raum
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `kuerzel` | text |  |
| `mehrpersonenraum` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `listenpositionbettenstation` | integer | NOT NULL. nur iOS |
| `bettenstation_ident` | bigint | FK → `bettenstation` |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |

### stelle
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `color` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### vertretung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `context` | text |  |
| `visible` | boolean | NOT NULL |
| `vertretungfuer_ident` | bigint | FK → `nutzer` |

## 3. Termine & Kalender

### abwesenheit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `ende` | timestamp |  |
| `start` | timestamp |  |
| `type` | integer | NOT NULL |
| `urlaubsverteilung` | text |  |
| `visible` | boolean | NOT NULL |
| `abwesenheitstyp_ident` | bigint | FK → `abwesenheitstyp` |
| `antragstatus` | boolean |  |
| `begruendung` | text |  |
| `erstellung` | timestamp |  |
| `gesehen` | timestamp |  |
| `isantrag` | boolean | NOT NULL |
| `notiz` | text |  |
| `adminremark` | text |  |
| `personioid` | text |  |

### abwesenheitstyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `color` | text |  |
| `consumeurlaub` | boolean |  |
| `factorsollzeit` | integer | NOT NULL |
| `factorstechuhr` | integer | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `notrequestable` | boolean |  |
| `personioid` | text |  |
| `urlaubtoconsume` | double |  |

### externertermin
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `accountident` | bigint | Account class depends on provider |
| `additionaldatajson` | text | Not standardized across services, use as needed (for example for original calendar) |
| `extbookingident` | text |  |
| `extcalendarident` | text |  |
| `extcreationdate` | timestamp |  |
| `extinstanceident` | text |  |
| `extpatientident` | text |  |
| `extuserident` | text |  |
| `inboxstate` | integer | 0/Null = None, 1 = Pending, 2 = Accepted, 3 = Rejected |
| `modificationdate` | timestamp | Refering to state changes as relevant to the external service |
| `processingstate` | integer | Not standardized across services, use as needed |
| `provider` | text |  |
| `sourcedata` | text | Whatever (last) data was sent by the external service which defines this |
| `tocommunicatejson` | text | To hold data which still has to be sent to the other service |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |
| `apipartner_ident` | bigint | FK (intern) |

### externeterminkette
> See ExternerTermin for meaning of most fields

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `accountident` | bigint |  |
| `additionaldatajson` | text |  |
| `extbookingident` | text |  |
| `extcalendarident` | text |  |
| `extcreationdate` | timestamp |  |
| `extinstanceident` | text |  |
| `extpatientident` | text |  |
| `extuserident` | text |  |
| `inboxstate` | integer |  |
| `ismaindataprovider` | boolean | NOT NULL. Indicates, that patient data etc. should be read from here instead of the individual appointments |
| `modificationdate` | timestamp |  |
| `processingstate` | integer |  |
| `provider` | text |  |
| `sourcedata` | text |  |
| `tocommunicatejson` | text |  |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |

### feiertag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `datum` | timestamp |  |
| `jahr` | integer | NOT NULL. for performance |
| `nurinkv` | text | komma-separiert, leer wenn fuer alle KVen gueltig |

### kalender
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `farbe` | text |  |
| `listenpos` | integer | NOT NULL |
| `terminlokalitaet_ident` | bigint | FK → `terminlokalitaet` |
| `kuerzel` | text |  |
| `csfeiertagscodes` | text |  |
| `zskuerzelnr` | integer |  |

### kalenderfavorit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listenpos` | integer | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `fixiertetermine` | integer | NOT NULL |
| `showeinkalender` | integer | NOT NULL |
| `showfarbe` | integer | NOT NULL |
| `showressource` | integer | NOT NULL |
| `showspaltenweise` | integer | NOT NULL |
| `showwoche` | integer | NOT NULL |

### kalenderschema
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `listenpos` | integer |  |
| `internalweek` | integer |  |

### kalendersperrmodus
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `color` | text |  |
| `isfeiertag` | boolean | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `listenpos` | integer |  |

### offenesprechstundezeit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `fachgruppe` | integer |  |
| `start` | timestamp |  |
| `stop` | timestamp |  |
| `weekday` | integer |  |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `removed` | boolean | NOT NULL |

### recalltermin
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `benachrichtigtam` | timestamp |  |
| `benachrichtigungsart` | integer |  |
| `removed` | boolean | NOT NULL |
| `rueckmeldungam` | timestamp |  |
| `smsnachricht_ident` | bigint | FK → `smsnachricht` |
| `brief_ident` | bigint | FK → `karteieintraganhang` |
| `email_ident` | bigint | FK → `email` |
| `patient_ident` | bigint | FK → `patient` |
| `recalltyp_ident` | bigint | FK → `recalltyp` |
| `anzahlbenachrichtigungen` | integer | NOT NULL |
| `faelligam` | timestamp |  |
| `datei_ident` | bigint | FK → `datei` |

### recalltyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `erlaubtanruf` | boolean | NOT NULL |
| `erlaubtbrief` | boolean | NOT NULL |
| `erlaubtemail` | boolean | NOT NULL |
| `erlaubtsms` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `zeitintervalle` | text |  |
| `smsvorlage_ident` | bigint | FK → `smsvorlage` |
| `briefvorlage_ident` | bigint | FK → `briefvorlage` |
| `emailvorlage_ident` | bigint | FK → `emailvorlage` |
| `statistikoutlineelement_ident` | bigint | FK → `outlineviewelement` |
| `modusbenachrichtigung` | integer | NOT NULL |
| `name` | text |  |
| `periode` | integer | NOT NULL |
| `periodenart` | integer | NOT NULL |
| `intervallarten` | text |  |

### termin
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beginn` | timestamp |  |
| `ende` | timestamp |  |
| `info` | text |  |
| `removed` | boolean | NOT NULL |
| `wdhende` | timestamp |  |
| `wiederholung` | integer | NOT NULL |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `patient_ident` | bigint | FK → `patient` |
| `terminart_ident` | bigint | FK → `terminart` |
| `warda` | boolean | NOT NULL |
| `angelegt` | timestamp |  |
| `bett` | boolean | NOT NULL |
| `behandler` | text |  |
| `kassenname` | text |  |
| `privatversichert` | boolean | NOT NULL |
| `telefon` | text |  |
| `geaendert` | timestamp |  |
| `onlineident` | text |  |
| `aenderndernutzer_ident` | bigint | FK → `nutzer` |
| `acceptssms` | boolean | NOT NULL |
| `terminlokalitaet_ident` | bigint | FK → `terminlokalitaet` |
| `onlinesprechstundeident` | text |  |
| `tsvgkontaktart` | integer | NOT NULL |
| `tsvgvermittlungsdatum` | timestamp |  |
| `dsinfo` | integer |  |
| `tsvgscheinzugeordnet` | boolean | NOT NULL |
| `tsvgvermittlungscode` | text |  |
| `tsvgdringlichkeit` | text |  |
| `entbindungstermin` | timestamp | fuer SchwangerSchaftsWoche |
| `beginnpatientoffsetminuten` | integer |  |
| `ticketnumber` | text |  |
| `shouldbeterminkette` | boolean | NOT NULL. Ob in TK, damit keine unnoetigen TK fetches |
| `isneuerpatient` | boolean | NOT NULL |
| `jsonpayload` | text |  |
| `heilmittel_ident` | bigint | FK → `heilmittel` |
| `genutztesuche_ident` | bigint | FK → `terminsuche` |
| `creationmessagemail` | text |  |
| `lastchangemessagedate` | timestamp |  |
| `shouldhavearbmedu` | boolean | NOT NULL |
| `serveronlywdhbaseident` | bigint |  |
| `serveronlywdhposition` | integer |  |
| `externertermin_ident` | bigint | FK → `externertermin` |
| `statusjsonformulare` | integer |  |
| `endepatientoffsetminuten` | integer |  |
| `triedautomaticupload` | boolean |  |
| `verschiebeoderloeschunggrund` | text |  |
| `keinenachrichtenmaske` | integer | 1<<0 Erinnerung, 1<<1 Änderungsbenachrichtigung |
| `tssfhirid` | text |  |

### terminaenderungfuernachricht
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `aenderungsdatum` | timestamp |  |
| `altdatenjson` | text |  |
| `art` | text |  |
| `preparedcommandsjson` | text |  |
| `removed` | boolean | NOT NULL |
| `problem_ident` | bigint | FK → `terminaenderungnachrichtproblem` |
| `termin_ident` | bigint | FK → `termin` |

### terminaenderungnachrichtproblem
> Represents error on automatic message, needs manual message

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `changecontent` | text |  |
| `changedate` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `abschlussnutzer_ident` | bigint | FK → `nutzer` |
| `changedtermin_ident` | bigint | FK → `termin` |

### terminart
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `farbe` | text |  |
| `infotermin` | boolean | NOT NULL. 1 fuer Ressourcen |
| `kuerzel` | text |  |
| `laenge` | integer | NOT NULL. in min |
| `visible` | boolean | NOT NULL |
| `terminresourceverbindung_ident` | bigint | FK → `terminart` |
| `terminfuerresourcedoppelklick_ident` | bigint | FK → `terminart` |
| `laengebeiautosuche` | integer | NOT NULL |
| `onlinesprechstunde` | boolean | NOT NULL |
| `farbeschrift` | text |  |
| `fixelaenge` | boolean | NOT NULL |
| `tsvgkontaktart` | integer | NOT NULL |
| `beginnpatientoffsetminuten` | integer | < 0: Patient kommt frueher. |
| `gerastert` | boolean | NOT NULL. YES: Terminverschiebung nur auf Raster relativ zu Ressource |
| `terminlokalitaet_ident` | bigint | FK → `terminlokalitaet` |
| `warteschlangeident` | bigint |  |
| `webformularkarteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `termintyp` | integer | fuer Kanzlaw Fristen |
| `zsgeneriert` | boolean |  |
| `defaultopeintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `premigrationart_ident` | bigint | FK → `terminart` |
| `listenpos` | integer |  |
| `typ` | integer | NOT NULL. 0 Termin, 1 Ressource, 2 Sperrbereich. 3 Ganztagsart |
| `endepatientoffsetminuten` | integer |  |

### terminartlimit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `visible` | boolean | NOT NULL |
| `maxcount` | integer | NOT NULL |
| `timeinterval` | integer | NOT NULL |
| `timeunit` | integer | NOT NULL. enum for minute,day,week etc. |
| `name` | text |  |
| `allappointmenttypes` | boolean | NOT NULL |
| `allcalendars` | boolean | NOT NULL |
| `percalendar` | boolean | NOT NULL |
| `perpatient` | boolean | NOT NULL |
| `endclocktimeminute` | integer |  |
| `excludedweekdaymask` | integer | NOT NULL |
| `startclocktimeminute` | integer |  |
| `startdate` | timestamp |  |
| `stopdate` | timestamp |  |
| `relativestartdays` | integer |  |
| `relativestopdays` | integer |  |
| `ignorierteversicherungsarten` | text |  |
| `markernoetigoder` | boolean | NOT NULL |
| `markerverbotenoder` | boolean | NOT NULL |
| `ignoriereoffline` | boolean | NOT NULL |
| `ignoriereonline` | boolean | NOT NULL |
| `ignorebestandspatienten` | boolean | NOT NULL |
| `ignoreneupatienten` | boolean | NOT NULL |
| `ignorepatientenlos` | boolean | NOT NULL |
| `listenpos` | integer |  |
| `beachteverpasstetermine` | boolean | NOT NULL |
| `besuchzeitraumbestandspatient_ident` | bigint | FK → `zeitraumkomponenten` |
| `relativeend_ident` | bigint | FK → `zeitraumkomponenten` |
| `relativestart_ident` | bigint | FK → `zeitraumkomponenten` |

### terminerinnerung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `errormsg` | text |  |
| `removed` | boolean | NOT NULL |
| `status` | integer |  |
| `email_ident` | bigint | FK → `email` |
| `terminerinnerungart_ident` | bigint | FK → `terminerinnerungart` |
| `senddate` | timestamp |  |
| `smsnachricht_ident` | bigint | FK → `smsnachricht` |
| `modus` | integer |  |
| `type` | text |  |
| `terminerinnerung_ident` | bigint | FK → `terminerinnerung` |

### terminerinnerungart
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `preferredsendtimeend` | timestamp |  |
| `preferredsendtimestart` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `emailvorlage_ident` | bigint | FK → `emailvorlage` |
| `dontsendonweekends` | boolean | NOT NULL |
| `listenposition` | integer | NOT NULL |
| `maxdaysbeforetermin` | integer | NOT NULL |
| `mindaysbeforetermin` | integer | NOT NULL |
| `modus` | integer |  |
| `smsvorlage_ident` | bigint | FK → `smsvorlage` |
| `emailaccount_ident` | bigint | FK → `emailaccount` |
| `combinetermine` | boolean | NOT NULL |
| `dokumodus` | integer | NOT NULL |
| `emailsignatur_ident` | bigint | FK → `emailsignatur` |
| `karteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `smsaccount_ident` | bigint | FK (intern) |
| `aftertermin` | boolean | NOT NULL |
| `lowerbounddaysfromtermin` | integer | NOT NULL |
| `upperbounddaysfromtermin` | integer | NOT NULL |

### terminerinnerungartmodus
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `inactive` | boolean |  |
| `priority` | integer |  |
| `type` | integer |  |

### terminerinnerungplan
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `removed` | boolean | NOT NULL |
| `allekalender` | boolean | NOT NULL |
| `alleterminarten` | boolean | NOT NULL |
| `active` | boolean | NOT NULL |

### terminformulareintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `wert` | boolean |  |
| `text` | text |  |
| `listenpos` | integer |  |

### terminkalendertag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `info` | text |  |
| `removed` | boolean | NOT NULL |
| `tag` | timestamp |  |
| `beginn` | timestamp |  |
| `ende` | timestamp |  |
| `kalender_ident` | bigint | FK → `kalender` |
| `sperrmodus` | integer | NOT NULL |
| `sperrname` | text |  |
| `kalendersperrmodus_ident` | bigint | FK → `kalendersperrmodus` |

### terminkette
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `otkappointmentseries_ident` | bigint | FK → `otkevent` |
| `terminkettesuche_ident` | bigint | FK → `terminkettesuche` |
| `externeterminkette_ident` | bigint | FK → `externeterminkette` |

### terminketteeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `createop` | boolean | NOT NULL |
| `listenpos` | integer |  |
| `mhd` | integer |  |
| `pluszeit` | integer |  |
| `varianzzeit` | integer |  |
| `visible` | boolean | NOT NULL |
| `termin_ident` | bigint | FK → `termin` |

### terminkettesuche
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `availableonline` | boolean | NOT NULL |
| `listenpos` | integer |  |
| `singlebetriebsstaettelocal` | boolean | NOT NULL |
| `multiplebetriebsstaetteonline` | boolean | NOT NULL. inverted w.r. to local for different default |

### terminkettesucheeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listenpos` | integer | NOT NULL |
| `mhd` | integer | NOT NULL. minuten=1 stunden=2 tage=3 |
| `pluszeit` | integer | NOT NULL |
| `varianzzeit` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |
| `terminsuche_ident` | bigint | FK → `terminsuche` |
| `vorgaenger_ident` | bigint | FK → `terminkettesucheeintrag` |
| `createop` | boolean | NOT NULL |
| `abkomponente_ident` | bigint | FK → `zeitraumkomponenten` |
| `fuerkomponente_ident` | bigint | FK → `zeitraumkomponenten` |

### terminloeschgrundmuster
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `content` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `shownforarten` | boolean | NOT NULL. If YES, show for associated Terminarten, else hide |

### terminlokalitaet
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `farbe` | text |  |
| `kuerzel` | text |  |
| `visible` | boolean | NOT NULL |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `listenpos` | integer |  |

### terminsuche
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kalenderund` | boolean | NOT NULL |
| `laenge` | integer | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `suchtermin_ident` | bigint | FK → `terminart` |
| `availableonline` | boolean | NOT NULL |
| `availableonlineprivat` | boolean | NOT NULL |
| `availableonlinesz` | boolean | NOT NULL |
| `onlinetext` | text |  |
| `ab` | integer | NOT NULL |
| `availableonlinesprechstunde` | boolean | NOT NULL |
| `mitbett` | boolean | NOT NULL |
| `mitop` | boolean | NOT NULL |
| `availableonlinebg` | boolean | NOT NULL |
| `bezugszeitpunkt` | integer | Bezugszeitpunkt ab dem nach einem Termin gesucht werden soll 0:jetzt 1:SSW(Schwangerschaftswoche 0W+0T) 2: Geburt 3: Aus Briefkommando |
| `usesubterminsuchen` | boolean | NOT NULL |
| `usesubterminsuchenund` | boolean | NOT NULL |
| `listenpos` | integer |  |
| `hauptanforderung_ident` | bigint | FK → `terminsucheanforderung` |
| `komplexeressourcenansicht` | boolean | NOT NULL |
| `abbriefkommando` | text |  |
| `ortbeschraenkung` | integer | NOT NULL |
| `abkomponente_ident` | bigint | FK → `zeitraumkomponenten` |
| `fuerkomponente_ident` | bigint | FK → `zeitraumkomponenten` |
| `raster` | integer | NOT NULL |

### terminsucheanforderung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `multiplicity` | integer |  |
| `position` | integer |  |
| `type` | integer | NOT NULL. 0 functionality, 1 and, 2 or, ... |
| `visible` | boolean | NOT NULL |
| `funktionalitaetsart_ident` | bigint | FK → `terminart` |
| `timeinterval` | integer |  |
| `alwaysallcustomcalendars` | boolean | NOT NULL |
| `usecustomcalendars` | boolean | NOT NULL |

### terminverschiebegrundmuster
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `content` | text |  |
| `name` | text |  |
| `shownforarten` | boolean | NOT NULL. If YES, show for associated Terminarten, else hide |
| `visible` | boolean | NOT NULL |

### terminviewtextreplacement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `command` | text |  |
| `replacement` | text |  |
| `toreplace` | text |  |
| `visible` | boolean | NOT NULL |

### terminwartelisteeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `angebotenerbeginn` | timestamp |  |
| `angebotenesende` | timestamp |  |
| `letztesangebot` | timestamp |  |
| `patientdata` | text |  |
| `removed` | boolean | NOT NULL |
| `status` | integer | NOT NULL |
| `existierendertermin_ident` | bigint | FK → `termin` |
| `patient_ident` | bigint | FK → `patient` |
| `suche_ident` | bigint | FK → `terminsuche` |
| `anfragedatum` | timestamp |  |
| `adinstanceid` | text |  |
| `apipartnername` | text |  |

### terminwartelisteeintragbereich
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beginn` | timestamp |  |
| `ende` | timestamp |  |

### terminwartelisteeintragregel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `startminute` | integer | NOT NULL |
| `stopminute` | integer | NOT NULL |
| `wochentag` | integer | NOT NULL |

### timeslot
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `days` | integer |  |
| `endtime` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `starttime` | timestamp |  |
| `week` | integer |  |
| `year` | integer |  |

## 4. Besuche & Kontakte

### arztpatientenkontakt
> Manche Leistungen duerfen nur dann mehrmals an einem Tag abgerechnet werden
> wenn sie in verschiedenen Arzt-Patienten-Kontakten erbracht wurden.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kontaktzeit` | timestamp |  |
| `ambulantebehandlung_ident` | bigint | FK → `ambulantebehandlung` |
| `atarztpatientenkontaktdetails_ident` | bigint | FK → `atarztpatientenkontaktdetails` |

### atarztpatientenkontaktdetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kontaktid` | text |  |
| `hauptdiagnose_ident` | bigint | FK → `diagnose` |
| `kontaktart` | integer | NOT NULL |
| `storniert` | boolean |  |
| `eberechtiungkontaktzeitpunkt` | timestamp |  |
| `fachgebietcode` | text |  |
| `gueltigbisuploadtoken` | timestamp |  |
| `uploadtoken` | text |  |
| `gemeindecode` | text |  |
| `vpnr` | text |  |
| `patient_ident` | bigint | FK → `patient` |

### besuch
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `ankunft` | timestamp |  |
| `besuchohneanwesenheit` | boolean | NOT NULL |
| `bgfall` | boolean | NOT NULL |
| `ende` | timestamp |  |
| `imbettseit` | timestamp |  |
| `infotext` | text |  |
| `kvfall` | boolean | NOT NULL |
| `listenpositionbett` | integer | NOT NULL. zur Sortierung der anstehenden Betten in der Bettenuebersicht |
| `privatfall` | boolean | NOT NULL |
| `terminzeit` | timestamp |  |
| `unfall` | boolean | NOT NULL |
| `unfallort` | text |  |
| `unfalltag` | timestamp |  |
| `wichtig` | boolean | NOT NULL |
| `aufnahmedurch_ident` | bigint | FK → `nutzer` |
| `bett_ident` | bigint | FK → `bett` |
| `bettanstehend_ident` | bigint | FK → `bett` |
| `patient_ident` | bigint | FK → `patient` |
| `boolcol1` | boolean | NOT NULL. generischeSpalte (nutzerdefiniert) |
| `boolcol2` | boolean | NOT NULL. generischeSpalte (nutzerdefiniert) |
| `stringcol1` | text | generischeSpalte (nutzerdefiniert) |
| `stringcol2` | text | generischeSpalte (nutzerdefiniert) |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `kartenichtgesteckt` | boolean | NOT NULL |
| `preferredschein_ident` | bigint | FK → `kvschein` |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |
| `preferredprivatrechnung_ident` | bigint | FK → `privatrechnung` |
| `terminzeitenasstring` | text |  |
| `ueberweiser_ident` | bigint | FK → `hausarzt` |
| `untersuchungmodalitaet` | text |  |
| `untersuchungregion` | text |  |
| `keinoffenerschein` | boolean |  |
| `sortierung` | integer |  |
| `preferreddvpschein_ident` | bigint | FK → `dvpschein` |
| `terminart` | text |  |
| `ankunftpappwartezimmer` | timestamp |  |
| `endepappwartezimmer` | timestamp |  |
| `preferredkzvschein_ident` | bigint | FK → `kzvschein` |
| `preferredhzvdetails_ident` | bigint | FK → `hzvdetails` |
| `mkgfall` | boolean |  |
| `aktenzeichen_ident` | bigint | FK → `aktenzeichen` |
| `besuchart` | smallint |  |
| `terminkalender` | text |  |
| `terminlokalitaeten` | text |  |

### konsultation
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abrechnenderkostentraeger` | text |  |
| `abrechnungsperiode` | text |  |
| `abstimmungsbeleg` | text |  |
| `bearbeitungsdatum` | timestamp |  |
| `bearbeitungsdatumsignatur` | timestamp |  |
| `behandlungsdatum` | timestamp |  |
| `behandlungsfall` | text |  |
| `beleginhaltversion` | integer |  |
| `bezugsbereich` | text |  |
| `bundesland` | text |  |
| `ersatzbelegcode` | text |  |
| `fachgebiet` | text |  |
| `idnr` | text |  |
| `konsultationsart` | text |  |
| `limitpruefung` | text |  |
| `ordinationnr` | text |  |
| `originalversicherungstraeger` | text |  |
| `overlimit` | boolean |  |
| `status` | text |  |
| `txnnr` | text |  |
| `version` | integer |  |
| `vpnr` | text |  |
| `kartendaten_ident` | bigint | FK → `kartendaten` |
| `nacherfassungsgrund` | text |  |
| `erstkonsultation` | boolean |  |
| `keinanspruch` | boolean |  |
| `visible` | boolean | NOT NULL |
| `ocardtoken` | text |  |
| `leistungsversicherungstraeger` | text |  |
| `vsnr` | text |  |

### sitzung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `anfang` | timestamp |  |
| `ende` | timestamp |  |
| `ident` | bigint | PK. FK → `behandlungsfallelement` |
| `sitzungsnummer` | integer |  |

### xbesuchsanliegen
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `alsoshowifhasappointment` | boolean | NOT NULL |
| `autocompletebesuch` | boolean | NOT NULL |
| `besuchsinfo` | text |  |
| `removed` | boolean | NOT NULL |
| `name_ident` | bigint | FK → `xtranslatabletext`. NOT NULL |
| `successtext_ident` | bigint | FK → `xtranslatabletext` |
| `successtitle_ident` | bigint | FK → `xtranslatabletext` |

## 5. Karteieintraege & Formulare

### angefordertesjsonformular
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `responseid` | text |  |
| `verschicktanemailadresse` | text |  |
| `zuletztverschickt` | timestamp |  |
| `formular_ident` | bigint | FK → `karteieintrag` |
| `patient_ident` | bigint | FK → `patient` |
| `termin_ident` | bigint | FK → `termin` |
| `jsonformtemplateid` | text |  |
| `link` | text |  |
| `formulartyp_ident` | bigint | FK → `formulartyp` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `visible` | boolean | NOT NULL |
| `formgroupid` | text |  |
| `emaillautformular` | text |  |
| `geburtsdatumlautformular` | text |  |
| `nachnamelautformular` | text |  |
| `vornamelautformular` | text |  |
| `versichertennummerlautformular` | text |  |
| `neupatientendaten_ident` | bigint | FK → `neupatientendaten` |

### customentryerweiterung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `arbmedu_ident` | bigint | FK → `arbmedu` |
| `gravidogrammeintrag_ident` | bigint | FK → `gravidogrammeintrag` |

### customformularbgimage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `image` | text |  |
| `md5` | text |  |

### customformularelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `feldname` | text |  |
| `font` | text |  |
| `fontsize` | integer | NOT NULL |
| `format` | text |  |
| `height` | double | NOT NULL |
| `modus` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |
| `width` | double | NOT NULL |
| `xpos` | double | NOT NULL |
| `ypos` | double | NOT NULL |
| `formularelement_ident` | bigint | FK → `formularelement` |
| `listenpos` | integer | NOT NULL |
| `samevalueelement_ident` | bigint | FK → `customformularelement` |
| `noprefillatcopyfromvorlage` | boolean | NOT NULL |
| `showinkarteitext` | integer |  |
| `persistingkeypath` | text |  |
| `persistingkeypathoption` | text |  |
| `color` | text |  |
| `ismandatory` | boolean | NOT NULL |
| `modificationdate` | timestamp |  |
| `signaturebase64` | text |  |
| `signaturedate` | timestamp |  |
| `listenname` | text |  |

### customformularpage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `backgroundimage` | text |  |
| `page` | integer | NOT NULL |
| `currentimage_ident` | bigint | FK → `customformularbgimage` |
| `notesdata` | text |  |
| `notesimage` | text |  |
| `visibilityoptions` | integer | NOT NULL |
| `signaturebase64` | text |  |
| `signaturedate` | timestamp |  |

### customkarteieintragentry
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `auswahl` | text |  |
| `listenpos` | integer | NOT NULL |
| `modus` | text |  |
| `name` | text |  |
| `removed` | boolean | NOT NULL |
| `value` | text |  |
| `vorauswahl` | text |  |
| `anzeigename` | text |  |
| `widthlabel` | integer |  |
| `widthvalue` | integer |  |
| `callformulartyp_ident` | bigint | FK → `formulartyp` |
| `columncount` | integer |  |
| `showinkarteitext` | integer |  |
| `customkarteieintragentry_ident` | bigint | FK → `customkarteieintragentry` |
| `exportname` | text |  |
| `tooltip` | text |  |
| `alignment` | integer |  |
| `numberoflines` | integer |  |
| `callketteatfirstpos` | boolean | NOT NULL |
| `callketteonlyonce` | boolean | NOT NULL |
| `stopactivekette` | boolean | NOT NULL |
| `karteieintragkette_ident` | bigint | FK → `karteieintragkette` |
| `textsyntax` | text |  |
| `digets` | integer |  |
| `ismandatory` | boolean | NOT NULL |
| `persistingkeypath` | text |  |
| `persistingkeypathoption` | text |  |
| `customentryerweiterung_ident` | bigint | FK → `customentryerweiterung` |
| `color` | text |  |

### formeditablelistelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listenposition` | integer | NOT NULL |
| `listname` | text |  |
| `name` | text |  |
| `removed` | boolean | NOT NULL |
| `autogenerated` | boolean |  |
| `bemerkung` | text |  |
| `zs_ident` | text |  |

### formularelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichner` | text |  |
| `wert` | text |  |
| `datei_ident` | bigint | FK → `datei` |
| `listenpos` | integer |  |
| `jsonformkey` | text |  |
| `jsonformzusatzinfo_ident` | bigint | FK → `jsonformzusatzinfo` |

### formulargruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `isstandard` | boolean |  |
| `removed` | boolean | NOT NULL |
| `printertype` | integer |  |
| `product` | integer |  |

### formulartyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `customimage` | text | Das Bild das in der Toolbar angezeigt wird |
| `font` | text |  |
| `fontsize` | double | NOT NULL |
| `inkarteitoolbar` | boolean | NOT NULL. Ist das Formular in der Karteitoolbar zur Auswahl enthalten |
| `intageslistetoolbar` | boolean | NOT NULL. Ist das Formular in der Tagesliste-Toolbar zur Auswahl enthalten |
| `kuerzel` | text |  |
| `name` | text |  |
| `papersize_height` | double | NOT NULL |
| `papersize_width` | double | NOT NULL |
| `visible` | boolean | NOT NULL |
| `xibfile` | text |  |
| `formtemplate_ident` | bigint | FK → `karteieintrag` |
| `art` | integer | NOT NULL. 0 = normal, 1 = BG-Formular |
| `tooltip` | text |  |
| `ohnearztstempel` | boolean | NOT NULL |
| `musternummer` | text | Benutzung der Adresse laut Karte fuer 5, 6, 7, 10, 10A, 19, 39 |
| `numberofdirectpages` | integer |  |
| `printpagesforblanko` | text | comma-seperated list of pages |
| `printpagesfordirect` | text | comma-seperated list of pages |
| `showelementbackground` | boolean | NOT NULL |
| `customformular` | boolean | NOT NULL |
| `customformularcolor` | text |  |
| `customformularimage` | text |  |
| `kettenausloeser` | integer |  |
| `tagdaleuv` | text |  |
| `versiondaleuv` | text |  |
| `customformulardefaulttyp` | integer | NOT NULL. 0 = default, 1 = Kassenbuchbeleg, 2 = Terminzettel |
| `directprint` | boolean | NOT NULL |
| `omitsicdbezeichnung` | boolean | // rf. http://forum.tomedo.de/index.php/4532/icd-code-laborschein-ohne-textbezeichnung |
| `nonpersiting` | boolean |  |
| `hintergrundfarbeinkartei` | text |  |
| `textfarbeinkartei` | text |  |
| `onlineid` | text |  |
| `marketplaceversion` | integer |  |
| `hiddenforselection` | boolean |  |
| `lastusage` | timestamp |  |
| `ignoreonios` | boolean | NOT NULL |
| `openingmode` | integer | NOT NULL |
| `kategorie` | text |  |
| `listenposition` | integer | NOT NULL |
| `ausgeblendet` | boolean |  |
| `customkarteitextformat` | text |  |
| `jsonformtemplateid` | text |  |
| `hatpersonenstammdaten` | boolean |  |
| `zollsofttrackingstring` | text |  |
| `jsonformpermanentlink` | text |  |
| `formulargruppe_ident` | bigint | FK → `formulargruppe` |
| `handoffmodus` | integer |  |
| `jsonforminstanceid` | text |  |
| `jsonformoverridesglobalrueckschriebsetting` | boolean |  |
| `epadocumentclasscode` | text |  |
| `epadocumenttypecode` | text |  |
| `epauploadvorlage_ident` | bigint | FK → `epauploadvorlage` |

### formulartyplistenelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listenpos` | integer |  |
| `formulartyp_ident` | bigint | FK → `formulartyp` |

### fragebogen
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beschreibung` | text |  |
| `externfragebogenid` | bigint |  |
| `externfragebogenkuerzel` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `balance` | integer |  |
| `defaultnorm_ident` | bigint | FK → `fragebogennorm` |
| `defaultreport_ident` | bigint | FK → `fragebogenreport` |
| `defaultskala_ident` | bigint | FK → `fragebogenskala` |
| `defaultsubtest_ident` | bigint | FK → `fragebogensubtest` |
| `aktuellerpreisincent` | integer |  |

### fragebogenbatterie
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abgeschlossenam` | timestamp |  |
| `erstelltam` | timestamp |  |
| `istemplate` | boolean | NOT NULL |
| `loginurl` | text |  |
| `name` | text |  |
| `status` | integer | REGISTERED=1, INCOMPLETE=2, COMPLETE=3, CANCELED=4 |
| `visible` | boolean | NOT NULL |
| `hogrefepatientenanmeldedaten_ident` | bigint | FK → `hogrefepatientenanmeldedaten` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `externbatterieid` | text |  |
| `patient_ident` | bigint | FK → `patient` |
| `testanbieteraccount_ident` | bigint | FK (intern) |

### fragebogenergebnis
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `externbatterieid` | text |  |
| `visible` | boolean | NOT NULL |
| `xmlergebnis` | text |  |
| `fragebogen_ident` | bigint | FK → `fragebogen` |
| `selectedfragebogennorm_ident` | bigint | FK → `fragebogennorm` |
| `selectedfragebogenskala_ident` | bigint | FK → `fragebogenskala` |
| `selectedreport_ident` | bigint | FK → `fragebogenreport` |
| `selectedsubtest_ident` | bigint | FK → `fragebogensubtest` |
| `index` | integer |  |
| `status` | integer | REGISTERED=1, INCOMPLETE=2, COMPLETE=3, CANCELED=4 |
| `fragebogenergebnispdfdatei_ident` | bigint | FK → `datei` |
| `ausgewertetam` | timestamp |  |
| `featuretrackingversendet` | boolean |  |
| `preisincent` | integer |  |
| `ausgewertetvon_ident` | bigint | FK → `nutzer` |

### fragebogennorm
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `externnormid` | bigint |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### fragebogenreport
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `externreportid` | text |  |
| `licensed` | boolean | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### fragebogenskala
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `externskalaid` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### fragebogensubtest
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `duration` | text |  |
| `externsubtestid` | text |  |
| `externuniqueid` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### jsonformanforderungcondition
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `visible` | boolean | NOT NULL |
| `frueherkennungsregel_ident` | bigint | FK → `frueherkennungsregel` |
| `zeitraumkomponenten_ident` | bigint | FK → `zeitraumkomponenten` |
| `active` | boolean |  |
| `conditiontype` | text |  |
| `gueltigkeittype` | text |  |
| `name` | text |  |

### jsonformattachment
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `jsonformelementname` | text |  |
| `jsonformelementtype` | text |  |
| `datei_ident` | bigint | FK → `datei` |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |

### jsonformrueckschriebsetting
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `global` | boolean |  |
| `rueckschrieboption` | integer |  |
| `visible` | boolean | NOT NULL |
| `wfakey` | text |  |
| `formulartyp_ident` | bigint | FK → `formulartyp` |

### jsonformzusatzinfo
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `removed` | boolean | NOT NULL |
| `vorbefuellung` | text |  |
| `showinkarteitext` | integer |  |

### karteieintrag
> s. Klassendiagramm PatientenDetailsRelationen
> s, Klassendiagramm Karteieintrag

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `primaer` | boolean | NOT NULL. nur wichtig fuer CAVE |
| `text` | text |  |
| `visible` | boolean | NOT NULL |
| `druckdatum` | timestamp |  |
| `headerline1` | text |  |
| `headerline2` | text |  |
| `headerline3` | text |  |
| `headerline4` | text |  |
| `headerline5` | text |  |
| `headerline6` | text |  |
| `headerline7` | text |  |
| `quartal` | text |  |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `bgformular_ident` | bigint | FK → `bgformular` |
| `bgschein_ident` | bigint | FK → `privatrechnung` |
| `diagnose_ident` | bigint | FK → `diagnose` |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `karteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `laborauftrag_ident` | bigint | FK → `laborauftrag` |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `mediatyp_ident` | bigint | FK → `karteieintragmediatyp` |
| `arzt_ident` | bigint | FK → `nutzer` |
| `formulartyp_ident` | bigint | FK → `formulartyp` |
| `abrechnungstyp` | integer |  |
| `kvschein_ident` | bigint | FK → `kvschein` |
| `drucklinks` | real |  |
| `druckrechts` | real |  |
| `achselinks` | real |  |
| `achserechts` | real |  |
| `freitext` | text |  |
| `sphaerelinks` | real |  |
| `sphaererechts` | real |  |
| `zylinderlinks` | real |  |
| `zylinderrechts` | real |  |
| `messtyp` | integer |  |
| `addlinks` | real |  |
| `addrechts` | real |  |
| `basislinks` | integer |  |
| `basisrechts` | integer |  |
| `prismalinks` | real |  |
| `prismarechts` | real |  |
| `pupillendistanz` | real |  |
| `scheitelabstandlinks` | real |  |
| `scheitelabstandrechts` | real |  |
| `refraktioneintrag_ident` | bigint | FK → `karteieintrag` |
| `hhr1links` | real |  |
| `hhr1rechts` | real |  |
| `hhr2links` | real |  |
| `hhr2rechts` | real |  |
| `keraachselinks` | real |  |
| `keraachserechts` | real |  |
| `kerafreitext` | text |  |
| `ccvisusfernbintext` | text |  |
| `ccvisusfernlinkstext` | text |  |
| `ccvisusfernrechtstext` | text |  |
| `ccvisusnahbintext` | text |  |
| `ccvisusnahlinkstext` | text |  |
| `ccvisusnahrechtstext` | text |  |
| `scvisusfernbintext` | text |  |
| `scvisusfernlinkstext` | text |  |
| `scvisusfernrechtstext` | text |  |
| `scvisusnahbintext` | text |  |
| `scvisusnahlinkstext` | text |  |
| `scvisusnahrechtstext` | text |  |
| `anestesist_ident` | bigint | FK → `nutzer` |
| `operateur1_ident` | bigint | FK → `nutzer` |
| `operateur2_ident` | bigint | FK → `nutzer` |
| `termin_ident` | bigint | FK → `termin` |
| `modus` | text |  |
| `augenfreitext` | text |  |
| `json` | text |  |
| `name` | text |  |
| `opfreitext` | text |  |
| `folgearzt_ident` | bigint | FK → `hausarzt` |
| `ueberweiser_ident` | bigint | FK → `hausarzt` |
| `heilmittel_1_ident` | bigint | FK → `heilmittel` |
| `heilmittel_2_ident` | bigint | FK → `heilmittel` |
| `augendruckmesstyp_ident` | bigint | FK → `augendruckmesstyp` |
| `allinks` | real |  |
| `alrechts` | real |  |
| `iolachselinks` | real |  |
| `iolachserechts` | real |  |
| `iolemmetropielinks` | real |  |
| `iolemmetropierechts` | real |  |
| `iolimplantiertlinks` | real |  |
| `iolimplantiertrechts` | real |  |
| `iolziellinks` | real |  |
| `iolzielrechts` | real |  |
| `iolzylinderlinks` | real |  |
| `iolzylinderrechts` | real |  |
| `keraachse1links` | real |  |
| `keraachse1rechts` | real |  |
| `keraachse2links` | real |  |
| `keraachse2rechts` | real |  |
| `kerazylinderlinks` | real |  |
| `kerazylinderrechts` | real |  |
| `vktlinks` | real |  |
| `vktrechts` | real |  |
| `hzvdetails_ident` | bigint | FK → `hzvdetails` |
| `heilmittel_1b_ident` | bigint | FK → `heilmittel` |
| `nachrichtthread_ident` | bigint | FK → `nachrichtthread` |
| `gedruckterechnung_ident` | bigint | FK → `privatrechnung` |
| `additionaltext` | text |  |
| `formel` | text |  |
| `iolziel0links` | real |  |
| `iolziel0rechts` | real |  |
| `status` | integer | Unterschiedliche Bedeutungen, je nach Typ.. Fuer EArztbriefe: -1 = Sendefehler, 0 = Neu, 1 = Versandt, 2 = Bestaetigt, 3 = wird versendet  |
| `untersuchungsbesuch_ident` | bigint | FK → `besuch` |
| `anaesthesiedoku_ident` | bigint | FK → `anaesthesiedoku` |
| `bgunfallrechnung_ident` | bigint | FK → `privatrechnung` |
| `dateidaleuv_ident` | bigint | FK → `datei` |
| `heilmittel_1c_ident` | bigint | FK → `heilmittel` |
| `korrekturlinks` | real |  |
| `korrekturrechts` | real |  |
| `aufgabe_ident` | bigint | FK → `aufgabe` |
| `globalident` | text |  |
| `letzteaenderungam` | timestamp |  |
| `icpc2_ident` | bigint | FK → `icpc2` |
| `thenadocument_ident` | bigint | FK → `thenadocument` |
| `geschlecht` | text |  |
| `hzvitvedocument_ident` | bigint | FK → `hzvitvedocument` |
| `arztbriefeav_ident` | bigint | FK → `arztbriefeav` |
| `chopcode_ident` | bigint | FK → `chopcode` |
| `allergiezusatzinfo_ident` | bigint | FK → `allergiezusatzinfo` |
| `konsileav_ident` | bigint | FK → `konsileav` |
| `druckpdf_ident` | bigint | FK → `datei` |
| `elektronischeau_ident` | bigint | FK → `elektronischeau` |
| `eformular_ident` | bigint | FK → `eformular` |
| `rezept_ident` | bigint | FK → `rezept` |
| `roentgenbucheintrag_ident` | bigint | FK → `roentgenbucheintrag` |
| `indentalablage` | boolean |  |
| `internetmarke_ident` | bigint | FK (intern) |
| `signaturebase64` | text |  |
| `signaturedate` | timestamp |  |
| `berufsgenossenschaft_ident` | bigint | FK → `berufsgenossenschaft` |
| `vidierungsstatus_ident` | bigint | FK → `vidierungsstatus` |
| `edokumentation_ident` | bigint | FK → `edokumentation` |
| `arztstempelusage_ident` | bigint | FK → `arztstempelusage` |
| `zahn` | text |  |
| `kzvschein_ident` | bigint | FK → `kzvschein` |
| `dateijson_ident` | bigint | FK → `datei` |
| `jsonformgelesen` | boolean |  |
| `jsonformsource` | integer |  |
| `patientunterschriebenam` | timestamp |  |
| `irdanfrage_ident` | bigint | FK → `irdanfrage` |
| `iszahnarzt` | boolean |  |
| `epauploadstatus_ident` | bigint | FK → `epauploadstatus` |
| `jsonformresponseid` | text |  |
| `serveronlyplaintext` | text |  |
| `jsonformrueckschriebstatus` | integer |  |

### karteieintraganhang
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `listenposition` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `adressfeld` | text |  |
| `anrede` | text |  |
| `druckdatum` | timestamp |  |
| `druckstatus` | integer |  |
| `faxnr` | text |  |
| `individualchange` | boolean |  |
| `nameintable` | text |  |
| `papier` | integer |  |
| `typ` | text |  |
| `file_ident` | bigint | FK → `datei` |
| `arzt_ident` | bigint | FK → `nutzer` |
| `email` | text |  |
| `identempfaenger` | bigint |  |
| `anzeigename` | text |  |
| `briefvorlage_ident` | bigint | FK → `briefvorlage` |
| `internetmarke_ident` | bigint | FK (intern) |
| `kimsendedatum` | timestamp |  |
| `kimsignaturdatum` | timestamp |  |
| `kimsignaturiccsn` | text |  |
| `kimsignaturnutzer` | text |  |
| `pdffile_ident` | bigint | FK → `datei` |
| `pdffilesigned_ident` | bigint | FK → `datei` |
| `freigabedatum` | timestamp |  |
| `freigabevon_ident` | bigint | FK → `nutzer` |
| `classnameempfaenger` | text |  |
| `epauploadstatus_ident` | bigint | FK → `epauploadstatus` |
| `epauploaddecision` | integer |  |

### karteieintragkette
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `karteieintraege` | text |  |
| `kuerzel` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `showwindow` | boolean | NOT NULL |
| `inkarteitoolbar` | boolean | NOT NULL |
| `customimage` | text |  |
| `runsinbackground` | boolean | NOT NULL |
| `availablefortermine` | boolean | NOT NULL |
| `isgroup` | boolean |  |
| `listenpos` | integer |  |
| `hiddenforselection` | boolean |  |

### karteieintragketteeintrag
> Wrapper-Classe um Kette in richtige Sortierung zu bringen
> Enthaelt Aktionen, die ausgefuehrt werden (z.B. Doku eines Favoriten)

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `commandozeile` | text |  |
| `favoritdiaginkartei` | boolean | NOT NULL |
| `gdt` | text |  |
| `listenpos` | integer |  |
| `typ` | text |  |
| `visible` | boolean | NOT NULL |
| `applescript_ident` | bigint | FK → `skript` |
| `formulartyp_ident` | bigint | FK → `formulartyp` |
| `karteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `outlineviewelement_ident` | bigint | FK → `outlineviewelement` |
| `briefvorlage_ident` | bigint | FK → `briefvorlage` |
| `hausapothekenelement_ident` | bigint | FK → `hausapothekenelement` |
| `hinweisfenstertext` | text |  |
| `prefillkarteieintrag` | text |  |
| `todokette_ident` | bigint | FK → `todokette` |
| `shownotkarteipopover` | boolean | NOT NULL |
| `todovorlage_ident` | bigint | FK → `todovorlage` |
| `tag_ident` | bigint | FK → `tag` |
| `konfiguration` | integer | Konfigurationen - bei Tag: 0 setzen, 1 entfernen |
| `switchkette_ident` | bigint | FK → `karteieintragkette` |
| `createinstantly` | boolean |  |
| `guiactioncondition_ident` | bigint | FK → `guiactioncondition` |
| `icpc2_ident` | bigint | FK → `icpc2` |
| `callketteatfirstpos` | boolean | NOT NULL |
| `callketteonlyonce` | boolean | NOT NULL |
| `stopactivekette` | boolean | NOT NULL |
| `terminkettesuche_ident` | bigint | FK → `terminkettesuche` |
| `terminsuche_ident` | bigint | FK → `terminsuche` |
| `recalltyp_ident` | bigint | FK → `recalltyp` |
| `formularvorlage_ident` | bigint | FK → `karteieintrag` |
| `printformimmediately` | boolean | NOT NULL |
| `emailvorlage_ident` | bigint | FK → `emailvorlage` |
| `privatrechnungtyp_ident` | bigint | FK → `privatrechnungtyp` |
| `privatrechnungvorlage_ident` | bigint | FK → `privatrechnungvorlage` |
| `patientenschlange_ident` | bigint | FK → `patientenschlange` |
| `smsvorlage_ident` | bigint | FK → `smsvorlage` |
| `patientenzugriffsrechtvorlage_ident` | bigint | FK → `patientenzugriffsrechtvorlage` |
| `isgroup` | boolean | NOT NULL |
| `karteiversandprofil_ident` | bigint | FK → `karteiversandprofil` |
| `favorituebernahmemodus` | integer |  |
| `writebackkeypath` | integer |  |
| `writebackoption` | integer |  |
| `writebackseperator` | text |  |
| `vitalwerteeinstellung_ident` | bigint | FK → `vitalwerteeinstellung` |
| `guiactionquestion_ident` | bigint | FK → `guiactionquestion` |
| `printform` | integer |  |
| `deletemode` | integer |  |
| `deletetimebis` | integer |  |
| `deletetimemode` | integer |  |
| `deletetimevon` | integer |  |
| `coderegex` | text |  |
| `ebmkatalogeintrag_ident` | bigint | FK → `ebmkatalogeintrag` |
| `emailaccount_ident` | bigint | FK → `emailaccount` |
| `frueherkennungskrankheit_ident` | bigint | FK → `frueherkennungskrankheit` |
| `kvscheingruppe_ident` | bigint | FK → `kvscheingruppe` |
| `konsultationbehandlungsfall` | text |  |
| `orderentry` | text |  |
| `hzvhonoraranlage_ident` | bigint | FK → `hzvhonoraranlage` |
| `goaekatalogeintrag_ident` | bigint | FK → `goaekatalogeintrag` |
| `customkarteieintragentry_ident` | bigint | FK → `customkarteieintragentry` |
| `callketteimmediately` | boolean |  |

### karteieintragmediatyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `textpattern1` | text | Definition eines Pattern fuer Kommunikation mit seriellen Geraeten (z.B. bei Refraktion)  |
| `textpattern2` | text | alternative Def. eines Pattern fuer Kommunikation mit seriellen Geraeten (z.B. bei Refraktion nur Visus)  |
| `checkbox1` | boolean | NOT NULL |
| `zsident` | integer |  |

### karteieintragtyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `custom` | boolean | NOT NULL |
| `customimage` | text |  |
| `farbe` | text |  |
| `inkarteitoolbar` | boolean | NOT NULL. Ist das Item in der Karteitoolbar zur Auswahl enthalten |
| `kuerzel` | text |  |
| `name` | text |  |
| `subpathforanhang` | text |  |
| `visible` | boolean | NOT NULL |
| `standardmediatyp_ident` | bigint | FK → `karteieintragmediatyp` |
| `backgroundcolor` | text |  |
| `hasbriefvorlageformular` | boolean | NOT NULL |
| `namebriefvorlageformular` | text |  |
| `briefmergekuerzel` | text |  |
| `hasbriefmergetyp` | boolean | NOT NULL |
| `webformularvorlage_ident` | bigint | FK → `webformularvorlage` |
| `columncount` | integer | Anzahl der Spalten die im KarteiPopover in der Macrotabelle angezeigt werden (nil = 4) |
| `standardauswahl` | text | fuer standardauswahl refraktion(LM,AR) oder Augendruck (APPL,NPP) |
| `listenposforkartei` | real | NOT NULL |
| `augendruckmesstyp_ident` | bigint | FK → `augendruckmesstyp` |
| `tabellefortlaufend` | boolean |  |
| `tabellezusatzinfo` | boolean |  |
| `hintergrund_ident` | bigint | FK → `datei` |
| `marketplaceversion` | integer |  |
| `onlineid` | text |  |
| `hiddenforselection` | boolean |  |
| `lastusage` | timestamp |  |
| `customkarteitextformat` | text |  |
| `customkarteitextformatedit` | boolean | NOT NULL |
| `popoverheight` | integer |  |
| `popoverwidth` | integer |  |
| `briefvorlage_ident` | bigint | FK → `briefvorlage` |
| `laborpopoverselection` | integer |  |
| `vidierbarkeit` | integer | 0/null = nein, 1= (manuell) vidierpflichtig, 2 = immer vidierpflichtig |
| `vorbelegungvidierungmode` | integer | 0/null = keine, 1= Erstbehandler, 2= Hauptbehandler, 3= alle behandler, bitwise. nutzer(gruppen)relationen kommen on top dazu |
| `shouldcreatemetadaten` | boolean | NOT NULL |
| `preventautosetvidiert` | boolean |  |
| `konfigvidierbarkeitoperator` | integer |  |
| `konfigvidierbarkeittextliste` | text |  |
| `macrolist_ident` | bigint | FK → `macrolist` |
| `vidierungsstatuspriority` | integer |  |
| `zuvidierendurchmodus` | integer |  |
| `nichtexportierbar` | boolean |  |
| `zahnschemaanzeigen` | boolean |  |
| `zahnauswahlpopoveranzeigen` | boolean | NOT NULL |
| `nutzerdefiniert` | boolean |  |
| `zsident` | integer |  |
| `defaultordnername` | text |  |
| `createwithcustomtimeshift` | integer |  |
| `customtimeshift` | text |  |
| `epadocumentclasscode` | text |  |
| `epadocumenttypecode` | text |  |
| `epatitle` | text |  |
| `epauploadvorlage_ident` | bigint | FK → `epauploadvorlage` |

### karteiimport
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `errortext` | text |  |
| `jsontext` | text |  |
| `quellsystem` | text |  |
| `removed` | boolean | NOT NULL |
| `status` | integer | NOT NULL |
| `vorschautext` | text |  |
| `importfile_ident` | bigint | FK → `datei` |
| `serverident` | bigint |  |

### karteiversandprofil
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `allenutzer` | boolean |  |
| `anhaengemodus` | integer |  |
| `briefemodus` | integer |  |
| `fileextensionfilter` | text |  |
| `formularemodus` | integer |  |
| `karteieintraegemodus` | integer |  |
| `name` | text |  |
| `rechnungenmodus` | integer |  |
| `terminemodus` | integer |  |
| `zsident` | integer |  |
| `briefvorlage_ident` | bigint | FK → `briefvorlage` |
| `emailvorlage_ident` | bigint | FK → `emailvorlage` |
| `visible` | boolean | NOT NULL |

### webformularvorlage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `removed` | boolean | NOT NULL |

## 6. Diagnosen

### diagnose
> s. Klassendiagramm ICD

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anamnestischeddi` | boolean | NOT NULL |
| `ausnahmetatbestandddi` | text | = FK3677 wenn DDI, FK6008 wenn keine DDI |
| `datum` | timestamp |  |
| `diagnosenerlaeuterungddi` | text | = FK3676 wenn DDI, FK6006 wenn keine DDI |
| `freitext` | text |  |
| `isddi` | boolean | NOT NULL |
| `lokalisation` | text |  |
| `typ` | text |  |
| `visible` | boolean | NOT NULL |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `icdkatalogeintrag_ident` | bigint | FK → `icdkatalogeintrag` |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `alreadyshownvorschlaege` | integer | NOT NULL. 1 = Diagnosesicherheitfenster. 2 = Substitution (z.B. ABRD790) |
| `alsstellvertreter` | boolean | NOT NULL |
| `stellvertreter_ident` | bigint | FK → `nutzer` |
| `abgesetzt` | integer |  |
| `color` | text |  |
| `letzteaenderung` | timestamp |  |
| `sortierung` | integer |  |
| `anamnestischseit` | timestamp |  |
| `abgesetztstatusseit` | timestamp |  |
| `kennzeichen` | integer | NOT NULL. 0: standard, 1: hauskrankenpflegerelevant (AT) |
| `rehabehandlungsergebnis` | text |  |
| `kategorie` | integer | Vereinheitlicht iDDI, anamnestischeDDI in xtomedo. Siehe DiagnoseKategorie-Enum |
| `serveronlyplaintext` | text |  |

### diagnosebgformular
> 0 = ICD10, 1 = ICPM, 2 = AO-Klassifikation

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `artderdiagnose` | integer |  |
| `diagnosecode` | text |  |
| `diagnosetext` | text |  |

### icd10code
> CATALOGENTRY

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `code` | text |  |
| `text` | text |  |
| `parent_ident` | bigint | FK → `icd10code` |

### icdkatalogeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abrechenbar` | boolean |  |
| `altersbezugfehlerart` | text |  |
| `bezeichnung` | text |  |
| `code` | text |  |
| `favoritinheilmittelicdauswahl` | boolean | NOT NULL. wird vom User gesetzt, nicht durch irgendeinen import |
| `geschlechtsbezug` | text |  |
| `geschlechtsbezugfehlerart` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `infektionsschutzgesetzabrechnungsbesonderheit` | boolean |  |
| `infektionsschutzgesetzmeldepflicht` | boolean |  |
| `krankheitinmitteleuropasehrselten` | boolean |  |
| `notationskennzeichen` | text | + fuer Grunderkrankungen. * fuer Komplikationen. ! fuer zusaetzliche Modifikatoren |
| `oberealtersgrenzeinjahren` | integer |  |
| `oberealtersgrenzeintagen` | integer |  |
| `schluesselnummermitinhaltbelegt` | boolean |  |
| `unterealtersgrenzeinjahren` | integer |  |
| `unterealtersgrenzeintagen` | integer |  |
| `realcode` | text | code ohne - am Ende |
| `color` | text |  |
| `katalogtyp` | integer | null, 0 : ICD-Katalog; 1: TessinerCode |
| `keineeignungdauerdiagnose` | boolean |  |
| `bezeichnung_phonetic` | text |  |
| `autosubstitution_ident` | bigint | FK → `icdautosubstitution` |

### icdkataloggruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `bisicd` | text |  |
| `vonicd` | text |  |

### icdkatalogkapitel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `bisicd` | text |  |
| `code` | text |  |
| `vonicd` | text |  |

### icdthesauruseintrag
> Thesauruseintraege, die an keinen ICD-Code angehaengt sind, sind allgemeine Hinweistext
> wie z.B. "Abusus s.a. Missbrauch"

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `fuerarztgruppen` | text | Komma-separierte Liste von Arztgruppenziffern (z.B. 3 für Hausrzt) |
| `bezeichnung_phonetic` | text |  |

### icpc2
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `freitext` | text |  |
| `lokalisation` | text |  |
| `icpc2katalogeintrag_ident` | bigint | FK → `icpc2katalogeintrag` |

### icpc2katalogeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `color` | text |  |
| `gruppebezeichnung` | text |  |
| `gruppecode` | text |  |
| `icpc2bezeichnung` | text |  |
| `icpc2code` | text |  |
| `visible` | boolean | NOT NULL |
| `component` | integer | NOT NULL |

### zuordnungicdops
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `count` | bigint | Gibt an wie haeufig diese Zuordnung vorkommt |
| `icdcode` | text |  |
| `opscode` | text |  |

## 7. EBM-Leistungen

### ebmkatalogeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anhang2typ` | text | Typ der Leistung im Anhang2 des EBM-Katalogs (z.B. Operation, Ueberwachung, etc ) |
| `anmerkungen` | text | multiple Anmerkungen seperated by '\n' |
| `code` | text |  |
| `gruppe` | text | kann vermutlich geloescht werden |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp | um schnell entscheiden zu koennen, ob suchbar |
| `kapitelbezeichnung` | text |  |
| `kurztext` | text | aktuellster Kurztext |
| `quittungstext` | text |  |
| `temporaer` | boolean | NOT NULL. true fuer haendisch angelegt Eintraege |
| `nichtabrechenbar` | boolean | NOT NULL. selbst definierte Eintraege koennen als nicht mit in die Abrechnung zu uebernehmen markiert werden |
| `farbe` | text |  |
| `custompruefzeit` | integer | Nutzer kann Pruefzeiten selbst definieren und Auswertungen darueber machen |
| `customzusatzangaben` | text | comma-seperated List of Feldkennungen |
| `dtype` | varchar | NOT NULL |
| `nichtfuerarztpraxis` | boolean | NOT NULL |
| `lastimportfromkvcatalogue` | timestamp | in contrast to import from KBV-catalogue |
| `nichtfuerarztpraxisoverride` | boolean | falls Praxis eine solche Ziffer doch unbedingt selber abrechnen will |
| `bezugspersonoverride` | integer |  |
| `halbeleistungoverride` | integer | 0/Null = berechnet, 1 = Ja, 2 = Nein |
| `rezidivoverride` | integer |  |
| `aktuellequelle` | integer | 1= KBV (74), 2 = KV, 3 = both |
| `respectsuffixforregelcheck` | boolean |  |
| `customregelleistungsvolumen` | integer |  |

### ebmkatalogeintragdetails
> enthaelt zu historisierende Angaben

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `eurowertincent` | real |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `kurztext` | text |  |
| `langtext` | text |  |
| `pruefzeit` | integer | KBV Pruefzeit in Sekunden; Der Typ (Tages-, Quartalsbudget, ?) . wird duch Feld zeitprofilart bestimmt |
| `punktwert` | real |  |
| `regelleistungsvolumen` | integer |  |
| `removed` | boolean | NOT NULL. werden beim base-Daten-Laden ignoriert |
| `temporaer` | boolean |  |
| `zeitbedarf` | integer | Von der KBV festgelegter Zeitbedarf in Sekunden |
| `zeitprofilart` | integer | 2 = Quartalsprofil; 3 = Tages- und Quartalsprofil |
| `createdinquartal` | timestamp |  |

### ebmleistungskatalog
> nuetzlich beim Base-Daten-Laden 
> um nur bestimmte Kataloge herunterzuladen

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `s3ccodelegruppe` | text | cannot be modelled via Relation. as Gruppe is cleanedUp on Import |
| `s3cvertragsname` | text |  |

### leistung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `anzahl` | integer | NOT NULL. Entspricht Feld 5005 (Multiplikator) bei EBMLeistungen. |
| `datum` | timestamp | Beinhaltet sowohl Datum (Feld 5000). als auch Um-Uhrzeit (Feld 5006) |
| `visible` | boolean | NOT NULL |
| `aerzte5016` | text |  |
| `artderuntersuchung5002` | text |  |
| `aufnahmedatum5025` | timestamp |  |
| `doppelkilometer5008` | integer |  |
| `entlassungsdatum5026` | timestamp |  |
| `erbringungsort5019` | text |  |
| `freitextbegruendung5009` | text |  |
| `gebuehrenordungsnummernzusatz5023` | text |  |
| `gesamtschnittnahtzeit5037` | integer |  |
| `jahrletztekrebsfrueherkennung5021` | integer |  |
| `komplikation5038` | text |  |
| `kontrastoderarzneimitteleinheit5043` | integer |  |
| `kontrastoderarzneimittelmenge5042` | integer |  |
| `opdatum5034` | timestamp |  |
| `organe5015` | text |  |
| `orthausbesuch5017` | text |  |
| `patientennrfekbogen5040` | text |  |
| `poststationaereleistung5024` | boolean |  |
| `prozentderleistung5013` | integer |  |
| `umuhrzeit5006` | timestamp |  |
| `wiederholungsuntersuchung5020` | boolean |  |
| `zonehausbesuch5018` | text |  |
| `begruendung5009` | text |  |
| `issachkosten` | boolean |  |
| `kostenincent` | integer |  |
| `medikament5050` | text |  |
| `organ5015` | text |  |
| `sachkostenname` | text |  |
| `skelettabschnitt5055` | text |  |
| `steigerungfix` | boolean |  |
| `steigerungsfaktor` | real |  |
| `abrechnenderarzt_ident` | bigint | FK → `nutzer` |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `leistungserbringer_ident` | bigint | FK → `nutzer` |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `arztpatientenkontakt_ident` | bigint | FK → `arztpatientenkontakt` |
| `ebmkatalogeintrag_ident` | bigint | FK → `ebmkatalogeintrag` |
| `invkvschein_ident` | bigint | FK → `kvschein` |
| `goaekatalogeintrag_ident` | bigint | FK → `goaekatalogeintrag` |
| `grundleistung_ident` | bigint | FK → `leistung` |
| `kostenautoreduktion` | boolean |  |
| `ersetzung_ident` | bigint | FK → `leistung` |
| `allgemeinkostenincent` | integer |  |
| `besonderekostenincent` | integer |  |
| `vollkostenincent` | integer |  |
| `hzvkatalogeintrag_ident` | bigint | FK → `hzvkatalogeintrag` |
| `omimerkrankungsnamen5073` | text |  |
| `omimgcode5070` | text |  |
| `omimgennamen5072` | text |  |
| `omimpcode5071` | text |  |
| `anforderungsdatumabrd984` | timestamp |  |
| `anforderungszeitabrd984` | timestamp |  |
| `auftraggeberbsnr` | text |  |
| `auftraggeberlanr` | text |  |
| `invertretung` | boolean |  |
| `namepflegeheimabrd970` | text |  |
| `ortpflegeheimabrd970` | text |  |
| `alsstellvertreter_ident` | bigint | FK → `nutzer` |
| `auftraggeber_ident` | bigint | FK → `hausarzt` |
| `transferid` | text |  |
| `voreinschreibeleistungversandt` | boolean |  |
| `standalonecode` | text |  |
| `begruendung` | text |  |
| `sachkostenmwstsatz` | real |  |
| `qsmbefund` | text |  |
| `chefarztkennzeichenchkz` | text |  |
| `zusatzkennzeichenkeze` | text |  |
| `dvpkatalogeintrag_ident` | bigint | FK → `dvpkatalogeintrag` |
| `asvteamnummer5100_ident` | bigint | FK → `asvteamnummer` |
| `begruendungdatum` | timestamp |  |
| `begruendungkennzeichen` | text |  |
| `begruendungtext` | text |  |
| `sitzung` | integer |  |
| `stelle` | integer |  |
| `uhrzeit` | timestamp |  |
| `visiteort` | text |  |
| `visiteplz` | text |  |
| `visitestrasse` | text |  |
| `zusatzkennzeichenkezeh` | text |  |
| `ssw` | integer |  |
| `zusatzparameter` | text |  |
| `arztnummer5003` | text |  |
| `autogeneratedleistung_ident` | bigint | FK → `leistung` |
| `datumletzteaenderung` | timestamp |  |
| `bemakatalogeintrag_ident` | bigint | FK → `bemakatalogeintrag` |
| `zahn` | text |  |
| `ial_ok` | text |  |
| `kzv_info` | text |  |
| `lany` | text |  |
| `chargennummer5010` | text |  |
| `materialkatalogeintrag_ident` | bigint | FK → `materialkatalogeintrag` |
| `einheit` | text |  |
| `faktor` | integer |  |
| `nettopreisincent` | integer |  |
| `mwstinpromille` | integer |  |
| `rechnung_ident` | bigint | FK → `zahnarztlaborrechnung` |
| `anzahlkilometer` | integer |  |
| `anzahlpatienten` | integer |  |
| `fuellungslage` | text |  |
| `kig` | text |  |
| `zusatzangabebehandlung` | text |  |
| `bzeichng` | text |  |
| `mat_dat` | text |  |
| `forcebesonderkosten` | boolean |  |
| `laborkatalogeintrag_ident` | bigint | FK → `laborkatalogeintrag` |
| `befundgruppe_ident` | bigint | FK → `befundgruppe` |
| `inplanenthalten` | boolean |  |
| `geplanteleistung_ident` | bigint | FK → `leistung` |
| `verlangensleistung` | boolean |  |
| `zsidentifier` | text |  |
| `containedonrechnung_ident` | bigint | FK → `privatrechnung` |
| `privatleistung` | boolean |  |
| `anzahlnenner` | integer |  |
| `warenleistung_ident` | bigint | FK → `warenleistung` |
| `zusatzinformation` | text |  |
| `dokumentationsleistung` | boolean |  |
| `bemazuschuss_ident` | bigint | FK → `leistung` |
| `asvteammanuallyset` | boolean |  |
| `codeforrechnungsposition` | text |  |
| `nameforrechnungsposition` | text |  |
| `isbrutto` | boolean |  |
| `typ` | integer |  |
| `opskatalogeintrag_ident` | bigint | FK → `opskatalogeintrag` |
| `lokalisation` | text |  |
| `freitext` | text |  |
| `cekennzeichen` | text |  |
| `haltbarkeit` | timestamp |  |
| `hersteller` | text |  |
| `material` | text |  |
| `useforkonformitaetserklaerung` | boolean |  |
| `gegenstandswerincent` | bigint |  |
| `staatskasse` | boolean |  |
| `anaesthesie` | smallint |  |
| `ausland` | boolean |  |
| `automatischberechnen` | boolean |  |
| `enddatum` | timestamp |  |
| `inkrement` | integer |  |
| `startdatum` | timestamp |  |
| `ohnefranchise` | boolean |  |
| `status` | integer |  |
| `patient_ident` | bigint | FK → `patient` |
| `sammelabrechnung_ident` | bigint | FK → `sammelabrechnung` |
| `sammelschein_ident` | bigint | FK → `sammelschein` |
| `sammelkatalogeintragarbmed_ident` | bigint | FK → `goaekatalogeintrag` |

### leistungspunktwert
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `tarif` | text |  |
| `visible` | boolean | NOT NULL |
| `wertincent` | integer |  |
| `steigerungsschema_ident` | bigint | FK → `steigerungsschema` |
| `bereichscode` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `kassenart` | text |  |
| `punktwert10stellig` | bigint |  |
| `benutzerdefiniert` | boolean |  |
| `gebuehrennummern` | text |  |
| `personengruppe` | text |  |
| `priority` | integer |  |
| `source` | text |  |

### subgop
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `maxalter` | bigint |  |
| `minalter` | bigint |  |
| `ebmkatalogeintrag_ident` | bigint | FK → `ebmkatalogeintrag`. NOT NULL |

### verknuepfteleistung
> 0 oder null..ignorierte Leistung, 1..geplante Leistung, 2...abgerechnete Leistung

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `leistungsstatus` | integer |  |
| `ebmleistung_ident` | bigint | FK → `leistung` |
| `goaeleistung_ident` | bigint | FK → `leistung` |

## 8. GOAE-Leistungen

### customsteigerungsfaktor
> rf. TOM-14062 

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `steigerung` | real |  |
| `goaekatalogeintrag_ident` | bigint | FK → `goaekatalogeintrag` |
| `tarif_ident` | bigint | FK → `steigerungsschema` |

### gebuehrenabhaengigkeit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abhaengigkeitstyp` | integer |  |
| `leistungstyp` | integer |  |
| `listenpos` | integer |  |
| `visible` | boolean | NOT NULL |
| `referenzgebuehr_ident` | bigint | FK → `leistung` |

### gebuehrenordnungkbv
> aus der Schluesseltabelle S_KBV_GEBUEHRENORDNUNG.xml (1.2.276.0.76.5.231) ausgelesen
> Werte: EBM, Bewertungsmassstab Aerzte, ErsatzkassenGO, GOAE

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `visible` | boolean | NOT NULL |

### goaeabschnitt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### goaeanalogwrapper
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anzahl` | real | NOT NULL |
| `goaekatalogeintrag_ident` | bigint | FK → `goaekatalogeintrag` |

### goaeblock
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text | wenn keine Untergruppe vorhanden, wird der Code der Obergruppe. benutzt. (Bsp. Ziffer 1 , code = B1) |

### goaekapitel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### goaekatalogeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `analogleistung` | boolean | NOT NULL |
| `code` | text |  |
| `eurowertahincent` | integer | NOT NULL. Eurowert fuer allgemeine Heilbehandlung BG |
| `eurowertbhincent` | integer | NOT NULL. Eurowert fuer besondere Heilbehandlung BG |
| `eurowertincent` | integer | NOT NULL. !ACHTUNG! kann 0 sein obwohl. punktwert vorhanden! (s. 201A) |
| `faktor_bahn` | real | NOT NULL |
| `faktor_bahn_unfall` | real | NOT NULL |
| `faktor_basistarif` | real | NOT NULL |
| `faktor_bundeswehr_amb` | real | NOT NULL |
| `faktor_bundeswehr_stat` | real | NOT NULL |
| `faktor_entschaedigungsamt_berlin` | real | NOT NULL |
| `faktor_knappschaft` | real | NOT NULL |
| `faktor_normal` | real | NOT NULL |
| `faktor_polizei_amb` | real | NOT NULL |
| `faktor_polizei_stat` | real | NOT NULL |
| `faktor_post` | real | NOT NULL |
| `faktor_post_unfall` | real | NOT NULL |
| `faktor_standardtarif` | real | NOT NULL |
| `faktor_student` | real | NOT NULL |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `hinweis` | text |  |
| `kurztext` | text |  |
| `langtext` | text | editierbar in GUI, wird zum Rechnungsdruck benutzt |
| `leistung_subtyp` | integer | NOT NULL. nur relevant bei leistung_typ=ZL. 0 = nicht beregel. 1 = einfacher Gebuehrensatz. 2 = reduzierter GS (wie technische). 3 =abhaengig von der Grundleist. |
| `leistung_typ` | text | TL = technische Leistung. AL = Arztleistung. LL = Laborleistung. KE = Kostenerstattung. ZL = Zusatzleistung |
| `mindestdauer` | text | s. Par 12 |
| `nutzerdefiniert` | boolean | NOT NULL. der Nutzer kann eigene Analogleistungen definieren |
| `punktwert` | real | NOT NULL |
| `sortstring` | text |  |
| `spezialbewertung` | integer | NOT NULL. 7 = variabel - 25 Prozent des einfachen Satzes der Grundleistung. 8 = variabel - 100 Prozent  des einfachen Satzes der Grundleistung. 6 = variabel - Allgemein- und Sachkosten 50 Prozent des entspr.  Betrages der Grundleistung. 9 = wahre Selbstkosten in Euro |
| `typ` | integer | NOT NULL. 3 = nur GOAE. 4 = GOAE + UV-GOAE. 5 = nur UV-GOAE. 6 = sachkosten krankenhaus |
| `allgemeinkostenincent` | integer | NOT NULL |
| `besonderekostenincent` | integer | NOT NULL |
| `sachkostenincent` | integer | NOT NULL |
| `vollkostenincent` | integer | NOT NULL |
| `kurztextlautkatalog` | text | analog langtextLautKatalog |
| `langtextlautkatalog` | text | nicht editierbar in GUI (vgl. langtext). als backup falls man .langtext versaut hat |
| `farbe` | text |  |
| `anaesthesie` | text |  |
| `anzahlassistenten` | integer |  |
| `behandlungsart` | text |  |
| `knr` | text |  |
| `mutdatum` | timestamp |  |
| `pflichtstatus` | integer |  |
| `quantitativedignitaet` | text |  |
| `skalierungsfaktorarzt` | real |  |
| `skalierungsfaktortechnisch` | real |  |
| `sparte` | text |  |
| `taxpunktearzt` | real |  |
| `taxpunkteassistenz` | real |  |
| `taxpunktetechnisch` | real |  |
| `zeitbefund` | real |  |
| `zeitleistungimengerensinne` | real |  |
| `zeitraum` | real |  |
| `zeitvorundnachbereitung` | real |  |
| `zeitwechsel` | real |  |
| `zeitzusatz` | real |  |
| `bnr` | text |  |
| `gnr` | text |  |
| `buchungskonto` | text | KuTo relevant |
| `faktormaximum` | real | Nutzerdefinierter Hoechstwert fuer die Steigerung |
| `dentalkatalogdetails_ident` | bigint | FK → `dentalkatalogdetails` |
| `kuerzel` | text |  |
| `standardkuerzel` | text |  |
| `pauschal` | boolean |  |
| `mehrwertsteuerinprozent` | real |  |
| `custombegruendung` | text |  |
| `verlangensleistunggesetzt` | boolean |  |
| `chkatalogdetails_ident` | bigint | FK → `chkatalogdetails` |

### goaeleistungbedingung
> bezugsraum und aussetzungsgrund sind in alles Subklassen wie in GOAEAnzahlBed

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `meldung` | text |  |
| `typ` | integer | NOT NULL. 0 = Fehler. 1 = Warnung |
| `userdefined` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `anzahlbezugsraum` | integer |  |
| `aussetzungsgrund` | integer |  |
| `bezugsraum` | integer |  |
| `komplemetaer` | boolean |  |
| `kapitel` | text |  |
| `komplementaer` | boolean |  |
| `geschlecht` | text |  |
| `anzahl` | integer |  |
| `minmax` | integer |  |
| `einheit` | integer |  |
| `maxalter` | bigint |  |
| `minalter` | bigint |  |
| `mindanzahl` | integer |  |
| `hinweistext` | text |  |
| `modus` | integer |  |
| `kapitelliste` | text |  |
| `maxaltertoleranz` | bigint |  |
| `minaltertoleranz` | bigint |  |
| `gnrlistekomplementaer` | boolean |  |
| `zahnangabe` | integer |  |
| `maxdistanz` | integer |  |

### goaeleistungsgruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `visible` | boolean | NOT NULL |

### goaeunterabschnitt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### steigerungsschema
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `auswaehlbar` | boolean | NOT NULL. vordefinierte Schemata koennen im. dropdown auch ausgeblendet sein |
| `faktorlab` | real | NOT NULL |
| `faktormed` | real | NOT NULL |
| `faktortech` | real | NOT NULL |
| `listenposition` | integer | NOT NULL |
| `name` | text |  |
| `userdefined` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `faktorlabhonorar` | real | NOT NULL |
| `faktormedhonorar` | real | NOT NULL |
| `faktortechhonorar` | real | NOT NULL |
| `tariftyp` | integer | null, 0 : GOAE, 10 : TARMED |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `preisistfixiert` | boolean |  |

## 9. Scheine & Abrechnung

### abrechnung
> wird vom Client erstellt um eine Abrechnung zu triggern

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `complete` | boolean | NOT NULL. wird gesetzt wenn der Server die Abrechnungsdateien erzeugt hat. der Server muss hier einen Change erstellen |
| `cryptostatus` | integer | Ergebnis der Verschluesselung. Werte: 0 = OK, 1-11 = Fehler (fuer genaue Fehler siehe XKM-Handbuch) |
| `datum` | timestamp | das setzen dieses Attribut triggert den Start der Abrechnung. daher muss dieses Attribut vom Client IMMER zuletzt gesetzt werden |
| `pruefstatus` | integer | Ergebnis des Pruefmoduldurchlaufs. Werte: 0 = OK, 1 = Enthaelt Warnungen, 2 = Fehlerhaft, 3 = Pruefung abgebrochen |
| `quartal` | timestamp | ein beliebiges Datum aus dem abzurechnenden Quartal |
| `removed` | boolean | NOT NULL |
| `versandt` | boolean | NOT NULL. diese Abrechnung wurde an die KV uebermittelt |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `veranlassendebetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `veranlasser_ident` | bigint | FK → `nutzer` |
| `kvconnectuid` | text |  |
| `kvconnectusername` | text | Das Nutzerkonto ueber welches die Abrechnung verschickt wurde (und ueber welches die Antworten empfangen werden) |
| `kvconnectversion` | integer | NOT NULL |
| `oneclickdatum` | timestamp |  |
| `oneclickstatus` | integer | Werte: 1 = abgeschickt, 2 = eingegangen |
| `oneclickstatusmeldung` | text | Die letzte Statusmeldung zur One-Click-Abrechnung (von der KV per KV-Connect-Mail uebermittelt) |
| `anzahlscheine` | integer | null wenn die Abrechnung noch nicht gestartet ist, sonst immer serveronlyKVScheine.size() |
| `uebersprungenescheine` | integer | Gibt an wieviele Scheine aufgrund eines Fehlers nicht abgerechnet werden konnten und somit nicht in der .CON auftauchen |
| `knappschaftverhalten` | integer | 0 = keine Einschraenkung; 1= ohne Knappschaft; 2 = nur Knappschaft |
| `oneclickteststatus` | integer |  |
| `oneclick_ident` | bigint | FK → `email` |
| `oneclickfachrm_ident` | bigint | FK → `email` |
| `oneclicktechrm_ident` | bigint | FK → `email` |
| `oneclicktest_ident` | bigint | FK → `email` |
| `oneclicktestfachrm_ident` | bigint | FK → `email` |
| `oneclicktesttechrm_ident` | bigint | FK → `email` |
| `kassenaerztlichevereinigung_ident` | bigint | FK → `kassenaerztlichevereinigung` |
| `emailaccount_ident` | bigint | FK → `emailaccount` |
| `oneclickvollstaendig` | boolean |  |
| `sammelerklaerung_ident` | bigint | FK → `sammelerklaerung` |
| `mitsammelerklaerung` | integer |  |
| `processingstate` | integer |  |
| `rechnungskreis_ident` | bigint | FK → `rechnungskreis` |
| `knowsskippedscheine` | boolean |  |
| `countvorquartalsscheine` | integer |  |
| `fehlertext` | text |  |

### abrechnungsbereich
> aus der Schluesseltabelle S_KTS_KTABRECHNUNGSBEREICH.xml (1.2.276.0.76.5.239) ausgelesen
> Werte: Primaerabrechnung, Sozialversicherungsabkommen, Rheinschiffer, usw.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### abrechnungsdatei
> beim wirklichen Loeschen sollte der Server Sorge tragen, dass auch die zugehoerige Datei geloescht wird

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `filename` | text |  |
| `removed` | boolean | NOT NULL |
| `digitalesmuster_ident` | bigint | FK → `karteieintrag` |
| `dtype` | varchar | NOT NULL |
| `dateityp` | integer |  |
| `status` | integer |  |

### abrechnungsfehler
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `art` | text | Fehler, Warnung, Info |
| `datum` | timestamp |  |
| `ignoriert` | boolean | NOT NULL |
| `nutzerkuerzel` | text | Kuerzel des verursachenden Nutzers (loggedInNutzer bei change) |
| `regel` | text | Die Regel (bzw. der Validator), die fuer diesen Fehler verantwortlich ist. . Wird benoetigt um Fehler wieder loeschen zu koennen, wenn ein Check fehlerfrei durchlaeuft. |
| `revision` | bigint |  |
| `text` | text |  |
| `ende` | timestamp |  |
| `start` | timestamp |  |
| `patient_ident` | bigint | FK → `patient` |
| `invebmleistung_ident` | bigint | FK → `leistung` |
| `removed` | boolean | NOT NULL |
| `diagnose_ident` | bigint | FK → `diagnose` |
| `betriebsstaettenkuerzel` | text |  |
| `invebmleistungziffernkranz_ident` | bigint | FK → `leistung` |
| `krwfehlerbehandlung_ident` | bigint | FK → `krwfehlerbehandlung` |
| `code` | text |  |
| `jahr` | integer |  |
| `quartal` | integer |  |
| `isbgfehler` | boolean |  |
| `rulecategory` | text |  |
| `rulecategoryreadable` | text |  |
| `eurowertincent` | integer |  |
| `behandler` | text | Kuerzel der betroffenen Abrechner (ggf. kommasepariert) |
| `leistungserbringer` | text | Kuerzel der betroffenen Leistungserbringer (ggf. kommasepariert) |

### abrechnungsfehlerfilter
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `activated` | boolean |  |
| `filtertext` | text |  |
| `ignoreglobally` | boolean |  |
| `kuerzel` | text |  |
| `name` | text |  |
| `filtermode` | integer |  |
| `operationmode` | integer |  |
| `artmode` | integer |  |
| `hinweismode` | integer |  |
| `usermode` | integer |  |
| `patientmode` | integer |  |

### abrechnungsvorschlag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `removed` | boolean | NOT NULL |
| `marketplaceversion` | integer |  |
| `onlineid` | text |  |

### abrkostentraegerdetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abrechnungsdatum` | timestamp |  |
| `rechnungsnummer` | text |  |
| `kostentraeger_ident` | bigint | FK → `kostentraegernichtkvabrechnung` |

### direktabrechnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `datenannahmestelle_ident` | bigint | FK → `kostentraegernichtkvabrechnung` |
| `status` | integer |  |

### erechnungsdokument
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `documentreference` | text |  |
| `modus` | integer | 0 : Versand, 1: Empfang |
| `status` | integer | 0 : done, 1 : processing, 2 : error |
| `transmissionreference` | text |  |
| `typ` | integer | 0: Rechnung, 1 : Mahnung1, 2: Mahnung2, 3 : Mahnung3, 4: Benachrichtigung, 5 : Rechnungsantwort |
| `datei_ident` | bigint | FK → `datei` |
| `ersteller_ident` | bigint | FK → `nutzer` |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `privatrechnung_ident` | bigint | FK → `privatrechnung` |
| `rechnungsantwort_ident` | bigint | FK → `rechnungsantwort` |
| `rooterechnungsdokument_ident` | bigint | FK → `erechnungsdokument` |
| `visible` | boolean | NOT NULL |
| `sammelrechnungtyp_ident` | bigint | FK → `sammelrechnungtyp` |

### forderung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datumbis` | timestamp |  |
| `datumvon` | timestamp |  |
| `freitext` | text |  |
| `grundlage` | text |  |
| `hauptforderungskatalog` | integer |  |
| `kostentyp` | integer |  |
| `typ` | integer |  |
| `verweis` | text |  |
| `visible` | boolean | NOT NULL |
| `zinsart` | integer |  |
| `zinsmethode` | integer |  |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `auslandskennzeichen` | text |  |
| `datumforderungabgetreten` | timestamp |  |
| `ort` | text |  |
| `postleitzahl` | text |  |
| `vertragsart` | text |  |
| `zedentauslandskz` | text |  |
| `zedentname` | text |  |
| `zedentort` | text |  |
| `zedentpostleitzahl` | text |  |
| `zinsintervall` | integer |  |
| `buchungsdatum` | timestamp |  |
| `buchungstext` | text |  |
| `bestritten` | boolean |  |
| `betragincent` | bigint |  |
| `tituliert` | boolean |  |
| `verbraucherkreditjahreszins` | bigint |  |
| `verbraucherkreditvertragsdatum` | timestamp |  |
| `strasse` | text |  |
| `rarechnung_ident` | bigint | FK → `rarechnung` |
| `teilbetrag_ident` | bigint | FK → `teilbetrag` |

### forderungskonto
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `datum` | timestamp |  |
| `freitext` | text |  |
| `typ` | integer |  |
| `visible` | boolean | NOT NULL |
| `status` | integer |  |
| `gesamtschuldner` | boolean |  |
| `berechnungsdatum` | timestamp |  |
| `hauptforderungincent` | bigint |  |
| `hauptforderungzinsenincent` | bigint |  |
| `kostenzinsenincent` | bigint |  |
| `unverzinslichekostenincent` | bigint |  |
| `verzinslichekostenincent` | bigint |  |

### kassendetailsproabrechnungsbereich
> Entity, die der Relation GesetzlicheKasse-Abrechnungsbereich weitere Attribute
>  hinzufuegt (in einem E/R-Diagramm wuerde man das als Relationen-Attribut modellieren).

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bedruckungsname` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `temporaer` | boolean |  |
| `abrechnungsbereich_ident` | bigint | FK → `abrechnungsbereich` |

### kostenstelle
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `code` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### kostenstellenanteil
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anteil` | real |  |
| `kostenstelle_ident` | bigint | FK → `kostenstelle` |

### kvschein
> Enthaelt die abgerechneten Leistungen eines Quartals.
> Zur Historie: Die Leistungen werden analog zu der (ab 2011 nur noch im Ausnahmefaellen erlaubten) Vorgehen in Papierform 
> in Papierform in diesen "virtuellen" Scheinen durchgef?hrt, obwohl wir genausogut einfach die abgerechneten
> Leistungen mit den entsprechenden Informationen ausstatten koennten (Stefan: mir faellt zumindest kein
> zwingender Grund ein, warum die Entity KVSchein notwendig sein sollte).
>  
> Die im Schein enthaltenen Daten haben einen archivierenden Charakter und duerfen deshalb nach erfolgter Abrechnung 
> nicht veraendert werden (es sei denn, die Daten wurden manuell eingegeben, siehe Attribute "ersatzverfahren".
> und "selbstAusgestellt").
> s. Klassendiagramm StammdatenKBV

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abgerechnet` | boolean | NOT NULL |
| `hasleistung` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `abklaerungsomatischeursachen4236` | boolean | NOT NULL |
| `arbeitsunfaehigbis` | timestamp | Ist zwar auf dem Ueberweisungsformular 6/E 4.2011 vorhanden, wird aber in der Abrechnung an die KBV nicht uebertragen |
| `auftragdiagnoseverdacht4209` | text | Stammt aus Ueberweisungsformularen vor dem 2. Quartal 2011 und enthaelt die Angaben. aus Auftrag4205, diagnose4207 und befund4208 in loser Anordnung. Dieses "Multi"-Attribut. darf zum Beispiel fuer Belegaerztliche Mitbehandlung oder Laborueberweisungen nicht mehr verwendet werden. |
| `auftragstext4205` | text | fuer Ueberweisungen; der Auftragstext ist hier als zusammenhaengender String modelliert,. wird aber in der Abrechnung in 60 Zeichen lange Substrings aufgeteilt. |
| `ausstellungsdatum4102` | timestamp | Erstellungsdatum |
| `befundodermedikation4208` | text |  |
| `behandlungnachparagraph116bsgbv` | boolean | NOT NULL. ist zwar auf dem Ueberweisungsformular 6/E 4.2011 vorhanden, wird aber nicht in der Abrechnung an die KBV uebertragen  |
| `datumderop` | timestamp | Wird nur dann gebraucht, wenn eine postoperative Leistung (Leistung nach Abschnitt 31.2) abgerechnet . wird. In diesem Fall wird das OP-Datum als Zusatzangabe 5034 der Leistung uebertragen. |
| `diagnose4207` | text |  |
| `eingeschraenkterleistungsanspruchparagraph16sgbv4204` | boolean | NOT NULL |
| `erstveranlasserbsnr4217` | text |  |
| `erstveranlasserlanr4241` | text |  |
| `ignoreordinationsgebuehrcheck` | boolean | NOT NULL |
| `ignoriertfuerabrechnung` | boolean | NOT NULL. Hiermit kann verhindet werden, dass bestimmte Scheine abgerechnet werden.. Fuer Abrechnung im Folgequartal muss Flag haendisch wieder entfernt werden. |
| `jahr` | integer | NOT NULL |
| `kurativpraeventiv4221` | text | 1 = kurativ. 2 = praeventiv. 3 = Empfaengnisregelung, Sterilisation, Schwangerschaftsabbruch (keine Ankreuzfeld auf Formular). 4 = belegaerztliche Behandlung. nur bei Ueberweisungen |
| `mutmasslichertagderentbindung4206` | timestamp |  |
| `quartal` | integer | NOT NULL. Quartal fuer das der Schein abgerechnet werden soll |
| `serveronlyinformedid` | bigint | Wird nur fuer den Datenimport gebraucht, um einem Schein Leistungen/Diagnosen zuzuordnen |
| `sortierdatum` | timestamp | Das Datum zum Sortieren der Scheine in der Pulldown-Liste im MacOS Client. Entweder nehmen wir. da das Erstellungsdatum (nicht zu verwechseln mit ausstellungsdatum4102, das kann auch leer sein),. oder das Datum, als der Schein das letzte mal geaendert wurde.. erstelltDatum. Scheine werden mit aktuellem Datum erstellt und daraus ein Quartal erzeugt. soll ein Schein fuer das letzte Quartal erstellt werden, muss die Systemzeit umgestellt werden |
| `ueberweisendebsnr4218` | text | ___________________Attribute Ueberweisungsformular_______________________________________________________ |
| `ueberweisenderarzt` | text | In Abhaengigkeit vom Flag ueberweisenderArztIstVertragsarzt wird dieses Attribut als. Feld 4242 (LANR des ueberweisenden Vertragsarztes) oder Feld 4219 (Ueberweisung von. anderen Aerzten) abgerechnet. |
| `ueberweisenderarztistvertragsarzt` | boolean | NOT NULL |
| `ueberweisenderarztname` | text |  |
| `ueberweisungan4220` | text |  |
| `unfall4202` | boolean | NOT NULL |
| `weiterbehandelnderarzt4243` | text |  |
| `zusatzangabeskt4124` | text | Der tatsaechliche Inhalt der Felder "zusatzangabenSKT412X" ist von Fall zu Fall unterschiedlich.. So koennen z.B. in 4124 die Angaben aus der "Schluesseltabelle" KVZusatzangabeFuerFeld4124. 1 = Grundlistennummer Versorgungsamt, 2 = Registriernummer, usw. eintragen werden. |
| `zusatzangabeskt4125bis` | timestamp |  |
| `zusatzangabeskt4125von` | timestamp | Der tatsaechliche Inhalt der Felder "zusatzangabenSKT412X" ist von Fall zu Fall unterschiedlich.. So koennen z.B. in 4124 die Angaben aus der "Schluesseltabelle" KVZusatzangabeFuerFeld4124. 1 = Grundlistennummer Versorgungsamt, 2 = Registriernummer, usw. eintragen werden. |
| `zusatzangabeskt4126` | text | Zusatzangabe SKT. Der tatsaechliche Inhalt der Felder "zusatzangabenSKT412X" ist von Fall zu Fall unterschiedlich.. So koennen z.B. in 4124 die Angaben aus der "Schluesseltabelle" KVZusatzangabeFuerFeld4124. 1 = Grundlistennummer Versorgungsamt, 2 = Registriernummer, usw. eintragen werden. |
| `abgeleiteterkostentraeger_ident` | bigint | FK → `krankenkasse` |
| `abrechnungsbereich_ident` | bigint | FK → `abrechnungsbereich` |
| `abrechnungsgebiet_ident` | bigint | FK → `kvabrechnungsgebiet` |
| `ausnahmeindikation4229_ident` | bigint | FK → `ebmkatalogeintrag` |
| `kartendaten_ident` | bigint | FK → `kartendaten` |
| `scheingruppe_ident` | bigint | FK → `kvscheingruppe` |
| `zusatzangabe4123_ident` | bigint | FK → `kvspezifikaerlaubtewertefuerfeld4123` |
| `freitext` | text |  |
| `dtype` | varchar | NOT NULL |
| `kartenlesedatum_ident` | bigint | FK → `kartenlesedatum` |
| `teilnahme_ident` | bigint | FK → `s3cteilnahme` |
| `abrechnendebetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `kennziffersadt3005` | text |  |
| `abgeleitetevknrsadt` | text |  |
| `qsmendbefund` | text |  |
| `qsmfragestellung` | text |  |
| `vermittlungsart4103` | integer | 1=TSS-Terminfall, 2=TSS-Akutfall, 3=HA-Vermittlungsfall, 4=offeneSprechstunde, 5=Neupatient |
| `vermittlungsartzusatz4105` | text | durch Komma separierter Multistring |
| `tsvgvermittlungsdatum` | timestamp | Der Tag an dem der TSS-Termin vereinbart wurde, FK 4115 |
| `tsvgkontaktdatum` | timestamp | Der Tag an dem der TSS-Termin wahrgenommen wurde (also Kontakt stattgefunden hat). wird nicht an die KV uebertragen |
| `tsvgvermittlungscode` | text |  |
| `musterueberweisung` | integer |  |
| `zusatzangabenuntersuchung4209` | text |  |
| `qsmunterauftrag` | boolean | NOT NULL |
| `abweichendegebuehrenordnungkbv_ident` | bigint | FK → `gebuehrenordnungkbv` |
| `abweichenderkvbereich_ident` | bigint | FK → `kassenaerztlichevereinigung` |
| `behandlungstag4214` | timestamp |  |
| `patient_ident` | bigint | FK → `patient` |
| `gueltigkeitseinschraenkungbis` | timestamp |  |
| `gueltigkeitseinschraenkungvon` | timestamp |  |
| `weiterbehandelnderarztbsnr` | text |  |
| `weiterbehandelnderarztlanr` | text |  |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |

### kvscheingruppe
> Wird aus der KBV-Schluesseltabelle S_KBV_SCHEINART.xml ausgelesen.
> Werte: 00 = ambulante Behandlung, 20 = Selbstausstellung, 21 = Auftragsleistung, 23 = Konsiliarsuntersuchung, ...

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `listenposition` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |

### leistungsprotokoll
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anzahlleistung` | integer |  |
| `datum` | timestamp |  |
| `rechnungstatus` | integer |  |
| `removed` | boolean | NOT NULL |
| `verschicktstatus` | integer |  |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |
| `leistungsprotokolltyp_ident` | bigint | FK → `leistungsprotokolltyp` |
| `patient_ident` | bigint | FK → `patient` |
| `anzahlleistunggesamt` | integer |  |
| `protokolldatei_ident` | bigint | FK → `datei` |
| `ignored` | boolean | NOT NULL |
| `raleistung_ident` | bigint | FK → `leistung` |

### leistungsprotokolltyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `removed` | boolean | NOT NULL |
| `vorbefuellung` | text |  |
| `briefvorlage_ident` | bigint | FK → `briefvorlage` |
| `dokueintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `flatrateeintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `protokolleintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `tableautosave` | text |  |
| `ckeeanrechenbareleistung_ident` | bigint | FK → `customkarteieintragentry` |
| `ckeedokumentierteleistung_ident` | bigint | FK → `customkarteieintragentry` |
| `ckeeflatrateende_ident` | bigint | FK → `customkarteieintragentry` |
| `ckeeflatratestart_ident` | bigint | FK → `customkarteieintragentry` |
| `defaultpatientprefilter_ident` | bigint | FK → `outlineviewelement` |
| `ckeeleistungsdatum_ident` | bigint | FK → `customkarteieintragentry` |

### mahnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `druckdatum` | timestamp |  |
| `mahngebuehrincent` | integer | NOT NULL |
| `md5ersterentwurf` | text |  |
| `entwurfmahnung_ident` | bigint | FK → `datei` |
| `versandt` | boolean | NOT NULL |
| `erstelltam` | timestamp |  |
| `internetmarke_ident` | bigint | FK (intern) |
| `versandtansteuerberater` | integer | NOT NULL |

### patientenquittung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `gedruckt` | boolean | NOT NULL |
| `removed` | boolean | NOT NULL |
| `patient_ident` | bigint | FK → `patient` |

### privatrechnung
> s. Klassendiagramm Privatliquidation

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abgerechnet` | boolean | NOT NULL |
| `hasleistung` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `abweichenderechnungsanschriftnachname` | text |  |
| `abweichenderechnungsanschriftort` | text |  |
| `abweichenderechnungsanschriftplz` | text |  |
| `abweichenderechnungsanschriftstrasse` | text |  |
| `abweichenderechnungsanschrifttitel` | text |  |
| `abweichenderechnungsanschriftvorname` | text |  |
| `bezahlt` | boolean | NOT NULL |
| `bezahltdatum` | timestamp |  |
| `druckdatum` | timestamp |  |
| `erstelltam` | timestamp |  |
| `freitext` | text |  |
| `isbgrechnung` | boolean | NOT NULL |
| `versichertennummer` | text | ⚠ Nicht im finalen SELECT |
| `abrechnenderarzt_ident` | bigint | FK → `nutzer` |
| `bgtarif_ident` | bigint | FK → `bgtarif` |
| `gedruckteversion_ident` | bigint | FK → `datei` |
| `patient_ident` | bigint | FK → `patient` |
| `privatkasse_ident` | bigint | FK → `krankenkasse` |
| `steigerungsschema_ident` | bigint | FK → `steigerungsschema` |
| `summekosten` | real | NOT NULL |
| `briefvorlageident` | bigint |  |
| `individualchangeofdocx` | boolean | NOT NULL |
| `mahnstufe` | integer | NOT NULL |
| `mahndatei_ident` | bigint | FK → `datei` |
| `privatrechnungkonto_ident` | bigint | FK → `privatrechnungkonto` |
| `privatrechnungkostenstelle_ident` | bigint | FK → `privatrechnungkostenstelle` |
| `privatrechnungtyp_ident` | bigint | FK → `privatrechnungtyp` |
| `bezahlterteilbetrag` | real | NOT NULL |
| `md5ersterentwurf` | text |  |
| `mehrwertsteuerinprozent` | real | NOT NULL |
| `rechnungsnummer` | text |  |
| `teilbetrag` | boolean | NOT NULL |
| `entwurfrechnung_ident` | bigint | FK → `datei` |
| `mahnung1_ident` | bigint | FK → `mahnung` |
| `mahnung2_ident` | bigint | FK → `mahnung` |
| `mahnung3_ident` | bigint | FK → `mahnung` |
| `abweichenderechnungsanschriftgeschlecht` | text |  |
| `bemerkung` | text |  |
| `nichtambulant` | integer | NOT NULL. 0 = ambulant, 1 = belegarzt, 2= stationaer |
| `pvs` | boolean | NOT NULL |
| `summekostenreal` | real | NOT NULL. beachtet z.B. Reduzierung Belegarzt |
| `versandt` | boolean | NOT NULL. z.B. Rosenheim: an DATEV gesendet |
| `abweichenderechnungsanschriftland` | text |  |
| `abweichenderechnungsanschriftnamenszusatz` | text |  |
| `ueberweiser_ident` | bigint | FK → `hausarzt` |
| `aktenzeichen` | text |  |
| `mehrwertsteuerabsolut` | real | beachtet auch nichtAmbulant |
| `berufsgenossenschaft_ident` | bigint | FK → `berufsgenossenschaft` |
| `datumletzteleistung` | timestamp |  |
| `needsupdatesummekosten` | boolean | NOT NULL |
| `abrechnendebetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `mostfittingbetriebsstaette` | text |  |
| `insammelrechnung` | boolean | NOT NULL |
| `festbetrag` | real |  |
| `festbetragisreal` | boolean | NOT NULL |
| `festbetragsteigerungsfaktormodus` | integer | NOT NULL |
| `heilmittelformular_ident` | bigint | FK → `karteieintrag` |
| `arbeitgeber_ident` | bigint | FK → `arbeitgeber` |
| `fehlerprotokoll` | text | Fehlerprotokoll fuer die Erstellung der TARMED-Abrechnungsdatei |
| `behandlungsgrund` | integer | 0: disease/Krankheit, 1: accident/Unfall 2: maternity/Schwangerschaft 3: prevention/Vorsorge 4:birthdefect/Geburtsgebrechen 5:unkown/unbekannt |
| `rechnungsdaten_ident` | bigint | FK → `rechnungsdaten` |
| `abweichenderechnungsanschriftemail` | text |  |
| `dueforpaymentdate` | timestamp | Faelligkeitsdatum fuer kuto-Projekt |
| `zusatzdatum` | timestamp |  |
| `status` | integer |  |
| `gesperrtdurch` | text |  |
| `stornodatei_ident` | bigint | FK → `datei` |
| `privatrechnungrabatt_ident` | bigint | FK → `privatrechnungrabatt` |
| `mahnung4_ident` | bigint | FK → `mahnung` |
| `internetmarke_ident` | bigint | FK (intern) |
| `internetmarkestorno_ident` | bigint | FK (intern) |
| `auswahladressat` | integer |  |
| `abweichenderechnungsanschrifttelefon` | text |  |
| `alleleistungserbringer` | text |  |
| `befund_ident` | bigint | FK → `zahnarztbefund` |
| `plan_ident` | bigint | FK → `zahnarztbefund` |
| `versandtansteuerberater` | integer | NOT NULL |
| `stornodetails_ident` | bigint | FK → `stornodetails` |
| `gueltigkeitseinschraenkungbis` | timestamp |  |
| `gueltigkeitseinschraenkungvon` | timestamp |  |
| `bgaktenzeichen_ident` | bigint | FK → `aktenzeichen` |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `rechnungsempfaengergeburtsdatum` | timestamp |  |

### privatrechnungkonto
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### privatrechnungkostenstelle
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |

### privatrechnungrabatt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `isforll` | boolean | NOT NULL. fuer Laborleistungen |
| `isforml` | boolean | NOT NULL. fuer medizinische Leistungen |
| `isforsk` | boolean | NOT NULL. fuer Sachkosten |
| `isfortl` | boolean | NOT NULL. fuer technische Leistungen |
| `kuerzel` | text |  |
| `name` | text |  |
| `prozent` | real |  |
| `visible` | boolean | NOT NULL |
| `wertincent` | integer |  |

### privatrechnungtyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `defaultmehrwertsteuerinprozent` | real | NOT NULL |
| `isbg` | boolean | NOT NULL |
| `isdefaulttyp` | boolean | NOT NULL. wenn nicht geloescht werden soll, also Mahnung,kostenvoranschlag,bg |
| `iskostenvoranschlag` | boolean | NOT NULL |
| `kuerzel` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `rechnungskreis_ident` | bigint | FK → `rechnungskreis` |
| `standardprivatrechnungkonto_ident` | bigint | FK → `privatrechnungkonto` |
| `standardprivatrechnungkostenstelle_ident` | bigint | FK → `privatrechnungkostenstelle` |
| `vorlagemahnung1_ident` | bigint | FK → `briefvorlage` |
| `vorlagemahnung2_ident` | bigint | FK → `briefvorlage` |
| `vorlagemahnung3_ident` | bigint | FK → `briefvorlage` |
| `vorlagerechnung_ident` | bigint | FK → `briefvorlage` |
| `currency` | text |  |
| `backgroundcolor` | text |  |
| `tariftyp` | integer | null, 0 : GOAE, 1: TARMED |
| `initialfreitext` | text |  |
| `keinediagnosefehler` | boolean | NOT NULL |
| `einzahlscheinmahnung1_ident` | bigint | FK → `briefvorlage` |
| `einzahlscheinmahnung2_ident` | bigint | FK → `briefvorlage` |
| `einzahlscheinmahnung3_ident` | bigint | FK → `briefvorlage` |
| `einzahlscheinrechnung_ident` | bigint | FK → `briefvorlage` |
| `showunderagewarning` | boolean | NOT NULL. Den Hinweis/Scheinfehler generieren und PAD-Export unterbinden, wenn die Rechnung an minderjaerigen versandt wird  |
| `vorlagestorno_ident` | bigint | FK → `briefvorlage` |
| `tgorganisation` | text |  |
| `totporganisation` | boolean | NOT NULL |
| `tpalternativeorganisation` | text |  |
| `trustcenter` | text |  |
| `tgtopatient` | boolean | NOT NULL |
| `tptopatient` | boolean | NOT NULL |
| `insammelrechnung` | boolean | NOT NULL |
| `pvs` | boolean | NOT NULL |
| `standardsammelrechnungtyp_ident` | bigint | FK → `sammelrechnungtyp` |
| `vorlagemahnung4_ident` | bigint | FK → `briefvorlage` |
| `dueforpaymentmahnung1` | integer |  |
| `dueforpaymentmahnung2` | integer |  |
| `dueforpaymentmahnung3` | integer |  |
| `dueforpaymentrechnung` | integer |  |
| `currencylocale` | text |  |
| `vorlagezeiterfassung_ident` | bigint | FK → `briefvorlage` |
| `vorlagedeckblattrechnungskopie_ident` | bigint | FK → `briefvorlage` |
| `buchungskontodatev` | integer |  |
| `ignoretrustcenter` | boolean | NOT NULL |

### privatrechnungverlauf
> Serveronly Klasse fuer Statistik

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datumserver` | timestamp |  |
| `summekosten` | real | NOT NULL |
| `summekostenreal` | real | NOT NULL |
| `typ` | integer | NOT NULL |
| `privatrechnung_ident` | bigint | FK → `privatrechnung` |
| `clientid` | text |  |
| `nutzerkuerzel` | text |  |
| `bezahltdatum` | timestamp |  |
| `druckdatum` | timestamp |  |
| `druckdatummahnung` | timestamp |  |
| `versandt` | boolean | NOT NULL |

### privatrechnungvorlage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `listenposition` | integer | NOT NULL |
| `vorlage_ident` | bigint | FK → `privatrechnung` |
| `uebernahmerechnungstyp` | boolean | NOT NULL |
| `uebernahmetarif` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `uebernahmeueberweiser` | boolean | NOT NULL |
| `uebernahmeanschrift` | boolean | NOT NULL |

### privatscheindetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `datumstationaerbeginn` | timestamp |  |
| `datumstationaerende` | timestamp |  |
| `pro_grd` | smallint |  |
| `unfall` | boolean |  |
| `upt_freq` | integer |  |
| `ident` | bigint | PK. FK → `kzvscheindetails` |
| `krankenhaus_ident` | bigint | FK → `krankenhaus` |
| `verletzungsbefund` | text |  |
| `vorgesehenebehandlung` | text |  |

### protokollrechnungvorlage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `removed` | boolean | NOT NULL |
| `schwellwert` | integer |  |
| `umrechnunganzahl` | integer |  |
| `umrechnungkostenincent` | integer |  |
| `privatrechnungvorlage_ident` | bigint | FK → `privatrechnungvorlage` |
| `favoritgoaeleistung_ident` | bigint | FK → `outlineviewelement` |

### pvsabrechnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anzahlrechnungen` | integer | NOT NULL |
| `info` | text |  |
| `isbg` | boolean | NOT NULL |
| `pvsname` | text |  |
| `summerechnungen` | real | NOT NULL |
| `versandtdatum` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `pvsabrechner_ident` | bigint | FK → `nutzer` |
| `isabgerechnet` | boolean | NOT NULL |
| `sammelrechnungtyp_ident` | bigint | FK → `sammelrechnungtyp` |
| `rechnungsnummer` | text |  |
| `dienstleister_ident` | bigint | FK → `padnextdienstleister` |
| `firma_ident` | bigint | FK → `patient` |

### rechnungsantwort
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `explanation` | text |  |
| `kontaktsachbearbeiter` | text |  |
| `kontaktversicherung` | text |  |
| `message` | text |  |
| `status` | integer |  |
| `visible` | boolean | NOT NULL |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `patient_ident` | bigint | FK → `patient` |
| `privatkasse_ident` | bigint | FK → `krankenkasse` |
| `privatrechnung_ident` | bigint | FK → `privatrechnung` |
| `filename` | text |  |

### rechnungsdaten
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bankname` | text |  |
| `bic` | text |  |
| `iban` | text |  |
| `mandatsnummer` | text |  |
| `ustid` | text |  |
| `kontoinhaber` | text |  |

### rechnungskreis
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kuerzel` | text |  |
| `laufenderechnungsnummer` | integer | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `prefix` | text |  |
| `owner_ident` | bigint | FK (intern) |
| `stornorechnungskreis_ident` | bigint | FK → `rechnungskreis` |

### sammelabrechnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `erstelltam` | timestamp |  |
| `gedrucktam` | timestamp |  |
| `rechnungsnummer` | text |  |
| `status` | integer |  |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `empfaenger_ident` | bigint | FK → `patient` |
| `ersetztabrechnung_ident` | bigint | FK → `sammelabrechnung` |
| `erstellendernutzer_ident` | bigint | FK → `nutzer` |

### sammelrechnungtyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `mitgliedsnummer` | text |  |
| `name` | text |  |
| `text` | text |  |
| `volumename` | text |  |
| `krankenhaus_ident` | bigint | FK → `krankenhaus` |
| `rechnungskreis_ident` | bigint | FK → `rechnungskreis` |
| `uhrzeituebermitteln` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `typ` | integer | NOT NULL |
| `briefvorlagedetails_ident` | bigint | FK → `briefvorlage` |
| `briefvorlagekopf_ident` | bigint | FK → `briefvorlage` |
| `dienstleister_ident` | bigint | FK → `padnextdienstleister` |
| `textanweisung` | text |  |
| `textende` | text |  |
| `nodiagnosewarning` | boolean | NOT NULL |
| `anweisunguebermitteln` | boolean | NOT NULL |
| `diagnosetrenner` | text |  |
| `patnrforversnr` | boolean |  |
| `zertifikat_ident` | bigint | FK (intern) |
| `nurgesamtbetragbeidatevexport` | boolean |  |
| `datevexportohneleistungsdatum` | boolean |  |
| `datevexportohnebuchungskonto` | boolean |  |
| `datevexportohnedebitorenkonto` | boolean |  |
| `trustcenter` | integer |  |

### sammelschein
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abgerechnet` | boolean | NOT NULL |
| `gueltigkeitseinschraenkungbis` | timestamp |  |
| `gueltigkeitseinschraenkungvon` | timestamp |  |
| `hasleistung` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `abrechnendebetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |

### stornodetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `notiz` | text |  |
| `stornodate` | timestamp |  |
| `stornorechnung_ident` | bigint | FK → `privatrechnung` |

### teilbetrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `cent` | integer | NOT NULL |
| `datum` | timestamp |  |
| `freitext` | text |  |
| `isstorno` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `isvorschuss` | boolean |  |

### zahlung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `freitext` | text |  |
| `visible` | boolean | NOT NULL |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `verrechnungsart` | integer |  |
| `teilbetrag_ident` | bigint | FK → `teilbetrag` |
| `buchungsdatum` | timestamp |  |

### zahlungsauftrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `angelegtdatum` | timestamp |  |
| `ausgekehrtdatum` | timestamp |  |
| `betragincent` | bigint |  |
| `status` | integer |  |
| `verwendungszweck` | text |  |
| `visible` | boolean | NOT NULL |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `kassenbucheintrag_ident` | bigint | FK → `kassenbucheintrag` |
| `zahlungsempfaenger_ident` | bigint | FK → `patient` |
| `type` | integer |  |
| `datei_ident` | bigint | FK → `datei` |
| `rechnungsdaten_ident` | bigint | FK → `rechnungsdaten` |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |

### zahlungseingang
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `buchungsdatum` | timestamp |  |
| `fremdgeldincent` | bigint |  |
| `storniert` | boolean |  |
| `visible` | boolean | NOT NULL |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `kassenbucheintrag_ident` | bigint | FK → `kassenbucheintrag` |
| `buchungstext` | text |  |
| `rechnungsdaten_ident` | bigint | FK → `rechnungsdaten` |

### zinseintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datumbis` | timestamp |  |
| `datumvon` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `zinssatz` | real |  |
| `betragincent` | bigint |  |

## 10. Kassen & Kostentraeger

### bezirksstelle
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `kassenaerztlichevereinigung_ident` | bigint | FK → `kassenaerztlichevereinigung` |
| `unbillable` | boolean |  |

### dalegkvkasse
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `ik` | text |  |
| `name` | text |  |
| `rechtsnachfolger_ident` | bigint | FK → `dalegkvkasse` |

### daleland
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### datenannahmestelle
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `institutionskennzeichen` | text |  |
| `nachnameansprechpartner` | text |  |
| `name` | text | Der (hoffentlich eindeutige) Name der Annahmestelle (organization->addr->ADL) |
| `vornameansprechpartner` | text |  |
| `kontaktannahmestelle_ident` | bigint | FK → `kontaktdaten` |
| `kontaktansprechpartner_ident` | bigint | FK → `kontaktdaten` |
| `nameorganisation` | text |  |
| `visible` | boolean | NOT NULL |
| `nutzerdefiniert` | boolean | NOT NULL |
| `sddaversion` | text |  |

### gkvstatus
> Wird auch als MFR-Status bezeichnet: ( M )itglied, ( F )amilienversichert, ( R )entner.
> Wurde urspruenglich von der Schluesseltabelle S_AST_VERSICHERTENSTATUS.xml
> importiert, aber diese Tabelle enthaelt nicht alle relevanten Eintraege und zudem auch
> noch einen Eintrag "Summe MFR", welcher fuer das UI stoerend ist.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text | = KVK.versichertenstatus bzw. EGK.versichtertenart |
| `code` | text |  |
| `listenposition` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |

### gkvstatusergaenzung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `listenposition` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |

### institutionskennzeichen
> wird meist nur als IK bezeichnet und umfasst neben Krankenkassen auch andere
> Institutionen, die fuer die Abrechnung von Relevanz sein kann (z.B. Berufsgenossenschaften
> fuer die Abrechnung von Berufsunfaellen).

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abrechnungsik` | boolean | Gibt an, ob diese IK fuer Abrechnungen benutzt werden darf. |
| `code` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `realcode` | text | Stellen 3-9 von Code |
| `temporaer` | boolean |  |

### kassenaerztlichevereinigung
> aus der Schluesseltabelle S_KBV_KV.xml (1.2.276.0.76.5.233) ausgelesen
> Wird auch unter dem Synonym WOP (Wohnortprinzip) verwendet

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### kassenzahnaerztlichevereinigung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### kostentraegergruppe
> aus der Schluesseltabelle S_KTS_KTGRUPPE.xml (1.2.276.0.76.5.240) ausgelesen
> Werte: Primarkasse, Ersatzkasse, Sonstige Kostentraeger

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### kostentraegernichtkvabrechnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `email` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `leistungserbringertyp` | integer | 1. SonstigeLeistungserbringer, 2. Krankenhaus |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `zeichensatz` | text |  |
| `grosskundenadresse_ident` | bigint | FK → `adresse` |
| `hausadresse_ident` | bigint | FK → `adresse` |
| `postadresse_ident` | bigint | FK → `adresse` |
| `artderinstitution` | text |  |
| `dfuprotokoll` | text |  |
| `institutskennzeichen` | bigint |  |
| `ftamadresse` | text |  |
| `ftamport` | text |  |

### kostentraegersonstigeleistungserbringer
> Deprecated, wird nicht verwendet.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `art` | integer |  |
| `email` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `institutskennzeichen` | bigint |  |
| `name` | text |  |
| `zeichensatz` | text |  |
| `visible` | boolean | NOT NULL |

### kostentraegerverknuepfung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abrechnungscode` | text |  |
| `bundesland` | text |  |
| `datenlieferungsart` | text |  |
| `kvbezirk` | text |  |
| `tarifkennzeichen` | text |  |
| `uebermittelungsmediumsart` | text |  |
| `verknuepfungspartner_ident` | bigint | FK → `kostentraegersonstigeleistungserbringer` |
| `visible` | boolean | NOT NULL |
| `artderverknuepfung` | text |  |
| `weiterleitenderkostentr_ident` | bigint | FK → `kostentraegernichtkvabrechnung` |

### krankenkasse
> Falls die Kasse nicht beim ABDA-Import existiert, sollte eine Warnung generiert werden.
> Muesste korrekterweise "Kostentraeger" heissen, aber das zu refactoren waere zu aufwendig.
> Es gibt keine Relation zwischen Kostentraeger und Kartendaten, da eine solche Zuordnung
> eher von untergeordnetem Interesse ist. Wichtiger ist, fuer einen Schein zu wissen, auf welchen
> Kostentraeger _unter Beruecksichtigung von Fusionen_ abgerechnet werden soll (je nach
> Quartal koennte ein und dieselbe Karte auf zwei verschiedene Kostentraeger abgerechnet werden).

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `kassenname` | text |  |
| `erfassungsdatumletzteaenderung` | timestamp |  |
| `existenzbeendigung` | timestamp |  |
| `kostentraegernummer` | text |  |
| `kurzname` | text |  |
| `revision` | bigint |  |
| `sortiername` | text |  |
| `suchname` | text |  |
| `temporaer` | boolean |  |
| `wirksamkeitsdatumletzteaenderung` | timestamp |  |
| `ort` | text |  |
| `plz` | text |  |
| `registernr` | text |  |
| `strasse` | text |  |
| `abrechnendekv_ident` | bigint | FK → `kassenaerztlichevereinigung` |
| `anschrift_ident` | bigint | FK → `adresse` |
| `aufnehmendekasse_ident` | bigint | FK → `krankenkasse` |
| `gebuehrenordnungkbv_ident` | bigint | FK → `gebuehrenordnungkbv` |
| `kostentraegergruppe_ident` | bigint | FK → `kostentraegergruppe` |
| `postfach_ident` | bigint | FK → `adresse` |
| `referenzkasse_ident` | bigint | FK → `krankenkasse` |
| `vertragsabschliessendekv_ident` | bigint | FK → `kassenaerztlichevereinigung` |
| `standardsteigerungsschema_ident` | bigint | FK → `steigerungsschema` |
| `empfaengergln` | text |  |
| `versicherergln` | text |  |
| `bundesland` | text |  |
| `abrechnungsstelle_ident` | bigint | FK → `dvpabrechnungsstelle` |
| `modus` | integer |  |
| `typ` | integer |  |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `kontaktdatenvertrauensarzt_ident` | bigint | FK → `kontaktdaten` |
| `gruppe` | integer |  |
| `abrechnungkbr` | boolean |  |
| `abrechnungkch` | boolean |  |
| `abrechnungkfo` | boolean |  |
| `abrechnungpar` | boolean |  |
| `abrechnungpro` | boolean |  |
| `kassenart` | text |  |
| `kassenblock` | text |  |
| `telefax` | text |  |
| `telefon` | text |  |
| `kzv_ident` | bigint | FK → `kassenzahnaerztlichevereinigung` |
| `iknummer` | text |  |
| `debitorennummer` | text |  |
| `art` | integer |  |
| `backup_ident` | bigint | FK → `krankenkasse` |
| `manuelleadresse_ident` | bigint | FK → `adresse` |
| `hauptik` | text |  |

### kvabrechnungsgebiet
> Wird aus der KBV-Schluesseltabelle S_KBV_ABRECHNUNGSGEBIET.xml importiert.
> Werte: 01 = Dialyse-Arztkosten, 02 = Dialyse-Sachkosten, 03 = Methadon-Substitutionsbehandlung, ...

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `listenposition` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |

### pflegekasse
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `institutionskennzeichen` | text |  |
| `name` | text |  |

## 11. Medikamente & Verordnungen

### darreichung
> DAA_MED
> CATALOGENTRY via PACKAGE

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abdakey` | text |  |
| `kuerzel` | text |  |
| `name` | text |  |

### dosierungshistorie
> enthaelt archivierte + aktuelle Dosierung

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `dosierungabend` | text |  |
| `dosierungfrueh` | text |  |
| `dosierungmittag` | text |  |
| `dosierungnacht` | text |  |
| `gueltigbis` | timestamp |  |
| `reichtbis` | timestamp |  |
| `restkontingent` | real |  |
| `startkontingent` | real |  |
| `dosierungeinheit` | text |  |
| `dosierungfreitext` | text |  |

### medikament
> beinhaltet alle Infos, die in Tabellenform dargestellt werden muessen
> s. auch Fragen zu KBV-Anforderungen P3-120
> PACKAGE/PRODUCT

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `atcbezeichnung` | text | Suchattribut fuer coreData, diese muessen bei. Update haendisch synchronisiert werden. weiter unten kommen noch mehr davon |
| `atccode` | text | Suchattribut f?r coreData |
| `ausservertrieb` | boolean | NOT NULL |
| `avp` | integer | NOT NULL. ApothekenVerkaufsPreis |
| `avpunverbindlich` | boolean | NOT NULL |
| `darreichung` | text | Suchattribut f?r coreData |
| `darreichungequiv` | text | Fuer Gruppierung aequivalenter Darreichungsformen in H028 P3-320 |
| `darreichungkurz` | text | zur Filterung bei S3C-IMM-Verweisen, Bezeichnung laut Schluesseltabelle  1.2.276.0.76.3.1.1.5.2.15 |
| `einheit` | text |  |
| `equivalenzgruppe` | text | benoetigt fuer Sortierung gemaess P3-320 |
| `erstattungsfaehig` | integer | NOT NULL. Wertebereich 0 bis 30 (s. defines in ABDA_PreprocessingSearchTables.java) |
| `hersteller` | text | Suchattribut f?r coreData |
| `indikationen` | text |  |
| `kurzname` | text | Suchattribut f?r coreData |
| `liste` | smallint | NOT NULL. 1 = Med, 2 = Hilfsmittel, 3 = beide |
| `menge` | text |  |
| `mengesortfield` | real | NOT NULL |
| `nkennzeichnung` | text |  |
| `ownequivgroup` | text |  |
| `pharmadetailsident` | bigint | um schnell 'gleiche' Medikamente zu identifizieren (Medikamentennplan) |
| `priscus` | boolean | NOT NULL |
| `pzn` | text | PK, PharmaZentralNummer |
| `rabattidents` | text |  |
| `reimport` | boolean | NOT NULL |
| `rezeptpflicht` | smallint | NOT NULL |
| `wirkstaerke` | text |  |
| `wirkstoffe` | text |  |
| `zuzfreisgb31` | boolean | NOT NULL. zuzahlungsfrei nach Par. 31 SGB V |
| `zuzahlung` | integer | NOT NULL. beinhaltet den wert, der bei erstattungsfaehigkeit zugezahlt werden muesste  |
| `medikamentendetails_ident` | bigint | FK → `medikamentendetails` |
| `festbetrag` | integer |  |
| `wirkstaerkesortname` | text |  |
| `aussortiert` | boolean |  |
| `teilbarkeit` | smallint |  |
| `regnr` | text |  |
| `hasblauehandbriefe` | boolean |  |
| `hascurrentrotehandbriefe` | boolean |  |
| `digaagelist` | text |  |
| `digahardwarerequired` | text |  |
| `digaindikationencodediagnoselist` | text |  |
| `digaindikationencodelist` | text |  |
| `digamodulname` | text |  |
| `diganame` | text |  |
| `digastatus` | text |  |
| `isgenerikum` | boolean |  |
| `patientpayment130b1c` | integer |  |
| `digahaskontraindikationen` | boolean |  |
| `enthaeltlaktose` | boolean |  |

### medikamentendetails
> PACKAGE/PRODUCT

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `apopflicht` | smallint | NOT NULL. apothekenpflichtig? |
| `arzneimittel` | smallint | NOT NULL |
| `ausnahme_ersetzung` | smallint | NOT NULL |
| `bedingte_erstatt_fam` | smallint | NOT NULL. erstattungsfaehig = rezeptpflichtig oder bedinte Erstattung_fam. auch indirekt vorhanden ueber entsprechende Verordnungsvorgabe |
| `biotechnisch` | smallint | NOT NULL |
| `btm` | smallint | NOT NULL. Betaeubungsmittel? |
| `diaetetikum` | smallint | NOT NULL |
| `gdat_verkehrsstatus` | timestamp |  |
| `gdat_vertriebsstatus` | timestamp |  |
| `gdate_preise` | timestamp |  |
| `generikum` | smallint | NOT NULL |
| `hilfsmittelzumverbrauch` | smallint | NOT NULL |
| `import_reimport` | integer | NOT NULL |
| `lifestyle` | smallint | NOT NULL. LifeStyle-Produkt? |
| `medizinprodukt` | smallint | NOT NULL |
| `nachfolgepzn` | text |  |
| `negativliste` | smallint | NOT NULL |
| `orginalpznbeireimport` | text |  |
| `t_rezept` | smallint | NOT NULL |
| `tfg` | smallint | NOT NULL. Transfusionsgesetz (Blutprodukte) |
| `vertriebsstatus` | smallint | NOT NULL |
| `zuzfrei_31sgb_feb` | integer | NOT NULL |
| `zuzfrei_31sgb_tstr` | smallint | NOT NULL |
| `darreichung_ident` | bigint | FK → `darreichung` |
| `medikamentenhersteller_ident` | bigint | FK → `medikamentenhersteller` |
| `pharmadetails_ident` | bigint | FK → `medikamentenpharmadetails` |
| `abloesung130a` | smallint |  |
| `erstattungsbetrag130b` | integer |  |
| `medizinprodukt_amrl` | smallint |  |
| `verbandmittel31` | smallint |  |
| `kontrazeptivum` | smallint | NOT NULL |
| `packungnorm_ident` | bigint | FK → `packungnorm` |
| `bmp_komponente_ident` | bigint | FK → `bmp_artikelkomponente` |
| `prescriptionname` | text |  |
| `vaccine` | smallint |  |
| `verordnungsartikelarvgroup_ident` | bigint | FK → `verordnungsartikelarvgroup` |
| `diga` | smallint |  |
| `regnr` | text |  |
| `ifaname` | text |  |
| `digaausschlusskriterien` | text |  |
| `digaerforderlichezusatzgeraete` | text |  |
| `digagenderlist` | text |  |
| `digalanguagelist` | text |  |
| `digamodulid` | text |  |
| `wundbehandlung31` | smallint |  |
| `benoetigtverschreiberid` | boolean |  |

### medikamentenhersteller
> COMPANY

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abdakey` | text |  |
| `firmenname` | text |  |
| `sortiername` | text |  |
| `addresscity` | text |  |
| `addresscountry` | text |  |
| `addressline` | text |  |
| `addresspostcode` | text |  |
| `contactaddressline` | text |  |
| `contactemail` | text |  |
| `contactfamilyname` | text |  |
| `contactgivenname` | text |  |
| `contactphone` | text |  |
| `email` | text |  |

### medikamentenpharmadetails
> PRODUCT

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `monopraeparat` | smallint | NOT NULL |
| `produktgruppe` | smallint | NOT NULL |
| `veterinaerpraeparat` | smallint | NOT NULL |
| `nkennzeichen` | text | komma-separierte Liste von Packungsnormen |
| `emazulassung` | boolean |  |
| `regnr` | text |  |

### medikamentenplan
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `apothekenidf` | text |  |
| `ausdruckdatum` | timestamp |  |
| `ausdruckender` | text |  |
| `disclaimer` | text |  |
| `email` | text |  |
| `geburtsdatum` | text | ⚠ Nicht im finalen SELECT. `CAST(x AS date)` empfohlen |
| `gesamtseitenzahl` | integer |  |
| `identifikationsname` | text |  |
| `laenderkennzeichen` | text |  |
| `lanr` | text |  |
| `nachname` | text | ⚠ Nicht im finalen SELECT |
| `ort` | text |  |
| `parameterfreitext` | text |  |
| `parameterblock_text1` | text |  |
| `parameterblock_text2` | text |  |
| `parameterblock_text3` | text |  |
| `patchnummer` | integer |  |
| `patientgeschlecht` | text |  |
| `patientschwanger` | text |  |
| `patientstillend` | text |  |
| `patientenallergienunvertraeglichkeiten` | text |  |
| `patientenid` | text |  |
| `patientenkreatininwert` | text |  |
| `patientengewicht` | text |  |
| `patientengroesse` | text |  |
| `plz` | text |  |
| `sprachkennzeichen` | text |  |
| `strasse` | text |  |
| `telefonnummer` | text |  |
| `versionsnummer` | text |  |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `zertifizierungskennung` | text |  |
| `thenadocument_ident` | bigint | FK → `thenadocument` |
| `namenszusatz` | text |  |
| `titel` | text |  |
| `vorsatzwort` | text |  |
| `parameterfreitextd` | boolean |  |
| `patiententbindungstermin` | timestamp |  |
| `patientgeschlechtd` | boolean |  |
| `patientschwangerd` | boolean |  |
| `patientstillendd` | boolean |  |
| `patientenallergienunvertraeglichkeitend` | boolean |  |
| `patientenkreatininwertd` | boolean |  |
| `patientenkreatininwertdatum` | timestamp |  |
| `patientengewichtd` | boolean |  |
| `patientengroessed` | boolean |  |
| `aenderungsdatum` | timestamp |  |

### medikamentenplanallergieelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `quelle` | text |  |
| `reaktion` | text |  |
| `substanz` | text |  |
| `listenposition` | integer |  |

### medikamentenplanelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `arzneimittel` | text |  |
| `behandlungsgrund` | text |  |
| `darreichungsform` | text |  |
| `dosiereinheit` | text |  |
| `dosierschema` | text |  |
| `freitextzeile` | text |  |
| `hinweise` | text |  |
| `isfreitextzeile` | boolean |  |
| `iskombinationspraeparat` | boolean |  |
| `iswirkstoffverordnung` | boolean |  |
| `listenposition` | integer |  |
| `modifiziertepzn` | text |  |
| `rezeptureintrag` | text |  |
| `wirkstaerke` | text |  |
| `wirkstoff` | text |  |
| `zwischenueberschrift` | text |  |
| `medikamentenverordnung_ident` | bigint | FK → `medikamentenverordnung` |
| `gebundenezusatzzeile` | text |  |
| `aenderungsdatum` | timestamp |  |
| `beendet` | timestamp |  |
| `dauermedikation` | boolean |  |
| `erfassungsdatum` | timestamp |  |
| `historisiert` | boolean |  |
| `kommentar` | text |  |
| `relevantfuerbmp` | boolean |  |

### medikamentenplanseite
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `instanzid_1_0` | text |  |
| `seitenzahl_1_2` | integer |  |
| `datei_ident` | bigint | FK → `datei` |

### medikamentenverordnung
> s. Klassendiagramm Medikamente

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `autidem` | boolean |  |
| `avpbeiverordnung` | integer | NOT NULL |
| `darreichungbeiverordnung` | text |  |
| `datum` | timestamp | auch Datum der letzen Dosierungsanpassung |
| `dosierungabend` | text |  |
| `dosierungfreitext` | text |  |
| `dosierungfrueh` | text |  |
| `dosierungmittag` | text |  |
| `dosierungnacht` | text |  |
| `dosierungreichtbis` | timestamp |  |
| `einheitbeiverordnung` | text |  |
| `herstellerbeiverordnung` | text |  |
| `mengebeiverordnung` | text |  |
| `namebeiverordnung` | text | if PZN is deleted, we want to show the old information. wie er auf das Rezept gedruckt wurde (mit Menge...) |
| `nkennzeichnungbeiverordnung` | text |  |
| `pzn` | text |  |
| `visible` | boolean | NOT NULL |
| `wirkstaerkebeiverordnung` | text |  |
| `eigenrezeptur_ident` | bigint | FK → `eigenrezeptur` |
| `dauermedikation` | boolean | NOT NULL |
| `rezepttyp` | smallint | NOT NULL. 0 = n.d., 1 = rot, 2= gruen, 3 = blau, 4 = BTM, 5 = 16a |
| `abdakurznamebeiverordnung` | text | der Name wie er zum Verordnungszeitpunkt in der ABDA lautet |
| `anzahl` | integer | NOT NULL |
| `diagnosetext` | text |  |
| `hilfsmittel` | integer | NOT NULL. 0 = uninitialisiert. 1 = ja. 2 = nein |
| `gkvhilfsmitteltyp` | integer | 0 = Regelfall; 1 = Einzelproduktverordnung (vgl. VSST625) |
| `zeitraum` | integer | NOT NULL. vgl. VSST625. 1 = 1-2 Wochen. 2  = 1 Monat. 3 = 3 Monate. 4 = 6 Monate |
| `hzvkategorie` | text | z.B. GRUEN |
| `ignoreinteraktionen` | boolean | NOT NULL |
| `atcbeiverordnung` | text |  |
| `listenposition` | integer | im Medikamentenplan |
| `inhaltinfospalte` | text |  |
| `namebeiverordnung_phonetic` | text |  |
| `gevkofarbe` | text | fuer die Berechnung der Gruenklickquote |
| `aenderungseitdruck` | boolean |  |
| `datumletzteaenderung` | timestamp | s #4027 |
| `dosiereinheit_bmp` | text |  |
| `grund_bmp` | text |  |
| `hinweis_bmp` | text |  |
| `abgesetztam` | timestamp |  |
| `fremdimportiert` | boolean |  |
| `importiertprotokoll` | text | Aenderungshistorie fuer Fremdimporte |
| `goaeleistung_ident` | bigint | FK → `leistung` |
| `katalogtyp` | integer | nil, 0 : ABDA, 1 Schweiz |
| `freitextzeile` | text |  |
| `isfreitextzeile` | boolean |  |
| `zwischenueberschrift` | text |  |
| `absetzungsgrund` | integer | 0 = inaktiv, 1 = unvertraeglichkeit |
| `druckbar` | boolean |  |
| `impfstoff` | integer |  |
| `einnahmetyp` | integer | NOT NULL |
| `grund_armin` | text |  |
| `hinweis_armin` | text |  |
| `gebundenezusatzzeile_bmp` | text |  |
| `iswirkstoffverordnung` | boolean |  |
| `namebeiwirkstoffverordnung` | text |  |
| `wirkstoffnamebeiverordnung` | text | Achtung! ist erst seit Feb 2020 befüllt |
| `databasebeiverordnung` | text | nil = ABDA, MMI = MMI |
| `dtype` | varchar | NOT NULL |
| `gebuehrenbefreit` | boolean |  |
| `kvpbeiverordnung` | integer |  |
| `packungsart` | smallint |  |
| `taxpreisbeiverordnung` | integer |  |
| `kassenzeichenbeiverordnung` | text |  |
| `ersatzverordnung` | boolean |  |
| `fremdverordner` | text |  |
| `begruendung` | text |  |
| `bewilligungsanfrageid` | text |  |
| `bewilligungsstatus` | smallint |  |
| `batchablaufdatum` | timestamp |  |
| `batchlotnumber` | text |  |
| `contenttext` | text |  |
| `verschreibungspflichtig` | boolean |  |
| `addtomedplan` | boolean |  |
| `bewilligungsmethode` | smallint |  |
| `bewilligungstyp` | smallint |  |
| `rezept_ident` | bigint | FK → `rezept` |
| `elgaadverordnungsid` | text |  |
| `stornierbar` | boolean |  |
| `storniert` | boolean |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `bgcolor` | text |  |
| `abgabehinweis` | text |  |
| `darreichungscodebeiverordnung` | text |  |
| `kategoriebeiverordnung` | integer |  |
| `eformular_ident` | bigint | FK → `eformular` |
| `mehrfachverordnungselement_ident` | bigint | FK → `mehrfachverordnungselement` |
| `notfallkennzeichen` | smallint |  |
| `zusatzkennzeichenbitmask` | integer |  |
| `dosierangabeoption` | smallint |  |
| `abgabeart` | smallint |  |
| `abweichenderattester_ident` | bigint | FK → `nutzer` |
| `abweichenderverordner_ident` | bigint | FK → `nutzer` |
| `darreichungbeiwirkstoffverordnung` | text |  |
| `atlangzeitbewilligung_ident` | bigint | FK → `atlangzeitbewilligung` |
| `digaagelistbeiverordnung` | text |  |
| `digaausschlusskriterienbeiverordnung` | text |  |
| `digaerforderlichezusatzgeraetebeiverordnung` | text |  |
| `digagenderlistbeiverordnung` | text |  |
| `digahardwarerequiredbeiverordnung` | text |  |
| `digaindikationencodelistbeiverordnung` | text |  |
| `digakontraindikationencodelistbeiverordnung` | text |  |
| `digalanguagelistbeiverordnung` | text |  |
| `digamodulnamebeiverordnung` | text |  |
| `diganamebeiverordnung` | text |  |
| `digastatusbeiverordnung` | text |  |
| `digazusaetzlichemehrkostenbeiverordnung` | integer |  |
| `herstellercontactemailbeiverordnung` | text |  |
| `herstellercontactfamilynamebeiverordnung` | text |  |
| `herstellercontactgivennamebeiverordnung` | text |  |
| `herstellercontactphonebeiverordnung` | text |  |
| `rabattproduktbeiverordnung` | boolean |  |
| `abgesetztvon_ident` | bigint | FK → `nutzer` |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |
| `epaprescriptionid` | text |  |
| `dispense_ident` | bigint | FK → `medikamentenverordnung` |
| `verschreiberidbeiverordnung` | text |  |

### rezept
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `ausgestelltdatum` | timestamp |  |
| `erstelltdatum` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `arzt_ident` | bigint | FK → `nutzer` |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `kartendaten_ident` | bigint | FK → `kartendaten` |
| `attester_ident` | bigint | FK → `nutzer` |

### teilbarkeit
> DIVISIBILITY

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `teilbarkeit` | smallint | NOT NULL |
| `teilbarkeittype` | smallint | NOT NULL |

### verordnungsartikel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `ddd` | real | NOT NULL. nur Typ 4 |
| `clipmetoo_ident` | bigint | FK → `clipmetoo` |

### verordnungsauftrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `dosierungabend` | text |  |
| `dosierungfreitext` | text |  |
| `dosierungfrueh` | text |  |
| `dosierungmittag` | text |  |
| `dosierungnacht` | text |  |
| `erstelltam` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `wirkstoffname` | text |  |
| `pzn` | text |  |
| `darreichung` | text |  |
| `freitext` | text |  |
| `medikamentenverordnung_ident` | bigint | FK → `medikamentenverordnung` |
| `patient_ident` | bigint | FK → `patient` |
| `wirkstaerke` | text |  |

### verordnungsvorgabe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `befristungsdatum` | timestamp |  |
| `text` | text |  |
| `typ` | smallint | NOT NULL |
| `name` | text |  |

## 12. Labor

### einzelbefund
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `befundobjectype` | smallint |  |
| `beschreibung` | text |  |
| `kuerzel` | text |  |
| `name` | text |  |
| `type` | smallint |  |
| `zsidentifier` | text |  |
| `befcolor` | text |  |
| `plancolor` | text |  |
| `seite` | smallint |  |
| `textype` | smallint |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `hkpbefundcode` | text |  |
| `hkpplancode` | text |  |
| `regelversorgung` | smallint |  |
| `synadocbefundcode` | text |  |
| `synadocplancode` | text |  |

### labor
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `allginformationen9472` | text |  |
| `bsnr0201` | text |  |
| `bsnrbezeichnung0203` | text |  |
| `erstellungsdatum9103` | timestamp |  |
| `kbvpruefnummer0101` | text |  |
| `kundennummer8312` | text | Kundennummer der Praxis beim Labor |
| `labor8300` | text |  |
| `laborname8320` | text |  |
| `lanr0212` | text | kann mehrmals auftreten |
| `lanrarztname0211` | text | einmal pro LANR |
| `satzversion9212` | text |  |
| `zeichensatz9106` | text |  |
| `adresse_ident` | bigint | FK → `adresse` |
| `fachrichtung7268` | text |  |
| `laborart7266` | text |  |
| `laborstandortid8324` | text |  |
| `urlkataloge7352` | text |  |

### laborauftrag
> Falls Befunde ohne zuordenbaren Auftrag kommen, muss ein Auftrag angelegt werden
> s. Klassendiagramm Labordaten

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anforderungsident` | text | laufende Nummer des Klebchens |
| `auftrag` | text | Inhalt des Auftrages - angeforderte Untersuchung |
| `erstellt` | timestamp |  |
| `labor_ident` | bigint | FK → `labor` |
| `laborbefund_ident` | bigint | FK → `laborbefund` |
| `patient_ident` | bigint | FK → `patient` |
| `removed` | boolean | NOT NULL |
| `laborueberweisung_ident` | bigint | FK → `karteieintrag` |
| `arztlanr` | text |  |
| `praxisbsnr` | text |  |
| `endbefund_ident` | bigint | FK → `lb820x` |
| `internelabornummer` | text |  |

### laborbefund
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anforderungsident` | text |  |
| `erstellt` | timestamp |  |
| `removed` | boolean | NOT NULL |

### laborkatalogeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `dtype` | varchar | NOT NULL |
| `ident` | bigint | PK |
| `code` | text |  |
| `farbe` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `temporaer` | boolean | NOT NULL |
| `kzvbereich` | text |  |
| `katalogtyp` | smallint |  |
| `useforkonformitaetserklaerung` | boolean |  |

### laborkatalogeintragdetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `kassenart` | smallint |  |
| `kuerzel` | text |  |
| `kurztext` | text |  |
| `preisgewerbelabor` | integer |  |
| `preiskbgewerbelabor` | integer |  |
| `preiskbpraxislabor` | integer |  |
| `preiskfogewerbelabor` | integer |  |
| `preiskfopraxislabor` | integer |  |
| `preispagewerbelabor` | integer |  |
| `preispapraxislabor` | integer |  |
| `preispraxislabor` | integer |  |
| `preiszegewerbelabor` | integer |  |
| `preiszepraxislabor` | integer |  |
| `mwstgewerbelabor` | integer |  |
| `mwstpraxislabor` | integer |  |

## 13. Impfungen

### einzelimpfung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `charge` | text |  |
| `datum` | timestamp |  |
| `notiz` | text |  |
| `ort` | text |  |
| `removed` | boolean | NOT NULL |
| `impfstoff_ident` | bigint | FK → `impfstoff` |
| `gda` | text |  |
| `identifier` | text |  |
| `dosis` | text |  |
| `dosistext` | text |  |
| `schemacode` | text |  |
| `uniqueid` | text |  |
| `mioattesteroperationsite` | text |  |
| `mioattesterpractitioner` | text |  |
| `mioentereroperationsite` | text |  |
| `mioentererpractitioner` | text |  |
| `mioquelleinformation` | text |  |
| `nachtragung` | boolean |  |
| `elgaimpfdaten_ident` | bigint | FK → `elgaimpfdaten` |

### impfeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `haltbarkeit` | timestamp | bis wann aktuell Impfschutz besteht. wann die n?chste Impfung erfolgen soll |
| `notiz` | text |  |
| `visible` | boolean | NOT NULL |
| `impfkrankheit_ident` | bigint | FK → `impfkrankheit` |
| `impfschutz` | boolean | NOT NULL |
| `letztertestimmundatum` | timestamp |  |
| `letztertestimmunerlangt` | boolean |  |
| `letztertestimmunhinweis` | text |  |

### impfkrankheit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beschreibung` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `code` | text |  |
| `kategorie_ident` | bigint | FK → `elgavalueset` |

### impfplan
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `notiz` | text |  |
| `visible` | boolean | NOT NULL |

### impfschema
> halb transparent, d.h. im Normalfall werden Impfstoffe einmalig direkt angewendet

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abstand1` | integer | NOT NULL |
| `abstand2` | integer | NOT NULL. Abstaende in Tagen |
| `beschreibung` | text |  |
| `haltbarkeit` | integer | NOT NULL. Haltbarkeit in Monaten |
| `name` | text |  |
| `removed` | boolean | NOT NULL |
| `abstand3` | integer | NOT NULL |
| `abstand4` | integer | NOT NULL |
| `code` | text |  |

### impfschemadetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `dosis` | text |  |
| `dosistext` | text |  |
| `sortkey` | text |  |

### impfstoff
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beschreibung` | text |  |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `pzn` | text |  |
| `code` | text |  |
| `registernr` | text |  |

### verabreichung
> DIVISIBILITY

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `breaklinetype` | smallint | NOT NULL |
| `crushable` | smallint | NOT NULL |
| `hinweis` | text |  |
| `maybeopened` | smallint | NOT NULL |
| `suspendable` | smallint | NOT NULL |
| `tubeapplicable` | smallint | NOT NULL |
| `tubediameter` | bigint |  |
| `watersoluble` | smallint | NOT NULL |

## 14. Frueherkennung & Vorsorge

### frueherkennungerinnerungconfig
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abstanderinnerung` | integer |  |
| `ausschlussbeianstehendemtermin` | boolean |  |
| `diagnoseausschlusszeitraum` | integer |  |
| `erinnernarztdirekt` | boolean | NOT NULL |
| `erinnernpost` | boolean | NOT NULL |
| `erinnernsms` | boolean | NOT NULL |
| `maxanzahlerinnerung` | integer |  |
| `visible` | boolean | NOT NULL |
| `emailvorlage_ident` | bigint | FK → `emailvorlage` |
| `erinnernemail` | boolean | NOT NULL |
| `tageerinnerungvortermin` | integer |  |
| `emailaccount_ident` | bigint | FK → `emailaccount` |
| `emailsignatur_ident` | bigint | FK → `emailsignatur` |
| `karteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `terminart_ident` | bigint | FK → `terminart` |
| `dontsendimmediately` | boolean | NOT NULL |
| `isgruppenversandaktiv` | boolean | NOT NULL |
| `gruppenemailvorlage_ident` | bigint | FK → `emailvorlage` |
| `maxanzahlprokanal` | integer |  |
| `versandende` | integer | NOT NULL |
| `versandnurwerktags` | boolean | NOT NULL |
| `versandstart` | integer | NOT NULL |
| `ismanualdefaultconfig` | boolean | NOT NULL |

### frueherkennungscustomfilter
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `predicates` | text |  |
| `type` | text |  |

### frueherkennungskrankheit
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `icdkatalogeintrag_ident` | bigint | FK → `icdkatalogeintrag` |
| `removed` | boolean | NOT NULL |
| `lastchange` | timestamp |  |
| `lastupdate` | timestamp |  |
| `lastupdatestate` | text |  |
| `needsupdate` | integer | NOT NULL |
| `activeforeverypatient` | boolean |  |
| `visible` | boolean | NOT NULL |
| `isfromzollsoft` | boolean |  |
| `zsidentifier` | text |  |
| `frueherkennungerinnerungconfig_ident` | bigint | FK → `frueherkennungerinnerungconfig` |
| `karteieintragkette_ident` | bigint | FK → `karteieintragkette` |
| `kriterienhash` | text |  |
| `kriterienversion` | integer |  |

### frueherkennungskriterienelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `info` | text |  |
| `isgroup` | boolean | NOT NULL |
| `name` | text |  |
| `removed` | boolean | NOT NULL |
| `ebmkatalogeintrag_ident` | bigint | FK → `ebmkatalogeintrag` |
| `goaekatalogeintrag_ident` | bigint | FK → `goaekatalogeintrag` |
| `hzvkatalogeintrag_ident` | bigint | FK → `hzvkatalogeintrag` |
| `icdkatalogeintrag_ident` | bigint | FK → `icdkatalogeintrag` |
| `priority` | integer |  |
| `typeflag` | integer |  |
| `usesanzahl` | boolean |  |
| `favorit_ident` | bigint | FK → `outlineviewelement` |
| `erstelltam` | timestamp |  |
| `bemakatalogeintrag_ident` | bigint | FK → `bemakatalogeintrag` |
| `abrechnungstyp` | smallint |  |
| `karteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `diagnosesicherheit` | text |  |

### frueherkennungsregel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beginagedays` | integer |  |
| `endagedays` | integer |  |
| `forfemale` | boolean |  |
| `formale` | boolean |  |
| `intervalmonths` | integer | NOT NULL |
| `totalnumber` | integer |  |
| `krankheit_ident` | bigint | FK → `frueherkennungskrankheit` |
| `removed` | boolean | NOT NULL |
| `annualframe` | boolean | kann ab v1.135 entfernt werden |
| `name` | text |  |
| `filterflag` | integer |  |
| `frueherkennungskriterien_ident` | bigint | FK → `frueherkennungskriterienelement` |
| `totalnumberframe` | integer |  |
| `totalannualframe` | boolean |  |
| `abrechnungsvorschlag_ident` | bigint | FK → `abrechnungsvorschlag` |
| `usecurrenttimeunitfortotalnumber` | boolean |  |
| `onlyonsaturday` | boolean |  |
| `mininterval` | integer |  |
| `intervaltimeunit` | smallint |  |
| `minintervaltimeunit` | smallint |  |
| `totalnumberframetimeunit` | smallint |  |
| `abrechnungsfehlerfilter_ident` | bigint | FK → `abrechnungsfehlerfilter` |
| `zsidentifier` | text |  |
| `ageunitinteger` | integer |  |
| `kriterienhash` | text |  |

### frueherkennungsuntersuchung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `aufgeklaert` | boolean |  |
| `date` | timestamp |  |
| `untersucht` | boolean |  |
| `krankheit_ident` | bigint | FK → `frueherkennungskrankheit` |
| `ebmleistung_ident` | bigint | FK → `leistung` |
| `goaeleistung_ident` | bigint | FK → `leistung` |
| `hzvleistung_ident` | bigint | FK → `leistung` |
| `removed` | boolean | NOT NULL |
| `type` | integer |  |
| `frueherkennungskriterienelement_ident` | bigint | FK → `frueherkennungskriterienelement` |
| `anzahl` | integer |  |
| `beginscase` | boolean |  |

### patientenfrueherkennungsregel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `intervalmonth` | integer | NOT NULL |
| `krankheit_ident` | bigint | FK → `frueherkennungskrankheit` |
| `active` | boolean |  |
| `interval` | integer | NOT NULL |
| `intervaltimeunit` | smallint |  |

## 15. Psychotherapie

### psychotherapie
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `iskinderjugendtherapie` | boolean |  |
| `therapieanfang` | timestamp |  |
| `therapieart` | integer | 0..einzel, 1..gruppe, 2...kombiüberwiegiendEinzel, 3...kombiÜberwiegendGruppe |
| `therapieende` | timestamp |  |
| `therapieverfahren` | integer | 0..analytisch, 1...tiefen, 2...verhaltens, 3...systemisch |
| `visible` | boolean | NOT NULL |
| `apsyedokumentation_ident` | bigint | FK → `edokumentation` |
| `therapieanfanguserdefined` | timestamp |  |
| `therapieendeuserdefined` | timestamp |  |
| `iskjtuserdefined` | boolean |  |
| `therapieartuserdefined` | integer |  |
| `therapieverfahrenuserdefined` | integer |  |

### psychotherapieaktion
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `ebmkatalogeintrag_ident` | bigint | FK → `ebmkatalogeintrag` |
| `formulartyp_ident` | bigint | FK → `formulartyp` |

### psychotherapieinfo
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beginn` | timestamp |  |
| `name` | text |  |
| `status` | text |  |
| `visible` | boolean | NOT NULL |

### psychotherapiequalifikation
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `analytischepsychotherapie` | boolean | NOT NULL |
| `darfemdrabrechnen` | boolean | NOT NULL |
| `darfgruppenabrechnen` | boolean | NOT NULL |
| `darfhypnoseabrechnen` | boolean | NOT NULL |
| `systemischepsychotherapie` | boolean | NOT NULL |
| `tiefenpsychologischepsychotherapie` | boolean | NOT NULL |
| `verhaltenstherapie` | boolean | NOT NULL |
| `darfuebendeverfahrenabrechnen` | boolean | NOT NULL |
| `behandelterwachsene` | boolean | NOT NULL |
| `behandeltkinderundjugendliche` | boolean | NOT NULL |

### psychotherapiestadium
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `visible` | boolean | NOT NULL |
| `psychotherapieinfo_ident` | bigint | FK → `psychotherapieinfo` |

### psychotherapiezaehler
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `wert` | real | NOT NULL |
| `maxwertoverride` | real | NOT NULL |
| `minwertoverride` | real | NOT NULL |
| `warnwertoverride` | real |  |
| `psychotherapiezaehlertyp_ident` | bigint | FK → `psychotherapiezaehlertyp` |
| `offsetwert` | real |  |
| `visibleinkartei` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |

### psychotherapiezaehlergewicht
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `gewicht` | real | NOT NULL |
| `ebmkatalogeintrag_ident` | bigint | FK → `ebmkatalogeintrag` |
| `goaekatalogeintrag_ident` | bigint | FK → `goaekatalogeintrag` |
| `visible` | boolean | NOT NULL |

### psychotherapiezaehlertyp
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `basecolor` | text |  |
| `context` | integer | NOT NULL. 0 = heute, 1 = Behandlungsfall, 2 = halbes Jahr, 4 = Krankheitsfalll |
| `fuerbezugspers` | boolean |  |
| `fuerrezidiv` | boolean |  |
| `maxwert` | real | NOT NULL |
| `minwert` | real | NOT NULL |
| `name` | text |  |
| `warncolor` | text |  |
| `visible` | boolean | NOT NULL |

## 16. Heilmittel & Hilfsmittel

### heilmittel
> z.B. CHG = Chirogymnastik

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `listenposition` | integer | NOT NULL |
| `kostenincent_aok` | integer | NOT NULL |
| `kostenincent_bkk` | integer | NOT NULL |
| `kostenincent_ikk` | integer | NOT NULL |
| `kostenincent_knappschaft` | integer | NOT NULL |
| `kostenincent_svlfg` | integer | NOT NULL |
| `kostenincent_vdek` | integer | NOT NULL |
| `positionsnummer` | text | laut GNR-Katalog fuer Physiotherapeuten |
| `visible` | boolean | NOT NULL |
| `sprach` | boolean |  |
| `sprech` | boolean |  |
| `stimm` | boolean |  |
| `therapiedauerinminuten` | integer | fuer Logopaedie |
| `bevorzugtefrequenz` | text |  |
| `abweichendekbvbezeichnung` | text |  |
| `terminart_ident` | bigint | FK → `terminart` |
| `terminarthausbesuch_ident` | bigint | FK → `terminart` |

### heilmittelbegruendung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `dauerhinweis` | text | Hinweistext zur Nutzungsdauer (z.B. "Laengstens ein Jahr nach Akutereignis") |
| `typ` | integer | NOT NULL. 1 = langfristig, 2= bes. Verordnungsbedarf |
| `obere_altersgrenze` | integer |  |
| `obere_altersgrenzetyp` | text |  |
| `untere_altersgrenze` | integer |  |
| `untere_altersgrenzetyp` | text |  |
| `zeitraum_akutereignis_typ` | integer | NOT NULL |
| `zeitraum_akutereignis_zahl` | integer | NOT NULL |

### heilmittelblankoindikation
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `erster_icd_code` | text |  |
| `hoechstalter_jahre` | integer |  |
| `mindestalter_jahre` | integer |  |
| `zweiter_icd_code` | text |  |
| `diagnosegruppe_ident` | bigint | FK → `heilmitteldiagnose` |

### heilmitteldiagnose
> z.B. WS1=Wirbelsaeulenerkrankungen mit prognostisch kurzzeitigem Behandlungsbedarf 

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beispiele` | text |  |
| `bezeichnung` | text |  |
| `code` | text |  |
| `hinweise` | text |  |
| `listenposition` | integer | NOT NULL |
| `behandlungsmenge` | integer | NOT NULL |
| `behandlungsmenge_ausnahmen` | text |  |
| `behandlungsmenge_massage` | integer | NOT NULL |
| `behandlungsmenge_standardisiert` | integer | NOT NULL |
| `frequenzempfehlung` | text |  |
| `frequenzempfehlungstyp` | integer | NOT NULL |
| `hoechstmenge_verordnung` | integer | NOT NULL |
| `patientenindividuell` | boolean | NOT NULL |
| `heilmittelkatalogkapitel_ident` | bigint | FK → `heilmittelkatalogkapitel` |

### heilmittelkatalogkapitel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `typ` | integer | NOT NULL |
| `heilmittelkatalog_ident` | bigint | FK → `customheilmittelkatalog` |

### heilmittelleitsymptomatik
> z.B. WS1a = Funktionsstoerungen/Schmerzen durch Gelenkfunktionsstoerung

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |
| `listenposition` | integer | NOT NULL |
| `ziel` | text |  |
| `hzvtherapieziel` | text |  |
| `erlaeuterungen` | text |  |

### heilmittelschein
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abgerechnet` | boolean | NOT NULL |
| `hasleistung` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `abrechnendebetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `abgerechnetam` | timestamp |  |
| `gueltigkeitseinschraenkungbis` | timestamp |  |
| `gueltigkeitseinschraenkungvon` | timestamp |  |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |

### heilmittelverordnung
> Nur für Heilmittelerbringer

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `behandlungsabbrucham` | timestamp |  |
| `fehlerhaft` | boolean |  |
| `hausbesuch` | boolean |  |
| `visible` | boolean | NOT NULL |
| `vollstaendig` | boolean |  |
| `formular_ident` | bigint | FK → `karteieintrag` |
| `privatrechnung_ident` | bigint | FK → `privatrechnung` |
| `zusammenfassung` | text |  |
| `scanseite1_ident` | bigint | FK → `datei` |
| `scanseite2_ident` | bigint | FK → `datei` |
| `abgerechnet` | boolean |  |
| `behandlungabgeschlossen` | boolean |  |
| `heilmittelschein_ident` | bigint | FK → `heilmittelschein` |
| `gutschrifterstattet` | boolean |  |
| `ausstellenderarzt_ident` | bigint | FK → `hausarzt` |
| `therapiebericht_ident` | bigint | FK → `karteieintrag` |
| `fremdverordnung` | boolean |  |

### hilfsmittel
> Hilfsmittel koennen auf dem GKV-Hilfsmittelverzeichnis stammen oder aus der ABDA.
> Hier sind nur Hilfsmittel aus dem GKV Hilfsmittelverzeichnis aufgefuehrt.
> Fuer ABDA-Hilfsmittel existiert keine Information zur HilsfmittelArt etc.
> Im Gegensatz zu Medikamenten sind Hilfsmittel Basedaten.
> Sie muessen keine inter-praxis eindeutigen idents haben.
> Es ist aber darauf zu achten, dass der HilfsmittelVerzeichnisImporter vor dem Erzeugen der sqlite-Dateien ausgefuehrt wurde
> Zu beachten ist auch die Abhaengigkeit des Hilfsmittelverzeichnisimporters vom HZV-Anhang
> !!!Es darf keine Referenz auf die Hilfsmittelklassen geben (analog Medikamente)!!!

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `code` | text | zur eindeutigen Identifizierung in der Historie. zusammengesetzt aus Gruppe.Ort.Untergruppe.Art+Hilfsmittelcode (z.B. 29.26.01.0001) |
| `hersteller` | text |  |
| `merkmale` | text |  |
| `name` | text |  |
| `hilfsmittelart_ident` | bigint | FK → `hilfsmittelart` |

### hilfsmittelart
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beschreibung` | text |  |
| `code` | text |  |
| `fragebogen` | text | rf. VSST629 |
| `name` | text |  |
| `steuerbar` | boolean | rf. VSST626 |
| `thesaurus` | text | aus der entsprechenden csv-Datei im HZV-Anhang |
| `hilfsmitteluntergruppe_ident` | bigint | FK → `hilfsmitteluntergruppe` |

### hilfsmittelgruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beschreibung` | text |  |
| `code` | text |  |
| `indikation` | text |  |
| `name` | text |  |

## 17. DMP

### dmpkennzeichen
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichnung` | text |  |
| `code` | text |  |

### dmpparameter
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bezeichner` | text |  |
| `wert` | text |  |

## 18. Briefe & Dokumente

### arztbriefeav
> s. HZV_IT_Arztvernetzung

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abschliessendebemerkungen` | text |  |
| `anrede` | text |  |
| `bekannteallergien` | text |  |
| `empfaengermode` | integer | 1= BSNR, 2= Gruppe |
| `empfaengerzusatzinfos` | text | JSON: BSNR-Bezeichnung (+Adresse und  Aerzte) oder Gruppenbezeichnung |
| `empfohlenemassnahmen` | text |  |
| `epikrise` | text |  |
| `erhobenebefunde` | text |  |
| `familienanamnese` | text |  |
| `fruehereerkrankungen` | text |  |
| `gesundheitsprobleme` | text |  |
| `grundderueberweisung` | text |  |
| `heilmittel` | text |  |
| `identifikator` | text |  |
| `impfungen` | text |  |
| `jetzigeanamnese` | text |  |
| `status` | integer | 1= created, 2 = in Zustellung, 3 = zugestellt, 4= nicht zugestellt, 0 = unbekannt |
| `therapie` | text |  |
| `aspdf_ident` | bigint | FK → `datei` |
| `erstellerbsnr_ident` | bigint | FK → `betriebsstaette` |
| `erstellerlanr_ident` | bigint | FK → `nutzer` |
| `freitextdiagnose` | text |  |
| `freitextlabor` | text |  |
| `freitextmediks` | text |  |
| `empfangsstatus` | integer |  |
| `fehlermeldung` | text |  |
| `transferid` | text |  |
| `uebernommeneangaben` | text | nur fuer empfanegen Arztbriefe |
| `versanddatum` | text |  |
| `patient_ident` | bigint | FK → `patient` |
| `nachname` | text | ⚠ Nicht im finalen SELECT. nur fuer empfanegen Arztbriefe |
| `versichertennummer` | text | ⚠ Nicht im finalen SELECT. nur fuer empfangene Arztbriefe |
| `vorname` | text | ⚠ Nicht im finalen SELECT. nur fuer empfanegen Arztbriefe |
| `zugriffstoken` | text | nur fuer empfanegen Arztbriefe |
| `absender` | text |  |
| `druckdatum` | timestamp |  |
| `dtype` | varchar | NOT NULL |
| `primaerempfaengermode` | integer |  |
| `primaerempfaengerzusatzinfos` | text |  |
| `signiererlanr_ident` | bigint | FK → `nutzer` |
| `identifikatorkopie` | text |  |
| `statuskopie` | integer |  |

### briefanrede
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `empfaengertyp` | bigint |  |
| `format` | text |  |
| `geschlechtempfaenger` | integer |  |
| `geschlechtpatient` | integer |  |
| `maxalter` | integer |  |
| `minalter` | integer |  |
| `removed` | boolean | NOT NULL |

### briefvorlage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `custom` | boolean | NOT NULL. Flag ob benutzerdefinierte Vorlage oder Standard |
| `details` | text |  |
| `formular` | boolean | NOT NULL. Formular (keine Ersetzungen) oder Vorlage mit Textfeldern (Ersetzungen) |
| `listenpos` | integer | NOT NULL |
| `name` | text |  |
| `papier` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `repaired` | boolean | NOT NULL |
| `datei_ident` | bigint | FK → `datei` |
| `onlineid` | text |  |
| `version` | integer | Falls aus dem Marketplace erzeugt ist dies die Versionsnummer des jeweiligen Marketplaceelements  |
| `hiddenforselection` | boolean |  |
| `lastusage` | timestamp |  |
| `kategorie` | text |  |
| `neueversionvorhanden` | boolean | NOT NULL |
| `dateiserverversion_ident` | bigint | FK → `datei` |
| `briefvorlagengruppe_ident` | bigint | FK → `briefvorlagengruppe` |
| `formulargruppe_ident` | bigint | FK → `formulargruppe` |
| `epadocumentclasscode` | text |  |
| `epadocumenttypecode` | text |  |
| `epauploadvorlage_ident` | bigint | FK → `epauploadvorlage` |

### briefvorlagengruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `isstandard` | boolean |  |
| `name` | text |  |
| `printertype` | integer |  |
| `removed` | boolean | NOT NULL |

### datei
> comment 1

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anzeigename` | text |  |
| `content` | text |  |
| `creationdate` | timestamp |  |
| `extension` | text | sowas wie pdf, png oder docx |
| `filename` | text |  |
| `karteitypsubpath` | text |  |
| `lastchangedate` | timestamp |  |
| `longliving` | boolean | NOT NULL. Flag ob Datei langlebig lokal gespeichert (keine Loeschung) |
| `md5` | text | md5-Hash fuer den content |
| `removed` | boolean | NOT NULL |
| `serveronlyinternalpath` | text |  |
| `dateierstelltvon_ident` | bigint | FK → `nutzer` |
| `dateigeaendertvon_ident` | bigint | FK → `nutzer` |
| `filecreationdate` | timestamp |  |
| `languagecode` | text |  |
| `contentdescription` | text |  |
| `hasdateitext` | boolean |  |
| `zsident` | integer |  |

### dateitext
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `md5` | text |  |
| `rawtext` | text |  |
| `datei_ident` | bigint | FK → `datei` |
| `rawtextvector` | tsvector |  |

### handbrief
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `documenttypecode` | text |  |
| `filepath` | text |  |
| `gueltigab` | timestamp |  |
| `gueltigbis` | timestamp |  |
| `name` | text |  |
| `sourcename` | text |  |
| `targetgroup` | text |  |

### konsileav
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `identifikator` | text |  |
| `priority` | integer | 1 = inquiry, 2 = low, 3 = medium, 4 = high |
| `removed` | boolean | NOT NULL |
| `status` | integer | 1 = IN_ARBEIT, 2 = BEAUFTRAGT, 3 = RUECKFRAGE, 4 = BEANTWORTET, 5 = BEFUNDET, 6 = ABGESCHLOSSEN, 7 = ABGEBROCHEN |
| `versichertennummer` | text | ⚠ Nicht im finalen SELECT |
| `archiveaspdf_ident` | bigint | FK → `datei` |
| `erstellerbsnr_ident` | bigint | FK → `betriebsstaette` |
| `erstellerlanr_ident` | bigint | FK → `nutzer` |
| `patient_ident` | bigint | FK → `patient` |
| `archiveconfirmationdate` | timestamp |  |
| `failedattemptnumber` | integer |  |
| `lastarchiveattemptdate` | timestamp |  |

## 19. Aufgaben & Todos

### aufgabe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `bis` | timestamp |  |
| `erstelltam` | timestamp |  |
| `priority` | integer |  |
| `removed` | boolean | NOT NULL |
| `text` | text |  |
| `von` | timestamp |  |
| `ersteller_ident` | bigint | FK → `nutzer` |
| `patient_ident` | bigint | FK → `patient` |
| `erdedigungstyp` | integer | 0 oder null = von einem, 1 = von allen |
| `archivedinkartei` | boolean |  |
| `aufgabentitle` | text |  |
| `blueprint_ident` | bigint | FK → `outlineviewelement` |
| `dontrepeat` | boolean |  |
| `wiederholungsoption_ident` | bigint | FK → `aufgabenwiederholung` |
| `ticketnumber` | text |  |
| `criticaltimespanindays` | integer | NOT NULL |
| `referenznummer` | text |  |
| `status` | integer |  |
| `laststatuschange` | timestamp |  |
| `availability` | integer |  |
| `nextrepeatingaufgabe_ident` | bigint | FK → `aufgabe` |

### aufgabenempfaenger
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `laststatuschange` | timestamp |  |
| `status` | integer |  |
| `nutzer_ident` | bigint | FK → `nutzer` |

### aufgabenlabel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `color` | text |  |
| `label` | text |  |
| `visible` | boolean | NOT NULL |

### todo
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `anfang` | timestamp |  |
| `ende` | timestamp |  |
| `infotext` | text |  |
| `listenposition` | integer | NOT NULL |
| `listenpositionraum` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `raum_ident` | bigint | FK → `raum` |
| `todovorlage_ident` | bigint | FK → `todovorlage` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `stundensatzrelevant` | boolean |  |

### todokette
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `removed` | boolean | NOT NULL |

### todoketteneintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `listenposition` | integer | NOT NULL |
| `removed` | boolean | NOT NULL |
| `todovorlage_ident` | bigint | FK → `todovorlage` |

### todovorlage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `zeigtanfang` | boolean | NOT NULL |
| `zeigtende` | boolean | NOT NULL |
| `zeigtinfo1` | boolean | NOT NULL |
| `kritischnachsekunden` | integer |  |
| `warnungnachsekunden` | integer |  |
| `darfnichtabgearbsetzen_ident` | bigint | FK → `nutzergruppe` |
| `darfnichtaktuellsetzen_ident` | bigint | FK → `nutzergruppe` |
| `colorabgearbeitet` | text |  |
| `colorcurrent` | text |  |
| `coloranstehendakut` | text |  |
| `coloranstehendpersp` | text |  |
| `grouptodo` | boolean |  |
| `stundensatzrelevant` | boolean |  |
| `usertooltip` | text |  |

## 20. Nachrichten

### nachricht
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `alertdate` | timestamp |  |
| `erstellt` | timestamp |  |
| `iserinnerung` | boolean | NOT NULL |
| `listenposition` | integer | NOT NULL |
| `removed` | boolean | NOT NULL. !!! als removed markierte Nachrichten duerfen/koennen nicht einfach geloescht werden. es kann Karteineintraege geben, die auf die Nachricht (via thread) verweisen |
| `text` | text |  |
| `verfaelltam` | timestamp |  |
| `wichtig` | boolean | NOT NULL |
| `patient_ident` | bigint | FK → `patient` |
| `sender_ident` | bigint | FK → `nutzer` |
| `archiviertinkartei` | boolean |  |
| `absenderarbeitsplatz` | text | #3574 |
| `generatedcompletely` | boolean | wird als letztes gesetzt, damit der client weiss, zu welchem Thread die Nachricht gehoert |
| `servernachrichttyp_ident` | bigint | FK → `servernachrichttyp` |
| `servernachrichttypcontext` | text | um Servernachrichten gleichen Typs für unterschiedliche Objekte unterscheiden zu können (z.B. 2 kaputte Emailaccounts) |
| `geloeschtforsender` | boolean | rf. TOM-18060 |

### nachrichtempfaenger
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `nachrichtgelesenam` | timestamp |  |
| `nachrichtgeloeschtam` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `arbeitsplatz_ident` | bigint | FK → `arbeitsplatz` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `gelesenvon_ident` | bigint | FK → `nutzer` |
| `snoozeduntil` | timestamp |  |

### nachrichtthread
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `removed` | boolean | NOT NULL. !!! als removed markierte Threads duerfen/koennen nicht einfach geloescht werden. es kann Karteineintraege geben, die auf den Thread verweisen |

### smsnachricht
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `absender` | text |  |
| `rezipient` | text |  |
| `serverresponse` | text |  |
| `tarif` | integer | NOT NULL |
| `test` | integer | NOT NULL |
| `text` | text |  |
| `timestamp` | timestamp |  |
| `patient_ident` | bigint | FK → `patient` |
| `smsvorlage_ident` | bigint | FK → `smsvorlage` |
| `smscount` | integer | NOT NULL |
| `ersteller_ident` | bigint | FK → `nutzer` |
| `smsaccount_ident` | bigint | FK (intern) |

### smsvorlage
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `absender` | text |  |
| `creationdate` | timestamp |  |
| `deletiondate` | timestamp |  |
| `name` | text |  |
| `textvorlage` | text |  |
| `visible` | boolean | NOT NULL |
| `createkarteieintrag` | boolean | NOT NULL |
| `karteieintragtyp_ident` | bigint | FK → `karteieintragtyp` |
| `createkarteieintragnurwennsuccessfullyversandt` | boolean | NOT NULL |
| `zsident` | integer |  |

## 21. Warteschlange

### patientenschlange
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `removed` | boolean | NOT NULL |
| `dtype` | varchar | NOT NULL |
| `identifier` | text |  |
| `todokette_ident` | bigint | FK → `todokette` |
| `createbesuch` | boolean |  |
| `karteieintragtypana_ident` | bigint | FK → `karteieintragtyp` |
| `karteieintragtypinfo_ident` | bigint | FK → `karteieintragtyp` |
| `karteieintragtyprech_ident` | bigint | FK → `karteieintragtyp` |
| `karteieintragtypegk_ident` | bigint | FK → `karteieintragtyp` |
| `noduplicates` | boolean | NOT NULL |
| `aetitle` | text |  |
| `modality` | text |  |
| `characterset` | text |  |
| `hl7` | boolean |  |
| `firsttodoactive` | boolean |  |
| `arbeitsplatz_ident` | bigint | FK → `arbeitsplatz` |
| `regionprefill` | text |  |
| `regionselectiontyp` | text |  |
| `aetitlestation` | text |  |
| `currentmessage_ident` | bigint | FK → `pappwartezimmerstatusnachricht` |
| `instanceidentifier` | text |  |

### patientenschlangeelement
> hier kann man spaeter noch Relationen zu z.B Besuch oder Schein hinzufuegen

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `checked` | boolean | NOT NULL |
| `datum` | timestamp |  |
| `listenposition` | real |  |
| `removed` | boolean | NOT NULL |
| `patient_ident` | bigint | FK → `patient` |
| `infotext` | text |  |
| `karteieintrag_ident` | bigint | FK → `karteieintrag` |
| `pappwartezimmerelement_ident` | bigint | FK → `pappwartezimmerelement` |
| `besuch_ident` | bigint | FK → `besuch` |
| `dicomorder_ident` | bigint | FK → `dicomorder` |
| `handoffelement_ident` | bigint | FK → `handoffelement` |

### warteschlange
> kann von TerminArt-Objekten verlinkt werden

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kuerzel` | text |  |
| `name` | text |  |
| `startnummer` | integer | NOT NULL |
| `laufendenummer` | integer | NOT NULL |
| `prefix` | text |  |
| `timestampletzteausgegebenenummer` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `resetatmidnight` | boolean | NOT NULL |
| `buttontext` | text |  |
| `fixedestimatedwartezeitperentry` | integer | NOT NULL |
| `timefordailyreset` | timestamp |  |
| `timestampletztereset` | timestamp |  |
| `showestimatedwartezeit` | integer | NOT NULL. 0 = no; 1 = fixed value; 2 = todo's warning; 3 = todo's critical; 4 = average actual |
| `todokuerzelfuerwartezeit` | text |  |
| `todokuerzelzumvergeben` | text |  |

### warteschlangeneintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `ausgegebenenummer` | text |  |
| `kioskemail` | text |  |
| `kioskfax` | text |  |
| `kioskgeburtstag` | text |  |
| `kioskgrund` | text |  |
| `kioskhandy` | text |  |
| `kioskland` | text |  |
| `kiosknachname` | text |  |
| `kioskort` | text |  |
| `kioskplz` | text |  |
| `kioskstrasse` | text |  |
| `kiosktel` | text |  |
| `kioskteldienstlich` | text |  |
| `kioskvorname` | text |  |
| `letzteraufruf` | text |  |
| `timestampletzteraufruf` | timestamp |  |
| `timestampnummernausgabe` | timestamp |  |
| `patient_ident` | bigint | FK → `patient` |
| `gehoertzuwarteschlange_ident` | bigint | FK → `warteschlange` |
| `removed` | boolean | NOT NULL |
| `kioskerror` | text |  |
| `usercheckbox1` | boolean | NOT NULL |
| `usercheckbox2` | boolean | NOT NULL |

## 22. Zahnmedizin

### bemakatalogeintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `code` | text |  |
| `farbe` | text |  |
| `gueltigbis` | timestamp |  |
| `gueltigvon` | timestamp |  |
| `lastimport` | timestamp |  |
| `temporaer` | boolean | NOT NULL |
| `kapitel` | smallint |  |
| `dentalkatalogdetails_ident` | bigint | FK → `dentalkatalogdetails` |
| `kuerzel` | text |  |
| `hideinabrechnung` | boolean |  |
| `hideinplanung` | boolean |  |

### kzvabrechnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `einreichungsziffer` | integer |  |
| `jahr` | integer |  |
| `monat` | integer |  |
| `quartal` | integer |  |
| `removed` | boolean | NOT NULL |
| `type` | smallint |  |
| `versandt` | boolean | NOT NULL |
| `abrcrypt_ident` | bigint | FK → `datei` |
| `abrechnungsdaten_ident` | bigint | FK → `datei` |
| `dta_ident` | bigint | FK → `datei` |
| `fallzahlprotokoll_ident` | bigint | FK → `datei` |
| `fehlerprotokoll_ident` | bigint | FK → `datei` |
| `idx_ident` | bigint | FK → `datei` |
| `leistungsspiegel_ident` | bigint | FK → `datei` |
| `uploadfile_ident` | bigint | FK → `datei` |
| `anzahlscheineabgerechnet` | integer |  |
| `rev` | integer |  |
| `replaced` | boolean |  |
| `kzvabrechnungsnummer` | text |  |

### kzvschein
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `abgerechnet` | boolean | NOT NULL |
| `hasleistung` | boolean | NOT NULL |
| `visible` | boolean | NOT NULL |
| `freitext` | text |  |
| `ignoriertfuerabrechnung` | boolean | NOT NULL |
| `jahr` | integer | NOT NULL |
| `monat` | integer | NOT NULL |
| `quartal` | integer | NOT NULL |
| `sortierdatum` | timestamp |  |
| `typ` | smallint |  |
| `abrechnendebetriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `kartendaten_ident` | bigint | FK → `kartendaten` |
| `kartenlesedatum_ident` | bigint | FK → `kartenlesedatum` |
| `abgeleiteterkostentraeger_ident` | bigint | FK → `krankenkasse` |
| `kzvvalidierung_ident` | bigint | FK → `kzvvalidierung` |
| `befund_ident` | bigint | FK → `zahnarztbefund` |
| `scheindetails_ident` | bigint | FK → `kzvscheindetails` |
| `abgeleiteterkostentraegerkzbv_ident` | bigint | FK → `krankenkasse` |
| `datumletzteabrechnung` | timestamp |  |
| `plan_ident` | bigint | FK → `zahnarztbefund` |
| `planung` | boolean |  |
| `privatfall` | boolean |  |
| `planungsschein_ident` | bigint | FK → `kzvschein` |
| `imported` | boolean |  |
| `bgunfall_ident` | bigint | FK → `bgunfall` |
| `gueltigkeitseinschraenkungbis` | timestamp |  |
| `gueltigkeitseinschraenkungvon` | timestamp |  |
| `planungverworfen` | boolean |  |
| `steigerungsschema_ident` | bigint | FK → `steigerungsschema` |
| `dokumentierendernutzer_ident` | bigint | FK → `nutzer` |

### zahn
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `hyperdont` | boolean |  |
| `identifier` | text |  |
| `notiz` | text |  |
| `befundstatus` | smallint |  |
| `changedate` | timestamp |  |
| `createdate` | timestamp |  |
| `pardetails_ident` | bigint | FK → `pardetails` |
| `blutungsbi` | boolean |  |
| `plaque` | boolean |  |
| `json` | text |  |

### zahnarztbefund
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `date` | timestamp |  |
| `visible` | boolean | NOT NULL |
| `fortlaufnr` | integer |  |
| `tag` | text |  |
| `vorbefund_ident` | bigint | FK → `zahnarztbefund` |
| `bitmap` | text |  |
| `mundkrankheit` | boolean |  |
| `zahnstein` | boolean |  |
| `dentalage` | integer |  |
| `imported` | boolean |  |
| `json` | text |  |
| `notiz` | text |  |

### zahnarztbefund01
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK. FK → `zahnarztbefund` |

### zahnarztbefundpa
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK. FK → `zahnarztbefund` |
| `knochenabbaupercentage` | real |  |
| `knochenabbauspecifics` | smallint |  |
| `komplexerehabilitationneeded` | boolean |  |
| `molareninzisivenmuster` | boolean |  |
| `anamnese` | text |  |
| `anderezustaendeparodont` | boolean |  |
| `diabetes` | smallint |  |
| `jahrvorigetherapie` | timestamp |  |
| `kennzeichensystemischererkrankungenpresent` | boolean |  |
| `parodontitisdiagnosed` | boolean |  |
| `rauchen` | smallint |  |
| `systemischeerkrankungen` | text |  |

### zahnarztbefundpsi
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `sext1` | smallint |  |
| `sext2` | smallint |  |
| `sext3` | smallint |  |
| `sext4` | smallint |  |
| `sext5` | smallint |  |
| `sext6` | smallint |  |
| `ident` | bigint | PK. FK → `zahnarztbefund` |

### zahnarztbefundsbi
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK. FK → `zahnarztbefund` |

### zahnarztfalldetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK. FK → `behandlungsfalldetails` |

### zahnbefundobjectdetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `einzelbefund_ident` | bigint | FK → `einzelbefund` |
| `material` | smallint |  |
| `notiz` | text |  |
| `zervikal` | boolean |  |
| `fehlstellung` | smallint |  |
| `lockerung` | smallint |  |
| `luecke` | integer |  |
| `vitalitaet` | smallint |  |
| `fehltaufgrundvonparodontitis` | boolean |  |
| `wurzelanzahl` | smallint |  |
| `zahnimplantatdetails_ident` | bigint | FK → `zahnimplantatdetails` |
| `fremd` | boolean |  |
| `blend` | smallint |  |
| `suff` | boolean |  |
| `roentgen` | boolean |  |
| `changedate` | timestamp |  |
| `datumderfuellungslegung` | timestamp |  |
| `fremdbefund` | boolean |  |
| `furkationsgrad` | smallint |  |
| `lage` | smallint |  |
| `material2` | smallint |  |
| `entzuendet` | boolean |  |
| `verfaerbungsart` | smallint |  |

### zahnbonushefteintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `luekenlosedokumentationseit` | timestamp |  |
| `removed` | boolean | NOT NULL |
| `untersuchungstyp` | smallint |  |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `institution_ident` | bigint | FK → `hausarzt` |
| `epauploaddatum` | timestamp |  |
| `epauploadstatus_ident` | bigint | FK → `epauploadstatus` |

### zahnimplantatdetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `chargennummer` | text |  |
| `datum` | timestamp |  |
| `durchmesser` | real |  |
| `laenge` | real |  |
| `typ` | text |  |
| `bezeichnung` | text |  |
| `hersteller` | text |  |

## 23. Warenwirtschaft

### ware
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `charge` | text | charge darf nicht null sein |
| `einkaufspreis` | integer |  |
| `verfallsdatum` | timestamp |  |
| `ausgegeben_ident` | bigint | FK → `warenlager` |
| `lager_ident` | bigint | FK → `warenlager` |
| `warendetails_ident` | bigint | FK → `warendetails` |
| `teilverbrauch` | integer |  |
| `secupharmcode` | text |  |
| `wwks2packid` | text |  |
| `reservervierenderpatient_ident` | bigint | FK → `patient` |

### warenbestellelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `einkaufspreis` | integer |  |
| `freitext` | text |  |
| `status` | integer | NOT NULL. 0: offen, 1: erhalten, 2:storniert, 3:retoure, 4: auf Lager |
| `visible` | boolean | NOT NULL |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `warenbuchung_ident` | bigint | FK → `warenbuchung` |
| `warendetails_ident` | bigint | FK → `warendetails` |
| `zusatzinformation` | text |  |
| `warenbestellelementdetails_ident` | bigint | FK → `warenbestellelementdetails` |
| `patient_ident` | bigint | FK → `patient` |

### warenbestellung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `beschreibung` | text |  |
| `datum` | timestamp |  |
| `freitext` | text |  |
| `status` | integer | NOT NULL. 0: offen, 1: erhalten, 2:storniert |
| `verkaeufer` | integer | NOT NULL. 0:keiner, 1: zur Rose, 2:Galexis |
| `visible` | boolean | NOT NULL |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `zusatzinformation` | text |  |
| `warenhaendler_ident` | bigint | FK → `warenhaendler` |
| `warenlager_ident` | bigint | FK → `warenlager` |
| `fuernutzer_ident` | bigint | FK → `nutzer` |

### warenbuchung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `letzteaenderung` | timestamp |  |
| `status` | integer | NOT NULL. 0: offen, 1: ausgegeben, 2: storniert, 3: eingebucht, 4: queued, 5: wartend, 6: umbuchung |
| `letzternutzer_ident` | bigint | FK → `nutzer` |
| `patient_ident` | bigint | FK → `patient` |
| `verordnendernutzer_ident` | bigint | FK → `nutzer` |
| `ware_ident` | bigint | FK → `ware` |
| `warendetails_ident` | bigint | FK → `warendetails` |
| `freitext` | text |  |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `leistung_ident` | bigint | FK → `leistung` |
| `warenlabel_ident` | bigint | FK → `warenlabel` |
| `teilmenge` | integer |  |
| `impfeintrag_ident` | bigint | FK → `karteieintrag` |
| `impfnotiz_ident` | bigint | FK → `karteieintrag` |
| `impfreservierung_ident` | bigint | FK → `karteieintrag` |
| `buchungsgrund` | text |  |
| `freigebendernutzer_ident` | bigint | FK → `nutzer` |
| `warendetailsrabatt_ident` | bigint | FK → `warendetailsrabatt` |

### warendetails
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `atc` | text |  |
| `beschreibung` | text |  |
| `ean` | text |  |
| `freitext` | text |  |
| `mwstinprozent` | real |  |
| `packagesize` | integer |  |
| `packageunit` | text |  |
| `substanzen` | text |  |
| `typ` | integer | NOT NULL |
| `verkaufspreis` | integer |  |
| `visible` | boolean | NOT NULL |
| `leistung_ident` | bigint | FK → `leistung` |
| `alternativekennung` | text |  |
| `defaultpackageunit` | integer |  |
| `typenbitmask` | integer | NOT NULL. Maske die zb robotertauglich, migel usw enthaelt |
| `labellist` | text |  |
| `tarifcode` | text |  |

### warenhaendler
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `name` | text |  |
| `nutzername` | text |  |
| `typ` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |
| `kontaktdaten_ident` | bigint | FK → `kontaktdaten` |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `freitext` | text |  |
| `kundennummer` | text |  |
| `nutzer_ident` | bigint | FK → `nutzer` |
| `customhaendlertyp_ident` | bigint | FK → `customhaendlertyp` |
| `vorlageeinkaufsliste_ident` | bigint | FK → `briefvorlage` |
| `emailaccountbestellung_ident` | bigint | FK → `emailaccount` |

### warenlabel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `dosierungabend` | text |  |
| `dosierungfrueh` | text |  |
| `dosierungmittag` | text |  |
| `dosierungnacht` | text |  |
| `freitext` | text |  |
| `reichtbis` | timestamp |  |
| `templateid` | text |  |
| `verordnungab` | timestamp |  |

### warenlager
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `kurzname` | text |  |
| `name` | text |  |
| `typ` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |
| `betriebsstaette_ident` | bigint | FK → `betriebsstaette` |
| `url` | text |  |
| `status` | integer |  |
| `statustext` | text |  |
| `color` | text |  |
| `hersteller` | integer |  |
| `roboterlagerkennung` | text |  |
| `server_ident` | bigint | FK (intern) |

### warenlieferung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `deliveryid` | text |  |
| `typ` | integer | NOT NULL |
| `datum` | timestamp |  |
| `warenhaendler_ident` | bigint | FK → `warenhaendler` |

## 24. Kassenbuch

### kassenbuch
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `datum` | timestamp |  |
| `laufendequittungsnummer` | integer | NOT NULL |
| `name` | text |  |
| `visible` | boolean | NOT NULL |
| `abgeschlossenaustria` | boolean | NOT NULL |
| `typ` | integer | NOT NULL. 0 oder nichts = normal. 1 = Registrierkasse Austria. 2 = Kasse nutzt TSE |
| `aesschluesselaustria` | text |  |
| `kassenidaustria` | text |  |
| `summenspeicheraustriaincent` | text |  |
| `zertifikatinformationaustria` | text |  |
| `zertifikatseriennummeraustria` | text |  |
| `color` | text |  |
| `isbar` | boolean |  |
| `privatrechnungkonto_ident` | bigint | FK → `privatrechnungkonto` |
| `belegvorlage_ident` | bigint | FK → `formulartyp` |
| `paymentmethodsuffix` | text | wird benutzt zur Bezeichnung der Zahlungsart in der Privatrechnung |
| `tseersid` | text |  |
| `tselogtimeformat` | text |  |
| `tsepublickey` | text |  |
| `tsesignaturalgorithmus` | text |  |
| `tseencoding` | text |  |
| `tseid` | bigint |  |
| `tseserial` | text |  |
| `tseserverident` | bigint |  |
| `tsezertifikat` | text |  |
| `tseport` | text |  |
| `owner_ident` | bigint | FK (intern) |

### kassenbucheintrag
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `betrag` | real | NOT NULL |
| `datum` | timestamp |  |
| `info` | text |  |
| `mehrwertsteuerinprozent` | real | NOT NULL |
| `quittungsnummer` | integer | NOT NULL |
| `visible` | boolean | NOT NULL |
| `aenderndernutzer_ident` | bigint | FK → `nutzer` |
| `dokumentierenedernutzer_ident` | bigint | FK → `nutzer` |
| `teilbetrag_ident` | bigint | FK → `teilbetrag` |
| `identprivatrechnung` | bigint |  |
| `typregaustria` | integer | NOT NULL. 0 = standard. 1 = start. 2 = null. 3 = storno. 4 = training. 5 = schluss |
| `depeintragaustria` | text |  |
| `readytosignaustria` | boolean | NOT NULL |
| `summebesondersaustriaincent` | bigint |  |
| `summeermaessigt1austriaincent` | bigint |  |
| `summeermaessigt2austriaincent` | bigint |  |
| `summenormalaustriaincent` | bigint |  |
| `summenullaustriaincent` | bigint |  |
| `storno_ident` | bigint | FK → `kassenbucheintrag` |
| `checked` | boolean | NOT NULL. geprueft/nicht geprueft |
| `patientenname` | text |  |
| `rechnungsnummer` | text |  |
| `tseprocessdata` | text |  |
| `tseprocesstype` | text |  |
| `tsesignaturzaehler` | integer |  |
| `tsetransactionendzeit` | text |  |
| `tsetransactionstartzeit` | text |  |
| `tsetransaktionsnummer` | integer |  |
| `tsesignatur` | text |  |
| `tsefehler` | text |  |
| `pspreference` | text |  |
| `transactionid` | text |  |

### kassenbuchung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `buchungsdatum` | timestamp |  |
| `valutadatum` | timestamp |  |
| `datei_ident` | bigint | FK → `datei` |
| `kassenbucheintrag_ident` | bigint | FK → `kassenbucheintrag` |
| `privatrechnung_ident` | bigint | FK → `privatrechnung` |
| `teilbetrag_ident` | bigint | FK → `teilbetrag` |
| `fehler` | text |  |
| `status` | integer | NOT NULL |
| `kassenbuchcandidate_ident` | bigint | FK → `kassenbuch` |
| `akte_ident` | bigint | FK → `patient` |
| `storniert` | boolean |  |
| `visible` | boolean | NOT NULL |

### kontoinhaber
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `firma` | boolean | NOT NULL |
| `name` | text |  |
| `vorname` | text | ⚠ Nicht im finalen SELECT |
| `adresse_ident` | bigint | FK → `adresse` |

## 25. Weitere Tabellen

- **abdadokument** — 10 Spalten, 1 FK-Beziehungen
- **abdaversion** — 6 Spalten, 1 FK-Beziehungen
- **agegroup** — 3 Spalten, 0 FK-Beziehungen
- **aktenkreis** — 6 Spalten, 0 FK-Beziehungen
- **aktenzeichen** — 6 Spalten, 0 FK-Beziehungen
- **allergiezusatzinfo** — 10 Spalten, 0 FK-Beziehungen
- **alternatingsollzeit** — 7 Spalten, 0 FK-Beziehungen
- **alternativartikel** — 7 Spalten, 1 FK-Beziehungen
- **ambulantebehandlung** — 2 Spalten, 1 FK-Beziehungen
- **anaesthesiedoku** — 2 Spalten, 0 FK-Beziehungen
- **anaesthesieelement** — 4 Spalten, 0 FK-Beziehungen
- **anerkennungsbescheidp** — 5 Spalten, 0 FK-Beziehungen
- **anerkennungsbescheidpsychotherapie** — 18 Spalten, 3 FK-Beziehungen
- **anwaltskammer** — 4 Spalten, 1 FK-Beziehungen
- **apinachricht** — 2 Spalten, 1 FK-Beziehungen
- **apinachrichtinhalt** — 14 Spalten, 6 FK-Beziehungen
- **apinachrichtrechtanfrageeintrag** — 3 Spalten, 0 FK-Beziehungen
- **apinachrichtstub** — 8 Spalten, 2 FK-Beziehungen
- **apinachrichtteilnehmer** — 7 Spalten, 5 FK-Beziehungen
- **apinachrichtthread** — 14 Spalten, 2 FK-Beziehungen
- **arbeitszeitkonto** — 4 Spalten, 1 FK-Beziehungen
- **arbeitszeitkontoeinstellung** — 35 Spalten, 0 FK-Beziehungen
- **arbeitszeitkontoupdateinfo** — 3 Spalten, 0 FK-Beziehungen
- **arbmedkatalogeintrag** — 15 Spalten, 1 FK-Beziehungen
- **arbmedu** — 23 Spalten, 9 FK-Beziehungen
- **arminmedikamentenplan** — 29 Spalten, 1 FK-Beziehungen
- **arminmedikamentenplanelement** — 30 Spalten, 1 FK-Beziehungen
- **artbriefeav_ersatzwert** — 3 Spalten, 0 FK-Beziehungen
- **arvereinbarung** — 11 Spalten, 0 FK-Beziehungen
- **arvhistorie** — 9 Spalten, 0 FK-Beziehungen
- **arvregel** — 7 Spalten, 0 FK-Beziehungen
- **arvregeltyp** — 6 Spalten, 1 FK-Beziehungen
- **arvteilverordnung** — 2 Spalten, 1 FK-Beziehungen
- **arvverordnungsgruppe** — 2 Spalten, 1 FK-Beziehungen
- **arvverordnungsgruppengrouper** — 1 Spalten, 0 FK-Beziehungen
- **arzneimittelkomponente** — 12 Spalten, 3 FK-Beziehungen
- **arzneimittelkomponenteidenta** — 10 Spalten, 0 FK-Beziehungen
- **arztdirektchat** — 3 Spalten, 1 FK-Beziehungen
- **arztdirektpayzahlung** — 22 Spalten, 5 FK-Beziehungen
- **asrautokorrekturelement** — 21 Spalten, 2 FK-Beziehungen
- **assortedconditions** — 8 Spalten, 0 FK-Beziehungen
- **asvarztgruppe** — 6 Spalten, 0 FK-Beziehungen
- **asvindikation** — 4 Spalten, 1 FK-Beziehungen
- **asvindikationrelationen** — 1 Spalten, 0 FK-Beziehungen
- **asvleistung** — 8 Spalten, 3 FK-Beziehungen
- **asvteammitglied** — 5 Spalten, 2 FK-Beziehungen
- **asvteamnummer** — 7 Spalten, 2 FK-Beziehungen
- **atcacode** — 3 Spalten, 0 FK-Beziehungen
- **atdmpteilnahme** — 19 Spalten, 2 FK-Beziehungen
- **atedokumentationsblatt** — 6 Spalten, 3 FK-Beziehungen
- **atedokuparameter** — 3 Spalten, 0 FK-Beziehungen
- **atkontaktdiagnosedetails** — 5 Spalten, 1 FK-Beziehungen
- **atkontaktleistungdetails** — 5 Spalten, 1 FK-Beziehungen
- **atlangzeitbewilligung** — 11 Spalten, 3 FK-Beziehungen
- **atrechnung** — 5 Spalten, 1 FK-Beziehungen
- **atrezept** — 11 Spalten, 1 FK-Beziehungen
- **aufgabedetailssubvieweinstellung** — 6 Spalten, 0 FK-Beziehungen
- **aufgabefinishcondition** — 4 Spalten, 1 FK-Beziehungen
- **aufgabenwiederholung** — 5 Spalten, 0 FK-Beziehungen
- **aufgabeworklist** — 2 Spalten, 0 FK-Beziehungen
- **aufgabeworklistelement** — 3 Spalten, 1 FK-Beziehungen
- **augendruckmesstyp** — 6 Spalten, 0 FK-Beziehungen
- **avatar** — 6 Spalten, 1 FK-Beziehungen
- **awsstdoku** — 21 Spalten, 1 FK-Beziehungen
- **bdocdetails** — 5 Spalten, 1 FK-Beziehungen
- **bdocdiagnosenwrapper** — 4 Spalten, 0 FK-Beziehungen
- **bdocerkrankung** — 7 Spalten, 1 FK-Beziehungen
- **bdocerkrankungcommondetails** — 2 Spalten, 0 FK-Beziehungen
- **bdocleistungsbogen** — 12 Spalten, 4 FK-Beziehungen
- **bdocleistungsparameter** — 3 Spalten, 0 FK-Beziehungen
- **bdocmaterial** — 5 Spalten, 1 FK-Beziehungen
- **bdocmedication** — 5 Spalten, 0 FK-Beziehungen
- **bdocrechnungsleger** — 7 Spalten, 1 FK-Beziehungen
- **beaaccount** — 12 Spalten, 2 FK-Beziehungen
- **beaanhang** — 8 Spalten, 1 FK-Beziehungen
- **beaidentity** — 21 Spalten, 1 FK-Beziehungen
- **beamessagejournal** — 5 Spalten, 1 FK-Beziehungen
- **beanachricht** — 39 Spalten, 7 FK-Beziehungen
- **beapostfach** — 5 Spalten, 1 FK-Beziehungen
- **bearbeiterstundensatzwrapper** — 6 Spalten, 1 FK-Beziehungen
- **bearecht** — 6 Spalten, 2 FK-Beziehungen
- **beasendungsprioritaet** — 3 Spalten, 0 FK-Beziehungen
- **befundgruppe** — 18 Spalten, 2 FK-Beziehungen
- **behandlungsfall** — 9 Spalten, 0 FK-Beziehungen
- **behandlungsfalldetails** — 11 Spalten, 1 FK-Beziehungen
- **behandlungsfallelement** — 21 Spalten, 12 FK-Beziehungen
- **belegaerztlichebehandlung** — 3 Spalten, 0 FK-Beziehungen
- **belegpositionen** — 6 Spalten, 0 FK-Beziehungen
- **bemakatalogeintragdetails** — 8 Spalten, 1 FK-Beziehungen
- **bemakatalogkapitel** — 4 Spalten, 0 FK-Beziehungen
- **benefitassessmentgba** — 14 Spalten, 0 FK-Beziehungen
- **benefitassessmentgbapatgroup** — 8 Spalten, 1 FK-Beziehungen
- **berufsgenossenschaft** — 10 Spalten, 1 FK-Beziehungen
- **betreuarztwrapper** — 5 Spalten, 1 FK-Beziehungen
- **bett** — 9 Spalten, 0 FK-Beziehungen
- **bettenstation** — 3 Spalten, 0 FK-Beziehungen
- **bewilligteleistung** — 8 Spalten, 1 FK-Beziehungen
- **bewleistungenp** — 7 Spalten, 1 FK-Beziehungen
- **bezugsartikel** — 5 Spalten, 2 FK-Beziehungen
- **bgberichtfeld** — 13 Spalten, 2 FK-Beziehungen
- **bgberichtfeldwertebereich** — 5 Spalten, 0 FK-Beziehungen
- **bgberichtsegment** — 8 Spalten, 0 FK-Beziehungen
- **bgformular** — 76 Spalten, 4 FK-Beziehungen
- **bgscheindetails** — 25 Spalten, 1 FK-Beziehungen
- **bgtarif** — 3 Spalten, 0 FK-Beziehungen
- **bgunfall** — 13 Spalten, 2 FK-Beziehungen
- **blankoampelphase** — 4 Spalten, 0 FK-Beziehungen
- **bmp_artikelkomponente** — 12 Spalten, 3 FK-Beziehungen
- **bmp_artikelkomponente_einnahmehinweise** — 2 Spalten, 2 FK-Beziehungen
- **bmp_dosiereinheit** — 5 Spalten, 0 FK-Beziehungen
- **bmp_einnahmehinweis** — 4 Spalten, 0 FK-Beziehungen
- **bmp_einnahmehinweisgrouper** — 1 Spalten, 0 FK-Beziehungen
- **bmp_einnahmehinweisgrouper_einnahmehinweise** — 2 Spalten, 2 FK-Beziehungen
- **bmp_wirkstoff** — 4 Spalten, 0 FK-Beziehungen
- **cdcharge** — 16 Spalten, 7 FK-Beziehungen
- **cdgeraet** — 25 Spalten, 1 FK-Beziehungen
- **cdprotokoll** — 17 Spalten, 1 FK-Beziehungen
- **cdprotokollanhang** — 3 Spalten, 1 FK-Beziehungen
- **cdsterilpackung** — 10 Spalten, 2 FK-Beziehungen
- **cegedimexport** — 10 Spalten, 0 FK-Beziehungen
- **chextendedxmldata** — 5 Spalten, 2 FK-Beziehungen
- **chkatalogdetails** — 3 Spalten, 0 FK-Beziehungen
- **chopcode** — 10 Spalten, 5 FK-Beziehungen
- **chopkatalogeintrag** — 10 Spalten, 0 FK-Beziehungen
- **chrechnung** — 13 Spalten, 1 FK-Beziehungen
- **clipleitsubstanz** — 2 Spalten, 0 FK-Beziehungen
- **clipmetoo** — 5 Spalten, 1 FK-Beziehungen
- **cockpitgeteiltediagramme** — 7 Spalten, 2 FK-Beziehungen
- **cockpitnutzereinstellung** — 5 Spalten, 1 FK-Beziehungen
- **customdatenfeld** — 10 Spalten, 0 FK-Beziehungen
- **customerspecificcondition** — 5 Spalten, 1 FK-Beziehungen
- **customhaendlertyp** — 3 Spalten, 0 FK-Beziehungen
- **customheilmittelkatalog** — 3 Spalten, 0 FK-Beziehungen
- **customstatistikelement** — 19 Spalten, 1 FK-Beziehungen
- **dameadresse** — 5 Spalten, 0 FK-Beziehungen
- **damenachricht** — 28 Spalten, 5 FK-Beziehungen
- **dateitranslation** — 4 Spalten, 2 FK-Beziehungen
- **datevexport** — 12 Spalten, 3 FK-Beziehungen
- **datevlogeintrag** — 8 Spalten, 0 FK-Beziehungen
- **delegierteleistungen** — 3 Spalten, 0 FK-Beziehungen
- **dentalkatalogdetails** — 8 Spalten, 0 FK-Beziehungen
- **derechnung** — 1 Spalten, 0 FK-Beziehungen
- **derezept** — 11 Spalten, 2 FK-Beziehungen
- **diagnosenwithplaintext** — 14 Spalten, 4 FK-Beziehungen
- **dicomorder** — 9 Spalten, 3 FK-Beziehungen
- **documentscanoutlineelement** — 8 Spalten, 3 FK-Beziehungen
- **drgabrechnung** — 24 Spalten, 10 FK-Beziehungen
- **drgabrechnungsfall** — 29 Spalten, 11 FK-Beziehungen
- **drgkatalogeintrag** — 6 Spalten, 0 FK-Beziehungen
- **drucker** — 30 Spalten, 1 FK-Beziehungen
- **druckerschlangeelement** — 6 Spalten, 4 FK-Beziehungen
- **druckversion** — 6 Spalten, 3 FK-Beziehungen
- **dvpabrechnung** — 18 Spalten, 6 FK-Beziehungen
- **dvpabrechnungsstelle** — 6 Spalten, 0 FK-Beziehungen
- **dvpabrechnungszeitraum** — 6 Spalten, 0 FK-Beziehungen
- **dvpbewilligung** — 4 Spalten, 0 FK-Beziehungen
- **dvpbundesland** — 3 Spalten, 0 FK-Beziehungen
- **dvpkatalogabschnitt** — 5 Spalten, 0 FK-Beziehungen
- **dvpkatalogeintrag** — 8 Spalten, 1 FK-Beziehungen
- **dvpkatalogeintragdetails** — 9 Spalten, 0 FK-Beziehungen
- **dvpkatalogfachgruppendetails** — 7 Spalten, 0 FK-Beziehungen
- **dvplandeu** — 8 Spalten, 0 FK-Beziehungen
- **dvpleistungbedingung** — 15 Spalten, 0 FK-Beziehungen
- **dvppauschalleistung** — 11 Spalten, 0 FK-Beziehungen
- **dvpschein** — 32 Spalten, 12 FK-Beziehungen
- **dvpscheinart** — 6 Spalten, 0 FK-Beziehungen
- **dvpscheingrund** — 7 Spalten, 0 FK-Beziehungen
- **dvptarif** — 8 Spalten, 0 FK-Beziehungen
- **dvptherapiecode** — 6 Spalten, 0 FK-Beziehungen
- **dvpversichertenkategorie** — 6 Spalten, 0 FK-Beziehungen
- **dvpvertrag** — 10 Spalten, 1 FK-Beziehungen
- **dvpvertragsrelationen** — 1 Spalten, 0 FK-Beziehungen
- **dvpzusatzangabekeze** — 6 Spalten, 0 FK-Beziehungen
- **dvpzusatzangabezuskz** — 6 Spalten, 0 FK-Beziehungen
- **ebmaltersbedingung** — 9 Spalten, 0 FK-Beziehungen
- **ebmanzahlbedingung** — 10 Spalten, 0 FK-Beziehungen
- **ebmausschlussregel** — 10 Spalten, 0 FK-Beziehungen
- **ebmbegruendungbedingung** — 7 Spalten, 0 FK-Beziehungen
- **ebmfachgruppenbedingung** — 7 Spalten, 0 FK-Beziehungen
- **ebmgenderbedingung** — 6 Spalten, 0 FK-Beziehungen
- **ebmgrundleistungbedingung** — 7 Spalten, 0 FK-Beziehungen
- **ebmscheingruppebedingung** — 6 Spalten, 0 FK-Beziehungen
- **ebmzusatzangabenbedingung** — 6 Spalten, 0 FK-Beziehungen
- **ebzmitteilung** — 5 Spalten, 0 FK-Beziehungen
- **edakennziffer** — 5 Spalten, 1 FK-Beziehungen
- **edifactlabormapping** — 3 Spalten, 0 FK-Beziehungen
- **edokuabrechnung** — 25 Spalten, 6 FK-Beziehungen
- **edokumentation** — 119 Spalten, 25 FK-Beziehungen
- **eformular** — 48 Spalten, 4 FK-Beziehungen
- **eigenrezeptur** — 6 Spalten, 0 FK-Beziehungen
- **ekonsil** — 10 Spalten, 3 FK-Beziehungen
- **ekonsilanhang** — 6 Spalten, 1 FK-Beziehungen
- **ekvkformular** — 12 Spalten, 1 FK-Beziehungen
- **elektronischeau** — 15 Spalten, 1 FK-Beziehungen
- **elgagda** — 11 Spalten, 0 FK-Beziehungen
- **elgaimpfdaten** — 9 Spalten, 0 FK-Beziehungen
- **elgavalueset** — 6 Spalten, 0 FK-Beziehungen
- **email** — 36 Spalten, 14 FK-Beziehungen
- **emailaccount** — 45 Spalten, 6 FK-Beziehungen
- **emailaccountsyncstatus** — 8 Spalten, 1 FK-Beziehungen
- **emailempfaengerelement** — 7 Spalten, 2 FK-Beziehungen
- **emailempfaengerliste** — 3 Spalten, 0 FK-Beziehungen
- **emailheader** — 3 Spalten, 0 FK-Beziehungen
- **emailsignatur** — 5 Spalten, 1 FK-Beziehungen
- **emailstump** — 5 Spalten, 1 FK-Beziehungen
- **emailvorlage** — 11 Spalten, 3 FK-Beziehungen
- **epadaten** — 4 Spalten, 0 FK-Beziehungen
- **epadatenschutzangaben** — 6 Spalten, 0 FK-Beziehungen
- **epametadatavorlage** — 3 Spalten, 0 FK-Beziehungen
- **epaprotokoll** — 7 Spalten, 1 FK-Beziehungen
- **epauploadstatus** — 6 Spalten, 1 FK-Beziehungen
- **epauploadvorlage** — 5 Spalten, 0 FK-Beziehungen
- **ersatzwarendetails** — 5 Spalten, 1 FK-Beziehungen
- **externesticket** — 4 Spalten, 0 FK-Beziehungen
- **favoritlabortest** — 20 Spalten, 1 FK-Beziehungen
- **favoritlabortestintervall** — 10 Spalten, 0 FK-Beziehungen
- **febenachrichtigungskanal** — 11 Spalten, 7 FK-Beziehungen
- **feerinnerunggruppe** — 7 Spalten, 0 FK-Beziehungen
- **feerinnerungkanalstatus** — 8 Spalten, 1 FK-Beziehungen
- **feerinnerungpatienteninformation** — 13 Spalten, 1 FK-Beziehungen
- **fekelemente** — 3 Spalten, 0 FK-Beziehungen
- **feksnapshotevent** — 5 Spalten, 1 FK-Beziehungen
- **fekstatussnapshot** — 13 Spalten, 1 FK-Beziehungen
- **femanualerinnerung** — 10 Spalten, 2 FK-Beziehungen
- **ferstatussnapshot** — 12 Spalten, 1 FK-Beziehungen
- **fileimportsetting** — 15 Spalten, 1 FK-Beziehungen
- **fokomassnahme** — 11 Spalten, 1 FK-Beziehungen
- **fokoverrechnung** — 4 Spalten, 0 FK-Beziehungen
- **folderspecificemailinfo** — 5 Spalten, 1 FK-Beziehungen
- **formulartypliste** — 3 Spalten, 0 FK-Beziehungen
- **fremdgeldverrechnung** — 4 Spalten, 0 FK-Beziehungen
- **fusformular** — 12 Spalten, 2 FK-Beziehungen
- **fusformularanhang** — 3 Spalten, 1 FK-Beziehungen
- **gdtexportsetting** — 13 Spalten, 0 FK-Beziehungen
- **gdtfield** — 11 Spalten, 0 FK-Beziehungen
- **gdtuntersuchungszuordnung** — 4 Spalten, 1 FK-Beziehungen
- **genehmigunglhmb** — 12 Spalten, 3 FK-Beziehungen
- **gravidogrammeintrag** — 36 Spalten, 1 FK-Beziehungen
- **gueltigkeit** — 3 Spalten, 0 FK-Beziehungen
- **guiaction** — 48 Spalten, 31 FK-Beziehungen
- **guiactioncondition** — 8 Spalten, 0 FK-Beziehungen
- **guiactionquestion** — 15 Spalten, 0 FK-Beziehungen
- **guiactionquestionentry** — 11 Spalten, 2 FK-Beziehungen
- **gynverlaufeinstellungen** — 3 Spalten, 0 FK-Beziehungen
- **handoffelement** — 8 Spalten, 1 FK-Beziehungen
- **hausapothekehistorie** — 5 Spalten, 1 FK-Beziehungen
- **hausapothekenelement** — 28 Spalten, 2 FK-Beziehungen
- **hcimappingpharmacode** — 8 Spalten, 0 FK-Beziehungen
- **hcimappingproduktnummer** — 6 Spalten, 0 FK-Beziehungen
- **heilmittelverordnungsvorlage** — 11 Spalten, 1 FK-Beziehungen
- **hgnccode** — 4 Spalten, 0 FK-Beziehungen
- **hgnckette** — 3 Spalten, 0 FK-Beziehungen
- **hilfsmittelort** — 3 Spalten, 0 FK-Beziehungen
- **hilfsmitteluntergruppe** — 6 Spalten, 2 FK-Beziehungen
- **hogrefepatientenanmeldedaten** — 3 Spalten, 0 FK-Beziehungen
- **homoeoabrechnung** — 6 Spalten, 0 FK-Beziehungen
- **homoeoleistung** — 5 Spalten, 0 FK-Beziehungen
- **homoeoschein** — 17 Spalten, 5 FK-Beziehungen
- **homoeoteilnahme** — 14 Spalten, 1 FK-Beziehungen
- **htmldocument** — 2 Spalten, 0 FK-Beziehungen
- **hzv9erdiagnose** — 2 Spalten, 0 FK-Beziehungen
- **hzv9erdiagnoseliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvabrechnung** — 27 Spalten, 7 FK-Beziehungen
- **hzvabrechnunggroup** — 3 Spalten, 1 FK-Beziehungen
- **hzvabrufcode** — 3 Spalten, 0 FK-Beziehungen
- **hzvakutdiagnose** — 4 Spalten, 1 FK-Beziehungen
- **hzvakutdiagnosez** — 2 Spalten, 1 FK-Beziehungen
- **hzvakutdiagnosezliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvaltersbedingung** — 9 Spalten, 1 FK-Beziehungen
- **hzvanzahlbedingung** — 8 Spalten, 1 FK-Beziehungen
- **hzvarribadaten** — 6 Spalten, 2 FK-Beziehungen
- **hzvarztfunktionenbedingung** — 6 Spalten, 1 FK-Beziehungen
- **hzvbedingunggenerell** — 1 Spalten, 0 FK-Beziehungen
- **hzvcachedteilnahmeinfo** — 10 Spalten, 1 FK-Beziehungen
- **hzvcustomheilmittelliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvdetails** — 30 Spalten, 10 FK-Beziehungen
- **hzvdiagnosebedingung** — 9 Spalten, 1 FK-Beziehungen
- **hzvdiagnosesubstitution** — 5 Spalten, 1 FK-Beziehungen
- **hzvdiagnosetyp** — 5 Spalten, 1 FK-Beziehungen
- **hzvdokument** — 6 Spalten, 0 FK-Beziehungen
- **hzvdokumentationsangabe** — 6 Spalten, 0 FK-Beziehungen
- **hzvdokumentenvorlage** — 5 Spalten, 0 FK-Beziehungen
- **hzveinschlussdiagnosewrapper** — 4 Spalten, 1 FK-Beziehungen
- **hzveinschreibediagnose** — 3 Spalten, 1 FK-Beziehungen
- **hzveinschreibediagnoseliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvfehlermeldung** — 3 Spalten, 0 FK-Beziehungen
- **hzvfolgeaudiagnose** — 2 Spalten, 1 FK-Beziehungen
- **hzvformular** — 8 Spalten, 1 FK-Beziehungen
- **hzvfunktionmitnebenbedingung** — 5 Spalten, 1 FK-Beziehungen
- **hzvgenderbedingung** — 6 Spalten, 1 FK-Beziehungen
- **hzvgueltigkeitkvbereich** — 4 Spalten, 1 FK-Beziehungen
- **hzvhauskometmedikamentenplan** — 29 Spalten, 4 FK-Beziehungen
- **hzvhauskometnotification** — 5 Spalten, 1 FK-Beziehungen
- **hzvhibdiagnose** — 8 Spalten, 1 FK-Beziehungen
- **hzvhonoraranlage** — 5 Spalten, 0 FK-Beziehungen
- **hzvikgruppe** — 5 Spalten, 1 FK-Beziehungen
- **hzvikrefmitdatum** — 5 Spalten, 0 FK-Beziehungen
- **hzvimportbericht** — 13 Spalten, 1 FK-Beziehungen
- **hzvimportkonflikt** — 6 Spalten, 1 FK-Beziehungen
- **hzvimportprotokoll** — 5 Spalten, 1 FK-Beziehungen
- **hzvitvedocument** — 10 Spalten, 4 FK-Beziehungen
- **hzvitvedocumentsendprotocol** — 3 Spalten, 0 FK-Beziehungen
- **hzvkatalogeintrag** — 9 Spalten, 1 FK-Beziehungen
- **hzvkatalogeintragdetails** — 10 Spalten, 1 FK-Beziehungen
- **hzvkodierhilfeaktion** — 3 Spalten, 0 FK-Beziehungen
- **hzvkodierhilfeaoksportsliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvkodierhilfedefinition** — 7 Spalten, 2 FK-Beziehungen
- **hzvkodierhilfeelement** — 3 Spalten, 0 FK-Beziehungen
- **hzvkodierhilfezliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvkostentraeger** — 16 Spalten, 3 FK-Beziehungen
- **hzvkrankheitsbild** — 5 Spalten, 0 FK-Beziehungen
- **hzvkrankheitsbildkontext** — 5 Spalten, 0 FK-Beziehungen
- **hzvmetainformation** — 9 Spalten, 1 FK-Beziehungen
- **hzvmorbiditaetsgruppe** — 3 Spalten, 0 FK-Beziehungen
- **hzvmorbirsadiagnose** — 13 Spalten, 3 FK-Beziehungen
- **hzvmorbirsadiagnosenliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvmorbirsakrankheit** — 3 Spalten, 0 FK-Beziehungen
- **hzvopseintrag** — 7 Spalten, 2 FK-Beziehungen
- **hzvopsliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvpatbegleitungdiagnose** — 3 Spalten, 1 FK-Beziehungen
- **hzvpatbegleitungdiagnoseliste** — 3 Spalten, 0 FK-Beziehungen
- **hzvpatientparticipant** — 28 Spalten, 2 FK-Beziehungen
- **hzvpraeventionsdiagnoseliste** — 2 Spalten, 0 FK-Beziehungen
- **hzvschein** — 26 Spalten, 8 FK-Beziehungen
- **hzvtagesbedingung** — 7 Spalten, 1 FK-Beziehungen
- **hzvteilnehmerverzeichnis** — 16 Spalten, 4 FK-Beziehungen
- **hzvtelescanaccount** — 9 Spalten, 1 FK-Beziehungen
- **hzvtransfercontent** — 7 Spalten, 1 FK-Beziehungen
- **hzvvertrag** — 17 Spalten, 2 FK-Beziehungen
- **hzvvertragsrelationen** — 11 Spalten, 10 FK-Beziehungen
- **hzvvorgangsvorlage** — 15 Spalten, 0 FK-Beziehungen
- **hzvziffernbedingung** — 9 Spalten, 1 FK-Beziehungen
- **hzvziffernkranz** — 6 Spalten, 1 FK-Beziehungen
- **hzvziffernkranzebmziffer** — 4 Spalten, 0 FK-Beziehungen
- **hzvzusammenstellung** — 7 Spalten, 1 FK-Beziehungen
- **hzvzusatzangabe** — 8 Spalten, 1 FK-Beziehungen
- **icd_kh_element** — 4 Spalten, 0 FK-Beziehungen
- **icd_kh_element_icds** — 2 Spalten, 2 FK-Beziehungen
- **icd_va_element** — 7 Spalten, 0 FK-Beziehungen
- **icd_va_element_icdkatalogeintraege** — 2 Spalten, 2 FK-Beziehungen
- **icd_va_element_unterelemente** — 2 Spalten, 2 FK-Beziehungen
- **icdautosubstitution** — 3 Spalten, 0 FK-Beziehungen
- **imapfolder** — 8 Spalten, 1 FK-Beziehungen
- **immkapitel** — 5 Spalten, 0 FK-Beziehungen
- **immkapitelverweis** — 4 Spalten, 1 FK-Beziehungen
- **immkategorie** — 5 Spalten, 1 FK-Beziehungen
- **immmetadaten** — 12 Spalten, 1 FK-Beziehungen
- **immwirkstoff** — 5 Spalten, 1 FK-Beziehungen
- **implantateregistertieintrag** — 4 Spalten, 0 FK-Beziehungen
- **implantatregistereintrag** — 7 Spalten, 1 FK-Beziehungen
- **inboxcounter** — 8 Spalten, 1 FK-Beziehungen
- **indikationsbereich** — 3 Spalten, 0 FK-Beziehungen
- **interaktionvolltext** — 4 Spalten, 0 FK-Beziehungen
- **irdanfrage** — 29 Spalten, 7 FK-Beziehungen
- **irdbogen** — 2 Spalten, 0 FK-Beziehungen
- **irdmeldung** — 6 Spalten, 0 FK-Beziehungen
- **irdmodul** — 3 Spalten, 0 FK-Beziehungen
- **irdparameter** — 3 Spalten, 0 FK-Beziehungen
- **karteieintragtext** — 4 Spalten, 1 FK-Beziehungen
- **karteieintragwithplaintext** — 15 Spalten, 8 FK-Beziehungen
- **kbeintragvorschlag** — 7 Spalten, 0 FK-Beziehungen
- **kbrscheindetails** — 11 Spalten, 1 FK-Beziehungen
- **kchscheindetails** — 3 Spalten, 0 FK-Beziehungen
- **kfoplandetails** — 23 Spalten, 0 FK-Beziehungen
- **kfoplankriterium** — 4 Spalten, 0 FK-Beziehungen
- **kfoscheindetails** — 14 Spalten, 1 FK-Beziehungen
- **kommentar** — 6 Spalten, 1 FK-Beziehungen
- **komponenteninhaltsstoff** — 9 Spalten, 1 FK-Beziehungen
- **komponenteninhaltsstoffsort** — 3 Spalten, 1 FK-Beziehungen
- **konfigurationspaket** — 8 Spalten, 1 FK-Beziehungen
- **konfigurationspaketentitaet** — 6 Spalten, 1 FK-Beziehungen
- **kontextidforvos** — 8 Spalten, 5 FK-Beziehungen
- **krankenhaus** — 4 Spalten, 1 FK-Beziehungen
- **krebserkrankung** — 7 Spalten, 1 FK-Beziehungen
- **krebsregisterbogen** — 2 Spalten, 0 FK-Beziehungen
- **krebsregistermodul** — 3 Spalten, 0 FK-Beziehungen
- **krebsregisterparameter** — 3 Spalten, 0 FK-Beziehungen
- **krwbedingung** — 5 Spalten, 0 FK-Beziehungen
- **krwfehlerbehandlung** — 5 Spalten, 1 FK-Beziehungen
- **krwkorrektur** — 4 Spalten, 1 FK-Beziehungen
- **krwregel** — 17 Spalten, 0 FK-Beziehungen
- **krwwert** — 2 Spalten, 0 FK-Beziehungen
- **kvspezifika** — 7 Spalten, 1 FK-Beziehungen
- **kvspezifikadatenpaket** — 8 Spalten, 1 FK-Beziehungen
- **kvspezifikaerlaubtesabrechnungsgebietfuerschein** — 3 Spalten, 2 FK-Beziehungen
- **kvspezifikaerlaubtewertefuerfeld4123** — 3 Spalten, 0 FK-Beziehungen
- **kvspezifikazusatzangabefuerfeld4124** — 3 Spalten, 0 FK-Beziehungen
- **kvspezifikazusatzangabensktbedingung** — 7 Spalten, 3 FK-Beziehungen
- **kzvpruefmodulvalueset** — 7 Spalten, 0 FK-Beziehungen
- **kzvscheinbemerkung** — 6 Spalten, 0 FK-Beziehungen
- **kzvscheindetails** — 15 Spalten, 1 FK-Beziehungen
- **kzvvalidierung** — 6 Spalten, 0 FK-Beziehungen
- **laborausnahmekennziffer** — 5 Spalten, 1 FK-Beziehungen
- **laborbefundvidierungbedingung** — 6 Spalten, 0 FK-Beziehungen
- **laborbefundvidierungkonfig** — 18 Spalten, 1 FK-Beziehungen
- **labordatenabruf** — 25 Spalten, 3 FK-Beziehungen
- **laborergebnistexteformat** — 9 Spalten, 0 FK-Beziehungen
- **laborgeraet** — 30 Spalten, 1 FK-Beziehungen
- **laborgeraetworklist** — 6 Spalten, 1 FK-Beziehungen
- **laborkarteieintragtypselection** — 6 Spalten, 1 FK-Beziehungen
- **laborperzentilenzuordnung** — 8 Spalten, 0 FK-Beziehungen
- **labvermesswertzelleentity** — 9 Spalten, 6 FK-Beziehungen
- **labverspalteentity** — 4 Spalten, 1 FK-Beziehungen
- **labverzeileentity** — 6 Spalten, 1 FK-Beziehungen
- **laufendenummer** — 8 Spalten, 1 FK-Beziehungen
- **lb820x** — 62 Spalten, 9 FK-Beziehungen
- **lb820xzusaetzlichwertehl7** — 7 Spalten, 0 FK-Beziehungen
- **lbantibiogramm** — 3 Spalten, 0 FK-Beziehungen
- **lbantibiogrammergebnis** — 7 Spalten, 0 FK-Beziehungen
- **lbdateiimport** — 19 Spalten, 5 FK-Beziehungen
- **lbgnr** — 13 Spalten, 2 FK-Beziehungen
- **lbgnrimport** — 8 Spalten, 3 FK-Beziehungen
- **lbgnrzuordnunganalogziffern** — 6 Spalten, 2 FK-Beziehungen
- **lbkeim** — 13 Spalten, 0 FK-Beziehungen
- **lblabortestjoin** — 6 Spalten, 0 FK-Beziehungen
- **lbtestelement** — 9 Spalten, 0 FK-Beziehungen
- **lbtestgruppe** — 10 Spalten, 0 FK-Beziehungen
- **lbtestlbanforderung** — 58 Spalten, 5 FK-Beziehungen
- **lbtestlbobjekttumor** — 11 Spalten, 0 FK-Beziehungen
- **lbtestlbtransmutterschaftsvor** — 11 Spalten, 0 FK-Beziehungen
- **lbwirkstoff** — 5 Spalten, 0 FK-Beziehungen
- **lbwirtschaftlichkeitsbonus** — 20 Spalten, 3 FK-Beziehungen
- **lbzytohpvbefund** — 6 Spalten, 0 FK-Beziehungen
- **ldtanhang** — 18 Spalten, 1 FK-Beziehungen
- **ldtbefundgruppe** — 5 Spalten, 0 FK-Beziehungen
- **ldtfehler** — 8 Spalten, 1 FK-Beziehungen
- **ldtfeldelement** — 8 Spalten, 0 FK-Beziehungen
- **ldtmaterial** — 13 Spalten, 0 FK-Beziehungen
- **ldtsatzarttabelle** — 3 Spalten, 0 FK-Beziehungen
- **leseaufforderung** — 10 Spalten, 3 FK-Beziehungen
- **linkarbeitsplatzprofil** — 4 Spalten, 2 FK-Beziehungen
- **linkclientexportknopf** — 4 Spalten, 0 FK-Beziehungen
- **linkclientexportknopfanfrage** — 9 Spalten, 3 FK-Beziehungen
- **listelement** — 5 Spalten, 0 FK-Beziehungen
- **llmchat** — 8 Spalten, 1 FK-Beziehungen
- **lokalerhauskometpflegearztwrapper** — 3 Spalten, 1 FK-Beziehungen
- **macro** — 13 Spalten, 0 FK-Beziehungen
- **macrolist** — 4 Spalten, 0 FK-Beziehungen
- **macrolistlinker** — 9 Spalten, 4 FK-Beziehungen
- **macrolistroot** — 6 Spalten, 1 FK-Beziehungen
- **macrotabelleneintrag** — 5 Spalten, 1 FK-Beziehungen
- **materialkatalogeintrag** — 14 Spalten, 0 FK-Beziehungen
- **medicosearchaccount** — 10 Spalten, 1 FK-Beziehungen
- **medicosearchcalendarassignment** — 5 Spalten, 2 FK-Beziehungen
- **medicosearchtreatmentassignment** — 5 Spalten, 1 FK-Beziehungen
- **medikamentarvgroup** — 1 Spalten, 0 FK-Beziehungen
- **medikamentinhaltsstoffvos** — 8 Spalten, 0 FK-Beziehungen
- **medikamentinteraktion** — 10 Spalten, 2 FK-Beziehungen
- **medikamentinteraktionenklasse** — 2 Spalten, 0 FK-Beziehungen
- **medikamentinteraktionobservation** — 3 Spalten, 0 FK-Beziehungen
- **medikdbcatalog** — 2 Spalten, 0 FK-Beziehungen
- **medpreishistorie** — 3 Spalten, 0 FK-Beziehungen
- **mehrfachverordnungseinstellung** — 4 Spalten, 0 FK-Beziehungen
- **mehrfachverordnungselement** — 7 Spalten, 1 FK-Beziehungen
- **metadatenelement** — 10 Spalten, 4 FK-Beziehungen
- **metadatenfilter** — 4 Spalten, 0 FK-Beziehungen
- **mioepaerbringer** — 8 Spalten, 2 FK-Beziehungen
- **mioepaexandimport** — 5 Spalten, 0 FK-Beziehungen
- **mlabrechnungsmodel** — 6 Spalten, 3 FK-Beziehungen
- **mutterpass** — 30 Spalten, 0 FK-Beziehungen
- **mutterpasschild** — 5 Spalten, 0 FK-Beziehungen
- **mutterpassctgeintrag** — 7 Spalten, 0 FK-Beziehungen
- **mutterpassdicomimport** — 6 Spalten, 0 FK-Beziehungen
- **mutterpassdicomimportfeld** — 4 Spalten, 0 FK-Beziehungen
- **mutterpassdopplereintrag** — 3 Spalten, 0 FK-Beziehungen
- **mutterpasselement** — 8 Spalten, 3 FK-Beziehungen
- **mutterpasslaborconfig** — 10 Spalten, 0 FK-Beziehungen
- **mutterpasslaborstatus** — 4 Spalten, 0 FK-Beziehungen
- **mutterpasslaborwert** — 15 Spalten, 3 FK-Beziehungen
- **mutterpasspreviouspregnancy** — 5 Spalten, 0 FK-Beziehungen
- **mutterpasstermin** — 5 Spalten, 0 FK-Beziehungen
- **mutterpassuseintrag** — 22 Spalten, 1 FK-Beziehungen
- **mutterpassuseintragelement** — 5 Spalten, 0 FK-Beziehungen
- **okfebogen** — 15 Spalten, 1 FK-Beziehungen
- **okfeparameter** — 3 Spalten, 0 FK-Beziehungen
- **omimgcode** — 6 Spalten, 0 FK-Beziehungen
- **omimpcode** — 7 Spalten, 0 FK-Beziehungen
- **onlinetermineaccount** — 9 Spalten, 0 FK-Beziehungen
- **opbestellung** — 21 Spalten, 3 FK-Beziehungen
- **opsbegruendung** — 4 Spalten, 1 FK-Beziehungen
- **opskatalogeintrag** — 12 Spalten, 0 FK-Beziehungen
- **orderentryeintrag** — 29 Spalten, 0 FK-Beziehungen
- **orgcav** — 6 Spalten, 1 FK-Beziehungen
- **orthomedoguielement** — 6 Spalten, 3 FK-Beziehungen
- **otkaccount** — 6 Spalten, 0 FK-Beziehungen
- **otkblocklist** — 8 Spalten, 0 FK-Beziehungen
- **otkblockpatient** — 5 Spalten, 1 FK-Beziehungen
- **otkevent** — 23 Spalten, 4 FK-Beziehungen
- **otkkassenbuchsynceintrag** — 3 Spalten, 2 FK-Beziehungen
- **otkwaitlistentry** — 10 Spalten, 2 FK-Beziehungen
- **outlineviewelement** — 108 Spalten, 32 FK-Beziehungen
- **packungnorm** — 4 Spalten, 0 FK-Beziehungen
- **padnextdienstleister** — 12 Spalten, 1 FK-Beziehungen
- **pappaccount** — 15 Spalten, 2 FK-Beziehungen
- **pappautonachrichtregel** — 5 Spalten, 0 FK-Beziehungen
- **pappautonachrichtvorlage** — 9 Spalten, 0 FK-Beziehungen
- **pappchat** — 12 Spalten, 5 FK-Beziehungen
- **pappcsmmessage** — 16 Spalten, 3 FK-Beziehungen
- **pappmessage** — 13 Spalten, 2 FK-Beziehungen
- **pappmessagejunk** — 1 Spalten, 0 FK-Beziehungen
- **pappnachrichtvorlage** — 12 Spalten, 0 FK-Beziehungen
- **pappnachrichtvorlagegruppe** — 5 Spalten, 0 FK-Beziehungen
- **papppairingrequest** — 28 Spalten, 2 FK-Beziehungen
- **pappsammelnachricht** — 6 Spalten, 1 FK-Beziehungen
- **pappsammelnachrichtenchat** — 3 Spalten, 0 FK-Beziehungen
- **pappwartezimmerelement** — 11 Spalten, 1 FK-Beziehungen
- **pappwartezimmerpatient** — 13 Spalten, 0 FK-Beziehungen
- **pappwartezimmerstatusnachricht** — 6 Spalten, 0 FK-Beziehungen
- **pardetails** — 9 Spalten, 0 FK-Beziehungen
- **parmesspunkt** — 7 Spalten, 0 FK-Beziehungen
- **parscheindetails** — 31 Spalten, 0 FK-Beziehungen
- **partialholiday** — 4 Spalten, 0 FK-Beziehungen
- **patientcandidate** — 15 Spalten, 0 FK-Beziehungen
- **patientdetailsinfoelement** — 4 Spalten, 0 FK-Beziehungen
- **patientendatentransfererlaubnis** — 5 Spalten, 1 FK-Beziehungen
- **patientenzugriffsrecht** — 5 Spalten, 2 FK-Beziehungen
- **patientenzugriffsrechtvorlage** — 6 Spalten, 2 FK-Beziehungen
- **patientverstoss** — 6 Spalten, 0 FK-Beziehungen
- **patteilnahmevertragsgruppe** — 2 Spalten, 0 FK-Beziehungen
- **preisintervall** — 7 Spalten, 0 FK-Beziehungen
- **projekt** — 9 Spalten, 4 FK-Beziehungen
- **qmrevision** — 7 Spalten, 3 FK-Beziehungen
- **qms** — 3 Spalten, 0 FK-Beziehungen
- **qsdokumentation** — 28 Spalten, 11 FK-Beziehungen
- **qshgvdokumentation** — 73 Spalten, 8 FK-Beziehungen
- **qsmgfachgruppe** — 4 Spalten, 0 FK-Beziehungen
- **qsmgfragestellung** — 6 Spalten, 0 FK-Beziehungen
- **qsmgleistung** — 7 Spalten, 0 FK-Beziehungen
- **qsmgquotient** — 5 Spalten, 0 FK-Beziehungen
- **qsmgringversuch** — 5 Spalten, 0 FK-Beziehungen
- **quickfilter** — 11 Spalten, 1 FK-Beziehungen
- **qzv** — 8 Spalten, 2 FK-Beziehungen
- **qzvzahlung** — 6 Spalten, 1 FK-Beziehungen
- **qzvzuweisung** — 8 Spalten, 1 FK-Beziehungen
- **rabattvertrag** — 5 Spalten, 0 FK-Beziehungen
- **rarechnung** — 5 Spalten, 0 FK-Beziehungen
- **recht** — 21 Spalten, 12 FK-Beziehungen
- **rechtetyp** — 13 Spalten, 0 FK-Beziehungen
- **rehaabsage** — 3 Spalten, 0 FK-Beziehungen
- **rehaanwesenheitszeit** — 4 Spalten, 0 FK-Beziehungen
- **rehaaufnahmedaten** — 10 Spalten, 0 FK-Beziehungen
- **rehabegleitperson** — 7 Spalten, 0 FK-Beziehungen
- **rehabewilligung** — 21 Spalten, 0 FK-Beziehungen
- **rehadurchgefuertemassnahme** — 4 Spalten, 0 FK-Beziehungen
- **rehaentgelt** — 8 Spalten, 0 FK-Beziehungen
- **rehaentlassungsberichtdaten** — 40 Spalten, 0 FK-Beziehungen
- **rehaentlassungsmeldungdaten** — 9 Spalten, 0 FK-Beziehungen
- **rehafallaufnahmedaten** — 10 Spalten, 0 FK-Beziehungen
- **rehafalldaten** — 14 Spalten, 0 FK-Beziehungen
- **rehafalldetails** — 20 Spalten, 2 FK-Beziehungen
- **rehafallentgelt** — 7 Spalten, 0 FK-Beziehungen
- **rehafallperson** — 8 Spalten, 0 FK-Beziehungen
- **rehafallzuzahlung** — 5 Spalten, 0 FK-Beziehungen
- **rehakindinmutterkind** — 6 Spalten, 0 FK-Beziehungen
- **rehaleistung** — 6 Spalten, 0 FK-Beziehungen
- **rehanachricht** — 38 Spalten, 10 FK-Beziehungen
- **reharechnung** — 9 Spalten, 0 FK-Beziehungen
- **rehaunterbrechung** — 5 Spalten, 0 FK-Beziehungen
- **roentgenabfrage** — 11 Spalten, 2 FK-Beziehungen
- **roentgenbucheintrag** — 24 Spalten, 6 FK-Beziehungen
- **rvganrechnungregel** — 4 Spalten, 3 FK-Beziehungen
- **rvgeraet** — 4 Spalten, 0 FK-Beziehungen
- **rvgkatalogeintrag** — 6 Spalten, 0 FK-Beziehungen
- **rvgkatalogeintraganrechnung** — 3 Spalten, 0 FK-Beziehungen
- **rvgkatalogeintrageurowert** — 3 Spalten, 0 FK-Beziehungen
- **rvgkatalogeintragfaktor** — 3 Spalten, 0 FK-Beziehungen
- **rvgkatalogeintraginhoehe** — 6 Spalten, 0 FK-Beziehungen
- **rvgkatalogeintragschwellwerte** — 8 Spalten, 0 FK-Beziehungen
- **rvmaterial** — 3 Spalten, 0 FK-Beziehungen
- **s3c_bqalternative** — 5 Spalten, 0 FK-Beziehungen
- **s3c_bqdokument** — 10 Spalten, 0 FK-Beziehungen
- **s3c_bqmailkim** — 6 Spalten, 0 FK-Beziehungen
- **s3c_bqpaket** — 4 Spalten, 1 FK-Beziehungen
- **s3c_bqpaket_regelungen** — 2 Spalten, 2 FK-Beziehungen
- **s3c_bqregel** — 3 Spalten, 0 FK-Beziehungen
- **s3c_bqregel_alternativen** — 2 Spalten, 2 FK-Beziehungen
- **s3c_bqregel_dokumente** — 2 Spalten, 2 FK-Beziehungen
- **s3c_bqregel_kimmails** — 2 Spalten, 2 FK-Beziehungen
- **s3c_bqregel_texte** — 2 Spalten, 2 FK-Beziehungen
- **s3c_bqregelung** — 13 Spalten, 0 FK-Beziehungen
- **s3c_bqregelung_regeln** — 2 Spalten, 2 FK-Beziehungen
- **s3c_bqtext** — 4 Spalten, 0 FK-Beziehungen
- **s3cabrechnungszeitenregel** — 5 Spalten, 0 FK-Beziehungen
- **s3canzahlbeschraenkungregel** — 6 Spalten, 0 FK-Beziehungen
- **s3causschlussregel** — 6 Spalten, 0 FK-Beziehungen
- **s3cdokument** — 6 Spalten, 0 FK-Beziehungen
- **s3ceinschreibediagnose** — 5 Spalten, 0 FK-Beziehungen
- **s3cfrist** — 8 Spalten, 0 FK-Beziehungen
- **s3cfunktion** — 6 Spalten, 0 FK-Beziehungen
- **s3cinteraktion** — 4 Spalten, 0 FK-Beziehungen
- **s3ckatalogeintragdetails** — 12 Spalten, 0 FK-Beziehungen
- **s3cleistungserbringergruppe** — 5 Spalten, 0 FK-Beziehungen
- **s3cleistungserbringerkriterium** — 5 Spalten, 0 FK-Beziehungen
- **s3cmedcolor** — 15 Spalten, 3 FK-Beziehungen
- **s3cpahistorie** — 3 Spalten, 0 FK-Beziehungen
- **s3cparameter** — 4 Spalten, 0 FK-Beziehungen
- **s3cpatientenkriterium** — 6 Spalten, 1 FK-Beziehungen
- **s3cpotentialanalyse** — 4 Spalten, 0 FK-Beziehungen
- **s3cpotentiellervertrag** — 6 Spalten, 0 FK-Beziehungen
- **s3cpotvertragkriterien** — 9 Spalten, 1 FK-Beziehungen
- **s3crabattangabe** — 3 Spalten, 1 FK-Beziehungen
- **s3cteilnahme** — 13 Spalten, 3 FK-Beziehungen
- **s3cverordnungsdatenexport** — 7 Spalten, 2 FK-Beziehungen
- **s3cversichertengruppe** — 5 Spalten, 0 FK-Beziehungen
- **s3cvertrag** — 13 Spalten, 1 FK-Beziehungen
- **s3cvertragsid** — 3 Spalten, 0 FK-Beziehungen
- **s3cvertragskennzeichen** — 9 Spalten, 0 FK-Beziehungen
- **s3cvertragsrelationen** — 1 Spalten, 0 FK-Beziehungen
- **s3cvertragsteilnahmearzt** — 7 Spalten, 1 FK-Beziehungen
- **sammelerklaerung** — 10 Spalten, 3 FK-Beziehungen
- **sammelerklaerungliste** — 6 Spalten, 2 FK-Beziehungen
- **sammelerklaerungzeit** — 5 Spalten, 0 FK-Beziehungen
- **sbattachment** — 5 Spalten, 1 FK-Beziehungen
- **sbcategory** — 8 Spalten, 2 FK-Beziehungen
- **sbfeedback** — 10 Spalten, 5 FK-Beziehungen
- **sbinputfield** — 7 Spalten, 2 FK-Beziehungen
- **sbinputfieldelement** — 8 Spalten, 2 FK-Beziehungen
- **sbinputfieldentry** — 7 Spalten, 2 FK-Beziehungen
- **sbinputfieldtemplate** — 10 Spalten, 1 FK-Beziehungen
- **sbprocess** — 17 Spalten, 6 FK-Beziehungen
- **sbprocessmetainfo** — 14 Spalten, 3 FK-Beziehungen
- **sbprocessstep** — 11 Spalten, 4 FK-Beziehungen
- **sbsortedinputfieldvalue** — 5 Spalten, 1 FK-Beziehungen
- **sbworkflow** — 10 Spalten, 3 FK-Beziehungen
- **sbworkflowedge** — 11 Spalten, 3 FK-Beziehungen
- **sbworkflowmetainfo** — 12 Spalten, 2 FK-Beziehungen
- **sbworkflownode** — 8 Spalten, 1 FK-Beziehungen
- **sbworkflowtasklabel** — 6 Spalten, 2 FK-Beziehungen
- **schema_version** — 10 Spalten, 0 FK-Beziehungen
- **schicht** — 10 Spalten, 2 FK-Beziehungen
- **schichtbewerbung** — 6 Spalten, 0 FK-Beziehungen
- **schwangerschaftsdetails** — 13 Spalten, 1 FK-Beziehungen
- **schwangerverlaufeinstellungen** — 11 Spalten, 1 FK-Beziehungen
- **sdavdaten** — 5 Spalten, 0 FK-Beziehungen
- **sddakonfiguration** — 13 Spalten, 3 FK-Beziehungen
- **sddazuordnung** — 21 Spalten, 3 FK-Beziehungen
- **selektivvertrag** — 17 Spalten, 2 FK-Beziehungen
- **selektivvertragsrelationen** — 3 Spalten, 2 FK-Beziehungen
- **seriellesgeraet** — 15 Spalten, 2 FK-Beziehungen
- **seriellesgeraetcomeintrag** — 23 Spalten, 0 FK-Beziehungen
- **seriellesgeraetcomkette** — 6 Spalten, 0 FK-Beziehungen
- **servernachricht** — 6 Spalten, 1 FK-Beziehungen
- **servernachrichttyp** — 8 Spalten, 1 FK-Beziehungen
- **servernachrichttypelement** — 3 Spalten, 1 FK-Beziehungen
- **skippedschein** — 3 Spalten, 1 FK-Beziehungen
- **skript** — 20 Spalten, 0 FK-Beziehungen
- **sollzeit** — 13 Spalten, 0 FK-Beziehungen
- **sollzeitweek** — 3 Spalten, 1 FK-Beziehungen
- **standardhinweis** — 3 Spalten, 0 FK-Beziehungen
- **starfaceanlage** — 4 Spalten, 0 FK-Beziehungen
- **starfacenutzer** — 10 Spalten, 3 FK-Beziehungen
- **statistikergebnis** — 5 Spalten, 1 FK-Beziehungen
- **statistikergebnisdocx** — 6 Spalten, 2 FK-Beziehungen
- **statistiktoolbaritem** — 6 Spalten, 0 FK-Beziehungen
- **stechuhr** — 19 Spalten, 0 FK-Beziehungen
- **sto_med_grouper** — 2 Spalten, 0 FK-Beziehungen
- **sto_med_grouper_interaktionenlinks** — 2 Spalten, 2 FK-Beziehungen
- **sto_med_grouper_interaktionenrechts** — 2 Spalten, 2 FK-Beziehungen
- **stoffgruppe** — 5 Spalten, 0 FK-Beziehungen
- **stoffname** — 5 Spalten, 1 FK-Beziehungen
- **svdatei** — 4 Spalten, 1 FK-Beziehungen
- **svteilnahme** — 11 Spalten, 2 FK-Beziehungen
- **svteilnahmearzt** — 6 Spalten, 1 FK-Beziehungen
- **svteilnahmebedingung** — 3 Spalten, 0 FK-Beziehungen
- **synadocplanung** — 4 Spalten, 0 FK-Beziehungen
- **tag** — 17 Spalten, 0 FK-Beziehungen
- **tagautomationelement** — 4 Spalten, 0 FK-Beziehungen
- **tagautomationelemententry** — 7 Spalten, 0 FK-Beziehungen
- **tagscriptvariable** — 6 Spalten, 0 FK-Beziehungen
- **teilnahmeauschlusssv** — 5 Spalten, 3 FK-Beziehungen
- **thenadocument** — 9 Spalten, 2 FK-Beziehungen
- **thenadocumentversion** — 6 Spalten, 2 FK-Beziehungen
- **ticket** — 16 Spalten, 7 FK-Beziehungen
- **ticketautomationsregel** — 8 Spalten, 2 FK-Beziehungen
- **ticketcontactdata** — 7 Spalten, 2 FK-Beziehungen
- **ticketrelation** — 5 Spalten, 0 FK-Beziehungen
- **ticketstatus** — 6 Spalten, 0 FK-Beziehungen
- **tomedonews** — 9 Spalten, 0 FK-Beziehungen
- **tsplocalpackage** — 6 Spalten, 2 FK-Beziehungen
- **tsssyncschedule** — 11 Spalten, 3 FK-Beziehungen
- **uheftelement** — 6 Spalten, 2 FK-Beziehungen
- **uheftuntersuchung** — 23 Spalten, 1 FK-Beziehungen
- **urlaubsanspruch** — 7 Spalten, 0 FK-Beziehungen
- **vddsaustauschobjekt** — 21 Spalten, 5 FK-Beziehungen
- **verabreichungstandard** — 4 Spalten, 0 FK-Beziehungen
- **verguetungverrechnung** — 4 Spalten, 1 FK-Beziehungen
- **verordnungsartikelarvgroup** — 1 Spalten, 0 FK-Beziehungen
- **verordnungsvorgabebestimmung** — 5 Spalten, 0 FK-Beziehungen
- **verordnungsvorgabeelement** — 4 Spalten, 0 FK-Beziehungen
- **verordnungswirkstoff** — 7 Spalten, 0 FK-Beziehungen
- **vidierer** — 3 Spalten, 1 FK-Beziehungen
- **vidierergruppe** — 1 Spalten, 0 FK-Beziehungen
- **vidierungsstatus** — 9 Spalten, 3 FK-Beziehungen
- **vitalwerteeinstellung** — 8 Spalten, 3 FK-Beziehungen
- **vitalwerteeinstellungennode** — 15 Spalten, 5 FK-Beziehungen
- **volltextdokument** — 4 Spalten, 0 FK-Beziehungen
- **volltextinformation** — 5 Spalten, 0 FK-Beziehungen
- **warenbestanddetails** — 8 Spalten, 3 FK-Beziehungen
- **warenbestellelementdetails** — 5 Spalten, 0 FK-Beziehungen
- **warendetailshaendlernummer** — 5 Spalten, 1 FK-Beziehungen
- **warendetailsrabatt** — 10 Spalten, 1 FK-Beziehungen
- **warenlagerschacht** — 5 Spalten, 1 FK-Beziehungen
- **warenleistung** — 7 Spalten, 0 FK-Beziehungen
- **warenlieferelement** — 10 Spalten, 1 FK-Beziehungen
- **warenvoreinstellung** — 6 Spalten, 1 FK-Beziehungen
- **warteschlangelocalization** — 4 Spalten, 1 FK-Beziehungen
- **xdt** — 8 Spalten, 0 FK-Beziehungen
- **xdteintrag** — 10 Spalten, 0 FK-Beziehungen
- **xdtsatzart** — 5 Spalten, 0 FK-Beziehungen
- **xi18n** — 6 Spalten, 0 FK-Beziehungen
- **xmlnode** — 6 Spalten, 0 FK-Beziehungen
- **xtranslatabletext** — 4 Spalten, 1 FK-Beziehungen
- **zahnarztlaborrechnung** — 18 Spalten, 5 FK-Beziehungen
- **zahnkroneflaeche** — 13 Spalten, 0 FK-Beziehungen
- **zahnwurzel** — 9 Spalten, 0 FK-Beziehungen
- **zeiterfassung** — 12 Spalten, 3 FK-Beziehungen
- **zeitmessung** — 5 Spalten, 0 FK-Beziehungen
- **zeitmessungtimer** — 6 Spalten, 1 FK-Beziehungen
- **zeitraumkomponenten** — 6 Spalten, 0 FK-Beziehungen
- **zescheindetails** — 35 Spalten, 1 FK-Beziehungen
- **zifferneinschraenkung** — 4 Spalten, 0 FK-Beziehungen
- **zsmenutoolbaritem** — 7 Spalten, 1 FK-Beziehungen
- **zswindowtutorial** — 7 Spalten, 0 FK-Beziehungen
- **zswindowtutorialelement** — 15 Spalten, 0 FK-Beziehungen
- **zusatzangabe** — 3 Spalten, 0 FK-Beziehungen
- **zusatzangabeerkrankung** — 2 Spalten, 0 FK-Beziehungen
- **zusatzangabehgnc** — 3 Spalten, 0 FK-Beziehungen
- **zusatzangabeomim** — 3 Spalten, 0 FK-Beziehungen
- **zusatzangabeops** — 3 Spalten, 1 FK-Beziehungen
- **zusatzangabesachkosten** — 8 Spalten, 0 FK-Beziehungen
- **zusatzbezeichnungbar** — 5 Spalten, 0 FK-Beziehungen
- **zuschlag** — 15 Spalten, 0 FK-Beziehungen

## 26. Bridge-Tabellen (m:n Beziehungen)

Diese Tabellen verknüpfen zwei Entities in einer Many-to-Many-Beziehung.

- **abrechnung_abrechnungsdateien**: `abrechnung` ↔ `abrechnungsdatei`
- **abrechnung_direktabrechnungen**: `abrechnung` ↔ `direktabrechnung`
- **abrechnung_externalconfiles**: `abrechnung` ↔ `datei`
- **abrechnung_nebenbetriebsstaetten**: `abrechnung` ↔ `betriebsstaette`
- **abrechnung_serveronlykvscheine**: `abrechnung` ↔ `kvschein`
- **abrechnung_serveronlyskippedscheine**: `abrechnung` ↔ `skippedschein`
- **abrechnungsfehler_konfliktleistungen**: `abrechnungsfehler` ↔ `leistung`
- **abrechnungsfehlerfilter_betriebsstaetten**: `abrechnungsfehlerfilter` ↔ `betriebsstaette`
- **abrechnungsfehlerfilter_loggedinusers**: `abrechnungsfehlerfilter` ↔ `nutzer`
- **abrechnungsfehlerfilter_nutzer**: `abrechnungsfehlerfilter` ↔ `nutzer`
- **abrkostentraegerdetails_teilrechnungen**: `abrkostentraegerdetails` ↔ `privatrechnung`
- **abteilung_kostenstellen**: `abteilung` ↔ `kostenstelle`
- **alternatingsollzeit_sollzeitweeks**: `alternatingsollzeit` ↔ `sollzeitweek`
- **alternativartikel_verordnungsgruppen**: `alternativartikel` ↔ `arvverordnungsgruppengrouper`
- **anaesthesiedoku_anaesthesieelemente**: `anaesthesiedoku` ↔ `anaesthesieelement`
- **anerkennungsbescheidp_bewleistungenp**: `anerkennungsbescheidp` ↔ `bewleistungenp`
- **anerkennungsbescheidpsychotherapie_anerkennungsbescheidfehler**: `anerkennungsbescheidpsychotherapie` ↔ `abrechnungsfehler`
- **anerkennungsbescheidpsychotherapie_bewilligteleistungen4244**: `anerkennungsbescheidpsychotherapie` ↔ `bewilligteleistung`
- **angefordertesjsonformular_formulare**: `angefordertesjsonformular` ↔ `karteieintrag`
- **angefordertesjsonformular_formulartypen**: `angefordertesjsonformular` ↔ `formulartyp`
- **apinachricht_inhalte**: `apinachricht` ↔ `apinachrichtinhalt`
- **apinachrichtinhalt_rechtanfrageneintraege**: `apinachrichtinhalt` ↔ `apinachrichtrechtanfrageeintrag`
- **apinachrichtthread_empfaenger**: `apinachrichtthread` ↔ `apinachrichtteilnehmer`
- **apinachrichtthread_stubs**: `apinachrichtthread` ↔ `apinachrichtstub`
- **apinachrichtthread_zugeordnetenutzer**: `apinachrichtthread` ↔ `nutzer`
- **arbeitgeber_abteilungen**: `arbeitgeber` ↔ `abteilung`
- **arbeitgeber_arbmedarbeitgeberfavorit**: `arbeitgeber` ↔ `outlineviewelement`
- **arbeitgeber_kostenstellen**: `arbeitgeber` ↔ `kostenstelle`
- **arbeitsplatz_arbeitsplatzrechte**: `arbeitsplatz` ↔ `recht`
- **arbeitsplatz_gruppen**: `arbeitsplatz` ↔ `arbeitsplatzgruppe`
- **arbeitsplatz_laborgeraete**: `arbeitsplatz` ↔ `laborgeraet`
- **arbeitsplatzgruppe_arbeitsplatzgrupperechte**: `arbeitsplatzgruppe` ↔ `recht`
- **arbeitszeitkonto_abwesenheiten**: `arbeitszeitkonto` ↔ `abwesenheit`
- **arbeitszeitkonto_adminstellen**: `arbeitszeitkonto` ↔ `stelle`
- **arbeitszeitkonto_alternatingsollzeiten**: `arbeitszeitkonto` ↔ `alternatingsollzeit`
- **arbeitszeitkonto_arbeitszeitkontoupdateinfo**: `arbeitszeitkonto` ↔ `arbeitszeitkontoupdateinfo`
- **arbeitszeitkonto_sollzeiten**: `arbeitszeitkonto` ↔ `sollzeit`
- **arbeitszeitkonto_stechuhren**: `arbeitszeitkonto` ↔ `stechuhr`
- **arbeitszeitkonto_stellen**: `arbeitszeitkonto` ↔ `stelle`
- **arbeitszeitkonto_urlaubsansprueche**: `arbeitszeitkonto` ↔ `urlaubsanspruch`
- **arbeitszeitkonto_wohnhaftinkv**: `arbeitszeitkonto` ↔ `wohnhaftinkv`
- **arbmedkatalogeintrag_arbmedleistungskatalogeintrag**: `arbmedkatalogeintrag` ↔ `goaekatalogeintrag`
- **arminmedikamentenplan_arminmedikamentenplanelement**: `arminmedikamentenplan` ↔ `arminmedikamentenplanelement`
- **arvregel_dokumente**: `arvregel` ↔ `abdadokument`
- **arvregel_preisintervalle**: `arvregel` ↔ `preisintervall`
- **arvregel_regeltypen**: `arvregel` ↔ `arvregeltyp`
- **arvverordnungsgruppengrouper_einzelartikel**: `arvverordnungsgruppengrouper` ↔ `alternativartikel`
- **arzneimittelkomponente_komponenteninhaltsstoffesort**: `arzneimittelkomponente` ↔ `komponenteninhaltsstoffsort`
- **arztbriefeav_ersatzwerte**: `arztbriefeav` ↔ `artbriefeav_ersatzwert`
- **arztbriefeav_importedtexte**: `arztbriefeav` ↔ `karteieintrag`
- **arztbriefeav_listenelement**: `datei` ↔ `diagnose` ↔ `lbtestlbanforderung` ↔ `medikamentenverordnung`
- **arztbriefeav_listenelemente**: `arztbriefeav` ↔ `arztbriefeav_listenelement`
- **arztdirektchat_pappchats**: `arztdirektchat` ↔ `pappchat`
- **arztpatientenkontakt_diagnosen**: `arztpatientenkontakt` ↔ `diagnose`
- **asrautokorrekturelement_disablednutzers**: `asrautokorrekturelement` ↔ `nutzer`
- **asvindikation_asvarztgruppen**: `asvindikation` ↔ `asvarztgruppe`
- **asvindikationrelationen_asvleistungen**: `asvindikationrelationen` ↔ `asvleistung`
- **asvteamnummer_asvteammitglieder**: `asvteamnummer` ↔ `asvteammitglied`
- **atarztpatientenkontaktdetails_diagnosedetails**: `atarztpatientenkontaktdetails` ↔ `atkontaktdiagnosedetails`
- **atarztpatientenkontaktdetails_leistungdetails**: `atarztpatientenkontaktdetails` ↔ `atkontaktleistungdetails`
- **atedokumentationsblatt_atedokuparameter**: `atedokumentationsblatt` ↔ `atedokuparameter`
- **atrezept_absanhaenge**: `atrezept` ↔ `datei`
- **aufgabe_dateien**: `aufgabe` ↔ `datei`
- **aufgabe_finishconditions**: `aufgabe` ↔ `aufgabefinishcondition`
- **aufgabe_kommentare**: `aufgabe` ↔ `kommentar`
- **aufgabe_logeintraege**: `aufgabe` ↔ `kommentar`
- **aufgabe_verantwortliche**: `aufgabe` ↔ `aufgabenempfaenger`
- **aufgabeworklist_elements**: `aufgabeworklist` ↔ `aufgabeworklistelement`
- **bdocdetails_bdocerkrankungen**: `bdocdetails` ↔ `bdocerkrankung`
- **bdocdiagnosenwrapper_icds**: `bdocdiagnosenwrapper` ↔ `icdkatalogeintrag`
- **bdocdiagnosenwrapper_unterbedingungen**: `bdocdiagnosenwrapper` ↔ `bdocdiagnosenwrapper`
- **bdocerkrankung_diagnosenbedingungen**: `bdocerkrankung` ↔ `bdocdiagnosenwrapper`
- **bdocerkrankung_materialien**: `bdocerkrankung` ↔ `bdocmaterial`
- **bdocerkrankung_medications**: `bdocerkrankung` ↔ `bdocmedication`
- **bdocerkrankungcommondetails_materialien**: `bdocerkrankungcommondetails` ↔ `bdocmaterial`
- **bdocerkrankungcommondetails_opscodes**: `bdocerkrankungcommondetails` ↔ `opskatalogeintrag`
- **bdocleistungsbogen_bdocleistungsparameter**: `bdocleistungsbogen` ↔ `bdocleistungsparameter`
- **beanachricht_beaanhaenge**: `beanachricht` ↔ `beaanhang`
- **beanachricht_beamessagejournals**: `beanachricht` ↔ `beamessagejournal`
- **beanachricht_beaordner**: `beanachricht` ↔ `outlineviewelement`
- **beapostfach_beaordner**: `beapostfach` ↔ `outlineviewelement`
- **befundgruppe_regelversorgungbel**: `befundgruppe` ↔ `laborkatalogeintrag`
- **befundgruppe_regelversorgungbelab**: `befundgruppe` ↔ `laborkatalogeintrag`
- **befundgruppe_regelversorgungbema**: `befundgruppe` ↔ `bemakatalogeintrag`
- **behandlungsfall_behandlungsfalldetails**: `behandlungsfall` ↔ `behandlungsfalldetails`
- **behandlungsfall_behandlungsfallelemente**: `behandlungsfall` ↔ `behandlungsfallelement`
- **behandlungsfalldetails_children**: `behandlungsfalldetails` ↔ `behandlungsfalldetails`
- **bemakatalogeintrag_bemakatalogeintragdetails**: `bemakatalogeintrag` ↔ `bemakatalogeintragdetails`
- **bemakatalogeintrag_voreinstellungenbefund**: `bemakatalogeintrag` ↔ `outlineviewelement`
- **benefitassessmentgbapatgroup_icd10codes**: `benefitassessmentgbapatgroup` ↔ `icd10code`
- **besuch_abgerechnet**: `besuch` ↔ `nutzer`
- **besuch_behandelnderarzt**: `besuch` ↔ `behandelnderarzt`
- **besuch_dokumentiert**: `besuch` ↔ `nutzer`
- **besuch_todokette**: `besuch` ↔ `todo`
- **betriebsstaette_behandelndeaerzte**: `betriebsstaette` ↔ `behandelnderarzt`
- **betriebsstaette_customdatenfelder**: `betriebsstaette` ↔ `customdatenfeld`
- **betriebsstaette_edakennziffern**: `betriebsstaette` ↔ `edakennziffer`
- **betriebsstaette_emergencyeintraege**: `betriebsstaette` ↔ `emergencyeintrag`
- **betriebsstaette_fachgruppebar**: `betriebsstaette` ↔ `fachgruppebar`
- **betriebsstaette_implantateregistertieintraege**: `betriebsstaette` ↔ `implantateregistertieintrag`
- **betriebsstaette_logos**: `betriebsstaette` ↔ `customformularbgimage`
- **betriebsstaette_rvgeraete**: `betriebsstaette` ↔ `rvgeraet`
- **betriebsstaette_verwendetematerialien**: `betriebsstaette` ↔ `rvmaterial`
- **bewilligteleistung_abgerechneteleistungen**: `bewilligteleistung` ↔ `leistung`
- **bewilligteleistung_bewilligteleistungfehler**: `bewilligteleistung` ↔ `abrechnungsfehler`
- **bewleistungenp_abgerechnetegoaeleistungen**: `bewleistungenp` ↔ `leistung`
- **bgberichtfeld_bgberichtfeldwertebereich**: `bgberichtfeld` ↔ `bgberichtfeldwertebereich`
- **bgberichtsegment_bgberichtfelder**: `bgberichtsegment` ↔ `bgberichtfeld`
- **bgformular_diagnosen**: `bgformular` ↔ `diagnosebgformular`
- **bgunfall_besuche**: `bgunfall` ↔ `besuch`
- **bgunfall_bgformulare**: `bgunfall` ↔ `karteieintrag`
- **blankoampelphase_icdkatalogeintraege**: `blankoampelphase` ↔ `icdkatalogeintrag`
- **briefvorlage_alteversionen**: `briefvorlage` ↔ `datei`
- **cdgeraet_protokolle**: `cdgeraet` ↔ `cdprotokoll`
- **cdprotokoll_anhaenge**: `cdprotokoll` ↔ `cdprotokollanhang`
- **cegedimexport_dateien**: `cegedimexport` ↔ `datei`
- **chextendedxmldata_druckversionen**: `chextendedxmldata` ↔ `druckversion`
- **chopcode_assistenten**: `chopcode` ↔ `nutzer`
- **chopkatalogeintrag_leistungen**: `chopkatalogeintrag` ↔ `leistung`
- **clipleitsubstanz_fachgruppenhinweise**: `clipleitsubstanz` ↔ `fachgruppenhinweis`
- **clipmetoo_clipleitsubstanz**: `clipmetoo` ↔ `clipleitsubstanz`
- **clipmetoo_dokumente**: `clipmetoo` ↔ `abdadokument`
- **customdatenfeld_appearsinqmrevision**: `customdatenfeld` ↔ `qmrevision`
- **customerspecificcondition_assortedconditions**: `customerspecificcondition` ↔ `assortedconditions`
- **customformularpage_customformularelemente**: `customformularpage` ↔ `customformularelement`
- **customformularpage_images**: `customformularpage` ↔ `customformularbgimage`
- **customheilmittelkatalog_heilmittel**: `customheilmittelkatalog` ↔ `heilmittel`
- **customkarteieintragentry_cdcharge**: `customkarteieintragentry` ↔ `cdcharge`
- **customkarteieintragentry_children**: `customkarteieintragentry` ↔ `customkarteieintragentry`
- **dameadresse_edifactlabormappings**: `dameadresse` ↔ `edifactlabormapping`
- **damenachricht_patientcandidates**: `damenachricht` ↔ `patient`
- **darreichung_dosiereinheiten**: `darreichung` ↔ `bmp_dosiereinheit`
- **datevexport_rechnungen**: `datevexport` ↔ `privatrechnung`
- **delegierteleistungen_bebkatalogeintraege**: `delegierteleistungen` ↔ `laborkatalogeintrag`
- **delegierteleistungen_belkatalogeintraege**: `delegierteleistungen` ↔ `laborkatalogeintrag`
- **delegierteleistungen_bemakatalogeintraege**: `delegierteleistungen` ↔ `bemakatalogeintrag`
- **delegierteleistungen_ebmkatalogeintraege**: `delegierteleistungen` ↔ `ebmkatalogeintrag`
- **delegierteleistungen_goaekatalogeintraege**: `delegierteleistungen` ↔ `goaekatalogeintrag`
- **delegierteleistungen_hzvkatalogeintraege**: `delegierteleistungen` ↔ `hzvkatalogeintrag`
- **delegierteleistungen_nutzer**: `delegierteleistungen` ↔ `nutzer`
- **delegierteleistungen_nutzergruppen**: `delegierteleistungen` ↔ `nutzergruppe`
- **derezept_s3cteilnahmen**: `derezept` ↔ `s3cteilnahme`
- **direktabrechnung_abrechnungsdateien**: `direktabrechnung` ↔ `abrechnungsdatei`
- **direktabrechnung_abrechnungsdetails**: `direktabrechnung` ↔ `abrkostentraegerdetails`
- **direktabrechnung_amboabrechnungsfehler**: `direktabrechnung` ↔ `abrechnungsfehler`
- **direktabrechnung_heilmittelscheine**: `direktabrechnung` ↔ `heilmittelschein`
- **direktabrechnung_hmeabrechnungsfehler**: `direktabrechnung` ↔ `abrechnungsfehler`
- **direktabrechnung_krankenkassen**: `direktabrechnung` ↔ `kostentraegernichtkvabrechnung`
- **direktabrechnung_kvscheine**: `direktabrechnung` ↔ `kvschein`
- **drgabrechnung_abrechnungsdateien**: `drgabrechnung` ↔ `abrechnungsdatei`
- **drgabrechnung_korrekturen**: `drgabrechnung` ↔ `drgabrechnung`
- **drgabrechnungsfall_diagnosefehler**: `drgabrechnungsfall` ↔ `abrechnungsfehler`
- **drgabrechnungsfall_drgabrechnungen**: `drgabrechnung` ↔ `drgabrechnungsfall`
- **drgabrechnungsfall_drgfehler**: `drgabrechnungsfall` ↔ `abrechnungsfehler`
- **drgabrechnungsfall_drgleistungen**: `drgabrechnungsfall` ↔ `leistung`
- **drgabrechnungsfall_irdanfragen**: `drgabrechnungsfall` ↔ `irdanfrage`
- **drgabrechnungsfall_quartalsdiagnosen**: `drgabrechnungsfall` ↔ `diagnose`
- **drgkatalogeintrag_opskatalogeintraege**: `drgkatalogeintrag` ↔ `opskatalogeintrag`
- **drucker_warteschlange**: `drucker` ↔ `druckerschlangeelement`
- **dvpabrechnung_dvppauschalleistungen**: `dvpabrechnung` ↔ `dvppauschalleistung`
- **dvpabrechnung_versandnachrichten**: `dvpabrechnung` ↔ `damenachricht`
- **dvpabrechnung_zusatzdateien**: `dvpabrechnung` ↔ `datei`
- **dvpkatalogeintrag_dvpkatalogeintragdetails**: `dvpkatalogeintrag` ↔ `dvpkatalogeintragdetails`
- **dvpkatalogeintrag_dvpleistungbedingungen**: `dvpkatalogeintrag` ↔ `dvpleistungbedingung`
- **dvpkatalogeintragdetails_dvpkatalogfachgruppendetails**: `dvpkatalogeintragdetails` ↔ `dvpkatalogfachgruppendetails`
- **dvpleistungbedingung_ausschlussziffern**: `dvpleistungbedingung` ↔ `dvpkatalogeintrag`
- **dvpleistungbedingung_dvpkatalogabschnitte**: `dvpleistungbedingung` ↔ `dvpkatalogabschnitt`
- **dvpleistungbedingung_fachgruppen**: `dvpleistungbedingung` ↔ `fachgruppebar`
- **dvpleistungbedingung_limitierendeziffern**: `dvpleistungbedingung` ↔ `dvpkatalogeintrag`
- **dvpleistungbedingung_limitierteziffern**: `dvpleistungbedingung` ↔ `dvpkatalogeintrag`
- **dvpschein_diagnosefehler**: `dvpschein` ↔ `abrechnungsfehler`
- **dvpschein_dvpleistungen**: `dvpschein` ↔ `leistung`
- **dvpschein_irdanfragen**: `dvpschein` ↔ `irdanfrage`
- **dvpschein_konsultationen**: `dvpschein` ↔ `konsultation`
- **dvpschein_quartalsdiagnosen**: `dvpschein` ↔ `diagnose`
- **dvpschein_validationerrors**: `dvpschein` ↔ `abrechnungsfehler`
- **dvptarif_dvpkatalogabschnitte**: `dvptarif` ↔ `dvpkatalogabschnitt`
- **dvptarif_dvpkatalogeintraege**: `dvptarif` ↔ `dvpkatalogeintrag`
- **dvpvertragsrelationen_dvptarife**: `dvpvertragsrelationen` ↔ `dvptarif`
- **dvpvertragsrelationen_fremdkassen**: `dvpvertragsrelationen` ↔ `krankenkasse`
- **dvpvertragsrelationen_p2kassen**: `dvpvertragsrelationen` ↔ `krankenkasse`
- **ebmaltersbedingung_aussetzungsgrundicd**: `ebmaltersbedingung` ↔ `icdkatalogeintrag`
- **ebmaltersbedingung_aussetzungsgrundzusatzangabe**: `ebmaltersbedingung` ↔ `zusatzangabe`
- **ebmanzahlbedingung_aussetzungsgrund**: `ebmanzahlbedingung` ↔ `zusatzangabe`
- **ebmanzahlbedingung_aussetzungsgrundicd**: `ebmanzahlbedingung` ↔ `icdkatalogeintrag`
- **ebmanzahlbedingung_aussetzungsgrundzusatzangabe**: `ebmanzahlbedingung` ↔ `zusatzangabe`
- **ebmausschlussregel_ausschlussgnr**: `ebmausschlussregel` ↔ `ebmkatalogeintrag`
- **ebmausschlussregel_aussetzungsgrundicd**: `ebmausschlussregel` ↔ `icdkatalogeintrag`
- **ebmausschlussregel_aussetzungsgrundzusatzangabe**: `ebmausschlussregel` ↔ `zusatzangabe`
- **ebmbegruendungbedingung_aussetzungsgrundicd**: `ebmbegruendungbedingung` ↔ `icdkatalogeintrag`
- **ebmbegruendungbedingung_aussetzungsgrundzusatzangabe**: `ebmbegruendungbedingung` ↔ `zusatzangabe`
- **ebmbegruendungbedingung_begruendungsgnr**: `ebmbegruendungbedingung` ↔ `ebmkatalogeintrag`
- **ebmbegruendungbedingung_begruendungsicdcode**: `ebmbegruendungbedingung` ↔ `icdkatalogeintrag`
- **ebmbegruendungbedingung_opsbegruendungen**: `ebmbegruendungbedingung` ↔ `opsbegruendung`
- **ebmfachgruppenbedingung_aussetzungsgrundicd**: `ebmfachgruppenbedingung` ↔ `icdkatalogeintrag`
- **ebmfachgruppenbedingung_aussetzungsgrundzusatzangabe**: `ebmfachgruppenbedingung` ↔ `zusatzangabe`
- **ebmfachgruppenbedingung_fachgruppebar**: `ebmfachgruppenbedingung` ↔ `fachgruppebar`
- **ebmgenderbedingung_aussetzungsgrundicd**: `ebmgenderbedingung` ↔ `icdkatalogeintrag`
- **ebmgenderbedingung_aussetzungsgrundzusatzangabe**: `ebmgenderbedingung` ↔ `zusatzangabe`
- **ebmgrundleistungbedingung_aussetzungsgrundicd**: `ebmgrundleistungbedingung` ↔ `icdkatalogeintrag`
- **ebmgrundleistungbedingung_aussetzungsgrundzusatzangabe**: `ebmgrundleistungbedingung` ↔ `zusatzangabe`
- **ebmgrundleistungbedingung_grundebms**: `ebmgrundleistungbedingung` ↔ `ebmkatalogeintrag`
- **ebmkatalogeintrag_altersbedingung**: `ebmkatalogeintrag` ↔ `ebmaltersbedingung`
- **ebmkatalogeintrag_anzahlbedingung**: `ebmkatalogeintrag` ↔ `ebmanzahlbedingung`
- **ebmkatalogeintrag_ausschlussregel**: `ebmkatalogeintrag` ↔ `ebmausschlussregel`
- **ebmkatalogeintrag_begruendungbedingung**: `ebmkatalogeintrag` ↔ `ebmbegruendungbedingung`
- **ebmkatalogeintrag_ebmkatalogeintragdetails**: `ebmkatalogeintrag` ↔ `ebmkatalogeintragdetails`
- **ebmkatalogeintrag_ebmzusatzangabenbedingung**: `ebmkatalogeintrag` ↔ `ebmzusatzangabenbedingung`
- **ebmkatalogeintrag_fachgruppenbedingung**: `ebmkatalogeintrag` ↔ `ebmfachgruppenbedingung`
- **ebmkatalogeintrag_genderbedingung**: `ebmkatalogeintrag` ↔ `ebmgenderbedingung`
- **ebmkatalogeintrag_grundleistungbedingung**: `ebmkatalogeintrag` ↔ `ebmgrundleistungbedingung`
- **ebmkatalogeintrag_s3ckatalogeintragdetails**: `ebmkatalogeintrag` ↔ `s3ckatalogeintragdetails`
- **ebmkatalogeintrag_scheingruppebedingung**: `ebmkatalogeintrag` ↔ `ebmscheingruppebedingung`
- **ebmkatalogeintrag_subgop**: `ebmkatalogeintrag` ↔ `subgop`
- **ebmkatalogeintrag_zifferneinschraenkungen**: `ebmkatalogeintrag` ↔ `zifferneinschraenkung`
- **ebmleistungskatalog_ebmkatalogeintraege**: `ebmleistungskatalog` ↔ `ebmkatalogeintrag`
- **ebmscheingruppebedingung_aussetzungsgrundicd**: `ebmscheingruppebedingung` ↔ `icdkatalogeintrag`
- **ebmscheingruppebedingung_aussetzungsgrundzusatzangabe**: `ebmscheingruppebedingung` ↔ `zusatzangabe`
- **ebmscheingruppebedingung_scheingruppe**: `ebmscheingruppebedingung` ↔ `kvscheingruppe`
- **ebmzusatzangabenbedingung_aussetzungsgrundicd**: `ebmzusatzangabenbedingung` ↔ `icdkatalogeintrag`
- **ebmzusatzangabenbedingung_aussetzungsgrundzusatzangabe**: `ebmzusatzangabenbedingung` ↔ `zusatzangabe`
- **ebmzusatzangabenbedingung_feld**: `ebmzusatzangabenbedingung` ↔ `zusatzangabe`
- **ebzmitteilung_behandlungsabbruch**: `ebzmitteilung` ↔ `kzvscheinbemerkung`
- **ebzmitteilung_bemaleistungen**: `ebzmitteilung` ↔ `leistung`
- **ebzmitteilung_unplanmaessigerverlauf**: `ebzmitteilung` ↔ `kzvscheinbemerkung`
- **edokuabrechnung_abrechnungsdateien**: `edokuabrechnung` ↔ `abrechnungsdatei`
- **edokuabrechnung_edmpkimeinsendungen**: `edokuabrechnung` ↔ `email`
- **edokuabrechnung_edmpkimquittungen**: `edokuabrechnung` ↔ `email`
- **edokuabrechnung_nebenbetriebsstaetten**: `edokuabrechnung` ↔ `betriebsstaette`
- **edokumentation_autogeneratedleistungen**: `edokumentation` ↔ `leistung`
- **edokumentation_dmpparameter**: `edokumentation` ↔ `dmpparameter`
- **edokumentation_fekelemente**: `edokumentation` ↔ `fekelemente`
- **edokumentation_formulare**: `edokumentation` ↔ `karteieintrag`
- **einzelbefund_befundgruppen**: `einzelbefund` ↔ `befundgruppe`
- **ekonsil_anhaenge**: `ekonsil` ↔ `ekonsilanhang`
- **ekonsil_diagnosen**: `ekonsil` ↔ `diagnose`
- **email_emailanhaenge**: `email` ↔ `datei`
- **email_emailheader**: `email` ↔ `emailheader`
- **email_folders**: `outlineviewelement` ↔ `email`
- **email_folderspecificemailinfos**: `email` ↔ `folderspecificemailinfo`
- **email_patientcandidates**: `email` ↔ `patient`
- **emailaccount_emailfolder**: `emailaccount` ↔ `outlineviewelement`
- **emailaccount_imapfolders**: `emailaccount` ↔ `imapfolder`
- **emailaccount_serveronlysyncstatus**: `emailaccount` ↔ `emailaccountsyncstatus`
- **emailaccount_signatures**: `emailaccount` ↔ `emailsignatur`
- **emailempfaengerliste_emailempfaengerelemente**: `emailempfaengerliste` ↔ `emailempfaengerelement`
- **emailvorlage_attachments**: `emailvorlage` ↔ `datei`
- **emailvorlage_emailempfaengerlisten**: `emailvorlage` ↔ `emailempfaengerliste`
- **emailvorlage_emailheader**: `emailvorlage` ↔ `emailheader`
- **emergencyeintrag_receivedatarbeitsplaetze**: `emergencyeintrag` ↔ `arbeitsplatz`
- **emergencytype_arbeitsplaetze**: `emergencytype` ↔ `arbeitsplatz`
- **emergencytype_betriebsstaetten**: `emergencytype` ↔ `betriebsstaette`
- **emergencytype_nutzer**: `emergencytype` ↔ `nutzer`
- **erechnungsdokument_privatrechnungcandidates**: `erechnungsdokument` ↔ `privatrechnung`
- **externertermin_dateien**: `externertermin` ↔ `datei`
- **externertermin_formulardaten**: `externertermin` ↔ `terminformulareintrag`
- **externeterminkette_dateien**: `externeterminkette` ↔ `datei`
- **fachgebietbasfein_elementewbo**: `fachgebietbasfein` ↔ `fachgruppebar`
- **fachgebietbasgrob_elementefein**: `fachgebietbasgrob` ↔ `fachgebietbasfein`
- **fachgebietbasgrob_elementewbo**: `fachgebietbasgrob` ↔ `fachgruppebar`
- **fachgruppendurchschnitt_fachgruppendruchschnitteintraege**: `fachgruppendurchschnitt` ↔ `fachgruppendruchschnitteintrag`
- **fachgruppenhinweis_preisintervalle**: `fachgruppenhinweis` ↔ `preisintervall`
- **favoritlabortest_intervalle**: `favoritlabortest` ↔ `favoritlabortestintervall`
- **feerinnerunggruppe_terminerinnerungen**: `feerinnerunggruppe` ↔ `terminerinnerung`
- **feerinnerungpatienteninformation_feerinnerungkanalstatusse**: `feerinnerungpatienteninformation` ↔ `feerinnerungkanalstatus`
- **feerinnerungpatienteninformation_frueherkennungsuntersuchung**: `feerinnerungpatienteninformation` ↔ `frueherkennungsuntersuchung`
- **feerinnerungpatienteninformation_terminerinnerungen**: `feerinnerungpatienteninformation` ↔ `terminerinnerung`
- **fekstatussnapshot_ferstatussnapshot**: `fekstatussnapshot` ↔ `ferstatussnapshot`
- **fekstatussnapshot_frueherkennungsuntersuchung**: `fekstatussnapshot` ↔ `frueherkennungsuntersuchung`
- **femanualerinnerung_feerinnerungkanalstatusse**: `femanualerinnerung` ↔ `feerinnerungkanalstatus`
- **forderung_fokoverrechnungen**: `forderung` ↔ `fokoverrechnung`
- **forderung_nebenforderungen**: `forderung` ↔ `forderung`
- **forderung_raleistungen**: `forderung` ↔ `leistung`
- **forderung_zinseintraege**: `forderung` ↔ `zinseintrag`
- **forderungskonto_fokomassnahmen**: `forderungskonto` ↔ `fokomassnahme`
- **forderungskonto_forderungen**: `forderungskonto` ↔ `forderung`
- **forderungskonto_glaeubiger**: `forderungskonto` ↔ `patient`
- **forderungskonto_karteieintraege**: `forderungskonto` ↔ `karteieintrag`
- **forderungskonto_schuldner**: `forderungskonto` ↔ `patient`
- **forderungskonto_teilbetraege**: `forderungskonto` ↔ `teilbetrag`
- **forderungskonto_zahlungen**: `forderungskonto` ↔ `zahlung`
- **formulartyp_bgberichtsegmente**: `formulartyp` ↔ `bgberichtsegment`
- **formulartyp_customformularpages**: `formulartyp` ↔ `customformularpage`
- **formulartyp_vorlagen**: `formulartyp` ↔ `karteieintrag`
- **formulartypliste_formulartyplistenelemente**: `formulartypliste` ↔ `formulartyplistenelement`
- **fragebogen_fragebogennormen**: `fragebogen` ↔ `fragebogennorm`
- **fragebogen_fragebogenreports**: `fragebogen` ↔ `fragebogenreport`
- **fragebogen_fragebogenskalen**: `fragebogen` ↔ `fragebogenskala`
- **fragebogen_fragebogensubtests**: `fragebogen` ↔ `fragebogensubtest`
- **fragebogenbatterie_frageboegen**: `fragebogenbatterie` ↔ `fragebogen`
- **fragebogenbatterie_fragebogenergebnisse**: `fragebogenbatterie` ↔ `fragebogenergebnis`
- **frueherkennungerinnerungconfig_febenachrichtigungskanaele**: `frueherkennungerinnerungconfig` ↔ `febenachrichtigungskanal`
- **frueherkennungerinnerungconfig_feerinnerungpatienteninformation**: `frueherkennungerinnerungconfig` ↔ `feerinnerungpatienteninformation`
- **frueherkennungerinnerungconfig_frueherkennungscustomfilter**: `frueherkennungerinnerungconfig` ↔ `frueherkennungscustomfilter`
- **frueherkennungerinnerungconfig_icdkatalogeintrag**: `frueherkennungerinnerungconfig` ↔ `icdkatalogeintrag`
- **frueherkennungskrankheit_terminart**: `frueherkennungskrankheit` ↔ `terminart`
- **frueherkennungskriterienelement_children**: `frueherkennungskriterienelement` ↔ `frueherkennungskriterienelement`
- **frueherkennungsregel_frueherkennungscustomfilter**: `frueherkennungsregel` ↔ `frueherkennungscustomfilter`
- **frueherkennungsuntersuchung_bemaleistungen**: `frueherkennungsuntersuchung` ↔ `leistung`
- **frueherkennungsuntersuchung_diagnosen**: `frueherkennungsuntersuchung` ↔ `diagnose`
- **frueherkennungsuntersuchung_ebmleistungen**: `frueherkennungsuntersuchung` ↔ `leistung`
- **frueherkennungsuntersuchung_goaeleistungen**: `frueherkennungsuntersuchung` ↔ `leistung`
- **frueherkennungsuntersuchung_hzvleistungen**: `frueherkennungsuntersuchung` ↔ `leistung`
- **frueherkennungsuntersuchung_karteieintraege**: `frueherkennungsuntersuchung` ↔ `karteieintrag`
- **fusformular_anhaenge**: `fusformular` ↔ `fusformularanhang`
- **gdtexportsetting_gdtfields**: `gdtexportsetting` ↔ `gdtfield`
- **goaeabschnitt_subgroups**: `goaeabschnitt` ↔ `goaeunterabschnitt`
- **goaeblock_katalogeintraege**: `goaeblock` ↔ `goaekatalogeintrag`
- **goaekapitel_subgroups**: `goaekapitel` ↔ `goaeabschnitt`
- **goaekatalogeintrag_analog**: `goaekatalogeintrag` ↔ `goaeanalogwrapper`
- **goaekatalogeintrag_ersetzungsliste**: `goaekatalogeintrag` ↔ `goaekatalogeintrag`
- **goaekatalogeintrag_goaeleistungbedingungen**: `goaekatalogeintrag` ↔ `goaeleistungbedingung`
- **goaekatalogeintrag_grundleistungen**: `goaekatalogeintrag` ↔ `goaekatalogeintrag`
- **goaekatalogeintrag_kombichildren**: `goaekatalogeintrag` ↔ `goaekatalogeintrag`
- **goaekatalogeintrag_voreinstellungenbefunde**: `goaekatalogeintrag` ↔ `outlineviewelement`
- **goaekatalogeintrag_warenvoreinstellungen**: `goaekatalogeintrag` ↔ `warenvoreinstellung`
- **goaekatalogeintrag_zifferneinschraenkungen**: `goaekatalogeintrag` ↔ `zifferneinschraenkung`
- **goaeleistungbedingung_ausschlussleistung**: `goaeleistungbedingung` ↔ `goaekatalogeintrag`
- **goaeleistungbedingung_fachgruppebar**: `goaeleistungbedingung` ↔ `fachgruppebar`
- **goaeleistungbedingung_gnrlisteleistung**: `goaeleistungbedingung` ↔ `goaekatalogeintrag`
- **goaeleistungbedingung_kumulativeleistungen**: `goaeleistungbedingung` ↔ `goaekatalogeintrag`
- **goaeleistungbedingung_onlyforfachgruppen**: `goaeleistungbedingung` ↔ `fachgruppebar`
- **goaeleistungsgruppe_goaekatalogeintraege**: `goaeleistungsgruppe` ↔ `goaekatalogeintrag`
- **goaeunterabschnitt_subgroups**: `goaeunterabschnitt` ↔ `goaeblock`
- **guiaction_arbeitsplaetze**: `guiaction` ↔ `arbeitsplatz`
- **guiaction_arbeitsplatzgruppen**: `guiaction` ↔ `arbeitsplatzgruppe`
- **guiaction_children**: `guiaction` ↔ `guiaction`
- **guiaction_nutzer**: `guiaction` ↔ `nutzer`
- **guiaction_nutzergruppen**: `guiaction` ↔ `nutzergruppe`
- **guiactioncondition_children**: `guiactioncondition` ↔ `guiactioncondition`
- **guiactionquestion_children**: `guiactionquestion` ↔ `guiactionquestion`
- **guiactionquestion_guiactionquestionentries**: `guiactionquestion` ↔ `guiactionquestionentry`
- **gynverlaufeinstellungen_schwangerverlaufeinstellungen**: `gynverlaufeinstellungen` ↔ `schwangerverlaufeinstellungen`
- **hausapothekenelement_mehrfachverordnungselemente**: `hausapothekenelement` ↔ `mehrfachverordnungselement`
- **heilmittel_hzvunterpositionsnummern**: `heilmittel` ↔ `heilmittel`
- **heilmittel_unterpositionsnummern**: `heilmittel` ↔ `heilmittel`
- **heilmittelbegruendung_icdkatalogeintraege**: `heilmittelbegruendung` ↔ `icdkatalogeintrag`
- **heilmittelbegruendung_sekundaercodes**: `heilmittelbegruendung` ↔ `icdkatalogeintrag`
- **heilmitteldiagnose_blankoheilmittel**: `heilmitteldiagnose` ↔ `heilmittel`
- **heilmitteldiagnose_erforderlichediagnosen**: `heilmitteldiagnose` ↔ `icdkatalogeintrag`
- **heilmitteldiagnose_ergaenzend**: `heilmitteldiagnose` ↔ `heilmittelverordnungsvorlage`
- **heilmitteldiagnose_heilmittelbegruendungen**: `heilmitteldiagnose` ↔ `heilmittelbegruendung`
- **heilmitteldiagnose_keinzurueckzu**: `heilmitteldiagnose` ↔ `heilmitteldiagnose`
- **heilmitteldiagnose_kombi**: `heilmitteldiagnose` ↔ `heilmittelverordnungsvorlage`
- **heilmitteldiagnose_leitsymptomatiken**: `heilmitteldiagnose` ↔ `heilmittelleitsymptomatik`
- **heilmitteldiagnose_vorrangig**: `heilmitteldiagnose` ↔ `heilmittelverordnungsvorlage`
- **heilmittelleitsymptomatik_besonderheiten**: `heilmittelleitsymptomatik` ↔ `heilmittelverordnungsvorlage`
- **heilmittelschein_diagnosefehler**: `heilmittelschein` ↔ `abrechnungsfehler`
- **heilmittelschein_heilmittelleistungen**: `heilmittelschein` ↔ `leistung`
- **heilmittelschein_hmeabrechnungsfehler**: `heilmittelschein` ↔ `abrechnungsfehler`
- **heilmittelschein_irdanfragen**: `heilmittelschein` ↔ `irdanfrage`
- **heilmittelschein_quartalsdiagnosen**: `heilmittelschein` ↔ `diagnose`
- **heilmittelverordnung_termine**: `heilmittelverordnung` ↔ `termin`
- **heilmittelverordnungsvorlage_erforderlichediagnosen**: `heilmittelverordnungsvorlage` ↔ `icdkatalogeintrag`
- **hgnckette_hgnccodes**: `hgnckette` ↔ `hgnccode`
- **homoeoabrechnung_abgerechnetescheine**: `homoeoabrechnung` ↔ `homoeoschein`
- **homoeoabrechnung_abrechnungsdateien**: `homoeoabrechnung` ↔ `datei`
- **homoeoschein_diagnosefehler**: `homoeoschein` ↔ `abrechnungsfehler`
- **homoeoschein_homoeoleistungen**: `homoeoschein` ↔ `homoeoleistung`
- **homoeoschein_irdanfragen**: `homoeoschein` ↔ `irdanfrage`
- **homoeoschein_quartalsdiagnosen**: `homoeoschein` ↔ `diagnose`
- **homoeoteilnahme_teilnahmeformulare**: `homoeoteilnahme` ↔ `datei`
- **htmldocument_attachments**: `htmldocument` ↔ `datei`
- **hzv9erdiagnose_icdkatalogeintraege**: `hzv9erdiagnose` ↔ `icdkatalogeintrag`
- **hzv9erdiagnose_substitutionen**: `hzv9erdiagnose` ↔ `hzvdiagnosesubstitution`
- **hzv9erdiagnoseliste_hzv9erdiagnosen**: `hzv9erdiagnoseliste` ↔ `hzv9erdiagnose`
- **hzvabrechnung_transfercontents**: `hzvabrechnung` ↔ `hzvtransfercontent`
- **hzvabrechnung_ueberweisungen**: `hzvabrechnung` ↔ `karteieintrag`
- **hzvabrechnunggroup_children**: `hzvabrechnunggroup` ↔ `hzvabrechnung`
- **hzvakutdiagnosez_substitutionen**: `hzvakutdiagnosez` ↔ `hzvdiagnosesubstitution`
- **hzvakutdiagnosezliste_hzvakutdiagnosenz**: `hzvakutdiagnosezliste` ↔ `hzvakutdiagnosez`
- **hzvanzahlbedingung_gruppierung_summe**: `hzvanzahlbedingung` ↔ `hzvkatalogeintrag`
- **hzvbedingunggenerell_kassen**: `hzvbedingunggenerell` ↔ `hzvikrefmitdatum`
- **hzvbedingunggenerell_kvbereiche**: `hzvbedingunggenerell` ↔ `hzvgueltigkeitkvbereich`
- **hzvcustomheilmittelliste_heilmittel**: `hzvcustomheilmittelliste` ↔ `heilmittel`
- **hzvdetails_modulteilnahmen**: `hzvdetails` ↔ `hzvdetails`
- **hzvdiagnosebedingung_einschlussliste**: `hzvdiagnosebedingung` ↔ `hzveinschlussdiagnosewrapper`
- **hzveinschreibediagnoseliste_hzveinschreibediagnosen**: `hzveinschreibediagnoseliste` ↔ `hzveinschreibediagnose`
- **hzvfolgeaudiagnose_ersetzungdurch**: `hzvfolgeaudiagnose` ↔ `icdkatalogeintrag`
- **hzvhauskometmedikamentenplan_element**: 
- **hzvhauskometmedikamentenplan_elemente**: `hzvhauskometmedikamentenplan` ↔ `hzvhauskometmedikamentenplan_element`
- **hzvhonoraranlage_hzvkatalogeintraege**: `hzvhonoraranlage` ↔ `hzvkatalogeintrag`
- **hzvhonoraranlage_hzvziffernkraenze**: `hzvhonoraranlage` ↔ `hzvziffernkranz`
- **hzvitvedocument_hzvitvedocumentsendprotocols**: `hzvitvedocument` ↔ `hzvitvedocumentsendprotocol`
- **hzvkatalogeintrag_hzvaltersbedingung**: `hzvkatalogeintrag` ↔ `hzvaltersbedingung`
- **hzvkatalogeintrag_hzvanzahlbedingungen**: `hzvkatalogeintrag` ↔ `hzvanzahlbedingung`
- **hzvkatalogeintrag_hzvarztfunktionenbedingungen**: `hzvkatalogeintrag` ↔ `hzvarztfunktionenbedingung`
- **hzvkatalogeintrag_hzvdiagnosebedingungen**: `hzvkatalogeintrag` ↔ `hzvdiagnosebedingung`
- **hzvkatalogeintrag_hzvgenderbedingung**: `hzvkatalogeintrag` ↔ `hzvgenderbedingung`
- **hzvkatalogeintrag_hzvkatalogeintragdetails**: `hzvkatalogeintrag` ↔ `hzvkatalogeintragdetails`
- **hzvkatalogeintrag_hzvtagesbedingungen**: `hzvkatalogeintrag` ↔ `hzvtagesbedingung`
- **hzvkatalogeintrag_hzvziffernbedingungen**: `hzvkatalogeintrag` ↔ `hzvziffernbedingung`
- **hzvkatalogeintrag_hzvzusatzangaben**: `hzvkatalogeintrag` ↔ `hzvzusatzangabe`
- **hzvkodierhilfeaktion_diagnosen**: `hzvkodierhilfeaktion` ↔ `hzvdiagnosetyp`
- **hzvkodierhilfeaoksportsliste_icdkatalogeintraege**: `hzvkodierhilfeaoksportsliste` ↔ `icdkatalogeintrag`
- **hzvkodierhilfedefinition_auschluesse**: `hzvkodierhilfedefinition` ↔ `hzvkodierhilfeelement`
- **hzvkodierhilfedefinition_ausloeser**: `hzvkodierhilfedefinition` ↔ `hzvkodierhilfeelement`
- **hzvkodierhilfeelement_diagnosen**: `hzvkodierhilfeelement` ↔ `hzvdiagnosetyp`
- **hzvkodierhilfezliste_icdkatalogeintraege**: `hzvkodierhilfezliste` ↔ `icdkatalogeintrag`
- **hzvkostentraeger_hzvikgruppen**: `hzvkostentraeger` ↔ `hzvikgruppe`
- **hzvkrankheitsbildkontext_hzvkrankheitsbilder**: `hzvkrankheitsbildkontext` ↔ `hzvkrankheitsbild`
- **hzvmorbirsadiagnosenliste_hzvmorbirsadiagnosen**: `hzvmorbirsadiagnosenliste` ↔ `hzvmorbirsadiagnose`
- **hzvopsliste_eintraege**: `hzvopsliste` ↔ `hzvopseintrag`
- **hzvpatbegleitungdiagnoseliste_diagnosen**: `hzvpatbegleitungdiagnoseliste` ↔ `hzvpatbegleitungdiagnose`
- **hzvpraeventionsdiagnoseliste_icdkatalogeintraege**: `hzvpraeventionsdiagnoseliste` ↔ `icdkatalogeintrag`
- **hzvschein_diagnosefehler**: `hzvschein` ↔ `abrechnungsfehler`
- **hzvschein_drcleverabrechnungsfehler**: `hzvschein` ↔ `abrechnungsfehler`
- **hzvschein_hzvleistungen**: `hzvschein` ↔ `leistung`
- **hzvschein_irdanfragen**: `hzvschein` ↔ `irdanfrage`
- **hzvschein_krwfehler**: `hzvschein` ↔ `abrechnungsfehler`
- **hzvschein_quartalsdiagnosen**: `hzvschein` ↔ `diagnose`
- **hzvschein_validationerrors**: `hzvschein` ↔ `abrechnungsfehler`
- **hzvteilnehmerverzeichnis_hzvimportkonflikte**: `hzvteilnehmerverzeichnis` ↔ `hzvimportkonflikt`
- **hzvteilnehmerverzeichnis_hzvpatientparticipants**: `hzvteilnehmerverzeichnis` ↔ `hzvpatientparticipant`
- **hzvvertrag_hzvfunktionenmitnebenbedingung**: `hzvvertrag` ↔ `hzvfunktionmitnebenbedingung`
- **hzvvertrag_metainformationen**: `hzvvertrag` ↔ `hzvmetainformation`
- **hzvvertrag_uebergreifendepateinschreibung**: `hzvvertrag` ↔ `hzvvertrag`
- **hzvvertrag_uebergreifendepatteilnahmepruef**: `hzvvertrag` ↔ `hzvvertrag`
- **hzvvertrag_vertragsgruppeteilnahme**: `hzvvertrag` ↔ `patteilnahmevertragsgruppe`
- **hzvvertragsrelationen_akutdiagnosen**: `hzvvertragsrelationen` ↔ `hzvakutdiagnose`
- **hzvvertragsrelationen_hzvaufolgediagnosen**: `hzvvertragsrelationen` ↔ `hzvfolgeaudiagnose`
- **hzvvertragsrelationen_hzvdokumentationsangaben**: `hzvvertragsrelationen` ↔ `hzvdokumentationsangabe`
- **hzvvertragsrelationen_hzvdokumente**: `hzvvertragsrelationen` ↔ `hzvdokument`
- **hzvvertragsrelationen_hzvdokumentenvorlagen**: `hzvvertragsrelationen` ↔ `hzvdokumentenvorlage`
- **hzvvertragsrelationen_hzvfehlermeldungen**: `hzvvertragsrelationen` ↔ `hzvfehlermeldung`
- **hzvvertragsrelationen_hzvformulare**: `hzvvertragsrelationen` ↔ `hzvformular`
- **hzvvertragsrelationen_hzvhibdiagnosen**: `hzvvertragsrelationen` ↔ `hzvhibdiagnose`
- **hzvvertragsrelationen_hzvhonoraranlagen**: `hzvvertragsrelationen` ↔ `hzvhonoraranlage`
- **hzvvertragsrelationen_hzvkodierhilfedefinitionen**: `hzvvertragsrelationen` ↔ `hzvkodierhilfedefinition`
- **hzvvertragsrelationen_hzvkostentraeger**: `hzvvertragsrelationen` ↔ `hzvkostentraeger`
- **hzvvertragsrelationen_hzvkrankheitsbilder**: `hzvvertragsrelationen` ↔ `hzvkrankheitsbild`
- **hzvvertragsrelationen_hzvkrankheitsbildkontexte**: `hzvvertragsrelationen` ↔ `hzvkrankheitsbildkontext`
- **hzvvertragsrelationen_hzvpatbegleitungdiagnoseliste**: `hzvvertragsrelationen` ↔ `hzvpatbegleitungdiagnoseliste`
- **hzvvertragsrelationen_hzvvorgangsvorlagen**: `hzvvertragsrelationen` ↔ `hzvvorgangsvorlage`
- **hzvvorgangsvorlage_hzvzusammenstellungen**: `hzvvorgangsvorlage` ↔ `hzvzusammenstellung`
- **hzvziffernbedingung_ausnahmediagnosen**: `hzvziffernbedingung` ↔ `icdkatalogeintrag`
- **hzvziffernbedingung_ausschlussliste**: `hzvziffernbedingung` ↔ `hzvkatalogeintrag`
- **hzvziffernbedingung_einschlussliste**: `hzvziffernbedingung` ↔ `hzvkatalogeintrag`
- **hzvziffernkranz_hzvziffernkranzebmziffern**: `hzvziffernkranz` ↔ `hzvziffernkranzebmziffer`
- **hzvziffernkranzebmziffer_ebmkatalogeintraege**: `hzvziffernkranzebmziffer` ↔ `ebmkatalogeintrag`
- **icdautosubstitution_substitutes**: `icdautosubstitution` ↔ `icdkatalogeintrag`
- **icdkatalogeintrag_mapicdkatalogeintraege**: `icdkatalogeintrag` ↔ `icdkatalogeintrag`
- **icdkatalogeintrag_thesauruseintraege**: `icdkatalogeintrag` ↔ `icdthesauruseintrag`
- **icdkatalogeintrag_untercodes**: `icdkatalogeintrag` ↔ `icdkatalogeintrag`
- **icdkataloggruppe_icdkatalogeintrag**: `icdkataloggruppe` ↔ `icdkatalogeintrag`
- **icdkatalogkapitel_icdkataloggruppe**: `icdkatalogkapitel` ↔ `icdkataloggruppe`
- **icpc2katalogeintrag_icdkatalogeintraege**: `icpc2katalogeintrag` ↔ `icdkatalogeintrag`
- **immkapitel_children**: `immkapitel` ↔ `immkapitel`
- **immkapitel_dokumente**: `immkapitel` ↔ `abdadokument`
- **immkapitel_verweise**: `immkapitel` ↔ `immkapitelverweis`
- **immkapitel_wirkstoffe**: `immkapitel` ↔ `immwirkstoff`
- **immmetadaten_indikationsbaum**: `immmetadaten` ↔ `immkapitel`
- **impfeintrag_einzelimpfungen**: `impfeintrag` ↔ `einzelimpfung`
- **impfkrankheit_einzelimpfkrankheiten**: `impfkrankheit` ↔ `impfkrankheit`
- **impfkrankheit_impfschema**: `impfkrankheit` ↔ `impfschema`
- **impfplan_impfeintrag**: `impfplan` ↔ `impfeintrag`
- **impfschema_impfschemadetails**: `impfschema` ↔ `impfschemadetails`
- **impfschema_impfstoff**: `impfschema` ↔ `impfstoff`
- **impfschema_impfstoff1**: `impfschema` ↔ `impfstoff`
- **impfschema_impfstoff2**: `impfschema` ↔ `impfstoff`
- **impfschema_impfstoff3**: `impfschema` ↔ `impfstoff`
- **impfschema_impfstoff4**: `impfschema` ↔ `impfstoff`
- **impfschemadetails_impfstoffe**: `impfschemadetails` ↔ `impfstoff`
- **impfstoff_impfkrankheiten**: `impfstoff` ↔ `impfkrankheit`
- **irdbogen_irdmodule**: `irdbogen` ↔ `irdmodul`
- **irdbogen_irdparameter**: `irdbogen` ↔ `irdparameter`
- **irdmodul_irdmodule**: `irdmodul` ↔ `irdmodul`
- **irdmodul_irdparameter**: `irdmodul` ↔ `irdparameter`
- **jsonformanforderungcondition_formulartypen**: `jsonformanforderungcondition` ↔ `formulartyp`
- **jsonformanforderungcondition_terminarten**: `jsonformanforderungcondition` ↔ `terminart`
- **kalender_anzeigeterminarten**: `kalender` ↔ `terminart`
- **kalender_hideforbetriebsstaetten**: `kalender` ↔ `betriebsstaette`
- **kalender_kalenderschemata**: `kalender` ↔ `kalenderschema`
- **kalender_showforgruppen**: `kalender` ↔ `nutzergruppe`
- **kalender_showfornutzer**: `kalender` ↔ `nutzer`
- **kalenderfavorit_kalender**: `kalenderfavorit` ↔ `kalender`
- **kalenderschema_ressourcen**: `kalenderschema` ↔ `termin`
- **karteieintrag_anhang**: `karteieintrag` ↔ `karteieintraganhang`
- **karteieintrag_besonderheitenheilmittel**: `karteieintrag` ↔ `heilmittel`
- **karteieintrag_customformularpages**: `karteieintrag` ↔ `customformularpage`
- **karteieintrag_customkarteieintragentries**: `karteieintrag` ↔ `customkarteieintragentry`
- **karteieintrag_erezeptverordnungen**: `karteieintrag` ↔ `medikamentenverordnung`
- **karteieintrag_formulardiagnosen**: `karteieintrag` ↔ `diagnose`
- **karteieintrag_formularelemente**: `karteieintrag` ↔ `formularelement`
- **karteieintrag_jsonformattachments**: `karteieintrag` ↔ `jsonformattachment`
- **karteieintrag_medikverordnung_bisher**: `karteieintrag` ↔ `medikamentenverordnung`
- **karteieintrag_medikverordnung_plan**: `karteieintrag` ↔ `medikamentenverordnung`
- **karteieintrag_metadatenelement**: `karteieintrag` ↔ `metadatenelement`
- **karteieintrag_patientenzeichnung**: `karteieintrag` ↔ `patientenzeichnung`
- **karteieintrag_s3cteilnahmen**: `karteieintrag` ↔ `s3cteilnahme`
- **karteieintragkette_children**: `karteieintragkette` ↔ `karteieintragkette`
- **karteieintragkette_eintraege**: `karteieintragkette` ↔ `karteieintragketteeintrag`
- **karteieintragketteeintrag_children**: `karteieintragketteeintrag` ↔ `karteieintragketteeintrag`
- **karteieintragtyp_customkarteieintragentries**: `karteieintragtyp` ↔ `customkarteieintragentry`
- **karteieintragtyp_icdfavoriten**: `karteieintragtyp` ↔ `outlineviewelement`
- **karteieintragtyp_macros**: `karteieintragtyp` ↔ `macrotabelleneintrag`
- **karteieintragtyp_vorbelegungvidierungeinzelnutzer**: `karteieintragtyp` ↔ `nutzer`
- **karteieintragtyp_vorbelegungvidierungnutzergruppe**: `karteieintragtyp` ↔ `nutzergruppe`
- **karteiimport_damenachrichten**: `karteiimport` ↔ `damenachricht`
- **karteiimport_patientcandidates**: `karteiimport` ↔ `patient`
- **karteiversandprofil_nutzer**: `karteiversandprofil` ↔ `nutzer`
- **karteiversandprofil_nutzergruppen**: `karteiversandprofil` ↔ `nutzergruppe`
- **kassenbuch_kassenbucheintraege**: `kassenbuch` ↔ `kassenbucheintrag`
- **kassenbuch_tselogs**: `kassenbuch` ↔ `datei`
- **kassenbucheintrag_beleg**: `kassenbucheintrag` ↔ `datei`
- **kassenbucheintrag_belegpositionen**: `kassenbucheintrag` ↔ `belegpositionen`
- **kassenbuchung_aktencandidates**: `kassenbuchung` ↔ `patient`
- **kassenbuchung_privatrechnungcandidates**: `kassenbuchung` ↔ `privatrechnung`
- **kassenzahnaerztlichevereinigung_bkzfiles**: `kassenzahnaerztlichevereinigung` ↔ `datei`
- **kfoplandetails_anamnesecodierung**: `kfoplandetails` ↔ `kzvscheinbemerkung`
- **kfoplandetails_diagnosecodierung**: `kfoplandetails` ↔ `kzvscheinbemerkung`
- **kfoplandetails_geraetecodierung**: `kfoplandetails` ↔ `kzvscheinbemerkung`
- **kfoplandetails_kfoplankriterium**: `kfoplandetails` ↔ `kfoplankriterium`
- **kfoplandetails_therapiecodierung**: `kfoplandetails` ↔ `kzvscheinbemerkung`
- **komponenteninhaltsstoff_entsprichtkomponenten**: `komponenteninhaltsstoff` ↔ `komponenteninhaltsstoff`
- **kontaktdaten_weiteretelefonummern**: `kontaktdaten` ↔ `telefonnummer`
- **kostentraegernichtkvabrechnung_kontaktdaten**: `kostentraegernichtkvabrechnung` ↔ `kontaktdaten`
- **kostentraegernichtkvabrechnung_kostentraegerverknuepfungen**: `kostentraegernichtkvabrechnung` ↔ `kostentraegerverknuepfung`
- **kostentraegersonstigeleistungserbringer_ansprechpartner**: `kostentraegersonstigeleistungserbringer` ↔ `kontaktdaten`
- **kostentraegersonstigeleistungserbringer_verknuepfungen**: `kostentraegersonstigeleistungserbringer` ↔ `kostentraegerverknuepfung`
- **krankenkasse_detailsproabrechnungsbereich**: `krankenkasse` ↔ `kassendetailsproabrechnungsbereich`
- **krankenkasse_institutionskennzeichen**: `krankenkasse` ↔ `institutionskennzeichen`
- **krankenkasse_unzulaessigekven**: `krankenkasse` ↔ `kassenaerztlichevereinigung`
- **krebserkrankung_diagnosen**: `krebserkrankung` ↔ `diagnose`
- **krebserkrankung_krebsregistermeldungen**: `krebserkrankung` ↔ `edokumentation`
- **krebsregisterbogen_krebsregistermodule**: `krebsregisterbogen` ↔ `krebsregistermodul`
- **krebsregisterbogen_krebsregisterparameter**: `krebsregisterbogen` ↔ `krebsregisterparameter`
- **krebsregistermodul_krebsregisterparameter**: `krebsregistermodul` ↔ `krebsregisterparameter`
- **krwbedingung_subbedingungen**: `krwbedingung` ↔ `krwbedingung`
- **krwbedingung_werte**: `krwbedingung` ↔ `krwwert`
- **krwkorrektur_werte**: `krwkorrektur` ↔ `krwwert`
- **krwregel_bedingungen**: `krwregel` ↔ `krwbedingung`
- **krwregel_fehlerbehandlungen**: `krwregel` ↔ `krwfehlerbehandlung`
- **krwregel_pruefungen**: `krwregel` ↔ `krwbedingung`
- **krwwert_icdkatalogeintraege**: `krwwert` ↔ `icdkatalogeintrag`
- **kvschein_abrvorschlagfehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_amboabrechnungsfehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_anerkennungsbescheidepsychotherapie4234**: `kvschein` ↔ `anerkennungsbescheidpsychotherapie`
- **kvschein_belegaerztlichebehandlung4233**: `kvschein` ↔ `belegaerztlichebehandlung`
- **kvschein_clientgeneratedkvfehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_diagnosefehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_drcleverabrechnungsfehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_implantatregistereintraege**: `kvschein` ↔ `implantatregistereintrag`
- **kvschein_irdanfragen**: `kvschein` ↔ `irdanfrage`
- **kvschein_krwfehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_kvscheinfehler**: `kvschein` ↔ `abrechnungsfehler`
- **kvschein_quartalsdiagnosen**: `kvschein` ↔ `diagnose`
- **kvspezifika_erlaubteabrechnungsgebietefuerscheine**: `kvspezifika` ↔ `kvspezifikaerlaubtesabrechnungsgebietfuerschein`
- **kvspezifika_handhabungdatenpakete**: `kvspezifika` ↔ `kvspezifikadatenpaket`
- **kvspezifika_pseudosachkostengnrs**: `kvspezifika` ↔ `ebmkatalogeintrag`
- **kvspezifika_zulaessigeabrechnungsbereiche4106**: `kvspezifika` ↔ `abrechnungsbereich`
- **kvspezifika_zusatzangabensktbedingungen**: `kvspezifika` ↔ `kvspezifikazusatzangabensktbedingung`
- **kvspezifikazusatzangabensktbedingung_erlaubtewertefuerfeld4123**: `kvspezifikazusatzangabensktbedingung` ↔ `kvspezifikaerlaubtewertefuerfeld4123`
- **kvspezifikazusatzangabensktbedingung_unzulaessigescheingruppen**: `kvspezifikazusatzangabensktbedingung` ↔ `kvscheingruppe`
- **kvspezifikazusatzangabensktbedingung_unzulaessigestatusse**: `kvspezifikazusatzangabensktbedingung` ↔ `gkvstatus`
- **kzvabrechnung_serveronlykzvscheine**: `kzvabrechnung` ↔ `kzvschein`
- **kzvschein_befundgruppenleistungen**: `kzvschein` ↔ `leistung`
- **kzvschein_bemaleistungen**: `kzvschein` ↔ `leistung`
- **kzvschein_diagnosefehler**: `kzvschein` ↔ `abrechnungsfehler`
- **kzvschein_gozleistungen**: `kzvschein` ↔ `leistung`
- **kzvschein_irdanfragen**: `kzvschein` ↔ `irdanfrage`
- **kzvschein_laborrechnungen**: `kzvschein` ↔ `zahnarztlaborrechnung`
- **kzvschein_quartalsdiagnosen**: `kzvschein` ↔ `diagnose`
- **kzvschein_validationerrors**: `kzvschein` ↔ `abrechnungsfehler`
- **kzvschein_zahnarztlaborkosten**: `kzvschein` ↔ `leistung`
- **kzvscheindetails_kzvscheinbemerkungen**: `kzvscheindetails` ↔ `kzvscheinbemerkung`
- **kzvscheindetails_mitteilungen**: `kzvscheindetails` ↔ `eformular`
- **kzvvalidierung_pruefmodulfehler**: `kzvvalidierung` ↔ `kzvpruefmodulvalueset`
- **laborauftrag_befunde**: `laborauftrag` ↔ `lb820x`
- **laborauftrag_customanhaenge**: `laborauftrag` ↔ `ldtanhang`
- **laborauftrag_lb820x**: `laborauftrag` ↔ `lb820x`
- **laborausnahmekennziffer_ebmkatalogeintraege**: `laborausnahmekennziffer` ↔ `ebmkatalogeintrag`
- **laborausnahmekennziffer_icdkatalogeintraege**: `laborausnahmekennziffer` ↔ `icdkatalogeintrag`
- **laborausnahmekennziffer_icdkataloggruppen**: `laborausnahmekennziffer` ↔ `icdkataloggruppe`
- **laborbefund_lb820x**: `laborbefund` ↔ `lb820x`
- **laborbefundvidierungkonfig_laborbefundvidierungbedingungen**: `laborbefundvidierungkonfig` ↔ `laborbefundvidierungbedingung`
- **laborbefundvidierungkonfig_vorbelegungvidierungnutzergruppen**: `laborbefundvidierungkonfig` ↔ `nutzergruppe`
- **laborbefundvidierungkonfig_vorbelegungvidierungnutzers**: `laborbefundvidierungkonfig` ↔ `nutzer`
- **laborgeraetworklist_lbtestlbanforderungen**: `laborgeraetworklist` ↔ `lbtestlbanforderung`
- **laborkatalogeintrag_laborkatalogeintragdetails**: `laborkatalogeintrag` ↔ `laborkatalogeintragdetails`
- **labvermesswertzelleentity_allemesswerte**: `labvermesswertzelleentity` ↔ `lbtestlbanforderung`
- **lb820x_anhang**: `lb820x` ↔ `ldtanhang`
- **lb820x_anhangamendbefund**: `lb820x` ↔ `ldtanhang`
- **lb820x_befundgruppe**: `lb820x` ↔ `ldtbefundgruppe`
- **lb820x_fehler**: `lb820x` ↔ `ldtfehler`
- **lb820x_lbtest**: `lb820x` ↔ `lbtestlbanforderung`
- **lb820x_lbtestamendbefund**: `lb820x` ↔ `lbtestlbanforderung`
- **lb820x_material**: `lb820x` ↔ `ldtmaterial`
- **lbantibiogramm_wirkstoffe**: `lbantibiogramm` ↔ `lbwirkstoff`
- **lbdateiimport_abgelehntfehler**: `lbdateiimport` ↔ `ldtfehler`
- **lbdateiimport_laborauftrag**: `lbdateiimport` ↔ `laborauftrag`
- **lbdateiimport_lb820x**: `lbdateiimport` ↔ `lb820x`
- **lbgnr_lbgnrhistory**: `lbgnr` ↔ `lbgnrimport`
- **lblabortestjoin_favoritlabortests**: `lblabortestjoin` ↔ `favoritlabortest`
- **lbtestgruppe_favoritlabortests**: `lbtestgruppe` ↔ `favoritlabortest`
- **lbtestgruppe_lblabortestjoins**: `lbtestgruppe` ↔ `lblabortestjoin`
- **lbtestlbanforderung_anhang**: `lbtestlbanforderung` ↔ `ldtanhang`
- **lbtestlbanforderung_antibiogramme**: `lbtestlbanforderung` ↔ `lbantibiogramm`
- **lbtestlbanforderung_keime**: `lbtestlbanforderung` ↔ `lbkeim`
- **lbtestlbanforderung_lbgnr**: `lbtestlbanforderung` ↔ `lbgnr`
- **lbtestlbanforderung_lbtestelemente**: `lbtestlbanforderung` ↔ `lbtestelement`
- **lbtestlbanforderung_lbzytohpvbefund**: `lbtestlbanforderung` ↔ `lbzytohpvbefund`
- **lbwirkstoff_antibiogrammergebnisse**: `lbwirkstoff` ↔ `lbantibiogrammergebnis`
- **ldtbefundgruppe_lbtest**: `ldtbefundgruppe` ↔ `lbtestlbanforderung`
- **ldtsatzarttabelle_ldtfeldelement**: `ldtsatzarttabelle` ↔ `ldtfeldelement`
- **leistung_dvpbewilligungen**: `leistung` ↔ `dvpbewilligung`
- **leistung_gebuehrenabhaengigkeiten**: `leistung` ↔ `gebuehrenabhaengigkeit`
- **leistung_goaeleistungenonrechnung**: `leistung` ↔ `leistung`
- **leistung_implantatregistereintraege**: `leistung` ↔ `implantatregistereintrag`
- **leistung_kzvvalidationerrors**: `leistung` ↔ `abrechnungsfehler`
- **leistung_leistungsspezifischesachkosten**: `leistung` ↔ `leistung`
- **leistung_sachkosten**: `leistung` ↔ `zusatzangabesachkosten`
- **leistung_validationerrors**: `leistung` ↔ `abrechnungsfehler`
- **leistung_zusatzangabeerkrankung**: `leistung` ↔ `zusatzangabeerkrankung`
- **leistung_zusatzangabegnr5036**: `leistung` ↔ `ebmkatalogeintrag`
- **leistung_zusatzangabehgnc**: `leistung` ↔ `zusatzangabehgnc`
- **leistung_zusatzangabenops**: `leistung` ↔ `zusatzangabeops`
- **leistung_zusatzangabeomimg5070**: `leistung` ↔ `zusatzangabeomim`
- **leistung_zusatzangabeomimp5071**: `leistung` ↔ `zusatzangabeomim`
- **leistungsprotokoll_dokueintraege**: `leistungsprotokoll` ↔ `karteieintrag`
- **macro_allowedkarteieintragtypen**: `macro` ↔ `karteieintragtyp`
- **macro_betriebsstaetten**: `macro` ↔ `betriebsstaette`
- **macro_children**: `macro` ↔ `macro`
- **macro_nutzer**: `macro` ↔ `nutzer`
- **macro_nutzergruppen**: `macro` ↔ `nutzergruppe`
- **mahnung_druckmahnungen**: `mahnung` ↔ `datei`
- **mahnung_druckversionen**: `mahnung` ↔ `druckversion`
- **medicosearchaccount_calendarassignments**: `medicosearchaccount` ↔ `medicosearchcalendarassignment`
- **medicosearchaccount_treatmentassignments**: `medicosearchaccount` ↔ `medicosearchtreatmentassignment`
- **medicosearchaccount_whitelistedresources**: `medicosearchaccount` ↔ `terminart`
- **medikamentarvgroup_medikament**: `medikamentarvgroup` ↔ `medikament`
- **medikamentendetails_arvteilverordnung**: `medikamentendetails` ↔ `arvteilverordnung`
- **medikamentendetails_benefitassessmentgbapatgroups**: `medikamentendetails` ↔ `benefitassessmentgbapatgroup`
- **medikamentendetails_digakontraindikationen**: `medikamentendetails` ↔ `icd10code`
- **medikamentendetails_indikationsbereiche**: `medikamentendetails` ↔ `indikationsbereich`
- **medikamentendetails_preishistorie**: `medikamentendetails` ↔ `medpreishistorie`
- **medikamentendetails_rabattvertraege**: `medikamentendetails` ↔ `rabattvertrag`
- **medikamentendetails_verordnungsartikelarv**: `medikamentendetails` ↔ `verordnungsartikel`
- **medikamentendetails_verordnungsvorgaben**: `medikamentendetails` ↔ `verordnungsvorgabe`
- **medikamentenpharmadetails_arzneimittelkomponenten**: `medikamentenpharmadetails` ↔ `arzneimittelkomponente`
- **medikamentenpharmadetails_atcacode**: `medikamentenpharmadetails` ↔ `atcacode`
- **medikamentenpharmadetails_digaageset**: `medikamentenpharmadetails` ↔ `agegroup`
- **medikamentenpharmadetails_handbriefe**: `medikamentenpharmadetails` ↔ `handbrief`
- **medikamentenpharmadetails_icd10codes**: `medikamentenpharmadetails` ↔ `icd10code`
- **medikamentenpharmadetails_interaktionenklassen**: `medikamentenpharmadetails` ↔ `medikamentinteraktionenklasse`
- **medikamentenpharmadetails_volltextdokumente**: `medikamentenpharmadetails` ↔ `volltextdokument`
- **medikamentenplan_medikamentenplanallergieelemente**: `medikamentenplan` ↔ `medikamentenplanallergieelement`
- **medikamentenplan_medikamentenplanseite**: `medikamentenplan` ↔ `medikamentenplanseite`
- **medikamentenplanseite_medikamentenplanelement**: `medikamentenplanseite` ↔ `medikamentenplanelement`
- **medikamentenverordnung_abgaben**: `medikamentenverordnung` ↔ `medikamentenverordnung`
- **medikamentenverordnung_dosierungen**: `medikamentenverordnung` ↔ `dosierungshistorie`
- **medikamentenverordnung_medikamentinhaltsstoffvos**: `medikamentenverordnung` ↔ `medikamentinhaltsstoffvos`
- **medikamentenverordnung_medplanverordnungen**: `medikamentenverordnung` ↔ `medikamentenverordnung`
- **medikamentenverordnung_verordnungswirkstoffe**: `medikamentenverordnung` ↔ `verordnungswirkstoff`
- **medikamentinteraktionenklasse_interaktionenlinks**: `medikamentinteraktionenklasse` ↔ `medikamentinteraktion`
- **medikamentinteraktionenklasse_interaktionenrechts**: `medikamentinteraktionenklasse` ↔ `medikamentinteraktion`
- **mehrfachverordnungseinstellung_mehrfachverordnungselemente**: `mehrfachverordnungseinstellung` ↔ `mehrfachverordnungselement`
- **metadatenfilter_metadatenelement**: `metadatenfilter` ↔ `metadatenelement`
- **mutterpass_gravidogrammeintraege**: `mutterpass` ↔ `gravidogrammeintrag`
- **mutterpass_mioepaexandimport**: `mutterpass` ↔ `mioepaexandimport`
- **mutterpass_mutterpasschild**: `mutterpass` ↔ `mutterpasschild`
- **mutterpass_mutterpassctgeintraege**: `mutterpass` ↔ `mutterpassctgeintrag`
- **mutterpass_mutterpassdopplereintrage**: `mutterpass` ↔ `mutterpassdopplereintrag`
- **mutterpass_mutterpasselemente**: `mutterpass` ↔ `mutterpasselement`
- **mutterpass_mutterpasslaborwerte**: `mutterpass` ↔ `mutterpasslaborwert`
- **mutterpass_mutterpasspreviouspregnancy**: `mutterpass` ↔ `mutterpasspreviouspregnancy`
- **mutterpass_mutterpasstermine**: `mutterpass` ↔ `mutterpasstermin`
- **mutterpass_mutterpassuseintrage**: `mutterpass` ↔ `mutterpassuseintrag`
- **mutterpassdicomimport_mutterpassdicomimporfeld**: `mutterpassdicomimport` ↔ `mutterpassdicomimportfeld`
- **mutterpasslaborwert_mutterpasslaborwertserologie**: `mutterpasslaborwert` ↔ `mutterpasslaborwert`
- **mutterpassuseintrag_mutterpassuseintragelemente**: `mutterpassuseintrag` ↔ `mutterpassuseintragelement`
- **nachricht_empfaenger**: `nachricht` ↔ `nachrichtempfaenger`
- **nachrichtthread_nachrichten**: `nachrichtthread` ↔ `nachricht`
- **neupatientendaten_patientendatentransfererlaubnisse**: `neupatientendaten` ↔ `patientendatentransfererlaubnis`
- **nutzer_aktivevertraege**: `nutzer` ↔ `hzvvertrag`
- **nutzer_arztstempel**: `nutzer` ↔ `arztstempel`
- **nutzer_bemaleistungsvorschlaege**: `nutzer` ↔ `bemakatalogeintrag`
- **nutzer_besitzstand**: `nutzer` ↔ `goaekatalogeintrag`
- **nutzer_betriebsstaetten**: `nutzer` ↔ `betriebsstaette`
- **nutzer_comfortsignaturnutzerallowed**: `nutzer` ↔ `nutzer`
- **nutzer_dvpvertraege**: `nutzer` ↔ `dvpvertrag`
- **nutzer_ebmleistungsvorschlaege**: `nutzer` ↔ `ebmkatalogeintrag`
- **nutzer_edakennziffern**: `nutzer` ↔ `edakennziffer`
- **nutzer_elgagdas**: `nutzer` ↔ `elgagda`
- **nutzer_fachgruppebar**: `nutzer` ↔ `fachgruppebar`
- **nutzer_gruppen**: `nutzer` ↔ `nutzergruppe`
- **nutzer_hzvabrufcodes**: `nutzer` ↔ `hzvabrufcode`
- **nutzer_hzvteilnehmerverzeichnisse**: `nutzer` ↔ `hzvteilnehmerverzeichnis`
- **nutzer_hzvtelescanaccount**: `nutzer` ↔ `hzvtelescanaccount`
- **nutzer_nutzerrechte**: `nutzer` ↔ `recht`
- **nutzer_praeferiertehonoraranlagen**: `nutzer` ↔ `hzvhonoraranlage`
- **nutzer_s3cinteraktionen**: `nutzer` ↔ `s3cinteraktion`
- **nutzer_s3cvertragsteilnahmen**: `nutzer` ↔ `s3cvertragsteilnahmearzt`
- **nutzer_sonstigesvteilnahmenarzt**: `nutzer` ↔ `svteilnahmearzt`
- **nutzergruppe_nutzergrupperechte**: `nutzergruppe` ↔ `recht`
- **okfebogen_okfeparameter**: `okfebogen` ↔ `okfeparameter`
- **omimgcode_omimpcodes**: `omimgcode` ↔ `omimpcode`
- **opbestellung_sachkosten**: `opbestellung` ↔ `zusatzangabesachkosten`
- **opskatalogeintrag_unteropscodes**: `opskatalogeintrag` ↔ `opskatalogeintrag`
- **otkevent_otkappointments**: `otkevent` ↔ `otkevent`
- **otkevent_otkattachments**: `otkevent` ↔ `otkevent`
- **otkwaitlistentry_currentcalendars**: `otkwaitlistentry` ↔ `kalender`
- **otkwaitlistentry_offeredcalendars**: `otkwaitlistentry` ↔ `kalender`
- **outlineviewelement_alteqmdateien**: `outlineviewelement` ↔ `datei`
- **outlineviewelement_arbeitsplaetze**: `outlineviewelement` ↔ `arbeitsplatz`
- **outlineviewelement_arbeitsplatzgruppen**: `outlineviewelement` ↔ `arbeitsplatzgruppe`
- **outlineviewelement_children**: `outlineviewelement` ↔ `outlineviewelement`
- **outlineviewelement_customstatistikelemente**: `outlineviewelement` ↔ `customstatistikelement`
- **outlineviewelement_dvpkatalogeintraege**: `outlineviewelement` ↔ `dvpkatalogeintrag`
- **outlineviewelement_hiddenfornutzer**: `outlineviewelement` ↔ `nutzer`
- **outlineviewelement_icdkatalogeintraege**: `outlineviewelement` ↔ `icdkatalogeintrag`
- **outlineviewelement_nutzer**: `outlineviewelement` ↔ `nutzer`
- **outlineviewelement_nutzergruppen**: `outlineviewelement` ↔ `nutzergruppe`
- **outlineviewelement_opskatalogeintraege**: `outlineviewelement` ↔ `opskatalogeintrag`
- **outlineviewelement_pinnedbynutzer**: `outlineviewelement` ↔ `nutzer`
- **outlineviewelement_qmrevisionen**: `outlineviewelement` ↔ `qmrevision`
- **outlineviewelement_relevantfuer**: `outlineviewelement` ↔ `nutzergruppe`
- **outlineviewelement_rvgkatalogeintraege**: `outlineviewelement` ↔ `rvgkatalogeintrag`
- **outlineviewelement_toolbaritems**: `outlineviewelement` ↔ `statistiktoolbaritem`
- **outlineviewelement_verantwortlichegroups**: `outlineviewelement` ↔ `nutzergruppe`
- **outlineviewelement_warenvoreinstellungen**: `outlineviewelement` ↔ `warenvoreinstellung`
- **outlineviewelement_zusatzangabeomim**: `outlineviewelement` ↔ `zusatzangabeomim`
- **pappaccount_arztdirektchats**: `pappaccount` ↔ `arztdirektchat`
- **pappaccount_onlinetermineaccounts**: `pappaccount` ↔ `onlinetermineaccount`
- **pappaccount_pappautonachrichtvorlagen**: `pappaccount` ↔ `pappautonachrichtvorlage`
- **pappaccount_pappchats**: `pappaccount` ↔ `pappchat`
- **pappaccount_pappnachrichtvorlagegruppen**: `pappaccount` ↔ `pappnachrichtvorlagegruppe`
- **pappaccount_papppairingrequest**: `pappaccount` ↔ `papppairingrequest`
- **pappaccount_pappsammelnachrichtenchats**: `pappaccount` ↔ `pappsammelnachrichtenchat`
- **pappautonachrichtvorlage_pappautonachrichtregeln**: `pappautonachrichtvorlage` ↔ `pappautonachrichtregel`
- **pappchat_pappmessagejunks**: `pappchat` ↔ `pappmessagejunk`
- **pappchat_pappmessages**: `pappchat` ↔ `pappmessage`
- **pappmessage_dateien**: `pappmessage` ↔ `datei`
- **pappmessagejunk_pappmessages**: `pappmessagejunk` ↔ `pappmessage`
- **pappnachrichtvorlage_dateien**: `pappnachrichtvorlage` ↔ `datei`
- **pappnachrichtvorlage_hidefornutzer**: `pappnachrichtvorlage` ↔ `nutzer`
- **pappnachrichtvorlagegruppe_pappnachrichtvorlagen**: `pappnachrichtvorlagegruppe` ↔ `pappnachrichtvorlage`
- **pappsammelnachricht_dateien**: `pappsammelnachricht` ↔ `datei`
- **pappsammelnachricht_pappmessages**: `pappsammelnachricht` ↔ `pappmessage`
- **pappsammelnachrichtenchat_pappsammelnachrichten**: `pappsammelnachrichtenchat` ↔ `pappsammelnachricht`
- **pappwartezimmerelement_datei**: `pappwartezimmerelement` ↔ `datei`
- **pappwartezimmerelement_xmlnodes**: `pappwartezimmerelement` ↔ `xmlnode`
- **pardetails_karteieintraege**: `pardetails` ↔ `karteieintrag`
- **pardetails_parmesspunkte**: `pardetails` ↔ `parmesspunkt`
- **pardetails_zahnbefundobjectdetails**: `pardetails` ↔ `zahnbefundobjectdetails`
- **patientendetails_aktenzeichen**: `patientendetails` ↔ `aktenzeichen`
- **patientendetails_arzthistorie**: `patientendetails` ↔ `arzthistorieneintrag`
- **patientendetails_atdmpteilnahmen**: `patientendetails` ↔ `atdmpteilnahme`
- **patientendetails_bearbeiterstundensatzwrapper**: `patientendetails` ↔ `bearbeiterstundensatzwrapper`
- **patientendetails_caves**: `patientendetails` ↔ `karteieintrag`
- **patientendetails_datentransfererlaubnisse**: `patientendetails` ↔ `patientendatentransfererlaubnis`
- **patientendetails_fragebogenbatterien**: `patientendetails` ↔ `fragebogenbatterie`
- **patientendetails_genehmigunglhmb**: `patientendetails` ↔ `genehmigunglhmb`
- **patientendetails_guthabenauszahlung**: `patientendetails` ↔ `teilbetrag`
- **patientendetails_guthabeneinzahlung**: `patientendetails` ↔ `teilbetrag`
- **patientendetails_hzvcachedteilnahmen**: `patientendetails` ↔ `hzvcachedteilnahmeinfo`
- **patientendetails_hzvdetails**: `patientendetails` ↔ `hzvdetails`
- **patientendetails_hzvvoreinschreibeleistungen**: `patientendetails` ↔ `leistung`
- **patientendetails_kostenstellenanteile**: `patientendetails` ↔ `kostenstellenanteil`
- **patientendetails_letztegestecktekartenlesedaten**: `patientendetails` ↔ `kartenlesedatum`
- **patientendetails_nonautomatictags**: `patientendetails` ↔ `tag`
- **patientendetails_nonduplicates**: `patientendetails` ↔ `patient`
- **patientendetails_orgcaves**: `patientendetails` ↔ `orgcav`
- **patientendetails_patientdetailsinfoelemente**: `patientendetails` ↔ `patientdetailsinfoelement`
- **patientendetails_patientenquittungen**: `patientendetails` ↔ `patientenquittung`
- **patientendetails_patientrelationships**: `patientendetails` ↔ `patientrelationship`
- **patientendetails_patientverstoesse**: `patientendetails` ↔ `patientverstoss`
- **patientendetails_psychotherapiezaehler**: `patientendetails` ↔ `psychotherapiezaehler`
- **patientendetails_s3cinteraktionen**: `patientendetails` ↔ `s3cinteraktion`
- **patientendetails_s3cteilnahmen**: `patientendetails` ↔ `s3cteilnahme`
- **patientendetails_sonstigesvteilnahmen**: `patientendetails` ↔ `svteilnahme`
- **patientendetails_tags**: `patientendetails` ↔ `tag`
- **patientendetails_teilnahmeauschlusssv**: `patientendetails` ↔ `teilnahmeauschlusssv`
- **patientendetails_weitereaerzte**: `patientendetails` ↔ `betreuarztwrapper`
- **patientendetails_zuzahlungsbefreiungen**: `patientendetails` ↔ `zuzahlungsbefreiung`
- **patientendetailsrelationen_anerkennungsbescheidep**: `patientendetailsrelationen` ↔ `anerkennungsbescheidp`
- **patientendetailsrelationen_behandlungsfaelle**: `patientendetailsrelationen` ↔ `behandlungsfall`
- **patientendetailsrelationen_bgfacharztrechnungen**: `patientendetailsrelationen` ↔ `privatrechnung`
- **patientendetailsrelationen_bgrechnungen**: `patientendetailsrelationen` ↔ `privatrechnung`
- **patientendetailsrelationen_bgunfaelle**: `patientendetailsrelationen` ↔ `bgunfall`
- **patientendetailsrelationen_bgunfallrechnungen**: `patientendetailsrelationen` ↔ `privatrechnung`
- **patientendetailsrelationen_customdatenfelder**: `patientendetailsrelationen` ↔ `customdatenfeld`
- **patientendetailsrelationen_dentalbgrechnungen**: `patientendetailsrelationen` ↔ `privatrechnung`
- **patientendetailsrelationen_diagnosen**: `patientendetailsrelationen` ↔ `diagnose`
- **patientendetailsrelationen_dokumentationen**: `patientendetailsrelationen` ↔ `edokumentation`
- **patientendetailsrelationen_drgabrechnungsfaelle**: `patientendetailsrelationen` ↔ `drgabrechnungsfall`
- **patientendetailsrelationen_dvpscheine**: `patientendetailsrelationen` ↔ `dvpschein`
- **patientendetailsrelationen_ekonsile**: `patientendetailsrelationen` ↔ `ekonsil`
- **patientendetailsrelationen_feerinnerungpatienteninformation**: `patientendetailsrelationen` ↔ `feerinnerungpatienteninformation`
- **patientendetailsrelationen_fekstatussnapshot**: `patientendetailsrelationen` ↔ `fekstatussnapshot`
- **patientendetailsrelationen_femanualerinnerung**: `patientendetailsrelationen` ↔ `femanualerinnerung`
- **patientendetailsrelationen_forderungskonten**: `patientendetailsrelationen` ↔ `forderungskonto`
- **patientendetailsrelationen_formulare**: `patientendetailsrelationen` ↔ `karteieintrag`
- **patientendetailsrelationen_frueherkennungsuntersuchungen**: `patientendetailsrelationen` ↔ `frueherkennungsuntersuchung`
- **patientendetailsrelationen_fusformulare**: `patientendetailsrelationen` ↔ `fusformular`
- **patientendetailsrelationen_heilmittelscheine**: `patientendetailsrelationen` ↔ `heilmittelschein`
- **patientendetailsrelationen_heilmittelverordnungen**: `patientendetailsrelationen` ↔ `heilmittelverordnung`
- **patientendetailsrelationen_homoeoscheine**: `patientendetailsrelationen` ↔ `homoeoschein`
- **patientendetailsrelationen_hzvscheine**: `patientendetailsrelationen` ↔ `hzvschein`
- **patientendetailsrelationen_karteieintraege**: `patientendetailsrelationen` ↔ `karteieintrag`
- **patientendetailsrelationen_konsultationen**: `patientendetailsrelationen` ↔ `konsultation`
- **patientendetailsrelationen_krebserkrankungen**: `patientendetailsrelationen` ↔ `krebserkrankung`
- **patientendetailsrelationen_kvscheine**: `patientendetailsrelationen` ↔ `kvschein`
- **patientendetailsrelationen_kzvscheine**: `patientendetailsrelationen` ↔ `kzvschein`
- **patientendetailsrelationen_medikamentenplan**: `patientendetailsrelationen` ↔ `medikamentenverordnung`
- **patientendetailsrelationen_miomutterpaesse**: `patientendetailsrelationen` ↔ `mutterpass`
- **patientendetailsrelationen_mutterpaesse**: `patientendetailsrelationen` ↔ `mutterpass`
- **patientendetailsrelationen_mutterpassdicomimport**: `patientendetailsrelationen` ↔ `mutterpassdicomimport`
- **patientendetailsrelationen_patientenfrueherkennungsregeln**: `patientendetailsrelationen` ↔ `patientenfrueherkennungsregel`
- **patientendetailsrelationen_patientenschlangeelemente**: `patientendetailsrelationen` ↔ `patientenschlangeelement`
- **patientendetailsrelationen_patientenzeichnungen**: `patientendetailsrelationen` ↔ `patientenzeichnung`
- **patientendetailsrelationen_psychotherapien**: `patientendetailsrelationen` ↔ `psychotherapie`
- **patientendetailsrelationen_psychotherapiestadien**: `patientendetailsrelationen` ↔ `psychotherapiestadium`
- **patientendetailsrelationen_qshgvdokumentationen**: `patientendetailsrelationen` ↔ `qshgvdokumentation`
- **patientendetailsrelationen_rechnungen**: `patientendetailsrelationen` ↔ `privatrechnung`
- **patientendetailsrelationen_rehanachrichten**: `patientendetailsrelationen` ↔ `rehanachricht`
- **patientendetailsrelationen_roentgenbucheintrag**: `patientendetailsrelationen` ↔ `roentgenbucheintrag`
- **patientendetailsrelationen_s3cscheine**: `patientendetailsrelationen` ↔ `kvschein`
- **patientendetailsrelationen_sammelrechnungen**: `patientendetailsrelationen` ↔ `pvsabrechnung`
- **patientendetailsrelationen_sammelscheine**: `patientendetailsrelationen` ↔ `sammelschein`
- **patientendetailsrelationen_thenadocuments**: `patientendetailsrelationen` ↔ `thenadocument`
- **patientendetailsrelationen_uheftuntersuchungen**: `patientendetailsrelationen` ↔ `uheftuntersuchung`
- **patientendetailsrelationen_verordnungen**: `patientendetailsrelationen` ↔ `medikamentenverordnung`
- **patientendetailsrelationen_zahlungsauftraege**: `patientendetailsrelationen` ↔ `zahlungsauftrag`
- **patientendetailsrelationen_zahlungseingaenge**: `patientendetailsrelationen` ↔ `zahlungseingang`
- **patientendetailsrelationen_zahnarztbefunde**: `patientendetailsrelationen` ↔ `zahnarztbefund`
- **patientendetailsrelationen_zahnbonushefteintrag**: `patientendetailsrelationen` ↔ `zahnbonushefteintrag`
- **patientendetailsrelationen_zeiterfassungen**: `patientendetailsrelationen` ↔ `zeiterfassung`
- **patientendetailsrelationen_zeitmessungentimer**: `patientendetailsrelationen` ↔ `zeitmessungtimer`
- **patientengruppe_kvscheine**: `patientengruppe` ↔ `kvschein`
- **patientengruppe_patientengruppenelemente**: `patientengruppe` ↔ `patientengruppenelement`
- **patientengruppe_privatrechnungen**: `patientengruppe` ↔ `privatrechnung`
- **patientenquittung_excludedleistungen**: `patientenquittung` ↔ `leistung`
- **patientenschlange_messages**: `patientenschlange` ↔ `pappwartezimmerstatusnachricht`
- **patientenschlange_schlange**: `patientenschlange` ↔ `patientenschlangeelement`
- **patientenschlange_todoketteneintraege**: `patientenschlange` ↔ `todoketteneintrag`
- **patientenzugriffsrecht_ausnahmebetriebsstaetten**: `patientenzugriffsrecht` ↔ `betriebsstaette`
- **patientenzugriffsrecht_ausnahmenutzer**: `patientenzugriffsrecht` ↔ `nutzer`
- **patientenzugriffsrecht_ausnahmenutzergruppen**: `patientenzugriffsrecht` ↔ `nutzergruppe`
- **patteilnahmevertragsgruppe_hzvvertraege**: `patteilnahmevertragsgruppe` ↔ `hzvvertrag`
- **privatrechnung_anhang**: `privatrechnung` ↔ `datei`
- **privatrechnung_bgformulare**: `privatrechnung` ↔ `bgformular`
- **privatrechnung_chopcodes**: `privatrechnung` ↔ `chopcode`
- **privatrechnung_diagnosefehler**: `privatrechnung` ↔ `abrechnungsfehler`
- **privatrechnung_druckrechnungen**: `privatrechnung` ↔ `datei`
- **privatrechnung_druckversionen**: `privatrechnung` ↔ `druckversion`
- **privatrechnung_errorsforprivatrechnung**: `privatrechnung` ↔ `abrechnungsfehler`
- **privatrechnung_goaeleistungen**: `privatrechnung` ↔ `leistung`
- **privatrechnung_irdanfragen**: `privatrechnung` ↔ `irdanfrage`
- **privatrechnung_leistungsprotokolle**: `privatrechnung` ↔ `leistungsprotokoll`
- **privatrechnung_quartalsdiagnosen**: `privatrechnung` ↔ `diagnose`
- **privatrechnung_teilbetraege**: `privatrechnung` ↔ `teilbetrag`
- **psychotherapie_anerkennungsbescheide**: `psychotherapie` ↔ `anerkennungsbescheidpsychotherapie`
- **psychotherapie_privateanerkennungsbescheide**: `psychotherapie` ↔ `anerkennungsbescheidp`
- **psychotherapie_therapeuten**: `psychotherapie` ↔ `nutzer`
- **psychotherapieinfo_aktionen**: `psychotherapieinfo` ↔ `psychotherapieaktion`
- **psychotherapiestadium_anerkennungsbescheide**: `psychotherapiestadium` ↔ `anerkennungsbescheidpsychotherapie`
- **psychotherapiestadium_therapieebmleistungen**: `psychotherapiestadium` ↔ `leistung`
- **psychotherapiestadium_therapieformulare**: `psychotherapiestadium` ↔ `karteieintrag`
- **psychotherapiezaehlertyp_psychotherapiezaehlergewichte**: `psychotherapiezaehlertyp` ↔ `psychotherapiezaehlergewicht`
- **pvsabrechnung_paddateien**: `pvsabrechnung` ↔ `datei`
- **pvsabrechnung_pvsprivatrechnungen**: `pvsabrechnung` ↔ `privatrechnung`
- **qms_qmdokumente**: `qms` ↔ `outlineviewelement`
- **qsdokumentation_qsmgfachgruppen**: `qsdokumentation` ↔ `qsmgfachgruppe`
- **qsdokumentation_qsmgleistungen**: `qsdokumentation` ↔ `qsmgleistung`
- **qsdokumentation_qsmgringversuche**: `qsdokumentation` ↔ `qsmgringversuch`
- **qsmgleistung_qsmgfachgruppen**: `qsmgleistung` ↔ `qsmgfachgruppe`
- **quickfilter_arbeitsplaetze**: `quickfilter` ↔ `arbeitsplatz`
- **quickfilter_arbeitsplatzgruppen**: `quickfilter` ↔ `arbeitsplatzgruppe`
- **quickfilter_nutzer**: `quickfilter` ↔ `nutzer`
- **quickfilter_nutzergruppen**: `quickfilter` ↔ `nutzergruppe`
- **qzv_ebmkatalogeintrag**: `qzv` ↔ `ebmkatalogeintrag`
- **rarechnung_stfrauslagen**: `rarechnung` ↔ `zahlungsauftrag`
- **rarechnung_verguetungverrechnungen**: `rarechnung` ↔ `verguetungverrechnung`
- **rarechnung_vorschussteilbetraege**: `rarechnung` ↔ `teilbetrag`
- **raum_betten**: `raum` ↔ `bett`
- **rechnungsantwort_rechnungsantwortdateien**: `rechnungsantwort` ↔ `datei`
- **rehaaufnahmedaten_diagnosen**: `rehaaufnahmedaten` ↔ `diagnose`
- **rehabewilligung_diagnosen**: `rehabewilligung` ↔ `diagnose`
- **rehaentlassungsberichtdaten_diagnosen**: `rehaentlassungsberichtdaten` ↔ `diagnose`
- **rehaentlassungsberichtdaten_rehaleistungen**: `rehaentlassungsberichtdaten` ↔ `rehaleistung`
- **rehaentlassungsmeldungdaten_diagnosen**: `rehaentlassungsmeldungdaten` ↔ `diagnose`
- **rehaentlassungsmeldungdaten_rehaanwesenheitszeiten**: `rehaentlassungsmeldungdaten` ↔ `rehaanwesenheitszeit`
- **rehaentlassungsmeldungdaten_rehadurchgefuertemassnahmen**: `rehaentlassungsmeldungdaten` ↔ `rehadurchgefuertemassnahme`
- **rehakindinmutterkind_diagnosen**: `rehakindinmutterkind` ↔ `diagnose`
- **rehanachricht_rehabegleitperson**: `rehanachricht` ↔ `rehabegleitperson`
- **rehanachricht_rehakindinmutterkind**: `rehanachricht` ↔ `rehakindinmutterkind`
- **reharechnung_rehaentgelte**: `reharechnung` ↔ `rehaentgelt`
- **roentgenabfrage_thumbnail**: `roentgenabfrage` ↔ `datei`
- **s3cdokument_leistungserbringergruppen**: `s3cdokument` ↔ `s3cleistungserbringergruppe`
- **s3cfrist_s3cleistungserbringergruppen**: `s3cfrist` ↔ `s3cleistungserbringergruppe`
- **s3cfrist_s3cversichertengruppen**: `s3cfrist` ↔ `s3cversichertengruppe`
- **s3ckatalogeintragdetails_s3cabrechnungszeitenregeln**: `s3ckatalogeintragdetails` ↔ `s3cabrechnungszeitenregel`
- **s3ckatalogeintragdetails_s3canzahlbeschraenkungregeln**: `s3ckatalogeintragdetails` ↔ `s3canzahlbeschraenkungregel`
- **s3ckatalogeintragdetails_s3causschlussregeln**: `s3ckatalogeintragdetails` ↔ `s3causschlussregel`
- **s3cleistungserbringergruppe_parameter**: `s3cleistungserbringergruppe` ↔ `s3cparameter`
- **s3cleistungserbringerkriterium_leistungserbringergruppen**: `s3cleistungserbringerkriterium` ↔ `s3cleistungserbringergruppe`
- **s3cmedcolor_medikament**: `s3cmedcolor` ↔ `medikament`
- **s3cpatientenkriterium_institutionskennzeichen**: `s3cpatientenkriterium` ↔ `institutionskennzeichen`
- **s3cpatientenkriterium_versichertengruppen**: `s3cpatientenkriterium` ↔ `s3cversichertengruppe`
- **s3cpotentialanalyse_historie**: `s3cpotentialanalyse` ↔ `s3cpahistorie`
- **s3cpotentialanalyse_potentiellevertraege**: `s3cpotentialanalyse` ↔ `s3cpotentiellervertrag`
- **s3cpotentiellervertrag_s3cpotvertragkriterien**: `s3cpotentiellervertrag` ↔ `s3cpotvertragkriterien`
- **s3cpotentiellervertrag_vertragskennzeichen**: `s3cpotentiellervertrag` ↔ `s3cvertragskennzeichen`
- **s3cpotvertragkriterien_institutionskennzeichen**: `s3cpotvertragkriterien` ↔ `institutionskennzeichen`
- **s3cpotvertragkriterien_s3causschlussdiagnosen**: `s3cpotvertragkriterien` ↔ `s3ceinschreibediagnose`
- **s3cpotvertragkriterien_s3ceinschreibediagnosen**: `s3cpotvertragkriterien` ↔ `s3ceinschreibediagnose`
- **s3crabattangabe_medikament**: `s3crabattangabe` ↔ `medikament`
- **s3cteilnahme_betreuaertze**: `s3cteilnahme` ↔ `nutzer`
- **s3cverordnungsdatenexport_verordnungsdateien**: `s3cverordnungsdatenexport` ↔ `datei`
- **s3cversichertengruppe_parameter**: `s3cversichertengruppe` ↔ `s3cparameter`
- **s3cvertrag_fristen**: `s3cvertrag` ↔ `s3cfrist`
- **s3cvertrag_funktionen**: `s3cvertrag` ↔ `s3cfunktion`
- **s3cvertrag_leistungserbringergruppen**: `s3cvertrag` ↔ `s3cleistungserbringergruppe`
- **s3cvertrag_leistungserbringerkriterien**: `s3cvertrag` ↔ `s3cleistungserbringerkriterium`
- **s3cvertrag_s3cdokumente**: `s3cvertrag` ↔ `s3cdokument`
- **s3cvertrag_vertragsids**: `s3cvertrag` ↔ `s3cvertragsid`
- **s3cvertrag_vertragskennzeichen**: `s3cvertrag` ↔ `s3cvertragskennzeichen`
- **s3cvertrag_vorausgesetztevertraege**: `s3cvertrag` ↔ `s3cvertrag`
- **s3cvertragsrelationen_bqpakete**: `s3cvertragsrelationen` ↔ `s3c_bqpaket`
- **s3cvertragsrelationen_honoraranlagen**: `s3cvertragsrelationen` ↔ `ebmleistungskatalog`
- **s3cvertragsrelationen_patientenkriterien**: `s3cvertragsrelationen` ↔ `s3cpatientenkriterium`
- **s3cvertragsrelationen_verordnungsdatenexporte**: `s3cvertragsrelationen` ↔ `s3cverordnungsdatenexport`
- **s3cvertragsrelationen_versichertengruppen**: `s3cvertragsrelationen` ↔ `s3cversichertengruppe`
- **sammelerklaerung_listen**: `sammelerklaerung` ↔ `sammelerklaerungliste`
- **sammelerklaerungliste_zeiten**: `sammelerklaerungliste` ↔ `sammelerklaerungzeit`
- **sammelrechnungtyp_privatrechnungtypen**: `sammelrechnungtyp` ↔ `privatrechnungtyp`
- **sammelschein_diagnosefehler**: `sammelschein` ↔ `abrechnungsfehler`
- **sammelschein_irdanfragen**: `sammelschein` ↔ `irdanfrage`
- **sammelschein_quartalsdiagnosen**: `sammelschein` ↔ `diagnose`
- **sbinputfieldtemplate_dropdownvalues**: `sbinputfieldtemplate` ↔ `sbsortedinputfieldvalue`
- **sbprocess_steps**: `sbprocess` ↔ `sbprocessstep`
- **sbprocessstep_attachments**: `sbprocessstep` ↔ `sbattachment`
- **sbprocessstep_inputfields**: `sbprocessstep` ↔ `sbinputfieldentry`
- **sbworkflow_edges**: `sbworkflow` ↔ `sbworkflowedge`
- **sbworkflow_nodes**: `sbworkflow` ↔ `sbworkflownode`
- **sbworkflowmetainfo_tasklabels**: `sbworkflowmetainfo` ↔ `sbworkflowtasklabel`
- **sbworkflownode_attachments**: `sbworkflownode` ↔ `sbattachment`
- **sbworkflownode_inputfields**: `sbworkflownode` ↔ `sbinputfield`
- **schicht_arbeitszeitkonten**: `schicht` ↔ `arbeitszeitkonto`
- **schicht_schichtbewerbungen**: `schicht` ↔ `schichtbewerbung`
- **selektivvertragsrelationen_svdateien**: `selektivvertragsrelationen` ↔ `svdatei`
- **selektivvertragsrelationen_svteilnahmebedingungen**: `selektivvertragsrelationen` ↔ `svteilnahmebedingung`
- **seriellesgeraetcomkette_seriellesgeraetcomeintraege**: `seriellesgeraetcomkette` ↔ `seriellesgeraetcomeintrag`
- **servernachrichttyp_arbeitsplaetze**: `servernachrichttyp` ↔ `arbeitsplatz`
- **servernachrichttyp_arbeitsplatzgruppen**: `servernachrichttyp` ↔ `arbeitsplatzgruppe`
- **servernachrichttyp_nutzer**: `servernachrichttyp` ↔ `nutzer`
- **servernachrichttyp_nutzergruppen**: `servernachrichttyp` ↔ `nutzergruppe`
- **servernachrichttypelement_arbeitsplaetze**: `servernachrichttypelement` ↔ `arbeitsplatz`
- **servernachrichttypelement_arbeitsplatzgruppen**: `servernachrichttypelement` ↔ `arbeitsplatzgruppe`
- **servernachrichttypelement_nutzer**: `servernachrichttypelement` ↔ `nutzer`
- **servernachrichttypelement_nutzergruppe**: `servernachrichttypelement` ↔ `nutzergruppe`
- **statistikergebnis_nutzer**: `statistikergebnis` ↔ `nutzer`
- **steigerungsschema_betriebsstaetten**: `steigerungsschema` ↔ `betriebsstaette`
- **steigerungsschema_privatkassen**: `steigerungsschema` ↔ `krankenkasse`
- **stoffname_stoffgruppen**: `stoffname` ↔ `stoffgruppe`
- **svteilnahmebedingung_institutionskennzeichen**: `svteilnahmebedingung` ↔ `institutionskennzeichen`
- **tag_children**: `tag` ↔ `tag`
- **tag_tagautomationelement**: `tag` ↔ `tagautomationelement`
- **tagautomationelement_tagautomationelemententry**: `tagautomationelement` ↔ `tagautomationelemententry`
- **termin_erbrachteheilmittel**: `termin` ↔ `heilmittel`
- **termin_externetickets**: `termin` ↔ `externesticket`
- **termin_kalender**: `termin` ↔ `kalender`
- **termin_manuallyassociatedtasks**: `termin` ↔ `aufgabe`
- **termin_otkappointments**: `termin` ↔ `otkevent`
- **termin_patientendatentransfererlaubnisse**: `termin` ↔ `patientendatentransfererlaubnis`
- **termin_preptasks**: `termin` ↔ `aufgabe`
- **termin_terminerinnerungen**: `termin` ↔ `terminerinnerung`
- **termin_verknuepfteleistungen**: `termin` ↔ `verknuepfteleistung`
- **termin_zukunftstodos**: `termin` ↔ `todoketteneintrag`
- **terminaenderungfuernachricht_terminerinnerungen**: `terminaenderungfuernachricht` ↔ `terminerinnerung`
- **terminart_ebmfavoriten**: `terminart` ↔ `outlineviewelement`
- **terminart_ebmleistungen**: `terminart` ↔ `leistung`
- **terminart_formulartypen**: `terminart` ↔ `formulartyp`
- **terminart_goaefavoriten**: `terminart` ↔ `outlineviewelement`
- **terminart_goaeleistungen**: `terminart` ↔ `leistung`
- **terminart_preptasks**: `terminart` ↔ `outlineviewelement`
- **terminart_todoketteneintrag**: `terminart` ↔ `todoketteneintrag`
- **terminart_webformularkarteieintragtypes**: `terminart` ↔ `karteieintragtyp`
- **terminartlimit_kalender**: `terminartlimit` ↔ `kalender`
- **terminartlimit_markernoetig**: `terminartlimit` ↔ `tag`
- **terminartlimit_markerverboten**: `terminartlimit` ↔ `tag`
- **terminartlimit_terminarten**: `terminartlimit` ↔ `terminart`
- **terminerinnerungart_modi**: `terminerinnerungart` ↔ `terminerinnerungartmodus`
- **terminerinnerungplan_kalender**: `terminerinnerungplan` ↔ `kalender`
- **terminerinnerungplan_terminarten**: `terminerinnerungplan` ↔ `terminart`
- **terminerinnerungplan_terminerinnerungarten**: `terminerinnerungplan` ↔ `terminerinnerungart`
- **terminkalendertag_termine**: `terminkalendertag` ↔ `termin`
- **terminkette_terminketteeintraege**: `terminkette` ↔ `terminketteeintrag`
- **terminkettesuche_hideforbetriebsstaette**: `terminkettesuche` ↔ `betriebsstaette`
- **terminkettesuche_terminkettesucheeintraege**: `terminkettesuche` ↔ `terminkettesucheeintrag`
- **terminloeschgrundmuster_terminarten**: `terminloeschgrundmuster` ↔ `terminart`
- **terminsuche_dontsearchinbetriebsstaetten**: `terminsuche` ↔ `betriebsstaette`
- **terminsuche_hideforbetriebsstaette**: `terminsuche` ↔ `betriebsstaette`
- **terminsuche_onlinekalenderaccounts**: `terminsuche` ↔ `onlinetermineaccount`
- **terminsuche_subterminsuchen**: `terminsuche` ↔ `terminsuche`
- **terminsuche_suchkalender**: `terminsuche` ↔ `kalender`
- **terminsuche_suchresource**: `terminsuche` ↔ `terminart`
- **terminsucheanforderung_customcalendars**: `terminsucheanforderung` ↔ `kalender`
- **terminsucheanforderung_subanforderungen**: `terminsucheanforderung` ↔ `terminsucheanforderung`
- **terminverschiebegrundmuster_terminarten**: `terminverschiebegrundmuster` ↔ `terminart`
- **terminwartelisteeintrag_angebotenekalender**: `terminwartelisteeintrag` ↔ `kalender`
- **terminwartelisteeintrag_erlaubnisregeln**: `terminwartelisteeintrag` ↔ `terminwartelisteeintragregel`
- **terminwartelisteeintrag_nichtbereiche**: `terminwartelisteeintrag` ↔ `terminwartelisteeintragbereich`
- **terminwartelisteeintrag_nurbereiche**: `terminwartelisteeintrag` ↔ `terminwartelisteeintragbereich`
- **terminwartelisteeintrag_nurbetriebsstaetten**: `terminwartelisteeintrag` ↔ `betriebsstaette`
- **terminwartelisteeintrag_nurkalender**: `terminwartelisteeintrag` ↔ `kalender`
- **thenadocument_thenadocumentversions**: `thenadocument` ↔ `thenadocumentversion`
- **ticket_attachments**: `ticket` ↔ `datei`
- **ticket_aufgaben**: `ticket` ↔ `aufgabe`
- **ticket_emails**: `ticket` ↔ `email`
- **ticket_kommentare**: `ticket` ↔ `kommentar`
- **ticket_label**: `ticket` ↔ `aufgabenlabel`
- **ticket_relatedtickets**: `ticket` ↔ `ticketrelation`
- **ticket_termine**: `ticket` ↔ `termin`
- **ticket_timeslots**: `ticket` ↔ `timeslot`
- **ticketautomationsregel_projekte**: `ticketautomationsregel` ↔ `projekt`
- **ticketstatus_automationsregeln**: `ticketstatus` ↔ `ticketautomationsregel`
- **todokette_eintraege**: `todokette` ↔ `todoketteneintrag`
- **todovorlage_moeglicheraeume**: `todovorlage` ↔ `raum`
- **tsplocalpackage_arbeitsplatzgruppen**: `tsplocalpackage` ↔ `arbeitsplatzgruppe`
- **uheftuntersuchung_mioepaexandimport**: `uheftuntersuchung` ↔ `mioepaexandimport`
- **uheftuntersuchung_uheftelemente**: `uheftuntersuchung` ↔ `uheftelement`
- **vddsaustauschobjekt_anlagen**: `vddsaustauschobjekt` ↔ `datei`
- **vddsaustauschobjekt_rechnungen**: `vddsaustauschobjekt` ↔ `privatrechnung`
- **verordnungsartikelarvgroup_verordnungsartikel**: `verordnungsartikelarvgroup` ↔ `verordnungsartikel`
- **verordnungsvorgabe_dokumente**: `verordnungsvorgabe` ↔ `abdadokument`
- **verordnungsvorgabe_verordnungsvorgabebestimmungen**: `verordnungsvorgabe` ↔ `verordnungsvorgabebestimmung`
- **verordnungsvorgabeelement_dokumente**: `verordnungsvorgabeelement` ↔ `abdadokument`
- **vertretung_vertretungdurch**: `vertretung` ↔ `nutzer`
- **vidierergruppe_vidierer**: `vidierergruppe` ↔ `vidierer`
- **vidierungsstatus_vidierergruppen**: `vidierungsstatus` ↔ `vidierergruppe`
- **vidierungsstatus_zuvidierendurch**: `vidierungsstatus` ↔ `nutzer`
- **vitalwerteeinstellungennode_vitalwerteeinstellungennodechildren**: `vitalwerteeinstellungennode` ↔ `vitalwerteeinstellungennode`
- **volltextdokument_volltextinformationen**: `volltextdokument` ↔ `volltextinformation`
- **ware_nachbestellungelement**: `ware` ↔ `warenbestellelement`
- **warenbestellung_dokumente**: `warenbestellung` ↔ `datei`
- **warenbestellung_warenbestellelement**: `warenbestellung` ↔ `warenbestellelement`
- **warendetails_customerspecificconditions**: `warendetails` ↔ `customerspecificcondition`
- **warendetails_ersatzwarendetails**: `warendetails` ↔ `ersatzwarendetails`
- **warendetails_generika**: `warendetails` ↔ `warendetails`
- **warendetails_standardwarenhaendler**: `warendetails` ↔ `warenhaendler`
- **warendetails_typen**: `warendetails`
- **warendetails_warendetailbilder**: `warendetails` ↔ `datei`
- **warendetails_warendetailshaendlernummer**: `warendetails` ↔ `warendetailshaendlernummer`
- **warendetails_warendetailsrabatte**: `warendetails` ↔ `warendetailsrabatt`
- **warenlieferung_dokumente**: `warenlieferung` ↔ `datei`
- **warenlieferung_warenbestellungen**: `warenlieferung` ↔ `warenbestellung`
- **warenlieferung_warenlieferelemente**: `warenlieferung` ↔ `warenlieferelement`
- **webformularvorlage_dateien**: `webformularvorlage` ↔ `datei`
- **xbesuchsanliegen_todos**: `xbesuchsanliegen` ↔ `todokette`
- **xdt_xdteintraege**: `xdt` ↔ `xdteintrag`
- **xdtsatzart_xdtsatzarteintraege**: `xdtsatzart` ↔ `xdteintrag`
- **xmlnode_xmlnodes**: `xmlnode` ↔ `xmlnode`
- **zahlung_fokoverrechnungen**: `zahlung` ↔ `fokoverrechnung`
- **zahlungsauftrag_fremdgeldverrechnungen**: `zahlungsauftrag` ↔ `fremdgeldverrechnung`
- **zahlungsauftrag_verguetungverrechnungen**: `zahlungsauftrag` ↔ `verguetungverrechnung`
- **zahlungseingang_fremdgeldverrechnungen**: `zahlungseingang` ↔ `fremdgeldverrechnung`
- **zahlungseingang_verguetungverrechnungen**: `zahlungseingang` ↔ `verguetungverrechnung`
- **zahn_karteieintraege**: `zahn` ↔ `karteieintrag`
- **zahn_tags**: `zahn` ↔ `tag`
- **zahn_zahnbefundobjectdetails**: `zahn` ↔ `zahnbefundobjectdetails`
- **zahn_zahnkroneflaechen**: `zahn` ↔ `zahnkroneflaeche`
- **zahn_zahnwurzeln**: `zahn` ↔ `zahnwurzel`
- **zahnarztbefund01_zaehne**: `zahnarztbefund01` ↔ `zahn`
- **zahnarztbefund_tags**: `zahnarztbefund` ↔ `tag`
- **zahnarztbefundpa_zaehne**: `zahnarztbefundpa` ↔ `zahn`
- **zahnarztbefundsbi_zaehne**: `zahnarztbefundsbi` ↔ `zahn`
- **zahnarztfalldetails_kvscheine**: `zahnarztfalldetails` ↔ `kvschein`
- **zahnarztfalldetails_kzvscheine**: `zahnarztfalldetails` ↔ `kzvschein`
- **zahnarztfalldetails_privatrechnungen**: `zahnarztfalldetails` ↔ `privatrechnung`
- **zahnkroneflaeche_karteieintraege**: `zahnkroneflaeche` ↔ `karteieintrag`
- **zahnkroneflaeche_zahnbefundobjectdetails**: `zahnkroneflaeche` ↔ `zahnbefundobjectdetails`
- **zahnwurzel_karteieintraege**: `zahnwurzel` ↔ `karteieintrag`
- **zahnwurzel_zahnbefundobjectdetails**: `zahnwurzel` ↔ `zahnbefundobjectdetails`
- **zifferneinschraenkung_betriebsstaetten**: `zifferneinschraenkung` ↔ `betriebsstaette`
- **zifferneinschraenkung_nutzer**: `zifferneinschraenkung` ↔ `nutzer`
- **zifferneinschraenkung_nutzergruppen**: `zifferneinschraenkung` ↔ `nutzergruppe`
- **zswindowtutorial_windowtutorialelemente**: `zswindowtutorial` ↔ `zswindowtutorialelement`
- **zusatzangabesachkosten_warenvoreinstellungen**: `zusatzangabesachkosten` ↔ `warenvoreinstellung`
- **zuschlag_stellen**: `zuschlag` ↔ `stelle`

---

> Dokumentierte Tabellen: 1056 | Bridge-Tabellen: 1147 | Ausgeblendet: 126 (intern/sensitiv)
> Generiert aus PostgreSQL `information_schema`