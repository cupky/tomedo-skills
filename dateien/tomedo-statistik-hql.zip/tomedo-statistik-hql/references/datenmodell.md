# tomedo Datenmodell — Vollständige Tabellenreferenz (v10)

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- v8 (2026-04-27): + PatF-Rendering-Mechanismus, + Bridge karteieintrag_formularelemente, + MPSS-Alt-System mutabo, + mutabo-ke.text-Erkenntnis (von SKILL_v7→hierhin geroutet), + Therapiezeilen-Kürzel, praxiseigen (K02-Legacy)

> Stand: 16.04.2026 · Neu ggü. v6: Abschnitt 7 um No-Show-Semantik (`warda`, `isneuerpatient`) + nutzer-/terminart-Feldkorrekturen · Neuer Abschnitt 13a Email-System · Abschnitt 17 um Outlook-Import-Artefakte ergänzt. Quellen: Threads NoShow, Email-Vorlagen, Therapeuten-Dashboard (03–04/2026).

Extrahiert aus ~25 Hersteller-Standard-Queries + Zollsoft-Herstellerdokumentation (03/2026, 1.056 Tabellen).
Felder mit Typ-Angabe (bigint, text, timestamp, boolean, real, integer) stammen aus dem Hersteller-Dump.
Felder ohne Typ-Angabe sind aus dem Query-Kontext abgeleitet.

> ⚠ **Datenschutz:** Felder wie `nachname`, `vorname`, `geburtsdatum` in der Tabelle `patient`
> sind personenbezogene Daten. Im finalen SELECT nur `patient.ident` (als patientID) und
> berechnetes Alter (`alter_jahre`) verwenden. Klartextdaten dürfen in Temp-Tabellen als
> JOIN-Hilfsspalten stehen, aber niemals im Ergebnis an die KI übermittelt werden.
> Bei explorativen Queries mit Klartextdaten im Ergebnis: Daten nur lokal in tomedo nutzen,
> vor Rückmeldung an die KI personenbezogene Spalten entfernen.
> Siehe SKILL.md → Datenschutz by Design.

## Inhaltsverzeichnis

1. Patient & Stammdaten
2. Karteieinträge & Formulare
3. Diagnosen
4. Leistungen & Abrechnung (EBM)
5. Leistungen & Abrechnung (GOÄ/Privat)
6. Leistungen & Abrechnung (HZV/Selektivverträge)
7. Termine & Kalender
8. Medikamente & Verordnungen
9. Heilmittel
10. Zuweiser
11. Psychotherapie
12. Todo & Raum
12a. Patientenliste (Panel → Patientenliste)
13. Nachrichten & Erinnerungen
13a. Email-System (Vorlagen, Versand, Erinnerungen)
14. Online-Terminkalender (OTK2)
15. Organisatorisches Cave
16. Beschäftigungsstatus & Sozialmedizin
17. Abwesenheiten & Kapazitätsplanung
18. KI- und LLM-Subsystem (Zollsoft 09/2026)

---

## 1. Patient & Stammdaten

### patient (Alias: p)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK. Muss als `patientid` ausgegeben werden |
| nachname, vorname | text | Name. † am Ende = verstorben. **⚠ Nicht im finalen SELECT — nur in Temp-Tabellen** |
| geburtsdatum | timestamp | Geburtsdatum (cast as date empfohlen). **⚠ Nicht im finalen SELECT — stattdessen alter_jahre berechnen** |
| geburtsname | text | Geburtsname. **⚠ Nicht im finalen SELECT** |
| titel | text | Titel (Dr., Prof., etc.) |
| ort | text | Wohnort |
| zuletztaufgerufen | timestamp | Letzter Aufruf der Akte |
| gesperrt | integer | 0/NULL = nein, 1 = ja. **Gesperrte Patienten ggf. in Analysen filtern** |
| patientendetails_ident | bigint | FK → patientendetails |

### patientendetails (Alias: pd)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| patientendetailsrelationen_ident | bigint | FK → patientendetailsrelationen |
| geschlecht | text | "M", "W", "U" (Unbekannt) |
| freitext | text | Patienteninfo |
| freitextinfofeld | text | Patienteninfo 2 |
| privatpatient | boolean | NOT NULL |
| selbststaendig | boolean | |
| beruf | text | Beruf |
| namenszusatz | text | Namenszusatz |
| sterbedatum | timestamp | Sterbedatum |
| ersterbesuch | timestamp | Datum des ersten Besuchs |
| datumletzterbesuch | timestamp | Datum des letzten Besuchs (tomedo-gepflegt) |
| datumtherapieende | timestamp | Datum Therapieende |
| arzt_ident | bigint | FK → nutzer (Erstbehandler) |
| kontaktdaten_ident | bigint | FK → kontaktdaten |
| hausarzt_ident | bigint | FK → hausarzt |
| folgearzt_ident | bigint | FK → hausarzt (Folgearzt/Weiterbehandler) |
| ueberweiser_ident | bigint | FK → hausarzt (Überweiser auf PD-Ebene) |
| privattarif_ident | bigint | FK → steigerungsschema |
| aktuellegvkkartendaten_ident | bigint | FK → kartendaten (GKV) |
| aktuellepvkartendaten_ident | bigint | FK → kartendaten (PKV) |
| arbeitgeber_ident | bigint | FK → arbeitgeber |
| pflegegrad_ident | bigint | FK → pflegegrad |
| beschaeftigungsstatus_ident | bigint | FK → beschaeftigungsstatus |
| schwerbehindertenausweis_ident | bigint | FK → schwerbehindertenausweis |
| privatezusatzversicherung | boolean | |
| stationaerezusatzversicherung | boolean | |
| privatezusatzversicherungtext | text | Name der Zusatzversicherung |
| statuspsychotherapiefall | integer | NULL/0 = abgeschlossen, 1 = Warteliste, 5 = beantragt, 10 = aktiv |
| aktuelleranerkennungsbescheidpsychotherapie_ident | bigint | FK → anerkennungsbescheidpsychotherapie |
| aktuellepsychotherapieinfo_ident | bigint | FK → psychotherapieinfo |
| kilometerzumwohnort | real | Entfernung zum Wohnort |
| nationalitaet | text | Ländercode der Nationalität (für BG-Abrechnung) |
| rechnungsdaten_ident | bigint | FK → rechnungsdaten |
| boolcol1, boolcol2 | boolean | Praxisspezifische Ja/Nein-Felder |
| stringcol1, stringcol2, stringcol3, stringcol4 | text | Praxisspezifische Freitextfelder |

### patientendetailsrelationen
Eigenständige Zwischentabelle. `ident` wird von `patientendetails.patientendetailsrelationen_ident` referenziert.

### kontaktdaten (Alias: kd)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| telefon | text | Telefon |
| telefon2 | text | Dienstlich |
| telefon3 | text | Weiteres Telefon |
| handynummer | text | Handy |
| email | text | E-Mail |
| fax | text | Fax |
| homepage | text | Homepage |
| dsinfo | integer | Bitfeld für Kommunikationspräferenzen (siehe enums) |
| willkeinesms | boolean | NOT NULL |
| adresse_ident | bigint | FK → adresse |
| kimemail | text | KIM-E-Mail-Adresse |
| kimstatus | integer | KIM-Status |

### adresse
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| strasse | text | Straße (kann Hausnummer enthalten; für PD.kontaktdaten.adresse immer ohne) |
| hausnummer | text | Hausnummer |
| plz | text | PLZ |
| ort | text | Ort |
| land | text | Ländercode |
| bundesland | text | Bundesland |

### kartendaten (Alias: k)
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| dtype | Diskriminator: `PVKartendaten`, `PVEGKDaten` |
| versichertennummer | Versichertennummer (GKV) |
| versichertennummerOnline | Versichertennummer bei PVEGKDaten |
| kassenname | Kassenname laut Karte |
| abrechnenderKostentraegerName | Name des abrechnenden KT |
| abrechnenderKostentraeger | IK des abrechnenden KT |
| kostentraeger | IK Kostenträger |
| IK | Institutionskennzeichen |
| versichertenstatus4112 | Versichertenstatus (eGK) |
| versichertenart | Versichertenart (KVK) |
| ersatzverfahrenTyp | integer | 0 = kein EV, 1 = KVK, 2 = EGK, 3 = Überweisungsschein, 4 = Sonstiger Behandlungsausweis (Polizei, Bundeswehr, Asyl) |
| privatkasse_ident | FK → krankenkasse |
| aktuelleskartenlesedatum_ident | FK → kartenlesedatum |
| wop, rechtskreis, besondere_personengruppe, versichertenstatus_rsa, dmp_kennzeichnung | Weitere KV-Felder |
| gueltigvon, gueltigbis, gueltigbis4110 | Gültigkeitszeiträume |
| statusergaenzungostwest | Ost/West-Status |

### krankenkasse
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| kurzname | Kurzname |
| iknummer | IK-Nummer |
| registernr | Registernummer |
| kostentraegergruppe_ident | FK → kostentraegergruppe |

### kostentraegergruppe
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| code | 01=AOK, 02=SVLFG, 03=IKK, 04=BKK, 05=Knappschaft, 11/12=VdEk |

### hausarzt
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| titel | text | Titel |
| vorname | text | **⚠ Nicht im finalen SELECT** |
| nachname | text | **⚠ Nicht im finalen SELECT** |
| lanr | text | LANR (Lebenslange Arztnummer) |
| bsnr | text | BSNR |
| fachgebiet | text | Fachgebiet |
| kuerzel | text | Kürzel |
| geschlecht | text | "M","W","U" |
| visible | boolean | NOT NULL |
| praxiskontakt_ident | bigint | FK → kontaktdaten |
| praxisname | text | Praxisname |
| typ | integer | 0/NULL=Arzt, 1=Apotheke |
| kimemail | text | KIM-E-Mail |

### nutzer (Alias: n)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| nachname, vorname | text | Name. **⚠ Nicht im finalen SELECT** |
| kuerzel | text | Kürzel (primäre Anzeige) |
| titel | text | Titel |
| lanr | text | Lebenslange Arztnummer |
| leistungserbringer | boolean | NOT NULL. True = abrechnungsberechtigter Arzt |
| isvertragsarzt | boolean | NOT NULL |
| isadmin | boolean | NOT NULL |
| nutzertyp | integer | NOT NULL |
| geschlecht | text | Geschlecht des Nutzers |
| visible | boolean | NOT NULL |
| arztgruppe_ident | bigint | FK → arztgruppe |
| fachgruppefuerbudget_ident | bigint | FK → fachgruppebar |
| psychotherapiequalifikation_ident | bigint | FK → psychotherapiequalifikation (VT/TP/AP/systemisch, KJP) |
| asrenabled | boolean | NOT NULL. Spracherkennung aktiviert (relevant für B39) |
| lastlogin | timestamp | Letzter Login |
| stundensatzincent | integer | Stundensatz in Cent (für Kostenrechnung) |
| color | text | Nutzerfarbe |
| patient_ident | bigint | FK → patient (Nutzer als Patient, optional) |
| abrechnungauf_ident | bigint | FK → nutzer (Abrechnung auf anderen Arzt umgelegt) |
| berufsbezeichnung | text | Berufsbezeichnung — an der Referenzinstallation durchgehend leer |
| qualification_type | text | Qualifikations-Typ — an der Referenzinstallation nur bei einem einzigen Nutzer befüllt (Wert "03"), Bedeutung unbekannt |

> ⚠ **nutzer hat KEIN Feld `name` oder `fachbezeichnung`** (validiert 03/2026). Korrekte Name-Felder: `vorname`, `nachname`, `kuerzel` (zuverlässig), `titel`. Team-Zuordnung (Arzt/Psycho/Physio) muss über Terminarten-Profile oder EBM/KE-Signaturen erfolgen, nicht über nutzer-Stammdaten.
> 
> `psychotherapiequalifikation` (referenziert über `psychotherapiequalifikation_ident`) hat **KEIN Feld `name`** — Spalten noch zu explorieren.

### tag
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| beschreibung | Marker-Text |
| gruppe | Boolean (Gruppenmarker) |
| visible | Boolean |

### Weitere Stammdaten-Tabellen
- **arbeitgeber**: `ident`, `name`, `visible`
- **pflegegrad**: `ident`, `grad` (integer), `letzteaenderung`
- **steigerungsschema**: `ident`, `name` (Privattarif)
- **betriebsstaette**: `ident`, `name`, `kuerzel`, `isnebenbetriebsstaette` (boolean), `visible`, `hauptbetriebsstaette_ident` (FK → betriebsstaette, Fallback-BST)
- **arbeitsplatz**: `ident`, `name`
- **kartenlesedatum**: `ident`, `datum`, `jahr`, `quartal`, `kartendaten_ident`, `betriebsstaette_ident`

### neupatientendaten
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| geburtsdatum | timestamp | **⚠ Nicht im finalen SELECT** |
| nachname | text | **⚠ Nicht im finalen SELECT** |
| vorname | text | **⚠ Nicht im finalen SELECT** |
| versicherungsart | text | GKV, PKV, SZ, BG, ... |
| versicherer | text | Kassenname |
| geschlecht | text | Wie bei patient |
| kontaktdaten_ident | bigint | FK → kontaktdaten |
| zugeordneterpatient_ident | bigint | FK → patient (nach Zuordnung) |

### schwerbehindertenausweis
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| gradderbehinderung | integer | GdB (0–100) |
| gueltigvon | timestamp | Gültig von |
| gueltigbis | timestamp | Gültig bis |
| kriegsgeschaedigt | boolean | |
| merkzeichen_g, merkzeichen_b, merkzeichen_bl, merkzeichen_h, merkzeichen_rf, merkzeichen_gl, merkzeichen_tbl, merkzeichen_ag, merkzeichen_1kl | boolean | Merkzeichen |

### arztgruppe
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| arztgruppe | text | Arztgruppencode |
| bezeichnung | text | Bezeichnung |
| punkte | real | Bewertung GOP 32001 der Fachgruppe |

### psychotherapiequalifikation
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| verhaltenstherapie | boolean | NOT NULL |
| tiefenpsychologischepsychotherapie | boolean | NOT NULL |
| analytischepsychotherapie | boolean | NOT NULL |
| systemischepsychotherapie | boolean | NOT NULL |
| behandelterwachsene | boolean | NOT NULL |
| behandeltkinderundjugendliche | boolean | NOT NULL |
| darfgruppenabrechnen | boolean | NOT NULL |
| darfemdrabrechnen | boolean | NOT NULL |
| darfhypnoseabrechnen | boolean | NOT NULL |

---

## 2. Karteieinträge & Formulare

### karteieintrag (Alias: k) / karteieintragwithplaintext
`karteieintragwithplaintext` ist eine View mit Plaintext-Zugriff. Für alle Queries empfohlen.

> ⚠ **Achtung Spaltenumfang:** Die folgende Feldliste gilt der **Basistabelle** `karteieintrag`. Die View `karteieintragwithplaintext` hat laut DB-Dump nur **15 Spalten** und enthaelt insbesondere `serveronlyplaintext`, `name`, `headerline1` und `additionaltext` **nicht**. Fuer Textanalysen die Basistabelle verwenden. `serveronlyplaintext` ist ausserdem im aeusseren SELECT nicht projizierbar (funktioniert nur innerhalb eines CTE) — Nutzlast aus `text` lesen.
>
> Ebenfalls validiert (2026-07-29, MAIL-Aus bei KAN und WOD): `name`, `headerline1` und `additionaltext` sind zu **0 % befuellt**. Der Email-Betreff ist nicht separat auswertbar.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK. Als `karteieintragid` ausgeben |
| dtype | varchar | NOT NULL. Diskriminator (z.B. `'Formular'`) |
| datum | timestamp | Datum |
| behandlungsdatum | — | Behandlungsdatum |
| text | text | Textinhalt |
| diagnosekurz | — | ICD-Code bei Diagnoseneinträgen |
| visible | boolean | NOT NULL |
| karteieintragtyp_ident | bigint | FK → karteieintragtyp |
| mediatyp_ident | bigint | FK → karteieintragmediatyp |
| formulartyp_ident | bigint | FK → formulartyp |
| betriebsstaette_ident | bigint | FK → betriebsstaette |
| dokumentierendernutzer_ident | bigint | FK → nutzer |
| letzternutzer_ident | bigint | FK → nutzer |
| arzt_ident | bigint | FK → nutzer |
| rezept_ident | bigint | FK → rezept |
| termin_ident | bigint | FK → termin. ⛔ an der Referenzinstallation **0 von 281.034 befüllt** (validiert 2026-09-08, Fenster 11/2025–09/2026) — **kein** nutzbarer Pfad KE→Termin |
| diagnose_ident | bigint | FK → diagnose (**direkter Pfad** KE→Diagnose — bei DIA und DDI 1:1 belegt, siehe §3) |
| druckdatum | timestamp | ⛔ an der Referenzinstallation **616/617 NULL** — praktisch nicht gepflegt |
| letzteaenderungam | timestamp | ⛔ an der Referenzinstallation **1024/1024 NULL** — nicht für Dokumentationsanalysen nutzbar |
| heilmittel_1_ident, heilmittel_1b_ident, heilmittel_1c_ident, heilmittel_2_ident | bigint | FK → heilmittel |
| kvschein_ident | bigint | FK → kvschein |
| abrechnungstyp | integer | 1=KV, 4=HZV |
| headerline1 | text | Kassenname |
| json | text | JSON-Daten (abhängig von dtype) |
| additionaltext | text | Zusatztext |
| status | integer | Unterschiedliche Bedeutung je nach dtype. Für EArztbriefe: -1=Sendefehler, 0=Neu, 1=Versandt, 2=Bestätigt |
| serveronlyplaintext | text | Plaintext (serveronly, für Views) |
| elektronischeau_ident | bigint | FK → elektronischeau |

> ⚠ **Feldrealitaet der Referenzinstallation:** `letzteaenderungam` und `druckdatum` sind an der Referenzinstallation **nicht befuellt** (validiert 2026-07-29: 1.024/1.024 bzw. 616/617 NULL). Die Beschreibung „Letzte Aenderung (fuer Dokumentationsanalysen)" gilt fuer die Referenzinstallation nicht. Fuer zeitliche Nutzer-Aktivitaetsanalysen ist ausschliesslich `datum` verwendbar — und das nur, wenn der Nutzer `dokumentierendernutzer_ident` ist. Bei `letzternutzer_ident` ist `datum` das Dokument-/Rechnungsdatum, nicht der Bearbeitungszeitpunkt.

### karteieintragtyp
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| kuerzel | z.B. `'BES'` (Besuch) |


> **Semantik der Anamnese-Typen an der Referenzinstallation (validiert 2026-08-13).** ANA trägt Arzt-Eigentext, T trägt neben
> Therapiezeilen auch die mutabo-Fragebogen-Stubs. Belege: von 476 geprüften Indikationstreffern in `ANA`
> war **keiner** mutabo-markiert, und sie verteilten sich auf 15 dokumentierende Nutzerkürzel; in `T` liegen
> dagegen 13.847 markierte Stubs. `ANA` ist damit die verlässliche Quelle für ärztliche Anamnese- und
> Beurteilungstexte — mittlere Textlänge seit 2015 stabil 340–450 Zeichen, **ohne** Bruch an der Migration
> 11/2025, Bestand ab 2010 vorhanden und ab 2014 belastbar.
>
> Reihenfolge der Trägerqualität für Beurteilungstexte: `ANA` (hoch, Eigentext) > `ÜBW` (klein, 120–180
> Zeichen) > `NOTIZ`/`K` (unsystematisch) > `KRH` (eingehende Klinikpost, für Eigenbeurteilungen praktisch
> leer) > `DOK-ALT`/`SCAN`/`DOK` (nur Bildunterschrift, Inhalt nicht in der DB).


### karteiEintragMediaTyp
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| name | z.B. `'custom'` |

### formulartyp
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| kuerzel | Kürzel |
| name | Name (z.B. `'Heilmittelverordnung'`, `'PrivateHeilmittelverordnung'`, `'F2400'`, `'F2402'`) |
| musternummer | z.B. `'13'`=Physio, `'14'`=Podologie, `'18'`=Ergo |

### formularelement
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| wert | Wert/Antwort |
| bezeichner | Feldbezeichner |

### customformularelement
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| feldname | Benutzerdefinierter Feldname |
| formularelement_ident | FK → formularelement |

### CustomKarteiEintragEntry (EAV-Modell)
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| name | Feldbezeichner (bei Patientenformularen generisch: `v1`, `v2`, ...; bei Vitalwerten: sprechender Name) |
| value | Wert/Antwort |
| auswahl | Auswahl (z.B. bei BMI, MPSS) |
| modus | Feldtyp (siehe unten) |
| removed | Boolean |

**Bekannte modus-Werte:**
| modus | Bedeutung | Beispiel |
|-------|-----------|---------|
| `Checkbox` | Ja/Nein-Feld | Patientenformular-Fragen |
| `Mehrfachauswahl` | Mehrere Optionen wählbar | Patientenformular-Fragen |
| `Text` | Freitextfeld | Patientenformular, Vitalwerte-Freitext |
| `Trennlinie` | Layout-Element (kein Datenwert) | Formularstruktur |
| `TextLabel` | Beschriftung (kein Datenwert) | Formularstruktur |
| `Auswahl` | Einfachauswahl/Dropdown | MPSS, Urinstatus (EW, GLUC, BIL, LEU, ERY, KET, UBG, ph) |
| `Checkbox mit Text` | Checkbox mit Freitextfeld | — |
| `BMI` | BMI-Eingabefeld | Wert in `value`, berechnet |
| `Blutdruck` | Blutdruck-Eingabefeld | systolisch/diastolisch |
| `Puls` | Puls-Eingabefeld | — |

### angefordertesjsonformular (arzt-direct Patientenformulare)
Speichert den Versand-Request für ein arzt-direct Patientenformular. Das ausgefüllte Formular landet als `karteieintrag` (dtype=`'Formular'`) in der Kartei.
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| responseid | Antwort-ID (leer wenn noch nicht ausgefüllt) |
| verschicktanemailadresse | E-Mail-Adresse des Empfängers |
| zuletztverschickt | Timestamp des letzten Versands |
| formular_ident | FK → karteieintrag (das tomedo-interne Formular-Template) |
| patient_ident | FK → patient (direkter Pfad!) |
| termin_ident | FK → termin (verknüpfter Termin, optional) |
| jsonformtemplateid | arzt-direct Template-ID |
| link | arzt-direct URL zum Ausfüllen |
| formulartyp_ident | FK → formulartyp |
| nutzer_ident | FK → nutzer (versendender Nutzer) |
| visible | Boolean |
| formgroupid | arzt-direct Formulargruppen-ID |
| emaillautformular | Vom Patienten im Formular angegebene E-Mail |
| geburtsdatumlautformular | Vom Patienten angegebenes Geburtsdatum |
| nachnamelautformular | Vom Patienten angegebener Nachname |
| vornamelautformular | Vom Patienten angegebener Vorname |
| versichertennummerlautformular | Vom Patienten angegebene Versichertennummer |
| neupatientendaten_ident | FK (für Neupatientenregistrierung) |

### Patientenformulare — Datenpfad & Muster

**Zwei Speicherpfade für Formularinhalte:**

Patientenformulare (arzt-direct) speichern ihre Daten auf **zwei Ebenen** im selben Karteieintrag:

| Ebene | Tabelle | Bridge | Inhalt |
|-------|---------|--------|--------|
| **Antworten** | `formularelement` | `karteieintrag_formularelemente` | Patientenantworten mit **sprechenden Feldnamen** (`bezeichner`) und Werten (`wert`) |
| **Formularstruktur** | `CustomKarteiEintragEntry` | `karteieintrag_customKarteiEintragEntries` | Formular-Layoutdefinition mit generischen Namen (`v1`–`v22`) und Feldtypen (`modus`) |

Für Datenanalysen ist fast immer **`formularelement`** der richtige Pfad.

**Gesamter Datenpfad (arzt-direct → Antwortdaten):**
```
angefordertesjsonformular (Versand-Request)
  → angefordertesjsonformular_formulare (Bridge)
    → karteieintrag (dtype='Formular', KE-Typ FOR, mediaTyp 'Formular')
      → karteieintrag_formularelemente (Bridge)
        → formularelement (bezeichner = Feldname, wert = Patientenantwort)
```

**Formulartyp-Namenskonvention:** `Patientenformular_<interner-name>` in `formulartyp.name`.
- `Patientenformular_psf-quartal` = Quartalfragebogen
- `Patientenformular_psf-teil1und2-v4` = psf-Erstanamnese (Version 4)
- Suffix kann Versionsnummern enthalten (`-v2`, `-v4`) — Formulare ändern sich über die Zeit.

**Briefkommando-Syntax:** `$[formularLinks PatF-<n>]$` generiert den arzt-direct Link.
- `$[formularLinks PatF-Quartalfragebogen]$`
- `PatF-` = Patientenformular-Prefix im Briefsystem

**Quartalfragebogen (`psf-quartal`) — Bekannte Feldbezeichner (Stand 03/2026):**

Schmerzcharakteristik: `schmerzintensität` (0–100 NRS), `schmerzcharakter`, `schmerzattackendauer`, `schmerzregion`, `körperregion`, `schmerzort-andere`, `schmerzabnahme`, `schmerzabnahme-p`, `funktionseinschränkung`.
Kopfschmerz-Modul: `genau-kopfsz`, `kopfschmerz-episodendauer`, `kopfschmerz-regelm`, `kopfschmerz-tagepromonat`, `kopfschmerz-tageprowoche`, `kopfschmerz-tabletteneinnahme`, `kopfschmerzkalender`, `kopf-begleit`, `weiterer-kopf-begleit`.
Scores: `vkorff` (von Korff Grad), `schmerz-vkorff` (Matrix), `disability-score`, `disability-punkte`, `intensitaet-ruhe-bel` (Matrix).
Medikation: `medi1`–`medi4` (Name), `medi1-t`–`medi4-t` (Einnahmezeitpunkt), `regelmäßige-schmemedis`.
Behandlung: `behandlungserfolg`, `behandlungen-effekt` (Matrix pro Verfahren), `behandlungen-effekt-ander`.
AU & Verfahren: `anz-autage`, `bg-verf`, `andereverf`.
Sonstiges: `anliegen`, `stärke-arbeit`, `stärke-einschränk`, `stärke-freizeit`.
Bildgebung: `rö-loc-dat`, `mrt-loc-dat`, `ct-loc-dat`.

⚠ Feldbezeichner können sich bei neuen Formularversionen ändern. Bei neuen Versionen explorativ prüfen.

**Vitalwerte in CustomKarteiEintragEntry (formularübergreifend stabil):**
| name | modus | Häufigkeit (Stand 03/2026) | Anmerkung |
|------|-------|---------------------------|-----------|
| `Blutdruck` | Blutdruck | ~3.300 | Vitalwert |
| `Text:` | Text | ~3.800 | Freitext-Notiz |
| `RR (Freitext):` | Text | ~1.100 | Blutdruck-Freitext |
| `BMI` | BMI | ~550 | Vitalwert |
| `MPSS` | Auswahl | ~190 | Nur ab Patientenformular-Ära (~11/2025). Historisch: siehe MPSS-Freitext |
| `Puls` | Puls | ~175 | Vitalwert |
| Urinstatus (`EW`, `GLUC`, `BIL`, `LEU`, `ERY`, `KET`, `UBG`, `ph`) | Auswahl | je ~26 | Urinschnelltest-Ergebnisse |


> **Feldbezeichner der psf-Erstanamnese und des Quartalfragebogens (validiert 2026-08-13 gegen die
> SurveyJS-JSON und gegen `formularelement`).**
>
> | Bezeichner | Formular | Typ | Befüllung 2025–2026 | Ø Zeichen |
> |---|---|---|---|---|
> | `anliegen` | **beide** (Quartal + Erstanamnese) | text | 7.862 | 51 |
> | `ziele` | nur Erstanamnese | comment | 1.703 | 114 |
> | `textfield_therapieziele` | Reha-/Verordnungskontext | text | 796 | 71 |
> | `terminanfrage-grund` · `absage-grund` | **Kontaktformular** Terminvereinbarung | text | 478 / 513 | 76 / 46 |
> | `anfragegrund` | Kontaktformular | Auswahl | 2.248 | 19 |
> | `vorop-kh-reha` | Erstanamnese | tagbox | — | — |
> | `op1`–`op4` / `opdat1`–`opdat4` | Erstanamnese | text | — | — |
>
> Drei Fallstricke: (1) `anliegen` trägt **denselben** Bezeichner in Quartalfragebogen und Erstanamnese —
> die Trennung läuft über das Vorhandensein erstanamnese-exklusiver Bezeichner (`ziele`, `op1`,
> `vorop-kh-reha`) am selben Karteieintrag, nicht über den Feldnamen. (2) Das Terminvereinbarungsformular
> hat **kein** `anliegen`-Feld; seine Felder heißen `Frage1`…`Frage66` plus `terminanfrage-grund`. (3) Ab
> etwa 15 Zeichen Mittelwert ist ein Feld Freitext, darunter Auswahlfeld — `neue-ziele` (5) und
> `zielerreicht` (6) sind trotz sprechendem Namen keine Freitextquellen.
>
> **`op1`–`op4` plus `vorop-kh-reha` sind die strukturierte Voroperationshistorie.** Für die Trennung
> „bereits operiert" gegen „Indikation offen" ist damit kein Regex auf `z.n. op` nötig.


### PatF-Rendering-Mechanismus (arzt-direct serverseitig)

Die narrative Zusammenfassung im `karteieintrag.text` eines PatF-Rückschriebs
wird **nicht** lokal in tomedo aus einem Template generiert, sondern **serverseitig
bei arzt-direct** gerendert und als fertiger HTML-Text (`<p>...</p>`-Markup)
in tomedo übernommen.

**Empirischer Beleg** (Patient 32385, KE-Ident 184575236481482752, PatF-Terminvereinbarung):

| Feld | Wert | Aussage |
|---|---|---|
| `karteieintrag.text` | `<p>Laut PSF bestehen Schmerzen...</p>` | Fertiger HTML-Text, enthält narrative Zusammenfassung |
| `formulartyp.customkarteitextformat` | leer | Kein lokales Template |
| `karteieintragtyp.customkarteitextformat` | leer | Auch kein KE-Typ-Template |
| `formulartyp.kettenausloeser` | leer | Keine Aktionskette beteiligt |
| `karteieintrag.jsonformsource` | 1 | Quelle: arzt-direct-Rückschrieb |
| `karteieintrag.jsonformresponseid` | 24-stellige Hex-ID | Verknüpfung zu arzt-direct |

**Konsequenz für Queries:** Der narrative Text ist ausschließlich über `karteieintrag.text`
auslesbar. Rohantworten der Einzelfragen (57 Felder bei PatF-Terminvereinbarung)
parallel in `formularelement` über Bridge `karteieintrag_formularelemente`.

**Konsequenz für Kommandos:** `$[formularEintrag ...]$` liefert nur Einzelfelder,
nicht die Zusammenfassung. Für den kompletten Text: `$[karteiEintragWert FOR text _ N]$`
(validiert 21.04.2026 via Builder-UI).

### MPSS (Mainzer Stadienmodell) — Zwei-Quellen-Modell

MPSS-Daten existieren in zwei Quellen mit unterschiedlicher Struktur:

| Zeitraum | Quelle | Pfad | Format |
|----------|--------|------|--------|
| Bis ~10/2025 | PSY-Karteieinträge (Freitext) | `karteieintragwithplaintext` mit KE-Typ `'PSY'` | Freitext, variabel (siehe Regex) |
| Ab ~11/2025 | Patientenformular / CustomKarteiEintragEntry | `CKEE.name = 'MPSS'`, `modus = 'Auswahl'` | Strukturiert |

**Historische Freitext-Varianten (PSY-Karteieinträge, n≈2.660, Zeitraum 04/2024–10/2025):**
Häufigste: `MPSS 2` (1.150×), `MPSS 3` (795×), `MPSS 1` (407×). Weitere: `MPSS: 2`, `MPSS II`, `MPSS = 3`, `Gerbershagen: II`, `MPSS Stadium III`, `MPSS Gesamtstadium = 3`. Teils Therapeuten-Kürzel als Suffix (`MPSS 2 Ulli`, `MPSS 1 (MJ)`, `(IG) MPSS 2`, `TM MPSS 3`). Vereinzelt Doppeleinträge (`MPSS 1 MPSS II`).

**Regex-Pattern für Freitext-Extraktion (PostgreSQL):**
```sql
CASE
  WHEN ke.text ~* 'kein\s+MPSS' THEN NULL
  WHEN ke.text ~* '(?:MPSS|Gerbershagen)\s*[=:.\\-]?\s*(?:Gesamt)?(?:Stadium)?\s*[=:.\\-]?\s*(III|3)' THEN 3
  WHEN ke.text ~* '(?:MPSS|Gerbershagen)\s*[=:.\\-]?\s*(?:Gesamt)?(?:Stadium)?\s*[=:.\\-]?\s*(II|2)' THEN 2
  WHEN ke.text ~* '(?:MPSS|Gerbershagen)\s*[=:.\\-]?\s*(?:Gesamt)?(?:Stadium)?\s*[=:.\\-]?\s*(I|1)' THEN 1
END AS mpss_stadium
```
⚠ Reihenfolge III→II→I ist wichtig (sonst matcht `I` auch auf `III`). Parserate: 99,7%.

⚠ `%Chronifizierung%` im PSY-Text matcht massenhaft Basisgruppe-Textbausteine (edukativ, kein Score) — **nicht** als MPSS-Suchkriterium verwenden. Nur `%MPSS%` und `%Gerbershagen%` sind zuverlässig.

### Alt-System mutabo — Fragebogen-Rückschriebe (pre-11/2025)

Vor der tomedo-Migration nutzte die Praxis das Fragebogen-System **mutabo** (Domäne `mutabo.szdd.de`). Patienten füllten Fragebögen über einen Patienten-Link aus; die Antworten wurden als **Text-Rückschrieb in die Kartei** geschrieben, verteilt auf mehrere KE-Typen. Keine strukturierten `formularelement`-Einträge wie im heutigen PatF-System — alles liegt in `karteieintrag.text`.

**Identifikations-Marker (aus Beispieldaten):**

| Marker | Fundort | Funktion |
|---|---|---|
| `XD:MUTABO.MUTA02` | `karteieintrag.text` (KE-Typ E) | Rückschrieb-Quellmarker mit Zeitstempel |
| `https://mutabo.szdd.de/s/{N}` | In Rückschrieben eingebettet | Session-Link, `{N}` ist vermutlich Formular-ID |
| `Quartalsfragebogen abgeschlossen` | KE-Typ A0, Header-Zeile | Rückschrieb-Typ-Indikator |

**Drei Parse-Muster (nach KE-Typ):**

**Muster A — Kompakt-Scores in PSY (psychotherapeutische Verlaufs-Messung):**
```
MFH 12.00              ← Multidim. Wohlbefinden (MFHW in späterer Variante)
D 11.00   A 11.00   S 10.00   ← DASS-21 (Depression / Angst / Stress)
Korff 3.00             ← von Korff Chronifizierungs-Grad
```
Varianten: `MFH` vs. `MFHW`; zeilenweise `D 11.00 / A 11.00 / S 10.00` vs. Kompaktform `D-A-S: 12-13-8`; Leere Werte als `-` oder `-----`. Wiederholt sich pro Quartalsvorstellung → **Längsschnitts-Verlaufsinstrument**. Beispieldaten zeigten 4 Messpunkte in 6 Monaten für denselben Patienten.

⚠ Abgrenzung zu MPSS-Freitext-Parser: Beide sitzen in KE-Typ PSY, aber die MPSS-Zeile (`MPSS 2`, `Gerbershagen II` etc.) ist ein separater Textbaustein — MPSS-Regex und mutabo-Score-Regex sind **disjunkt** und können in einer SQL-Query parallel laufen.

**Muster B — Numerische Ausführlich-Scores in A0 (Quartalsfragebogen-Detail):**
```
nrsAkt 4.00 · nrsMittel 2.00 · nrsMax 5.00          ← NRS (drei Varianten)
korffDisability 4.00 · korffIntensity 76.67 · korff 3.00   ← Korff mit Subscores
mfh - · d - · a - · s - · mcs - · pcs -              ← Platzhalter für Sub-Score-Felder
```
Alle numerischen Felder regex-fähig (`feldname\s+\d+\.\d{2}`). MCS/PCS als Felder sichtbar aber in Beispieldaten nicht befüllt → SF-12/SF-36-Module möglicherweise vorhanden, in Praxis-Testdaten nicht benutzt.

**Muster C — Strukturiertes Key:Value Freitext (ANA, A1, A2, C, C1, F1, FOR, G1, MED, O1, E, E1):**

| KE-Typ | Inhalt |
|---|---|
| `ANA` | Schmerz-Anamnese: Lokalisation, Ausstrahlung, Charakteristik, VAS (in Ruhe / bei Belastung), Funktionseinschränkungen, Anliegen, Zielerreichung |
| `A1` | Schmerztyp, Schmerzhäufigkeit (Dauer/Bewegung/Attacken), Intensität, Verbesserung/Verschlimmerung durch, Ursache, Zusammenhängende Beschwerden, Sonstige Erkrankungen (Checkliste), Allergien |
| `A2` | Sucht/Genuss: Rauchen, Trinken, Drogen; psychosoziale Faktoren |
| `C` / `C1` | Aktuelle Tätigkeit, **AU (ja/nein)**, **GdB**, GdB-beantragt, Sozialanamnese (Ehe/Partner/Kinder) |
| `F1` | Bisherige/Aktuelle Behandlungen mit Effekt-Kategorien: *kein Effekt / wenig Effekt / guter Effekt / nicht durchgeführt*. Behandlungen: Akupunktur, Ergotherapie, Physiotherapie, Heilpraktiker, CT-gestützte Schmerztherapie, Psychotherapie, KH-Aufenthalte, Reha/Kur, Einspritzungen ins Nervengebiet, weitere |
| `FOR` | Aktuelle Behandlungen (Rückschrieb-Variante von F1) |
| `G1` | **Schmerzschulung besucht ja/nein**, Behandelnde Ärzte |
| `MED` | Aktuelle Schmerzmedikamente, Andere Medikamente, Probierte Schmerzmedikamente, Eigene Medikamente und Nahrungsergänzungsmittel; je mit `Name / Dosis / Häufigkeit` |
| `O1` | Operation (Name, Datum) |
| `E` / `E1` | Eigenaktivitäten (Sport etc.) mit Intensität/Häufigkeit |

Muster C ist durchgehend `Feldname: Freitext`-Form pro Zeile. Mehrfach-Werte (Sonstige Erkrankungen, Funktionseinschränkungen) als Komma-Liste oder `-` präfixierte Bullet-Liste.

**Identifikation eines mutabo-Rückschriebs:**

```sql
-- Alle Alt-Rückschriebe (pre-Migration) finden:
ke.text ~ 'MUTABO|mutabo\.szdd\.de'
-- Optional enger: nur wenn XD:MUTABO.MUTAxx Marker vorhanden
ke.text ~ 'XD:MUTABO\.MUTA\d+'
```

⚠ Die Screenshots der Session waren **Testdaten**, nicht reale Patientendaten. Struktur ist bestätigt, **Befüllungs-Qualität über reale Patienten-Kohorte muss empirisch geprüft werden** (siehe Backlog B53).

**Abgrenzung Alt-System (mutabo) vs. Post-Migration (tomedo PatF):**

| Dimension | mutabo (pre-11/2025) | tomedo PatF (ab 11/2025) |
|---|---|---|
| Speicherort | `karteieintrag.text` (Freitext, mehrere KE-Typen) | `formularelement` (strukturiert, per Bridge) + narrative Zusammenfassung in `karteieintrag.text` |
| KE-Typ | PSY, A0, ANA, A1, A2, C, C1, F1, FOR, G1, MED, O1, E, E1 | `dtype='Formular'`, FOR |
| Auslese | Regex auf Freitext (wie MPSS-Pattern) | Feldweiser Zugriff über `formularelement.bezeichner/wert` |
| Fragebogen-Typ-Info | Aus Markern (`Quartalsfragebogen abgeschlossen`, URL) | `formulartyp.name` (`Patientenformular_psf-quartal` etc.) |
| Wiedervorstellungs-Frequenz | Quartalsweise (Muster A in PSY) | Quartalsweise (PatF-Quartal) |

#### Phase-C-Validierung — Marker-Verlust ab 2023 systematisch (Phase 2-Thread, 23.04.2026)

Validiert an 3 Patienten mit mutabo-Historie 2022–2026. Der mutabo-Rückschrieb hat **drei Epochen** mit unterschiedlicher Marker-Dichte:

| Epoche | Zeitraum | Header-Träger | Erkennungs-Marker | Beispiel |
|---|---|---|---|---|
| **A** (Start) | 07–09/2022 | PSY selbst | `XD:MUTABO.MUTA01` + `Schmerzfragebogen abgeschlossen` | `XD:MUTABO.MUTA01 16.08.2022 13:19:20 Schmerzfragebogen abgeschlossen mfh 12.00 d 13.00 a 10.00 s 10.00 sbss 18.00` |
| **B** (URL-Phase) | 11–12/2022 | A0 | `https://mutabo.szdd.de/s/{N}` + `Quartalsfragebogen abgeschlossen` | `Quartalsfragebogen abgeschlossen https://mutabo.szdd.de/s/75 mfh – d – a – s – …` |
| **C** (Kurzform, Hauptvolumen) | ab ~01/2023 bis 10/2025 | PSY | **keine Marker** — nur Score-Zeile | `MFHW - D-A-S: ----- Korff 3.00` (32 Zeichen) |

**Phase-C-Signatur (validiert anhand 14/16 Einträgen bei 2 unabhängigen Patienten):**
- KE-Typ `PSY`
- Textlänge `<50` Zeichen
- Regex-Match auf `Korff\s+\d+\.\d+` ODER `^MFHW?\s*[-0-9]`
- Zusätzlich separate MPSS-Zeile pro Set möglich: `MPSS\s+(\d|[IVX]+)` oder `MPSS Gesamtstadium [IVX]+`

**Abgrenzung zu False Positives:**
- Lange PSY-Einträge (>200 Zeichen) mit `Korff`-Erwähnung sind Therapie-Verlaufsnotizen, kein Rückschrieb
- Reine Psycho-Patienten ohne Schmerztherapie-Kontext haben keine mutabo-Rückschriebe in PSY — PSY ist dort ausschließlich Therapie-Journal
- URL-Marker `mutabo\.szdd\.de` schlägt in DOK/MAIL-Ein auch bei E-Mails an, die mutabo erwähnen (~70% False-Positive-Rate gemessen)

**Konsequenz für Queries:** Detection muss **zweigleisig** sein:
```sql
-- Gleis 1: Marker-basiert (Phase A + B, 2022)
ke.text ~ 'XD:MUTABO\.' OR ke.text ~ 'mutabo\.szdd\.de'
-- Gleis 2: Syntax-basiert (Phase C, 2023+)
(kt.kuerzel = 'PSY' AND LENGTH(ke.text) < 50
 AND (ke.text ~* 'Korff\s+[0-9]+\.[0-9]+' OR ke.text ~* '^MFHW?\s'))
```

**Volumen-Implikation:** Die 30.000 PSY-Treffer aus der vorausgehenden Exploration sind **obere Grenze** — enthält Phase-C-Rückschriebe (Ziel) UND reine Therapie-Verlaufsnotizen (Störsignal). Die Syntax-Länge-Bedingung `<50 Zeichen` trennt beide sauber.


> **Nutzlast der Rückschriebe: praktisch leer (validiert 2026-08-13).** Die mutabo-Rückschriebe liegen
> ausschließlich in **KE-Typ `T`**, nicht in `ANA`: 174 (2022) · 5.394 (2023) · 4.783 (2024) · 3.496 (2025) =
> 13.847 markierte Einträge, 137–151 Zeichen im Mittel (Maximum 744–2.563). Davon enthält **ein einziger**
> das Wort „anliegen", 45 das Wort „ziel", einer „operation". Es ist ein Verweis-Stub, kein Fragebogen-Export.
>
> Konsequenz für Auswertungen: Fragebogeninhalte der Prä-Migrationsära sind über die Kartei **nicht**
> rekonstruierbar. Wer sie braucht, braucht das Alt-System selbst — was an der Referenzinstallation als Zugangsweg abgelehnt ist.
> Zweite Konsequenz siehe Abschnitt „Therapiezeilen-Kürzel (T / SCHMA / THE)": die Stubs verfälschen jede
> T-basierte Kontaktzählung.


### Bridge-/Relationstabellen Kartei
- **patientendetailsrelationen_karteieintraege**: `karteieintraege_ident`, `patientendetailsrelationen_ident`
- **patientendetailsrelationen_formulare**: `formulare_ident`, `patientendetailsrelationen_ident`
- **patientendetails_caves**: `caves_ident`, `patientendetails_ident`
- **karteieintrag_formularelemente**: `karteieintrag_ident` → `formularelemente_ident`
- **karteieintrag_customKarteiEintragEntries**: `karteieintrag_ident` → `customKarteiEintragEntries_ident`
- **angefordertesjsonformular_formulare**: `angefordertesJSONformular_ident` → `formulare_ident`
- **patientendetails_tags**: `patientendetails_ident` → `tags_ident`
- **patientendetails_orgcaves**: `orgcaves_ident` → `patientendetails_ident`

---

**karteieintrag_formularelemente** — Bridge zu Formularelement

| Spalte | Typ | Zweck |
|---|---|---|
| `karteieintrag_ident` | bigint | FK → karteieintrag |
| `formularelemente_ident` | bigint | FK → formularelement (Plural!) |

Verbindet einen Formular-Karteieintrag (`dtype='Formular'`) mit seinen Einzelfeldern.
Bei PatF-Terminvereinbarung typischerweise ~57 Einträge pro Karteieintrag.
Query-Pattern siehe `query-bausteine.md` §29.

### mutabo-Rückschriebe (pre-11/2025): json leer, Payload nur in text

Die Zollsoft-Basistabelle `karteieintrag` hat vier Felder, die auf strukturierte JSON-Rückschriebe hindeuten: `json`, `jsonformrueckschriebstatus`, `jsonformgelesen`, `jsonformsource`, `jsonformresponseid`. Ein Volldump über 4.958 mutabo-Ära-KE-Einträge eines Demo-Patienten zeigt: **`json_len = 0` bei ALLEN Einträgen**.

**Interpretation:** Die `jsonform*`-Felder gehören zum neuen tomedo-PatF-Formularsystem (ab Migration 11/2025), nicht zum mutabo-Alt-System. mutabo schreibt ausschließlich in `ke.text`. Für historische Rückschrieb-Extraktion (2022–10/2025) genügt daher Textparse auf `ke.text`, keine JSON-Deserialisierung nötig.

### Therapiezeilen-Kürzel (praxiseigen, meist mehrere)

Für die Ermittlung des **echten Behandlers** (nicht des Abrechnungsarztes via
`leistungserbringer_ident`) sind drei Karteieintragstypen relevant. Sie alle
nutzen `dokumentierenderNutzer_ident` als wahren Behandler; `arzt_ident` ist
bei diesen Typen durchgehend `0`.

| Kürzel | Rolle | Typischer Befund an der Referenzinstallation |
|---|---|---|
| `<TYP-A>` | Alt-Typ | Hauptvolumen über Jahrzehnte, endet mit der Umstellung |
| `<TYP-B>` | Nachfolger | ab Umstellung aktiv, Volumen wächst |
| `<TYP-C>` | Paralleltyp | kleiner Bestand, oft fachbereichsspezifisch |

**Die eigenen Kürzel einmal ermitteln**, bevor eine Behandlerauswertung läuft — eine
Umstellung des Dokumentationsworkflows hinterlässt regelmäßig mehrere parallele Typen:

```sql
SELECT k.typ, min(k.datum) AS ab, max(k.datum) AS bis, count(*) AS anzahl
FROM karteieintrag k
WHERE k.arzt_ident = 0            -- Typen, die den dokumentierenden Nutzer tragen
GROUP BY k.typ ORDER BY anzahl DESC;
```

Für Auswertungen über einen Umstellungszeitraum alle Typen kombinieren — nur dann ist die Behandler-
Zuordnung vollständig (siehe `query-bausteine_v8.md` § 24 für DISTINCT-ON-Pattern).


### karteieintrag.autoquelle — KI-Marker (Zollsoft 09/2026)

| Feld | Typ | Bedeutung |
|---|---|---|
| `autoquelle` | `text` (Ordinalposition 156) | Herkunft eines maschinell erzeugten Eintrags. **JSON-Array**, nicht Skalar. Belegter Wert: `[{"kuerzel":"KC"}]` = KarteiChat. `NULL` bei manuell erzeugten Eintraegen. |

Dieses Feld traegt das ✦-Symbol der Karteiliste. Der Schalter „✦ anzeigen" blendet nur die
Anzeige aus und hat keine Wirkung auf die Datenbank.

**Auswertung immer ueber `IS NOT NULL`, nie ueber Wertgleichheit** — das Array-Format ist
darauf angelegt, mehrere Quellen pro Eintrag zu tragen. Kuerzel-Extraktion:

```sql
substring(k.autoquelle from '"kuerzel"[^"]*"([^"]+)"')
```

Diese Fassung liest nur das erste Element. Ein Eintrag mit zwei Quellen (etwa Diktat plus
Nachbearbeitung im Chat) verliert die zweite lautlos.

**Ungeprueft:** ob alle KI-Pfade das Feld setzen. Belegt ist nur der KarteiChat. Besonderer
Verdacht bei KI-Prompts aus Aktionsketten — bleibt `autoquelle` dort leer, untererfasst jede
KI-Kennzahl systematisch.

**Zweiter, unabhaengiger Belegpfad:** `dokassistentry.karteieintrag_ident` verbindet den
Dokumentenassistenten direkt mit dem Eintrag. Deckt aber nur diesen einen Pfad ab.

## 3. Diagnosen

### diagnose (Alias: d) / DiagnosenWithPlainText
`DiagnosenWithPlainText` ist eine View analog zu `karteieintragwithplaintext`.
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| datum | timestamp | Diagnosedatum |
| isDDI | boolean | Dauerdiagnose (anamnestischeDDI=true → anamn. DD) |
| abgesetzt | integer | 1 = abgesetzt |
| abgesetztstatusseit | timestamp | Datum der Absetzung |
| anamnestischseit | timestamp | ⛔ an der Referenzinstallation faktisch leer (1 von 54.290 Diagnose-Sätzen ab 11/2025) — **nicht** als Quelle für Chronifizierungs-Zeiträume verwendbar; die Information liegt stattdessen als Prosa im Freitext (23,1 Prozent der DIAX-Einträge tragen eine Jahresangabe) |
| typ | text | Diagnosesicherheit: A, G, V, Z |
| lokalisation | text | R, L, B |
| freitext | text | Freitext |
| visible | boolean | NOT NULL |
| icdkatalogeintrag_ident | bigint | FK → icdkatalogeintrag |
| dokumentierendernutzer_ident | bigint | FK → nutzer |
| letzteaenderung | timestamp | Letzte Änderung |
| sortierung | integer | Sortierposition |
| kategorie | integer | Vereinheitlicht DDI-Typen in xtomedo |

### icdkatalogeintrag
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| code | ICD-Code (z.B. `'F32.1'`) |
| bezeichnung | Bezeichnung |

### Aktive Dauerdiagnosen filtern
```sql
d.isddi = true AND (d.abgesetzt IS NULL OR d.abgesetzt < 1)
```

---

### Diagnose-Karteieintragstypen DIA / DDI / DIAX

Diagnosen erscheinen als Karteieinträge dreier Typen. Der Payload liegt in `diagnose`,
erreichbar über `karteieintrag.diagnose_ident` (§2).

| KE-Typ | Bedeutung | Diagnose-Satz vorhanden | Feld `typ` gefüllt | Feld `lokalisation` gefüllt |
|---|---|---|---|---|
| DIA | Akutdiagnose | 42.135 von 42.136 (1:1) | 97,5 Prozent | 13,5 Prozent |
| DDI | Dauerdiagnose | 11.052 von 11.053 (1:1) | 99,4 Prozent | 4,6 Prozent |
| DIAX | Nebendiagnose / Freitextdiagnose | **1.103 von 2.062 (53,5 Prozent)** | **33,4 Prozent** | 4,7 Prozent |

**Zähleinheit.** Bei DIA und DDI ist 1 Karteieintrag = 1 Diagnose-Satz, die beiden Ebenen sind
austauschbar. Bei DIAX gilt das nicht — dort ist nur der Karteieintrag eine durchgängige Einheit.

**Attribution einer Diagnose auf einen Behandler.** `diagnose.dokumentierendernutzer_ident`
zuerst, `karteieintrag.dokumentierendernutzer_ident` als Fallback:

```sql
COALESCE(NULLIF(TRIM(ndg.kuerzel), ''), NULLIF(TRIM(nke.kuerzel), ''), 'UNBEKANNT')
```

Die beiden Felder divergieren kaum (DIA 1,2 · DDI 3,7 · DIAX 0,2 Prozent), der Fallback ist aber
zwingend: bei DIAX existiert für 46,5 Prozent der Einträge gar kein Diagnose-Satz. Ohne Fallback
verschwindet knapp die Hälfte. Rest ohne jede Zuordnung: DIA 91, DDI 0, DIAX 0.

**Aggregation immer über `TRIM(nutzer.kuerzel)`**, nie über `nutzer.ident` — Doppelaccounts.

**Wer dokumentiert.** Die zehn stärksten Kürzel sind MFA-Konten. Eine Häufigkeitsstatistik über
diese Typen misst **Erfassungsvorgänge, nicht Diagnosestellung**; als Aussage über ärztliche
Tätigkeit ist sie unbrauchbar.

**`lokalisation` ist ein Haus-Standard-Problem**, kein DIAX-Problem: 4,6 bis 13,5 Prozent über
alle drei Typen. Von 362 DIAX-Einträgen mit einer Seitenangabe im Freitext tragen nur 49 auch
den Feldwert; Widersprüche zwischen Freitext und Feld gibt es genau einen.

## 4. Leistungen & Abrechnung (EBM)

### leistung (Alias: l) — EBM-spezifische Felder
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK. Als `ebmleistungid` ausgeben |
| dtype | varchar | NOT NULL. `'EBMLeistung'` für EBM, `'GOAELeistung'` für GOÄ |
| datum | timestamp | Leistungsdatum |
| anzahl | integer | NOT NULL. Multiplikator (Feld 5005) |
| visible | boolean | NOT NULL |
| patient_ident | bigint | ⚠ **NICHT vorhanden auf `leistung`** — diese Zeile widerspricht dem Abschnitt leistung — kein direkter patient_ident (validiert 03/2026) und der SKILL.md §5. Verbindlich ist: Pfad ueber `kvschein`, ab 11/2025 kurz via `kvschein.patient_ident`, davor volle Bridge `kvschein → patientendetailsrelationen_kvscheine → patientendetails → patient` |
| invkvschein_ident | bigint | FK → kvschein |
| ebmkatalogeintrag_ident | bigint | FK → ebmkatalogeintrag |
| prozentderleistung5013 | integer | Prozentuale Leistung |
| betriebsstaette_ident | bigint | FK → betriebsstaette |
| leistungserbringer_ident | bigint | FK → nutzer (⚠ Abrechnungsarzt, NICHT wahrer Behandler!) |
| abrechnenderarzt_ident | bigint | FK → nutzer |
| dokumentierendernutzer_ident | bigint | FK → nutzer |
| letzternutzer_ident | bigint | FK → nutzer |
| arztpatientenkontakt_ident | bigint | FK → arztpatientenkontakt |
| asvteamnummer5100_ident | bigint | FK → asvteamnummer |
| containedonrechnung_ident | bigint | FK → privatrechnung. ⛔ An der Referenzinstallation **nicht befüllt** → Pfad über `privatrechnung_goaeleistungen` |
| privatleistung | boolean | True = Privatleistung auf GKV-Schein |
| standalonecode | text | Code für Standalone-Leistungen ohne Katalogeintrag |
| datumletzteaenderung | timestamp | Letzte Änderung |
| gesamtschnittnahtzeit5037 | integer | Schnittnahtzeit |
| Weitere KBV-Felder | — | skelettabschnitt5055, organ5015, medikament5050, begruendung5009, etc. |

### ebmkatalogeintrag
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| code | EBM-Ziffer |
| custompruefzeit | Praxisspezifische Prüfzeit |

### ebmKatalogEintragDetails (über Bridge)
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| kurztext | Bezeichnung |
| euroWertInCent | Euro-Wert in Cent |
| punktwert | Punktwert |
| pruefzeit | Prüfzeit |
| zeitbedarf | Zeitbedarf |
| zeitprofilart | Tag+Quartal oder Quartal |
| gueltigVon, gueltigBis | Gültigkeitszeitraum |

Bridge: **ebmKatalogEintrag_ebmKatalogEintragDetails**: `ebmKatalogEintrag_ident` → `ebmKatalogEintragDetails_ident`

Gültigkeits-JOIN:
```sql
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
```

### kvschein (Alias: s)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK. Als `scheinid` ausgeben |
| quartal | integer | NOT NULL. Abrechnungsquartal |
| jahr | integer | NOT NULL. Jahr |
| visible | boolean | NOT NULL |
| sortierdatum | timestamp | Sortierdatum (Erstell- oder Änderungsdatum) |
| ausstellungsdatum4102 | timestamp | Erstellungsdatum des Scheins |
| ignoriertfuerabrechnung | boolean | NOT NULL |
| abgerechnet | boolean | NOT NULL |
| hasleistung | boolean | NOT NULL |
| scheingruppe_ident | bigint | FK → kvscheingruppe |
| kartendaten_ident | bigint | FK → kartendaten |
| abgeleiteterkostentraeger_ident | bigint | FK → krankenkasse |
| patient_ident | bigint | FK → patient (**direkter Pfad!**) |
| abrechnendebetriebsstaette_ident | bigint | FK → betriebsstaette |
| dokumentierendernutzer_ident | bigint | FK → nutzer |
| vermittlungsart4103 | integer | 1=TSS-Terminfall, 2=TSS-Akutfall, 3=HA-Vermittlungsfall, 4=offeneSprechstunde, 5=Neupatient |
| ueberweisenderarzt | text | LANR des Überweisers |
| ueberweisendebsnr4218 | text | BSNR des Überweisers |
| ueberweisenderarztname | text | Name |

### kvscheingruppe
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| code | Code |
| bezeichnung | Bezeichnung |

### Sachkosten, OPS, GNR-Zusatzangaben
- **leistung_sachkosten**: `leistung_ident` → `sachkosten_ident`
- **ZusatzangabeSachkosten**: `ident`, `bezeichnung5011`, `kostenincent5012`, `herstelllerASV5074`, `artikelnummerASV5075`, `rechnungsnummer5076`
- **leistung_zusatzangabenops**: `leistung_ident` → `zusatzangabenops_ident`
- **ZusatzangabeOPS**: `ident`, `katalogeintrag_ident`, `seitenlokalisation5041`
- **opskatalogeintrag**: `ident`, `opscode`
- **leistung_zusatzangabeGNR5036**: `leistung_ident` → `zusatzangabeGNR5036_ident` (FK → ebmkatalogeintrag)
- **ArztPatientenKontakt**: `ident`, `kontaktzeit`
- **ASVTeamnummer**: `ident`, `kuerzel`

---

## 5. Leistungen & Abrechnung (GOÄ/Privat)

### leistung — GOÄ-spezifische Felder
| Feld | Beschreibung |
|------|-------------|
| dtype | `'GOAELeistung'` |
| goaekatalogeintrag_ident | FK → goaekatalogeintrag |
| kostenInCent | Kosten in Cent |
| isBrutto | Boolean |
| isSachkosten | Boolean |
| sachkostenname | Name der Sachkosten |
| sachkostenmwstSatz | MwSt-Satz (ignorieren) |
| steigerungsfaktor | Steigerungsfaktor |
| steigerungfix | Boolean (kostenfixiert) |
| anzahlNenner | Divisor für Teilleistungen |

### goaekatalogeintrag
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| code | GOÄ-Ziffer |
| kurztext | Bezeichnung |
| typ | Typ (5 = besondere Kosten) |
| faktor_normal | Normaler Faktor |
| besonderekostenincent | Besondere Kosten |
| eurowertincent | Eurowert |
| eurowertahincent | ⛔ an der Referenzinstallation **nicht vorhanden** — `eurowertincent` verwenden |

### privatrechnung (Alias: pr)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK. Als `privatrechnungid` ausgeben |
| patient_ident | bigint | FK → patient (direkter Pfad!) |
| rechnungsnummer | text | Rechnungsnummer |
| visible | boolean | NOT NULL |
| erstelltam | timestamp | Erstellt am |
| druckdatum | timestamp | Gedruckt am |
| bezahlt | boolean | NOT NULL |
| bezahltdatum | timestamp | Bezahlt am |
| summekosten | real | NOT NULL. Nettosumme **in Euro** (nicht Cent!) |
| summekostenreal | real | NOT NULL. Bruttosumme in Euro (berücksichtigt z.B. Reduktion Belegarzt) |
| bezahlterteilbetrag | real | NOT NULL. Bereits bezahlter Teilbetrag |
| teilbetrag | boolean | NOT NULL. Ist Teilzahlung |
| mehrwertsteuerinprozent | real | NOT NULL. MwSt |
| mehrwertsteuerabsolut | real | MwSt absolut (berücksichtigt nichtAmbulant) |
| status | integer | 0=offen, 1=Korrektur, 2=Prüfung, 3=geprüft |
| mahnstufe | integer | NOT NULL. Mahnstufe |
| abgerechnet | boolean | NOT NULL |
| freitext | text | Notiz |
| aktenzeichen | text | Aktenzeichen |
| pvs | boolean | NOT NULL. PVS |
| nichtambulant | integer | NOT NULL. 0=ambulant, 1=belegärztlich, 2=stationär |
| isbgrechnung | boolean | NOT NULL. BG-Rechnung |
| iskostenvoranschlag | — | **⚠ Nicht direkt auf privatrechnung** — existiert auf `privatrechnungtyp`! |
| datumletzteleistung | timestamp | Datum der letzten enthaltenen Leistung |
| dueforpaymentdate | timestamp | Fälligkeitsdatum |
| privatrechnungtyp_ident | bigint | FK → privatrechnungtyp |
| steigerungsschema_ident | bigint | FK → steigerungsschema |
| abrechnenderarzt_ident | bigint | FK → nutzer |
| dokumentierendernutzer_ident | bigint | FK → nutzer |
| abrechnendebetriebsstaette_ident | bigint | FK → betriebsstaette |
| ueberweiser_ident | bigint | FK → hausarzt |
| privatkasse_ident | bigint | FK → krankenkasse |
| privatrechnungkostenstelle_ident | bigint | FK → privatrechnungkostenstelle |
| privatrechnungkonto_ident | bigint | FK → privatrechnungkonto |
| privatrechnungrabatt_ident | bigint | FK → privatrechnungrabatt |
| heilmittelformular_ident | bigint | FK → karteieintrag (verknüpfte HMV) |
| Abweichende Rechnungsanschrift | text | abweichenderechnungsanschrifttitel, ...vorname, ...nachname, ...strasse, ...plz, ...ort, ...geschlecht |

### privatrechnungtyp
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| kuerzel | Kürzel |
| name | Name |
| iskostenvoranschlag | Boolean |
| isbg | Boolean (BG-Typ) |
| rechnungskreis_ident | FK → rechnungskreis |

### Weitere Privat-Tabellen
- **privatrechnungkostenstelle**: `ident`, `name`
- **privatrechnungkonto**: `ident`, `name`
- **privatrechnungrabatt**: `ident`, `kuerzel`, `name`, `prozent`, `isforml`, `isfortl`, `isforll`, `isforsk`
- **rechnungskreis**: `ident`, `kuerzel`
- **privatrechnungvorlage**: `vorlage_ident` (FK → privatrechnung)

### Bridge-Tabellen GOÄ
- **privatrechnung_goaeleistungen**: `privatrechnung_ident` → `goaeleistungen_ident`
- **privatrechnung_quartalsdiagnosen**: `privatrechnung_ident` → `quartalsdiagnosen_ident`
- **patientendetailsrelationen_rechnungen**: `rechnungen_ident` → `patientendetailsrelationen_ident`

---

## 6. Leistungen & Abrechnung (HZV/Selektivverträge)

### hzvschein
Indirekter Pfad über `patientendetailsrelationen_hzvscheine`.

### hzvdetails
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| betreuarzt_ident | FK → nutzer |
| hzvvertrag_ident | FK → hzvvertrag |
| statusteilnahme | 2 = aktiv |
| statusFAVDirektaktivierung | 4/5 = Pseudo-Teilnahme |

### hzvvertrag
`ident`, `name`

### hzvkatalogeintrag
`ident`, `code`

### Selektivverträge
- **svteilnahme**: `ident`, `status` (2=aktiv), `selektivvertrag_ident`
- **selektivvertrag**: `ident`, `name`

### Bridge-Tabellen HZV
- **hzvschein_hzvleistungen**: `hzvschein_ident` → `hzvleistungen_ident`
- **hzvschein_quartalsdiagnosen**: `hzvschein_ident` → `quartalsdiagnosen_ident`
- **patientendetailsrelationen_hzvscheine**: `hzvscheine_ident` → `patientendetailsrelationen_ident`
- **patientendetails_hzvDetails**: `patientendetails_ident` → `hzvdetails_ident`
- **patientendetails_sonstigeSVTeilnahmen**: `patientendetails_ident` → `sonstigeSVTeilnahmen_ident`
- **kvschein_quartalsdiagnosen**: `kvschein_ident` → `quartalsdiagnosen_ident`

---

## 7. Termine & Kalender

### termin (Alias: t)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK. Als `terminid` ausgeben |
| patient_ident | bigint | FK → patient (direkter Pfad!) |
| beginn | timestamp | Beginn |
| ende | timestamp | Ende |
| info | text | Termininfo |
| removed | boolean | NOT NULL |
| warda | boolean | NOT NULL. **No-Show-Signal**: true = Patient war da (gesetzt via Todo-Workflow/MFA-Besuch). Zuverlässigkeit disziplinabhängig — siehe Kasten unten. |
| isneuerpatient | boolean | NOT NULL. **Neupatient-Flag** (relevant für Wartezeit-Analyse B41). Neupat haben 6,08% No-Show vs. 4,64% gesamt (Nov 25–Mär 26). |
| jsonpayload | text | JSON (Online-Buchungen) |
| behandler | text | ⛔ **an der Referenzinstallation praxisweit leer** — 1.406 von 1.406 geprüften Terminen über alle Terminarten (08/2026), nicht nur bei Gruppenterminen. Behandlerzuordnung stattdessen über `termin_kalender` → `kalender.nutzer_ident`; ersatzweise `dokumentierendernutzer_ident` (= Anleger, nicht Behandler) |
| terminart_ident | bigint | FK → terminart |
| dokumentierendernutzer_ident | bigint | FK → nutzer |
| aenderndernutzer_ident | bigint | FK → nutzer |
| angelegt | timestamp | Erstellungszeitpunkt des Termins |
| geaendert | timestamp | Letzte Änderung |
| heilmittel_ident | bigint | FK → heilmittel (verknüpftes Heilmittel) |
| genutztesuche_ident | bigint | FK → terminsuche (genutzte Suchvorlage) |
| verschiebeoderloeschunggrund | text | Verschiebe-/Löschungsgrund |

### terminart
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| kuerzel | text | Kürzel (Achtung: hat teils trailing Spaces → immer `TRIM()` verwenden) |
| bezeichnung | text | Bezeichnung |
| infotermin | boolean | NOT NULL. Steuert Unterscheidung Kapazität/Belegung (siehe Semantik) |
| laenge | integer | NOT NULL. Standard-Terminlänge in Minuten |
| typ | integer | NOT NULL. 0=Termin, 1=Ressource, 2=Sperrbereich, 3=Ganztagsart |
| visible | boolean | NOT NULL |
| farbe | text | Terminfarbe |
| terminresourceverbindung_ident | bigint | FK → terminart (verknüpfte Ressource) |
| premigrationart_ident | bigint | FK → terminart (Pre-Migration-Mapping) |
| listenpos | integer | Sortierposition |

**Semantik von `infotermin` und `typ`:**
- `infotermin = true` / `typ = 1` → **Ressource/Kapazitätsblock** (definiert verfügbare Therapiezeit im Kalender)
- `infotermin = false` / `typ = 0` → **Patiententermin** (belegt diese Zeit, für Patientenlisten filtern)
- `typ = 2` → **Sperrbereich** (blockiert Terminsuche)
- `typ = 3` → **Ganztagsart** (ganztägige Einträge)

Viele Terminarten existieren als **Paar** mit gleichem Kürzel aber unterschiedlichem `infotermin`-Flag (z.B. `AP` als Ressource UND als buchbarer Termin).

**Semantik `terminart.terminresourceverbindung_ident`:** Zeigt von einer Buchungs-Terminart (`infotermin=false`) auf die Ressource-Terminart (`infotermin=true`), die sie belegt. Mehrere Buchungs-Terminarten können auf dieselbe Ressource zeigen — Beispiel: `G`, `WV`, `Gespr`, `NTWeichteil` (!) zeigen alle auf `SprSt`.

⚠ **`terminart.typ = 3` ist an der Referenzinstallation KEIN aktiver Mechanismus.** Es existiert genau eine Ganztagsart
(„Urlaub ganztags") und die ist `visible = false`. Ein Filter auf `typ = 3` liefert daher **leer**.
Am Testkalender haben *alle* Eintraege `typ = 0` — auch `Blocker`, `Pause` und `Besprechung`.
Fuer Sperrtage stattdessen `terminkalendertag.sperrmodus = 1` verwenden; bei Alt-Blockern ist
`infotermin` der Unterscheider, nicht `typ`.

### kalender
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| name | Kalendername |
| kuerzel | Kürzel |
| nutzer_ident | FK → nutzer |

**Kalender-Typen:**
- **Therapeuten-Kalender**: `nutzer_ident IS NOT NULL` — einem Nutzer/Therapeuten zugeordnet
- **Raum-/Gruppenkalender**: `nutzer_ident IS NULL` — z.B. Fabrik, Studio, Diagnostik, Basisgruppen

**Workaround Raumkalender für Gruppentherapie-Slots:**
tomedo erlaubt nur manuelle parallele Buchungen; die Terminsuche sucht nur sequentiell. Für Gruppentermine wird die Terminart auf 1 Minute Länge gesetzt und die Ressource gibt exakt so viele Minuten frei wie Teilnehmerplätze vorhanden sind (z.B. 12 min = 12 Slots). Durch geschickte Rundung erhalten alle Teilnehmer eine Termineinladung für die selbe Uhrzeit. Konsequenz: Auslastung >100% in Raumkalendern ist systembedingt möglich.

### Sperrzeiten / Blocker

Ressourcenblöcke (`infotermin=true`) bleiben über Urlaube und Feiertage erhalten. Es wird eine Sperrzeit darüber gelegt, die die Terminsuche blockiert. Sperrzeiten erkennt man an: `infotermin=false`, `patient_ident IS NULL`, Dauer ≥300 min = gesperrter Tag.

| Terminart-Kürzel | Bezeichnung | Rolle |
|---|---|---|
| UNBEKANNT | UNBEKANNT | **Hauptblocker**: Feiertage (720min), Urlaub, individuelle Sperren. `info`-Feld enthält Sperrgrund |
| Blocker | Blocker | Expliziter Blocker-Typ |
| IMPORT_GANZTAG | IMPORT_GANZTAG | Import-bedingte Ganztagsblöcke |
| Urlaub | Urlaub | Explizite Urlaubseinträge |
| Ü-Abbau | Überstundenabbau | Abwesenheit durch Überstundenabbau |

Zwei getrennte Mechanismen — nicht verwechseln:

**1. Ganztags-Sperre (Primaerquelle ab Migration): `terminkalendertag`**

Ressourcenbloecke (`infotermin=true`) bleiben ueber Urlaube und Feiertage physisch erhalten. Die Sperre liegt *darueber*, in einer eigenen Tabelle, und fasst bestehende Termine **nicht** an. Deshalb koennen Patiententermine auf gesperrten Tagen stehenbleiben, ohne dass tomedo warnt (→ Konflikt-Query, query-bausteine §17).

#### terminkalendertag

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| kalender_ident | bigint | FK → kalender |
| tag | timestamp | Der Kalendertag |
| beginn | timestamp | **NULL = ganztags.** Gefuellt = Teilsperre |
| ende | timestamp | dito |
| sperrmodus | integer | NOT NULL. **0 = frei, 1 = gesperrt.** Nur diese zwei Werte beobachtet |
| kalendersperrmodus_ident | bigint | FK → kalendersperrmodus (Sperrgrund). Bei `sperrmodus=1` **immer** gesetzt |
| sperrname | text | Redundant zu `kalendersperrmodus.name` — nicht als Freitext nutzen |
| info | text | Bei automatisch angelegten Zeilen `'serverseitig'` |
| removed | boolean | NOT NULL |

**Granularitaet: eine Zeile pro Kalender × Tag — auch fuer ungesperrte Tage.** Die Tabelle ist damit kein Sperr-Log, sondern ein vollflaechiger Kalendertag-Index. Konsequenz: **immer auf `terminkalendertag.sperrmodus = 1` filtern**, sonst matcht jeder Tag.

#### kalendersperrmodus

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| name | text | Sperrgrund-Bezeichnung |
| isfeiertag | boolean | NOT NULL. Trennt Feiertag von Abwesenheit |
| color | text | Anzeigefarbe |
| visible | boolean | NOT NULL |
| listenpos | integer | Sortierung |

Praxis-Katalog → `enums-und-funktionen.md`; Interpretation → eigene Praxiskontext-Datei.

**2. Blocker-Termine (Alt-Pfad, Epochen vor Migration)**

Sperrzeit als `termin` mit `infotermin=false`, `patient_ident IS NULL`, Dauer ≥300 min. Fuer Zeitraeume ab Nov 2025 **nicht mehr die Leitquelle** — im geprueften Kalender existierte kein solcher Blocker, obwohl der Tag gesperrt war.

| Terminart-Kuerzel | Bezeichnung | Rolle |
|---|---|---|
| UNBEKANNT | UNBEKANNT | Hauptblocker: Feiertage (720min), Urlaub, individuelle Sperren. `info` enthaelt Sperrgrund |
| Blocker | Blocker | Expliziter Blocker-Typ |
| IMPORT_GANZTAG | IMPORT_GANZTAG | Import-bedingte Ganztagsbloecke |
| Urlaub | Urlaub | Explizite Urlaubseintraege |
| Ü-Abbau | Überstundenabbau | Abwesenheit durch Überstundenabbau |

**3. Ganztagsart auf terminart (`typ = 3`) — an der Referenzinstallation inaktiv**

Es existiert genau eine (`Urlau` / „Urlaub ganztags"), und die ist `visible = false`. `typ = 2` (Sperrbereich) ist unbelegt. Diese Modellierungsvariante spielt praktisch keine Rolle.

**Datenverfügbarkeit und Größenordnung (gemessen 07/2026):** eine Zeile pro Kalender × Tag,
~1.500 Zeilen/Monat bei 50–85 Kalendern, vorgepflegt bis 2031. **Belastbar ab 12/2024, vollständig ab 10/2025.**

**ArZeKo-Modi (Label ist KEIN Herkunftsbeleg — Korrektur 08/2026, s. u.):** die vier Modi `Arzeko_Urlaub`, `Arzeko_Krank`, `Arzeko_Kindkrank`,
`Arzeko_Sonstige_Abwesenheit` stammen aus dem Arbeitszeitkonto und unterscheiden eine *verbuchte* Abwesenheit von
einer manuell im Kalender gesetzten Sperre. Nur der ArZeKo-Weg reduziert über `abwesenheitstyp.factorsollzeit`
die Sollzeit und verbucht `urlaubsverteilung` — ein direkt gesetzter Sperrtag tut das nicht.

⚠ `kalendersperrmodus.isfeiertag = true` gilt **praxisweit**. Bei Konfliktauswertungen bewusst ein- oder
ausschließen, sonst Serien-Fehlalarme.

⚠ Die Tabelle **fehlt in `datenmodell.md`-Altversionen** und stand nur im ZOLLSOFT-DB-Dump. Bei
„Tabelle/Feld nicht gefunden“ immer gegen `datenmodell_ZOLLSOFT_DB-dump.md` gegenprüfen.

⚠ **Das Label sagt nichts ueber die Herkunft der Sperre.** Geprueft am 2026-08-18 an zwei Faellen:
Sperrtage mit dem Praefix `Arzeko_` waren **von Hand im Kalender** eingetragen. Der Katalog ist in
tomedo frei auswaehlbar, das Praefix ist ein Anzeigename ohne Schreibpfad-Semantik. Auswertungen
duerfen aus `kalendersperrmodus.name` deshalb **Zustand** ableiten, nie **Herkunft**. Wer wissen muss,
ob eine Abwesenheit im Arbeitszeitkonto verbucht ist, muss `abwesenheit`/`arbeitszeitkonto` lesen —
nicht das Sperrlabel. (Damit ist die frueher dokumentierte Lesart „vier Modi = eindeutiger
Herkunftsmarker" zurueckgenommen.)

⚠ **`terminkalendertag.tag` ist `timestamp`, nicht `date`.** Jeder Tagesvergleich und jede Ausgabe an
einen externen Konsumenten braucht `::date`; ohne Cast liefert ein API-Export Zeitstempel und ein
Soll-Ist-Vergleich gegen eine Tagesliste scheitert an der Uhrzeit.

**Gemessene Nutzung (Zukunftsfenster ab 2026-08-19, alle Kalender):** 374 Zeilen mit `sperrmodus = 1`,
davon 367 an Personenkalendern und 7 an Kalendern ohne `nutzer_ident` (Raum-/Sammelkalender). `removed`
war bei keiner Zeile gesetzt, `beginn`/`ende` bei keiner Zeile gefuellt — Teilsperren existieren in der
Praxis weiterhin nicht (Stand 08/2026 unveraendert gegenueber 07/2026).

### termin_kalender (Bridge)
`termin_ident` → `kalender_ident`

### No-Show-Erkennung: Zwei-Stufen-Modell

**Stufe 1 (warda-basiert):** Ist die warda-Pflegequote eines Behandlers hoch, ist `termin.warda = false` ein belastbares No-Show-Signal. An der Referenzinstallation lag die Schwelle bei ≥85 %; erreicht wurde sie von der Ärzteschaft und einem Teil der Psychotherapie.

> **Die Pflegequote ist je Behandler selbst zu erheben**, bevor Stufe 1 verwendet wird. Sie ist eine Eigenschaft des Dokumentationsworkflows, nicht der Person, und verschiebt sich mit jeder Workflow-Änderung. Baustein: Anteil `warda = true` an allen stattgefundenen Terminen, gruppiert nach `nutzer_ident` und Quartal. Ergebnis gehört in `praxis-interna.md`, nicht in dieses Referenzkorpus.

**Stufe 2 (KE-basiert): nicht verfügbar.** Das dafür vorgesehene Ersatzsignal `karteieintrag.termin_ident` war in einem geprüften Bestand über rund 280.000 Karteieinträge durchgehend leer (Werte und Fenster siehe `praxis-interna.md`). Für Behandlergruppen mit niedriger warda-Pflegequote existiert damit **kein** KE-basiertes Anwesenheitssignal über den Termin. Ein Ersatz muss über Datumsnähe KE↔Termin am selben Patiententag konstruiert werden — offen, siehe Backlog B162.

**Gruppentermine** (BG1/BG2/Bio/Kopf/Schlaf/Bew) haben ≤15% warda-Pflege und sind für No-Show-Analyse nur mit KE-basiertem Signal sinnvoll.

### leistung — kein direkter patient_ident

`leistung` hat **KEIN** direktes Feld `patient_ident` (validiert 03/2026). Pfad zu Patient geht:
- **EBM:** `leistung.invkvschein_ident → kvschein` → dann **volle Bridge** `patientendetailsrelationen_kvscheine → patientendetails → patient`.
  ⚠ `kvschein.patient_ident` ist erst ab Migration 11/2025 befüllt und für Historie unbrauchbar.
- **GOÄ:** `privatrechnung_goaeleistungen → privatrechnung.patient_ident → patient`

Die Bridge `terminart_ebmleistungen` (Terminart ↔ EBM-Favoriten) ist an der Referenzinstallation **leer** — EBM-Euro pro Terminart müssen über tatsächliche Abrechnungsdaten abgeleitet werden (siehe query-bausteine §31).

---

### Feldbefund `termin.verschiebeoderloeschunggrund` (Stand 09/2026)

Der **Loeschgrund ist an der Referenzinstallation zu rund 60 Prozent gefuellt** und damit als Auswertungsquelle
brauchbar — entgegen der aelteren Annahme, das Feld sei praktisch leer. Es ist ein halbfreies
Textfeld mit einem dominanten Wert und einem langen Schwanz aus Einzelformulierungen:

| Wertgruppe | Charakter |
|---|---|
| `patient hat termin abgesagt` (plus Varianten mit `, verschoben`) | dominanter Wert, patientenseitige Absage |
| `kurzfristiger ausfall des behandelnden arztes / psychotherapeuten / physiotherapeuten` | praxisseitiger Ausfall, offenbar aus einem Textbaustein |
| `.`, `-`, `i`, `wef`, `loeschen`, `fehleintrag`, `falsch eingetragen` | administrative Korrektur, kein inhaltlicher Grund |
| `OHNE_ANGABE` | leeres Feld, rund 40 Prozent |

Auswertungsregeln: Werteverteilung immer mit Haeufigkeitsschwelle (n >= 3 Patienten) und gekuerzt
ausgeben, weil das Feld personenbezogene Freitexte enthalten kann. `removed = true` umfasst
Absage **und** technische Verschiebung; eine Absagequote daraus ist eine Obergrenze, eine
Absagemenge mit Grundangabe eine Untergrenze. Ein Aenderungsprotokoll existiert weiterhin nicht.

## 8. Medikamente & Verordnungen

### medikamentenverordnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| dtype | varchar | NOT NULL |
| datum | timestamp | Verordnungsdatum (auch Datum letzter Dosierungsanpassung) |
| rezepttyp | smallint | NOT NULL. 0=n.d., 1=rot, 2=grün, 3=blau, 4=BTM, 5=16a (Sprechst.bedarf) |
| iswirkstoffverordnung | boolean | |
| pzn | text | PharmaZentralNummer |
| anzahl | integer | NOT NULL |
| namebeiverordnung | text | Name bei Verordnung (wie auf Rezept gedruckt) |
| namebeiwirkstoffverordnung | text | Name bei Wirkstoffverordnung |
| wirkstoffnamebeiverordnung | text | Wirkstoffname (erst seit Feb 2020 befüllt!) |
| atcbeiverordnung | text | ATC-Code |
| mengebeiverordnung | text | Menge |
| einheitbeiverordnung | text | Einheit |
| avpbeiverordnung | integer | NOT NULL. AVP in Cent |
| kvpbeiverordnung | integer | Kassenverkaufspreis in Cent |
| taxpreisbeiverordnung | integer | Taxpreis in Cent |
| darreichungbeiverordnung | text | Darreichungsform |
| dauermedikation | boolean | NOT NULL. ⚠ In der Praxis nicht gepflegt (0,2%) — als Analysedimension **unbrauchbar** |
| autidem | boolean | Aut idem |
| dosierungfrueh, dosierungmittag, dosierungabend, dosierungnacht | text | Dosierung |
| dosierungfreitext | text | Dosierungstext |
| dosierungreichtbis | timestamp | Reicht bis |
| visible | boolean | NOT NULL |
| eigenrezeptur_ident | bigint | FK → eigenrezeptur |
| rezept_ident | bigint | FK → rezept |
| abweichenderverordner_ident | bigint | FK → nutzer |
| abweichenderattester_ident | bigint | FK → nutzer |
| dokumentierendernutzer_ident | bigint | FK → nutzer (Verordner für Analyse!) |
| abgesetztam | timestamp | Absetzungsdatum |
| absetzungsgrund | integer | 0=inaktiv, 1=Unverträglichkeit |
| abgesetztvon_ident | bigint | FK → nutzer |
| herstellerbeiverordnung | text | Hersteller |
| kassenzeichenbeiverordnung | text | Kassenzeichen |
| gebuehrenbefreit | boolean | Gebührenbefreit |

| wirkstaerkebeiverordnung | text | Wirkstärke bei Verordnung (fehlte in v8; im ZOLLSOFT-DB-Dump vorhanden). Post-Migration ~82 % befüllt. |

### rezept
`ident`, `arzt_ident`, `attester_ident`, `betriebsstaette_ident`

### eigenrezeptur
`ident`, `kurzname`

### Bridge
- **patientendetailsrelationen_verordnungen**: `verordnungen_ident` → `patientendetailsrelationen_ident`
- **karteieintrag_medikverordnung_bisher**: `karteieintrag_ident` → `medikverordnung_bisher_ident`

---

## 9. Heilmittel

### heilmittelverordnung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| formular_ident | bigint | FK → karteieintrag |
| fremdverordnung | boolean | Fremdverordnung (extern) |
| heilmittelschein_ident | bigint | FK → heilmittelschein |
| privatrechnung_ident | bigint | FK → privatrechnung |
| ausstellenderarzt_ident | bigint | FK → hausarzt (ausstellender Arzt) |
| therapiebericht_ident | bigint | FK → karteieintrag (Therapiebericht) |
| visible | boolean | NOT NULL |
| abgerechnet | boolean | Abgerechnet |
| behandlungabgeschlossen | boolean | Behandlung abgeschlossen |
| behandlungsabbrucham | timestamp | Behandlungsabbruch-Datum |
| fehlerhaft | boolean | Fehlerhaft markiert |
| vollstaendig | boolean | Vollständig |
| zusammenfassung | text | Zusammenfassung |

### heilmittel
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| code | text | z.B. CHG = Chirogymnastik |
| bezeichnung | text | Bezeichnung |
| positionsnummer | text | Positionsnummer laut GNR-Katalog |
| visible | boolean | NOT NULL |
| therapiedauerinminuten | integer | Therapiedauer (für Logopädie) |
| terminart_ident | bigint | FK → terminart (verknüpfte Terminart) |
| kostenincent_aok, kostenincent_bkk, kostenincent_ikk, kostenincent_knappschaft, kostenincent_svlfg, kostenincent_vdek | integer | Kosten pro Kassenart |

### heilmittelschein
`ident`, `abgerechnetam`, `abgerechnet` (boolean), `abrechnendebetriebsstaette_ident`

### Bridge-Tabellen
- **heilmittelschein_heilmittelleistungen**: `heilmittelschein_ident` → `heilmittelleistungen_ident` (→ leistung)
- **heilmittelverordnung_termine**: `heilmittelverordnung_ident` → `termine_ident`
- **patientendetailsrelationen_heilmittelverordnungen**: `heilmittelverordnungen_ident` → `patientendetailsrelationen_ident`

### HMV-Pfad zum Patienten (validiert Q12, 27.03.2026)

**Primärer Pfad** (empfohlen): `heilmittelverordnung.formular_ident → karteieintrag → Dreifach-Pfad (karteieintraege/formulare/caves) → patient`
Der Alternative Pfad über `patientendetailsrelationen_heilmittelverordnungen` existiert, ist aber redundant.

### Praxis-Learnings Medikamentenverordnung (Q12, 27.03.2026)

- **ATC-Befüllung post-Migration:** 78,8 % (Sprung von 3 % Gesamtjahr 2025). Klassische Opioide ~100 % ATC-Abdeckung.
- **Cannabis-ATC-Lücke:** Magistralrezepturen (Dronabinol NRF 22.8, Tilray, Vertanical, Demecan) erhalten keinen ATC-Code, weil keine PZN-basierte Zuordnung möglich. Für vollständige Opioid+Cannabis-Analyse: Freitext-Matching auf ~10 Suchbegriffe nötig (`%Dronabinol%`, `%Cannabis%`, `%TILRAY%`, `%Vertanical%`, `%Demecan%`, `%Vayamed%`).
- **dauermedikation-Flag:** In der Praxis nicht gepflegt (0,2 % der Verordnungen). Als Analysedimension **unbrauchbar**.
- **Opioid-Freitext-Suchbegriffe** (für ATC-Lücken): Tilidin, Tramadol, Tapentadol, Palexia, Morphin, Oxycodon, Oxygesic, Targin, Fentanyl, Buprenorphin, Temgesic, Norspan, Hydromorphon, Jurnista, Palladon, Piritramid, Codein, Dihydrocodein, Dronabinol, Cannabis, TILRAY, Valoron.

### Formulartyp-Erweiterung: Rezepte (Q12 SELECT 5, 27.03.2026)

| formulartyp.name | Kürzel | musternummer | Bedeutung |
|---|---|---|---|
| `'Rezept'` | Rez | 16 | Kassenrezept (Muster 16) |
| `'BlauesRezept'` | RezBl | — | Privatrezept |
| `'BTM-Rezept'` | RezBTM | — | Betäubungsmittelrezept |
| `'gruenesRezept'` | RezGr | 16A | OTC-Empfehlung |
| `'ERezeptPat20211001'` | eRezPat | — | E-Rezept |
| `'VerordnungMedReha'` | RehaV | 61 | Medizinische Reha |
| `'VerordnungMedVorsorge'` | VerVor | 64 | Medizinische Vorsorge |

**DiGA:** Kein Formulartyp mit „DiGA" oder „digital" vorhanden (Stand 03/2026).

---

### Formulartyp-Erweiterung: Krankenhauseinweisung (T3, 12.07.2026)

| formulartyp.name | Kürzel | musternummer | dtype | Bedeutung |
|---|---|---|---|---|
| `'Krankenhausbehandlung'` | KrBeh | 2 | Formular | Verordnung von Krankenhausbehandlung (Muster 2) |

- **Datenfenster:** erste KE 25.09.2025, relevantes Volumen ab Nov 2025 (Migration). 493 KE bis 10.07.2026.
- **Patient-Join:** ausschließlich `_formulare`-Bridge (490/493); `_karteieintraege` trägt 0 (wie für `dtype='Formular'` erwartet).

**KE-Typ `KRH`** (Kürzel, 2010–Okt 2025): dedizierter „Krankenhaus"-KE-Typ, enthält aber **eingehende Klinikpost** (Entlassbriefe/Arztbriefe), NICHT eigene Einweisungen (`einweisung_raus`-Marker ≈ 0). = Hospitalisierungs-Proxy, endet zur Migration (durch Muster-2-Formular abgelöst).

**dtype-Inventar `karteieintrag`** (12.07.2026): nur drei dtypes existieren — `KarteiEintrag` (3,65 Mio), `Formular` (ab 03/2025), `CustomKarteiEintrag`. **Kein eigener Dokument-dtype** — Dokumente/Scans/Klinikpost werden über den KE-Typ differenziert (DOK-ALT, SCAN, KRH, MAIL-Ein, eArztbrief), nicht über dtype.

## 10. Zuweiser

Zuweiser auf KV-Schein: `kvschein.ueberweisenderarzt` (LANR), JOIN über `HA.lanr = kvschein.ueberweisenderarzt`.
Zuweiser auf Privatrechnung: `privatrechnung.ueberweiser_ident` (FK → hausarzt).

---


### Zuweiser auf dem KV-Schein: Textfelder, kein Fremdschluessel (31.08.2026)

**`kvschein` traegt KEINEN Fremdschluessel auf hausarzt.** Der Zuweiser existiert dort
ausschliesslich als Text:

| Feld | Typ | Bedeutung |
|---|---|---|
| `ueberweisenderarzt` | text | LANR des Ueberweisers. Abgerechnet als KBV-Feld **4242** (LANR des ueberweisenden Vertragsarztes) oder **4219** (Ueberweisung von anderen Aerzten) — je nach Flag |
| `ueberweisenderarztistvertragsarzt` | boolean | steuert 4242 gegen 4219. `false` = Klinikambulanz, Bundeswehr, Arzt ohne Kassenzulassung → traegt strukturell **keine** gueltige LANR |
| `ueberweisendebsnr4218` | text | BSNR des Ueberweisers |
| `ueberweisenderarztname` | text | Freitextname |

**Konsequenzen fuer jede Zuweiserauswertung:**

1. **Namensaufloesung nur ueber den LANR-Join** — `TRIM(hausarzt.lanr) = kvschein.ueberweisenderarzt`.
   Ein Zuweiser-Stammsatz **ohne** gepflegte LANR erzeugt einen Schein mit Namen und ohne
   LANR. Der ist im LANR-Pfad nicht aufloesbar und wird ohne eigene Klasse faelschlich als
   Selbstzuweiser gezaehlt. Dreistufige Namensquelle:
   `hausarzt`-Personenname → `hausarzt.praxisname` → `ueberweisenderarztname`; die genutzte
   Stufe immer als Spalte ausweisen.
2. **`hausarzt` hat Dubletten je LANR.** Vor dem Join entdoppeln, sonst Kreuzprodukt:
   `SELECT DISTINCT ON (TRIM(lanr)) … ORDER BY TRIM(lanr), (CASE WHEN visible THEN 0 ELSE 1 END), ident`.
3. **Fachgruppe aus der LANR, nicht aus dem Freitext.** Stellen 8-9 der neunstelligen LANR
   sind der KBV-Arztgruppenschluessel (Anlage 2 zur Richtlinie nach § 75 Abs. 7 SGB V):
   hausaerztlich 01/02/03/34–39 · Neurochirurgie 52 · Orthopaedie-UCH 10–12 · Innere
   fachaerztlich 23–33 · Neurologie 51/53 · Psychiatrie-PT 47/58–61/68/69 · Anaesthesiologie
   04 · Physikalische Medizin 57 · Chirurgie sonstige 06–09/13/14/50 · Radiologie 62–64.
   Restklassen getrennt fuehren: Pseudo-LANR (`strpos(lanr,'999999')=1`), Schluessel `00`
   (nicht codiert), Formatfehler (`lanr !~ '^[0-9]{9}$'`), Name ohne LANR.
   `hausarzt.fachgebiet` ist Freitext und als Auswertungsquelle unbrauchbar.
4. **Der Zuweiser steht einmalig auf dem Erstschein.** Deshalb tragen nur wenige Prozent
   aller Scheine eine Zuweiserangabe. Eine Sicht „Zuweiser des ersten Scheins im
   Berichtsjahr" misst dadurch **keine** Selbstzuweisung, sondern Bestandspatienten ohne
   erneute Angabe. Gueltig ist nur die Sicht auf den fruehesten Schein des Patienten
   ueberhaupt.

Privatzuweisungen laufen ueber `privatrechnung.ueberweiser_ident` (echter FK) und sind ein
**anderer** Pfad — nie mit den Scheinzahlen mischen.


> **Doppelstammsatz ohne LANR (validiert 2026-08-13).** Zu einem Zuweiser können mehrere `hausarzt`-Sätze
> existieren, davon einer **ohne** `lanr` — mit Fachgebietstext, aber ohne Arztgruppenschlüssel. Zuweisungen,
> die an diesem Satz hängen, sind in jedem LANR-basierten Pfad unsichtbar. An der Referenzinstallation am neurochirurgischen
> Hauptzuweiser reproduziert: ein Satz mit gültiger LANR und Schlüssel 52, ein zweiter ohne LANR.
>
> Zweiter Befund derselben Prüfung: `kvschein.ueberweisenderarzt` kann über ganze Jahresblöcke leer sein,
> obwohl der Zuweiser vorher und nachher Fälle schickt (im Realfall Lücke 2016–2021 bei 102 Fällen in 2013
> und 59 in 2022). Zuweiserquoten aus diesem Feld sind deshalb **Untergrenzen**, nicht Vollerhebungen.
>
> Freitextfelder der Überweisung — `auftragstext4205`, `diagnose4207`, `befundodermedikation4208`, `freitext`
> — existieren, sind bei eingehenden Überweisungen aber nur schwach befüllt; der auswertbare Überweisungstext
> liegt an der Referenzinstallation im Karteieintragstyp `ÜBW` (9–21 Einträge pro Jahr und Zuweiser, 120–180 Zeichen).


## 11. Psychotherapie

### anerkennungsbescheidpsychotherapie
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| datum4235 | Bewilligungsdatum |
| antragsdatum4247 | Antragsdatum |
| anzahlbewilligtversicherter4252 | Bewilligte Sitzungen |
| anzahlRezidivVersicherter | Davon Rezidivprophylaxe |
| abgerechnet | Boolean (beendet) |
| kombiBehandlung4251 | Kombibehandlung |
| abgeleitetvon_ident | Self-FK (Versionierung) |
| beendigungsziffer_ident | FK → leistung |

### bewilligteleistung
`ident`, `ebmkatalogeintrag_ident`, `fuerBezugsperson`, `hasHalbeLeistung`, `anzahlAbgerechneterLeistungen4246`

### psychotherapie (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| therapieanfang | timestamp | Beginn der Therapie |
| therapieende | timestamp | Ende der Therapie |
| therapieart | integer | 0=Einzel, 1=Gruppe, 2=Kombi überwiegend Einzel, 3=Kombi überwiegend Gruppe |
| therapieverfahren | integer | 0=analytisch, 1=tiefenpsych., 2=verhaltensther., 3=systemisch |
| iskinderjugendtherapie | boolean | KJP-Behandlung |
| visible | boolean | NOT NULL |
| therapieanfanguserdefined | timestamp | Nutzerdefinierter Therapiebeginn |
| therapieendeuserdefined | timestamp | Nutzerdefiniertes Therapieende |

### psychotherapieinfo (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| beginn | timestamp | Beginn |
| name | text | Bezeichnung |
| status | text | Status |
| visible | boolean | NOT NULL |

Pfad: `patientendetails.aktuellepsychotherapieinfo_ident → psychotherapieinfo`

### psychotherapiezaehler (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| wert | real | NOT NULL. Aktueller Zählerstand |
| maxwertoverride | real | NOT NULL |
| minwertoverride | real | NOT NULL |
| warnwertoverride | real | |
| psychotherapiezaehlertyp_ident | bigint | FK → psychotherapiezaehlertyp |
| visibleinkartei | boolean | NOT NULL |

### psychotherapiezaehlertyp (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| name | text | Bezeichnung |
| context | integer | NOT NULL. 0=heute, 1=Behandlungsfall, 2=halbes Jahr, 4=Krankheitsfall |
| maxwert | real | NOT NULL |
| minwert | real | NOT NULL |
| fuerbezugspers | boolean | Für Bezugsperson |
| fuerrezidiv | boolean | Für Rezidivprophylaxe |

### Psychotherapie-Statusfelder auf Patientenebene

Direkter Zugriff auf Psychotherapie-Status über `patientendetails`:
- `statuspsychotherapiefall`: 0=abgeschlossen, 1=Warteliste, 5=beantragt, 10=aktiv
- `aktuelleranerkennungsbescheidpsychotherapie_ident`: FK → aktueller Bewilligungsbescheid
- `aktuellepsychotherapieinfo_ident`: FK → aktuelle PT-Info
- `datumtherapieende`: Therapieende-Datum

Nutzer-Qualifikation: `nutzer.psychotherapiequalifikation_ident → psychotherapiequalifikation` (VT/TP/AP/systemisch + KJP)

### Bridge
- **kvschein_anerkennungsbescheidepsychotherapie4234**: `kvschein_ident` → `anerkennungsbescheidepsychotherapie4234_ident`
- **anerkennungsbescheidpsychotherapie_bewilligteleistungen4244**: `anerkennungsbescheidpsychotherapie_ident` → `bewilligteleistungen4244_ident`

---

## 12. Todo & Raum

### todo
`ident`, `anfang`, `ende`, `todovorlage_ident`, `raum_ident`

### todovorlage
`ident`, `name`

### raum
`ident`, `bezeichnung`

### besuch (Alias: b)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| patient_ident | bigint | FK → patient (direkt!) |
| kvfall | boolean | NOT NULL |
| privatfall | boolean | NOT NULL |
| bgfall | boolean | NOT NULL |
| unfall | boolean | NOT NULL |
| ankunft | timestamp | Ankunftszeit (für Wartezeitanalyse) |
| ende | timestamp | Ende des Besuchs |
| terminzeit | timestamp | Geplante Terminzeit |
| infotext | text | Infotext |
| wichtig | boolean | NOT NULL |
| betriebsstaette_ident | bigint | FK → betriebsstaette |
| aufnahmedurch_ident | bigint | FK → nutzer |
| karteieintrag_ident | bigint | FK → karteieintrag |
| preferredschein_ident | bigint | FK → kvschein |
| preferredprivatrechnung_ident | bigint | FK → privatrechnung |
| ueberweiser_ident | bigint | FK → hausarzt |
| terminart | text | Terminart-Kürzel (denormalisiert) |
| terminkalender | text | Kalender-Kürzel (denormalisiert) |
| boolcol1, boolcol2 | boolean | Praxisspezifische Ja/Nein-Felder |
| stringcol1, stringcol2 | text | Praxisspezifische Freitextfelder |

### Bridge
- **besuch_todokette**: `besuch_ident` → `todokette_ident`

---

### aufgabe (Aufgaben & Tickets — Mitarbeiter-Aufgabensystem)

Mitarbeiter-Aufgaben/Tickets (NICHT Patienten-Todo aus Abschnitt 12). Validiert 2026-06-19.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| `ident` | bigint | PK |
| `aufgabentitle` | text | Titel (kann leer sein -> Junk/Vorlagen ausfiltern) |
| `text` | text | Beschreibung |
| `availability` | integer | **0 = oeffentlich, 1 = persoenlich** (Checkbox „oeffentlich" im Dialog); NULL = System-Vorlage |
| `status` | integer | **NULL = offen, 1 = erledigt (Fertig)**; 0/2 selten (Sonderzustaende, unbestaetigt) |
| `laststatuschange` | timestamp | Zeitpunkt der letzten Statusaenderung |
| `erdedigungstyp` | integer | 0 = von einem, 1 = von allen |
| `priority` | integer | hoeher = wichtiger (Range ~ -2..+2; Default 0) |
| `von` / `bis` | timestamp | Faelligkeit ab / bis |
| `erstelltam` | timestamp | Anlage |
| `criticaltimespanindays` | integer | NOT NULL |
| `dontrepeat` | boolean | |
| `wiederholungsoption_ident` | bigint | FK -> aufgabenwiederholung |
| `nextrepeatingaufgabe_ident` | bigint | FK -> aufgabe (Serienaufgabe) |
| `ticketnumber` / `referenznummer` | text | Ticket-/Referenznummer |
| `archivedinkartei` | boolean | in Kartei archiviert |
| `removed` | boolean | NOT NULL |
| `ersteller_ident` | bigint | FK -> nutzer |
| `patient_ident` | bigint | FK -> patient (optional, patientenbezogene Aufgabe) |
| `blueprint_ident` | bigint | FK -> outlineviewelement |

### aufgabenempfaenger
`ident`, `nutzer_ident` (FK -> nutzer), `status` (gleiche Enum wie aufgabe.status: NULL=offen/1=erledigt), `laststatuschange`. Bei `erdedigungstyp=0` spiegelt der Empfaenger-Status den Aufgaben-Status; bei `erdedigungstyp=1` (von allen) liegt der Erledigt-Zustand **pro Empfaenger** hier.

### aufgabenlabel
`ident`, `label` (text), `color` (text), `visible` (boolean). Verknuepfung ueber Ticket (siehe Bridges).

### kommentar (fuer aufgabe-Kommentare/Logeintraege)
`ident`, `datum`, `art`, `text`, `nutzer_ident`, `system` (boolean, J=systemgeneriert), `edited`. Systemgenerierte Logeintraege protokollieren Anlage/Zuweisung/Statuswechsel.

### Bridges (alle Spalten = Standardkonvention `aufgabe_ident` / `<relation>_ident`, validiert 2026-06-19)
- **aufgabe_verantwortliche**: `aufgabe_ident` <-> `verantwortliche_ident` (-> aufgabenempfaenger)
- **aufgabe_kommentare**: `aufgabe_ident` <-> `kommentare_ident` (-> kommentar)
- **aufgabe_logeintraege**: `aufgabe_ident` <-> `logeintraege_ident` (-> kommentar)
- **aufgabe_finishconditions**: `aufgabe_ident` <-> `finishconditions_ident`
- **aufgabe_dateien**: `aufgabe_ident` <-> `dateien_ident`
- **ticket_aufgaben** / **ticket_label**: Aufgabe <-> Ticket <-> Label
- **termin_manuallyassociatedtasks** / **termin_preptasks**: `termin_ident` <-> `manuallyassociatedtasks_ident` / `preptasks_ident`

## 12a. Patientenliste (Panel → Patientenliste)

Die in tomedo unter **Panel → Patientenliste** sichtbaren Listen werden in `patientenschlange` gespeichert — **NICHT** in `patientengruppe` (das sind Abrechnungsgruppen).

### patientenschlange
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| name | text | Angezeigter Listenname (z.B. "Kopfschmerz", "Warteliste PT Einzel") |
| removed | boolean | NOT NULL |
| dtype | varchar | NOT NULL. Polymorphie: `Patientenschlange` (manuell), `DICOMModality` (DICOM-Geräte), `HandoffSchlange` (Übergabe) |
| identifier | text | Interner Identifier |
| todokette_ident | bigint | FK → todokette |
| createbesuch | boolean | Automatisch Besuch anlegen |
| karteieintragtypana_ident | bigint | FK → karteieintragtyp (Anamnese) |
| karteieintragtypinfo_ident | bigint | FK → karteieintragtyp (Info) |
| karteieintragtyprech_ident | bigint | FK → karteieintragtyp (Rechnung) |
| karteieintragtypegk_ident | bigint | FK → karteieintragtyp (EGK) |
| noduplicates | boolean | NOT NULL. Keine Duplikate erlaubt |
| aetitle | text | DICOM AE-Title (nur dtype=DICOMModality) |
| modality | text | DICOM-Modalität (nur dtype=DICOMModality) |
| arbeitsplatz_ident | bigint | FK → arbeitsplatz |
| currentmessage_ident | bigint | FK → pappwartezimmerstatusnachricht |

**Bekannte dtype-Werte:**
| dtype | Bedeutung | Beispiel |
|-------|-----------|---------|
| `Patientenschlange` | Manuell angelegte Patientenliste | "Kopfschmerz", "Warteliste PT Einzel" |
| `DICOMModality` | DICOM-Gerätezuordnung | "SZW_B_052", "Cotti" |
| `HandoffSchlange` | Übergabe-/Handoff-Liste | "Rechnungen" |

**Systemgenerierte Liste:** `ZS_EMAIL_AUTO_ASSIGNMENT_TARGETS` — automatisch von Zollsoft erzeugt, enthält E-Mail→Patient-Routing-Zuordnungen.

### patientenschlangeelement
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| checked | boolean | NOT NULL. Abhak-Status in der Liste |
| datum | timestamp | Hinzugefügt am |
| listenposition | real | Sortierposition |
| removed | boolean | NOT NULL |
| patient_ident | bigint | FK → patient (direkt!) |
| infotext | text | Kommentar zum Patienten in dieser Liste |
| karteieintrag_ident | bigint | FK → karteieintrag |
| besuch_ident | bigint | FK → besuch |
| pappwartezimmerelement_ident | bigint | FK → pappwartezimmerelement |

### Bridges
- **patientenschlange_schlange**: `patientenschlange` ↔ `patientenschlangeelement`
- **patientenschlange_messages**: `patientenschlange` ↔ `pappwartezimmerstatusnachricht`
- **patientenschlange_todoketteneintraege**: `patientenschlange` ↔ `todoketteneintrag`

### ⚠ Abgrenzung: patientengruppe ≠ patientenschlange
| Feature | Tabelle | Zweck |
|---------|---------|-------|
| Panel → **Patientenliste** | `patientenschlange` | Manuelle Listen, Wartelisten, Gruppentherapie-Teilnehmer |
| **Patientengruppe** (Abrechnung) | `patientengruppe` | Sammelrechnungen, Abrechnungsgruppen |

---

### 12a-Nachtrag: Gruppenabrechnung & Verzug (Warteschlangen-Analyse 06/2026)

- **Bridge verifiziert:** `patientenschlange_schlange` hat die Spalten `patientenschlange_ident` (→ `patientenschlange.ident`) und `schlange_ident` (→ `patientenschlangeelement.ident`). `patientenschlangeelement.patient_ident` ist Direkt-FK zum Patienten.
- **`patientenschlangeelement.datum` = Anlege-/Dokutag, NICHT Sitzungstag.** Bei Batch-/Spätdokumentation weicht es stark ab → für Sitzungs-Matching das **Datum aus `patientenschlange.name`** parsen, nicht `element.datum`.
- **`removed` = Soft-Delete-Flag:** nach Abrechnung „gelöschte" Gruppenlisten bleiben vollständig erhalten (Name + Mitglieder). Manuelles Präfix `zzz_löschen_`/`ZZZ_löschen_` markiert nur, löscht nicht.
- **Naming-Schema (Gruppe + Therapeut + Datum, variable Reihenfolge/Trenner):** Der Therapeut steht als Kürzel, als Initialen oder als Vornamensanfang — **dieselbe Person erscheint je Liste unterschiedlich**. Die Zuordnung ist praxislokal und einmal zu erheben; ein Gruppieren über das Namensfeld ohne diese Zuordnung zählt eine Person mehrfach. Gruppentokens: „BG Schmerz", „PT-Gruppe/Psychotherapiegruppe", „Stress(bewältigung)", „Kopf/KS", „Bewegung/BEW", „Schlaf".
- Gruppen-PT-Abrechnung läuft über dieses Modul. Kalenderseitige Teilnehmer nur in **Fabrik**; **Studio** = nur Header-Slots (0 Teilnehmer).

## 13. Nachrichten & Erinnerungen

### nachricht
| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| alertdate | Erinnerungsdatum |
| erstellt | Erstellt am |
| iserinnerung | Boolean |
| text | Text |
| wichtig | Boolean |
| verfaelltAm | Verfallsdatum |
| removed | Boolean |
| sender_ident | FK → nutzer |
| patient_ident | FK → patient (direkt!) |

### nachrichtempfaenger
`ident`, `nutzer_ident`, `arbeitsplatz_ident`

### Bridge
- **nachricht_empfaenger**: `nachricht_ident` → `empfaenger_ident` (→ nachrichtempfaenger)

---


### Arbeitsplatz-Spur im Nachrichtensystem

Das Nachrichtensystem ist die **einzige** Stelle in tomedo, an der Aktivitaet mit einem Arbeitsplatz und einem Zeitstempel zusammen vorliegt.

| Feld | Typ | Befuellung an der Referenzinstallation (11/2025 bis 08/2026) |
|------|-----|-------------|
| `nachricht.absenderarbeitsplatz` | text | 7.376 von 20.666 Zeilen, also rund 36 Anteilspunkte. 7.167 davon im Namensschema |
| `nachrichtempfaenger.arbeitsplatz_ident` | FK → `arbeitsplatz` | traegt zusammen mit `nachrichtempfaenger.nachrichtgelesenam` ein Leseereignis am Arbeitsplatz |
| `nachrichtempfaenger.gelesenvon_ident` | FK → `nutzer` | erlaubt den Ausschluss administrativer Konten |

> ⚠ **`absenderarbeitsplatz` ist Freitext und nicht mit `arbeitsplatz.name` gleichzusetzen.** Der Client meldet den Rechnernamen ohne Gruppenpraefix und ohne Rollensuffix. Ein Gleichheits-Join liefert fast nur Nulltreffer, ohne Fehlermeldung. Siehe `lessons-learned.md`, Abschnitt C.

**Nicht als Arbeitsplatzquelle brauchbar** (validiert 2026-08-23):

- `patientenschlange.arbeitsplatz_ident` — FK vorhanden, an der Referenzinstallation **null Zeilen befuellt**, obwohl 4.615 Schlangenelemente ab 11/2025 vorliegen.
- `druckerschlangeelement` — sechs Spalten, **kein Zeitstempel**, kein Arbeitsplatz-FK. `senderidentifier` bei 160 von 12.115 Zeilen befuellt und nie im Arbeitsplatzschema, `karteieintrag_ident` bei null Zeilen.
- `drucker.name` — Drucker sind nach Haus und Etage benannt, nicht nach Arbeitsplatz, und die Tabelle traegt keinen Zeitstempel.

## 13a. Email-System (Vorlagen, Versand, Erinnerungen)

### emailvorlage
Admin > Email-Vorlagen / KIM-Vorlagen. Enthält alle konfigurierten Email-Vorlagen der Praxis.

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| name | text | Interner Vorlagenname (z.B. `'Terminbestätigung'`, `'3-Mahnung'`) |
| subject | text | Betreffzeile (kann tomedo-Platzhalter enthalten, z.B. `$[selektierterTermin %doz]$`) |
| plaincontent | text | Plaintext-Inhalt |
| htmlcontent_ident | bigint | FK → datei (HTML-Inhalt als Datei) |
| mailcc | text | CC-Empfänger |
| removed | boolean | NOT NULL |
| karteieintragtyp_ident | bigint | FK → karteieintragtyp |
| emailaccount_ident | bigint | FK → emailaccount |
| defaulttype | — | Standard-Typ |
| zsident | integer | Zollsoft-Sync-ID |

> ⚠ **Kein FK von karteieintrag auf emailvorlage!** Beim Versand wird der Vorlageninhalt in `karteieintrag.text` aufgelöst — der Vorlagenname geht verloren. Zuordnung MAIL-Aus → Vorlage nur über ILIKE-Matching auf den statischen Betreff-Prefix in `emailvorlage.subject`.

### emailaccount
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| — | — | 45 Spalten, 6 FK. Enthält SMTP/IMAP-Konfiguration. |

Praxen betreiben typischerweise mehrere **Funktions-Accounts** (Kontakt, Rechnung, Fachbereich) auf der eigenen Domain. Für Auswertungen über den Absender heißt das: nicht auf eine Adresse filtern, sondern die Liste der eigenen Funktions-Accounts vorab erheben.

### emailsignatur
`ident`, `name`, + 3 weitere Felder. FK von `emailaccount` und `terminerinnerungart`.

### terminerinnerung
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| errormsg | text | Fehlertext |
| removed | boolean | NOT NULL |
| status | integer | Sendestatus |
| email_ident | bigint | FK → email |
| terminerinnerungart_ident | bigint | FK → terminerinnerungart |
| senddate | timestamp | Versanddatum |
| smsnachricht_ident | bigint | FK → smsnachricht |
| modus | integer | |
| type | text | |
| terminerinnerung_ident | bigint | FK → terminerinnerung (Self-Ref) |


**Auswertungssemantik des Versandprotokolls (Realbefund 2026-08-31)**

**status = 0 heisst versandt, status = 1 heisst gescheitert.** Bei `status = 0` ist genau eines
der Kanalobjekte gesetzt (`email_ident` oder `smsnachricht_ident`) und `errormsg` in der Regel
leer; bei `status = 1` ist kein Kanalobjekt gesetzt und `errormsg` gefüllt.

⚠ **`type` ist NICHT das Kanalfeld.** Es trägt die Nachrichtenart (`TerminErinnerung`,
`TerminÄnderungsbenachrichtigung`). Der **Kanal** wird bestimmt über

1. `email_ident IS NOT NULL` → Mail, `smsnachricht_ident IS NOT NULL` → SMS (nur bei Erfolg);
2. sonst über die Vorlagenbelegung der Stufe: `terminerinnerungart.emailvorlage_ident` bzw.
   `.smsvorlage_ident`. Bei Stufen mit **beiden** Vorlagen ist das eine Prioritätskaskade —
   dann bleibt nur Weg 1 eindeutig.

⚠ **`status` und `errormsg` sind unabhängig.** Eine OTK-2-Erinnerungsstufe schreibt für jeden
nicht-OTK-Termin `status = 0` **mit** Fehlertext („Termin ist kein OTK-2-Termin") — das ist ein
protokolliertes Überspringen, kein Ausfall. Ausfallzählungen über `status`, Ursachenanalysen
über `errormsg`, niemals beides gleichsetzen.

⛔ **`terminerinnerungart.mindaysbeforetermin` und `.maxdaysbeforetermin` sind ungepflegt** —
an der Referenzinstallation stehen beide Felder auf **allen** Stufen auf 0, während empirisch Vorläufe von 4,5 bis
119,5 Tagen gemessen werden. Vorlaufzeit deshalb nur empirisch bestimmen:
`AVG(EXTRACT(EPOCH FROM (t.beginn - te.senddate)) / 86400.0)`.

`terminerinnerungplan` hat **vier Felder mehr als der ZOLLSOFT-DB-Dump kennt**: `listenpos`,
`plantyp`, `giltfuerfremdaenderungen`, `aenderungversandverzoegerung` (per
`json_object_keys(row_to_json(t))` ermittelt). Der Dump ist für diese Tabelle unvollständig.

**Wirkungslogik:** ein Termin erhält nur dann eine Erinnerung, wenn seine **Terminart** *und*
sein **Kalender** in einem `active = true`-Plan liegen. `alleterminarten` und `allekalender`
heben die jeweilige Auswahl auf. Ein vollständig konfigurierter Plan mit `active = false` ist
in den Daten nicht von einem fehlenden Plan zu unterscheiden — deshalb Planzugehörigkeit immer
über die gemessene Abdeckung je Terminart prüfen, nicht über die Konfiguration allein.

### terminerinnerungart
Konfiguration einer Erinnerungsregel (Admin > Terminerinnerungen).

| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| preferredsendtimestart | timestamp | Frühester Versandzeitpunkt |
| preferredsendtimeend | timestamp | Spätester Versandzeitpunkt |
| removed | boolean | NOT NULL |
| emailvorlage_ident | bigint | FK → emailvorlage |
| dontsendonweekends | boolean | NOT NULL |
| listenposition | integer | NOT NULL |
| maxdaysbeforetermin | integer | NOT NULL |
| mindaysbeforetermin | integer | NOT NULL |
| modus | integer | |
| smsvorlage_ident | bigint | FK → smsvorlage |
| emailaccount_ident | bigint | FK → emailaccount |
| combinetermine | boolean | NOT NULL |
| dokumodus | integer | NOT NULL |
| emailsignatur_ident | bigint | FK → emailsignatur |
| karteieintragtyp_ident | bigint | FK → karteieintragtyp |
| aftertermin | boolean | NOT NULL |
| lowerbounddaysfromtermin | integer | NOT NULL |
| upperbounddaysfromtermin | integer | NOT NULL |

### Bridges Email-System
- **emailvorlage_attachments**: `emailvorlage` ↔ `datei`
- **emailvorlage_emailempfaengerlisten**: `emailvorlage` ↔ `emailempfaengerliste`
- **emailvorlage_emailheader**: `emailvorlage` ↔ `emailheader`

### Weitere Tabellen mit emailvorlage-FK
- `recalltyp.emailvorlage_ident` — Recall-System
- `karteiversandprofil.emailvorlage_ident` — Karteiexport
- `frueherkennungerinnerungconfig.emailvorlage_ident` — Früherkennungs-Erinnerungen
- `guiaction.emailvorlage_ident` — Aktionsketten (Email-Versand als Aktion)

---

## 14. Online-Terminkalender (OTK2)

### otkevent
`ident`, `dType` (`OtkAppointment`, `OtkAppointmentSeries`), `eventType`, `otkObjectId`, `createdUtc`, `modifiedUtc`, `queuePayload` (JSON)

### Bridge
- **otkevent_otkappointments**: `OtkEvent_ident` → `OtkAppointments_ident`
- **termin_otkappointments**: `Termin_ident` → `OtkAppointments_ident`

### Suchvorlagen
- **terminsuche**: `ident`, `name`
- **terminketteSuche**: `ident`, `name`

---

## 15. Organisatorisches Cave

### orgcav
`ident`, `datum`, `text`, `primaer` (wichtig), `dokumentierendernutzer_ident`, `removed`

Pfad: `orgcav` → `patientendetails_orgcaves` → `patientendetails` → `patient`

---

## 16. Beschäftigungsstatus & Sozialmedizin

### beschaeftigungsstatus (Zollsoft 03/2026)
Pfad: `patientendetails.beschaeftigungsstatus_ident → beschaeftigungsstatus`
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| erwerbstaetig | boolean | Erwerbstätig |
| arbeitsunfaehig | boolean | Arbeitsunfähig |
| berufsunfaehig | boolean | Berufsunfähig |
| erwerbsgemindert | boolean | Erwerbsgemindert |
| ueberwiegendgeistig | boolean | Überwiegend geistige Tätigkeit |
| ueberwiegendsitzend | boolean | Überwiegend sitzende Tätigkeit |
| woechentlichearbeitszeit | real | Wöchentliche Arbeitszeit (Stunden) |
| freitext | text | Freitext |
| letzteaktualisierung | timestamp | Letzte Aktualisierung |

**Relevanz:** Ermöglicht direkte Analyse der Erwerbsfähigkeit und Arbeitsstatus-Verteilung im Patientenkollektiv ohne Freitext-Parsing. Kombinierbar mit Disziplinzugehörigkeit für Workforce-Preservation-Argumentation.

### zuzahlungsbefreiung (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| beginn | timestamp | Beginn Befreiungszeitraum |
| ende | timestamp | Ende Befreiungszeitraum |
| befreiungtyp | integer | NOT NULL. 1=allgemein, 2=teilweise (deprecated), 3=Schwangerschaft |
| removed | boolean | NOT NULL |

---

## 17. Abwesenheiten & Kapazitätsplanung

### abwesenheit (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| start | timestamp | Beginn |
| ende | timestamp | Ende |
| type | integer | NOT NULL |
| visible | boolean | NOT NULL |
| abwesenheitstyp_ident | bigint | FK → abwesenheitstyp |
| isantrag | boolean | NOT NULL. Ist Urlaubsantrag |
| antragstatus | boolean | Genehmigt ja/nein |
| begruendung | text | Begründung |
| notiz | text | Notiz |
| urlaubsverteilung | text | Verteilungsinfo |

Pfad zum Nutzer: `abwesenheit` gehört zu Nutzer über Bridge-Tabelle (zu explorieren).

**Gemessene Korrekturen (2026-07, Stichprobe 5 Zeilen):**

1. **`ende` ist EXKLUSIV (start + 1 Tag).** Eine eintaegige Abwesenheit am 03.08. steht als
   `start=2026-08-03, ende=2026-08-04`. Jedes `BETWEEN start AND ende` erfasst damit **einen Tag zu viel** —
   korrekt ist `>= start AND < ende`.
2. **`abwesenheitstyp_ident` war in allen Stichproben leer.** Diskriminator ist stattdessen **`type`**
   (beobachtet 1, 2, 4). `type = 2` traegt `urlaubsverteilung` mit `urlaubsanspruchIdent`/`tageConsumed`
   → **`type = 2` = Urlaub**.
3. **Es gibt keine Nutzer-Spalte.** Weder `nutzer_ident` noch `arbeitszeitkonto_ident`. Der Pfad zum
   Nutzer laeuft ueber eine Bridge zu `arbeitszeitkonto` (Core-Data-Feld `ZINV_ARBEITSZEITKONTO`) →
   `arbeitszeitkonto.nutzer_ident`. Der Postgres-Bridgename ist **noch unbestaetigt**; Kandidat nach
   tomedo-Konvention: `arbeitszeitkonto_abwesenheiten`.

**Fachliche Bedeutung:** Ein ArZeKo-Eintrag bewirkt mehr als den Kalender-Sperrtag — er verbucht ueber
`urlaubsverteilung` den Urlaubsanspruch und reduziert via `abwesenheitstyp.factorsollzeit` die Sollzeit im
Arbeitszeitkonto. Ein direkt im Kalender gesetzter Sperrtag tut das **nicht**.

### arbeitszeitkonto

| Feld | Beschreibung |
|------|-------------|
| ident | PK |
| nutzer_ident | FK → nutzer |
| aktiv | Konto aktiv |
| saldo | Zeitsaldo |

### abwesenheitstyp (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| name | text | Bezeichnung (z.B. Urlaub, Krank, Fortbildung) |
| color | text | Farbe |
| consumeurlaub | boolean | Verbraucht Urlaubstage |
| visible | boolean | NOT NULL |

**Relevanz für Kapazitätsplanung:** Ermöglicht Berechnung der effektiven Therapeuten-Verfügbarkeit pro Zeitraum, unabhängig von der Termin-/Sperrzeiten-Analyse.

### terminartlimit (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| maxcount | integer | NOT NULL. Maximale Anzahl |
| timeinterval | integer | NOT NULL. Zeitintervall |
| timeunit | integer | NOT NULL. Enum: Minute, Tag, Woche etc. |
| name | text | Bezeichnung |
| allappointmenttypes | boolean | NOT NULL. Gilt für alle Terminarten |
| allcalendars | boolean | NOT NULL. Gilt für alle Kalender |
| percalendar | boolean | NOT NULL. Pro Kalender |
| perpatient | boolean | NOT NULL. Pro Patient |
| visible | boolean | NOT NULL |

Bridge-Tabellen: `terminartlimit_kalender`, `terminartlimit_terminarten`

**Relevanz für Kapazitätsplanung:** Definiert Kontingentierungsregeln für Terminarten und Kalender — kann für Soll-/Ist-Vergleich der Terminslots herangezogen werden.

### recall (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| datum | timestamp | Recall-Datum |
| removed | boolean | NOT NULL |
| patient_ident | bigint | FK → patient |
| recalltyp_ident | bigint | FK → recalltyp |
| anzahlbenachrichtigungen | integer | NOT NULL |
| faelligam | timestamp | Fälligkeitsdatum |

### recalltyp (Zollsoft 03/2026)
| Feld | Typ | Beschreibung |
|------|-----|-------------|
| ident | bigint | PK |
| name | text | Bezeichnung |
| periode | integer | NOT NULL. Intervall |
| periodenart | integer | NOT NULL. Art des Intervalls |
| visible | boolean | NOT NULL |

### Outlook-Import-Kalender (Post-Migrations-Artefakte)

~30 Kalender mit Namensschema `Outlook__Lastname, Firstname (Rolle)` und `Outlook_New__Firstname Lastname`. Sind `nutzer_ident IS NULL` (Raum-Typ). Enthalten historische Pre-Migrations-Termine mit abweichenden Terminarten (`Gespr` statt `G`, `NT` statt `NTSono`) — insgesamt ~3.967 Termine.

**Für aktuelle Analysen AUSSCHLIESSEN** — nur `kalender.nutzer_ident IS NOT NULL` verwenden. Für Pre-Migrations-Rekonstruktion separat und mit Vorsicht behandeln.

```sql
-- Sauberste Variante: nur Therapeuten-Kalender
AND K.nutzer_ident IS NOT NULL
-- Alternative: Namens-Filter
AND K.name NOT ILIKE '%Outlook%'
```

---


## 18. KI- und LLM-Subsystem (Zollsoft 09/2026)

Im Datenmodell-Dump vor 09/2026 vollstaendig abwesend. Gefunden ueber den Spaltendiff in
der Metabase-Replika.

### llmcall — Telemetrie je Modellaufruf

| Feld | Typ | Bedeutung |
|---|---|---|
| `ident` | bigint | |
| `date` | timestamp | Zeitpunkt des Aufrufs. Spaltenname gleich Typname — immer ueber Alias ansprechen (`c.date`), notfalls `c."date"` |
| `nutzer_ident` | bigint | → `nutzer` |
| `typ` | text | belegte Werte: `KarteiChat`, `AgentSubcall` |
| `modelname` | text | z.B. `gemini/gemini-2.5-flash` (KarteiChat) bzw. `gemini-2.5-flash` (AgentSubcall) — **die Praefixe unterscheiden sich je Typ**, nie auf Gleichheit pruefen |
| `tokeninputcount` / `tokenoutputcount` | integer | |
| `costincent` | real | **US-Cent zum Modell-Listenpreis** (Beleg unten) |
| `visible` | boolean | Standardfilter |

**Kein Fremdschluessel auf `karteieintrag`.** Eine exakte Zuordnung Aufruf → Eintrag ist
nicht konstruierbar; nur ueber Nutzer plus Zeitfenster annaeherbar.

### Weitere Tabellen des Subsystems

| Tabelle | Zweck | Achtung |
|---|---|---|
| `llmchat` | Chatverlauf: `chatid`, `content`, `usecase`, `shortdescription` | `chatid` als moegliche Bruecke zu `llmcall` ungeprueft |
| `llmprompttemplate` | Systemprompts: `usagetype`, `issystemprompt`, `depersonalize`, `verbosity` | |
| `llmchatpromptsuggestion` | vorkonfigurierte Prompts, `macro_ident` → Textbaustein | |
| `dokassistentry` | Dokumentenassistent, **FK `karteieintrag_ident`**, `filingstatus` | einziger Pfad mit direktem Eintragsbezug |
| `dokassistresponsewrapper` | `usereditedkarteitext`, `userediteddate` — misst menschliche Nachbearbeitung | |
| `llmdokassistresponse` | Ergebnisobjekt: `title`, `zusammenfassung`, `processingstatus`, `errorcode` | ⚠ enthaelt `patientnachname`, `patientvorname`, `patientgeburtsdatum` als Klartext — **nie in ein finales SELECT** |
| `llmdocufile` | Diktat/Transkript: `transcript`, `llmresponse`, `generationsnapshotjson` | ⚠ Freitext mit Patientenbezug |
| `llmdocuconfig` | Konfiguration, `isaigenerated` | |
| `asrtrainingsample` | Spracherkennung, `autogenerated`, `transcript` | ⚠ Freitext |

### Kosteneinheit — Verifikationsmethode

`costincent` gegen den Listenpreis des Modells gegenrechnen. Belegt am 22.09.2026 fuer
Gemini 2.5 Flash (0,30 USD je Mio. Input-Token, 2,50 USD je Mio. Output-Token):

| Typ | Token in | Token out | erwartet | gemeldet | Quote |
|---|---|---|---|---|---|
| AgentSubcall | 180.944 | 18.367 | 0,1002 | 0,1000 | **0,998** |
| KarteiChat | 4.155.457 | 151.949 | 1,6265 | 1,3800 | 0,848 |

AgentSubcall trifft auf 0,2 Prozent — die Einheit ist damit belegt. Die Abweichung bei
KarteiChat ist **zu evaluieren**; Arbeitshypothese ist Context Caching des wiederkehrenden
Praefixes. Eine Spalte fuer Cache-Token existiert in `llmcall` nicht.

Beim Wechsel des Modells (konfigurierbar ueber den Hersteller-Support) muss die
Gegenrechnung wiederholt werden — die Einheit gilt je Preisliste, nicht absolut.

## 18. Statistikverwaltung (gespeicherte Statistiken)

Die in der Statistikverwaltung gespeicherten Statistiken liegen in der Datenbank und sind
per SQL auslesbar. Vier Tabellen tragen den Bestand.

### outlineviewelement (Statistik-Knoten)

Universelle Baumknoten-Tabelle von tomedo (108 Spalten, 32 FK) — traegt auch E-Mail-Ordner,
Favoriten und QM. Statistiken werden ueber den Diskriminator gefiltert:
`dtype = 'StatistikOutlineElement'`.

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `ident` | bigint | PK |
| `name` | text | Anzeigename in der Statistikverwaltung |
| `sqlquery` | text | das komplette Statement im Original, inkl. `<ZS:...>`-Tags und `create temporary table`-Bloecken |
| `explanation` | text | Erklaertext, der im Statistik-Dialog erscheint |
| `iscustom` | boolean | `false` = mitgelieferte Zollsoft-Statistik, `true` = selbst angelegt |
| `isgroup` | boolean | `true` = Ordner statt Statistik |
| `removed` | boolean | Loeschmarker. **Achtung:** `outlineviewelement` hat ein `removed`-Feld — anders als `karteieintrag` |
| `visibleingui` | boolean | Sichtbarkeit |
| `listenpos` | integer | Position im Baum |
| `zsident` | text | stabiler technischer Schluessel (`PatientCH`, `besucheOhneZifferAT`) |
| `stdrequestfor` | text | Kontextabsprung, z.B. `PATIENTID2PATIENT` |
| `sqltyp` | integer | Statement-Typ |
| `erstellt` | timestamp | Anlagezeitpunkt |
| `erstelltvon_ident` | bigint | FK → `nutzer`. **An der Referenzinstallation durchgaengig NULL** — Autorenzuordnung nicht lieferbar |
| `statistikbriefvorlage_ident`, `applescriptvorlage_ident` | bigint | angehaengte Vorlagen |
| `predefinedfilters`, `savedpreselections`, `tableautosave`, `savedsorting` | — | Voreinstellungen; Typ ungeprueft, nicht blind projizieren |

### customstatistikelement (Elemente kombinierter Statistiken)

19 Spalten, 1 FK. Traegt **nicht** SQL, sondern die Kriterien einer aus Mengenoperationen
gebauten Statistik.

| Feld | Typ | Bedeutung |
|------|-----|-----------|
| `ident` | bigint | PK |
| `kuerzel` | text | `A`, `B`, `C` — Operand, auf den sich `sqlquery` bezieht. **Mehrere Zeilen koennen dasselbe Kuerzel tragen**: ein Kuerzel ist eine UND-verknuepfte Gruppe, keine Einzelbedingung |
| `elementtyp` | integer | Kriteriumsart, siehe `enums-und-funktionen.md` |
| `suchfreitext` | text | gespeicherte Filterbelegung als ZS-XML, z.B. `<ZS:sqlTyp1>0</ZS><ZS:suchText1>30704</ZS>` |
| `listenpos` | integer | Reihenfolge im Dialog |
| `visible` | boolean | |
| `vonbezugsraumtyp`, `vonbezugsraumanzahl`, `vonbezugsraumanzahltyp` | integer | Zeitraum von |
| `bisbezugsraumtyp`, `bisbezugsraumanzahl`, `bisbezugsraumanzahltyp` | integer | Zeitraum bis |
| `von2*`, `bis2*` | integer | zweites Zeitraumpaar (Vergleichszeitraum) |
| `nutzer_ident` | bigint | FK → `nutzer`, meist NULL |

### Bruecken

| Bruecke | Spalten |
|---|---|
| `outlineviewelement_customstatistikelemente` | `outlineviewelement_ident`, `customstatistikelemente_ident` |
| `outlineviewelement_children` | `outlineviewelement_ident` (Elternknoten), `children_ident` |

### Zwei Bauarten — der zentrale Fallstrick

Eine Statistik enthaelt **entweder** eigenes SQL in `sqlquery` **oder** nur eine
Mengenoperation ueber ihre Elemente (`A`, `B-A`, `A&B`, `(A-B)-C`). Im zweiten Fall ist
`sqlquery` unter 30 Zeichen lang und der gesamte Inhalt steckt in
`customstatistikelement`. Ein Export ueber `sqlquery` allein verliert diese Statistiken
vollstaendig — an der Referenzinstallation 14 von 73, und ausgerechnet die inhaltlich interessanten
(Ziffernkombinationen, Medikamenten- und Diagnosefilter).

### Geloeschte Statistiken

`removed = true` bleibt in der Tabelle stehen, verliert aber die Verknuepfung in
`outlineviewelement_children` — der Ordnerpfad ist dann leer. Damit ist eine versehentlich
geloeschte Statistik ueber ihren Textbestand rekonstruierbar.


## Anhang: Zollsoft-Referenz

> Das vollständige Zollsoft-Herstellerdokument (03/2026, 1.056 Tabellen + 1.147 Bridge-Tabellen)
> liegt als `datenmodell_generated.md` vor. Es wurde für selektive Anreicherung dieses Dokuments verwendet.
> Für Tabellen, die hier nicht dokumentiert sind, ist das Zollsoft-Dokument als Referenz heranzuziehen.
>
> **Wichtig:** Das Zollsoft-Dokument enthält keine Views (`karteieintragwithplaintext`, `DiagnosenWithPlainText`),
> keine Praxis-Learnings, keine validierten JOIN-Pfade und keine Semantik-Erklärungen.
> Diese sind ausschließlich in diesem Dokument dokumentiert.
