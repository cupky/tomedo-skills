# JOIN-Pfade — Korrekte Verknüpfungen zum Patienten (v10)

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- v8 (2026-04-27): + Formular-KE _formulare-Bridge-Hinweis (PatF-Delta)

> Stand: 16.04.2026 · Keine inhaltlichen Änderungen ggü. v6 (keine neuen Pfade in den Threads 31.03.–02.04.2026)

Die Wahl des richtigen JOIN-Pfads ist die häufigste Fehlerquelle. Diese Referenz zeigt für jede Entität den korrekten Weg zum Patienten.

## Pfad-Typ 1: Indirekt über patientendetailsrelationen_*

### Karteieintrag → Patient (Dreifach-Pfad)

#### Wichtig: Formular-KE nutzen die _formulare-Bridge

Bei `karteieintrag.dtype = 'Formular'` (also allen Patientenformularen, PatF etc.)
läuft die Verknüpfung **nicht** über `patientendetailsrelationen_karteieintraege`,
sondern über `patientendetailsrelationen_formulare.formulare_ident`.

Deshalb `GREATEST(...)` über beide Bridges verwenden — sonst fehlen alle
Formular-Karteieinträge im Ergebnis. Empirisch bestätigt 21.04.2026 mit
Patient 32385 (PatF-Terminvereinbarung): die erste Query-Variante mit
nur `_karteieintraege`-Bridge lieferte leer, erst mit Dual-Bridge-Pattern
Erfolg.

**Auch `angefordertesjsonformular.patient_ident`** ist nicht als
robuster Einstiegspunkt geeignet — das Feld ist nur für
tatsächlich per arzt-direct-Link verschickte Formulare gefüllt, nicht
für offline am Tablet oder nachträglich manuell zugeordnete.
```sql
FROM tempKarteiTable A
-- Schritt 1: Kartei → patientendetailsrelationen_ident
LEFT JOIN Patientendetailsrelationen_karteieintraege G ON G.karteieintraege_ident = A.ident
LEFT JOIN Patientendetailsrelationen_formulare H ON H.formulare_ident = A.ident
-- Schritt 2: → patientendetails (mit GREATEST für den nicht-null Pfad)
LEFT JOIN Patientendetails PD ON PD.patientendetailsrelationen_ident = GREATEST(G.patientendetailsrelationen_ident, H.patientendetailsrelationen_ident)
-- Schritt 3: Alternative über Caves
LEFT JOIN Patientendetails_caves CAVES ON CAVES.caves_ident = A.ident
-- Schritt 4: → patient (GREATEST wählt den vorhandenen Pfad)
JOIN Patient P ON P.patientendetails_ident = GREATEST(PD.ident, CAVES.patientendetails_ident)
```


**Bei MAIL-Aus ist die Formular-Bruecke leer** — gemessen 2026-08-26 ueber 20 Minuten Live-Betrieb:
`patientendetailsrelationen_karteieintraege` > 0 Treffer, `patientendetailsrelationen_formulare` = 0.
Fuer `MAIL-Aus` (und vermutlich alle reinen Kommunikations-KE) genuegt die `karteieintraege`-Bruecke.

⚠ **Kreuzprodukt-Falle.** Beide Bruecken gleichzeitig ueber `patientendetails` zu verjoinen und den
KE per `k.ident IN (g.karteieintraege_ident, h.formulare_ident)` zu treffen, erzeugt ein
Kreuzprodukt ueber alle KE des Patienten — Realbefund: 29 identische Zeilen fuer einen Treffer.
Die Dual-Bridge mit `GREATEST()` bleibt richtig, wenn vom **KE aus** gejoint wird
(`g.karteieintraege_ident = k.ident`), nicht vom Patienten aus. Bei `LIMIT 1`-Bedingungen fallen
Duplikate nicht auf; bei Zaehlungen schon.

### Diagnose → Patient (über KV-Schein)
```sql
FROM Diagnose A
JOIN kvschein_quartalsdiagnosen C ON A.ident = C.quartalsdiagnosen_ident
JOIN KVSchein S ON C.kvschein_ident = S.ident
JOIN patientendetailsrelationen_kvscheine PDRK ON S.ident = PDRK.kvscheine_ident
LEFT JOIN patientendetails PD ON PD.patientendetailsrelationen_ident = PDRK.patientendetailsrelationen_ident
LEFT JOIN patient P ON P.patientendetails_ident = PD.ident
```

### Diagnose → Patient (über Privatrechnung)
```sql
FROM Diagnose A
JOIN privatrechnung_quartalsdiagnosen C ON A.ident = C.quartalsdiagnosen_ident
JOIN privatrechnung I ON C.privatrechnung_ident = I.ident
LEFT JOIN patient P ON P.ident = I.patient_ident
```

### Diagnose → Patient (über Patientendetails, für DDI)
```sql
FROM Diagnose A
JOIN Patientendetailsrelationen_diagnosen J ON J.diagnosen_ident = A.ident
LEFT JOIN Patientendetails PD ON PD.patientendetailsrelationen_ident = J.patientendetailsrelationen_ident
LEFT JOIN Patient P ON P.patientendetails_ident = PD.ident
```

### EBM-Leistung → Patient
```sql
FROM Leistung A
JOIN KVSchein S ON A.invkvschein_ident = S.ident
JOIN patientendetailsrelationen_kvscheine PDRK ON S.ident = PDRK.kvscheine_ident
LEFT JOIN patientendetails PD ON PD.patientendetailsrelationen_ident = PDRK.patientendetailsrelationen_ident
LEFT JOIN patient P ON P.patientendetails_ident = PD.ident
WHERE A.dtype = 'EBMLeistung' AND S.visible = true AND A.visible = true
```

### GOÄ-Leistung → Patient
```sql
FROM Leistung A
LEFT JOIN privatrechnung_goaeleistungen J ON J.goaeleistungen_ident = A.ident
JOIN privatrechnung I ON I.ident = J.privatrechnung_ident
LEFT JOIN patient P ON P.ident = I.patient_ident
WHERE A.dtype = 'GOAELeistung' AND I.visible = true AND A.visible = true
```

### HZV-Leistung → Patient
```sql
FROM Leistung A
JOIN hzvschein_hzvleistungen C ON A.ident = C.hzvleistungen_ident
JOIN HZVSchein I ON C.hzvschein_ident = I.ident
JOIN patientendetailsrelationen_hzvscheine PDRK ON I.ident = PDRK.hzvscheine_ident
LEFT JOIN patientendetails PD ON PD.patientendetailsrelationen_ident = PDRK.patientendetailsrelationen_ident
LEFT JOIN patient P ON P.patientendetails_ident = PD.ident
WHERE A.dtype = 'HZVLeistung' AND I.visible = true AND A.visible = true
```

### Medikamentenverordnung → Patient
```sql
FROM medikamentenverordnung A
JOIN patientendetailsrelationen_verordnungen D ON D.verordnungen_ident = A.ident
JOIN patientendetails E ON E.patientendetailsrelationen_ident = D.patientendetailsrelationen_ident
JOIN patient P ON P.patientendetails_ident = E.ident
```

### Heilmittelverordnung → Patient
```sql
FROM heilmittelverordnung hmv
LEFT JOIN patientendetailsrelationen_heilmittelverordnungen D ON D.heilmittelverordnungen_ident = hmv.ident
LEFT JOIN patientendetails E ON E.patientendetailsrelationen_ident = D.patientendetailsrelationen_ident
LEFT JOIN patient P ON P.patientendetails_ident = E.ident
```

---

### Rueckwaertsrichtung: Patientenliste zu Karteieintraegen

Wenn die Kohorte aus Patient-Idents besteht (etwa aus `termin`) und die Karteieintraege dazu
gesucht werden, laeuft der Pfad umgekehrt zum Standardmuster. Das `GREATEST()`-Muster funktioniert
dabei **nicht**, weil es aus zwei Eintragsquellen einen Patienten bildet, nicht umgekehrt.
Stattdessen beide Bridges als `UNION` (nicht `UNION ALL`, sonst Doppelzaehlung bei Eintraegen, die
in beiden Bridges haengen):

```sql
-- Bridge 1: normale Karteieintraege
FROM kohorte KOH
JOIN patient PAB          ON PAB.ident = KOH.patientid
JOIN patientendetails PDB ON PDB.ident = PAB.patientendetails_ident
JOIN patientendetailsrelationen_karteieintraege BRK
     ON BRK.patientendetailsrelationen_ident = PDB.patientendetailsrelationen_ident
JOIN karteieintrag KEB    ON KEB.ident = BRK.karteieintraege_ident
UNION
-- Bridge 2: formularbasierte Eintraege (dtype = 'Formular')
FROM kohorte KOH
JOIN patient PAF          ON PAF.ident = KOH.patientid
JOIN patientendetails PDF ON PDF.ident = PAF.patientendetails_ident
JOIN patientendetailsrelationen_formulare BRF
     ON BRF.patientendetailsrelationen_ident = PDF.patientendetailsrelationen_ident
JOIN karteieintrag KEF    ON KEF.ident = BRF.formulare_ident
```

Nur eine der beiden Bridges zu verwenden laesst die jeweils andere Eintragsart stillschweigend
wegfallen. Derselbe Pfad traegt auch Diagnosen ueber
`patientendetailsrelationen_diagnosen.diagnosen_ident`.

## Pfad-Typ 2: Direkt über patientendetails_*

### Tags → Patient
```sql
FROM patientendetails_tags B
JOIN tag C ON B.tags_ident = C.ident
JOIN patientendetails PD ON PD.ident = B.patientendetails_ident  -- Achtung: patientendetails.ident, NICHT patientendetailsrelationen_ident!
JOIN patient P ON P.patientendetails_ident = PD.ident
WHERE C.gruppe = false AND C.visible = true
```

### OrgCAV → Patient
```sql
FROM OrgCAV O
JOIN patientendetails_orgcaves J ON J.orgcaves_ident = O.ident
JOIN patientendetails PD ON PD.ident = J.patientendetails_ident
JOIN Patient P ON P.patientendetails_ident = PD.ident
```

### HZV-Details → Patient
```sql
FROM patientendetails_hzvDetails JT
JOIN hzvdetails HZVD ON JT.hzvdetails_ident = HZVD.ident
JOIN patientendetails PD ON PD.ident = JT.patientendetails_ident
JOIN patient P ON P.patientendetails_ident = PD.ident
```

---

## Pfad-Typ 3: Direkt über patient_ident

### Termin → Patient
```sql
FROM Termin T
JOIN Patient P ON P.ident = T.patient_ident
```

### Privatrechnung → Patient
```sql
FROM privatrechnung PR
LEFT JOIN patient P ON P.ident = PR.patient_ident
```

### Besuch → Patient
```sql
FROM Besuch B
JOIN Patient P ON P.ident = B.patient_ident
```

### Nachricht → Patient
```sql
FROM Nachricht N
LEFT JOIN Patient P ON P.ident = N.patient_ident
```

---

## Patient → Stammdaten (Basis-JOIN)

```sql
FROM patient P
LEFT JOIN patientendetails PD ON P.patientendetails_ident = PD.ident
LEFT JOIN Kontaktdaten KD ON PD.kontaktdaten_ident = KD.ident
LEFT JOIN Adresse ADR ON KD.adresse_ident = ADR.ident
LEFT JOIN Nutzer N ON PD.arzt_ident = N.ident  -- Erstbehandler
LEFT JOIN Hausarzt HA ON PD.hausarzt_ident = HA.ident
```

---

## Tag-Aggregation (1:n, Standardmuster)

```sql
DROP TABLE IF EXISTS tempTagTable;
CREATE TEMPORARY TABLE tempTagTable AS
SELECT
    A.patientID,
    string_agg(C.beschreibung, ', ' ORDER BY C.beschreibung) AS tags,
    array_agg(C.ident) AS tags_idents
FROM tempPatientTable A
JOIN patientendetails_tags B ON A.patientendetailsID = B.patientendetails_ident
JOIN tag C ON B.tags_ident = C.ident
WHERE C.gruppe = false AND C.visible = true
GROUP BY A.patientID;
```

---

## Termin → Kalender → Nutzer

```sql
FROM Termin T
LEFT JOIN Termin_Kalender T_K ON T_K.termin_ident = T.ident
LEFT JOIN Kalender K ON K.ident = T_K.kalender_ident
LEFT JOIN Nutzer KN ON KN.ident = K.nutzer_ident
LEFT JOIN TerminArt TA ON T.terminart_ident = TA.ident
WHERE TA.infotermin = false AND (T.removed IS NULL OR T.removed = false)
```

Arzt-Ermittlung: `COALESCE(T.behandler, KN.kuerzel) as Arzt`

---

### Termin -> Aenderer (Attribution einer Terminaenderung)

Wer einen Termin zuletzt bearbeitet hat, haengt direkt am Termin — nicht am Kalender und nicht
am Karteieintrag:

```sql
FROM termin TER
JOIN termin_kalender TKB ON TKB.termin_ident = TER.ident
JOIN kalender KAL        ON KAL.ident        = TKB.kalender_ident
LEFT JOIN nutzer AEN     ON AEN.ident        = TER.aenderndernutzer_ident
LEFT JOIN nutzer NUK     ON NUK.ident        = KAL.nutzer_ident
```

Kalender eines Behandlers robust eingrenzen — **alle drei** Kriterien, nicht nur eines:

```sql
WHERE strpos(lower(COALESCE(KAL.name, '')), '<kuerzel>') > 0
   OR strpos(lower(COALESCE(KAL.kuerzel, '')), '<kuerzel>') > 0
   OR TRIM(UPPER(COALESCE(NUK.kuerzel, ''))) = '<KUERZEL>'
```

`kalender.nutzer_ident` ist nicht durchgaengig gesetzt; ein Behandlerkalender kann rein ueber
den Namen identifiziert sein. `DISTINCT` auf `termin.ident` ist Pflicht, weil ein Termin in
mehreren Kalendern haengen kann (Raum- plus Behandlerkalender).

Serienzusammenhang: `termin.serveronlywdhbaseident` gruppiert Wiederholungstermine. Mehrere
Aenderungen am selben Patienten mit gleicher `serveronlywdhbaseident` sind **ein** Vorgang
(Serie am Stueck verschoben), nicht mehrere Fehlgriffe.

## Aufgabe → Nutzer (Ersteller / Verantwortliche)

Ersteller (direkt):
```
aufgabe A → nutzer NE  (NE.ident = A.ersteller_ident)
```

Verantwortliche (ueber Bridge, ggf. mehrere; Kuerzel-Aggregation):
```
aufgabe A
  → aufgabe_verantwortliche AV  (AV.aufgabe_ident = A.ident)
  → aufgabenempfaenger AE       (AE.ident = AV.verantwortliche_ident)
  → nutzer NV                   (NV.ident = AE.nutzer_ident)
-- string_agg(DISTINCT NV.kuerzel, ', ')
```
Empfaenger-Status (offen/erledigt je Person) in `AE.status`.

## Sperrtag → Kalender → Termin (Konflikterkennung)

`terminkalendertag` haengt am **Kalender**, nicht am Termin. Die Verbindung zu Terminen entsteht ausschliesslich ueber `kalender_ident` + Datumsgleichheit:

```sql
FROM terminkalendertag TKT
JOIN kalender           K   ON K.ident   = TKT.kalender_ident
JOIN kalendersperrmodus KSM ON KSM.ident = TKT.kalendersperrmodus_ident
LEFT JOIN nutzer        N   ON N.ident   = K.nutzer_ident
JOIN termin_kalender    TK  ON TK.kalender_ident = K.ident
JOIN termin             T   ON T.ident   = TK.termin_ident
JOIN terminart          TA  ON TA.ident  = T.terminart_ident
WHERE TKT.sperrmodus = 1
  AND T.beginn::date = TKT.tag::date
```

Die Bridge `terminkalendertag_termine` existiert im DB-Dump, ist an der Referenzinstallation aber **nicht** der Weg zur Konflikterkennung — sie fasst nur explizit verknuepfte Termine, nicht alle Termine des gesperrten Tages.

Bei Teilsperren (`TKT.beginn IS NOT NULL`) zusaetzlich Zeitueberlappung pruefen:
```sql
AND (TKT.beginn IS NULL OR (T.beginn < TKT.ende AND T.ende > TKT.beginn))
```

## Sperrtag → Kalender → Nutzer (terminkalendertag)

```sql
FROM terminkalendertag tkt
JOIN kalender k              ON k.ident = tkt.kalender_ident
JOIN nutzer n                ON n.ident = k.nutzer_ident
LEFT JOIN kalendersperrmodus ksm ON ksm.ident = tkt.kalendersperrmodus_ident
WHERE tkt.sperrmodus = 1
  AND (tkt.removed IS NULL OR tkt.removed = false)
```
`LEFT JOIN` auf den Sperrmodus, damit eine Sperre ohne Grund nicht verschluckt wird.
Ganztaegig = `tkt.beginn IS NULL AND tkt.ende IS NULL`; Tagesbezug ueber `tkt.tag::date`.

## Abwesenheit → Arbeitszeitkonto → Nutzer (unbestaetigt)

`abwesenheit` hat **keine** Nutzer-Spalte. Pfad laut Core-Data-Schema:
`abwesenheit → arbeitszeitkonto → nutzer`, verbunden ueber eine Bridge-Tabelle
(Core-Data-Feld `ZINV_ARBEITSZEITKONTO`). Postgres-Bridgename noch zu verifizieren,
Kandidat `arbeitszeitkonto_abwesenheiten`.

## Patient ← Patientenliste (Panel → Patientenliste)

```sql
FROM patientenschlange PS
JOIN patientenschlange_schlange PSS ON PS.ident = PSS.patientenschlange_ident
JOIN patientenschlangeelement PSE ON PSS.schlange_ident = PSE.ident
JOIN patient P ON PSE.patient_ident = P.ident
WHERE PS.removed = false
  AND PSE.removed = false
  AND PS.dtype = 'Patientenschlange'
  AND PS.name = 'DEIN_LISTENNAME'
```

**Hinweis:** `patientenschlange` ist polymorph (dtype). Für manuelle Patientenlisten immer `dtype = 'Patientenschlange'` filtern. Andere Werte: `DICOMModality` (Geräte), `HandoffSchlange` (Übergabe).

**Abgrenzung:** `patientengruppe` ist ein anderes Feature (Sammelrechnungen/Abrechnungsgruppen) — nicht verwechseln!

Direkter FK: `patientenschlangeelement.patient_ident → patient.ident`. Kommentar pro Patient in `PSE.infotext`.

---

## Statistik → Elemente → Ordnerbaum (Statistikverwaltung)

Elemente einer kombinierten Statistik:

```sql
FROM outlineviewelement OVE
JOIN outlineviewelement_customstatistikelemente BRC
  ON BRC.outlineviewelement_ident = OVE.ident
JOIN customstatistikelement CSE
  ON CSE.ident = BRC.customstatistikelemente_ident
WHERE OVE.dtype = 'StatistikOutlineElement'
```

Ordnerpfad ueber die Baum-Bruecke, aufsteigend. Zwei Ebenen genuegen in der Praxis
(an der Referenzinstallation: maximal drei Baumebenen, keine Mehrfachverknuepfung):

```sql
LEFT JOIN outlineviewelement_children BRP ON BRP.children_ident = OVE.ident
LEFT JOIN outlineviewelement          PAR ON PAR.ident = BRP.outlineviewelement_ident
LEFT JOIN outlineviewelement_children BRG ON BRG.children_ident = PAR.ident
LEFT JOIN outlineviewelement          GPA ON GPA.ident = BRG.outlineviewelement_ident
```

Die Bruecke ist formal n:m; empirisch haengt jede Statistik an genau einem Ordner
(an der Referenzinstallation 08/2026: 77 Knoten, 0 Dubletten). Bei Dubletten in anderen Instanzen `DISTINCT`
setzen oder die Pfade aggregieren. Ob der `ZSStatistikFetchSQLConnector` `WITH RECURSIVE`
vertraegt, ist ungeprueft — mit zwei Ebenen wird es nicht gebraucht.


## LLM-Aufruf → Karteieintrag (Negativbefund)

**Kein Fremdschluessel llmcall zu karteieintrag.** Die Telemetrietabelle traegt nur
`nutzer_ident`. Eine exakte Zuordnung „welcher Aufruf erzeugte welchen Eintrag" ist aus dem
Datenmodell nicht ableitbar.

Zulaessige Naeherung, ausdruecklich als Heuristik zu kennzeichnen:

```sql
JOIN llmcall c
  ON c.nutzer_ident = k.dokumentierendernutzer_ident
 AND c.date BETWEEN k.datum - INTERVAL '120 seconds'
                AND k.datum + INTERVAL '120 seconds'
```

Das Fenster faengt bei aktiver Nutzung mehrere Aufrufe je Eintrag — eine Interaktion erzeugt
typischerweise zwei `KarteiChat`-Aufrufe plus drei bis vier `AgentSubcall`. Zaehlungen auf
dieser Basis sind obere Schranken, keine Zuordnungen.

Ungeprueft als moegliche Bruecke: `llmchat.chatid`.


## Kurzreferenz — Kompaktübersicht

*Aus SKILL.md v9 hierher verschoben (v10). Vollständige Pfade mit Filtern siehe oben.*

### Patient ← Leistung (EBM)
```
leistung A → kvschein S (A.invkvschein_ident = S.ident)
  → patientendetailsrelationen_kvscheine PDRK (S.ident = PDRK.kvscheine_ident)
  → patientendetails PD (PD.patientendetailsrelationen_ident = PDRK.patientendetailsrelationen_ident)
  → patient P (P.patientendetails_ident = PD.ident)
```
⚠ **Kein Shortcut für Historie:** `kvschein.patient_ident` ist erst ab 11/2025 befüllt. Für Zeiträume davor zwingend die volle Bridge oben.

### Patient ← Leistung (GOÄ)
```
leistung A → privatrechnung_goaeleistungen J (J.goaeleistungen_ident = A.ident)
  → privatrechnung I (I.ident = J.privatrechnung_ident)
  → patient P (P.ident = I.patient_ident)
```

### Patient ← Karteieintrag (Dreifach-Pfad)
```
karteieintrag KE
  LEFT JOIN patientendetailsrelationen_karteieintraege G (G.karteieintraege_ident = KE.ident)
  LEFT JOIN patientendetailsrelationen_formulare H (H.formulare_ident = KE.ident)
  LEFT JOIN patientendetails PD (PD.patientendetailsrelationen_ident = GREATEST(G...ident, H...ident))
  LEFT JOIN patientendetails_caves CAVES (CAVES.caves_ident = KE.ident)
  JOIN patient P (P.patientendetails_ident = GREATEST(PD.ident, CAVES.patientendetails_ident))
```

### Karteieintrag ← Termin (direkt, Zollsoft 03/2026)
```
karteieintrag KE → termin T (KE.termin_ident = T.ident)
```
Direkter Pfad ohne Bridge-Tabelle.


### Termin → Terminerinnerung (Versandprotokoll)

Spaltennamen **verifiziert 2026-08-31** per `json_object_keys(row_to_json(t))`:

```sql
FROM termin_terminerinnerungen bruecke
JOIN terminerinnerung te          ON te.ident  = bruecke.terminerinnerungen_ident
LEFT JOIN terminerinnerungart tea ON tea.ident = te.terminerinnerungart_ident
WHERE te.removed = false
-- bruecke.termin_ident = termin.ident
```

Ein Termin kann mehrere Protokollzeilen tragen (eine je Stufe und Versuch) — vor dem JOIN an
die Terminpopulation deshalb je `termin_ident` aggregieren, sonst vervielfachen sich die Termine.

**Plankonfiguration (drei Brücken, alle verifiziert):**

```sql
terminerinnerungplan_terminarten             (terminerinnerungplan_ident, terminarten_ident)
terminerinnerungplan_kalender                (terminerinnerungplan_ident, kalender_ident)
terminerinnerungplan_terminerinnerungarten   (terminerinnerungplan_ident, terminerinnerungarten_ident)
```

Muster bestätigt: der Spaltenname der Gegenseite ist der **Namensteil hinter dem Unterstrich**
plus `_ident` — auch dort, wo er im Plural steht (`terminarten_ident`), und auch dort, wo nicht
(`kalender_ident`).

⛔ **Kein Pfad von MAIL-Aus zum Termin.** Der Direkt-FK `karteieintrag.termin_ident` ist bei
`MAIL-Aus` zu **0 von 15.556** Einträgen befüllt (07–08/2026). Eine terminscharfe Aussage über
Erinnerungsmails ist nur über das Versandprotokoll möglich, nicht über die Kartei. Der
Kalenderbezug eines Termins läuft über `termin_kalender` (`termin_ident` → `kalender_ident`).

### Patient ← Patientenliste (Panel → Patientenliste)
```
patientenschlange PS
JOIN patientenschlange_schlange PSS ON PS.ident = PSS.patientenschlange_ident
JOIN patientenschlangeelement PSE ON PSS.schlange_ident = PSE.ident
JOIN patient P ON PSE.patient_ident = P.ident
WHERE PS.removed = false AND PSE.removed = false
  AND PS.dtype = 'Patientenschlange' AND PS.name = 'Listenname'
```
Direkter FK: `patientenschlangeelement.patient_ident → patient.ident`. Kommentar pro Patient in `PSE.infotext`.
