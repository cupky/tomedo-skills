---
name: tomedo-statistik-hql
description: >-
  Erstellt und debuggt HQL-Statistik-Queries (PostgreSQL-Dialekt) fuer das tomedo
  Praxisverwaltungssystem. Verwende diesen Skill IMMER wenn tomedo-HQL, tomedo-Statistik, KV-
  Abrechnung, EBM-/GOAe-Leistungsauswertungen, Patientensegmentierung, Karteieintrag-Analysen,
  Termin-, Kalender- oder Sperrtagsauswertungen oder Praxiskennzahlen erwaehnt werden. Auch
  verwenden bei Query bauen, Statistik erstellen, HQL debuggen, Datenmodell-Frage, JOIN-Pfad
  finden, ZS-Filter einbauen, Umsatz berechnen, Chroniker-Analyse, Wiedervorstellungen zaehlen,
  Feld existiert nicht, Query bricht ab, Ergebnis unplausibel, oder jede Frage zu tomedo-Tabellen
  und -Feldern. Der Skill enthaelt das vollstaendige Datenmodell, validierte JOIN-Pfade, 37 Query-
  Bausteine, ZS-Filter-Syntax und 46 dokumentierte Fehlerquellen.
metadata:
  version: 1.5
---

# tomedo HQL-Statistik Skill

**v10 · 2026-08-04.** Basis: ~25 reverse-engineerte Hersteller-Queries, das Zollsoft-Herstellerdokument
(03/2026, 1.056 Tabellen), 11+ validierte Praxis-Queries und die Erkenntnisse aus 11 Analyse-Threads bis 07/2026.

Diese Datei ist absichtlich kurz. Sie enthaelt die **Verbote**, den **Lese-Routing-Plan** und die zwei Tabellen,
die bei fast jeder Query gebraucht werden. Alles Erklaerende steht in `references/` und wird bei Bedarf gelesen,
nicht auf Vorrat.

---

## 1 · Lese-Routing

| Frage oder Situation | Datei |
|---|---|
| Tabelle oder Feld gesucht | `references/datenmodell.md` |
| „Tabelle/Feld nicht gefunden" trotz Suche | `references/datenmodell_ZOLLSOFT_DB-dump.md` (**autoritativ** ueber `datenmodell.md`) |
| Pfad zum Patienten, Nutzer oder Kalender unklar | `references/join-pfade.md` |
| Bewaehrtes Pattern gesucht (37 Bausteine) | `references/query-bausteine.md` |
| Enum-Wert, Bitfeld, tomedo-eigene Funktion | `references/enums-und-funktionen.md` |
| Query soll reproduzierbar / parametrisierbar werden | `references/zs-filter.md` |
| **Query bricht ab · Ergebnis unplausibel · Feld unerwartet leer** | `references/lessons-learned.md` |
| Struktur- oder Beziehungshypothese ueber Core-Data-Introspektion | `references/llm-toolebene.md` (**nachgeordnet** — dokumentiert, ungeprueft, kein Beleg fuer Tabellen- oder Feldnamen) |
| **Neuer Analyseauftrag · Thread-Start · Scope noch offen** | Erst Scope klären: Nenner, Zeitfenster, Population, Abnahmekriterium — **dann** dieser Skill |
| Kuerzel, Terminart, Karteieintragstyp, Epochengrenze der **eigenen** Installation | `references/praxis-interna.md` |

**Zuerst `references/praxis-interna.md` lesen.** Dort stehen die Kuerzel, Namen und
gemessenen Werte der eigenen Installation — und die Aufloesung der Platzhalter
(`<TYP-A>` und Verwandte), die im uebrigen Text stehen. Ist die Datei noch nicht
ausgefuellt, gilt ausschliesslich der generische Text; dann vor jeder Auswertung, die
auf Kuerzel aufsetzt, die dort genannten Ermittlungsqueries fahren. Praxisbezogene
Angaben gehoeren **nur** in diese Datei, nie in den uebrigen Text.

**Pflicht vor der ersten Zeile SQL:** `datenmodell.md` fuer die beteiligten Tabellen **und** den passenden
Abschnitt aus `lessons-learned.md` lesen. Dort stehen 46 reproduzierte Fehler, gegliedert nach
A Ausfuehrungsumgebung · B PostgreSQL-Fallen · C Pfade und Geldwerte · D Epochen und Feldrealitaet ·
E fachliche Marker und Codes · F Praxis-Codetabellen.

**Reihenfolge beachten:** Ist der Auftrag noch nicht definiert — Scope, Nenner, Zeitfenster, Definition of Done offen — dann gehoert die Strukturierung vor den Query-Bau und laeuft ueber den Opener-Skill. Dieser Skill setzt eine geklaerte Fragestellung voraus.

**Eine Einzelfallauskunft aus dem KI-Chat ist keine Kennzahl.** Der KarteiChat liefert zu *einem*
Patienten Dokumentation, Diagnosen, Leistungen, Formulare und Laborwerte ohne Query — aber ohne
Aggregation, Nenner und Zeitfenster ueber Faelle hinweg. Solche Auskuenfte duerfen nicht als Wert in
eine Auswertung wandern. Umgekehrt ist die Core-Data-Introspektion (`ListEntities`,
`DescribeEntitySchema`) eine **Hypothesenquelle** fuer Beziehungen, kein Beleg fuer Tabellen- und
Feldnamen: der Export sagt nur `className == entityName` im Objektmodell und nichts ueber die
Abbildung auf die PostgreSQL-Schicht. Der Beleg kommt weiterhin aus
`datenmodell_ZOLLSOFT_DB-dump.md`. Details: `references/llm-toolebene.md`.

---

## 2 · Arbeitsablauf

1. **Ohne ZS-Filter bauen** und gegen Echtdaten testen.
2. **ZS-Filter nachruesten** — erst wenn die Query reproduzierbar sein oder ins Forum gehen soll.
3. **Anonymisieren** (Abschnitt 4).
4. **Abgabecheck** durchlaufen (Abschnitt 3).

Bei mehr als einem Ergebnisblock: ein SELECT pro Ausfuehrung, getrennt mit
`-- ============ HIER TRENNEN: SELECT N ============`.

---


### Erfassungsdichte des Traegerfelds vor jeder Zeitreihe pruefen

Ein Feld kann strukturell existieren und trotzdem ueber Jahre unbefuellt sein. Das ist
**nicht** dasselbe wie „Wert null" und faellt beim Query-Bau nicht auf, weil die Query
laeuft und plausible Zahlen liefert.

**Regel:** Bevor eine Kennzahl ueber mehrere Jahre gebaut wird, einen Vorlauf fahren, der je
Jahr die Gesamtzahl gegen die Zahl der befuellten Zeilen stellt:

```sql
SELECT jahr, COUNT(*) AS zeilen,
       SUM(CASE WHEN TRIM(COALESCE(<feld>, '')) <> '' THEN 1 ELSE 0 END) AS befuellt
FROM <tabelle> GROUP BY 1 ORDER BY 1;
```

Ist `befuellt` in frueheren Jahren nahe null, ist die Zeitreihe fuer diese Jahre **nicht
rechenbar**. Diese Jahre gehoeren als „nicht rechenbar" ausgewiesen und aus Grafiken und
Kennzahlen ausgeschlossen — nicht als Nullwert interpretiert. Ein Nullwert waere eine
inhaltliche Aussage, die die Daten nicht tragen.

Realfall (31.08.2026): `kvschein.ueberweisenderarzt` trug 2021 **null** von 12.695 Scheinen.
Die Aussage „2021 kamen alle Patienten ohne Ueberweisung" waere daraus ableitbar und
vollstaendig falsch gewesen.

Zweite Haelfte derselben Regel: Auch ein befuelltes Feld kann eine **Erfassungslogik**
haben, die den Nenner verschiebt. Steht ein Merkmal nur einmal je Patient (auf dem
Erstbeleg), traegt es nur wenige Prozent der Belege — eine Quote „je Beleg im Berichtsjahr"
misst dann die Erfassungslogik, nicht das Merkmal. Vor dem Nenner-Entscheid klaeren, ob das
Merkmal belegweise oder einmalig erfasst wird.

## 3 · Abgabecheck — harte Verbote

Vor jeder Abgabe durchgehen. Jede Zeile ist ein reproduzierter Abbruch oder ein stiller Zahlenfehler;
Details und Codebeispiele in `references/lessons-learned.md`.

| # | Regel | Kategorie |
|---|---|---|
| 1 | **Kein `%`-Zeichen im Query-Text** — auch nicht in Kommentaren. Wildcards ueber `LEFT(TRIM(x), n) = '…'` | A |
| 2 | **Genau ein Semikolon** (Statement-Ende) | A |
| 3 | **Nur ein SELECT pro Ausfuehrung** | A |
| 4 | **Keine System-Katalog-Tabellen** (`pg_tables`, `information_schema`, `pg_catalog`, `pg_stat_*`) — sofortiger tomedo-Crash. Katalogfragen gehoeren in die Metabase-Replika (dort gefahrlos, da die Sperre eine Client- und keine DB-Eigenschaft ist); im Client ersatzweise `json_object_keys(row_to_json(t))` in einer CTE | A |
| 5 | **Jede Datei selbsttragend** — Temp-Tabellen sterben zwischen Runs | A |
| 6 | **ZS-Tags nur im finalen SELECT**, niemals in `CREATE TEMPORARY TABLE` — und nur in einer gespeicherten Statistik vom Typ SQL; im Connector/Metabase gehen sie roh an PostgreSQL | A |
| 7 | **`ROUND()` nur mit `::numeric`-Cast**; `percentile_cont()` liefert `double precision` | B |
| 8 | **String-Literale aus CTE/UNION mit `::text` casten** — sonst `unknown`-Typfehler | B |
| 9 | **Mehrzeichige, eindeutige Aliase** — unquotierte Aliase sind case-insensitiv. Zusätzlich: **keine reservierten Wörter als Alias** (`TO`, `AS`, `IN`, `IS`, `ON`, `OR`, `ALL`, `END`, `USER`, `ORDER`, `TABLE`) — sie erfüllen Regel 9 und brechen die Query trotzdem | B |
| 10 | **Jahresspalte im JOIN mitfuehren**, wenn die Population eine hat — sonst Prozente >100 % | C |
| 11 | **Sperrtage nicht in `termin` suchen** — sie liegen in `terminkalendertag.sperrmodus = 1` | D |
| 12 | **Kein `nachname` / `vorname` / `geburtsdatum` im finalen SELECT** (Abschnitt 4) | — |
| 13 | **Aenderungshistorie nicht in `termin` suchen** — `geaendert` / `aenderndernutzer_ident` halten nur die **letzte** Aenderung; ein Vorher-Zustand existiert nicht. `terminaenderungfuernachricht` ist an der Referenzinstallation leer | D |

---


**Prozentzeichen — Reichweite.** Das Verbot gilt auch fuer Beispiele in den references dieses
Skills. Realfall 2026-09-01: der Kapazitaets-Baustein trug `NOT ILIKE 'Bespr…'` mit Wildcard
und war nicht ausfuehrbar (korrigiert). Praefixpruefungen deshalb immer als
`LEFT(TRIM(feld), n) = 'praefix'`, Enthaltenseins-Pruefungen als
`strpos(lower(feld), 'term') > 0`. Wer einen Baustein kopiert, kopiert auch dessen Fehler —
vor der Uebernahme auf Wildcards pruefen.

## 4 · Datenschutz by Design

Alle Queries laufen vollstaendig lokal auf der praxiseigenen tomedo-Datenbank. Die KI sieht niemals
Patientendaten direkt: sie baut die Abfrage, der Nutzer fuehrt sie aus und meldet nur aggregierte Ergebnisse
zurueck.

**Finaler SELECT** darf `nachname`, `vorname`, `geburtsdatum` **nicht** enthalten. Stattdessen `patientID`
(= `patient.ident`) zur Zuordnung und `alter_jahre` fuer Altersanalysen. In Temp-Tabellen sind die Spalten als
JOIN-Hilfe in Ordnung, im Ergebnis nicht.

**Aktive Warnung — auch bei ausdruecklicher Anforderung.** Enthaelt eine Query personenbezogene Spalten im
Ergebnis, MUSS die KI proaktiv ausgeben:

> ⚠ **Hinweis:** Diese Query enthaelt personenbezogene Spalten (Name/Geburtsdatum) im Ergebnis. Das Ergebnis ist
> nur fuer die lokale Verwendung in tomedo bestimmt. Bitte pruefe es vor dem Teilen mit der KI und entferne
> Klartextdaten. Fuer die Analyse reichen `patientID` und `alter_jahre`.

**Explorative Queries** (Stichproben, Einzelfallpruefung) duerfen Klarnamen enthalten, damit der Nutzer die
Faelle in tomedo identifizieren kann. Ablauf: Warnung ausgeben → Nutzer fuehrt lokal aus → Nutzer entfernt die
personenbezogenen Spalten, **bevor** er Ergebnisse zurueckmeldet. Alternativ nur `patientID` plus Aggregate
zurueckmelden.

Vor Veroeffentlichung (Forum, Vortrag, Verbandsarbeit): absolute Zahlen gegebenenfalls randomisieren.

---

## 5 · ⛔ Die fünf Direkt-Pfad-Korrekturen

Die Zollsoft-Doku 03/2026 listet FK-Shortcuts, die an der Referenzinstallation **nicht tragen**. Korrigierter Stand:

| Feld | Status (Referenzinstallation) | Konsequenz |
|---|---|---|
| `leistung.patient_ident` | **existiert nicht** | Immer Bridge — `kvschein` (EBM) bzw. `privatrechnung_goaeleistungen` (GOÄ) |
| `kvschein.patient_ident` | erst **ab Migration 11/2025** befüllt | Für historische Queries **verboten** — volle Bridge `kvschein → patientendetailsrelationen_kvscheine → patientendetails → patient` |
| `karteieintrag.patient_ident` | **existiert nicht** | Pfad über `patientendetailsrelationen_karteieintraege → patientendetails → patient`; Formular-KE zusätzlich über `_formulare`-Bridge (Dual-Bridge mit `GREATEST()`) |
| `leistung.containedonrechnung_ident` | Feld vorhanden, aber **nicht befüllt** | GOÄ-Pfad über `privatrechnung_goaeleistungen` (`J.goaeleistungen_ident = L.ident`, `J.privatrechnung_ident = I.ident`) |
| `karteieintrag.termin_ident` | Feld vorhanden, **0 von 281.034 befüllt** (Fenster 11/2025–09/2026) | Keine Brücke KE→Termin an der Referenzinstallation. Disziplin und Anwesenheit sind **nicht** über den Termin am Karteieintrag ableitbar (ADR-MFA-06) |

**Kein belastbarer Direkt-Shortcut mehr.** `karteieintrag.termin_ident` galt als der eine Ausnahmefall. Validiert 2026-09-08 über alle 49 Nutzerkürzel im Fenster 11/2025–09/2026: **0 von 281.034** Karteieinträgen tragen einen Terminbezug. Damit ist keiner der fünf dokumentierten Direkt-FK-Shortcuts an der Referenzinstallation nutzbar — der Merksatz unten gilt ausnahmslos.

**Merksatz:** Ein Feld im DB-Dump ist keine Zusage, dass es befüllt ist. Vor Nutzung eines neuen Direkt-FK immer
`COUNT(*) FILTER (WHERE feld IS NOT NULL)` gegen die Gesamtzahl prüfen — drei der vier Shortcuts oben sind genau
daran gescheitert.

---


### ⛔ Korrektur 5 — Doppel-Konten je Kuerzel: nie ueber `nutzer.ident` aggregieren

Die `nutzer`-Tabelle enthaelt **mehrere Datensaetze je Kuerzel**. Realbefund der Referenzinstallation 2026-08-24: 10 von 24 geprueften Kuerzeln doppelt, eines dreifach. Bei **allen sechs Physiotherapeuten** liegt die Historie auf einem Alt-Konto und die aktuelle Aktivitaet auf einem Neu-Konto.

```sql
-- FALSCH: verkuerzt die Historie stillschweigend
GROUP BY nutzer.ident
-- RICHTIG:
GROUP BY TRIM(nutzer.kuerzel)
```

Symptom, wenn die Regel verletzt wird: Ein Behandler erscheint mit unplausibel kurzer Tenure oder mit zwei Zeilen, von denen eine keine Aktivitaet im Auswertungsfenster hat. Ohne Konsolidierung wurde ein Physiotherapeut mit 12 statt 48 Monaten gefuehrt.

Gilt fuer: Tenure- und Erstkontaktproxys, Aktivitaetszaehlungen, Behandlerkennzahlen, jede Whitelist. Eine Query, die nur ein Fenster nach der Migration betrachtet, ist meist unauffaellig — der Fehler schlaegt erst zu, sobald Historie im Spiel ist.

## 6 · Disziplin-Mapping (interdisziplinaere Analysen)

| Disziplin | Signal | Quelle |
|---|---|---|
| Arzt | EBM 30700 | Leistung → KV-Schein |
| Psychologie | EBM 35xxx oder 232xx | Leistung → KV-Schein |
| Physiotherapie | KE-Typ PHY oder BEF_PHY | Karteieintrag → Patient |

PSY-KE-Typ ist als Psycho-Marker **ungeeignet** (24 Nutzer inkl. Ärzte). 30708 ist kein Interdisziplinaritäts-Marker (auch Arzt-Arzt-Fallkonferenzen).


### Disziplinsignal statt Personensignal — die Migrationsgrenze gilt nicht immer

Die Regel „personenscharfe Attribution erst ab 11/2025" wird regelmaessig zu weit ausgelegt und beschneidet Auswertungen ohne Not. Sie gilt fuer die Frage **welcher Behandler**, nicht fuer die Frage **welche Disziplin**.

| Frage | Grenze | Signalweg |
|---|---|---|
| Welcher Behandler hat den Patienten betreut? | ab 11/2025 | `dokumentierendernutzer_ident` plus Rollen-Whitelist |
| Welche Disziplin hat den Patienten beruehrt? | Historie nutzbar (an der Referenzinstallation ab 2019) | Arzt = EBM-Leistung ohne 35xxx/232xx · Psycho = EBM 35xxx/232xx · Physio = KE `PHY`/`BEF_PHY` |

Damit sind Kohorten- und Verlaufsanalysen ueber mehrere Jahre moeglich, wo eine personenscharfe Auswertung nur ein kurzes Fenster haette. Preis: die Basisrate der aerztlichen Ebene liegt hoeher, weil jede EBM-Leistung zaehlt und nicht nur ein klinischer Karteieintrag. **Zahlen aus beiden Wegen niemals in einem Satz mischen** — nur in sich vergleichbar.


---

## 7 · Arbeitsplatzbezug: was tomedo nicht traegt

**Aktivitaetsdaten sind nicht arbeitsplatzattribuiert.** `karteieintrag`, `leistung`, `termin` und `aufgabe` fuehren **kein** Arbeitsplatzfeld. Eine Auswertung „welcher Rechner wurde wann benutzt" ist aus diesen Tabellen nicht ableitbar — unabhaengig davon, wie die Frage gestellt wird.

Praxisweit gibt es genau vier Stellen mit Arbeitsplatzbezug (validiert 2026-08-23 gegen alle 2.137 Tabellennamen des DB-Dumps):

| Feld | Charakter |
|---|---|
| `arbeitsplatz.name` | Stammdatum |
| `nachricht.absenderarbeitsplatz` (text) | **Aktivitaet** — Freitextkopie des Clientnamens |
| `nachrichtempfaenger.arbeitsplatz_ident` + `.nachrichtgelesenam` | **Aktivitaet** |
| `patientenschlange.arbeitsplatz_ident` | Konfiguration, an der Referenzinstallation **null Zeilen befuellt** |

Dazu 14 reine Zuordnungstabellen (`arbeitsplatz_gruppen`, `guiaction_arbeitsplaetze`, `quickfilter_arbeitsplaetze`, `servernachrichttyp_arbeitsplaetze` und weitere) — Konfiguration ohne Zeitachse.

**Konsequenz fuer die Planung:** Von 381.305 zeitgestempelten Ereignissen ab 11/2025 behalten nur die Nachrichtenstroeme eine Arbeitsplatzzuordnung, an der Referenzinstallation rund 7.400 Ereignisse. Das traegt eine **Ja-Nein-Aussage je Arbeitsplatz** („wurde in diesem Monat benutzt"), aber **keine Dauermessung** — die Dichte liegt bei etwa 0,6 Ereignissen je Arbeitsplatz und Tag und damit Faktor 15 unter der Belastbarkeitsschwelle von 9 Ereignissen je aktivem Tag.

**Die Login-Historie existiert, ist aber nicht abfragbar.** Siehe Skill `tomedo-navigation`, Abschnitt Automatisierung.

