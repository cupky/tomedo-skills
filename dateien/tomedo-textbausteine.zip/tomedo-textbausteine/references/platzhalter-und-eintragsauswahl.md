# Platzhalter, Briefkommandos, verschachtelte Bausteine, Eintragsauswahl

Ergänzung zu `SKILL.md`, überarbeitet im Oktober 2026. Alles hier ist, wo nicht anders
vermerkt, **[ungeprüft]** — also noch nicht in der Oberfläche nachgestellt. Vor produktivem Einsatz an einem
Testpatienten ausprobieren.

---

## 1. Reihenfolge der Ersetzung

Beim Einsetzen eines Textbausteins arbeitet tomedo den Text in dieser Reihenfolge ab
[ungeprüft]:

1. feste Platzhalter `|P_…|`, `|A_…|`
2. Datum und Zeit: `|Datum|`, `|Zeit|`, `|Datum+N|`, `|P_Geb|`
3. Geschlechtsweiche `|?G;…|`
4. **Briefkommandos** `$[…]$` im ganzen Text — auch innerhalb von Frage-Blöcken und
   Antworten — als **reiner Text** (Formatierung des Kommando-Ergebnisses geht verloren)
5. übrig gebliebene `$[Kürzel]$` als **verschachtelter Textbaustein**
6. Eintragsauswahl `|{…}|`
7. Frage-Antwort-Dialog für alle `∆…∆`-Blöcke
8. nach „OK“ ein zweiter Durchlauf; dabei entstehen gegebenenfalls Folgedialoge

Folge für den Bau: Briefkommandos und Platzhalter sind schon aufgelöst, wenn der Dialog
erscheint. Ein `$[if …]$` in einer Antwort entscheidet also **vor** dem Dialog, was dort
als Antworttext steht. [ungeprüft]

---

## 2. Feste Platzhalter

| Platzhalter | Wert | Hinweis |
|---|---|---|
| `\|P_NN\|` | Nachname des Patienten | |
| `\|P_VN\|` | Vorname | |
| `\|P_TIT\|` | Titel | |
| `\|P_NZS\|` | Namenszusatz und Vorsatzwort | |
| `\|P_PLZ\|` | Postleitzahl | |
| `\|P_Ort\|` | Ort | |
| `\|P_StrNr\|` | Straße | |
| `\|P_Geb\|` | Geburtsdatum TT.MM.JJJJ | |
| `\|A_NN\|`, `\|A_VN\|`, `\|A_TIT\|` | Nachname, Vorname, Titel des **Hausarztes** des Patienten | |
| `\|Datum\|` | heutiges Datum | `\|?D;4\|` wirkt genauso |
| `\|Zeit\|` | Uhrzeit HH:mm | |
| `\|Datum+N\|`, `\|Datum-N\|` | heute plus/minus N Tage | **genau so schreiben** (`Datum` mit großem D, Rest klein), siehe Falle unten |
| `\|?G;männlich;unbestimmt;weiblich\|` | Text je Geschlecht des Patienten | drei Werte, Trenner Semikolon |
| `\|machZu\|` | wird entfernt; aus der Textbaustein-Tabelle eingefügt, schließt es danach den Karteieintrag | |

Alle Angaben [ungeprüft].

**Leere Werte:** Ist ein Wert leer (kein Titel, kein Hausarzt), verschwindet der Platzhalter
samt **einem** angrenzenden Leerzeichen. `Dr. |P_TIT| |P_NN|` wird so nicht zu doppelten
Leerzeichen. [ungeprüft]

**Geschlechtsweiche mit zwei Werten:** `|?G;er;sie|` ist keine sichere Kurzform. Nach
aktuellem Stand bekommt dann der Mann den leeren Text, „unbestimmt“ den ersten und die Frau
den zweiten Wert. Immer drei Werte angeben. [ungeprüft]

> ⚠️ **Falle Schreibweise `Datum`.** `|DATUM+3|` oder `|datum+3|` vor dem Einsatz testen:
> Nach aktuellem Stand wird nur die Schreibweise `|Datum+3|` sicher ersetzt; bei anderer
> Schreibweise kann tomedo hängen bleiben. [ungeprüft]

Ohne geöffneten Patienten (etwa in einer Vorlage ohne Patientenbezug) werden die
Patientenwerte leer. [ungeprüft]

---

## 3. Briefkommandos im Textbaustein

Jedes Briefkommando `$[…]$` funktioniert im Langtext, auch in Antworten und Fragetiteln.
Das Ergebnis ist reiner Text. Ein Kommando, das sich nicht auflösen lässt, bleibt beim
Einsetzen eines Bausteins ohne Meldung stehen. [ungeprüft]

Kommandosyntax → Skill `tomedo-kommandos`.

**Bedingte Antworten:** Weil Kommandos vor dem Dialog laufen, kann ein `$[if …]$` den Text
einer Antwort je nach Patient verändern. Ob eine dadurch leere Antwort im Dialog als leere
Zeile stehen bleibt, ist nicht geklärt — Aktionsketten-Fragen blenden leere Antworten aus,
für Textbausteine ist das nicht belegt. Vor dem Einsatz testen. [ungeprüft]

---

## 4. Verschachtelte Textbausteine `$[Kürzel]$`

| Regel | Status |
|---|---|
| `$[Kürzel]$` setzt den Langtext des Bausteins mit diesem Kürzel ein (Kürzel exakt, Groß- und Kleinschreibung zählt). | [ungeprüft] |
| Höchstens **30 Ebenen**. Darüber meldet tomedo „Textbausteinersetzungen innerhalb von Textbausteinen sind nur bis zu einer Tiefe von 30 Schritten erlaubt …“ und setzt nichts ein. | [ungeprüft] |
| Heißt das Kürzel zugleich wie ein Briefkommando, gewinnt das **Briefkommando**. Kürzel deshalb nicht wie Kommandos benennen (etwa nicht `a`, `d`, `x`). | [ungeprüft] |
| Außerhalb eines Frage-Blocks: Die Fragen des eingebetteten Bausteins erscheinen im **selben** Dialog wie die übrigen. | [ungeprüft] |
| Innerhalb einer **Antwort**: Die Antwortzeile zeigt die eingebettete Frage als `'Fragetitel'`. Erst wenn diese Antwort gewählt und „OK“ gedrückt wurde, folgt ein **Folgedialog** mit diesen Fragen; dort gibt es „Zurück“. | [ungeprüft] |
| Ein `∆` direkt in einer Antwort ist nicht möglich (es beendet den Block). Verzweigungen gehen nur über `$[Kürzel]$` oder eine Eintragsauswahl in der Antwort. | [ungeprüft] |
| Bausteine mit **Chat-Freigabe** werden über `$[Kürzel]$` nicht gefunden. | [ungeprüft] |
| Doppelte Kürzel: unbestimmt, welcher Baustein eingesetzt wird. | [ungeprüft] |

Muster „Verzweigter Befund“:

```
Schmerzcharakter: ∆Charakter<zsMacroAnswerDivider>dumpf<zsMacroAnswerDivider>neuropathisch, $[npdetail]$∆
```

Der Baustein `npdetail` enthält eigene Fragen (etwa Brennen, Kribbeln, Allodynie). Sie
werden nur gestellt, wenn „neuropathisch“ gewählt wurde. [ungeprüft]

Das ersetzt die abgekündigten **Textbausteinketten** (Startliste und Folgelisten am
Karteieintrag).

---

## 5. Eintragsauswahl `|{…}|`

Eine Eintragsauswahl setzt Inhalte aus der Kartei oder der Medikation des Patienten ein —
alle, die neuesten n oder per Auswahldialog. Im Editor: Reiter „Symbol“ › Knopf „neue
Eintragsauswahl“; das Popover „Eintragsauswahl“ schreibt die Syntax. [ungeprüft]

### Syntax

```
|{Quelle:Liste:Anzahl}|
|{Quelle:Liste:Anzahl:OPTION1<zsMacroOption>OPTION2}|
```

| Teil | Werte |
|---|---|
| Quelle | `Eintragtyp` (Karteieinträge; Liste = **Kürzel** von Karteieintrags- oder Formulartypen, kommagetrennt, ohne Leerzeichen) · `Mediatyp` (Liste = **Name** des Medientyps, kein Kürzel) · `Medik` (Liste = `Plan`, `Bisher` oder `Plan+Bisher`) |
| Anzahl | `*` alle · eine Zahl n = die n **neuesten** · `mc` = Auswahldialog (Mehrfachauswahl) |
| Optionen | siehe Tabelle; mehrere mit `<zsMacroOption>` |

Die alten Schreibweisen `Eintragstyp` und `Medientyp` werden noch erkannt. Ohne
geöffneten Patienten meldet tomedo „Platzhalter kann nicht ausgefüllt werden, da kein
Patient ausgewählt ist.“ und lässt den Platzhalter stehen. Alles [ungeprüft].

### Optionen

| Option | Wirkung | Quelle |
|---|---|---|
| `QUESTIONNAME=…` | Titel des Auswahldialogs (nur `mc`); Standard „generische Auswahl“ | alle |
| `ISSINGLECHOICE` | Auswahldialog als Einzelauswahl (sonst Mehrfachauswahl). Im Editor: Kästchen „Mehrfachauswahl möglich“ **ab**haken | alle (`mc`) |
| `SKIPDIALOGIFEXACTLYONEANSWER` | genau ein Treffer → ohne Dialog einsetzen. Editor: „Wenn nur eine mögliche Antwort existiert, dann diese automatisch wählen“ | alle (`mc`) |
| `NOENTRYPLACEHOLDER=…` | Text bei keinem Treffer; Standard „(keine Einträge)“; leer mit `NOENTRYPLACEHOLDER=` | alle |
| `DIVIDER=…`, `LASTDIVIDER=…` | Trenner; Standard bei `*`/Zahl: überall `, `; bei `mc` wie im Frage-Block (`, ` / ` und `). `FIRSTDIVIDER` wirkt bei `*`/Zahl nicht | alle |
| `PREFIXWHENCONTENT=…`, `SUFFIXWHENCONTENT=…` | Text davor/danach, nur bei mindestens einem Treffer | alle |
| `REVERSEDATEORDER` | älteste zuerst (Standard: neueste zuerst) | alle |
| `MAXDATE=nD` / `MAXDATE=nQ` | nur Einträge der letzten n Tage bzw. ab dem Quartal vor n Quartalen; `0D` = heute, `0Q` = aktuelles Quartal | Kartei, Medien |
| `MINDATE=nD` / `MINDATE=nQ` | nur Einträge, die mindestens n Tage bzw. Quartale alt sind | Kartei, Medien |
| `TRIMANSWER` | Leerzeichen und Zeilenumbrüche am Anfang und Ende jedes Eintrags entfernen | alle |
| `REMOVEALLNEWLINES` | alle Zeilenumbrüche im Eintrag durch Leerzeichen ersetzen | alle |
| `WITHICD` | ICD-Code der verknüpften Diagnose voranstellen | Kartei |
| `GROUPBYTYPE` | nach Typ gruppieren, in der Reihenfolge der Kürzelliste | Kartei |
| `DATEPREFIX` | Datum voranstellen | Kartei |
| `TYPASPREFIX` | Kürzel des Typs voranstellen (`KÜRZEL: …`) | Kartei |
| `TYPNAMEASPREFIX` | Name des Typs voranstellen; mit `TYPASPREFIX` zusammen `KÜRZEL (Name): …` | Kartei |
| `MED_DATEPREFIX` | Verordnungsdatum voranstellen | Medik |
| `MED_DOSIERUNG` | Dosierung anhängen | Medik |
| `MED_ATC` | „(ATC …)“ anhängen | Medik |
| `MED_PZN` | „(PZN …)“ anhängen | Medik |
| `MED_NODUPLICATES` | doppelte PZN nur einmal (der neueste Eintrag bleibt) | Medik |
| `MED_EXCLUDEABGESETZT` | abgesetzte Medikamente ausschließen | Medik |

Alle Angaben [ungeprüft]. Die Kennwörter ohne `=` sind reine Schalter.

> ⚠️ **Editor vor dem Einsatz prüfen:** Nach aktuellem Stand schreibt das Kästchen
> „Leerzeichen und Zeilenumbrüche am Anfang und Ende … entfernen“ die Option
> `REMOVEALLNEWLINES` und das Kästchen „Zeilenumbrüche überall … entfernen“ die Option
> `TRIMANSWER` — also jeweils die andere. Nach dem Setzen im Reiter „Text“ kontrollieren,
> welche Option im Rohtext steht. [ungeprüft]

### Beispiele

```
Bekannte Diagnosen: |{Eintragtyp:DIA:*:TRIMANSWER<zsMacroOption>NOENTRYPLACEHOLDER=keine}|
Letzte drei Befunde: |{Eintragtyp:BEF:3:DATEPREFIX<zsMacroOption>DIVIDER=; <zsMacroOption>LASTDIVIDER=; }|
Aktuelle Medikation: |{Medik:Plan:*:MED_DOSIERUNG<zsMacroOption>MED_EXCLUDEABGESETZT}|
|{Eintragtyp:DIA,ANA:mc:QUESTIONNAME=Welche Diagnosen?<zsMacroOption>MAXDATE=4Q<zsMacroOption>LASTDIVIDER= sowie }|
```

Die Kürzel `DIA`, `BEF`, `ANA` sind Beispiele; einsetzen, was die Praxis als
Karteieintragstyp-Kürzel führt. [ungeprüft]

**Vorsicht bei Karteitexten mit Steuerzeichen:** Enthält ein ausgewählter Karteitext selbst
`∆`, `<zsMacroAnswerDivider>` oder `|P_NN|`, kann er die Auswahl zerbrechen oder nachträglich
ersetzt werden. [ungeprüft]

Steht eine Eintragsauswahl mit `mc` in einer Antwort, erscheint sie dort als
`'Fragetitel'` und wird erst nach „OK“ als Folgedialog gestellt (wie in Abschnitt 4).
[ungeprüft]
