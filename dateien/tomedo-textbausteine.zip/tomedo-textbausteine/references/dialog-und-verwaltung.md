# Frage-Antwort-Dialog und Makroverwaltung

Ergänzung zu `SKILL.md`, überarbeitet im Oktober 2026. Was nicht als Messung gekennzeichnet
ist, gilt als **[ungeprüft]** — noch nicht in der Oberfläche nachgestellt, vor dem Einsatz
prüfen.

---

## 1. Der Dialog zur Laufzeit

### Fenster

| Element | Beschreibung |
|---|---|
| Titel | „Textbausteine“. Bei Leistungs-Textbausteinen steht die Kurzbeschreibung der Leistung dort, bei der Begründung des Steigerungsfaktors „Steigerungsfaktor“. Der Name des Bausteins erscheint nie. |
| links | **Fragenliste** mit allen Fragen des Bausteins und einem Haken „beantwortet“ je Frage (nicht anklickbar). Ein Klick auf eine Frage springt zu ihr. |
| rechts | **Antworten** der aktuellen Frage mit Kästchen; ein Klick in die Zeile schaltet um. Am Ende jeder Frage stehen automatisch „(Eigene Antwort)“ und `___`. |
| unten | Rahmen **„Vorschau“**: der Text mit den bisher gewählten Antworten; offene Fragen erscheinen als Knopf mit dem Fragetitel. Sie aktualisiert sich beim Wechsel der Frage. |
| Knöpfe | **„OK“** (Tooltip „fn+Enter“), **„Abbrechen (ESC)“**, **„Zurück“** (nur im Folgedialog verschachtelter Bausteine), zwei Pfeilknöpfe für vorige/nächste Frage. Es gibt **keinen** Knopf „Weiter“. |
| Hinweiszeile | „Tipp: Mit den Pfeiltasten ▲▼ zur nächsten Antwort, mit Cmd-▲▼ zur nächsten Frage, mit der Leertaste/Enter eine Antwort an-abhaken“ |

Der Dialog sperrt tomedo, bis er geschlossen ist (modal). Er hat keinen Schließknopf in der
Titelleiste, öffnet immer in der Bildschirmmitte und merkt sich nur die Größe. Alles
[ungeprüft].

### Tastatur

| Taste | Wirkung |
|---|---|
| ↓ / ↑ | nächste / vorige Antwortzeile markieren |
| ⌘↓ / ⌘↑ | nächste / vorige Frage (im Kreis, beantwortete werden nicht übersprungen) |
| Leertaste, Return | markierte Antwort an- oder abhaken |
| Enter (Ziffernblock) bzw. fn+Return | „OK“ |
| Esc | „Abbrechen“ (im Folgedialog liegt Esc auch auf „Zurück“) |
| Ziffern, Tab, ←/→ | ohne Funktion |

Alles [ungeprüft]. Anders als bei Aktionsketten-Fragen gibt es **keine** Schnellwahl über
die Ziffern 1–9.

### Ablauf

- **Nichts ist vorausgewählt.** Die erste Antwortzeile ist nur markiert, nicht angehakt.
- **Einzelauswahl** (Frage ohne `ˆ`): Nach dem Anhaken springt der Dialog zur nächsten
  **unbeantworteten** Frage. Ist keine mehr offen, löst er selbst „OK“ aus und fügt den Text
  ein. Andere Antworten werden dabei nicht abgewählt.
- **Mehrfachauswahl** (`ˆ`): kein Sprung, kein automatisches Schließen.
- „OK“ geht jederzeit, auch mit offenen Fragen. Eine offene Frage ergibt leeren Text oder
  den `UNANSWEREDQUESTIONTEXT`; Prefix und Suffix entfallen.
- Gewählte Antworten stehen in der **Reihenfolge der Antwortliste**, nicht in der
  Klickreihenfolge.
- **„Abbrechen“ fügt nichts ein** — auch nicht den statischen Text; das getippte Kürzel
  verschwindet. Aktionsketten aus `ACTION_ANSWER` starten dann nicht.

Alles [ungeprüft].

### „(Eigene Antwort)“, `___` und Datum

- **„(Eigene Antwort)“** ist ein Eingabefeld in der Antwortliste. Tippen hakt die Antwort an.
  Bleibt der Text unverändert, wird der Haken wieder entfernt. Ist sie als einzige gewählt,
  gilt die Frage als unbeantwortet — der Dialog schließt dann nicht von selbst. Die eigene
  Antwort wird nicht gespeichert; sie übernimmt die Schrift der übrigen Antworten.
- **`___`** fügt wörtlich `___` ein. Im fertigen Text ist die erste Sprungmarke markiert, Tab
  springt zur nächsten. Steht `___` in einer eigenen Antwort, wird daraus **kein**
  Eingabefeld im Dialog.
- **`_%d_`**: Die Antwortzeile zeigt links ein Datumsfeld (heute vorbelegt, Kalender), im
  Antworttext steht `…` an der Stelle. Eine Datumsänderung hakt die Antwort an. Eingesetzt
  wird das Datum im Einfügetext (vor `<zsUserText>`). [Sonde C/C4 für Datumsdialog;
  Einzelheiten ungeprüft]

### Folgedialog

Steht in einer Antwort ein verschachtelter Baustein mit eigenen Fragen (`$[Kürzel]$`) oder
eine Eintragsauswahl mit Dialog, zeigt die Antwortzeile nur `'Fragetitel'`. Nach „OK“ folgt
ein zweiter Dialog mit diesen Fragen, sofern die Antwort gewählt war. Nur dort gibt es
„Zurück“; es zeigt den vorigen Dialog erneut und verwirft dessen Antworten. [ungeprüft]

---

## 2. Makroverwaltung

### Aufruf und Fenster

**Verwaltung › Textbausteine/Makros** oder **Admin › Textbausteine/Makros** → Fenster
„Textbausteine-Makroverwaltung“. Weitere Wege: im Textfeld markierten Text per Kontextmenü
„Textbaustein (Makro) hinzufügen“; aus der KI-Assistenten-Verwaltung „In Makro-Verwaltung
bearbeiten ↗“. [ungeprüft]

### Linke Seite

- Baum mit Gruppen, Spalten „Kürzel“ und „Buttontext“, Augen-Symbol bei eingeschränkter
  Sichtbarkeit (Nutzer, Betriebsstätte, Karteityp; die Chat-Freigabe allein zeigt kein Auge).
- Suchfeld mit Filter „Kürzel“, „Buttontext“, „Langtext“.
- Knöpfe „+“, „−“ („Auswahl löschen“), „Gruppe“, „Kopie(n)“, „A..Z↓ Kürzel“,
  „A..Z↓ Buttontext“; Häkchen „gelöschte anzeigen“ mit Knopf „Wiederherstellen“.
- Hinweis: Diagnosenkürzel aus der Favoritenliste erscheinen in der Vervollständigung mit.

Alles [ungeprüft].

### Rechte Seite (Box „Makro“)

| Feld | Regel |
|---|---|
| **Buttontext** | Pflicht, muss eindeutig sein („Ein Eintrag mit diesem Wert existiert schon!“). Beschriftung in der Textbaustein-Tabelle. |
| **Kürzel** | kein Leerzeichen, kein Komma, nicht leer. Doppelte Kürzel werden **nicht** abgewiesen. Leer → tomedo setzt `_` + Buttontext ohne Leerzeichen. |
| **Kommando** | zeigt `$[Kürzel]$`, Knopf „Kopieren“ legt es in die Zwischenablage. |
| **Langtext** | Reiter **„Symbol“** (Fragen als Symbole; Knöpfe „neue Frage“, „neue Eintragsauswahl“; Schriftknopf) und **„Text“** (Rohtext mit `∆…∆`). |
| **Schriftgrößenübernahme** | „wie praxisweit“, „einheitlich“, „angepasst, skaliert“, „exakt“. Die praxisweite Vorgabe steht in den Einstellungen („Schriftgröße von Textbausteinen in großen Eingabefeldern“). |
| **Hilfe zu Expertenfeatures** | öffnet das Handbuch zum Frage-Antwort-Dialog. |
| **Import/Export** | „Import“, „Export“ (Datei `.makro`, „Alles“ oder „Ausgewähltes“), „Upload“ und „Tausch-Center“. |

Alles [ungeprüft].

### Frage-Editor (Klick auf eine Frage im Reiter „Symbol“)

„Fragestellung“, „Antwortmöglichkeiten“ (Knöpfe „+“, „−“, „Datum“), „mehrere Antworten
auswählbar“ (setzt bzw. entfernt `ˆ`), „Text der bei Antwort-Auswahl übernommen wird“,
„abweichender Kurztext in der Antwortauswahl“ (`<zsUserText>`), „Bei Auswahl der Antwort
soll die Aktionskette mit dem folgenden Kürzel gestartet werden“ (`ACTION_ANSWER<n>`), Box
„Eigene Verknüpfung zwischen Antworten“ mit „zwischen 1. und 2. Antwort“, „zwischen letzter
und vorletzter Antwort“, „zwischen anderen Antworten“ (nur aktiv mit „mehrere Antworten
auswählbar“), Text vorangestellt / angefügt / ohne Antwort, „Antwort wiederbenutzen
(s. Tooltipp)“. [ungeprüft]

Beim Anhaken eines Trenner-, Prefix-, Suffix- oder Ohne-Antwort-Kästchens erscheint ein
**leeres** Feld; gespeichert wird die Option ohne Wert, bis man etwas einträgt. [belegt,
Sonde B]

Optionen, die der Editor nicht kennt (etwa `ISSINGLECHOICE`), bleiben beim Speichern
unverändert im Rohtext erhalten. [ungeprüft]

### Reiter „Sichtbarkeit“

Drei Boxen, je mit „Freigabe anpassen…“ [ungeprüft]:

| Box | Wirkung |
|---|---|
| Nutzer/Nutzergruppe/Betriebsstätte | Baustein nur für diese vorgeschlagen. |
| Karteieintragstypen (nur Typ Text) | Baustein **nur** in Text-Karteieinträgen dieser Typen — und **nirgends sonst** (kein Brief, keine Nachricht). Tooltip: „Wird nur in Kartei-Popovern dieses Typs angezeigt. Sonst nirgends.“ |
| Chats | „Kartei-Chat“, „Tom Edo (Support-Chat)“, „LLM Aktionsketteneintrag“. Mit einer Chat-Freigabe fällt der Baustein aus der normalen Vervollständigung und aus `$[Kürzel]$` heraus. |

### Kopieren, Export, Löschen

- **„Kopie(n)“**: neues Kürzel `<Kürzel>_Kopie`. Mitkopiert werden Buttontext, Langtext,
  Schriftgröße, Nutzer, Nutzergruppen, Betriebsstätten. **Nicht** mitkopiert: Karteityp-
  Einschränkung, Chat-Freigabe, Gruppe. [ungeprüft]
- **Export** (`.makro`) enthält nur Langtext, Buttontext, Kürzel und Schriftgrößenmodus —
  keine Sichtbarkeit, keine Chat-Freigabe, keine Gruppen. Nach einem Import also neu setzen.
  Beim Import mit gleichem Buttontext: „Alle bestehenden Einträge überschreiben“ oder „Diesen
  Eintrag doppelt anlegen“. [ungeprüft]
- **Löschen** ist ein Ausblenden: Rückfrage „Markierten Eintrag wirklich löschen?“, Knopf
  „Ja, systemweit löschen“; wiederherstellbar über „gelöschte anzeigen“. Die Knöpfe des
  Bausteins in Textbaustein-Tabellen gehen dabei verloren und kommen beim Wiederherstellen
  nicht zurück. Mehr als 30 Einträge auf einmal löschen nur Admins. [ungeprüft]

---

## 3. Aufruf im Text

- tomedo schlägt Bausteine vor, deren Kürzel mit dem getippten Wortanfang beginnt (ohne
  Rücksicht auf Groß- und Kleinschreibung), Anzeige „Kürzel:   Langtextanfang“.
- **Einsetzen nur mit Return/Enter oder Mausklick** in der Liste. Leertaste und Tab setzen
  nicht ein.
- Ab wie vielen Buchstaben vorgeschlagen wird: Nutzereinstellung „Ab wie vielen getippten
  Buchstaben sollen Textbausteine vorgeschlagen werden?“ (Reiter „Sonstiges“, Standard 1).
- Die Zeichen `# + - § % $ <` direkt vor dem Wort zählen zum Suchbegriff; ein Kürzel mit
  solchem Präfix muss also mit Präfix getippt werden.
- Ein gerade angelegter oder geänderter Baustein ist erst nach wenigen Sekunden per Kürzel
  auffindbar.
- Vervollständigung gibt es in vielen Textfeldern (Kartei, Brief-Popover, E-Mail,
  Nachrichten, Aufgaben, CAVE, Diagnosen, Termininfo u. a.), sofern keine Sichtbarkeits-
  Einschränkung entgegensteht.

Alles [ungeprüft].

### Textbaustein-Tabelle im Karteieintrag

Unter dem Karteieintrag kann je Karteieintragstyp eine Tabelle mit Knöpfen stehen (Standard
4 Spalten; sichtbare Zeilen begrenzt durch eine Systemeinstellung, Standard 30). Klick fügt
den Baustein ein. Kontextmenü u. a. „Neuer Eintrag“, „Eintrag editieren“, „Eintrag löschen“,
„Spalte hinzufügen“, „Zeile hinzufügen“, „Fettdarstellung ein/aus“, „Tabelle aus Datei
laden“, „Tabelle speichern“, „Textbausteine alphabetisch sortieren…“. Bearbeiten braucht ein
eigenes Recht. Buttontexte aus der Verwaltung lassen sich in die Tabelle ziehen. Für den
Nutzer unsichtbare Bausteine erscheinen hellgrau. [ungeprüft]

### Briefvorlagen

`$[Kürzel]$` setzt den Baustein im Brief ein — mit Dialog, als reiner Text. Besteht der
Baustein aus genau einem Briefkommando, wird dieses direkt ausgeführt. [ungeprüft]
Briefkommandos selbst → Skill `tomedo-kommandos`.

### Zahnmedizin

Für zahnärztliche Leistungen gibt es Standard-Textbausteine je Leistung über ein festes
Kürzelmuster (Präfix je Katalog, dann das Leistungskürzel). Für EBM gibt es nichts
Vergleichbares. [ungeprüft]

---

## 4. Textbausteinketten (abgekündigt)

Der Knopf „Textbausteinkette starten…“ am Karteieintrag ist standardmäßig ausgeblendet und
erscheint nur mit einer Systemeinstellung, die keine Oberfläche hat. Bei jedem Start meldet
tomedo, dass Textbausteinketten in einer späteren Version entfallen und stattdessen normale
Textbausteine verwendet werden sollen. Eine Kette besteht aus einer Startliste je
Karteieintragstyp und Listenelementen mit Anzeigetext, Textbaustein, „nächste Liste“ und
Aktionskette; ein Klick fügt den Baustein ein und startet die Kette. Eine Aktionskettenfrage
lässt sich nicht direkt starten (nur über eine Aktionskette mit dem Schritt
„Aktionskettenfrage“). [ungeprüft]

**Empfehlung:** nicht neu einrichten. Verzweigung mit `$[Kürzel]$` in Antworten bauen
(`references/platzhalter-und-eintragsauswahl.md`, Abschnitt 4).
