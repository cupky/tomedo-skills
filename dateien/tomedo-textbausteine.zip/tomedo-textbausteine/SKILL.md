---
name: tomedo-textbausteine
description: >-
  Erstellt tomedo-Textbausteine mit interaktiven Frage-Antwort-Dialogen in korrekter tomedo-
  Syntax. Verwende diesen Skill immer wenn Textbausteine für tomedo erstellt oder bearbeitet
  werden sollen — für beliebige Fachbereiche (Psychosomatik, Chirurgie, Allgemeinmedizin etc.).
  Enthält den Optionskatalog der Frage-Antwort-Dialoge (Mehrfachauswahl per Zirkumflex,
  ISSINGLECHOICE als Autosprung, DIVIDER, FIRSTDIVIDER, LASTDIVIDER, PREFIXWHENCONTENT,
  SUFFIXWHENCONTENT, UNANSWEREDQUESTIONTEXT, REUSEANSWER, Kurztext, Aktionskette je Antwort) sowie
  ein Gate zum Formatierungsgrad (ohne / leicht / stark). Auch verwenden bei: Fließtextvariante
  statt Gliederung, Trennzeichen zwischen Antworten, Standardtext bei leerer Auswahl, Aktionskette
  aus einer Antwort starten, fett im Baustein, Markdown im Baustein. Auch verwenden, wenn ein
  Textbaustein als vorkonfigurierter Prompt für den KarteiChat, den Support-Chat oder eine KI-
  Prompt-Aktionskette dienen soll — dort gelten abweichende Regeln (keine Frage-Antwort-Makros).
metadata:
  version: 1.0
---

# tomedo Textbausteine — Syntax & Stil

## Was sind tomedo Textbausteine?

Textbausteine in tomedo sind Kürzel-basierte Makros, die beim Eintippen des Kürzels (z. B. `+pbef`) einen interaktiven Frage-Antwort-Dialog starten. Das Ergebnis ist ein strukturierter Text im Karteieintrag.

## Geltungsregel für diesen Skill

**Die tomedo-Onlinehilfe sticht.** Bei Widerspruch zwischen diesem Skill und dem
Herstellerhandbuch gilt das Handbuch; der Skill wird korrigiert, nicht verteidigt.
Eigene Messungen gelten nur dort, wo das Handbuch schweigt — und werden als
Messung gekennzeichnet.

Statuskennzeichnung im ganzen Skill: **belegt** (Handbuch oder eigene Sonde),
**plausibel** (Indiz, nicht gemessen), **zu evaluieren** (offen).

Leitquelle: Onlinehilfe › Automatisierung › Textbausteine › „Expertenfeature:
Konfiguration von Frage-Antwort-Dialogen".

---

## Gate 0 — Formatierungsgrad (Pflicht vor dem Bau)

**Vor jedem Neubau und vor jeder Umarbeitung wird der Formatierungsgrad aktiv
erfragt.** Nicht raten, nicht stillschweigend Stufe 1 annehmen.

> Soll der Baustein **ohne**, mit **leicht** oder mit **starker** Formatierung
> gebaut werden?
> Wenn unklar: Wohin geht das Ergebnis — nur lesen am Bildschirm, oder wird der
> Text weiterverarbeitet (KI-Prompt, Briefkommando, Export, Arztbrief)?

| Ziel des erzeugten Textes | Empfehlung |
|---|---|
| Prompt für KarteiChat / Support-Chat / Aktionsketten-Aktion `KI-Prompt` | **Stufe 0** (verbindlich) |
| Wird per `karteiEintragWert … text` in Brief oder Arztbrief ausgelesen | **Stufe 0** |
| Geht in Export, Statistik oder maschinelle Auswertung | **Stufe 0** |
| Karteieintrag, der am Bildschirm gelesen wird | **Stufe 1** (Default) |
| Karteieintrag, der nur gelesen und nie weiterverarbeitet wird | Stufe 2 — **gesperrt**, siehe unten |

Die gewählte Stufe wird im Kopf des ausgelieferten Bausteins als Kommentarzeile
vermerkt (`Formatierungsgrad: Stufe 1`).

---

## Gate 1 — Optionsrunde nach dem Erstbau (Pflicht)

Der Bau läuft **zweiphasig**. Pro Frage einzeln nachzufragen ist bei 25 Fragen
unzumutbar; nach dem Erstbau einmal zu fragen ist zumutbar und fängt die
Sonderfälle ein.

**Phase 1 — Grundbaustein.** Alle Fragen im Regelfall (Einzelauswahl, erster
Eintrag als Normalwert), dazu eine **nummerierte Frageliste** als Tabelle neben
dem Baustein:

| Nr | Fragetitel | Auswahl | Normalwert | Optionen |
|---|---|---|---|---|
| F01 | Pünktlichkeit | einzeln | pünktlich erschienen | — |
| F02 | Kontakt | mehrfach | zugewandt | — |

**Phase 2 — Optionsrunde.** Eine Frage an den Nutzer:

> Sollen einzelne Fragen Sonderoptionen bekommen? Bitte Nummer und Wunsch
> nennen — z. B. „F02 mehrfach", „F09 Kette bei 'vorhanden'", „F04 Suffix".

Antwort → nur die benannten Blöcke werden gepatcht, alles andere bleibt
unberührt.

**Die Nummern stehen ausschließlich in der Tabelle, nie im Bausteintext** —
sonst landen sie im Karteieintrag.

Aktiv anbieten statt abwarten: eine **Aktionskette je Antwort** bei
Alarmantworten (z. B. „Suizidalität vorhanden"), und **„Antwort wiederbenutzen"**
bei Bausteinen, in denen dieselbe Frage mehrfach vorkommt.

---

## Die drei Formatierungsgrade

### Stufe 0 — ohne Formatierung (Fließtext / maschinenlesbar)

Ergebnis ist ein zusammenhängender Absatz, die Blöcke stehen **inline im Satz**.

**Erlaubt:** Fließtext, `∆`-Blöcke mitten im Satz, Einzelauswahl mit tragfähigem
Normalwert, Mehrfachauswahl mit den Standardtrennern, cp1252-sicherer Zeichenvorrat.

**Verboten:** `== Gruppe ==`, Zeilenumbrüche als Struktur, Aufzählungszeichen,
Markdown (`**`, `#`, `__` — wird im Karteieintrag **nicht** interpretiert und
bleibt wörtlich stehen), Emoji, `→`, Halbgeviertstrich (außerhalb cp1252;
stattdessen `=>` und `-`), jede Zeichenformatierung.

```
Der Patient ist ∆¥ISSINGLECHOICE¥Pünktlichkeit<zsMacroAnswerDivider>pünktlich<zsMacroAnswerDivider>leicht verspätet<zsMacroAnswerDivider>deutlich verspätet∆ erschienen, wirkte im Kontakt ∆¥UNANSWEREDQUESTIONTEXT=zugewandt¥ˆKontakt<zsMacroAnswerDivider>zugewandt<zsMacroAnswerDivider>offen<zsMacroAnswerDivider>misstrauisch∆ und im Antrieb ∆¥ISSINGLECHOICE¥Antrieb<zsMacroAnswerDivider>unauffällig<zsMacroAnswerDivider>vermindert<zsMacroAnswerDivider>gesteigert∆.
```

### Stufe 1 — leichte Formatierung (Struktur in reinem Text) — Default

Gliederung ausschließlich über Zeichen, die selbst Text sind.

**Zusätzlich erlaubt:** Abschnittsüberschriften `== Gruppenname ==`, eine Frage
pro Zeile, Leerzeile zwischen Gruppen, Label-Doppelpunkt-Muster, ASCII-Aufzählung
`- `, Trennzeile `---`.

**Weiterhin verboten:** Zeichenformatierung, Markdown-Inline, Emoji als
Bedeutungsträger.

### Stufe 2 — starke Formatierung — GESPERRT, und stark eingedampft

> ⛔ **Wird derzeit nicht ausgeliefert.** Bei Anfrage auf Stufe 1 ausweichen und
> das Sondenprotokoll anbieten.

Messstand (Sonden A und B, Referenzinstallation):

| Mittel | Ergebnis im Karteieintrag | Status |
|---|---|---|
| **fett** | kommt an — aber nur in bestimmten Positionen | belegt |
| unterstrichen | geht verloren, Text kommt flach an | belegt |
| Farbe | geht verloren | belegt |

**Von den drei geplanten Mitteln bleibt nur fett.** Damit ist Stufe 2 nicht mehr
„Rich Text", sondern „fett an wenigen Stellen".

Positionsmuster [Sonde C/C8–C10]:

- Fett an einer **Antwortoption innerhalb** des `∆`-Blocks → **kommt an**, reist
  mit der Antwort mit
- Fett auf **statischem Text** → **geht verloren**, gleich an welcher Stelle der
  Zeile. Sonde C hat Zeilenanfang und Zeilenmitte geprüft; beide kamen flach an.
- Offen bleibt allein der Fall „komplette Zeile ab Spalte 0 gefettet"

**Damit bleibt von Stufe 2 genau ein Mittel übrig: fett an Antwortoptionen.**
Statischer Text lässt sich gar nicht auszeichnen.

Ebenfalls belegt: `∆`-Blöcke brechen durch Formatierung **nicht**. Die zunächst
geplante Regel „nie an oder in einem Block formatieren" entfällt ersatzlos.

Weiter gilt: jede Bedeutung, die an Auszeichnung hängt, bekommt eine
ASCII-Redundanz (`ACHTUNG:` im Text). Und Stufe 2 bleibt unzulässig, sobald der
Text irgendwo weiterverarbeitet wird.

**Nicht per Syntax steuerbar:** Zeichenformatierung erzeugt **keinen** Zuwachs im
Rohtext (Sonde B/Z11). Sie liegt in der RTF-Ebene. Folge: ein Stufe-2-Baustein
lässt sich **nicht** als Text ausliefern — er muss im Editor nachformatiert
werden. Der Skill liefert dafür Text plus Formatierungsplan.

**Der Karteieintragstyp sticht.** Bringt der Zieltyp eine eigene Formatierung mit
(etwa Anamnese-Zeilen durchgehend grün), überschreibt sie jede Formatierung des
Bausteins — auch nachträglich beim Umhängen eines bestehenden Eintrags auf einen
anderen Typ. Formatierung im Baustein ist damit nicht nur schwach, sondern
jederzeit durch eine Typänderung zerstörbar. [belegt, Referenzinstallation]

**Auslesen per Briefkommando:** `$[karteiEintragWert <Typ> text _ N]$` liefert
**reinen Text**; Fettschrift aus dem Eintrag kommt flach an, Tags stehen keine im
Ergebnis. Der Typ im Kommando muss dem Typ des Eintrags entsprechen — sonst
kommt leer zurück. [belegt, Sonde C/S-7]

---

## Sonderzeichen und Marker

| Zeichen | Mac | Windows | Bedeutung |
|---------|-----|---------|-----------|
| `∆` | ⌥+J | Alt+8710 | Öffnet/schließt einen Frage-Block |
| `¥` | ⌥+Y | Alt+0165 | Klammert den Optionsblock |
| `ˆ` | — | — | **Mehrfachauswahl**, steht direkt vor dem Fragetitel |
| `<zsMacroAnswerDivider>` | ausschreiben | ausschreiben | Trennt Antwortoptionen |
| `<zsMacroOption>` | ausschreiben | ausschreiben | Trennt **mehrere Optionen** innerhalb eines `¥…¥`-Blocks |
| `<zsUserText>` | ausschreiben | ausschreiben | Trennt **Einfügetext** (davor) von **Dialog-Label** (dahinter) |
| `___` | ausschreiben | ausschreiben | Freitext-Platzhalter — im Dialog ohnehin automatisch angeboten |
| `_%d_` | Knopf „+ Datum" | — | Datums-Antwortoption |

`ˆ` ist ein Modifier-Zeichen, nicht der ASCII-Zirkumflex `^`. Beim Bau **aus dem
Konfigurator übernehmen oder kopieren**, nicht tippen.

---

## Grundstruktur eines Frage-Blocks

```
∆¥OPTION1<zsMacroOption>OPTION2¥ˆFragetitel<zsMacroAnswerDivider>Antwort1<zsMacroAnswerDivider>Antwort2∆
```

Bestandteile in dieser Reihenfolge:

1. `∆` öffnet
2. optional `¥…¥` mit einer oder mehreren Optionen, verkettet mit `<zsMacroOption>`
3. optional `ˆ` → Mehrfachauswahl
4. **Fragetitel** (erscheint als Button-Label)
5. `<zsMacroAnswerDivider>` + Antwortoptionen
6. `∆` schließt

Ohne Optionsblock entfällt `¥…¥` ersatzlos: `∆ˆTitel<zsMacroAnswerDivider>A∆`.

---

## Auswahlart: die wichtigste Unterscheidung

| | Einzelauswahl | Mehrfachauswahl |
|---|---|---|
| Marker | kein `ˆ` | `ˆ` vor dem Fragetitel |
| Ergebnis | genau eine Antwort | alle gewählten, verkettet |
| Autosprung | nur mit `ISSINGLECHOICE` | nicht vorgesehen |

**`ISSINGLECHOICE` bedeutet nicht „Einzelauswahl".** Laut Handbuch springt der
Dialog damit nach Auswahl einer Antwort automatisch zur nächsten Frage — es ist
ein **Sprungverhalten**, keine Auswahlsemantik. [belegt, Handbuch]

Bei Mehrfachauswahl springt tomedo grundsätzlich nicht automatisch weiter; hier
wird über „Weiter" bestätigt. [belegt, Handbuch/Forum]

---

## Optionskatalog

Alle Werte stehen hinter `=` und werden mit `<zsMacroOption>` aneinandergereiht.

| Option | Wirkung | Status |
|---|---|---|
| `ISSINGLECHOICE` | Autosprung zur nächsten Frage | belegt |
| `DIVIDER=` | Trenner zwischen den mittleren Antworten (Standard `, `) | belegt |
| `FIRSTDIVIDER=` | Trenner zwischen 1. und 2. Antwort (Standard `, `) | belegt |
| `LASTDIVIDER=` | Trenner vor der letzten Antwort (Standard ` und `) | belegt |
| `PREFIXWHENCONTENT=` | Text davor, **nur** wenn mindestens eine Antwort gewählt | belegt |
| `SUFFIXWHENCONTENT=` | Text danach, **nur** wenn mindestens eine Antwort gewählt | belegt |
| `UNANSWEREDQUESTIONTEXT=` | Text, wenn **keine** Antwort gewählt | belegt (Sonde C/C1) |
| `ACTION_ANSWER<n>=<Kürzel>` | startet bei Auswahl der n-ten Antwort eine Aktionskette | belegt (Kettenstart gemessen) |
| `REUSEANSWER` | koppelt zwei gleichlautende Fragen: gemeinsame Auswahl, zweite Frage wird im Durchlauf übersprungen | belegt (Sonde C/C11–C13) |
| `TRIMANSWER` | soll den Antworttext beschneiden — **ohne erkennbare Wirkung**, Leerraum blieb erhalten | gemessen wirkungslos (Sonde C/C6) |
| `NOENTRYPLACEHOLDER=` | Ersatztext, wenn keine Einträge vorliegen | zu evaluieren |
| `QUESTIONNAME=` | benennt die Frage separat vom Text | dokumentiert, im GUI-Weg nicht nötig |
| `SKIPDIALOGIFEXACTLYONEANSWER` | soll den Dialog bei genau einer Antwort überspringen — **Frage wurde trotzdem gestellt** | gemessen wirkungslos (Sonde C/C7) |

Nur für Auswahlblöcke über Karteieinträge (`|{Eintragtyp:…}|`, anderer
Mechanismus): `MAXDATE=`, `MINDATE=`, `REVERSEDATEORDER`, `GROUPBYTYPE`,
`TYPASPREFIX`. Einheiten bei MAXDATE/MINDATE: `D` für Tage und `Q` für Quartale,
gezählt ab heute bzw. ab dem aktuellen Quartal.

### Trenner — gemessenes Verhalten

Standard ohne jede Option, vier Antworten gewählt:

```
ZWEI, DREI und VIER
```

**Die Aktivierungsfalle:** Solange das Häkchen aus ist, zeigt der Konfigurator
den Standardwert als Text an (`', '` bzw. `' und '`). Beim Anhaken wird daraus
ein **leeres Eingabefeld** — der Standard wird nicht übernommen. Wer anhakt und
nichts einträgt, setzt aktiv einen leeren Trenner: aus zwei gewählten Antworten
wurde so `DREIVIER`. [belegt, Sonde B]

**Regel:** Standardtrenner nicht anfassen. Sie erzeugen bereits eine korrekte
deutsche Aufzählung (`ZWEI, DREI und VIER`). Wer anhakt, trägt zwingend einen
Wert ein.

Die Anführungszeichen in der Standardanzeige markieren die Leerzeichen; die
gehören mit ins Feld.

| Feld | Standard | Regelwert |
|---|---|---|
| `FIRSTDIVIDER=` (1. zu 2. Antwort) | `, ` | Komma + Leerzeichen |
| `DIVIDER=` (übrige Antworten) | `, ` | Komma + Leerzeichen |
| `LASTDIVIDER=` (vor der letzten) | ` und ` | Leerzeichen + und + Leerzeichen |

Sinnvolle Abweichungen:

| Situation | Werte |
|---|---|
| Antworttexte enthalten selbst Kommata („Kopf, Nacken") | `; ` statt `, ` |
| Antworten sind ganze Sätze | `. ` in allen drei Feldern, kein „und" |
| Aufzählung in einer Verneinung | ` sowie ` statt ` und ` |
| Alternativen statt Aufzählung | ` oder ` |

Abweichungen immer in **allen betroffenen Feldern gleichzeitig** setzen, sonst
entsteht eine Mischform (`A; B und C`).

### Prefix und Suffix — gemessenes Verhalten

Beide werden **ohne automatisches Leerzeichen** angesetzt:

```
PREFIXWHENCONTENT=Es besteht    →   Es bestehtZWEI
SUFFIXWHENCONTENT=.             →   EINS.
```

Nötige Leerzeichen gehören in den Wert. [belegt, Sonde B]

Ihr Nutzen laut Handbuch: bei mehreren Fragebausteinen hintereinander sorgen sie
für einheitliche Trennung, ohne dass leere Antworten überzählige Trennzeichen
hinterlassen — anders als Trennzeichen, die als statischer Text zwischen den
Fragen stehen.

**Praxisregel:** Sobald ein Rahmensatz ohne Auswahl sinnlos würde, gehört er in
`PREFIXWHENCONTENT`/`SUFFIXWHENCONTENT` statt in den statischen Text.

### Abweichender Kurztext

```
∆Titel<zsMacroAnswerDivider>EINFÜGETEXT<zsUserText>DIALOG-LABEL<zsMacroAnswerDivider>…∆
```

**Die Zuordnung ist umgekehrt zur naheliegenden Lesart.** Der Text **vor**
`<zsUserText>` landet im Karteieintrag; der Text **dahinter** erscheint als
Auswahlzeile im Dialog. [belegt, Sonde C/C2]

Nutzen: ausführliche, selbsterklärende Auswahlzeile bei knappem Ergebnistext —
etwa `o.B.<zsUserText>unauffälliger Befund, keine Auffälligkeiten`.

### Aktionskette je Antwort

```
∆¥ACTION_ANSWER2=Kaudal¥Titel<zsMacroAnswerDivider>EINS<zsMacroAnswerDivider>ZWEI∆
```

`<n>` zählt die **Antworten**, der Fragetitel zählt nicht mit. Der Kettenstart
ist gemessen. Damit wird ein Dokumentationsbaustein zum Workflow-Auslöser —
etwa Alarmkette bei „Suizidalität vorhanden".

### Datums-Antwortoption

Der Knopf „+ Datum" fügt `_%d_` als Antwortoption ein. Die Auswahl öffnet einen
**Datumsdialog**, der aktiv bestätigt werden muss; das Tagesdatum ist vorbelegt.
Im Karteieintrag steht danach das formatierte Datum (`15.09.2026`).
[belegt, Sonde C/C4]

Kein stiller Einsetzer: wer nur ein automatisches Tagesdatum will, nimmt das
Briefkommando statt der Antwortoption.

### Antwort wiederbenutzen

Keyword: **`REUSEANSWER`**, als normale Option im `¥…¥`-Block.

```
∆¥REUSEANSWER¥Titel<zsMacroAnswerDivider>EINS<zsMacroAnswerDivider>ZWEI∆
```

**Beide** Fragen tragen die Option. Als identisch gelten Fragen mit gleichem
Fragetext, gleichen Antworttexten und gleichen Füllwörtern.

Gemessenes Verhalten [Sonde C/C11–C13]:

- Die Kopplung ist **bidirektional**. Eine Änderung an einer der beiden Fragen
  zieht die andere nach — es gibt keine Ursprungs- und keine Folgefrage.
- Der Dialog **überspringt** die Partnerfrage im Durchlauf: nach der ersten
  Frage geht es direkt zur übernächsten. Beide bleiben in der Fragenliste
  sichtbar und einzeln anklickbar.

Bei langen Befundbausteinen mit wiederkehrenden Fragen aktiv anbieten.

> ⚠️ **Kollisionsgefahr.** Zwei inhaltlich verschiedene Fragen mit zufällig
> gleichem Fragetext und gleichen Antworten koppeln ungewollt, sobald beide
> `REUSEANSWER` tragen. Abhilfe: Fragetexte unterscheiden oder Option weglassen.

---

## Abschnittsüberschriften — Korrektur

`== Gruppenname ==` wird **nicht** als Überschrift gerendert. Der Text steht
wörtlich im Karteieintrag. [belegt, Sonden A und B]

Es bleibt trotzdem als optische Konvention in Stufe 1 brauchbar — aber als das,
was es ist: sichtbarer Text. Wer keine Doppel-Gleichheitszeichen im Befund will,
nimmt eine Label-Zeile ohne `==`. In Stufe 0 entfällt das Konstrukt.

---

## Statischer Text zwischen Blöcken

Text außerhalb von `∆…∆` wird wörtlich übernommen. Vorsicht bei
Mehrfachauswahl-Blöcken, die leer bleiben können: statischer Rahmentext steht
dann sinnlos da. Dafür gibt es `PREFIXWHENCONTENT`/`SUFFIXWHENCONTENT`.

---

## Zeilenstruktur (Stufe 1)

- Jede Frage auf einer eigenen Zeile
- Leerzeile zwischen Gruppen
- Innerhalb einer Gruppe nur einfacher Zeilenumbruch

In **Stufe 0** entfallen alle Zeilenumbrüche.

---

## Entscheidungsbaum

```
Gate 0: Formatierungsgrad geklärt?  (Pflicht)
└── ja
    Mehrere Antworten gleichzeitig wählbar?
    ├── JA  → ˆ vor den Fragetitel
    │         Soll bei leerer Auswahl Text erscheinen?
    │         ├── JA  → ¥UNANSWEREDQUESTIONTEXT=…¥
    │         └── NEIN → Rahmentext in PREFIX/SUFFIXWHENCONTENT verlagern
    └── NEIN → kein ˆ, erster Eintrag = Normalwert
              Soll der Dialog automatisch weiterspringen?
              ├── JA  → ¥ISSINGLECHOICE¥
              └── NEIN → ohne Option
Gate 1: Optionsrunde nach dem Erstbau  (Pflicht)
```

---

## Vollständiges Beispiel Stufe 1

```
== Erscheinungsbild ==
Pünktlichkeit: ∆¥ISSINGLECHOICE¥Pünktlichkeit<zsMacroAnswerDivider>pünktlich erschienen<zsMacroAnswerDivider>leicht verspätet erschienen<zsMacroAnswerDivider>deutlich verspätet erschienen∆.
Kleidung: ∆¥ISSINGLECHOICE¥Kleidung<zsMacroAnswerDivider>unauffällig<zsMacroAnswerDivider>dezent<zsMacroAnswerDivider>überwiegend dunkel<zsMacroAnswerDivider>bunt∆.
Kontakt: ∆¥UNANSWEREDQUESTIONTEXT=zugewandt¥ˆKontakt<zsMacroAnswerDivider>zugewandt<zsMacroAnswerDivider>offen<zsMacroAnswerDivider>bemüht<zsMacroAnswerDivider>misstrauisch<zsMacroAnswerDivider>verschlossen∆.

== Suizidalität ==
ACHTUNG - Suizidgedanken: ∆¥ISSINGLECHOICE<zsMacroOption>ACTION_ANSWER3=alarmkette¥Suizidgedanken<zsMacroAnswerDivider>glaubhaft verneint<zsMacroAnswerDivider>passiv geäußert<zsMacroAnswerDivider>aktiv geäußert∆.
```

Die letzte Zeile zeigt beides: zwei Optionen mit `<zsMacroOption>` verkettet und
eine Kette, die genau bei der dritten Antwort anspringt.

---

## JavaScript-Hilfsfunktion

```javascript
const DIVIDER = "<zsMacroAnswerDivider>";
const OPT     = "<zsMacroOption>";
const MULTI   = "ˆ";           // aus dem Konfigurator kopieren, nicht tippen
const Y = "¥";
const D = "∆";

// titel     = Button-Label, steht als erstes Element im Block
// antworten = Auswahloptionen
// multi     = true  → ˆ (Mehrfachauswahl)
// optionen  = Array, z.B. ["ISSINGLECHOICE", "SUFFIXWHENCONTENT=. "]
function q({ titel = "", antworten = [], multi = false, optionen = [] }) {
  const optStr = optionen.length ? Y + optionen.join(OPT) + Y : "";
  const alle = titel ? [titel, ...antworten] : antworten;
  return D + optStr + (multi ? MULTI : "") + alle.join(DIVIDER) + D;
}

// Antwort mit abweichendem Dialog-Label
// einfuegetext = was im Karteieintrag landet (vorn)
// label        = was im Dialog als Auswahlzeile steht (hinten)
const kurz = (einfuegetext, label) => `${einfuegetext}<zsUserText>${label}`;

// Abschnittsüberschrift — nur Stufe 1, erscheint wörtlich im Befund
const section = (name) => `== ${name} ==`;

// Fügeoperator je Stufe
const join = (stufe, teile) => teile.join(stufe === 0 ? " " : "\n");
```

---

## Kritische Fehler

| Fehler | Symptom | Lösung |
|--------|---------|--------|
| `ˆ` vergessen | Frage bleibt Einzelauswahl, Mehrfachantworten unmöglich | `ˆ` vor den Fragetitel |
| `ˆ` als ASCII-`^` getippt | Marker greift nicht | Zeichen aus dem Konfigurator kopieren |
| Optionen mit `¥A¥¥B¥` gereiht | Konfigurationstext erscheint wörtlich als Button | mit `<zsMacroOption>` verketten: `¥A<zsMacroOption>B¥` |
| Trenner angehakt, Wert leer gelassen | Antworten kleben aneinander (`DREIVIER`) | Wert samt Leerzeichen eintragen oder Option weglassen |
| Prefix/Suffix ohne Leerzeichen | `Es bestehtZWEI` | Leerzeichen gehört in den Wert |
| Kein Fragetitel als erste Option | Button zeigt die erste Antwort statt des Titels | Titel immer als allererstes Element |
| Statischer Rahmentext um leerbare Mehrfachauswahl | Satzfragment ohne Inhalt | `PREFIXWHENCONTENT`/`SUFFIXWHENCONTENT` |
| Markdown (`**fett**`) im Baustein | Sternchen stehen wörtlich im Karteieintrag | Markdown gehört in keine Stufe |
| Emoji oder `→` als Bedeutungsträger | Zeichen verschwindet bei Export/Reimport | ASCII-Redundanz im Text |
| Formatierungsgrad nicht erfragt | Neubau für den echten Einsatzzweck nötig | Gate 0 |
| Optionsrunde übersprungen | Sonderfälle bleiben unentdeckt | Gate 1 |
| `<zsUserText>`-Seiten vertauscht | langer Text landet im Befund statt im Dialog | vorn der Einfügetext, hinten das Dialog-Label |
| Zwei fremde Fragen mit gleichem Text, beide `REUSEANSWER` | Auswahl koppelt ungewollt, zweite Frage wird übersprungen | Fragetexte unterscheiden |
| Formatierung im Baustein, Zieltyp mit eigener Formatierung | Bausteinformatierung wird überschrieben | Stufe 0 oder 1 wählen |
| `karteiEintragWert` mit falschem Eintragstyp | Kommando liefert leer | Typ des Zieleintrags einsetzen |

**Zurückgezogen:** Das frühere Verbot, `ISSINGLECHOICE` mit
`UNANSWEREDQUESTIONTEXT` zu kombinieren, ist widerlegt. Korrekt verkettet
(`¥A<zsMacroOption>B¥`) arbeiten beide Optionen zusammen; im Ergebnis stand die
gewählte Antwort, kein Konfigurationstext. Das alte Verbot beruhte auf falscher
Optionsverkettung (`¥A¥¥B¥`). [belegt, Sonde C/C3]

---

## Checkliste vor Abgabe

1. Gate 0 erfragt, Stufe im Bausteinkopf vermerkt
2. Gate 1 vorbereitet: nummerierte Frageliste liegt bei
3. Auswahlart je Frage bewusst gesetzt (`ˆ` oder nicht)
4. Jeder Block trägt den Fragetitel als erstes Element
5. Mehrere Optionen mit `<zsMacroOption>` verkettet, nicht mit doppeltem `¥`
6. Kein Trenner-Keyword mit leerem Wert
7. Prefix/Suffix-Werte enthalten die nötigen Leerzeichen
8. Stufe 0: keine Zeilenumbrüche, keine `==`-Zeilen, keine leerbare Mehrfachauswahl mitten im Satz
9. Zeichenvorrat cp1252-sicher, kein Markdown
10. Stufe 2 nicht ausgeliefert — Stufe 1 plus Formatierungsplan
11. Bei `<zsUserText>`: Einfügetext vorn, Dialog-Label hinten
12. Bei `REUSEANSWER`: beide Fragen markiert, Fragetexte nicht zufällig gleich

---

## Sondenprotokoll — abgeschlossen (Sonde C, 15.09.2026)

Sonden A, B und C sind ausgewertet. S-1 bis S-10 sind geschlossen.

| # | Ergebnis |
|---|---|
| S-1 | `UNANSWEREDQUESTIONTEXT` wirkt — leere Mehrfachauswahl gibt den Text aus |
| S-2 | `<zsUserText>`: **vorn Einfügetext, hinten Dialog-Label** — invers zur alten Doku |
| S-3 | `ISSINGLECHOICE` + `UNANSWEREDQUESTIONTEXT` vertragen sich, Verbot gestrichen |
| S-4 | `_%d_` öffnet einen Datumsdialog mit vorbelegtem Tagesdatum |
| S-5 | Keyword `REUSEANSWER`; Kopplung bidirektional, Partnerfrage wird übersprungen |
| S-6 | Trennermapping bestätigt: `FIRSTDIVIDER` / `DIVIDER` / `LASTDIVIDER` wie dokumentiert |
| S-7 | `karteiEintragWert … text` liefert reinen Text ohne Tags; Eintragstyp muss passen |
| S-8 | fett überlebt nur an Antwortoptionen; statischer Text geht flach durch |
| S-9 | `TRIMANSWER` und `SKIPDIALOGIFEXACTLYONEANSWER` ohne erkennbare Wirkung |
| S-10 | Zeilenumbruch als Trennerwert zulässig, steht roh im Baustein |

### Rest-Offenes

| # | Frage | Vorgehen |
|---|---|---|
| R-1 | Bleibt Fettschrift erhalten, wenn die **komplette Zeile ab Spalte 0** gefettet ist? | eine Zeile ohne führenden Text, ganz fett |
| R-2 | Braucht `TRIMANSWER` einen Wert (`TRIMANSWER=…`)? | Minimalbaustein mit Wertvariante |
| R-3 | `NOENTRYPLACEHOLDER=` — bislang ungetestet | nur im Karteieintrags-Auswahlblock sinnvoll |

Keiner der drei Punkte blockiert den produktiven Bau.

---

## Tomedo-Einstellungen (Textbaustein anlegen)

1. tomedo → Einstellungen → Textbausteine → `+`
2. **Kürzel**: z. B. `+pbef` (Präfix `+` empfohlen)
3. **Karteieintragstyp**: z. B. `BEF` für Befund
4. **Modus**: Programmiermodus aktivieren
5. Syntax einfügen, speichern
6. Im Karteieintrag Kürzel eintippen → Dialog startet

**Konfigurator als Übersetzer:** Wer ein Keyword nicht kennt, setzt die Option im
Dialog, bestätigt mit OK und liest den Rohtext im Programmiermodus ab. Das ist
der schnellste Weg zu belegter Syntax — und die Methode, mit der dieser
Optionskatalog entstanden ist.

---

## Referenz: Psychischer Befund (Vorlage)

Vollständiger psychischer Befund mit 9 Gruppen und ~25 Fragen als
Beispiel-Implementierung (Stufe 1):
- Datei: `Psychischer_Befund_Kombiniert.docx`
- Gruppen: Erscheinungsbild, Kognition, Denken, Ich-Erleben, Affektivität,
  Antrieb, Persönlichkeit, Suizidalität, Introspektionsfähigkeit & Abwehr

---

## Textbausteine als KI-Prompts — abweichende Regeln

**Formatierungsgrad: immer Stufe 0.**

Textbausteine lassen sich als vorkonfigurierte Prompts im KarteiChat, im
Support-Chat und in der Aktionsketten-Aktion `KI-Prompt` verwenden. Dabei
gelten andere Regeln als im Karteieintrag. [Hersteller, 11.09.2026]

> ⚠️ **Nur reine Textbausteine.** Makros zur Auswahl von Karteieinträgen,
> Diagnosen oder Medikamenten sowie **Frage-Antwort-Makros werden nicht
> ausgeführt** — sie werden als reiner Text an den Chatbot weitergereicht.
> [Hersteller, 11.09.2026]
>
> **Ein Baustein mit `∆`-Blöcken ist als Chat-Prompt unbrauchbar.** Wer beides
> braucht, pflegt zwei Fassungen.

**Platzhalter statt Dialog:** `___` (drei Unterstriche) ist der einzige
Interaktionsmechanismus, der im Chat trägt. [Hersteller, 11.09.2026]

**Markdown hat zwei Adressaten:** Im Chat-Fenster wird `**` als Fettschrift
gerendert, im Karteieintrag nach Copy-Paste nicht. Für maschinelle
Weiterverarbeitung XML-Tags (`<diagnosen>…</diagnosen>`) vorziehen.

### Freigabe und Pflegeort

| Weg | Vorgehen |
|---|---|
| Textbaustein-Makroverwaltung | Reiter **Sichtbarkeit**, Freigabe getrennt für Kartei-Chat und Support-Chat |
| Promptverwaltung | Verwaltung › Sprechstunden-Assistent › KI-Assistenten-Verwaltung — zusätzlich Schnell-Button und Buttonfarbe |

Die Freigabe wirkt **nutzerübergreifend**. Für Aktionsketten ist eine **eigene
Freigabe** nötig. [Hersteller, 11.09.2026]

> ⚠️ **Löschen wirkt durch.** Ein in der Promptverwaltung gelöschter Eintrag
> löscht den **Textbaustein**. [Hersteller, 11.09.2026]

Zum Prompt-Inhalt → Skill `karteichat-prompting`; zur Einbindung in Ketten →
`tomedo-aktionsketten/references/ki-prompt-aktion.md`.
