---
name: tomedo-textbausteine
description: >-
  Erstellt tomedo-Textbausteine mit interaktiven Frage-Antwort-Dialogen in korrekter tomedo-
  Syntax, für beliebige Fachbereiche. Verwende diesen Skill immer wenn Textbausteine für tomedo
  erstellt oder bearbeitet werden sollen. Enthält den Optionskatalog (Mehrfachauswahl per
  Zirkumflex, Autosprung, ISSINGLECHOICE, DIVIDER, FIRSTDIVIDER, LASTDIVIDER, PREFIXWHENCONTENT,
  SUFFIXWHENCONTENT, UNANSWEREDQUESTIONTEXT, REUSEANSWER, Kurztext, Aktionskette je Antwort),
  Platzhalter wie |P_NN| und |Datum|, verschachtelte Bausteine per $[Kürzel]$, die
  Eintragsauswahl |{Eintragtyp:…}| sowie ein Gate zum Formatierungsgrad. Auch verwenden bei:
  Fließtext statt Gliederung, Trennzeichen zwischen Antworten, Text bei leerer Auswahl,
  Aktionskette aus einer Antwort, Dialog schließt von selbst, fett oder Markdown im Baustein,
  Makroverwaltung, Kürzel wird nicht eingesetzt. Auch wenn ein Textbaustein als Prompt für
  KarteiChat, Support-Chat oder die Aktion KI-Prompt dienen soll — dort gelten eigene Regeln.
metadata:
  version: 1.1
---

# tomedo Textbausteine — Syntax & Stil

## Was sind tomedo Textbausteine?

Textbausteine in tomedo sind Kürzel-basierte Makros. Beim Eintippen des Kürzels schlägt
tomedo den Baustein vor; nach dem Einsetzen werden Platzhalter ersetzt und, falls der Text
Frage-Blöcke enthält, ein interaktiver Frage-Antwort-Dialog gestartet. Das Ergebnis ist ein
strukturierter Text im Karteieintrag (oder in einem anderen Textfeld).

## Geltungsregel für diesen Skill

**Die tomedo-Onlinehilfe sticht.** Bei Widerspruch zwischen diesem Skill und dem
Herstellerhandbuch gilt das Handbuch; der Skill wird korrigiert, nicht verteidigt.
Eigene Messungen gelten nur dort, wo das Handbuch schweigt — und werden als
Messung gekennzeichnet.

Statuskennzeichnung im ganzen Skill: **belegt** (Handbuch oder eigene Sonde),
**plausibel** (Indiz, nicht gemessen), **zu evaluieren** (offen).

Seit Fassung 1.1 ist der Skill zusätzlich überarbeitet (Stand Oktober 2026).
**[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz prüfen.
Widerspricht eine solche Angabe einer Herstelleraussage, stehen beide Angaben im Text, bis
eine Prüfung in der Oberfläche entscheidet.

Leitquelle: Onlinehilfe › Automatisierung › Textbausteine › „Expertenfeature:
Konfiguration von Frage-Antwort-Dialogen". Vertiefung in diesem Skill:
- `references/dialog-und-verwaltung.md` — Verhalten des Frage-Antwort-Dialogs, Tastatur,
  Makroverwaltung, Sichtbarkeit, Kopieren und Löschen
- `references/platzhalter-und-eintragsauswahl.md` — Platzhalter `|…|`, Briefkommandos und
  verschachtelte Textbausteine `$[Kürzel]$`, Eintragsauswahl `|{…}|` mit allen Optionen

---

## Gate 0 — Formatierungsgrad (Pflicht vor dem Bau)

**Vor jedem Neubau und vor jeder Umarbeitung wird der Formatierungsgrad aktiv
erfragt.** Nicht raten, nicht stillschweigend Stufe 1 annehmen.

> Soll der Baustein **ohne**, mit **leicht** oder mit **starker** Formatierung
> gebaut werden?
> Wenn unklar: Wohin geht das Ergebnis — nur lesen am Bildschirm, oder wird der
> Text weiterverarbeitet (KI-Prompt, Briefkommando, Export, Arztbrief)?

| Ziel des erzeugten Textes | Empfehlung |
|---|---|
| Prompt für KarteiChat / Support-Chat / Aktionsketten-Aktion `KI-Prompt` | **Stufe 0** (verbindlich) |
| Wird per `karteiEintragWert … text` in Brief oder Arztbrief ausgelesen | **Stufe 0** |
| Geht in Export, Statistik oder maschinelle Auswertung | **Stufe 0** |
| Karteieintrag, der am Bildschirm gelesen wird | **Stufe 1** (Default) |
| Karteieintrag, der nur gelesen und nie weiterverarbeitet wird | Stufe 2 — **gesperrt**, siehe unten |

Die gewählte Stufe wird im Kopf des ausgelieferten Bausteins als Kommentarzeile
vermerkt (`Formatierungsgrad: Stufe 1`).

---

## Gate 1 — Optionsrunde nach dem Erstbau (Pflicht)

Der Bau läuft **zweiphasig**. Pro Frage einzeln nachzufragen ist bei 25 Fragen
unzumutbar; nach dem Erstbau einmal zu fragen ist zumutbar und fängt die
Sonderfälle ein.

**Phase 1 — Grundbaustein.** Alle Fragen im Regelfall (Einzelauswahl, erster
Eintrag als Normalwert), dazu eine **nummerierte Frageliste** als Tabelle neben
dem Baustein:

| Nr | Fragetitel | Auswahl | Normalwert | Optionen |
|---|---|---|---|---|
| F01 | Pünktlichkeit | einzeln | pünktlich erschienen | — |
| F02 | Kontakt | mehrfach | zugewandt | — |

„Normalwert“ heißt nur: **steht als erste Antwort oben**. tomedo wählt nichts vor;
der Nutzer muss jede Frage selbst beantworten. [ungeprüft]

**Phase 2 — Optionsrunde.** Eine Frage an den Nutzer:

> Sollen einzelne Fragen Sonderoptionen bekommen? Bitte Nummer und Wunsch
> nennen — z. B. „F02 mehrfach", „F09 Kette bei 'vorhanden'", „F04 Suffix".

Antwort → nur die benannten Blöcke werden gepatcht, alles andere bleibt
unberührt.

**Die Nummern stehen ausschließlich in der Tabelle, nie im Bausteintext** —
sonst landen sie im Karteieintrag.

Aktiv anbieten statt abwarten: eine **Aktionskette je Antwort** bei
Alarmantworten (z. B. „Suizidalität vorhanden"), und **„Antwort wiederbenutzen"**
bei Bausteinen, in denen dieselbe Frage mehrfach vorkommt.

**Selbstschließen ansprechen:** Besteht der Baustein nur aus Einzelauswahl-Fragen,
schließt sich der Dialog nach der letzten Antwort von selbst und fügt den Text ein.
Wer vor dem Einfügen noch einmal prüfen will, braucht mindestens eine
Mehrfachauswahl-Frage (siehe „Auswahlart“). [ungeprüft]

---

## Die drei Formatierungsgrade

### Stufe 0 — ohne Formatierung (Fließtext / maschinenlesbar)

Ergebnis ist ein zusammenhängender Absatz, die Blöcke stehen **inline im Satz**.

**Erlaubt:** Fließtext, `∆`-Blöcke mitten im Satz, Einzelauswahl mit tragfähigem
Normalwert, Mehrfachauswahl mit den Standardtrennern, cp1252-sicherer Zeichenvorrat.

**Verboten:** `== Gruppe ==`, Zeilenumbrüche als Struktur, Aufzählungszeichen,
Markdown (`**`, `#`, `__` — wird im Karteieintrag **nicht** interpretiert und
bleibt wörtlich stehen), Emoji, `→`, Halbgeviertstrich (außerhalb cp1252;
stattdessen `=>` und `-`), jede Zeichenformatierung.

```
Der Patient ist ∆Pünktlichkeit<zsMacroAnswerDivider>pünktlich<zsMacroAnswerDivider>leicht verspätet<zsMacroAnswerDivider>deutlich verspätet∆ erschienen, wirkte im Kontakt ∆¥UNANSWEREDQUESTIONTEXT=zugewandt¥ˆKontakt<zsMacroAnswerDivider>zugewandt<zsMacroAnswerDivider>offen<zsMacroAnswerDivider>misstrauisch∆ und im Antrieb ∆Antrieb<zsMacroAnswerDivider>unauffällig<zsMacroAnswerDivider>vermindert<zsMacroAnswerDivider>gesteigert∆.
```

### Stufe 1 — leichte Formatierung (Struktur in reinem Text) — Default

Gliederung ausschließlich über Zeichen, die selbst Text sind.

**Zusätzlich erlaubt:** Abschnittsüberschriften `== Gruppenname ==`, eine Frage
pro Zeile, Leerzeile zwischen Gruppen, Label-Doppelpunkt-Muster, ASCII-Aufzählung
`- `, Trennzeile `---`.

**Weiterhin verboten:** Zeichenformatierung, Markdown-Inline, Emoji als
Bedeutungsträger.

### Stufe 2 — starke Formatierung — GESPERRT, und stark eingedampft

> ⛔ **Wird derzeit nicht ausgeliefert.** Bei Anfrage auf Stufe 1 ausweichen und
> das Sondenprotokoll anbieten.

Messstand (Sonden A und B, Referenzinstallation):

| Mittel | Ergebnis im Karteieintrag | Status |
|---|---|---|
| **fett** | kommt an — aber nur in bestimmten Positionen | belegt |
| unterstrichen | geht verloren, Text kommt flach an | belegt |
| Farbe | geht verloren | belegt |

**Von den drei geplanten Mitteln bleibt nur fett.** Damit ist Stufe 2 nicht mehr
„Rich Text", sondern „fett an wenigen Stellen".

Positionsmuster [Sonde C/C8–C10]:

- Fett an einer **Antwortoption innerhalb** des `∆`-Blocks → **kommt an**, reist
  mit der Antwort mit
- Fett auf **statischem Text** → **geht verloren**, gleich an welcher Stelle der
  Zeile. Sonde C hat Zeilenanfang und Zeilenmitte geprüft; beide kamen flach an.
- Offen bleibt allein der Fall „komplette Zeile ab Spalte 0 gefettet"

**Damit bleibt von Stufe 2 genau ein Mittel übrig: fett an Antwortoptionen.**
Statischer Text lässt sich gar nicht auszeichnen.

> Gegenbefund (Stand Oktober 2026): tomedo übernimmt die Formatierung des
> statischen Textes grundsätzlich mit. Der Messbefund bleibt gültig, bis eine Prüfung
> klärt, was die Fettschrift verliert (etwa die Schriftgrößenübernahme des Bausteins
> oder die Formatierung des Karteieintragstyps). [ungeprüft]

Trenner zwischen Antworten (`DIVIDER` usw.) werden immer **ohne** Formatierung
eingefügt; Prefix, Suffix und der Text für unbeantwortete Fragen behalten ihre
Formatierung. [ungeprüft]

Ebenfalls belegt: `∆`-Blöcke brechen durch Formatierung **nicht**. Die zunächst
geplante Regel „nie an oder in einem Block formatieren" entfällt ersatzlos.

Weiter gilt: jede Bedeutung, die an Auszeichnung hängt, bekommt eine
ASCII-Redundanz (`ACHTUNG:` im Text). Und Stufe 2 bleibt unzulässig, sobald der
Text irgendwo weiterverarbeitet wird.

**Nicht per Syntax steuerbar:** Zeichenformatierung erzeugt **keinen** Zuwachs im
Rohtext (Sonde B/Z11). Sie liegt in der RTF-Ebene. Folge: ein Stufe-2-Baustein
lässt sich **nicht** als Text ausliefern — er muss im Editor nachformatiert
werden. Der Skill liefert dafür Text plus Formatierungsplan.

**Der Karteieintragstyp sticht.** Bringt der Zieltyp eine eigene Formatierung mit
(etwa Anamnese-Zeilen durchgehend grün), überschreibt sie jede Formatierung des
Bausteins — auch nachträglich beim Umhängen eines bestehenden Eintrags auf einen
anderen Typ. Formatierung im Baustein ist damit nicht nur schwach, sondern
jederzeit durch eine Typänderung zerstörbar. [belegt, Referenzinstallation]

**Auslesen per Briefkommando:** `$[karteiEintragWert <Typ> text _ N]$` liefert
**reinen Text**; Fettschrift aus dem Eintrag kommt flach an, Tags stehen keine im
Ergebnis. Der Typ im Kommando muss dem Typ des Eintrags entsprechen — sonst
kommt leer zurück. [belegt, Sonde C/S-7]

---

## Sonderzeichen und Marker

| Zeichen | Mac | Windows | Bedeutung |
|---------|-----|---------|-----------|
| `∆` | ⌥+J | Alt+8710 | Öffnet/schließt einen Frage-Block (Zeichen „Increment“ U+2206, nicht das griechische Delta) |
| `¥` | ⌥+Y | Alt+0165 | Klammert den Optionsblock |
| `ˆ` | — | — | **Mehrfachauswahl**, steht direkt vor dem Fragetitel (Zeichen U+02C6) |
| `<zsMacroAnswerDivider>` | ausschreiben | ausschreiben | Trennt Antwortoptionen |
| `<zsMacroOption>` | ausschreiben | ausschreiben | Trennt **mehrere Optionen** innerhalb eines `¥…¥`-Blocks |
| `<zsUserText>` | ausschreiben | ausschreiben | Trennt **Einfügetext** (davor) von **Dialog-Label** (dahinter) |
| `___` | ausschreiben | ausschreiben | **Sprungmarke** im fertigen Text: nach dem Einfügen markiert, mit Tab zur nächsten. Im Dialog steht sie als letzte Antwortzeile jeder Frage automatisch bereit. Kein Eingabefeld im Dialog. [ungeprüft] |
| `_%d_` | Knopf „Datum" | — | Datums-Antwortoption |

`ˆ` ist ein Modifier-Zeichen, nicht der ASCII-Zirkumflex `^`. Beim Bau **aus dem
Konfigurator übernehmen oder kopieren**, nicht tippen.

Der alte Antworttrenner `;` (bis 2018) gilt nur noch, wenn im Block **kein**
`<zsMacroAnswerDivider>` steht. Sobald einer vorkommt, ist `;` ein normales Zeichen.
[ungeprüft]

Platzhalter in senkrechten Strichen (`|P_NN|`, `|Datum|` …) und eingebettete
Briefkommandos stehen in `references/platzhalter-und-eintragsauswahl.md`.

---

## Grundstruktur eines Frage-Blocks

```
∆¥OPTION1<zsMacroOption>OPTION2¥ˆFragetitel<zsMacroAnswerDivider>Antwort1<zsMacroAnswerDivider>Antwort2∆
```

Bestandteile in dieser Reihenfolge:

1. `∆` öffnet
2. optional `¥…¥` mit einer oder mehreren Optionen, verkettet mit `<zsMacroOption>` —
   **direkt** hinter `∆`, sonst wird der Block nicht als Optionsblock erkannt
3. optional `ˆ` → Mehrfachauswahl
4. **Fragetitel** (erscheint als Überschrift im Dialog und in der Fragenliste)
5. `<zsMacroAnswerDivider>` + Antwortoptionen
6. `∆` schließt

Ohne Optionsblock entfällt `¥…¥` ersatzlos: `∆ˆTitel<zsMacroAnswerDivider>A∆`.

Optionsnamen sind unabhängig von Groß- und Kleinschreibung, werden aber **nicht
getrimmt**: kein Leerzeichen vor oder hinter einem Optionsnamen oder um
`<zsMacroOption>`. [ungeprüft]

Jede Frage bekommt im Dialog automatisch zwei Zusatzzeilen: **„(Eigene Antwort)“**
(Freitext) und **`___`** (Sprungmarke). Sie werden nicht in den Baustein geschrieben.
[ungeprüft]

---

## Auswahlart: die wichtigste Unterscheidung

| | Einzelauswahl | Mehrfachauswahl |
|---|---|---|
| Marker | kein `ˆ` | `ˆ` vor dem Fragetitel |
| Nach dem Anhaken | **Sprung zur nächsten unbeantworteten Frage**; war es die letzte, schließt der Dialog von selbst (wie „OK“) [ungeprüft] | kein Sprung; weiter mit ⌘↓, Pfeilknopf oder Klick in die Fragenliste; Abschluss mit **„OK“** |
| Ergebnis | in der Regel eine Antwort | alle gewählten, verkettet |

**Jede Frage ohne `ˆ` springt nach der Auswahl weiter, dafür ist keine Option
nötig.** [ungeprüft] Das Handbuch beschreibt den Autosprung bei `ISSINGLECHOICE`;
nach aktuellem Stand bewirkt die Option nur eines: Sie **hebt ein `ˆ` auf** und macht
die Frage damit zur Einzelauswahl. Ohne `ˆ` hat sie keine Wirkung. Praktisch gebraucht
wird sie in der Eintragsauswahl (`|{…:mc…}|`), die tomedo immer als Mehrfachauswahl
erzeugt. [ungeprüft]

**Einzelauswahl ist nicht exklusiv.** Kehrt der Nutzer zu einer beantworteten Frage
zurück und klickt eine andere Antwort an, sind danach **beide** gewählt und stehen
verkettet im Text. Zum Korrigieren erst die alte Antwort abhaken, dann die neue wählen.
[ungeprüft]

Einen Knopf „Weiter“ gibt es nicht. Der Dialog hat „OK“, „Abbrechen (ESC)“ und —
nur in Folgedialogen — „Zurück“. Einzelheiten und Tastatur:
`references/dialog-und-verwaltung.md`. [ungeprüft]

---

## Optionskatalog

Alle Werte stehen hinter `=` und werden mit `<zsMacroOption>` aneinandergereiht.

| Option | Wirkung | Status |
|---|---|---|
| `ISSINGLECHOICE` | hebt `ˆ` auf → Einzelauswahl mit Autosprung; ohne `ˆ` wirkungslos | Handbuch: Autosprung; nach aktuellem Stand: nur zusammen mit `ˆ` [ungeprüft] |
| `DIVIDER=` | Trenner zwischen den mittleren Antworten (Standard `, `) | belegt |
| `FIRSTDIVIDER=` | Trenner zwischen 1. und 2. Antwort — **nur wenn gesetzt**; bei genau zwei Antworten ersetzt er den LASTDIVIDER | belegt (Sonde C/S-6); Zwei-Antworten-Fall [ungeprüft] |
| `LASTDIVIDER=` | Trenner vor der letzten Antwort (Standard ` und `) | belegt |
| `PREFIXWHENCONTENT=` | Text davor, **nur** wenn mindestens eine Antwort gewählt | belegt |
| `SUFFIXWHENCONTENT=` | Text danach, **nur** wenn mindestens eine Antwort gewählt | belegt |
| `UNANSWEREDQUESTIONTEXT=` | Text, wenn **keine** Antwort gewählt; Prefix und Suffix entfallen dann | belegt (Sonde C/C1); Prefix-Fall [ungeprüft] |
| `ACTION_ANSWER<n>=<Kürzel>` | startet die Aktionskette, wenn die n-te Antwort beim Abschluss gewählt ist | belegt (Kettenstart gemessen); Zeitpunkt siehe unten |
| `REUSEANSWER` | koppelt gleichlautende Fragen: gemeinsame Auswahl, Partnerfrage wird im Durchlauf übersprungen | belegt (Sonde C/C11–C13) |
| `TRIMANSWER` | beschneidet Leerraum — wirkt **nur in der Eintragsauswahl**, in `∆`-Blöcken wirkungslos | gemessen wirkungslos in `∆` (Sonde C/C6); Eintragsauswahl [ungeprüft] |
| `NOENTRYPLACEHOLDER=` | Ersatztext, wenn eine Eintragsauswahl nichts findet; Standard „(keine Einträge)“ | [ungeprüft] |
| `QUESTIONNAME=` | Dialogtitel einer Eintragsauswahl mit Dialog; Standard „generische Auswahl“; in `∆`-Blöcken ist der Titel das erste Element | [ungeprüft] |
| `SKIPDIALOGIFEXACTLYONEANSWER` | überspringt den Dialog, wenn eine Eintragsauswahl genau einen Treffer hat — in `∆`-Blöcken wirkungslos | gemessen wirkungslos in `∆` (Sonde C/C7); Eintragsauswahl [ungeprüft] |

Nur für die **Eintragsauswahl** über Karteieinträge, Medien oder Medikamente
(`|{Eintragtyp:…}|`, `|{Mediatyp:…}|`, `|{Medik:…}|`, anderer Mechanismus):
`MAXDATE=`, `MINDATE=`, `REVERSEDATEORDER`, `GROUPBYTYPE`, `TYPASPREFIX`,
`TYPNAMEASPREFIX`, `DATEPREFIX`, `WITHICD`, `REMOVEALLNEWLINES`, `TRIMANSWER`,
`NOENTRYPLACEHOLDER=`, `QUESTIONNAME=`, `SKIPDIALOGIFEXACTLYONEANSWER` sowie die
Medikamenten-Optionen `MED_DATEPREFIX`, `MED_DOSIERUNG`, `MED_ATC`, `MED_PZN`,
`MED_NODUPLICATES`, `MED_EXCLUDEABGESETZT`. Einheiten bei MAXDATE/MINDATE: `D` für
Tage und `Q` für Quartale, gezählt ab heute bzw. ab dem aktuellen Quartal. Syntax,
Wirkung und Beispiele: `references/platzhalter-und-eintragsauswahl.md`.

### Trenner — gemessenes Verhalten

Standard ohne jede Option, vier Antworten gewählt:

```
ZWEI, DREI und VIER
```

Bei zwei gewählten Antworten steht nur der LASTDIVIDER dazwischen (`ZWEI und DREI`).
[ungeprüft]

**Die Aktivierungsfalle:** Solange das Häkchen aus ist, zeigt der Konfigurator
den Standardwert als Text an (`', '` bzw. `' und '`). Beim Anhaken wird daraus
ein **leeres Eingabefeld** — der Standard wird nicht übernommen. Wer anhakt und
nichts einträgt, setzt aktiv einen leeren Trenner: aus zwei gewählten Antworten
wurde so `DREIVIER`. [belegt, Sonde B]

Die drei Trenner-Häkchen („zwischen 1. und 2. Antwort“, „zwischen letzter und
vorletzter Antwort“, „zwischen anderen Antworten“) sind nur aktiv, wenn „mehrere
Antworten auswählbar“ angehakt ist. [ungeprüft]

**Regel:** Standardtrenner nicht anfassen. Sie erzeugen bereits eine korrekte
deutsche Aufzählung (`ZWEI, DREI und VIER`). Wer anhakt, trägt zwingend einen
Wert ein.

Die Anführungszeichen in der Standardanzeige markieren die Leerzeichen; die
gehören mit ins Feld.

| Feld | Standard | Regelwert |
|---|---|---|
| `FIRSTDIVIDER=` (1. zu 2. Antwort) | ungesetzt: wie `DIVIDER`, bei zwei Antworten wie `LASTDIVIDER` | nur setzen, wenn die erste Lücke anders aussehen soll |
| `DIVIDER=` (übrige Antworten) | `, ` | Komma + Leerzeichen |
| `LASTDIVIDER=` (vor der letzten) | ` und ` | Leerzeichen + und + Leerzeichen |

Sinnvolle Abweichungen:

| Situation | Werte |
|---|---|
| Antworttexte enthalten selbst Kommata („Kopf, Nacken") | `; ` statt `, ` |
| Antworten sind ganze Sätze | `. ` in allen drei Feldern, kein „und" |
| Aufzählung in einer Verneinung | ` sowie ` statt ` und ` |
| Alternativen statt Aufzählung | ` oder ` |

Abweichungen immer in **allen betroffenen Feldern gleichzeitig** setzen, sonst
entsteht eine Mischform (`A; B und C`).

### Prefix und Suffix — gemessenes Verhalten

Beide werden **ohne automatisches Leerzeichen** angesetzt:

```
PREFIXWHENCONTENT=Es besteht    →   Es bestehtZWEI
SUFFIXWHENCONTENT=.             →   EINS.
```

Nötige Leerzeichen gehören in den Wert. [belegt, Sonde B]

Ihr Nutzen laut Handbuch: bei mehreren Fragebausteinen hintereinander sorgen sie
für einheitliche Trennung, ohne dass leere Antworten überzählige Trennzeichen
hinterlassen — anders als Trennzeichen, die als statischer Text zwischen den
Fragen stehen.

**Praxisregel:** Sobald ein Rahmensatz ohne Auswahl sinnlos würde, gehört er in
`PREFIXWHENCONTENT`/`SUFFIXWHENCONTENT` statt in den statischen Text.

### Abweichender Kurztext

```
∆Titel<zsMacroAnswerDivider>EINFÜGETEXT<zsUserText>DIALOG-LABEL<zsMacroAnswerDivider>…∆
```

**Die Zuordnung ist umgekehrt zur naheliegenden Lesart.** Der Text **vor**
`<zsUserText>` landet im Karteieintrag; der Text **dahinter** erscheint als
Auswahlzeile im Dialog. [belegt, Sonde C/C2]

Nutzen: ausführliche, selbsterklärende Auswahlzeile bei knappem Ergebnistext —
etwa `o.B.<zsUserText>unauffälliger Befund, keine Auffälligkeiten`.

Im Dialog werden Zeilenumbrüche im Label zu Leerzeichen, lange Labels werden am
Zeilenende abgeschnitten. Im Konfigurator heißt das Feld „abweichender Kurztext in
der Antwortauswahl“. [ungeprüft]

### Aktionskette je Antwort

```
∆¥ACTION_ANSWER2=Kaudal¥Titel<zsMacroAnswerDivider>EINS<zsMacroAnswerDivider>ZWEI∆
```

`<n>` zählt die **Antworten**, der Fragetitel zählt nicht mit. Der Kettenstart
ist gemessen. Damit wird ein Dokumentationsbaustein zum Workflow-Auslöser —
etwa Alarmkette bei „Suizidalität vorhanden".

Zeitpunkt nach aktuellem Stand [ungeprüft]:
- Gesammelt wird beim **Abschluss** des Dialogs („OK“ oder das automatische Schließen
  nach der letzten Einzelauswahl), und nur für Antworten, die dann angehakt sind.
  Eine an- und wieder abgewählte Antwort startet nichts.
- **Abbrechen startet keine Kette.**
- Die Ketten laufen erst nach dem Schließen des Dialogs, mit dem gerade geöffneten
  Patienten. Ohne geöffneten Patienten (etwa im Brief) laufen sie nicht.
- Ein unbekanntes Kürzel meldet „Die Aktionskette mit dem Kürzel '…' existiert leider
  nicht. Das Makro ist falsch konfiguriert.“; der Text wird trotzdem eingefügt.

Vor dem Einsatz testen: Bestätigt man einen solchen Dialog ohne geöffneten Patienten,
starten Ketten aus Textbausteinen möglicherweise bis zum Neustart von tomedo nicht mehr.
[ungeprüft]

### Datums-Antwortoption

Der Knopf „Datum" im Frage-Editor fügt `_%d_` als Antwortoption ein. Die Antwortzeile
zeigt im Dialog ein **Datumsfeld** mit Kalender; das Tagesdatum ist vorbelegt, eine
Änderung hakt die Antwort an. Im Karteieintrag steht danach das formatierte Datum
(`15.09.2026`). [belegt, Sonde C/C4; Datumsfeld in der Zeile ungeprüft]

Kein stiller Einsetzer: wer nur ein automatisches Tagesdatum will, nimmt den
Platzhalter `|Datum|` oder das Briefkommando statt der Antwortoption.

### Antwort wiederbenutzen

Keyword: **`REUSEANSWER`**, als normale Option im `¥…¥`-Block. Im Konfigurator:
„Antwort wiederbenutzen (s. Tooltipp)“.

```
∆¥REUSEANSWER¥Titel<zsMacroAnswerDivider>EINS<zsMacroAnswerDivider>ZWEI∆
```

**Beide** Fragen tragen die Option (so verlangt es der Tooltip). Als identisch gelten
Fragen mit gleichem Fragetext, gleichen Antworttexten und gleichen Füllwörtern.

Gemessenes Verhalten [Sonde C/C11–C13]:

- Die Kopplung ist **bidirektional**. Eine Änderung an einer der beiden Fragen
  zieht die andere nach — es gibt keine Ursprungs- und keine Folgefrage.
- Der Dialog **überspringt** die Partnerfrage im Durchlauf: nach der ersten
  Frage geht es direkt zur übernächsten. Beide bleiben in der Fragenliste
  sichtbar und einzeln anklickbar.

Präzisierung (Stand Oktober 2026) [ungeprüft]:
- Übernommen wird von jeder Frage, die **selbst** die Option trägt. Trägt nur eine der
  beiden sie, wirkt die Kopplung nur in eine Richtung.
- Verglichen werden Fragetitel und die **Dialog-Labels** der Antworten, ohne Rücksicht
  auf Groß- und Kleinschreibung und Leerzeichen am Rand. „Füllwörter“ sind die Werte
  von FIRSTDIVIDER, DIVIDER und LASTDIVIDER.
- Die Kopplung wirkt innerhalb **eines** Dialogs. Über einen Folgedialog hinweg
  (verschachtelte Bausteine) greift sie vermutlich nicht.

Bei langen Befundbausteinen mit wiederkehrenden Fragen aktiv anbieten.

> ⚠️ **Kollisionsgefahr.** Zwei inhaltlich verschiedene Fragen mit zufällig
> gleichem Fragetext und gleichen Antworten koppeln ungewollt, sobald beide
> `REUSEANSWER` tragen. Abhilfe: Fragetexte unterscheiden oder Option weglassen.

---

## Abschnittsüberschriften — Korrektur

`== Gruppenname ==` wird **nicht** als Überschrift gerendert. Der Text steht
wörtlich im Karteieintrag. [belegt, Sonden A und B]

Es bleibt trotzdem als optische Konvention in Stufe 1 brauchbar — aber als das,
was es ist: sichtbarer Text. Wer keine Doppel-Gleichheitszeichen im Befund will,
nimmt eine Label-Zeile ohne `==`. In Stufe 0 entfällt das Konstrukt.

---

## Statischer Text zwischen Blöcken

Text außerhalb von `∆…∆` wird wörtlich übernommen. Vorsicht bei
Mehrfachauswahl-Blöcken, die leer bleiben können: statischer Rahmentext steht
dann sinnlos da. Dafür gibt es `PREFIXWHENCONTENT`/`SUFFIXWHENCONTENT`.

**Abbrechen löscht alles.** Bricht der Nutzer den Dialog ab, wird **gar nichts**
eingefügt, auch nicht der statische Text; das getippte Kürzel verschwindet. Wer einen
Teil behalten will, drückt „OK“ — offene Fragen werden dann leer (oder zum
`UNANSWEREDQUESTIONTEXT`). [ungeprüft]

---

## Platzhalter, Briefkommandos und verschachtelte Bausteine (Kurzfassung)

Vor dem Dialog ersetzt tomedo im ganzen Baustein [ungeprüft]:

| Syntax | Ergebnis |
|---|---|
| `\|P_NN\|`, `\|P_VN\|`, `\|P_TIT\|`, `\|P_Geb\|` | Nachname, Vorname, Titel, Geburtsdatum des Patienten |
| `\|A_NN\|`, `\|A_VN\|`, `\|A_TIT\|` | Name des Hausarztes |
| `\|Datum\|`, `\|Datum+7\|`, `\|Datum-1\|`, `\|Zeit\|` | heutiges Datum, ± Tage, Uhrzeit |
| `\|?G;männlich;unbestimmt;weiblich\|` | Text je Geschlecht |
| `$[Briefkommando]$` | wird als **reiner Text** aufgelöst, auch innerhalb von Fragen und Antworten |
| `$[Kürzel]$` | setzt einen **anderen Textbaustein** ein (bis 30 Ebenen tief) |
| `\|{Eintragtyp:…:…}\|` | Eintragsauswahl aus der Kartei, siehe Referenz |

Ein `$[Kürzel]$` in einer **Antwort** erzeugt einen **Folgedialog**: Die Fragen des
eingebetteten Bausteins erscheinen erst, wenn diese Antwort gewählt und „OK“ gedrückt
wurde. So lassen sich verzweigte Befunde ohne Textbausteinketten bauen. [ungeprüft]

Fallen und Details (Leerzeichen bei leeren Werten, Schreibweise `Datum`, Namenskonflikt
mit Briefkommandos, chat-freigegebene Bausteine): `references/platzhalter-und-eintragsauswahl.md`.

---

## Zeilenstruktur (Stufe 1)

- Jede Frage auf einer eigenen Zeile
- Leerzeile zwischen Gruppen
- Innerhalb einer Gruppe nur einfacher Zeilenumbruch

In **Stufe 0** entfallen alle Zeilenumbrüche.

---

## Entscheidungsbaum

```
Gate 0: Formatierungsgrad geklärt?  (Pflicht)
└── ja
    Mehrere Antworten gleichzeitig wählbar?
    ├── JA  → ˆ vor den Fragetitel (kein Autosprung, Abschluss mit OK)
    │         Soll bei leerer Auswahl Text erscheinen?
    │         ├── JA  → ¥UNANSWEREDQUESTIONTEXT=…¥
    │         └── NEIN → Rahmentext in PREFIX/SUFFIXWHENCONTENT verlagern
    └── NEIN → kein ˆ, erster Eintrag = Normalwert
              (springt nach der Auswahl automatisch weiter; keine Option nötig)
              Nur Einzelauswahl-Fragen im Baustein?
              ├── JA  → Dialog schließt nach der letzten Antwort selbst — gewollt?
              └── NEIN → ohne Besonderheit
Gate 1: Optionsrunde nach dem Erstbau  (Pflicht)
```

---

## Vollständiges Beispiel Stufe 1

```
== Erscheinungsbild ==
Pünktlichkeit: ∆Pünktlichkeit<zsMacroAnswerDivider>pünktlich erschienen<zsMacroAnswerDivider>leicht verspätet erschienen<zsMacroAnswerDivider>deutlich verspätet erschienen∆.
Kleidung: ∆Kleidung<zsMacroAnswerDivider>unauffällig<zsMacroAnswerDivider>dezent<zsMacroAnswerDivider>überwiegend dunkel<zsMacroAnswerDivider>bunt∆.
Kontakt: ∆¥UNANSWEREDQUESTIONTEXT=zugewandt¥ˆKontakt<zsMacroAnswerDivider>zugewandt<zsMacroAnswerDivider>offen<zsMacroAnswerDivider>bemüht<zsMacroAnswerDivider>misstrauisch<zsMacroAnswerDivider>verschlossen∆.

== Suizidalität ==
ACHTUNG - Suizidgedanken: ∆¥ACTION_ANSWER3=alarmkette¥Suizidgedanken<zsMacroAnswerDivider>glaubhaft verneint<zsMacroAnswerDivider>passiv geäußert<zsMacroAnswerDivider>aktiv geäußert∆.
```

Die letzte Zeile zeigt eine Kette, die genau bei der dritten Antwort anspringt. Mehrere
Optionen werden mit `<zsMacroOption>` verkettet, etwa
`¥UNANSWEREDQUESTIONTEXT=keine<zsMacroOption>ACTION_ANSWER3=alarmkette¥`.

Bis Fassung 1.0 standen hier `ISSINGLECHOICE`-Optionen an Fragen ohne `ˆ`. Sie waren
unschädlich, aber nach aktuellem Stand ohne Wirkung und sind deshalb entfernt.
[ungeprüft]

---

## JavaScript-Hilfsfunktion

```javascript
const DIVIDER = "<zsMacroAnswerDivider>";
const OPT     = "<zsMacroOption>";
const MULTI   = "ˆ";           // U+02C6, aus dem Konfigurator kopieren, nicht tippen
const Y = "¥";
const D = "∆";                 // U+2206

// titel     = Fragetitel (Überschrift im Dialog), steht als erstes Element im Block
// antworten = Auswahloptionen
// multi     = true  → ˆ (Mehrfachauswahl, kein Autosprung)
// optionen  = Array, z.B. ["UNANSWEREDQUESTIONTEXT=keine", "SUFFIXWHENCONTENT=. "]
//             keine Leerzeichen um die Optionsnamen
function q({ titel = "", antworten = [], multi = false, optionen = [] }) {
  const optStr = optionen.length ? Y + optionen.join(OPT) + Y : "";
  const alle = titel ? [titel, ...antworten] : antworten;
  return D + optStr + (multi ? MULTI : "") + alle.join(DIVIDER) + D;
}

// Antwort mit abweichendem Dialog-Label
// einfuegetext = was im Karteieintrag landet (vorn)
// label        = was im Dialog als Auswahlzeile steht (hinten)
const kurz = (einfuegetext, label) => `${einfuegetext}<zsUserText>${label}`;

// Abschnittsüberschrift — nur Stufe 1, erscheint wörtlich im Befund
const section = (name) => `== ${name} ==`;

// Fügeoperator je Stufe
const join = (stufe, teile) => teile.join(stufe === 0 ? " " : "\n");
```

---

## Kritische Fehler

| Fehler | Symptom | Lösung |
|--------|---------|--------|
| `ˆ` vergessen | Frage bleibt Einzelauswahl, springt nach der ersten Antwort weiter | `ˆ` vor den Fragetitel |
| `ˆ` als ASCII-`^` getippt | Marker greift nicht | Zeichen aus dem Konfigurator kopieren |
| Optionsblock nicht direkt hinter `∆` (etwa hinter `ˆ`) | Optionen wirken nicht, Text steht im Fragetitel | `∆¥…¥ˆTitel…` |
| Optionen mit `¥A¥¥B¥` gereiht | Konfigurationstext erscheint wörtlich im Fragetitel | mit `<zsMacroOption>` verketten: `¥A<zsMacroOption>B¥` |
| Leerzeichen um Optionsnamen | Option wirkt nicht [ungeprüft] | Optionen ohne Leerzeichen schreiben |
| Trenner angehakt, Wert leer gelassen | Antworten kleben aneinander (`DREIVIER`) | Wert samt Leerzeichen eintragen oder Option weglassen |
| Prefix/Suffix ohne Leerzeichen | `Es bestehtZWEI` | Leerzeichen gehört in den Wert |
| Kein Fragetitel als erste Option | Dialog zeigt die erste Antwort als Titel | Titel immer als allererstes Element |
| Statischer Rahmentext um leerbare Mehrfachauswahl | Satzfragment ohne Inhalt | `PREFIXWHENCONTENT`/`SUFFIXWHENCONTENT` |
| Nur Einzelauswahl-Fragen | Dialog schließt nach der letzten Antwort ohne Kontrollblick [ungeprüft] | mindestens eine Frage mit `ˆ`, wenn geprüft werden soll |
| Antwort nachträglich umgeklickt | zwei Antworten im Text [ungeprüft] | alte Antwort zuerst abhaken |
| Dialog abgebrochen | gar nichts eingefügt, Kürzel weg [ungeprüft] | „OK“ drücken, offene Fragen bleiben leer |
| `ISSINGLECHOICE` als Autosprung-Schalter benutzt | keine Wirkung ohne `ˆ` [ungeprüft] | weglassen; Autosprung hat jede Frage ohne `ˆ` |
| `TRIMANSWER` / `SKIPDIALOGIFEXACTLYONEANSWER` im `∆`-Block | keine Wirkung | nur in der Eintragsauswahl verwenden |
| Markdown (`**fett**`) im Baustein | Sternchen stehen wörtlich im Karteieintrag | Markdown gehört in keine Stufe |
| Emoji oder `→` als Bedeutungsträger | Zeichen verschwindet bei Export/Reimport | ASCII-Redundanz im Text |
| Formatierungsgrad nicht erfragt | Neubau für den echten Einsatzzweck nötig | Gate 0 |
| Optionsrunde übersprungen | Sonderfälle bleiben unentdeckt | Gate 1 |
| `<zsUserText>`-Seiten vertauscht | langer Text landet im Befund statt im Dialog | vorn der Einfügetext, hinten das Dialog-Label |
| Zwei fremde Fragen mit gleichem Text, beide `REUSEANSWER` | Auswahl koppelt ungewollt, zweite Frage wird übersprungen | Fragetexte unterscheiden |
| Formatierung im Baustein, Zieltyp mit eigener Formatierung | Bausteinformatierung wird überschrieben | Stufe 0 oder 1 wählen |
| `karteiEintragWert` mit falschem Eintragstyp | Kommando liefert leer | Typ des Zieleintrags einsetzen |
| Baustein mit Karteityp-Einschränkung | erscheint nur in Text-Einträgen dieser Typen, sonst nirgends [ungeprüft] | Einschränkung nur setzen, wenn gewollt |
| Baustein für einen Chat freigegeben | fehlt in der Kartei-Vervollständigung und als `$[Kürzel]$` [ungeprüft] | Karteifassung und Chatfassung getrennt pflegen |
| Kürzel doppelt vergeben | unbestimmt, welcher Baustein kommt [ungeprüft] | Kürzel eindeutig halten |

**Zurückgezogen:** Das frühere Verbot, `ISSINGLECHOICE` mit
`UNANSWEREDQUESTIONTEXT` zu kombinieren, ist widerlegt. Korrekt verkettet
(`¥A<zsMacroOption>B¥`) arbeiten beide Optionen zusammen; im Ergebnis stand die
gewählte Antwort, kein Konfigurationstext. Das alte Verbot beruhte auf falscher
Optionsverkettung (`¥A¥¥B¥`). [belegt, Sonde C/C3]

---

## Checkliste vor Abgabe

1. Gate 0 erfragt, Stufe im Bausteinkopf vermerkt
2. Gate 1 vorbereitet: nummerierte Frageliste liegt bei
3. Auswahlart je Frage bewusst gesetzt (`ˆ` oder nicht); Selbstschließen bei reiner
   Einzelauswahl bedacht
4. Jeder Block trägt den Fragetitel als erstes Element
5. Mehrere Optionen mit `<zsMacroOption>` verkettet, nicht mit doppeltem `¥`; Optionsblock
   direkt hinter `∆`, keine Leerzeichen um Optionsnamen
6. Kein Trenner-Keyword mit leerem Wert
7. Prefix/Suffix-Werte enthalten die nötigen Leerzeichen
8. Stufe 0: keine Zeilenumbrüche, keine `==`-Zeilen, keine leerbare Mehrfachauswahl mitten im Satz
9. Zeichenvorrat cp1252-sicher, kein Markdown
10. Stufe 2 nicht ausgeliefert — Stufe 1 plus Formatierungsplan
11. Bei `<zsUserText>`: Einfügetext vorn, Dialog-Label hinten
12. Bei `REUSEANSWER`: beide Fragen markiert, Fragetexte nicht zufällig gleich
13. Keine `ISSINGLECHOICE` ohne `ˆ`; Optionen der Eintragsauswahl nicht in `∆`-Blöcken

---

## Sondenprotokoll — abgeschlossen (Sonde C, 15.09.2026)

Sonden A, B und C sind ausgewertet. S-1 bis S-10 sind geschlossen.

| # | Ergebnis |
|---|---|
| S-1 | `UNANSWEREDQUESTIONTEXT` wirkt — leere Mehrfachauswahl gibt den Text aus |
| S-2 | `<zsUserText>`: **vorn Einfügetext, hinten Dialog-Label** — invers zur alten Doku |
| S-3 | `ISSINGLECHOICE` + `UNANSWEREDQUESTIONTEXT` vertragen sich, Verbot gestrichen |
| S-4 | `_%d_` öffnet einen Datumsdialog mit vorbelegtem Tagesdatum |
| S-5 | Keyword `REUSEANSWER`; Kopplung bidirektional, Partnerfrage wird übersprungen |
| S-6 | Trennermapping bestätigt: `FIRSTDIVIDER` / `DIVIDER` / `LASTDIVIDER` wie dokumentiert |
| S-7 | `karteiEintragWert … text` liefert reinen Text ohne Tags; Eintragstyp muss passen |
| S-8 | fett überlebt nur an Antwortoptionen; statischer Text geht flach durch |
| S-9 | `TRIMANSWER` und `SKIPDIALOGIFEXACTLYONEANSWER` ohne erkennbare Wirkung — nach aktuellem Stand, weil beide nur in der Eintragsauswahl wirken [ungeprüft] |
| S-10 | Zeilenumbruch als Trennerwert zulässig, steht roh im Baustein |

### Rest-Offenes

| # | Frage | Stand |
|---|---|---|
| R-1 | Bleibt Fettschrift erhalten, wenn die **komplette Zeile ab Spalte 0** gefettet ist? | offen; dazu Gegenbefund (siehe Stufe 2) |
| R-2 | Braucht `TRIMANSWER` einen Wert (`TRIMANSWER=…`)? | nach aktuellem Stand nein, reines Kennwort, wirkt nur in der Eintragsauswahl [ungeprüft] |
| R-3 | `NOENTRYPLACEHOLDER=` — bislang ungetestet | nach aktuellem Stand nur Eintragsauswahl, Standard „(keine Einträge)“ [ungeprüft] |

Keiner der drei Punkte blockiert den produktiven Bau.

---

## Textbaustein anlegen und aufrufen

1. **Verwaltung › Textbausteine/Makros** (gleicher Eintrag auch unter **Admin ›
   Textbausteine/Makros**) → Fenster „Textbausteine-Makroverwaltung“. Einen Eintrag
   unter „Einstellungen“ gibt es nicht. [ungeprüft]
2. **„+“** unter der Liste → der Cursor steht im Feld **„Buttontext“** (Pflicht,
   eindeutig; Beschriftung in der Textbaustein-Tabelle des Karteieintrags).
3. **„Kürzel“**: z. B. `pbef` — kein Leerzeichen, kein Komma. Ein Präfix ist nicht
   nötig; ein Präfix-Zeichen wie `+` gehört zum Kürzel und muss mitgetippt werden.
   Bleibt das Kürzel leer, setzt tomedo `_` plus Buttontext ohne Leerzeichen. Doppelte
   Kürzel werden **nicht** abgewiesen — eindeutig halten. [ungeprüft]
4. **„Langtext“** im Reiter **„Text“** (Rohtext) einfügen. Der Reiter **„Symbol“**
   zeigt dieselben Fragen grafisch, mit den Knöpfen „neue Frage“ und „neue
   Eintragsauswahl“. Einen „Programmiermodus“ gibt es unter diesem Namen nicht.
   [ungeprüft]
5. Optional Reiter **„Sichtbarkeit“**: Nutzer/Nutzergruppe/Betriebsstätte,
   „Karteieintragstypen (nur Typ Text)“, „Chats“. Eine Karteityp-Einschränkung lässt
   den Baustein **nur** in Text-Einträgen dieser Typen erscheinen. [ungeprüft]
6. Im Karteieintrag das Kürzel tippen → Vorschlagsliste → mit **Return/Enter** oder
   Mausklick einsetzen (Leertaste und Tab setzen nicht ein) → Platzhalter werden
   ersetzt, bei `∆`-Blöcken startet der Dialog. Ab wie vielen Buchstaben vorgeschlagen
   wird, steht in den Nutzereinstellungen („Sonstiges“, Standard 1). [ungeprüft]

Das Feld **„Kommando“** zeigt `$[Kürzel]$` mit Knopf „Kopieren“ — so wird der Baustein
in Briefvorlagen und anderen Bausteinen eingebunden. Kopieren, Export, Löschen und die
Textbaustein-Tabelle: `references/dialog-und-verwaltung.md`.

**Konfigurator als Übersetzer:** Wer ein Keyword nicht kennt, setzt die Option im
Frage-Editor des Reiters „Symbol“, bestätigt mit OK und liest den Rohtext im Reiter
„Text“ ab. Das ist der schnellste Weg zu belegter Syntax — und die Methode, mit der
dieser Optionskatalog entstanden ist. Achtung: Der Editor schreibt `ISSINGLECHOICE`
nie selbst; „mehrere Antworten auswählbar“ setzt oder entfernt nur das `ˆ`. [ungeprüft]

> **Textbausteinketten** (Knopf „Textbausteinkette starten…“, Startliste, Folgeliste)
> sind nach aktuellem Stand abgekündigt und standardmäßig ausgeblendet. Nicht neu
> einrichten; verzweigte Abläufe mit `$[Kürzel]$` in Antworten bauen (Folgedialog).
> [ungeprüft]

---

## Referenz: Psychischer Befund (Vorlage)

Vollständiger psychischer Befund mit 9 Gruppen und ~25 Fragen als
Beispiel-Implementierung (Stufe 1):
- Datei: `Psychischer_Befund_Kombiniert.docx`
- Gruppen: Erscheinungsbild, Kognition, Denken, Ich-Erleben, Affektivität,
  Antrieb, Persönlichkeit, Suizidalität, Introspektionsfähigkeit & Abwehr

---

## Textbausteine als KI-Prompts — abweichende Regeln

**Formatierungsgrad: immer Stufe 0.**

Textbausteine lassen sich als vorkonfigurierte Prompts im KarteiChat, im
Support-Chat und in der Aktionsketten-Aktion `KI-Prompt` verwenden. Dabei
gelten andere Regeln als im Karteieintrag. [Hersteller, 11.09.2026]

> ⚠️ **Herstellerhinweis:** Makros zur Auswahl von Karteieinträgen, Diagnosen oder
> Medikamenten sowie **Frage-Antwort-Makros werden nicht ausgeführt** — sie werden als
> reiner Text an den Chatbot weitergereicht. [Hersteller, 11.09.2026]
>
> **Stand Oktober 2026 — weicht je Weg ab** [ungeprüft]:
>
> | Weg | Frage-Antwort-Dialog `∆` | Platzhalter `\|…\|`, Eintragsauswahl | Briefkommandos `$[…]$` |
> |---|---|---|---|
> | Aktion `KI-Prompt` in der Aktionskette | nein, roh an die KI | nein, roh | **ja**, mit den Werten der laufenden Kette |
> | Schnell-Button im Chat, Baustein **mit** `∆` | **ja**, Dialog vor dem Senden | ja | ja |
> | Schnell-Button im Chat, Baustein **ohne** `∆` | – | nein, roh | ja (mit geöffnetem Patienten) |
> | Kürzel im Chat-Eingabefeld getippt | **ja** | ja | ja |
>
> Bis zur Prüfung gilt: **Für die Aktion `KI-Prompt` keine `∆`-Blöcke und keine
> `|…|`-Platzhalter.** Im Chat Frage-Antwort-Bausteine nur nach eigenem Test einsetzen.
> Wer beides braucht, pflegt zwei Fassungen.

**Platzhalter statt Dialog:** `___` (drei Unterstriche) lässt eine Stelle offen, die vor
dem Absenden ergänzt wird. [Hersteller, 11.09.2026] Nach aktuellem Stand springt das
Chat-Eingabefeld auch Text in **eckigen Klammern** an (`[Diagnose]`); enthält der Prompt
keinen solchen Platzhalter, wird er nach dem Klick auf den Schnell-Button **sofort
gesendet**. [ungeprüft]

**Markdown hat zwei Adressaten:** Im Chat-Fenster wird `**` als Fettschrift
gerendert, im Karteieintrag nach Copy-Paste nicht. Für maschinelle
Weiterverarbeitung XML-Tags (`<diagnosen>…</diagnosen>`) vorziehen.

### Freigabe und Pflegeort

| Weg | Vorgehen |
|---|---|
| Textbaustein-Makroverwaltung | Reiter **Sichtbarkeit**, Box „Chats“ › „Freigabe anpassen…“: „Kartei-Chat“, „Tom Edo (Support-Chat)“, „LLM Aktionsketteneintrag“ [ungeprüft] |
| Promptverwaltung | Verwaltung › Sprechstunden-Assistent › KI-Assistenten-Verwaltung [Hersteller]; Stand Oktober 2026: **Verwaltung › KI-Assistenten › KI-Assistenten-Verwaltung**, Seite „Prompt“ [ungeprüft]. Dort „Verfügbarkeit für“ („Kartei-Chat“, „KI-Soforthilfe“, „Aktionsketteneintrag KI-Prompt“), „Als Schnell-Button anzeigen“ und „Farbe“ |

Die Freigabe wirkt **nutzerübergreifend**. Für Aktionsketten ist eine **eigene
Freigabe** nötig. [Hersteller, 11.09.2026]

> ⚠️ **Chat-Freigabe macht den Baustein chat-exklusiv.** Sobald ein Chat angehakt ist,
> schlägt tomedo den Baustein in Kartei, Brief und anderen Textfeldern nicht mehr vor,
> und `$[Kürzel]$` findet ihn nicht mehr. Karteifassung und Chatfassung getrennt
> pflegen. [ungeprüft]

> ⚠️ **Löschen wirkt durch.** Ein in der Promptverwaltung gelöschter Eintrag
> löscht den **Textbaustein**. [Hersteller, 11.09.2026] Nach aktuellem Stand ohne
> Rückfrage, aber wiederherstellbar über „gelöschte anzeigen“ in der
> Textbausteinverwaltung. [ungeprüft]

Zum Prompt-Inhalt → Skill `tomedo-karteichat-prompting`; zur Einbindung in Ketten →
`tomedo-aktionsketten/references/ki-prompt-aktion.md`.
