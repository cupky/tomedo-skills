# Konfiguratoren & Steuerkommandos — Vollständige Syntax-Referenz

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Thema → Steuerkommando + Konfiguratoren),
Stand März 2026, überarbeitet im Oktober 2026. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt —
vor dem Einsatz an einer Testakte prüfen.

Steuerkommandos sind **kontextunabhängige** Kommandos (Kontext: "ohne"), die andere Kommandos manipulieren, vergleichen, formatieren oder bedingt ausführen. Sie bilden die "Programmiersprache" innerhalb des Kommandosystems.

---

## Übersicht: 16 Konfiguratoren

Admin › Kommandos › Bereich „Konfiguratoren“. Ein Konfigurator erscheint nur, wenn sein Kommando im
eigenen Produkt vorkommt. `if_then` hat keinen eigenen Konfigurator, steht hier aber als Kernbaustein.

| Konfigurator | Hauptzweck | Praxisrelevanz |
|---|---|---|
| **if** | Bedingte Auswertung mit Operatoren | ⭐⭐⭐ Kernbaustein |
| (if_then, ohne Konfigurator) | Bedingte Ausführung eines Folgekommandos | ⭐⭐⭐ |
| **d** | Datum-Kommando | ⭐⭐⭐ |
| **karteiEintragWert** | Werte aus Karteieinträgen | ⭐⭐⭐ |
| **formularEintrag** | Werte aus Patientenformularen | ⭐⭐⭐ |
| **KeyPath** | Direktzugriff auf Datenmodell | ⭐⭐⭐ |
| **x** | Komplexes Karteieintrags-Auslese-Kommando | ⭐⭐ |
| **regex** | Reguläre Ausdrücke auf Kommando-Ergebnisse | ⭐⭐ |
| **a** | Anrede-Platzhalter (geschlechtsabhängig) | ⭐⭐ |
| **lab** | Laborwerte (Kurzform) | ⭐⭐ |
| **labor** | Laborwerte (Langform/Tabelle) | ⭐⭐ |
| **Leistungen** | Leistungskommandos | ⭐⭐ |
| **medikamentenplan** | Medikamentendaten | ⭐ |
| **dmp** | DMP-Daten | ⭐ |
| **impfstatus** | Impfstatus-Tabelle | ⭐ |
| **kommandorahmen** | Text vor/nach einem Ergebnis, nur wenn nicht leer | ⭐⭐ |
| **Termine** | `patientenTermine`, `selektierterTermin`, `selektierteTermine` | ⭐⭐ |

Hinweis: Der Knopf zum regex-Konfigurator hängt am Kommando `lab`, nicht an `regex`
[ungeprüft]. Den Konfigurator deshalb über die Liste „Konfiguratoren“ öffnen.

---

## if — Bedingte Auswertung

### Kernkonzept
Führt ein Kommando aus, vergleicht das Ergebnis gegen beliebig viele Werte und gibt je nach Treffer einen alternativen Text aus.

### Syntax

```
$[if <auszuführendes Kommando> <arg1> <arg2> ... <argN> <Operator> <Vergleichswert1> <Alternativwert1> <Vergleichswert2> <Alternativwert2> ... <Rückfallwert>]$
```

Dabei sind `<arg1>` bis `<argN>` die Parameter des auszuführenden Kommandos, sofern vorhanden.

### Operatoren

| Operator | Beschreibung | Hinweis |
|---|---|---|
| `zs_equals` | Test auf Gleichheit | |
| `zs_not_equal` | Test auf Ungleichheit | |
| `zs_contains` | enthält | |
| `zs_not_contains` | enthält nicht | |
| `zs_less_than` | kleiner als | nur für Zahlen und Datum |
| `zs_greater_than` | größer als | nur für Zahlen und Datum |

Vergleichslogik [ungeprüft]:
- `zs_equals`, `zs_not_equal`: exakter Textvergleich, Groß-/Kleinschreibung zählt, keine Leerzeichen-Bereinigung.
- `zs_contains`, `zs_not_contains`: Teilstring, Groß-/Kleinschreibung zählt.
- `zs_less_than`, `zs_greater_than`: **strikt** kleiner/größer. Lässt sich der Vergleichswert als Datum
  (TT.MM.JJ oder TT.MM.JJJJ) lesen, wird tagesgenau verglichen, sonst als Zahl. Ein **leeres** Ergebnis
  zählt dabei als 0 — `$[if pt zs_less_than 5 …]$` trifft also auch bei fehlendem Wert. Der Konfigurator
  nennt die Auswahl „kleiner gleich/größer gleich“, erzeugt aber die strikten Operatoren.
- Ältere Schreibweisen `zs_less_then`/`zs_greater_then` werden noch angenommen.
- Ohne Operator gilt `zs_equals`; dann bekommt das auszuführende Kommando aber **keine** eigenen Argumente,
  weil alle folgenden Wörter als Wertepaare gelesen werden.
- Die Paare werden von vorn nach hinten geprüft, **der erste Treffer gewinnt**. Ohne Treffer und ohne
  Rückfallwert ist das Ergebnis leer.

### Sonderwert `<leer>`

Um gegen die **leere Zeichenkette** zu testen, wird `<leer>` als Vergleichswert verwendet. Optional kann als letztes Argument ein Rückfallwert angegeben werden, der ausgegeben werden soll, falls das auszuführende Kommando keinen der angegebenen Vergleichswerte geliefert hat. Soll dafür das Ergebnis des ursprünglichen Kommandos verwendet werden, so ist `XXX` als Rückfallwert anzugeben.

Nach aktuellem Stand [ungeprüft]:
- `XXX` wirkt **nur als ganzer Rückfallwert** (letzter Wert bei ungerader Zahl von Werten). Als Ausgabewert
  oder als Teil eines Textes (`'Label: XXX'`) bleibt `XXX` wörtlich stehen.
- `<leer>` wirkt nur als ganzes Wort und nicht innerhalb von Hochkommata.
- Zusätzlich gibt es **`<nichtleer>`**: trifft mit `zs_equals` (oder ohne Operator) jedes nicht leere Ergebnis.
  Mit `zs_not_equal` wirkt es nicht.

### Ersetzungsregeln in Vergleichs-/Ausgabewerten und Rückfallwert

Schreibweise im Kommando (die frühere Tabelle mit Punkt und Anführungszeichen war falsch):

| Gewünschtes Zeichen | So im Kommando schreiben |
|---|---|
| Leerzeichen | `_` |
| echter Unterstrich | `\u` |
| Zeilenumbruch | `\n` |
| Tabulator | `\t` |
| Backslash | `\\` |
| leere Zeichenkette | `<leer>` |

Diese Ersetzungen gelten nicht für alle Kommandos und Argumente gleich, sondern nur dort, wo das jeweilige
Kommando sie vorsieht: bei `if` für Vergleichs-, Ausgabe- und Rückfallwerte, bei `if_then` für den
Vergleichswert, bei `kommandorahmen` für Text davor/danach, bei `ersetze` für die Paare. **Nicht** ersetzt
werden z. B. der Ausdruck bei `regex`, Key und Typ bei `karteiEintragWert` und der Feldname bei
`formularEintrag` [ungeprüft]. Ein Feldname wie `aff_Skala` bleibt dort also unverändert; als
Vergleichswert im `if` würde `aff_Skala` dagegen zu „aff Skala“.

### Alternative Syntax (Abwärtskompatibilität)

```
$[if <auszuführendes Kommando> [ <arg 1> <arg 2> ... <arg n> ] <Vergleichswert 1> <Alternativwert 1> <Vergleichswert 2> <Alternativwert 2> ... <Rückfallwert>]$
```

Hier stehen **eckige** Klammern, jeweils durch Leerzeichen abgetrennt, und **kein Operator** —
verglichen wird immer auf Gleichheit (frühere Fassungen dieser Referenz zeigten geschweifte Klammern mit
Operator) [ungeprüft]. Fehlt die schließende Klammer, meldet tomedo „Syntaxfehler bei if-Kommando:
schließende eckige Klammer … wurde nicht gefunden“.

Alternativ können Vergleichswerte, alternative Ausgabewerte und der Rückfallwert auch durch **Hochkommata** (`'`) eingerahmt werden, ohne dass Ersetzungen gemacht werden müssen. In den Vergleich- und Alternativwerten können auch Platzhalter in der üblichen Syntax verwendet werden.

Nach aktuellem Stand [ungeprüft]: Hochkommata wertet nur `if` (und `tab_if`) aus, und nur für die Werte **nach**
dem Operator, nicht für die Argumente des auszuführenden Kommandos. Innerhalb der Hochkommata wird nur `\n`
ersetzt, `_` bleibt ein Unterstrich. Platzhalter in Ausgabewerten schreibt man am besten als `${…}$`: sie
werden dann erst ausgeführt, wenn ihr Paar zutrifft. Der if-Konfigurator wandelt `$[…]$` in Werten selbst
in `${…}$` um.

**Verschachtelte Platzhalter als auszuführendes Kommando vermeiden** [ungeprüft]: Ein inneres `$[…]$` wird
zuerst ausgeführt und sein Ergebnis kodiert eingesetzt — Leerzeichen als `_`, leeres Ergebnis als `<leer>`.
An der Kommando-Stelle des `if` wird das nicht zurückgewandelt. `$[if $[pt]$ zs_equals <leer> A B]$`
liefert bei leerem Titel deshalb vermutlich `B`, `$[if pt zs_equals <leer> A B]$` dagegen `A`. Das
Kommando also direkt angeben, ohne eigene Klammern.

Kann das angegebene auszuführende Kommando **nicht als Platzhalter aufgelöst** werden, so wird es selbst zum Vergleich verwendet. Dies ist beispielsweise sinnvoll, um mittels if-Kommando Karteieintragstexte oder Vorbefüllungen von CustomKarteieinträgen anzupassen.

### Beispiele

```
1) Das Kommando pt liefert den Titel des Patienten. Möchte man im Titel des Patienten 
   die üblicherweise abgekürzten Titel "Dr." und "Prof." durch die ausgeschriebenen 
   ersetzen, wobei alle anderen Titel belassen werden sollen, wählt man das Kommando:
   $[if pt Dr. Doktor Prof. Professor 'Prof. Dr.' 'Professor Doktor' XXX]$

   alternativ geht auch:
2) $[if pt Dr. Doktor Prof._Dr. Professor_Doktor XXX]$

3) $[if karteiEintragWert custom customKarteiEintragFeldwss variablenName %@ J zs_equals wert1 alternativwert1 alternativwert2]$

4) Als Vorbefüllung eines Custom-Karteieintrag-Feldes vom Typ "Text zusammengesetzt nicht editierbar" 
   mit Referenz auf ein Feld mit Variablenname "Feldname":
   $[if $[Feldname]$ zs_equals Wert1 Text_bei_Wert1 Text_sonst]$

5) Als Vorbefüllung eines Custom-Karteieintrag-Feldes vom Typ "Text zusammengesetzt nicht editierbar" 
   mit Referenz auf ein Feld mit Variablenname "Feldname" vom Typ Mehrfachauswahl:
   (Feldname liefert kommaseparierte Auswahl)
```

---

### Praxis-Lessons 06/2026: Leerfeld-Guard, Bezeichner-Quoting, Träger-Auflösung

> **⚠️ Punkt 1 dieses Abschnitts ist WIDERRUFEN** — siehe „Korrektur 06/2026: Leerfeld-Guard
> funktioniert NICHT" direkt unterhalb. Punkte 2 und 3 gelten unverändert. Wer nur diesen
> Abschnitt liest, wendet sonst eine im Realtest gescheiterte Regel an.

**1 · Leerfeld-Guard-Idiom (E3-Unterdrückung) — ⚠️ WIDERRUFEN, NICHT VERWENDEN.** Zeile nur ausgeben, wenn das Feld
nicht leer ist — Label INNERHALB des Guards, damit bei leerem Wert die ganze Zeile
verschwindet:
```
$[if <KMD> zs_not_equal <leer> 'Label: XXX' '']$
```
`XXX` = Ergebnis des inneren Kommandos (Rückfallwert). Leeres Feld → `''` → Leerzeile
(kosmetisch). Funktioniert mit `formularEintrag` und (nested) `x`.

**2 · Bezeichner mit Leerzeichen/Klammern → single-quote-wrappen.** ⚠️ Nach aktuellem Stand widersprüchlich
[ungeprüft]: Hochkommata wertet `if` nur in den Werten nach dem Operator aus; die Argumente von
`formularEintrag` gehen roh durch, und `formularEintrag` setzt einen Feldnamen mit einfachen Leerzeichen
selbst wieder zusammen. Danach würde `momentaner Status` **ohne** Hochkommata treffen und `'momentaner Status'`
leer bleiben. Bis zur Nachprüfung beide Formen mit [Testen] vergleichen. Bei `formularEintrag`
gilt exakter Feldnamen-Match (keine `_`→Leerzeichen-Umwandlung). Feldnamen MIT echtem
Leerzeichen/Klammer (`momentaner Status`, `Rentenart (zeitlich)`) müssen single-quote-
umschlossen werden: `'momentaner Status'`. Die Quotes halten das Leerzeichen zusammen
UND geben dem if-Parser eine saubere Token-Grenze (sonst zählt er die Parameter falsch).
Gegenprobe: reine Unterstrich-/Bindestrich-Bezeichner (`aff_Skala`, `personen-im-haushalt`)
NICHT quoten (Quotes gingen in die Feldsuche ein → leer).

**3 · Träger-Auflösung verifiziert (2026-06-19).** Briefkommandos lösen nicht nur in
Briefvorlagen auf, sondern auch **beim Einfügen eines Textbausteins in einen
Karteieintrag** und in der **Vorbefüllung eines Custom-Karteieintrags** — inkl.
komplexer `x`- und `if`-Kommandos. Ermöglicht Export per Textbaustein-Kürzel +
Copy-Paste ohne Brief-Dialog/Datei.

> Nesting-Hinweis: Mehr-Token-`x` im `if` ist die fragilste Stelle. Bei Bruch inneres
> Kommando im jeweiligen Konfigurator als gespeicherten Platzhalter ablegen und im
> if-Konfigurator wickeln; `[Testen]` vor Live.

### Korrektur 06/2026: Leerfeld-Guard funktioniert NICHT — „immer drucken"

**Widerruf der Guard-Empfehlung.** Das Idiom `$[if <feldcmd> zs_not_equal <leer> 'Label: XXX' '']$`
wertet im **Textbaustein-Träger / CKE-Vorbefüllung NICHT aus** — im Echtexport (4 Patienten,
06/2026) erschien das Platzhalter-Literal `XXX` wörtlich im Output (MPSS, SONO, BEF_PHY,
GdB, kompletter Sozialblock). Einfaches `formularEintrag`/`x` OHNE if liefert dagegen
zuverlässig (Beleg: Krankenhaus-Zeilen, `allergien K`, alle Skalarfelder).

→ **Regel:** Felder im Textbaustein-Export IMMER roh ausgeben („Maximalversion"). Leere
Felder hinterlassen eine wertlose „Label:"-Zeile — die wird im nachgelagerten
LLM-Schritt entfernt. Keine Leerfeld-Unterdrückung am Briefkommando.

**WICHTIGE Differenzierung — was funktioniert:**
- `if … zs_contains <muster> <wert> …` über `formularEintrag` läuft einwandfrei
  (Matrix-NAS-Mapping `ZeileN=SpalteM`, validiert).

**Ursache (Stand Oktober 2026) [ungeprüft]:** Der `<leer>`-Vergleich funktioniert. `'Label: XXX'`
steht im Idiom an der Stelle eines **Ausgabewerts**, nicht des Rückfallwerts; `XXX` wird aber nur ersetzt,
wenn der **ganze Rückfallwert** `XXX` ist. Bei gefülltem Feld erscheint deshalb wörtlich „Label: XXX“ — in
jedem Träger, nicht nur im Textbaustein. Zwei Formen, die das Gewünschte leisten:
```
$[kommandorahmen <KMD> <arg…> Label:_ <leer>]$
$[if <KMD> <arg…> zs_not_equal <leer> 'Label: ${<KMD> <arg…>}$' '']$
```
Bis zur Nachprüfung gilt die Regel „immer roh ausgeben“ weiter.

### Boolean → ja/nein per zs_contains (validiert 06/2026)
PatF-Boolean-Felder liefern roh `true`/`false`. Saubere Klartext-Ausgabe:
```
$[if formularEintrag <Formular> <bez> <sel> zs_contains true ja false nein]$
```
Im Textbaustein-Träger zuverlässig (4-Patienten-Test). Leeres Feld → leer. Betrifft u.a.
`schmerzereignis`, `regelmäs-med`, `Blutverdünner`, `allergien`, `rf`, alle
Komorbiditäts-Flags (`nerv`/`herz`/…), `kids`, `rente`, `gdb`, `schmerzabnahme`.
Zahlenfelder (z.B. `kidsn` = Anzahl Kinder) NICHT mappen.

## if_then — Bedingte Ausführung eines Folgekommandos

### Kernkonzept
Führt ein Kommando aus, vergleicht das Ergebnis mit einem Vergleichswert. Bei positivem Vergleich wird ein **anderes** Kommando ausgeführt. Die Syntax ist analog zum if-Kommando (ohne Hochkomma-Notation und ohne Platzhalter im Vergleichswert) mit dem Unterschied, dass nur ein Vergleichswert angegeben wird, gefolgt vom auszuführenden Kommando (und möglicherweise zusätzlichen Parametern dieses Kommandos).

### Syntax

```
$[if_then <Kommando 1> <argK1-1> <argK1-2> ... <Operator> <Vergleichswert> <Kommando 2> <argK2-1> <argK2-2> ...]$
```

Das Ergebnis des ersten Kommandos kann auch per `XXX` als Argument an das auszuführende Kommando übergeben werden. Dadurch erreicht man gewissermaßen eine Verschachtelung von Platzhaltern.

Nach aktuellem Stand [ungeprüft]: Der Vergleichswert bekommt die üblichen Ersetzungen (`<leer>`, `_` als
Leerzeichen; ein einzelnes `_` steht für leer). Die Argumente von Kommando 2 werden **unverändert**
übergeben; `XXX` muss dort ein eigenes Wort sein. Kein Treffer ergibt leer.

---

## regex — Reguläre Ausdrücke

### Kernkonzept
Extrahiert einen Teil des Ergebnisses eines Platzhalters mittels Regular Expression.

### Syntax

```
$[regex <RegularExpression> <Kommando> <arg1> <arg2> ...]$
```

- Erstes Argument: Regular Expression (ohne Leerzeichen)
- Danach: Kommando mit beliebig vielen Parametern
- Ausgabe: Inhalt der **ersten Gruppierung** (durch runde Klammern eingerahmter Bereich), falls eine Gruppierung angegeben wurde
- Ansonsten: erster Treffer des Ausdrucks insgesamt
- Kein Treffer: leeres Ergebnis der Länge Null

Nach aktuellem Stand [ungeprüft]: Der Ausdruck wird unverändert genommen (kein `_`→Leerzeichen; Leerzeichen per
`\s`). `^` und `$` gelten je Zeile. Ausgegeben wird die erste Gruppe, die tatsächlich etwas gefunden hat.
Optionen dürfen an beliebiger Stelle stehen. Groß-/Kleinschreibung zählt; `(?i)` am Anfang des Ausdrucks
sollte sie abschalten.

### Optionen

| Option | Beschreibung |
|---|---|
| `-anzahlTreffer <Anzahl>` | Um mehrere Treffer auszugeben, standardmäßig wird nur der erste ausgegeben. `'inf'` um alle Treffer auszugeben |
| `-trennsequenz <Trennsequenz>` | Um die Treffer getrennt durch `<Trennsequenz>` auszugeben, Standard ist `', '`. Wirkt nur zusammen mit `-anzahlTreffer` [ungeprüft] |
| `-nurAnzahl` | Um nur die Anzahl der Treffer auszugeben |

### Beispiele

```
1) Angenommen, im letzten Karteieintrag mit Kürzel 'test' wollen Sie das erste 
   Vorkommen von 'abc:' zusammen mit den 5 nachfolgenden Zeichen auslesen:
   $[regex abc:.{5} x test]$

2) Wie Beispiel 1), nur dass Sie 'abc:' nicht mit ausgeben möchten, sondern nur 
   die 5 Zeichen danach:
   $[regex abc:(.{5}) x test]$

3) Angenommen, Sie wollen aus dem letzten Karteieintrag mit Kürzel 'test' ein Datum 
   auslesen, das dort im Format dd.MM.yyyy steht, wollen aber die Jahr-Komponente 
   weglassen. Das geht mit:
   $[regex ([0-9]{2}.[0-9]{2}).[0-9]{4} x test]$
```

---

## score — Berechnungen

### Kernkonzept
Führt mathematische Berechnungen aus: Addition, Multiplikation, Subtraktion, Division, Maximum, Minimum, u.a.

### Syntax

```
$[score <Rechenausdruck>]$
```

Nach aktuellem Stand [ungeprüft]: Der Ausdruck darf Leerzeichen und Platzhalter (`$[…]$`, `${…}$`) enthalten
und wird wie ein Score-Feld eines Custom-Karteieintrags ausgewertet: `+ - * /`, Klammern, Funktionen wie
`max({a,b})`, `min({…})`, `sum({…})`, `average({…})`, `abs()`, `sqrt()`. Das Ergebnis wird nicht gerundet.
Ganze Zahlen werden vermutlich ganzzahlig geteilt (`7/2` → 3, `7.0/2` → 3.5). Ein Dezimalkomma in einem
eingesetzten Wert zerstört den Ausdruck — bei `karteiEintragWert` die Option `-fuerScores` verwenden.

---

## bereich — Teilstring-Extraktion

### Kernkonzept
Gibt das Ergebnis eines Kommandos in einem definierten Bereich bezüglich der Zeichenanzahl aus.

### Syntax

```
$[bereich <Index>,<Länge> <Kommando>]$
```

### Beispiele

```
Angenommen, das Kommando test gibt "abcdef" aus. Dann liefern:
$[bereich 0,2 test]$  → ab
$[bereich 1,4 test]$  → bcde
```

Der Index zählt ab 0. Ist die Länge zu groß, wird gekappt (`3,10` → def) [ungeprüft].

---

## ersetze — Text-Ersetzungen

### Kernkonzept
Text-Ersetzungen im Ergebnis eines Platzhalters.

### Syntax

```
$[ersetze a1 b1 a2 b2 ... an bn zs_in <Platzhalter>]$
```

Dabei wird der angegebene Platzhalter ausgeführt und im Ergebnis werden die Ersetzungen a1→b1, a2→b2, ..., an→bn vorgenommen.

**Achtung!** Bei den einzelnen Ersetzungs-Parametern müssen bestimmte Zeichen anders kodiert werden (siehe Hilfe-Button).

### Beispiel

```
$[ersetze ,_ \n zs_in x abc]$
```
→ ersetzt „, “ (Komma und Leerzeichen) durch einen Zeilenumbruch. Ein Paar besteht immer aus **zwei** Wörtern;
die frühere Fassung `$[ersetze _\n_ zs_in x abc]$` ist nur ein Wort und führt zur Meldung „ungerade Anzahl
an Ersetzungs-Einträgen“. Die Paare werden nacheinander angewandt, Groß-/Kleinschreibung zählt;
`<leer>` als Ersatz löscht [ungeprüft].

---

## kommandorahmen — Bedingter Textrahmen

### Kernkonzept
Wenn ein Kommando ein nicht-leeres Ergebnis liefert, wird es mit Präfix- und Suffix-Text umrahmt. Wenn das Ergebnis leer ist, wird nichts ausgegeben.

### Syntax

```
$[kommandorahmen <Kommando> <arg1> ... <Präfix-Text> <Suffix-Text>]$
```

- `\n` erlaubt Zeilenvorschub
- `_` wird als Leerzeichen gewertet
- Soll kein Text vorangestellt werden: als Präfix `<leer>` übergeben (ohne Anführungszeichen)
- Nach aktuellem Stand [ungeprüft]: mindestens **zwei** Argumente (Kommando und Text davor). Ab drei Argumenten
  sind **die letzten zwei** immer Text davor und Text danach — hat das Kommando eigene Argumente, also den
  Text danach mit angeben (notfalls `<leer>`). Ein nicht auflösbares Kommando ergibt leer.

### Beispiel (Tabellenvariante)

```
$[tab_kommandorahmen tab_pr_begruendung \nDie_Begründung:\n Hier_endet_die_Begründung]$
→ Falls eine Begründung in der Privat-Leistung vorhanden ist, fügt dieses Kommando 
  einen Zeilenvorschub, den Text "Die Begründung:" und einen weiteren Zeilenvorschub 
  vorne ein. Und nach der Begründung wird der Text "Hier endet die Begründung" angefügt.
```

---

## kommandovergleich — Zwei Kommandos vergleichen

### Kernkonzept
Testet ob zwei Kommandos das gleiche Ergebnis liefern. Besonders sinnvoll in Kombination mit dem if- oder dem if_then-Kommando.

### Syntax

```
$[kommandovergleich <Kommando1> <args1> UND <Kommando2> <args2>]$
```
Im Kommando selbst stehen **keine** Klammern; frühere Fassungen dieser Referenz zeigten
geschweifte Klammern [ungeprüft].

Die Argumente sind: das erste Vergleichskommando, dann die Trennsequenz `"UND"` und anschließend das zweite Vergleichskommando.

- **Gleichheit:** Ergebnis `"1"`
- **Ungleichheit:** Ergebnis `"0"`

### Beispiel

```
$[if_then kommandovergleich [ arztname UND abrechnenderArzt_name ] 0 abrechnenderArzt_name]$
```
→ gibt den abrechnenden Arzt nur aus, wenn er sich vom Arzt des Briefes unterscheidet. Die **eckigen**
Klammern sind die Altsyntax des if/if_then für Kommando-Argumente ohne Operator; mit Operator geht es auch
ohne Klammern: `$[if kommandovergleich pn UND pv zs_equals 1 gleich ungleich]$` [ungeprüft].

---

## abZeichen / bisZeichen — Substring-Extraktion

### abZeichen
Gibt das Ergebnis eines Kommandos **ab** dem n-ten Zeichen aus (n zählt ab 1, das n-te Zeichen ist dabei)
[ungeprüft].

```
$[abZeichen <n> <Kommando> <args>]$
```

### bisZeichen
Gibt das Ergebnis eines Kommandos **bis** zum n-ten Zeichen aus (die ersten n Zeichen).

```
$[bisZeichen <n> <Kommando> <args>]$
```

---

## ganzzahlAufrunden — Aufrunden

### Syntax

```
$[ganzzahlAufrunden <Zahl-oder-Platzhalter> <args...> <Vielfaches>]$
```

Es werden mindestens zwei Argumente benötigt: 1. Argument – eine ganze Zahl oder ein Platzhalter, der eine ganze Zahl liefert, ggf. gefolgt von Argumenten des Platzhalters; letztes Argument – eine positive ganze Zahl, auf deren Vielfache aufgerundet werden soll.

Nach aktuellem Stand [ungeprüft]: Nachkommastellen werden **vor** dem Aufrunden abgeschnitten (12,7 wird wie 12
behandelt), negative Zahlen runden Richtung null.

---

## vorKommaWert / nachKommaWert — Zahlen-Splitting

### vorKommaWert
Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis eine Gleitkommazahl enthält. Von dieser Zahl wird der Wert **vor** dem Komma genommen.

### nachKommaWert
Analog, aber der Wert **nach** dem Komma.

Nach aktuellem Stand [ungeprüft]: Enthält das Ergebnis kein Komma (z. B. „12“), liefern **beide** leer; ein
Minuszeichen geht verloren.

---

## ohneWaehrung — Währungszeichen entfernen

Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis einen Betrag mit Währung enthält. Davon wird der Betrag **ohne** Währungszeichen zurückgegeben.

---

## anzahlTabelleneintraege — Zählen in Tabellen

### Ohne Bedingung
```
$[anzahlTabelleneintraege]$
```
Anzahl der Einträge der Tabelle. Kann in allen internen Vorlagen zum Drucken einer Tabelle verwendet werden, auch in Statistik-Vorlagen.

### Mit Bedingung
```
$[anzahlTabelleneintraege mit <Bedingung>]$
```
Wie `anzahlTabelleneintraege`, allerdings mit einer Bedingung der Form `<Name der Tabellenspalte> = <Eintrag>`.

Internes Kommando: nur in internen Tabellen- und Statistikvorlagen. Groß-/Kleinschreibung egal, Leerzeichen
in Spaltenname oder Wert als `_` [ungeprüft].

---

## zwischenablage — Clipboard-Zugriff

Gibt den Text aus der Zwischenablage aus, sofern vorhanden.

```
$[zwischenablage]$
```

---

## Tabellen-Varianten der Steuerkommandos

| Tabellen-Kommando | Text-Äquivalent | Hinweis |
|---|---|---|
| `tab_if` | `if` | Für Tabellenplatzhalter. Andere Tabellenplatzhalter im Ausgabewert funktionieren, wenn sie mit `${…}$` geklammert werden, z. B. `$[tab_if indikator zs_equals <nichtleer> ${bezeichnung}$]$` [ungeprüft]. Vergleichswerte werden nicht als Platzhalter ausgeführt |
| `tab_if_then` | `if_then` | **Veraltet**, in der Kommandoliste ausgeblendet, funktioniert noch; durch `tab_if` ersetzbar |
| `tab_kommandorahmen` | `kommandorahmen` | Für Tabellenplatzhalter. Andere Reihenfolge: Tabellenkommando, Text davor, Text danach, **dann** weitere Argumente [ungeprüft] |
| `tab_anzahl` | – | Wie oft der Zellenwert eines Tabellenkommandos in der Spalte vorkommt; mit `tab_if` kombinierbar [ungeprüft] |

---
---

# selektierterTermin — Vollständige %-Ersetzungsreferenz

Das Kommando `selektierterTermin` (und die verwandten Kommandos `selektierteTermineErster`, `selektierteTermineLetzter`, `selektierteTermine`, `selektierteTermineTagErster`, `selektierteTermineTagLetzter`, `selektierteTermineTagIterator`, `selektierteTermineMWU`, `selektierteTermineEinzahlMehrzahl`, das veraltete `selektierteTermineListe` sowie `patientenTermine` und das interne Tabellenkommando `tabellenTermin`) verwenden ein eigenes Ersetzungssystem mit %-Platzhaltern.

Allgemein [ungeprüft]: Bei überlappenden Codes gewinnt der längste (`%doz` vor `%d`, `%ps`
vor `%p`, `%cA` vor `%c`). `\n` im Muster wird zum Zeilenumbruch. Ist der Patient gesperrt, lautet die
ganze Ausgabe „gesperrt“. In DOCX-Briefen werden Emoji entfernt.

## Grundlegende Termininfo-Platzhalter

| Platzhalter | Beschreibung |
|---|---|
| `%a` | Terminart (Kürzel) |
| `%A` | Terminart (Beschreibung) |
| `%anh` | Ob Termin Anhang hat (📎) |
| `%b` | Termin Zeit bis |
| `%c` | Terminlokalität (Kürzel) |
| `%cA` | Terminlokalität mit Adresse: „<Lokalitätsbezeichnung>, <Adresszeile der Betriebsstätte>“ |
| `%cB` | Terminlokalität (Beschreibung) |
| `%cEm` | E-Mail-Adresse der Betriebsstätte des Termins [ungeprüft] |
| `%cTel` | Telefonnummer der Betriebsstätte des Termins [ungeprüft] |
| `%cN` | Name der Betriebsstätte(n) des Termins [ungeprüft] |
| `%C` | Kalendername(n), kommasepariert |
| `%d` | Datum mit Zeit |
| `%doz` | Datum ohne Zeit |
| `%e` | Dokumentierender Nutzer (Kürzel) |
| `%ed` | Erstellungszeitpunkt |
| `%edoz` | Erstellungsdatum ohne Zeit |
| `%i` | Termininfo |
| `%G` | Geburtsdatum |
| `%k` | Kalendername(n) (Kürzel kommasepariert) |
| `%K` | Kassenname |
| `%l` | Terminlänge in Minuten |
| `%L` | Lebensalter (relativ zum Termindatum) |
| `%M` | Vollname des Patienten (Titel Vorname Zusatz Nachname) |
| `%n` | Nutzername (vom Kalender des Termins) |
| `%N` | Nachname des Patienten |
| `%o` | Suchname |
| `%oc` | Suchname der Terminkette, leer ohne Kette [ungeprüft] |
| `%Ol` | Anbieter des Onlinetermins |
| `%p` | Privat/Gesetzlich (P oder G), für OTK-2 auch Selbstzahler/Berufsgenossenschaft (S oder B), auch H (HZV); ohne Patient „-“ |
| `%ps` | Bestands- oder Neupatient (B oder N) |
| `%P` | PatientenID |
| `%r` | Grund der letzten Verschiebung oder Löschung |
| `%s` | Erinnerungs-Status (✉️ + Versanddatum + Kreuz/Haken für jeden bisherigen Versuch und Anzahl an noch offenen Anfragen + ✉️ + –– für ausstehende Erinnerungen) |
| `%S` | Schwangerschaftswoche W+T |
| `%t` | Telefon (nur die erste Nummer, außer bei der Kalendereinstellung für alle Nummern) |
| `%T` | Titel |
| `%u` | Nutzerkürzel (vom Kalender des Termins) |
| `%U` | Alle Nutzerkürzel (mit ,) |
| `%v` | Termin Zeit von |
| `%V` | Vorname des Patienten |
| `%w` | Termin Datum, Wochentag kurz |
| `%W` | Wiederholung (zeigt W wenn ja, sonst nichts) |
| `%x` | Termin Datum, Wochentag ausgeschrieben |
| `%wd` | ✓, wenn der Patient als „war da“ markiert ist (Emoji) [ungeprüft] |
| `%wdx` | unterdrückt den automatischen „war da“-Haken in der Kalenderbeschriftung, Ausgabe leer [ungeprüft] |
| `%Ü` | Übernachtung |

## Zeit-Varianten mit Vorlauf und Rundung

| Platzhalter | Beschreibung |
|---|---|
| `%vv` | Termin Zeit von mit Vorlauf |
| `%vr` | Termin Zeit von (gerundet auf 10 Minuten) |
| `%br` | Termin Zeit bis (gerundet auf 10 Minuten) |
| `%vvr` | Termin Zeit von mit Vorlauf (gerundet auf 10 Minuten) |
| `%vq` | Termin Zeit von (abgerundet auf Viertelstunde) |
| `%bq` | Termin Zeit bis (abgerundet auf Viertelstunde) |
| `%vvq` | Termin Zeit von mit Vorlauf (abgerundet auf Viertelstunde) |

### Rundungsregeln
- `%vr`, `%br`, `%vvr` runden die Minutenangabe auf volle **10 Minuten** ab (z.B. 14:13 → 14:10, 9:35 → 9:30)
- `%vq`, `%bq`, `%vvq` runden die Minutenangabe auf **Viertelstunden** (z.B. 11:14 → 11:00, 11:18 → 11:15)

### Zeitarithmetik
Bei `%d`, `%doz`, `%v` und `%b` können zusätzlich **Tage (d), Stunden (h) oder Minuten (m)** addiert oder subtrahiert werden (genau ein Einheitenbuchstabe, Groß-/Kleinschreibung egal, `M` = Minuten; nicht bei `%vv`, `%vr`, `%vq` [ungeprüft]):
- `%d+1d` — Datum + 1 Tag
- `%b+1h` — Endzeit + 1 Stunde
- `%v-15m` — Startzeit − 15 Minuten

### Vorherige-Zustand-Suffix `p`
Datums- und Kalenderangaben können um ein `p` verlängert werden, um bei **Terminbewegungen** den alten Zustand anzuzeigen. Diese Funktion gibt es nur bei Terminänderungsbenachrichtigungen und der Nutzung eines Briefkommandos der selektierteTermine-Familie.
- `%v` → `%vp` (vorheriger Startzeitpunkt)
- `%vv` → `%vvp` (vorheriger Startzeitpunkt mit Vorlauf)
- außerdem `%bp`, `%dp`, `%dozp`, `%wp`, `%xp`, `%kp`, `%Cp` [ungeprüft]; ohne Terminbewegung
  erscheint „-Fehler in Kommandoverwendung-“ (bei `%kp`/`%Cp` leer)

## Platzhalter die Patientendetails erfordern

**Achtung:** Folgende Kommandos funktionieren im Allgemeinen nur mit geladenen Patientendetails. In der Briefschreibung werden diese nachgeladen, aber normalerweise **nicht** für die Anzeige im Kalenderfenster. Dies kann mit entsprechenden **Performanzeinbußen** in den praxisweiten Kalendereinstellungen aktiviert werden.

| Platzhalter | Beschreibung |
|---|---|
| `%B` | Behandelnder Arzt (Kürzel) |
| `%BN` | Behandelnder Arzt (Nachname) |
| `%BVN` | Behandelnder Arzt (voller Name) |
| `%EB` | Erstbehandler (Kürzel) |
| `%adrCtr` | Land (Patientenadresse) |
| `%adrCit` | Stadt (Patientenadresse) |
| `%adrStr` | Straße mit Hausnummer (Patientenadresse) |
| `%adrZip` | Postleitzahl (Patientenadresse) |
| `%VR` | Rufname, sonst Vorname [ungeprüft] |
| `%g` | Anrede des Patienten (Herr/Frau) |
| `%h` | Anrede des Patienten in Langform (Sehr geehrter Herr/Sehr geehrte Frau) |
| `%formularlinks` | Erzeugt einen Link für die fälligen Patientenformulare |
| `%m` | E-Mail |
| `%z1` | Patientenspezifisches Ja/Nein Feld 1 |
| `%z2` | Patientenspezifisches Ja/Nein Feld 2 |
| `%z3` | Patientenspezifisches Text Feld 1 |
| `%z4` | Patientenspezifisches Text Feld 2 |
| `%z5` | Patientenspezifisches Text Feld 3 |
| `%z6` | Patientenspezifisches Text Feld 4 |

## %if — Bedingte Logik innerhalb von Termin-Platzhaltern

### Syntax

```
%if((<zu prüfender Text>) <Operator> ((<Vergleichswert1>) (<Ausgabewert1>)) ((<Vergleichswert2>) (<Ausgabewert2>)) ... (<Rückfallwert>))
```
Der Prüftext und jeder Wert stehen in eigenen Klammern, jedes Paar zusätzlich in einem Klammerpaar (so auch
im Beispiel unten). Frühere Fassungen dieser Referenz zeigten eine andere, ungültige
Syntaxzeile; eine falsche Form ergibt „Ungültige If-Syntax: …“ [ungeprüft]. Der Vergleich unterscheidet
Groß-/Kleinschreibung; `kleiner/größer` gibt es in `%if` nicht.

### Operatoren
- `zsEquals` — Gleichheit
- `zsNotEqual` — Ungleichheit
- `zsContains` — Enthaltensein
- `zsNotContains` — Nicht-Enthaltensein

**Achtung:** Die Operatornamen in `%if` sind **anders geschrieben** als im `$[if]$`-Kommando! (`zsEquals` vs. `zs_equals`)

### Escape-Regeln
Runde Klammern, die nicht zur Parametertrennung gehören sondern als Text dargestellt werden sollen, mit `\` escapen (`\(`, `\)`).

### Beispiel

```
%if((%g) zsEquals ((Herr) (🚹)) ((Frau) (🚺)) (?))
```
→ Nimmt die Anrede `%g`, wandelt "Herr" in 🚹 um, wandelt "Frau" in 🚺 um und gibt sonst ein ? aus.

## Einschränkungen bei Terminerinnerungen

Bei Terminerinnerungen werden die Argumente `%L`, `%s` und `%S` derzeit **nicht** unterstützt.

Nach aktuellem Stand [ungeprüft]: Automatisch versandte Terminerinnerungen und -benachrichtigungen werden auf dem
**Server** zusammengesetzt. Dort gelten nur die Termin-Kommandos (`selektierterTermin`, `selektierteTermine…`)
und `patientenTermine`; andere und verschachtelte Kommandos werden entfernt. Beim Speichern einer solchen
Vorlage warnt der Client vor nicht unterstützten Kommandos.

### Wo `selektierterTermin` einen Wert liefert [ungeprüft]

Leer ist es immer dann, wenn der Aufrufer keinen Termin mitgibt. Termine werden mitgegeben u. a. beim Druck
aus der Termininfo (z. B. Terminzettel), beim Druck aus dem Fenster „Patiententermine“, bei E-Mail/SMS aus
dem Termin heraus und in Aktionsketten, die aus der Termininfo gestartet werden oder vorher einen Termin
suchen. Aktionsketten über einen Auslöser, die Symbolleiste oder das Suchfeld haben keinen Termin.

---
---

# patientenTermine — Vollständige Parameter-Referenz

Das Text-Kommando `patientenTermine` gibt alle nicht gelöschten Termine des Patienten ab dem morgigen Tag aus (zeitlich aufsteigend). Folgende **Parameter** beeinflussen die Auswahl der Termine:

## Parameter

| Parameter | Beschreibung |
|---|---|
| `-abSofort` | Termine ab dem jetzigen Zeitpunkt ausgeben |
| `-vergangene` | bisherige Termine ausgeben |
| `-Zeitraum <Modus>` | Modus kann `AQ` sein für aktuelles Quartal oder `AJ` für das aktuelle Jahr. Auch Addition und Subtraktion sind möglich, also z.B. `AQ-1` für das letzte Quartal oder `AJ-1` für das letzte Jahr |
| `-heutige` | nur Termine von heute |
| `-Terminarten <Kürzel1>,<Kürzel2>,...` | nur Termine der aufgeführten Terminarten ausgeben |
| `-ohne_Terminarten <Kürzel1>,<Kürzel2>,...` | nur Termine OHNE die aufgeführten Terminarten ausgeben |
| `-Anzahl <Zahl>` | nur die ersten `<Zahl>` Termine ausgeben |
| `-position <Zahl>` | nur den so-vielen Termin ausgeben, falls vorhanden |
| `-ohneHaken` | früher: ohne Haken bei abgearbeiteten Terminen; nach aktuellem Stand ohne Wirkung [ungeprüft] |
| `-heilmittelTermine` | sucht nur die Termine heraus, die für Heilmittelerbringer mit einer Heilmittelverordnung verknüpft sind |
| `-absteigend` | Termine zeitlich absteigend ausgeben (fehlte bisher in dieser Referenz) |

Nach aktuellem Stand [ungeprüft]: `-ohneHaken` hat keine Wirkung mehr. Von `-vergangene`, `-abSofort`, `-heutige`
wirkt nur eines (in dieser Rangfolge). `-Terminarten` hat Vorrang vor `-ohne_Terminarten`; Kürzel werden
exakt verglichen. `-position` wirkt vor `-Anzahl`. Werte mit Leerzeichen (z. B. Terminart-Kürzel) dürfen in
doppelte Anführungszeichen gesetzt werden. Ausgabe: ein Termin je Zeile.

## Ersetzungsmuster

Die Ausgabe verwendet dieselben `%`-Platzhalter wie `selektierterTermin` (siehe oben): `%a`, `%A`, `%d`, `%v`, `%b`, etc.

## Beispiel

```
$[patientenTermine -abSofort -Anzahl 3 %d - %A (%c)]$
```
Nach aktuellem Stand bleiben Unterstriche im Ausgabemuster von `patientenTermine` **stehen**; Leerzeichen
funktionieren direkt [ungeprüft]. Frühere Fassungen schrieben `%d_-_%A_(%c)`.
→ Gibt die nächsten 3 Termine ab sofort aus, mit Datum, Terminart und Terminlokalität.

---
---


## Kontextregel: `patientenTermine` als Ersatz fuer `selektierterTermin`

`selektierterTermin` und die gesamte `selektierteTermine`-Familie haben Kontext
**Terminerinnerung** — sie liefern leer, wenn der Aufrufer keinen Termin mitgibt (siehe „Wo
`selektierterTermin` einen Wert liefert“).
Realbefund 2026-08-26: eine SMS-Vorlage, die aus einer per Karteieintrag ausgeloesten Aktionskette
gerendert wurde, zeigte einen leeren Termin, weil in diesem Kontext kein Termin selektiert ist.

`patientenTermine` hat Kontext **Patient**, braucht keinen selektierten Termin und akzeptiert
dieselben `%`-Platzhalter. Ersatzmuster:

```
$[patientenTermine -abSofort -Terminarten Erstkontakt,Erstkontakt_Weiterbildung -Anzahl 1 %doz um %v Uhr]$
```

Zwei Fallstricke:

- **Leerzeichen im Ausgabemuster:** Frühere Fassungen verlangten Unterstriche (`%doz_um_%v_Uhr`). Nach
  aktuellem Stand werden Unterstriche dort **nicht** in Leerzeichen umgewandelt, Leerzeichen
  funktionieren direkt [ungeprüft]. Ob der Server bei automatischen Erinnerungen genauso arbeitet, ist offen.
- **`-Terminarten` ist nicht Kosmetik.** Ohne Einschraenkung liefert `-Anzahl 1` den zeitlich
  naechsten Termin ueberhaupt — bei einem Patienten mit frueherem Termin anderer Art steht dann die
  falsche Uhrzeit in der Nachricht.

Wird die Nachricht dagegen aus dem Terminerinnerungssystem selbst versandt, ist ein Termin
selektiert und `selektierterTermin` funktioniert — der Umbau ist dort unnoetig.

# selektierteTermine — Nachfolger von selektierteTermineListe

Laut Beschreibung in der Kommandoliste [ungeprüft]:

```
$[selektierteTermine <TerminParameter> -trenner <Trenner>]$
$[selektierteTermineTagErster <TerminParameter> -trenner <Trenner>]$
$[selektierteTermineTagLetzter <TerminParameter> -trenner <Trenner>]$
$[selektierteTermineTagIterator %erster(<Muster>) %letzter(<Muster>) %alle(<Muster>; <Trenner>) -trenner <Trenner>]$
```

- `<TerminParameter>`: dieselben %-Codes wie bei `selektierterTermin`, Leerzeichen direkt (kein `_`), Standard `%d`.
- `-trenner`: Standard Zeilenumbruch; mit Leerzeichen in doppelte Anführungszeichen setzen. Darin `\"`, `\\`, `\n`, `\t`.
- `…TagErster`: je Tag der Termin mit dem frühesten Beginn; berücksichtigt alle Termine desselben Patienten an den selektierten Tagen.
- `…TagLetzter`: je Tag der Termin mit dem spätesten Ende.
- `…TagIterator`: Vorlage je Tag; `%alle(…)` trennt standardmäßig mit „, “; `\)` und `\;` escapen.
  Beispiel: `$[selektierteTermineTagIterator %erster(%doz %v)-%letzter(%b) %alle(%A)]$`

# selektierteTermineListe — Syntax (veraltet)

In der Kommandoliste ausgeblendet, funktioniert in bestehenden Vorlagen weiter. Für neue Vorlagen
`selektierteTermine` verwenden.

## Syntax

```
$[selektierteTermineListe <TerminParameter> <Trennzeichen>]$
```

Als `<TerminParameter>` funktionieren dieselben `%`-Platzhalter wie im Kommando `selektierterTermin`. Mit dem `<Trennzeichen>`-Parameter kann festgelegt werden, wie die Termininfos voneinander getrennt werden sollen. Ist kein Trennzeichen festgelegt, wird ein **Zeilenumbruch** als Trennzeichen verwendet. Innerhalb beider Argumente müssen Leerzeichen durch **Unterstriche** ersetzt werden.

## Beispiel

```
$[selektierteTermineListe %A,_%d,_-%b]$
```
→ Gibt alle selektierten Termine aus im Format: "Terminart, Datum mit Zeit, -Endzeit" getrennt durch Zeilenumbrüche.

---
---

# Alle Termin-bezogenen Kommandos (Thema: Termine)

Zusammenstellung aller Kommandos mit Thema "Termine" (aus Screenshot: Filter nach Themen → Termine):

## Text-Kommandos

| Name | Art | Param | Kontext | Beschreibung |
|---|---|---|---|---|
| aktuellerTerminInfofeld | Text | | Patient | Infofeld des heutigen Termins |
| datum | Text | | Kalendertag | Datum für ALLE Termine |
| druckdatum | Text | | Patiententermine | Datum und Uhrzeit des Druckens |
| kalender | Text | | Kalendertag | Name des Kalenders |
| name | Text | | Patiententermine | Voller Name des Patienten, Version 1 |
| patientenname | Text | | Patiententermine | Voller Name des Patienten, Version 2 |
| patientenTermine | Text | ✓ | Patient | Patiententermine (vollständige Parameter siehe oben) |
| selektierteTermineEinzahlMehrzahl | Text | ✓ | Terminerinnerung | Einzahl/Mehrzahl-abhängige Texte |
| selektierteTermineErster | Text | ✓ | Terminerinnerung | = selektierterTermin (erster Termin) |
| selektierteTermineLetzter | Text | ✓ | Terminerinnerung | Letzter selektierter Termin |
| selektierteTermine | Text | ✓ | Terminerinnerung | Alle selektierten Termine, Option `-trenner` (Nachfolger von selektierteTermineListe) |
| selektierteTermineListe | Text | ✓ | Terminerinnerung | **veraltet**, ausgeblendet; Alle selektierten Termine auflisten |
| selektierteTermineTagErster | Text | ✓ | Terminerinnerung | Je Tag der früheste Termin |
| selektierteTermineTagLetzter | Text | ✓ | Terminerinnerung | Je Tag der späteste Termin |
| selektierteTermineTagIterator | Text | ✓ | Terminerinnerung | Vorlage je Tag mit `%erster`, `%letzter`, `%alle` |
| selektierteTermineMWU | Text | ✓ | Terminerinnerung | Geschlechtsspezifische Texte (M/W/U) |
| selektierterTermin | Text | ✓ | Terminerinnerung | Informationen des selektierten Termins (%-Platzhalter) |
| terminArtBezeichnung | Text | | Patient | Terminart des heutigen Termins des aktuellen Patienten |

## Tabellen-Kommandos

| Name | Art | Kontext | Beschreibung |
|---|---|---|---|
| adresse | Tabelle | Patiententermine | Adresse der Betriebsstätte des Termins |
| beginn | Tabelle | Kalendertag | Beginn des Termins |
| behandler | Tabelle | Patiententermine | Verantwortlicher Behandler bzw. Arzt |
| datum | Tabelle | Patiententermine | Datum des Termins |
| ende | Tabelle | Kalendertag | Ende des Termins |
| gebdatum | Tabelle | Kalendertag | Geburtsdatum des Patienten |
| handy | Tabelle | Kalendertag | Handynummer des Patienten für Termin |
| info | Tabelle | Kalendertag | Freitext – Info für Termin |
| info | Tabelle | Patiententermine | Info des Termins |
| kalender | Tabelle | Patiententermine | Kalender des Termins |
| laenge | Tabelle | Patiententermine | Dauer des Arzt-Patienten-Kontaktes |
| patientenname | Tabelle | Kalendertag | Name des Patienten |
| patientennummer | Tabelle | Kalendertag | Patientennummer |
| plz | Tabelle | Kalendertag | PLZ des Patienten |
| strasse | Tabelle | Kalendertag | Straße des Patienten |
| tel | Tabelle | Kalendertag | Telefonnummer |
| terminart | Tabelle | Kalendertag | Terminart (Bezeichner) |
| terminart | Tabelle | Patiententermine | Terminart des Termins |
| todos | Tabelle | Kalendertag | ToDos des Termins |
| todos | Tabelle | Patiententermine | ToDos für den Termin |
| wochentag | Tabelle | Patiententermine | Wochentag des Termins |
| wochentagKurz | Tabelle | Patiententermine | Wochentag (Kurzform) |
| wohnort | Tabelle | Kalendertag | Wohnort des Patienten |
| zeit | Tabelle | Patiententermine | Uhrzeit des Termins |
| lokalitaet | Tabelle | Patiententermine | Terminlokalität **[ungeprüft]** |
| email | Tabelle | Kalendertag | E-Mail-Adresse des Patienten **[ungeprüft]** |
| tabellenTermin | Tabelle | Kalendertag, Patiententermine | Je Termin ein %-Muster wie bei `selektierterTermin` [ungeprüft] |

---
---

# d — Das Datum-Kommando (Konfigurator)

## Kernkonzept
Vielseitiges Datum-Kommando für System-, Kartei-, Besuchs- und Karteieintragsdaten. Kann Daten formatieren, Offsets berechnen und auf verschiedene Zeitquellen zugreifen.

## Syntax

```
$[d <Arg1> <Arg2> <Arg3> <Arg4>]$
```

Kurzform:
```
$[d <STKBE>[Tage] <Format> [Letzter Karteieintrag]]$
$[d <STKBE>[Tage] [<SML><SML>] [Letzter Karteieintrag]]$
```

## Arg1 — Bestimmung des Datums

| Wert | Beschreibung |
|---|---|
| `S` | Systemdatum (aktuelles Datum/Uhrzeit) |
| `T` | Tageslisten-Datum (oben rechts im Fenster "Tagesliste") |
| `K` | Kartei-Datum (unten links in Kartei des Patienten) |
| `G` | Geburts-Datum |
| `B` | Datum des letzten Besuchs |
| `A` | Datum des aktuellen Besuchs (nur Radiologen-Modus) |
| `E` | Datum des letzten Karteieintrags. Braucht Arg3 (Karteieintragtyp) um Datum zu bestimmen. Optional kann der Index mit Arg4 angegeben werden: 0 für den ersten Eintrag, 1 für den zweiten, usw. -1 für den letzten, -2 für den vorletzten, usw. |
| `AE` | Datum des letzten Karteieintrags des aktuellen Besuchs (nur Radiologen-Modus). Braucht Arg3 (Karteieintragtyp) |
| `L` | Datum der letzten Leistung einer bestimmten Nummer. Braucht Arg3 (eine oder mehrere Nummern, kommasepariert). Soll nicht die letzte, sondern die vorletzte bzw. drittletzte Leistung genommen werden, so ist als Arg4 die Zahl 2 bzw. 3 usw. anzugeben |
| `LA` | Wie Modus "L", nur dass die Leistung nur vom aktuellen Schein/der aktuellen Rechnung genommen wird |
| `R` | Schwangerschaft: Datum letzte Regel |
| `U` | Schwangerschaft: Geburtstermin |
| `Tage` | Manipulation des Datums, auch negativ möglich. Zum Beispiel: `S-10` oder `T5` für Systemdatum minus zehn Tage bzw. Tageslistendatum plus fünf Tage |

Nach aktuellem Stand [ungeprüft]:
- **Ohne Arg2 ist das Format `dd.MM.yy`** (zweistelliges Jahr), nicht `dd.MM.yyyy`.
- **Unbekannte Datumsart → Systemdatum.** `$[d I48.1]$` liefert also das heutige Datum, weder einen
  Diagnose-Check noch „-“. „-“ kommt nur, wenn eine gültige Datumsart kein Datum findet (kein
  Geburtsdatum, kein Eintrag des Typs …).
- Nur eine Zahl als Arg1 (z. B. `-10`) = Systemdatum ± Tage. `A` ist technisch nicht auf den
  Radiologen-Modus beschränkt.
- Bei `E`/`AE` darf Arg3 mehrere Kürzel kommagetrennt enthalten (Groß-/Kleinschreibung egal; bei Formularen
  zählt das Formulartyp-Kürzel). Arg4: leer bzw. `-1` = jüngster, `0` = ältester, `-2` = vorletzter. Ohne
  Arg3 kommt ein Hinweis und „-“.
- Weitere Arten: `P`, `TE` (kuto), `F` (Altform: Systemdatum im Format `ddMMyyyy`).

## Arg2 — Formatierung des Datums

### Variante a: Custom-Format

Trennzeichen beliebig einsetzbar, zum Beispiel Punkt "." oder Doppelpunkt ":"

| Kürzel | Bedeutung |
|---|---|
| `q` | Quartal |
| `dd` | Tag |
| `M` | Monat |
| `yy` | Jahr 2-stellig |
| `yyyy` | Jahr 4-stellig |
| `HH` | Stunde |
| `mm` | Minute |
| `EEEE` | Wochentag |

#### Beispiele Custom-Format

| Format | Ergebnis (für 26.06.2015 15:15) |
|---|---|
| `dd.MM.yy` | 26.06.15 |
| `dd.MM.yyyy` | 26.06.2015 |
| `ddMMyy` | 260615 |
| `ddMMyyyy` | 26062015 |
| `HH:mm` | 15:15 |

### Variante b: SML-Format

Der erste Buchstabe steht für die Formatierung des **Datums**, der zweite Buchstabe steht für die Formatierung der **Zeit**.
Arg2 gilt als SML-Format, sobald es **genau zwei** Zeichen aus `N S M L` sind. `MM`, `SS`, `LL`
sind deshalb immer Stile, nie Monat oder Sekunde; ein eigenes Format `MM` erzwingt man mit Hochkommata `'MM'` [ungeprüft]:

| Kürzel | Bedeutung |
|---|---|
| `L` | Lange Formatierung |
| `M` | Mittlere Formatierung |
| `S` | Kurze Formatierung |
| `N` | Keine Angabe machen |

#### Beispiele SML-Format

| Format | Ergebnis |
|---|---|
| `SN` in `$[d S SN]$` | 26.06.15 |
| `MN` in `$[d S MN]$` | 26.06.2015 |
| `LN` in `$[d S14 LN]$` | 10. Juli 2015 |
| `LS` in `$[d B-7 LS]$` | 9. Juni 2015 19:23 |
| `SS` in `$[d S SS]$` | 26.06.15 15:15 |

## Arg3 — Karteieintragtyp (nur bei E, AE) oder Leistungsnummer (bei L, LA)

### Für Karteieintragtyp (Modus E/AE):

| Beispiel | Kommando | Beschreibung |
|---|---|---|
| ANA | `$[d E10 SS ANA]$` | Zeigt 10 Tage nach dem letzten ANA-Eintrag des Patienten |
| THE | `$[d E5 SS THE]$` | Zeigt 5 Tage nach dem letzten THE-Eintrag des Patienten |

### Für Leistungsnummer (Modus L/LA):

| Beispiel | Kommando | Beschreibung |
|---|---|---|
| 201A | `$[d L SN 201A]$` | Datum der letzten Leistung mit Nr. 201A |
| 35600,35601 | `$[d L SN 35600,35601]$` | Datum der letzten Leistung mit Nr. 35600 oder 35601 |
| 35600,35601 (vorletzte) | `$[d L SN 35600,35601 2]$` | Datum der VORLETZTEN Leistung mit Nr. 35600 oder 35601 |

## Erweiterte Berechnungen

Zum betreffenden Datum können auch **Sekunden (s), Minuten (min), Stunden (h), Tage (d), Monate (m) und Jahre (y)** addiert und subtrahiert werden.
Achtung: Beim `d`-Kommando und im Zeitraum des `x`-Kommandos ist `m` der **Monat**; bei `karteiEintragWert`,
`formularEintrag` und `l` ist `m` die **Minute** und `M` der Monat [ungeprüft].

### Beispiele (Systemdatum = 1. Nov 2016, 14:48)

| Kommando | Ergebnis | Beschreibung |
|---|---|---|
| `$[d S+4h SS]$` | 01.11.16, 18:48 | + 4 Stunden |
| `$[d S+10y-1d SS]$` | 31.10.26, 14:48 | + 10 Jahre, − 1 Tag |
| `$[d S+10y SS]$` | 01.11.26, 14:48 | + 10 Jahre |
| `$[d S+10y LL]$` | 1. November 2026 um 14:48:19 MEZ | + 10 Jahre, langes Format |
| `$[d S10 SS]$` | 11.11.16, 14:48 | + 10 Tage (Kurzform) |

---
---

# l / l_alle / l_ohneKartei — Leistungskommandos (Konfigurator)

## Kernkonzept
Gibt Leistungen des Patienten aus (EBM, GOÄ, UVGOÄ). Drei Varianten:
- `l` — Leistungen des in der Kartei ausgewählten Scheins/(BG-)Rechnung
- `l_alle` — Alle Leistungen der geöffneten Kartei (alle Scheine + Privatrechnungen)
- `l_ohneKartei` — Leistungen des aktiven Scheins/Rechnung (heuristisch bestimmt)

## Syntax

```
$[l <Format> <Auswahl> <Trennsequenz>]$
$[l_alle <Leistungsart> <Format> <Auswahl> <Trennsequenz>]$
```

## Format — Ausgabeformat mit %-Platzhaltern

### Allgemeine Platzhalter (alle Leistungsarten)

| Platzhalter | Beschreibung |
|---|---|
| `%nr` | Leistungsnummer |
| `%t` | Text |
| `%typ` | Art der Leistung |
| `%abr` | Name des abrechnenden Arztes |
| `%erbr` | Name des Leistungserbringers |
| `%z` | Uhrzeit |
| `%a` | Anzahl |
| `%dm` | Datum – Monat |
| `%dt` | Datum – Tag |
| `%d` | Datum |

### GOÄ-/UVGOÄ-Leistungen (zusätzlich)

| Platzhalter | Beschreibung |
|---|---|
| `%nr` | Leistungsnummer |
| `%t` | Text |
| `%f` | Steigerungsfaktor |
| `%begr` | Begründung |
| `%einzelkostenInCentNetto` | Einzelkosten in Cent ohne USt. |
| `%einzelkostenInCentBrutto` | Einzelkosten in Cent mit USt. |
| `%kostenInCentNetto` | Kosten in Cent ohne USt. |
| `%kostenInCentBrutto` | Kosten in Cent mit USt. |

### EBM-Leistungen (zusätzlich)

| Platzhalter | Beschreibung |
|---|---|
| `%nr` | Leistungsnummer |
| `%snz` | Schnitt-Naht-Zeit |
| `%ops` | OPS-Codes (kommasepariert) |
| `%gebNr` | Gebührennummern (kommasepariert) |
| `%organ` | Organ (fehlte bisher) |

## Auswahl — Welche Leistungen

| Wert | Beschreibung |
|---|---|
| `N` | alle (default) |
| `J` | selektierte |
| `L` | letzteLeistung |
| `<Zahl>` | so-vielte Leistung |
| `<Zahl>d` | alle, die höchstens so-viele Tage alt sind |

Nach aktuellem Stand [ungeprüft] nehmen alle Varianten dieselbe Zeitspannen-Schreibweise: `<Zahl>d`, `w`, `M`
(Monat), `q`, `y`, `h`, `m` (**Minute**), auch Spannen wie `0-30d`. `l_alle` kennt als Leistungstyp
`ebm`, `goae` und `hzv` und schließt Leistungen in der Zukunft aus.

### Für l_alle zusätzlich

| Wert | Beschreibung |
|---|---|
| `<Zahl>d` | alle, die höchstens `<Zahl>` Tage alt sind |
| `<Zahl>q` | alle, die höchstens `<Zahl>` Quartale alt sind |
| `<Zahl>y` | alle, die höchstens `<Zahl>` Jahre alt sind |

## Trennsequenz

Zeichenkette, die die Ausgaben der einzelnen Leistungen trennt. Standard ist **Zeilenumbruch**.

## Beispiele

```
# Alle OPS-Codes der selektierten Leistungen, Komma-getrennt:
$[l %ops J ,_]$

# EBM-Codes aller Leistungen des Scheins + OPS-Codes + Schnitt-Naht-Zeit:
$[l EBM:_%nr_OPS:_%ops_Schnitt-Naht-Zeit_%snz_min N \n]$

# Codes aller Leistungen des heutigen Tages, getrennt durch Komma:
$[l %nr 0d ,]$

# Alle GNR und OPS-Codes der EBM-Leistungen der letzten 5 Jahre:
$[l_alle ebm GNR:_%gebNr_OPS:_%ops 5y \\n]$
```

---
---

# karteiEintragWert — Werte aus Karteieinträgen (Konfigurator)

Früherer Name: `karteiEintragValue_withArgs`. Liest einzelne Werte aus Karteieinträgen. Besonders wichtig für **CustomKarteieinträge (CKE)**, funktioniert aber auch für Standard-Karteieinträge.

## Syntax

```
$[karteiEintragWert <Arg1> <Arg2> <Arg3> <Arg4>]$
```

**Mindestens 4 Argumente erforderlich!**

## Arg1 — Karteieintragtyp-Kürzel

Das Kürzel des Karteieintragstyps (z.B. `BEH`, `ANA`, `THE`, `BIO`, `OPT`, `BMI` oder jedes Custom-KE-Kürzel).
Nach aktuellem Stand [ungeprüft] trifft Arg1 **auch das Kürzel eines Formulartyps**, exakt und mit
Groß-/Kleinschreibung.

## Arg2 — Variablenname / Key

Welcher Wert aus dem Karteieintrag gelesen werden soll:

| Wert | Beschreibung |
|---|---|
| `datum` | Datum des Karteieintrags |
| `text` | Gesamter Text des Karteieintrags (den früher hier genannten Key `eintrag` gibt es nicht, er liefert leer [ungeprüft]) |
| `customKarteiEintragEntries.<Variablenname>` | Einzelnes Feld eines CustomKarteieintrags, wobei `<Variablenname>` dem im CKE-Editor vergebenen Variablennamen entspricht |

**Hinweis:** Für Standard-KE-Typen (nicht-CKE) sind vor allem `datum` und `text` sinnvoll; nach aktuellem Stand
geht jedes Attribut des Karteieintrags (z. B. `letzteAenderungAm`) [ungeprüft]. Für CKE ist
`customKarteiEintragEntries.<Variablenname>` der Standard-Zugriffspfad; der Feldname muss exakt stimmen.
Optionen `-fuerScores` (Zahl mit Punkt, für `score`) und `-fuerText` dürfen an beliebiger Stelle stehen.

## Arg3 — Format

| Wert | Beschreibung |
|---|---|
| `_` | Kein spezielles Format (Standard für Nicht-Datum-Werte) |
| `dd.MM.yyyy` | Datumsformat (Java SimpleDateFormat-Syntax) |
| Andere Formate | Wie beim d-Kommando |

## Arg4 — Selektion

| Wert | Beschreibung |
|---|---|
| `N` | Letzten (neuesten) Karteieintrag des angegebenen Typs verwenden (Standard) |
| `D-<Zahl>t` | Letzter Eintrag innerhalb der letzten `<Zahl>` Tage |
| `D-<Zahl>h` | Letzter Eintrag innerhalb der letzten `<Zahl>` Stunden |
| `D-<Zahl>m` | Letzter Eintrag innerhalb der letzten `<Zahl>` Minuten |

## Beispiele

```

### Vollständige Argumentliste (Onlinehilfe, Stand 2026-07-30)

Die Onlinehilfe führt das Kommando unter dem Altnamen `karteiEintragValue_withArgs` und nennt
**fünf** Argumente:

```
<karteieintragtyp> <key> <format> <nutzeSelektiert> <soundsovielter>
```

Das fünfte Argument `soundsovielter` fehlte in dieser Referenz bislang. **Berichtigt
[ungeprüft]:** leer oder `1` = jüngster Eintrag, `2` = zweitjüngster, **`-1` = ältester**, `-2` =
zweitältester; `A` = alle (jüngster zuerst), danach optional ein Trenner (Standard „, “). Der frühere
Praxisbeleg (`$[karteiEintragWert FOR text _ N -1]$` zog das vorletzte Patientenformular) passt dazu nur,
wenn genau zwei Formulare vorlagen.

**Arg4 `nutzeSelektiert` — vollständige Werteliste:**

| Wert | Bedeutung |
|---|---|
| `J` | den in der Kartei selektierten Eintrag |
| `N` | den letzten Eintrag des angegebenen Typs |
| `AQ` / `AQ-n` | letzter Eintrag im aktuellen bzw. im n-letzten Quartal |
| `AD` / `AD-1` | nur heutige Einträge / gestern usw. |
| `D` + Zahl + `t`/`h`/`m` | letzter Eintrag innerhalb der Zeitspanne (Tage/Stunden/Minuten) |
| `Q` / `Q-n` | wie `AQ`, mit eingeschlossenen Quartalsgrenzen [ungeprüft] |
| Zeitspanne `<n>d`, `w`, `M`, `q`, `y`, `h`, `m` oder `<min>-<max><Einheit>` | Einträge in diesem Alter; `m` = Minute, `M` = Monat [ungeprüft] |

Nach aktuellem Stand [ungeprüft]: Andere Werte (auch `7t` ohne `D-`) filtern **nicht** — es wird einfach der
jüngste Eintrag genommen.

**Arg2 `datum` ist auch für Standard-KE dokumentiert**, mit Formatangabe in Arg3 — Beispiel aus
der Onlinehilfe: `$[karteiEintragValue_withArgs RÖN datum dd.MM.yyyy_HH.mm D-1t]$`.

> **⚠️ Widerspruch [ungeprüft]:** Nach aktuellem Stand trifft Arg1 auch das Formulartyp-Kürzel —
> `$[karteiEintragWert <Formulartyp-Kürzel> datum dd.MM.yyyy N]$` sollte das Datum des jüngsten Bogens
> dieses Typs liefern. Bis zur Nachprüfung gilt die folgende Aussage weiter.
>
> **⚠️ Strukturgrenze (2026-08-04 verifiziert):** Das Kommando filtert **ausschließlich** über den
> Karteieintragstyp. Ein Filter auf ein bestimmtes Formular, Kürzel oder eine Vorlage existiert
> nicht. Alle über arzt-direct eingehenden Patientenformulare liegen im gemeinsamen Typ `FOR`;
> `AQ`/`soundsovielter` grenzen nur zeitlich bzw. positionell ein, nicht inhaltlich. Wer einen
> bogenspezifischen Wert braucht, muss `formularEintrag` verwenden (dort aber keine Metafelder)
> oder per Aktionskette einen eigenen Karteieintragstyp erzeugen.

# Medikamente aus OP-Termin-CKE (Kürzel "OPT", Feld "Medikamente"):
$[karteiEintragWert OPT customKarteiEintragEntries.Medikamente _ N]$

# Körpertemperatur aus BIO-CKE:
$[karteiEintragWert BIO customKarteiEintragEntries.Körpertemperatur _ N]$

# Datum aus CKE der letzten 7 Tage im Format dd.MM.yyyy:
$[karteiEintragWert custom customKarteiEintragEntries.Datum dd.MM.yyyy D-7t]$

# Datum des letzten Röntgen-Eintrags (Standard-KE):
$[karteiEintragWert RÖN datum dd.MM.yyyy_HH:mm N]$

# In Kombination mit if_then (Wert nur ausgeben wenn vorhanden):
$[if_then karteiEintragWert TAPP customKarteiEintragEntries.vOPS2 _ D-1t zs_not_equal <leer> karteiEintragWert TAPP customKarteiEintragEntries.vOPS2-Text _ D-1t]$
```

### Praxis-Tipp: In Aktionsketten-Bedingungen

In Aktionsketten-Bedingungen wird `karteiEintragWert` häufig in der Kommando-Spalte verwendet:
```
Kommando: $[karteiEintragWert CHA2DS2 datum dd.MM.yyyy N]$
Relation: ist nicht
Vergleichswert: $[d S dd.MM.yyyy]$
```
→ Prüft ob der CHA2DS2-Score NICHT heute angelegt wurde (Duplikatschutz). Beide Seiten im selben
Format, denn „ist nicht“ vergleicht Text. Das heutige Datum kommt aus dem `d`-Kommando; einen Keypath
`$[&heute]$` gibt es nicht, er liefert den Text „Fehler: Keypath heute konnte nicht
aufgelöst werden!“.

---
---

# formularEintrag — Werte aus Patientenformularen (Konfigurator)

## Kernkonzept
Liest einzelne Werte aus tomedo-Patientenformularen (PatF) oder Custom-Formularen aus. Essentiell für Aktionsketten-Bedingungen, die auf Formularantworten basieren.

## Syntax

```
$[formularEintrag <FormularKürzel> <Variablenname> <Selektion>]$
```

**3 Argumente erforderlich**, optional `-index <n>` (1 bzw. leer = jüngstes, 2 = zweitjüngstes, -1 = ältestes Formular [ungeprüft]).

Nach aktuellem Stand [ungeprüft] werden alle Wörter zwischen dem ersten und dem letzten Argument mit **einem**
Leerzeichen zum Feldnamen verbunden — Feldnamen mit einfachen Leerzeichen sind damit adressierbar,
doppelte Leerzeichen nicht, `_` bleibt ein Unterstrich.

## Arg1 — FormularKürzel

Das Kürzel des Patientenformulars (z.B. `PatF-Anamnesebogen`, `PatF-Terminvereinbarung`, `PatF-Allgemeine-Beschwerden`). Entspricht dem Kürzel in der Formularverwaltung.

## Arg2 — Variablenname

Der Variablenname des Formularfeldes, dessen Wert ausgelesen werden soll. Die Variablennamen findet man in den **Patientenformular-Einstellungen** (Formularverwaltung → Patientenformular auswählen → Patientenformular-Einstellungen → Reiter "Elemente"). Dort kann man auch das Briefkommando per "Kopieren"-Button direkt kopieren.

## Arg3 — Selektion

#### Arg2 akzeptiert KEINE Metafelder

`formularEintrag` liest **ausschließlich Variablennamen von Formular-Elementen** (Reiter
„Elemente" der Patientenformular-Einstellungen). **Metafelder des Formulars — insbesondere das
Eingangs-/Erstellungsdatum — sind über dieses Kommando grundsätzlich nicht erreichbar.**

Konsequenz für die Praxis: Versuche wie `erstelltAm`, `created`, `datum`, `erstellt`,
`erstelltam` liefern **immer leer**; das ist kein Bezeichner-Problem, sondern eine
Architekturgrenze. Zwei belegte Auswege:

1. **Datum über den Karteieintrag** des eingegangenen Formulars holen (datiertes x-Kommando,
   Cap 1) — unabhängig vom Formularinhalt, benötigt aber den korrekten KE-Typ.
2. **Datums-Element im Formular ergänzen** — ein `expression`-Element mit `today()` und eigenem
   `shortTitle`; dann ist es ein reguläres Element und per `formularEintrag` auslesbar.

| Wert | Beschreibung |
|---|---|
| `N` | Neuestes (letztes) ausgefülltes Formular des Typs verwenden |
| `J` | das in der Kartei selektierte Formular [ungeprüft] |
| Zeitspanne, z. B. `7d`, `0-30d`, `1q`, `2M` | nur Formulare dieses Alters [ungeprüft] |

Nach aktuellem Stand [ungeprüft]: Jeder Wert **ohne Ziffer** (`N`, `d`, …) bedeutet „alle Formulare“. **`0` ist eine
Zeitspanne von null Tagen und findet nur heute ausgefüllte Bögen.** Bei Patientenformularen wird der Feldname
exakt (mit Groß-/Kleinschreibung) gesucht; fehlt das Feld, kommt leer ohne Hinweis. Bei klassischen
Formularen erscheint dagegen ein Hinweis „Formulare vom Typ … haben kein Feld …“.

## Beispiel

```
# Wert aus Patientenformular "PatF-Terminvereinbarung", Feld "Krankenkasse":
$[formularEintrag PatF-Terminvereinba... Krankenkasse N]$

# In Kombination mit kommandorahmen (nur wenn nicht leer):
$[kommandorahmen formularEintrag PatF-Test-Formular Var1 N Präfix_ _Suffix]$
```

### Praxis-Tipp: In Aktionsketten-Bedingungen

```
Kommando: $[formularEintrag PatF-Terminvereinba... Krankenkasse N]$
Relation: ist
Vergleichswert: Barmer
Datenlade: ☑ Lade alle Karteieinträge/Formulare vor Ausführung
```
→ Prüft ob im Patientenformular "Barmer" als Krankenkasse angegeben wurde.

---
---

# x — Komplexes Karteieintrags-Kommando (Konfigurator)

## Kernkonzept
Das x-Kommando ist das mächtigste Werkzeug zum Auslesen von Informationen aus der Kartei. Es hat zahlreiche Parameter (a bis g₂) für Filterung, Formatierung und Selektion.

> **Berichtigt im Oktober 2026 nach der Beschreibung des x-Kommandos in der Kommandoliste.**
> Frühere Fassungen dieser Referenz hatten die Parameter ab Position 5 verschoben benannt (Sortierung,
> Ausgabe, Filter, Ausgabeformat, Trennzeichen). Die Bedeutungen unten stehen so in der Kommandoliste;
> wo sie früheren Messungen widersprechen, sind sie mit [ungeprüft] markiert.

## Syntax

```
$[x a b₁ b₂ b₃ c₁c₂ d₁d₂d₃d₄ e₁e₂e₃e₄ f g₁ g₂]$
```

Zehn Argumente, durch Leerzeichen getrennt. Standard: `$[x … _ _ _ NJ NJ2N JJNN _ U _]$`. Fehlende Argumente
oder `_` nehmen den Standardwert.

| Pos. | Parameter | Bedeutung |
|---|---|---|
| 1 | a | Karteieintragstypen |
| 2 | b₁ | Anzahl |
| 3 | b₂ | Auswahl (markiert/nicht markiert/Besuch) |
| 4 | b₃ | Zeitraum (Alter) |
| 5 | c₁c₂ | Fettdruck von Sammel- und Typbezeichner (nur DOCX) |
| 6 | d₁d₂d₃d₄ | Zeilenumbrüche |
| 7 | e₁e₂e₃e₄ | Typbezeichner, Datum, Textumfang, Sammelbezeichner |
| 8 | f | Zusatzbedingungen (`invTime`, `ICDvorn`, `nurAktiveDiagnosen` …) |
| 9 | g₁ | Anhänge |
| 10 | g₂ | Anhangbreite in cm |

## Parameter-Übersicht

### a — Karteieintragtyp
Welcher Karteieintragtyp ausgelesen wird (z.B. `AU`, `BEH`, `ANA`, `THE`, `DDI`, `IMPF` oder jedes Custom-KE-Kürzel).

| Wert | Bedeutung |
|---|---|
| `…` (oder `...`) | alle Karteieinträge |
| `BES` | nur Typ BES |
| `-(BES),…` | alle außer BES |
| `BES,…` | erst BES, dann alle anderen |
| `ANA,BEF` | erst alle ANA, dann alle BEF — **zwei Gruppen** |
| `(ANA;BES)` | ANA und BES **gemischt in einer Gruppe** |

Nach aktuellem Stand [ungeprüft]: Kürzel werden ohne Groß-/Kleinschreibung verglichen, Formulare auch über das
Formulartyp-Kürzel. Ein **`+` wird nicht ausgewertet**: `DIA+DDI` gilt als ein einziges, nicht existierendes
Kürzel und liefert leer. Für mehrere Typen `,` (getrennte Gruppen) oder `(A;B)` (eine Gruppe) verwenden.

### b₁ — Anzahl der Karteieinträge
| Wert | Beschreibung |
|---|---|
| `inf` oder `_` | Keine Einschränkung |
| `<Zahl>` (z.B. `1`, `18`) | Maximale Anzahl |

### b₂ — Selektion
| Wert | Beschreibung |
|---|---|
| `_` oder `all` | Keine Einschränkung |
| `sel` | Nur in der Kartei selektierte Einträge |
| `inv_sel` | Nur nicht markierte Einträge |
| `bes` | Nur Einträge des aktuellen Besuchs (nur Radiologen) |

### b₃ — Zeitraum (Position 4; frühere Fassungen nannten ihn `c`)
| Wert | Beschreibung |
|---|---|
| `_` oder `inf` | Kein Zeitfilter |
| `2d`, `1M`, `1q`, `1y` | höchstens 2 Tage, 1 Monat, 1 Quartal, 1 Jahr alt |
| `2-d`, `2-3d` | mindestens 2 Tage bzw. 2 bis 3 Tage alt |
| `aq` | Aktuelles Quartal |
| `0-<Zahl>d` | Letzte N Tage (z.B. `0-10d`) |
| `L` | seit dem letzten Brief an denselben Empfänger |

Nach aktuellem Stand [ungeprüft]: außerdem `am`, `aj` (aktueller Monat/Jahr) und `aq-1` (genau das Vorquartal);
`m` und `M` sind hier beide **Monate**. **Bezugsdatum ist das Datum der Tagesliste**, nur ohne Tagesliste
heute. `Nq` beginnt am ersten Tag des Quartals N Quartale vor dem Bezugsquartal (`0q` = aktuelles Quartal,
`4q` = aktuelles + 4 Vorquartale, `8q` = 9 Quartale) und hat **keine Obergrenze** — Einträge in der Zukunft
zählen mit, `0-10d` schneidet sie ab. Ein ungültiger Wert ergibt still **keinen** Zeitfilter. Dauerdiagnosen
sind vom Zeitfilter ausgenommen (außer mit der Option `ddiAlter`).

### c₁c₂ — Fettdruck (2 Zeichen)
c₁ = Sammelbezeichner fett (J/N), c₂ = Typbezeichner fett (J/N). Wirkt nur in DOCX-Vorlagen. Standard `NJ`.

> **⚠️ Widerspruch zu früheren Fassungen [ungeprüft]:** Diese Position wurde hier bisher als
> „Reihenfolge/Sortierung“ beschrieben (`NN` = neueste zuerst, `JN` = älteste zuerst). Laut
> Kommandoliste steuert sie **nur den Fettdruck**; die Reihenfolge steuert `invTime` in Position 8.

### d₁d₂d₃d₄ — Zeilenumbrüche (4 Zeichen)
Je Zeichen `N` kein Umbruch, `J` neue Zeile, `A` neuer Absatz, `2` Leerzeile: d₁ nach dem Sammelbezeichner,
d₂ nach dem Typbezeichner, d₃ nach jedem Karteieintrag, d₄ zwischen den Gruppen. Standard `NJ2N`.
Nach aktuellem Stand [ungeprüft]: Mit d₃ = `N` werden die Einträge mit „, “ verbunden; mit d₄ = `N` stehen die
Gruppen ohne Trenner hintereinander.

### e₁e₂e₃e₄ — Typbezeichner, Datum, Textumfang, Sammelbezeichner
e₁ Typbezeichner anzeigen (J/N); e₂ Datum je Eintrag anzeigen (J/N, `U` = mit Uhrzeit);
e₃ Textumfang (`N` ganzer Text, `0` kein Text, `1` erster Absatz, `2-3` Absätze 2 bis 3); e₄
Sammelbezeichner anzeigen (J/N; zusätzlich `D` = Datum als Überschrift je neuem Tag, `B` =
beides [ungeprüft]). Standard `JJNN`.

#### Datums-Flag-Kombinationen (empirisch, Referenzkorpus)

Aus dem produktiven Arztbrief-Korpus (28 x-Kommandos, Realtests 06–07/2026) sind zwei
Kombinationen der Slots e₁e₂e₃e₄ + f₁f₂f₃f₄ belegt:

| Kombination | Wirkung | Einsatz |
|---|---|---|
| `NJ22 NNND` | **Datum (TT.MM.JJJJ) wird je Eintrag vorangestellt** | datierte Verlaufs-/Befundblöcke (BEF, BEF_PHY, SONO, SCAN, T, THE, ANA, Heilmittel, BEH_AB, BEH) |
| `NNJN NNNN` | Ausgabe **ohne** Datum, kumulativer Einzelblock | DIA/DIAX, CAV, ALG, SOZ, SOZ_AB |

**Erklärung [ungeprüft]:** `NJ22` ist d₁–d₄ (Umbrüche), `NNND` ist e₁–e₄: kein Typname,
kein Datum je Eintrag, ganzer Text, **e₄ = `D` setzt das Datum als Überschrift einmal je neuem Tag** —
deshalb steht das Datum vor dem Eintrag. `NNJN NNNN` heißt: Umbrüche N, N, J, N und weder Typ noch Datum.

**Wichtig:** Die Kombination steuert **nur die Ausgabe**, nicht die Sortierung — die steuert `invTime` in
Position 8 (ohne `invTime` neueste zuerst). Ein undatierter Block kann also korrekt sortiert sein und
*trotzdem* kein Datum zeigen; das ist der klassische Fehlschluss beim Debuggen. Umstellung von
`NNJN NNNN` auf `NJ22 NNND` verändert die Reihenfolge **nicht**.

### f — Zusatzbedingungen (Position 8)
Mehrere Werte direkt aneinanderhängen (z. B. `invTimestripMed`). Groß-/Kleinschreibung zählt.

| Wert | Bedeutung |
|---|---|
| `_` | keine |
| `invTime` | zeitlich **aufsteigend** sortieren |
| `arztname` | mit Arztnamen |
| `_nutzer` | nur vom aktiven Nutzer angelegte Einträge |
| `_betriebsstaette` | nur in der genutzten Betriebsstätte angelegte Einträge |
| `scheinDiagnosen` | Diagnosen vom Schein |
| `mitErlaeuterung` | Diagnosen mit Erläuterung |
| `mitICD` / `ICDvorn` / `ohneICD` | ICD-Code anhängen / voranstellen / weglassen (nicht kombinieren) |
| `nurAktiveDiagnosen`, `anamnestischeDiagnosen`, `auchAbgesetzteDiagnosen`, `nurInaktiveDiagnosen` | Diagnosenauswahl (nicht kombinieren) |
| `stripMed` | nur Medikamente aus dem Karteieintragstext |
| `diagAlsKe` | Diagnosen wie andere Karteieinträge auslesen |
| `ddiAlter` | Zeitfilter auch auf Dauerdiagnosen anwenden |

Nach aktuellem Stand [ungeprüft]: Die Kommandoliste schreibt `ICDVorn` und `auchabgesetzteDiagnosen`; wirksam sind
nur `ICDvorn` und `auchAbgesetzteDiagnosen`. `-mitICDCodes` enthält `mitICD` und schaltet deshalb auf „ICD
anhängen“. `invTime` sortiert **vor** dem Anzahl-Deckel — mit `b₁ = n` und `invTime` kommen die **n ältesten**.

### g₁ — Anhänge (Position 9)
| Wert | Beschreibung |
|---|---|
| `U` | Anhänge untereinander (Standard) |
| `N` | Anhänge nebeneinander |
| `K` | keine Anhänge |
| Zusatz `F`, `D`, `V` | auch Formulare, DOCX-Dokumente, Perzentile (z. B. `UFVD`) |

### g₂ — Anhangbreite (Position 10)
`_` = keine feste Breite, Zahl = Breite in cm (z. B. `10` oder `10.25`). Ein Trennzeichen-Parameter existiert
nicht; Trenner ergeben sich aus d₃/d₄.

### Ablauf [ungeprüft]
1. Einträge laden, neueste zuerst; mit `invTime` aufsteigend.
2. Nach den Gruppen in a aufteilen (Reihenfolge wie in a).
3. Zeitfilter, dann Nutzer-/Betriebsstättenfilter.
4. **Danach** den Anzahl-Deckel anwenden, **je Gruppe**: bei `A,B,C` bekommt jeder Typ einen eigenen Deckel,
   einen gemeinsamen nur `(A;B;C)`.

Diagnosen (ohne `diagAlsKe`) werden nach der manuellen Diagnosenreihenfolge sortiert, nicht nach Datum. Ohne
Diagnosen-Option kommen aktive und anamnestische Diagnosen. **Akutdiagnosen gelten ohne Zeitfilter nur im
laufenden und im Vorquartal als aktiv** (oder auf offenem Schein/offener Rechnung, oder manuell nicht
abgesetzt); mit Zeitfilter gelten alle nicht abgesetzten im Fenster als aktiv. Für alle Diagnosen
`auchAbgesetzteDiagnosen` angeben.

## Praxis-Beispiele

```

**ICD-Code-Ausgabe: ICDvorn in Position 8 (f), NICHT UD.** Beim x-Kommando steuert das
Zusatzbedingungs-Feld (f, frühere Fassungen nannten es g₁) die ICD-Voranstellung. Korrekt ist das Spezialformat
`ICDvorn` (ggf. aneinandergehängt mit `nurAktiveDiagnosen` ->
`ICDvornnurAktiveDiagnosen`). `UD` an dieser Position gibt KEINEN Code aus.
Validiertes Diagnose-Kommando (aktive Diagnosen mit Code, 4 Quartale):
`$[x DIA,DIAX _ _ 4q NN NNJN NNNN ICDvornnurAktiveDiagnosen U _]$`
Mit [Testen] an einem Patienten mit echt ICD-codierter Diagnose verifizieren
(Testdaten ohne Code maskieren den Fehler).

> **Berichtigt (Oktober 2026):** `Nq` ist in der Beschreibung des x-Kommandos dokumentiert
> (`1q` = höchstens ein Quartal) und steht in Position 4 (b₃). `4q` = aktuelles + 4 Vorquartale, bezogen
> auf das Datum der Tagesliste. Steht die Tagesliste auf einem alten Datum, beginnt das Fenster entsprechend
> früh [ungeprüft].
>
> **Hinweis zum `4q` (frühere Fassung):** Quartalsfenster (`4q`, `5q`) sind in der Argumentreferenz
> **nicht dokumentiert**; `4q` hat hier empirisch gegriffen. Das Kommando ist als Ganzes
> validiert, der Zeitfilter aber die fragile Stelle — bei „Export endet in einem alten Jahr"
> Arg 3 auf `_` stellen und die Menge stattdessen über den Anzahl-Cap in Arg 2 begrenzen
> (siehe `SKILL.md` → „x-Kommando: Auswahl-Fenster").

### Diagnose-Kommando: zwei stille Luecken (Realbefund 28.08.2026)

Das oben als validiert dokumentierte Diagnose-Kommando **zieht `DDI` nicht — Dauerdiagnosen
fehlen vollstaendig**, und es unterdrueckt abgeschlossene Diagnosen. Beide Luecken sind
**stumm**: die Ausgabe sieht vollstaendig aus.

Gefahrene Fassung im Arztbrief-Korpus (v25 bis v26.1):

```
$[x DIA,DIAX _ _ _ NN NNJN NNNN ICDvornnurAktiveDiagnosen U _]$
```

**Luecke 1 — Typliste.** `DDI` (Dauerdiagnosen) ist nicht enthalten. In der Praxis der Referenzinstallation werden
die beiden fuer den Arztbrief tragenden Diagnosen `F45.41` und `R52.2` **regelhaft als
Dauerdiagnose** gefuehrt. Sie fehlen damit in **jeder** Ausgabe, ohne dass etwas darauf
hindeutet. Wer die Diagnosenliste eines Patienten vollstaendig braucht, muss `DDI` mitziehen —
oder in einem zweiten Kommando separat abfragen.

**Erklärung [ungeprüft]:** Ohne Zeitfilter gelten Akutdiagnosen, die älter als das
Vorquartal sind, als **inaktiv** — auch **ohne** `nurAktiveDiagnosen` (Standard = aktive und anamnestische
Diagnosen). Die DIA vom 15.10.2025 fehlte deshalb. Mit `4q` gelten alle nicht abgesetzten Diagnosen im
Fenster als aktiv; deshalb zeigte die `4q`-Fassung mehr. `nurAktiveDiagnosen` entfernt zusätzlich nur die
anamnestischen Dauerdiagnosen. Wer alle Diagnosen braucht, setzt `auchAbgesetzteDiagnosen`.

**Luecke 2 — `nurAktiveDiagnosen` filtert mehr als erwartet.** Arg 2 (Anzahl-Cap) und Arg 3
(Zeitfenster) stehen hier auf `_`. Es gibt also **weder Deckel noch Zeitfilter**; der einzige
wirksame Filter ist das Ausgabeformat. Fehlt eine kodierte Diagnose in der Ausgabe, ist sie
**abgeschlossen**, nicht verdraengt. Realfall: eine `DIA`-Diagnose vom 15.10.2025 erschien
nicht, waehrend aeltere und neuere Eintraege derselben Region erschienen.

**Diagnostisches Vorgehen — in dieser Reihenfolge:**

1. **Erst die Argumentbelegung lesen, dann Hypothesen bilden.** Steht Arg 2 auf `_`, ist ein
   Anzahl-Deckel als Ursache ausgeschlossen; steht Arg 3 auf `_`, ein Zeitfenster ebenso. Diese
   Pruefung kostet einen Blick und schliesst zwei von drei Hypothesen aus. Im Realfall lief die
   Deckel-Hypothese ueber zwei Sessions, weil dieser Blick nicht getan wurde.
2. **Dann die Typliste** gegen die tatsaechlich verwendeten Diagnose-Karteieintragstypen.
3. **Zuletzt das Ausgabeformat.**

**Korrekturkandidat, `[Testen]` noch offen:**

```
$[x DIA,DIAX,DDI _ _ _ NN NNJN NNNN ICDvornnurAktiveDiagnosen U _]$
```

Zwei Vorbehalte, beide vor dem Produktivsetzen zu pruefen: ob `DDI` fuer das x-Kommando ein
gueltiger Typ ist, und ob `nurAktiveDiagnosen` Dauerdiagnosen als aktiv fuehrt. Nach aktuellem Stand ist
`DDI` gültig, und nicht abgesetzte Dauerdiagnosen gelten als aktiv [ungeprüft]. Ebenso
gilt der Deckel bei `DIA,DIAX,DDI` **je Typ**, nicht für die Vereinigung [ungeprüft] — die folgende
Warnung trifft dann nur auf die Schreibweise `(DIA;DIAX;DDI)` zu. **Und die
Warnung aus dem Anzahl-Cap-Abschnitt gilt hier doppelt:** sobald Arg 2 einen Deckel traegt,
gilt er fuer die **Vereinigung** der drei Typen — die zahlreichen `DIA`-Eintraege verdraengen
dann genau die drei `DDI`-Zeilen, um die es ging. Bei gesetztem Deckel deshalb **zwei
getrennte Kommandos** mit eigenen Deckeln.

# Aktuellste AU-Bescheinigung im aktuellen Quartal:
$[x AU 1 _ aq NN NNNN NNNN _ K 0]$

# In der Kartei selektierter AU-Eintrag:
$[x AU _ sel _ NN NNNN NNNN _ K 0]$

# Alle aktiven Dauerdiagnosen:
$[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$

# Alle ICD-Codes aus Diagnosen und Dauerdiagnosen, in einer Gruppe mit „, “ verbunden
# (frühere Fassung `DIA+DDI` liefert leer, weil `+` nicht ausgewertet wird) [ungeprüft]:
$[x (DIA;DDI) _ _ _ NN NNNN NNNN ICDvorn K _]$
```

**Praxis-Tipp:** Das x-Kommando hat einen eigenen **Konfigurator** unter Admin → Kommandos → Konfiguratoren → x, der alle Parameter per Dropdown auswählbar macht. Erstellte Kommandos können als "gespeicherte Platzhalter" wiederverwendet werden.

---
---

# Erweiterte Patterns: UND/ODER-Verknüpfung von Bedingungen

## UND-Verknüpfung (if_then + if)

```
$[if_then kommando1 wert1 if kommando2 wert2 Ausgabe]$
```

Prüft: Kommando1 == wert1 **UND** Kommando2 == wert2 → gibt "Ausgabe" aus.

Nach aktuellem Stand [ungeprüft] klappt diese Kurzform nur mit Kommandos **ohne** eigene Argumente (ohne Operator
gilt das erste folgende Wort als Vergleichswert). Mit Argumenten Operatoren angeben:
`$[if_then K1 a1 zs_equals w1 if K2 a2 zs_equals w2 Ausgabe_mit_Leerzeichen]$`.

## ODER-Verknüpfung

Kann über Kombination aus einfachem if-Kommando und score-Kommando realisiert werden, oder über verschachtelte if-Kommandos.
Für **ein** Kommando ist der einfachste Weg mehrere Paare mit derselben Ausgabe:
`$[if K zs_equals a X b X]$` (der erste Treffer gewinnt).

## Verschachtelung von Kommandos (if_then statt if)

**Wichtig:** Wenn das Ergebnis eines if-Vergleichs ein **anderes Kommando** ausführen soll (nicht einfach einen Text ausgeben), muss `if_then` statt `if` verwendet werden:

```
# Im if geht es auch, wenn das zweite Kommando als ${…}$ im Ausgabewert steht [ungeprüft].
# FALSCH — gibt den Kommando-Text als String aus statt ihn auszuführen:
$[if karteiEintragWert TAPP ... zs_not_equal <leer> karteiEintragWert TAPP ...]$

# RICHTIG — führt das zweite Kommando aus:
$[if_then karteiEintragWert TAPP customKarteiEintragEntries.vOPS2 _ D-1t zs_not_equal <leer> karteiEintragWert TAPP customKarteiEintragEntries.vOPS2-Text _ D-1t]$
```

---
---

# Weitere Konfiguratoren (Kurzreferenz)

## a — Anrede-Platzhalter

Geschlechtsabhängiger Anrede-Platzhalter für Briefe. Fallunterscheidung nach Empfänger und Geschlecht.

```
$[a <Text1> <Text2> … <Text24>]$
```

Berichtigt [ungeprüft]: bis zu **24** Argumente je Empfängertyp und Geschlecht — 1 Brief an
Patientin, 2 an Patient, 3–6 Hausarzt (Ärztin/Arzt × Patientin/Patient), 7–10 sonstiger Arzt, 11–12
Apotheke/BG/Kasse/Pflegeheim/sonstige, 13–16 Folgearzt, 17–20 Überweiser, 21–24 Familienmitglied. `_` oder
fehlend = Standardanrede aus den Einstellungen „Anreden für a-Kommando“. Leerzeichen innerhalb durch `_`
ersetzen. Funktioniert **nur in DOCX-Briefvorlagen** (frühere Fassung: `<männlich> <weiblich> <unbekannt>`).

## lab — Laborwerte (Kurzform)

Laborwerte aus dem Reiter Medizinische Dokumentation. Optionen zum Eingrenzen (mit
Bindestrich [ungeprüft]):
- `-nurKuerzel` — nur bestimmte Testkürzel
- `-ohneKuerzel` — bestimmte ausschließen
- `-nurGruppen` — nur bestimmte Gruppen
- `-ohneGruppen` — bestimmte Gruppen ausschließen
- `-nichtleer` — nur Tests mit Ergebnis

## labor — Laborwerte (Tabelle)

Erzeugt eine Tabelle aus den ausgewählten Laborwerten. Für den Druck in Briefvorlagen; läuft nur in
DOCX-Briefvorlagen. Argumente: Spaltenkürzel, Spaltennamen, Spaltenbreiten (gleich viele Teile) [ungeprüft].

## laborwert — Einzelne Laborwerte

```
$[laborwert <KE-Kürzel oder _> <Testident> <Format> <Auswahlmodus> <Trennsequenz>]$
```

Mindestens 4 Parameter. Gibt Informationen zu einem oder mehreren Laborwerten mit dem gleichen Testkürzel aus.
Berichtigt nach der Beschreibung in der Kommandoliste: Das **erste** Argument ist das Kürzel des
Karteieintrags (`_` = egal), dann Testident (Leerzeichen weglassen), Format, Auswahlmodus (`J` letzter
selektierter, `N` letzter Karteieintrag, `L` letzter Test des Kürzels, `<Zahl>` die letzten n Werte mit
optionalem Trenner, `E<Zahl>` nur der n-tletzte, `AQ`/`AQ-n`). Formatplatzhalter u. a. `%k` Kürzel, `%w` Wert,
`%e` Einheit. Beispiel: `$[laborwert LAB QUICK %w_%e J]$`.

## letzteLaborwerte — Alle Werte des letzten Befundes

```
$[letzteLaborwerte <Format> <Trennsequenz> <AlterInTagen>]$
```

Format verwendet dieselben Platzhalter wie `laborwert`. Trennsequenz Standard: `", "`. Optionales 3. Argument: Alter in Tagen um alle Befunde bis zu diesem Alter zu berücksichtigen.
Berichtigt: Die früheren Beispiele mit `%@` waren falsch übernommen (`%@` ist kein Platzhalter). Standardformat
`%k_%w_%e` [ungeprüft].

### Beispiele

```
# Alle Laborwerte des letzten Befundes (Kürzel Wert Einheit, Zeilenumbruch):
$[letzteLaborwerte %k_%w_%e \\n]$

# Laborwerte der letzten 7 Tage (Kürzel: WertEinheit, Komma):
$[letzteLaborwerte %k:_%w%e ,_ 7]$
```

## medikamentenplan — Medikamenten-Tabelle

Erzeugt eine Tabelle mit dem aktuellen Medikamentenplan. Als Parameter werden gewünschte Spaltenkürzel angegeben (gleiche Kürzel wie `tab_med_*` Tabellen-Kommandos).
Nach aktuellem Stand [ungeprüft]: nur in DOCX-Briefvorlagen; Argumente Spaltenkürzel, Spaltennamen, Spaltenbreiten.

## impfstatus — Impftabelle

Erzeugt eine Tabelle mit dem aktuellen Impfstatus. Nur in DOCX-Briefvorlagen und nur mit
aktiviertem ImpfDoc; optionale Argumente Spalten, Spaltennamen, Spaltenbreiten, Krankheiten [ungeprüft].

```
$[impfstatus]$
```

## dmp — DMP-Daten

Liest Informationen aus einer DMP-Dokumentation aus. Verwendet den Konfigurator für Parameter-Auswahl.
Genau zwei Argumente: Quartal (`0`–`4`, `a` oder `l`) und Parametername [ungeprüft].
