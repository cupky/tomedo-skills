# Konfiguratoren & Steuerkommandos — Vollständige Syntax-Referenz

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Thema → Steuerkommando + Konfiguratoren).
Stand: März 2026.

Steuerkommandos sind **kontextunabhängige** Kommandos (Kontext: "ohne"), die andere Kommandos manipulieren, vergleichen, formatieren oder bedingt ausführen. Sie bilden die "Programmiersprache" innerhalb des Kommandosystems.

---

## Übersicht: 14 Konfiguratoren

| Konfigurator | Hauptzweck | Praxisrelevanz |
|---|---|---|
| **if** | Bedingte Auswertung mit Operatoren | ⭐⭐⭐ Kernbaustein |
| **if_then** | Bedingte Ausführung eines Folgekommandos | ⭐⭐⭐ |
| **d** | Diagnose-Kommando | ⭐⭐⭐ |
| **karteiEintragWert** | Werte aus Karteieinträgen | ⭐⭐⭐ |
| **formularEintrag** | Werte aus Patientenformularen | ⭐⭐⭐ |
| **KeyPath** | Direktzugriff auf Datenmodell | ⭐⭐⭐ |
| **x** | Komplexes Karteieintrags-Auslese-Kommando | ⭐⭐ |
| **regex** | Reguläre Ausdrücke auf Kommando-Ergebnisse | ⭐⭐ |
| **a** | Anrede-Platzhalter (geschlechtsabhängig) | ⭐⭐ |
| **lab** | Laborwerte (Kurzform) | ⭐⭐ |
| **labor** | Laborwerte (Langform/Tabelle) | ⭐⭐ |
| **Leistungen** | Leistungskommandos | ⭐⭐ |
| **medikamentenplan** | Medikamentendaten | ⭐ |
| **dmp** | DMP-Daten | ⭐ |
| **impfstatus** | Impfstatus-Tabelle | ⭐ |

---

## if — Bedingte Auswertung

### Kernkonzept
Führt ein Kommando aus, vergleicht das Ergebnis gegen beliebig viele Werte und gibt je nach Treffer einen alternativen Text aus.

### Syntax

```
$[if <auszuführendes Kommando> <arg1> <arg2> ... <argN> <Operator> <Vergleichswert1> <Alternativwert1> <Vergleichswert2> <Alternativwert2> ... <Rückfallwert>]$
```

Dabei sind `<arg1>` bis `<argN>` die Parameter des auszuführenden Kommandos, sofern vorhanden.

### Operatoren

| Operator | Beschreibung | Hinweis |
|---|---|---|
| `zs_equals` | Test auf Gleichheit | |
| `zs_not_equal` | Test auf Ungleichheit | |
| `zs_contains` | enthält | |
| `zs_not_contains` | enthält nicht | |
| `zs_less_than` | kleiner als | nur für Zahlen und Datum |
| `zs_greater_than` | größer als | nur für Zahlen und Datum |

### Sonderwert `<leer>`

Um gegen die **leere Zeichenkette** zu testen, wird `<leer>` als Vergleichswert verwendet. Möchte man gegen die leere Zeichenkette testen, so ist `<leer>` als Vergleichswert anzugeben. Optional kann als letztes Argument ein Rückfallwert angegeben werden, der ausgegeben werden soll, falls das auszuführende Kommando keinen der angegebenen Vergleichswerte geliefert hat. Soll dafür das Ergebnis des ursprünglichen Kommandos verwendet werden, so ist `XXX` als Rückfallwert anzugeben.

### Ersetzungsregeln in Vergleichs-/Ausgabewerten und Rückfallwert

| Zeichen im Kommando | Wird ersetzt durch |
|---|---|
| `_` (Unterstrich) | ` ` (Leerzeichen) |
| `.` (Punkt) | `\t` (Tabulator) |
| `"` | `"` |
| `<Zeilenumbruch>` | `\n` |

### Alternative Syntax (Abwärtskompatibilität)

```
$[if <auszuführendes Kommando> { <arg 1> <arg 2> ... <arg n> } <Operator> <Vergleichswert 1> <Alternativwert 1> <Vergleichswert 2> <Alternativwert 2> ... <Rückfallwert>]$
```

Alternativ können Vergleichswerte, alternative Ausgabewerte und der Rückfallwert auch durch **Hochkommata** (`'`) eingerahmt werden, ohne dass Ersetzungen gemacht werden müssen. In den Vergleich- und Alternativwerten können auch Platzhalter in der üblichen Syntax verwendet werden.

Kann das angegebene auszuführende Kommando **nicht als Platzhalter aufgelöst** werden, so wird es selbst zum Vergleich verwendet. Dies ist beispielsweise sinnvoll, um mittels if-Kommando Karteieintragstexte oder Vorbefüllungen von CustomKarteieinträgen anzupassen.

### Beispiele

```
1) Das Kommando pt liefert den Titel des Patienten. Möchte man im Titel des Patienten 
   die üblicherweise abgekürzten Titel "Dr." und "Prof." durch die ausgeschriebenen 
   ersetzen, wobei alle anderen Titel belassen werden sollen, wählt man das Kommando:
   $[if pt Dr. Doktor Prof. Professor 'Prof. Dr.' 'Professor Doktor' XXX]$

   alternativ geht auch:
2) $[if pt Dr. Doktor Prof._Dr. Professor_Doktor XXX]$

3) $[if karteiEintragWert custom customKarteiEintragFeldwss variablenName %@ J zs_equals wert1 alternativwert1 alternativwert2]$

4) Als Vorbefüllung eines Custom-Karteieintrag-Feldes vom Typ "Text zusammengesetzt nicht editierbar" 
   mit Referenz auf ein Feld mit Variablenname "Feldname":
   $[if $[Feldname]$ zs_equals Wert1 Text_bei_Wert1 Text_sonst]$

5) Als Vorbefüllung eines Custom-Karteieintrag-Feldes vom Typ "Text zusammengesetzt nicht editierbar" 
   mit Referenz auf ein Feld mit Variablenname "Feldname" vom Typ Mehrfachauswahl:
   (Feldname liefert kommaseparierte Auswahl)
```

---

### Praxis-Lessons 06/2026: Leerfeld-Guard, Bezeichner-Quoting, Träger-Auflösung

> **⚠️ Punkt 1 dieses Abschnitts ist WIDERRUFEN** — siehe „Korrektur 06/2026: Leerfeld-Guard
> funktioniert NICHT" direkt unterhalb. Punkte 2 und 3 gelten unverändert. Wer nur diesen
> Abschnitt liest, wendet sonst eine im Realtest gescheiterte Regel an.

**1 · Leerfeld-Guard-Idiom (E3-Unterdrückung) — ⚠️ WIDERRUFEN, NICHT VERWENDEN.** Zeile nur ausgeben, wenn das Feld
nicht leer ist — Label INNERHALB des Guards, damit bei leerem Wert die ganze Zeile
verschwindet:
```
$[if <KMD> zs_not_equal <leer> 'Label: XXX' '']$
```
`XXX` = Ergebnis des inneren Kommandos (Rückfallwert). Leeres Feld → `''` → Leerzeile
(kosmetisch). Funktioniert mit `formularEintrag` und (nested) `x`.

**2 · Bezeichner mit Leerzeichen/Klammern → single-quote-wrappen.** Bei `formularEintrag`
gilt exakter Feldnamen-Match (keine `_`→Leerzeichen-Umwandlung). Feldnamen MIT echtem
Leerzeichen/Klammer (`momentaner Status`, `Rentenart (zeitlich)`) müssen single-quote-
umschlossen werden: `'momentaner Status'`. Die Quotes halten das Leerzeichen zusammen
UND geben dem if-Parser eine saubere Token-Grenze (sonst zählt er die Parameter falsch).
Gegenprobe: reine Unterstrich-/Bindestrich-Bezeichner (`aff_Skala`, `personen-im-haushalt`)
NICHT quoten (Quotes gingen in die Feldsuche ein → leer).

**3 · Träger-Auflösung verifiziert (2026-06-19).** Briefkommandos lösen nicht nur in
Briefvorlagen auf, sondern auch **beim Einfügen eines Textbausteins in einen
Karteieintrag** und in der **Vorbefüllung eines Custom-Karteieintrags** — inkl.
komplexer `x`- und `if`-Kommandos. Ermöglicht Export per Textbaustein-Kürzel +
Copy-Paste ohne Brief-Dialog/Datei.

> Nesting-Hinweis: Mehr-Token-`x` im `if` ist die fragilste Stelle. Bei Bruch inneres
> Kommando im jeweiligen Konfigurator als gespeicherten Platzhalter ablegen und im
> if-Konfigurator wickeln; `[Testen]` vor Live.

### Korrektur 06/2026: Leerfeld-Guard funktioniert NICHT — „immer drucken"

**Widerruf der Guard-Empfehlung.** Das Idiom `$[if <feldcmd> zs_not_equal <leer> 'Label: XXX' '']$`
wertet im **Textbaustein-Träger / CKE-Vorbefüllung NICHT aus** — im Echtexport (4 Patienten,
06/2026) erschien das Platzhalter-Literal `XXX` wörtlich im Output (MPSS, SONO, BEF_PHY,
GdB, kompletter Sozialblock). Einfaches `formularEintrag`/`x` OHNE if liefert dagegen
zuverlässig (Beleg: Krankenhaus-Zeilen, `allergien K`, alle Skalarfelder).

→ **Regel:** Felder im Textbaustein-Export IMMER roh ausgeben („Maximalversion"). Leere
Felder hinterlassen eine wertlose „Label:"-Zeile — die wird im nachgelagerten
LLM-Schritt entfernt. Keine Leerfeld-Unterdrückung am Briefkommando.

**WICHTIGE Differenzierung — was funktioniert:**
- `if … zs_contains <muster> <wert> …` über `formularEintrag` läuft einwandfrei
  (Matrix-NAS-Mapping `ZeileN=SpalteM`, validiert) — der Fehler liegt NICHT an `if`
  generell, sondern am `zs_not_equal <leer>`-Vergleich mit `XXX`-Rückfall.

### Boolean → ja/nein per zs_contains (validiert 06/2026)
PatF-Boolean-Felder liefern roh `true`/`false`. Saubere Klartext-Ausgabe:
```
$[if formularEintrag <Formular> <bez> <sel> zs_contains true ja false nein]$
```
Im Textbaustein-Träger zuverlässig (4-Patienten-Test). Leeres Feld → leer. Betrifft u.a.
`schmerzereignis`, `regelmäs-med`, `Blutverdünner`, `allergien`, `rf`, alle
Komorbiditäts-Flags (`nerv`/`herz`/…), `kids`, `rente`, `gdb`, `schmerzabnahme`.
Zahlenfelder (z.B. `kidsn` = Anzahl Kinder) NICHT mappen.

## if_then — Bedingte Ausführung eines Folgekommandos

### Kernkonzept
Führt ein Kommando aus, vergleicht das Ergebnis mit einem Vergleichswert. Bei positivem Vergleich wird ein **anderes** Kommando ausgeführt. Die Syntax ist analog zum if-Kommando (ohne Hochkomma-Notation und ohne Platzhalter im Vergleichswert) mit dem Unterschied, dass nur ein Vergleichswert angegeben wird, gefolgt vom auszuführenden Kommando (und möglicherweise zusätzlichen Parametern dieses Kommandos).

### Syntax

```
$[if_then <Kommando 1> <argK1-1> <argK1-2> ... <Operator> <Vergleichswert> <Kommando 2> <argK2-1> <argK2-2> ...]$
```

Das Ergebnis des ersten Kommandos kann auch per `XXX` als Argument an das auszuführende Kommando übergeben werden. Dadurch erreicht man gewissermaßen eine Verschachtelung von Platzhaltern.

---

## regex — Reguläre Ausdrücke

### Kernkonzept
Extrahiert einen Teil des Ergebnisses eines Platzhalters mittels Regular Expression.

### Syntax

```
$[regex <RegularExpression> <Kommando> <arg1> <arg2> ...]$
```

- Erstes Argument: Regular Expression (ohne Leerzeichen)
- Danach: Kommando mit beliebig vielen Parametern
- Ausgabe: Inhalt der **ersten Gruppierung** (durch runde Klammern eingerahmter Bereich), falls eine Gruppierung angegeben wurde
- Ansonsten: erster Treffer des Ausdrucks insgesamt
- Kein Treffer: leeres Ergebnis der Länge Null

### Optionen

| Option | Beschreibung |
|---|---|
| `-anzahlTreffer <Anzahl>` | Um mehrere Treffer auszugeben, standardmäßig wird nur der erste ausgegeben. `'inf'` um alle Treffer auszugeben |
| `-trennsequenz <Trennsequenz>` | Um die Treffer getrennt durch `<Trennsequenz>` auszugeben, Standard ist `', '` |
| `-nurAnzahl` | Um nur die Anzahl der Treffer auszugeben |

### Beispiele

```
1) Angenommen, im letzten Karteieintrag mit Kürzel 'test' wollen Sie das erste 
   Vorkommen von 'abc:' zusammen mit den 5 nachfolgenden Zeichen auslesen:
   $[regex abc:.{5} x test]$

2) Wie Beispiel 1), nur dass Sie 'abc:' nicht mit ausgeben möchten, sondern nur 
   die 5 Zeichen danach:
   $[regex abc:(.{5}) x test]$

3) Angenommen, Sie wollen aus dem letzten Karteieintrag mit Kürzel 'test' ein Datum 
   auslesen, das dort im Format dd.MM.yyyy steht, wollen aber die Jahr-Komponente 
   weglassen. Das geht mit:
   $[regex ([0-9]{2}.[0-9]{2}).[0-9]{4} x test]$
```

---

## score — Berechnungen

### Kernkonzept
Führt mathematische Berechnungen aus: Addition, Multiplikation, Subtraktion, Division, Maximum, Minimum, u.a.

### Syntax
(Keine detaillierte Syntax im Screenshot sichtbar — Konfigurator-UI verwenden)

---

## bereich — Teilstring-Extraktion

### Kernkonzept
Gibt das Ergebnis eines Kommandos in einem definierten Bereich bezüglich der Zeichenanzahl aus.

### Syntax

```
$[bereich <Index>,<Länge> <Kommando>]$
```

### Beispiele

```
Angenommen, das Kommando test gibt "abcdef" aus. Dann liefern:
$[bereich 0,2 test]$  → ab
$[bereich 1,4 test]$  → bcde
```

---

## ersetze — Text-Ersetzungen

### Kernkonzept
Text-Ersetzungen im Ergebnis eines Platzhalters.

### Syntax

```
$[ersetze a1 b1 a2 b2 ... an bn zs_in <Platzhalter>]$
```

Dabei wird der angegebene Platzhalter ausgeführt und im Ergebnis werden die Ersetzungen a1→b1, a2→b2, ..., an→bn vorgenommen.

**Achtung!** Bei den einzelnen Ersetzungs-Parametern müssen bestimmte Zeichen anders kodiert werden (siehe Hilfe-Button).

### Beispiel

```
$[ersetze _\n_ zs_in x abc]$
```

---

## kommandorahmen — Bedingter Textrahmen

### Kernkonzept
Wenn ein Kommando ein nicht-leeres Ergebnis liefert, wird es mit Präfix- und Suffix-Text umrahmt. Wenn das Ergebnis leer ist, wird nichts ausgegeben.

### Syntax

```
$[kommandorahmen <Kommando> <arg1> ... <Präfix-Text> <Suffix-Text>]$
```

- `\n` erlaubt Zeilenvorschub
- `_` wird als Leerzeichen gewertet
- Soll kein Text vorangestellt werden: als Präfix `"<leer>"` übergeben

### Beispiel

```
$[tab_kommandorahmen tab_pr_begruendung \nDie_Begründung:\n Hier_endet_die_Begründung]$
→ Falls eine Begründung in der Privat-Leistung vorhanden ist, fügt dieses Kommando 
  einen Zeilenvorschub, den Text "Die Begründung:" und einen weiteren Zeilenvorschub 
  vorne ein. Und nach der Begründung wird der Text "Hier endet die Begründung" angefügt.
```

---

## kommandovergleich — Zwei Kommandos vergleichen

### Kernkonzept
Testet ob zwei Kommandos das gleiche Ergebnis liefern. Besonders sinnvoll in Kombination mit dem if- oder dem if_then-Kommando.

### Syntax

```
$[kommandovergleich <Kommando1> { <args1> } UND <Kommando2> { <args2> }]$
```

Die Argumente sind: das erste Vergleichskommando, dann die Trennsequenz `"UND"` und anschließend das zweite Vergleichskommando.

- **Gleichheit:** Ergebnis `"1"`
- **Ungleichheit:** Ergebnis `"0"`

### Beispiel

```
$[if_then kommandovergleich { abrechnenderArzt_name } UND { abrechnenderArzt_name } 1 ...]$
```

---

## abZeichen / bisZeichen — Substring-Extraktion

### abZeichen
Gibt das Ergebnis eines Kommandos **ab** dem n-ten Zeichen aus.

```
$[abZeichen <n> <Kommando> <args>]$
```

### bisZeichen
Gibt das Ergebnis eines Kommandos **bis** zum n-ten Zeichen aus.

```
$[bisZeichen <n> <Kommando> <args>]$
```

---

## ganzzahlAufrunden — Aufrunden

### Syntax

```
$[ganzzahlAufrunden <Zahl-oder-Platzhalter> <args...> <Vielfaches>]$
```

Es werden mindestens zwei Argumente benötigt: 1. Argument – eine ganze Zahl oder ein Platzhalter, der eine ganze Zahl liefert, ggf. gefolgt von Argumenten des Platzhalters; letztes Argument – eine positive ganze Zahl, auf deren Vielfache aufgerundet werden soll.

---

## vorKommaWert / nachKommaWert — Zahlen-Splitting

### vorKommaWert
Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis eine Gleitkommazahl enthält. Von dieser Zahl wird der Wert **vor** dem Komma genommen.

### nachKommaWert
Analog, aber der Wert **nach** dem Komma.

---

## ohneWaehrung — Währungszeichen entfernen

Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis einen Betrag mit Währung enthält. Davon wird der Betrag **ohne** Währungszeichen zurückgegeben.

---

## anzahlTabelleneintraege — Zählen in Tabellen

### Ohne Bedingung
```
$[anzahlTabelleneintraege]$
```
Anzahl der Einträge der Tabelle. Kann in allen internen Vorlagen zum Drucken einer Tabelle verwendet werden, auch in Statistik-Vorlagen.

### Mit Bedingung
```
$[anzahlTabelleneintraege mit <Bedingung>]$
```
Wie `anzahlTabelleneintraege`, allerdings mit einer Bedingung der Form `<Name der Tabellenspalte> = <Eintrag>`.

---

## zwischenablage — Clipboard-Zugriff

Gibt den Text aus der Zwischenablage aus, sofern vorhanden.

```
$[zwischenablage]$
```

---

## Tabellen-Varianten der Steuerkommandos

| Tabellen-Kommando | Text-Äquivalent | Hinweis |
|---|---|---|
| `tab_if` | `if` | Für Tabellenplatzhalter. Tabellenplatzhalter in den Alternativwerten funktionieren hier nicht! |
| `tab_if_then` | `if_then` | Für Tabellenplatzhalter |
| `tab_kommandorahmen` | `kommandorahmen` | Für Tabellenplatzhalter |

---
---

# selektierterTermin — Vollständige %-Ersetzungsreferenz

Das Kommando `selektierterTermin` (und die verwandten Kommandos `selektierteTermineErster`, `selektierteTermineLetzter`, `selektierteTermineListe`, `selektierteTermineMWU`, `selektierteTermineEinzahlMehrzahl`) verwenden ein eigenes Ersetzungssystem mit %-Platzhaltern.

## Grundlegende Termininfo-Platzhalter

| Platzhalter | Beschreibung |
|---|---|
| `%a` | Terminart (Kürzel) |
| `%A` | Terminart (Beschreibung) |
| `%anh` | Ob Termin Anhang hat (📎) |
| `%b` | Termin Zeit bis |
| `%c` | Terminlokalität (Kürzel) |
| `%cA` | Terminlokalität (Adresse der Betriebsstätte) |
| `%cB` | Terminlokalität (Beschreibung) |
| `%C` | Kalendername(n), kommasepariert |
| `%d` | Datum mit Zeit |
| `%doz` | Datum ohne Zeit |
| `%e` | Dokumentierender Nutzer (Kürzel) |
| `%ed` | Erstellungszeitpunkt |
| `%edoz` | Erstellungsdatum ohne Zeit |
| `%i` | Termininfo |
| `%G` | Geburtsdatum |
| `%k` | Kalendername(n) (Kürzel kommasepariert) |
| `%K` | Kassenname |
| `%l` | Terminlänge |
| `%L` | Lebensalter (relativ zum Termindatum) |
| `%M` | Vollname des Patienten (Titel Vorname Zusatz Nachname) |
| `%n` | Nutzername (vom Kalender des Termins) |
| `%N` | Nachname des Patienten |
| `%o` | Suchname |
| `%Ol` | Anbieter des Onlinetermins |
| `%p` | Privat/Gesetzlich (P oder G), für OTK-2 auch Selbstzahler/Berufsgenossenschaft (S oder B) |
| `%ps` | Bestands- oder Neupatient (B oder N) |
| `%P` | PatientenID |
| `%r` | Grund der letzten Verschiebung oder Löschung |
| `%s` | Erinnerungs-Status (✉️ + Versanddatum + Kreuz/Haken für jeden bisherigen Versuch und Anzahl an noch offenen Anfragen + ✉️ + –– für ausstehende Erinnerungen) |
| `%S` | Schwangerschaftswoche W+T |
| `%t` | Telefon |
| `%T` | Titel |
| `%u` | Nutzerkürzel (vom Kalender des Termins) |
| `%U` | Alle Nutzerkürzel (mit ,) |
| `%v` | Termin Zeit von |
| `%V` | Vorname des Patienten |
| `%w` | Termin Datum, Wochentag kurz |
| `%W` | Wiederholung (zeigt W wenn ja, sonst nichts) |
| `%x` | Termin Datum, Wochentag ausgeschrieben |
| `%Ü` | Übernachtung |

## Zeit-Varianten mit Vorlauf und Rundung

| Platzhalter | Beschreibung |
|---|---|
| `%vv` | Termin Zeit von mit Vorlauf |
| `%vr` | Termin Zeit von (gerundet auf 10 Minuten) |
| `%br` | Termin Zeit bis (gerundet auf 10 Minuten) |
| `%vvr` | Termin Zeit von mit Vorlauf (gerundet auf 10 Minuten) |
| `%vq` | Termin Zeit von (abgerundet auf Viertelstunde) |
| `%bq` | Termin Zeit bis (abgerundet auf Viertelstunde) |
| `%vvq` | Termin Zeit von mit Vorlauf (abgerundet auf Viertelstunde) |

### Rundungsregeln
- `%vr`, `%br`, `%vvr` runden die Minutenangabe auf volle **10 Minuten** ab (z.B. 14:13 → 14:10, 9:35 → 9:30)
- `%vq`, `%bq`, `%vvq` runden die Minutenangabe auf **Viertelstunden** (z.B. 11:14 → 11:00, 11:18 → 11:15)

### Zeitarithmetik
Bei `%d`, `%doz`, `%v` und `%b` können zusätzlich **Tage (d), Stunden (h) oder Minuten (m)** addiert oder subtrahiert werden:
- `%d+1d` — Datum + 1 Tag
- `%b+1h` — Endzeit + 1 Stunde
- `%v-15m` — Startzeit − 15 Minuten

### Vorherige-Zustand-Suffix `p`
Datums- und Kalenderangaben können um ein `p` verlängert werden, um bei **Terminbewegungen** den alten Zustand anzuzeigen. Diese Funktion gibt es nur bei Terminänderungsbenachrichtigungen und der Nutzung eines Briefkommandos der selektierteTermine-Familie.
- `%v` → `%vp` (vorheriger Startzeitpunkt)
- `%vv` → `%vvp` (vorheriger Startzeitpunkt mit Vorlauf)

## Platzhalter die Patientendetails erfordern

**Achtung:** Folgende Kommandos funktionieren im Allgemeinen nur mit geladenen Patientendetails. In der Briefschreibung werden diese nachgeladen, aber normalerweise **nicht** für die Anzeige im Kalenderfenster. Dies kann mit entsprechenden **Performanzeinbußen** in den praxisweiten Kalendereinstellungen aktiviert werden.

| Platzhalter | Beschreibung |
|---|---|
| `%B` | Behandelnder Arzt (Kürzel) |
| `%BN` | Behandelnder Arzt (Nachname) |
| `%BVN` | Behandelnder Arzt (voller Name) |
| `%EB` | Erstbehandler (Kürzel) |
| `%adrCtr` | Land (Patientenadresse) |
| `%adrCit` | Stadt (Patientenadresse) |
| `%adrStr` | Straße mit Hausnummer (Patientenadresse) |
| `%adrZip` | Postleitzahl (Patientenadresse) |
| `%g` | Anrede des Patienten (Herr/Frau) |
| `%h` | Anrede des Patienten in Langform (Sehr geehrter Herr/Sehr geehrte Frau) |
| `%formularlinks` | Erzeugt einen Link für die fälligen Patientenformulare |
| `%m` | E-Mail |
| `%z1` | Patientenspezifisches Ja/Nein Feld 1 |
| `%z2` | Patientenspezifisches Ja/Nein Feld 2 |
| `%z3` | Patientenspezifisches Text Feld 1 |
| `%z4` | Patientenspezifisches Text Feld 2 |
| `%z5` | Patientenspezifisches Text Feld 3 |
| `%z6` | Patientenspezifisches Text Feld 4 |

## %if — Bedingte Logik innerhalb von Termin-Platzhaltern

### Syntax

```
%if((<zu prüfender Text> <Operator> (<Vergleichswert1> <Ausgabewert1>) (<Vergleichswert2> <Ausgabewert2>) ... (<Rückfallwert>)))
```

### Operatoren
- `zsEquals` — Gleichheit
- `zsNotEqual` — Ungleichheit
- `zsContains` — Enthaltensein
- `zsNotContains` — Nicht-Enthaltensein

**Achtung:** Die Operatornamen in `%if` sind **anders geschrieben** als im `$[if]$`-Kommando! (`zsEquals` vs. `zs_equals`)

### Escape-Regeln
Runde Klammern, die nicht zur Parametertrennung gehören sondern als Text dargestellt werden sollen, mit `\` escapen.

### Beispiel

```
%if((%g) zsEquals ((Herr) (🚹)) ((Frau) (🚺)) (?))
```
→ Nimmt die Anrede `%g`, wandelt "Herr" in 🚹 um, wandelt "Frau" in 🚺 um und gibt sonst ein ? aus.

## Einschränkungen bei Terminerinnerungen

Bei Terminerinnerungen werden die Argumente `%L`, `%s` und `%S` derzeit **nicht** unterstützt.

---
---

# patientenTermine — Vollständige Parameter-Referenz

Das Text-Kommando `patientenTermine` gibt alle nicht gelöschten Termine des Patienten ab dem morgigen Tag aus (zeitlich aufsteigend). Folgende **Parameter** beeinflussen die Auswahl der Termine:

## Parameter

| Parameter | Beschreibung |
|---|---|
| `-abSofort` | Termine ab dem jetzigen Zeitpunkt ausgeben |
| `-vergangene` | bisherige Termine ausgeben |
| `-Zeitraum <Modus>` | Modus kann `AQ` sein für aktuelles Quartal oder `AJ` für das aktuelle Jahr. Auch Addition und Subtraktion sind möglich, also z.B. `AQ-1` für das letzte Quartal oder `AJ-1` für das letzte Jahr |
| `-heutige` | nur Termine von heute |
| `-Terminarten <Kürzel1>,<Kürzel2>,...` | nur Termine der aufgeführten Terminarten ausgeben |
| `-ohne_Terminarten <Kürzel1>,<Kürzel2>,...` | nur Termine OHNE die aufgeführten Terminarten ausgeben |
| `-Anzahl <Zahl>` | nur die ersten `<Zahl>` Termine ausgeben |
| `-position <Zahl>` | nur den so-vielen Termin ausgeben, falls vorhanden |
| `-ohneHaken` | ohne Haken bei abgearbeiteten Terminen |
| `-heilmittelTermine` | sucht nur die Termine heraus, die für Heilmittelerbringer mit einer Heilmittelverordnung verknüpft sind |

## Ersetzungsmuster

Die Ausgabe verwendet dieselben `%`-Platzhalter wie `selektierterTermin` (siehe oben): `%a`, `%A`, `%d`, `%v`, `%b`, etc.

## Beispiel

```
$[patientenTermine -abSofort -Anzahl 3 %d_-_%A_(%c)]$
```
→ Gibt die nächsten 3 Termine ab sofort aus, mit Datum, Terminart und Terminlokalität.

---
---

# selektierteTermineListe — Syntax

## Syntax

```
$[selektierteTermineListe <TerminParameter> <Trennzeichen>]$
```

Als `<TerminParameter>` funktionieren dieselben `%`-Platzhalter wie im Kommando `selektierterTermin`. Mit dem `<Trennzeichen>`-Parameter kann festgelegt werden, wie die Termininfos voneinander getrennt werden sollen. Ist kein Trennzeichen festgelegt, wird ein **Zeilenumbruch** als Trennzeichen verwendet. Innerhalb beider Argumente müssen Leerzeichen durch **Unterstriche** ersetzt werden.

## Beispiel

```
$[selektierteTermineListe %A,_%d,_-%b]$
```
→ Gibt alle selektierten Termine aus im Format: "Terminart, Datum mit Zeit, -Endzeit" getrennt durch Zeilenumbrüche.

---
---

# Alle Termin-bezogenen Kommandos (Thema: Termine)

Zusammenstellung aller Kommandos mit Thema "Termine" (aus Screenshot: Filter nach Themen → Termine):

## Text-Kommandos

| Name | Art | Param | Kontext | Beschreibung |
|---|---|---|---|---|
| aktuellerTerminInfofeld | Text | | Patient | Infofeld des heutigen Termins |
| datum | Text | | Kalendertag | Datum für ALLE Termine |
| druckdatum | Text | | Patiententermine | Datum und Uhrzeit des Druckens |
| kalender | Text | | Kalendertag | Name des Kalenders |
| name | Text | | Patiententermine | Voller Name des Patienten, Version 1 |
| patientenname | Text | | Patiententermine | Voller Name des Patienten, Version 2 |
| patientenTermine | Text | ✓ | Patient | Patiententermine (vollständige Parameter siehe oben) |
| selektierteTermineEinzahlMehrzahl | Text | ✓ | Terminerinnerung | Einzahl/Mehrzahl-abhängige Texte |
| selektierteTermineErster | Text | ✓ | Terminerinnerung | = selektierterTermin (erster Termin) |
| selektierteTermineLetzter | Text | ✓ | Terminerinnerung | Letzter selektierter Termin |
| selektierteTermineListe | Text | ✓ | Terminerinnerung | Alle selektierten Termine auflisten |
| selektierteTermineMWU | Text | ✓ | Terminerinnerung | Geschlechtsspezifische Texte (M/W/U) |
| selektierterTermin | Text | ✓ | Terminerinnerung | Informationen des selektierten Termins (%-Platzhalter) |
| terminArtBezeichnung | Text | | Patient | Terminart des heutigen Termins des aktuellen Patienten |

## Tabellen-Kommandos

| Name | Art | Kontext | Beschreibung |
|---|---|---|---|
| adresse | Tabelle | Patiententermine | Adresse der Betriebsstätte des Termins |
| beginn | Tabelle | Kalendertag | Beginn des Termins |
| behandler | Tabelle | Patiententermine | Verantwortlicher Behandler bzw. Arzt |
| datum | Tabelle | Patiententermine | Datum des Termins |
| ende | Tabelle | Kalendertag | Ende des Termins |
| gebdatum | Tabelle | Kalendertag | Geburtsdatum des Patienten |
| handy | Tabelle | Kalendertag | Handynummer des Patienten für Termin |
| info | Tabelle | Kalendertag | Freitext – Info für Termin |
| info | Tabelle | Patiententermine | Info des Termins |
| kalender | Tabelle | Patiententermine | Kalender des Termins |
| laenge | Tabelle | Patiententermine | Dauer des Arzt-Patienten-Kontaktes |
| patientenname | Tabelle | Kalendertag | Name des Patienten |
| patientennummer | Tabelle | Kalendertag | Patientennummer |
| plz | Tabelle | Kalendertag | PLZ des Patienten |
| strasse | Tabelle | Kalendertag | Straße des Patienten |
| tel | Tabelle | Kalendertag | Telefonnummer |
| terminart | Tabelle | Kalendertag | Terminart (Bezeichner) |
| terminart | Tabelle | Patiententermine | Terminart des Termins |
| todos | Tabelle | Kalendertag | ToDos des Termins |
| todos | Tabelle | Patiententermine | ToDos für den Termin |
| wochentag | Tabelle | Patiententermine | Wochentag des Termins |
| wochentagKurz | Tabelle | Patiententermine | Wochentag (Kurzform) |
| wohnort | Tabelle | Kalendertag | Wohnort des Patienten |
| zeit | Tabelle | Patiententermine | Uhrzeit des Termins |

---
---

# d — Das Datum-Kommando (Konfigurator)

## Kernkonzept
Vielseitiges Datum-Kommando für System-, Kartei-, Besuchs- und Karteieintragsdaten. Kann Daten formatieren, Offsets berechnen und auf verschiedene Zeitquellen zugreifen.

## Syntax

```
$[d <Arg1> <Arg2> <Arg3> <Arg4>]$
```

Kurzform:
```
$[d <STKBE>[Tage] <Format> [Letzter Karteieintrag]]$
$[d <STKBE>[Tage] [<SML><SML>] [Letzter Karteieintrag]]$
```

## Arg1 — Bestimmung des Datums

| Wert | Beschreibung |
|---|---|
| `S` | Systemdatum (aktuelles Datum/Uhrzeit) |
| `T` | Tageslisten-Datum (oben rechts im Fenster "Tagesliste") |
| `K` | Kartei-Datum (unten links in Kartei des Patienten) |
| `G` | Geburts-Datum |
| `B` | Datum des letzten Besuchs |
| `A` | Datum des aktuellen Besuchs (nur Radiologen-Modus) |
| `E` | Datum des letzten Karteieintrags. Braucht Arg3 (Karteieintragtyp) um Datum zu bestimmen. Optional kann der Index mit Arg4 angegeben werden: 0 für den ersten Eintrag, 1 für den zweiten, usw. -1 für den letzten, -2 für den vorletzten, usw. |
| `AE` | Datum des letzten Karteieintrags des aktuellen Besuchs (nur Radiologen-Modus). Braucht Arg3 (Karteieintragtyp) |
| `L` | Datum der letzten Leistung einer bestimmten Nummer. Braucht Arg3 (eine oder mehrere Nummern, kommasepariert). Soll nicht die letzte, sondern die vorletzte bzw. drittletzte Leistung genommen werden, so ist als Arg4 die Zahl 2 bzw. 3 usw. anzugeben |
| `LA` | Wie Modus "L", nur dass die Leistung nur vom aktuellen Schein/der aktuellen Rechnung genommen wird |
| `R` | Schwangerschaft: Datum letzte Regel |
| `U` | Schwangerschaft: Geburtstermin |
| `Tage` | Manipulation des Datums, auch negativ möglich. Zum Beispiel: `S-10` oder `T5` für Systemdatum minus zehn Tage bzw. Tageslistendatum plus fünf Tage |

## Arg2 — Formatierung des Datums

### Variante a: Custom-Format

Trennzeichen beliebig einsetzbar, zum Beispiel Punkt "." oder Doppelpunkt ":"

| Kürzel | Bedeutung |
|---|---|
| `q` | Quartal |
| `dd` | Tag |
| `M` | Monat |
| `yy` | Jahr 2-stellig |
| `yyyy` | Jahr 4-stellig |
| `HH` | Stunde |
| `mm` | Minute |
| `EEEE` | Wochentag |

#### Beispiele Custom-Format

| Format | Ergebnis (für 26.06.2015 15:15) |
|---|---|
| `dd.MM.yy` | 26.06.15 |
| `dd.MM.yyyy` | 26.06.2015 |
| `ddMMyy` | 260615 |
| `ddMMyyyy` | 26062015 |
| `HH:mm` | 15:15 |

### Variante b: SML-Format

Der erste Buchstabe steht für die Formatierung des **Datums**, der zweite Buchstabe steht für die Formatierung der **Zeit**:

| Kürzel | Bedeutung |
|---|---|
| `L` | Lange Formatierung |
| `M` | Mittlere Formatierung |
| `S` | Kurze Formatierung |
| `N` | Keine Angabe machen |

#### Beispiele SML-Format

| Format | Ergebnis |
|---|---|
| `SN` in `$[d S SN]$` | 26.06.15 |
| `MN` in `$[d S MN]$` | 26.06.2015 |
| `LN` in `$[d S14 LN]$` | 10. Juli 2015 |
| `LS` in `$[d B-7 LS]$` | 9. Juni 2015 19:23 |
| `SS` in `$[d S SS]$` | 26.06.15 15:15 |

## Arg3 — Karteieintragtyp (nur bei E, AE) oder Leistungsnummer (bei L, LA)

### Für Karteieintragtyp (Modus E/AE):

| Beispiel | Kommando | Beschreibung |
|---|---|---|
| ANA | `$[d E10 SS ANA]$` | Zeigt 10 Tage nach dem letzten ANA-Eintrag des Patienten |
| THE | `$[d E5 SS THE]$` | Zeigt 5 Tage nach dem letzten THE-Eintrag des Patienten |

### Für Leistungsnummer (Modus L/LA):

| Beispiel | Kommando | Beschreibung |
|---|---|---|
| 201A | `$[d L SN 201A]$` | Datum der letzten Leistung mit Nr. 201A |
| 35600,35601 | `$[d L SN 35600,35601]$` | Datum der letzten Leistung mit Nr. 35600 oder 35601 |
| 35600,35601 (vorletzte) | `$[d L SN 35600,35601 2]$` | Datum der VORLETZTEN Leistung mit Nr. 35600 oder 35601 |

## Erweiterte Berechnungen

Zum betreffenden Datum können auch **Sekunden (s), Minuten (min), Stunden (h), Tage (d), Monate (m) und Jahre (y)** addiert und subtrahiert werden.

### Beispiele (Systemdatum = 1. Nov 2016, 14:48)

| Kommando | Ergebnis | Beschreibung |
|---|---|---|
| `$[d S+4h SS]$` | 01.11.16, 18:48 | + 4 Stunden |
| `$[d S+10y-1d SS]$` | 31.10.26, 14:48 | + 10 Jahre, − 1 Tag |
| `$[d S+10y SS]$` | 01.11.26, 14:48 | + 10 Jahre |
| `$[d S+10y LL]$` | 1. November 2026 um 14:48:19 MEZ | + 10 Jahre, langes Format |
| `$[d S10 SS]$` | 11.11.16, 14:48 | + 10 Tage (Kurzform) |

---
---

# l / l_alle / l_ohneKartei — Leistungskommandos (Konfigurator)

## Kernkonzept
Gibt Leistungen des Patienten aus (EBM, GOÄ, UVGOÄ). Drei Varianten:
- `l` — Leistungen des in der Kartei ausgewählten Scheins/(BG-)Rechnung
- `l_alle` — Alle Leistungen der geöffneten Kartei (alle Scheine + Privatrechnungen)
- `l_ohneKartei` — Leistungen des aktiven Scheins/Rechnung (heuristisch bestimmt)

## Syntax

```
$[l <Format> <Auswahl> <Trennsequenz>]$
$[l_alle <Leistungsart> <Format> <Auswahl> <Trennsequenz>]$
```

## Format — Ausgabeformat mit %-Platzhaltern

### Allgemeine Platzhalter (alle Leistungsarten)

| Platzhalter | Beschreibung |
|---|---|
| `%nr` | Leistungsnummer |
| `%t` | Text |
| `%typ` | Art der Leistung |
| `%abr` | Name des abrechnenden Arztes |
| `%erbr` | Name des Leistungserbringers |
| `%z` | Uhrzeit |
| `%a` | Anzahl |
| `%dm` | Datum – Monat |
| `%dt` | Datum – Tag |
| `%d` | Datum |

### GOÄ-/UVGOÄ-Leistungen (zusätzlich)

| Platzhalter | Beschreibung |
|---|---|
| `%nr` | Leistungsnummer |
| `%t` | Text |
| `%f` | Steigerungsfaktor |
| `%begr` | Begründung |
| `%einzelkostenInCentNetto` | Einzelkosten in Cent ohne USt. |
| `%einzelkostenInCentBrutto` | Einzelkosten in Cent mit USt. |
| `%kostenInCentNetto` | Kosten in Cent ohne USt. |
| `%kostenInCentBrutto` | Kosten in Cent mit USt. |

### EBM-Leistungen (zusätzlich)

| Platzhalter | Beschreibung |
|---|---|
| `%nr` | Leistungsnummer |
| `%snz` | Schnitt-Naht-Zeit |
| `%ops` | OPS-Codes (kommasepariert) |
| `%gebNr` | Gebührennummern (kommasepariert) |

## Auswahl — Welche Leistungen

| Wert | Beschreibung |
|---|---|
| `N` | alle (default) |
| `J` | selektierte |
| `L` | letzteLeistung |
| `<Zahl>` | so-vielte Leistung |
| `<Zahl>d` | alle, die höchstens so-viele Tage alt sind |

### Für l_alle zusätzlich

| Wert | Beschreibung |
|---|---|
| `<Zahl>d` | alle, die höchstens `<Zahl>` Tage alt sind |
| `<Zahl>q` | alle, die höchstens `<Zahl>` Quartale alt sind |
| `<Zahl>y` | alle, die höchstens `<Zahl>` Jahre alt sind |

## Trennsequenz

Zeichenkette, die die Ausgaben der einzelnen Leistungen trennt. Standard ist **Zeilenumbruch**.

## Beispiele

```
# Alle OPS-Codes der selektierten Leistungen, Komma-getrennt:
$[l %ops J ,_]$

# EBM-Codes aller Leistungen des Scheins + OPS-Codes + Schnitt-Naht-Zeit:
$[l EBM:_%nr_OPS:_%ops_Schnitt-Naht-Zeit_%snz_min N \n]$

# Codes aller Leistungen des heutigen Tages, getrennt durch Komma:
$[l %nr 0d ,]$

# Alle GNR und OPS-Codes der EBM-Leistungen der letzten 5 Jahre:
$[l_alle ebm GNR:_%gebNr_OPS:_%ops 5y \\n]$
```

---
---

# karteiEintragWert — Werte aus Karteieinträgen (Konfigurator)

Früherer Name: `karteiEintragValue_withArgs`. Liest einzelne Werte aus Karteieinträgen. Besonders wichtig für **CustomKarteieinträge (CKE)**, funktioniert aber auch für Standard-Karteieinträge.

## Syntax

```
$[karteiEintragWert <Arg1> <Arg2> <Arg3> <Arg4>]$
```

**Mindestens 4 Argumente erforderlich!**

## Arg1 — Karteieintragtyp-Kürzel

Das Kürzel des Karteieintragstyps (z.B. `BEH`, `ANA`, `THE`, `BIO`, `OPT`, `BMI` oder jedes Custom-KE-Kürzel).

## Arg2 — Variablenname / Key

Welcher Wert aus dem Karteieintrag gelesen werden soll:

| Wert | Beschreibung |
|---|---|
| `datum` | Datum des Karteieintrags |
| `eintrag` | Gesamter Text des Karteieintrags |
| `customKarteiEintragEntries.<Variablenname>` | Einzelnes Feld eines CustomKarteieintrags, wobei `<Variablenname>` dem im CKE-Editor vergebenen Variablennamen entspricht |

**Hinweis:** Für Standard-KE-Typen (nicht-CKE) sind die verfügbaren Keys limitiert (`datum`, `eintrag`). Für CKE ist `customKarteiEintragEntries.<Variablenname>` der Standard-Zugriffspfad.

## Arg3 — Format

| Wert | Beschreibung |
|---|---|
| `_` | Kein spezielles Format (Standard für Nicht-Datum-Werte) |
| `dd.MM.yyyy` | Datumsformat (Java SimpleDateFormat-Syntax) |
| Andere Formate | Wie beim d-Kommando |

## Arg4 — Selektion

| Wert | Beschreibung |
|---|---|
| `N` | Letzten (neuesten) Karteieintrag des angegebenen Typs verwenden (Standard) |
| `D-<Zahl>t` | Letzter Eintrag innerhalb der letzten `<Zahl>` Tage |
| `D-<Zahl>h` | Letzter Eintrag innerhalb der letzten `<Zahl>` Stunden |
| `D-<Zahl>m` | Letzter Eintrag innerhalb der letzten `<Zahl>` Minuten |

## Beispiele

```

### Vollständige Argumentliste (Onlinehilfe, Stand 2026-07-30)

Die Onlinehilfe führt das Kommando unter dem Altnamen `karteiEintragValue_withArgs` und nennt
**fünf** Argumente:

```
<karteieintragtyp> <key> <format> <nutzeSelektiert> <soundsovielter>
```

Das fünfte Argument `soundsovielter` fehlte in dieser Referenz bislang. Es wählt den n-ten
Eintrag rückwärts ab der Selektion: leer = der zeitlich letzte, `-1` = der vorletzte, `-2` = der
davor. Praxisbelegt im Arztbrief-Referenzkorpus (`$[karteiEintragWert FOR text _ N -1]$` zieht das
vorletzte Patientenformular).

**Arg4 `nutzeSelektiert` — vollständige Werteliste:**

| Wert | Bedeutung |
|---|---|
| `J` | den in der Kartei selektierten Eintrag |
| `N` | den letzten Eintrag des angegebenen Typs |
| `AQ` / `AQ-n` | letzter Eintrag im aktuellen bzw. im n-letzten Quartal |
| `AD` / `AD-1` | nur heutige Einträge / gestern usw. |
| `D` + Zahl + `t`/`h`/`m` | letzter Eintrag innerhalb der Zeitspanne (Tage/Stunden/Minuten) |

**Arg2 `datum` ist auch für Standard-KE dokumentiert**, mit Formatangabe in Arg3 — Beispiel aus
der Onlinehilfe: `$[karteiEintragValue_withArgs RÖN datum dd.MM.yyyy_HH.mm D-1t]$`.

> **⚠️ Strukturgrenze (2026-08-04 verifiziert):** Das Kommando filtert **ausschließlich** über den
> Karteieintragstyp. Ein Filter auf ein bestimmtes Formular, Kürzel oder eine Vorlage existiert
> nicht. Alle über arzt-direct eingehenden Patientenformulare liegen im gemeinsamen Typ `FOR`;
> `AQ`/`soundsovielter` grenzen nur zeitlich bzw. positionell ein, nicht inhaltlich. Wer einen
> bogenspezifischen Wert braucht, muss `formularEintrag` verwenden (dort aber keine Metafelder)
> oder per Aktionskette einen eigenen Karteieintragstyp erzeugen.

# Medikamente aus OP-Termin-CKE (Kürzel "OPT", Feld "Medikamente"):
$[karteiEintragWert OPT customKarteiEintragEntries.Medikamente _ N]$

# Körpertemperatur aus BIO-CKE:
$[karteiEintragWert BIO customKarteiEintragEntries.Körpertemperatur _ N]$

# Datum aus CKE der letzten 7 Tage im Format dd.MM.yyyy:
$[karteiEintragWert custom customKarteiEintragEntries.Datum dd.MM.yyyy D-7t]$

# Datum des letzten Röntgen-Eintrags (Standard-KE):
$[karteiEintragWert RÖN datum dd.MM.yyyy_HH:mm N]$

# In Kombination mit if_then (Wert nur ausgeben wenn vorhanden):
$[if_then karteiEintragWert TAPP customKarteiEintragEntries.vOPS2 _ D-1t zs_not_equal <leer> karteiEintragWert TAPP customKarteiEintragEntries.vOPS2-Text _ D-1t]$
```

### Praxis-Tipp: In Aktionsketten-Bedingungen

In Aktionsketten-Bedingungen wird `karteiEintragWert` häufig in der Kommando-Spalte verwendet:
```
Kommando: $[karteiEintragWert CHA2DS2 datum _ N]$
Relation: ist nicht
Vergleichswert: $[&heute]$
```
→ Prüft ob der CHA2DS2-Score NICHT heute angelegt wurde (Duplikatschutz).

---
---

# formularEintrag — Werte aus Patientenformularen (Konfigurator)

## Kernkonzept
Liest einzelne Werte aus tomedo-Patientenformularen (PatF) oder Custom-Formularen aus. Essentiell für Aktionsketten-Bedingungen, die auf Formularantworten basieren.

## Syntax

```
$[formularEintrag <FormularKürzel> <Variablenname> <Selektion>]$
```

**3 Argumente erforderlich.**

## Arg1 — FormularKürzel

Das Kürzel des Patientenformulars (z.B. `PatF-Anamnesebogen`, `PatF-Terminvereinbarung`, `PatF-Allgemeine-Beschwerden`). Entspricht dem Kürzel in der Formularverwaltung.

## Arg2 — Variablenname

Der Variablenname des Formularfeldes, dessen Wert ausgelesen werden soll. Die Variablennamen findet man in den **Patientenformular-Einstellungen** (Formularverwaltung → Patientenformular auswählen → Patientenformular-Einstellungen → Reiter "Elemente"). Dort kann man auch das Briefkommando per "Kopieren"-Button direkt kopieren.

## Arg3 — Selektion

#### Arg2 akzeptiert KEINE Metafelder

`formularEintrag` liest **ausschließlich Variablennamen von Formular-Elementen** (Reiter
„Elemente" der Patientenformular-Einstellungen). **Metafelder des Formulars — insbesondere das
Eingangs-/Erstellungsdatum — sind über dieses Kommando grundsätzlich nicht erreichbar.**

Konsequenz für die Praxis: Versuche wie `erstelltAm`, `created`, `datum`, `erstellt`,
`erstelltam` liefern **immer leer**; das ist kein Bezeichner-Problem, sondern eine
Architekturgrenze. Zwei belegte Auswege:

1. **Datum über den Karteieintrag** des eingegangenen Formulars holen (datiertes x-Kommando,
   Cap 1) — unabhängig vom Formularinhalt, benötigt aber den korrekten KE-Typ.
2. **Datums-Element im Formular ergänzen** — ein `expression`-Element mit `today()` und eigenem
   `shortTitle`; dann ist es ein reguläres Element und per `formularEintrag` auslesbar.

| Wert | Beschreibung |
|---|---|
| `N` | Neuestes (letztes) ausgefülltes Formular des Typs verwenden |

## Beispiel

```
# Wert aus Patientenformular "PatF-Terminvereinbarung", Feld "Krankenkasse":
$[formularEintrag PatF-Terminvereinba... Krankenkasse N]$

# In Kombination mit kommandorahmen (nur wenn nicht leer):
$[kommandorahmen formularEintrag PatF-Test-Formular Var1 N Präfix_ _Suffix]$
```

### Praxis-Tipp: In Aktionsketten-Bedingungen

```
Kommando: $[formularEintrag PatF-Terminvereinba... Krankenkasse N]$
Relation: ist
Vergleichswert: Barmer
Datenlade: ☑ Lade alle Karteieinträge/Formulare vor Ausführung
```
→ Prüft ob im Patientenformular "Barmer" als Krankenkasse angegeben wurde.

---
---

# x — Komplexes Karteieintrags-Kommando (Konfigurator)

## Kernkonzept
Das x-Kommando ist das mächtigste Werkzeug zum Auslesen von Informationen aus der Kartei. Es hat zahlreiche Parameter (a bis g₂) für Filterung, Formatierung und Selektion.

## Syntax

```
$[x <a> <b₁> <b₂> <c> <d₁d₂> <e₁e₂e₃e₄> <f₁f₂f₃f₄> <g₁> <g₂> <h>]$
```

## Parameter-Übersicht

### a — Karteieintragtyp
Welcher Karteieintragtyp ausgelesen wird (z.B. `AU`, `BEH`, `ANA`, `THE`, `DDI`, `IMPF` oder jedes Custom-KE-Kürzel).

### b₁ — Anzahl der Karteieinträge
| Wert | Beschreibung |
|---|---|
| `inf` oder `_` | Keine Einschränkung |
| `<Zahl>` (z.B. `1`, `18`) | Maximale Anzahl |

### b₂ — Selektion
| Wert | Beschreibung |
|---|---|
| `_` | Keine Einschränkung |
| `sel` | Nur in der Kartei selektierte Einträge |
| `bes` | Nur Einträge des aktuellen Besuchs (nur Radiologen) |

### c — Zeitraum
| Wert | Beschreibung |
|---|---|
| `_` | Kein Zeitfilter |
| `aq` | Aktuelles Quartal |
| `0-<Zahl>d` | Letzte N Tage (z.B. `0-10d`) |

### d₁d₂ — Reihenfolge/Sortierung (2 Zeichen)
`NN` = Standard (neueste zuerst)

### e₁e₂e₃e₄ — Ausgabe-Optionen (4 Zeichen)

#### Datums-Flag-Kombinationen (empirisch, Referenzkorpus)

Aus dem produktiven Arztbrief-Korpus (28 x-Kommandos, Realtests 06–07/2026) sind zwei
Kombinationen der Slots e₁e₂e₃e₄ + f₁f₂f₃f₄ belegt:

| Kombination | Wirkung | Einsatz |
|---|---|---|
| `NJ22 NNND` | **Datum (TT.MM.JJJJ) wird je Eintrag vorangestellt** | datierte Verlaufs-/Befundblöcke (BEF, BEF_PHY, SONO, SCAN, T, THE, ANA, Heilmittel, BEH_AB, BEH) |
| `NNJN NNNN` | Ausgabe **ohne** Datum, kumulativer Einzelblock | DIA/DIAX, CAV, ALG, SOZ, SOZ_AB |

**Wichtig:** Die Kombination steuert **nur die Ausgabe**, nicht die Sortierung — die liegt in
d₁d₂ (`NN` = neueste zuerst). Ein undatierter Block kann also korrekt sortiert sein und
*trotzdem* kein Datum zeigen; das ist der klassische Fehlschluss beim Debuggen. Umstellung von
`NNJN NNNN` auf `NJ22 NNND` verändert die Reihenfolge **nicht**.

Siehe auch: `invTime` steht im g₁-Slot und **invertiert** die Reihenfolge — es bedeutet nicht
„neueste zuerst".
`NNNN` = Standard. Jede Position steuert einen Aspekt der Ausgabe (Datum, Typ, Nutzer, Formatierung).

### f₁f₂f₃f₄ — Filter-Optionen (4 Zeichen)
`NNNN` = Standard. Positionen für z.B. nur aktive Diagnosen (`J` an Position 3 bei DDI).

### g₁ — Ausgabe-Format
| Wert | Beschreibung |
|---|---|
| `_` | Standardausgabe |
| `K` | Kompaktformat |
| Spezialformate | z.B. `ICDvornstripMed`, `nurAktiveDiagnosen` |

### g₂ — Trennzeichen
| Wert | Beschreibung |
|---|---|
| `_` | Zeilenumbruch (Standard) |
| `0` | Kein Trennzeichen |

## Praxis-Beispiele

```

**ICD-Code-Ausgabe: ICDvorn im g1-Feld, NICHT UD.** Beim x-Kommando steuert das
Ausgabe-Format-Feld (g₁) die ICD-Voranstellung. Korrekt ist das Spezialformat
`ICDvorn` (ggf. aneinandergehängt mit `nurAktiveDiagnosen` ->
`ICDvornnurAktiveDiagnosen`). `UD` an dieser Position gibt KEINEN Code aus.
Validiertes Diagnose-Kommando (aktive Diagnosen mit Code, 4 Quartale):
`$[x DIA,DIAX _ _ 4q NN NNJN NNNN ICDvornnurAktiveDiagnosen U _]$`
Mit [Testen] an einem Patienten mit echt ICD-codierter Diagnose verifizieren
(Testdaten ohne Code maskieren den Fehler).

> **Hinweis zum `4q` in Arg 3:** Quartalsfenster (`4q`, `5q`) sind in der Argumentreferenz
> **nicht dokumentiert**; `4q` hat hier empirisch gegriffen. Das Kommando ist als Ganzes
> validiert, der Zeitfilter aber die fragile Stelle — bei „Export endet in einem alten Jahr"
> Arg 3 auf `_` stellen und die Menge stattdessen über den Anzahl-Cap in Arg 2 begrenzen
> (siehe `SKILL.md` → „x-Kommando: Auswahl-Fenster").

# Aktuellste AU-Bescheinigung im aktuellen Quartal:
$[x AU 1 _ aq NN NNNN NNNN _ K 0]$

# In der Kartei selektierter AU-Eintrag:
$[x AU _ sel _ NN NNNN NNNN _ K 0]$

# Alle aktiven Dauerdiagnosen:
$[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$

# Alle ICD-Codes aus Diagnosen und Dauerdiagnosen:
$[x DIA+DDI _ _ _ NN NNNN NNNN ICDvorn K _]$
```

**Praxis-Tipp:** Das x-Kommando hat einen eigenen **Konfigurator** unter Admin → Kommandos → x, der alle Parameter per Dropdown auswählbar macht. Erstellte Kommandos können als "gespeicherte Platzhalter" wiederverwendet werden.

---
---

# Erweiterte Patterns: UND/ODER-Verknüpfung von Bedingungen

## UND-Verknüpfung (if_then + if)

```
$[if_then kommando1 wert1 if kommando2 wert2 Ausgabe]$
```

Prüft: Kommando1 == wert1 **UND** Kommando2 == wert2 → gibt "Ausgabe" aus.

## ODER-Verknüpfung

Kann über Kombination aus einfachem if-Kommando und score-Kommando realisiert werden, oder über verschachtelte if-Kommandos.

## Verschachtelung von Kommandos (if_then statt if)

**Wichtig:** Wenn das Ergebnis eines if-Vergleichs ein **anderes Kommando** ausführen soll (nicht einfach einen Text ausgeben), muss `if_then` statt `if` verwendet werden:

```
# FALSCH — gibt den Kommando-Text als String aus statt ihn auszuführen:
$[if karteiEintragWert TAPP ... zs_not_equal <leer> karteiEintragWert TAPP ...]$

# RICHTIG — führt das zweite Kommando aus:
$[if_then karteiEintragWert TAPP customKarteiEintragEntries.vOPS2 _ D-1t zs_not_equal <leer> karteiEintragWert TAPP customKarteiEintragEntries.vOPS2-Text _ D-1t]$
```

---
---

# Weitere Konfiguratoren (Kurzreferenz)

## a — Anrede-Platzhalter

Geschlechtsabhängiger Anrede-Platzhalter für Briefe. Fallunterscheidung nach Empfänger und Geschlecht.

```
$[a <männlich> <weiblich> <unbekannt>]$
```

Argumente sind die auszugebenden Texte für die drei Fälle. Leerzeichen innerhalb durch `_` ersetzen.

## lab — Laborwerte (Kurzform)

Laborwerte aus dem Reiter Medizinische Dokumentation. Optionen zum Eingrenzen:
- `nurKuerzel` — nur bestimmte Testkürzel
- `ohneKuerzel` — bestimmte ausschließen
- `nurGruppen` — nur bestimmte Gruppen
- `ohneGruppen` — bestimmte Gruppen ausschließen
- `nichtleer` — nur Tests mit Ergebnis

## labor — Laborwerte (Tabelle)

Erzeugt eine Tabelle aus den ausgewählten Laborwerten. Für den Druck in Briefvorlagen.

## laborwert — Einzelne Laborwerte

```
$[laborwert <Testkürzel> <Format> <AnzahlBefunde> <Trennsequenz>]$
```

Mindestens 4 Parameter. Gibt Informationen zu einem oder mehreren Laborwerten mit dem gleichen Testkürzel aus.

## letzteLaborwerte — Alle Werte des letzten Befundes

```
$[letzteLaborwerte <Format> <Trennsequenz> <AlterInTagen>]$
```

Format verwendet dieselben Platzhalter wie `laborwert`. Trennsequenz Standard: `", "`. Optionales 3. Argument: Alter in Tagen um alle Befunde bis zu diesem Alter zu berücksichtigen.

### Beispiele

```
# Alle Laborwerte des letzten Befundes (Kürzel_Wert, Zeilenumbruch):
$[letzteLaborwerte %@_%@_%@ \\n]$

# Laborwerte der letzten 7 Tage (Kürzel:_WertEinheit, Komma):
$[letzteLaborwerte %@_%@:_%@%@ ,_ 7]$
```

## medikamentenplan — Medikamenten-Tabelle

Erzeugt eine Tabelle mit dem aktuellen Medikamentenplan. Als Parameter werden gewünschte Spaltenkürzel angegeben (gleiche Kürzel wie `tab_med_*` Tabellen-Kommandos).

## impfstatus — Impftabelle

Erzeugt eine Tabelle mit dem aktuellen Impfstatus.

```
$[impfstatus]$
```

## dmp — DMP-Daten

Liest Informationen aus einer DMP-Dokumentation aus. Verwendet den Konfigurator für Parameter-Auswahl.
