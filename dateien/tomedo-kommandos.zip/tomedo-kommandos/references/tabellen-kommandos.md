# Vollständiger Katalog: Tabellen-Kommandos

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Art → Tabelle).
Stand: März 2026. Tabellen-Kommandos werden in Tabellenplatzhaltern innerhalb von Briefvorlagen verwendet.

---

## Allgemeine Tabellen-Kommandos

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| adresse | | Patiententermine | Termine | Adresse der Betriebsstätte des Termins, abgeleitet aus der Terminlokalität |
| arbmed_anlass | | Arbeitsmedizin | Praxis | Tabellenkommando: Anlass der Untersuchung |
| arbmed_art | | Arbeitsmedizin | Praxis | Tabellenkommando: Art der Untersuchung |
| arbmed_datum | | Arbeitsmedizin | Praxis | Tabellenkommando: Datum der Untersuchung |
| arbmed_ergebnis | | Arbeitsmedizin | Praxis | Tabellenkommando: Ergebnis der Untersuchung |
| arbmed_frist | | Arbeitsmedizin | Praxis | Tabellenkommando: Frist bis zur Nachuntersuchung |
| arbmed_kommentar_arbeitgeber | | Arbeitsmedizin | Praxis | Tabellenkommando: Kommentar an den Arbeitgeber |
| arbmed_kommentar_proband | | Arbeitsmedizin | Praxis | Tabellenkommando: Kommentar an den Probanden |
| arbmed_typ | | Arbeitsmedizin | Praxis | Tabellenkommando: Typ der Untersuchung |
| beginn | | Kalendertag | Termine | Tabellenkommando: Beginn des Termins |
| behandler | | Patiententermine | Termine | Verantwortlicher Behandler bzw. Arzt |
| bem | | Marcumarplan | Medikam... | Bemerkung |
| beschreibung | | Medikamentenetikett | Medikam... | Name des Produktes |
| bezeichnung | | Laborbefund | Labor | Bezeichnung des Tests |

## Datum/Kalender

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| date | | Marcumarplan | Medikam... | Datum |
| daten | | Laborbefund | Labor | Berichtsdaten der Tests, nur für kumulativen Verlauf! Wird durch eine variable Anzahl an Spalten ersetzt, je nach Anzahl der Befunde |
| datum | | Patiententermine | Termine | Datum des Termins |
| di | | Marcumarplan | Medikam... | Wert für Dienstag |
| don | | Marcumarplan | Medikam... | Wert für Donnerstag |
| druckdatum | | Patiententermine | Termine | Datum und Uhrzeit des Druckens |
| ende | | Kalendertag | Termine | Tabellenkommando: Ende des Termins |

## Labor

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| einheit | | Laborbefund | Labor | Physikalische Einheit des Ergebnisses |
| ergebnis | | Laborbefund | Labor | Ergebnis (Zahl) |
| ergebnistext | | Laborbefund | Labor | Ergebnistext. Sehr lang bei histologischen Befunden. Funktioniert nur in der Vorlage, die in den Praxis-Einstellungen bei Labor unter "Einzelbefund Druckvorlage mit Ergebnistext" ausgewählt ist |
| ergebniswerte | | Laborbefund | Labor | Ergebnis, nur für kumulativen Verlauf! Wird durch eine variable Anzahl an Spalten ersetzt, je nach Anzahl der Befunde |
| gruppenName | | Laborbefund | Labor | Gruppe des Tests |
| indikator | | Laborbefund | Labor | Indikator (Nicht bei kumulativ) |
| kommentar | | Laborbefund | Labor | Kommentar zum Test (Nicht bei kumulativ) |
| laborverlaufGrafik | | Laborbefund | Labor | Grafik, die das Ergebnis des Tests im Verhältnis zum Normbereich darstellt (Nicht bei kumulativ) |
| material | | Laborbefund | Labor | Material (Nicht bei kumulativ) |
| normalwert | | Laborbefund | Labor | Normalwert (Nicht bei kumulativ) |
| normbereich | | Laborbefund | Labor | Normbereich – für die Ausgabe hier gibt es eine Einstellung unter Praxis → Labor → Druckvorlagen (Nicht bei kumulativ) |
| normbereichGrafik | | Laborbefund | Labor | Grafik, die das Ergebnis des Tests im Verhältnis zum Normbereich darstellt (Nicht bei kumulativ) |
| normwerte | | Laborbefund | Labor | Normalwert (nur für kumulativ) |
| testbezogeneHinweise | | Laborbefund | Labor | Testbezogene Hinweise (Nicht bei kumulativ) |
| testdatum | | Laborbefund | Labor | Datum des Tests |
| testkuerzel | | Laborbefund | Labor | Kürzel für Test |

## Medikamentenplan

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| ean | | Medikamentenetikett | Medikam... | EAN des Produktes |
| tab_med_abends | | Medikamentenplan | Medikam... | Dosierung für den Abend |
| tab_med_anzahl | | Medikamentenplan | Medikam... | verordnete Anzahl des Medikaments |
| tab_med_atc | | Medikamentenplan | Medikam... | ATC-Code des Medikaments |
| tab_med_dauermedikation | | Medikamentenplan | Medikam... | "ja" falls Dauermedikation, sonst "nein" |
| tab_med_dosierEinheit | | Medikamentenplan | Medikam... | Einheit bei der Dosierung |
| tab_med_dosierSchema | | Medikamentenplan | Medikam... | Das Dosierschema wird in der Form "früh-mittags-abends-nachts" ausgegeben. Ein Schema, das ausschließlich Nullen enthält (0-0-0-0), wird nicht angezeigt |
| tab_med_einnahme | | Medikamentenplan | Medikam... | Einnahmetyp (aktiv, Reserve, Material) |
| tab_med_erstelltam | | Medikamentenplan | Medikam... | Datum der Verordnung des Medikamentes |
| tab_med_form | | Medikamentenplan | Medikam... | Darreichungsform des Medikaments |
| tab_med_freitext | | Medikamentenplan | Medikam... | Dosierungsfreitext |
| tab_med_grund | | Medikamentenplan | Medikam... | Grund der Verordnung (BMP) |
| tab_med_gueltigbis | | Medikamentenplan | Medikam... | Datum bis wann das Medikament einzunehmen ist |
| tab_med_hersteller | | Medikamentenplan | Medikam... | Hersteller des Medikaments |
| tab_med_hinweise | | Medikamentenplan | Medikam... | Hinweise zum Medikament (BMP) |
| tab_med_infospalte | | Medikamentenplan | Medikam... | Inhalt der Infospalte |
| tab_med_mittags | | Medikamentenplan | Medikam... | Dosierung für den Mittag |
| tab_med_morgens | | Medikamentenplan | Medikam... | Dosierung für den Morgen |
| tab_med_nachts | | Medikamentenplan | Medikam... | Dosierung für die Nacht |
| tab_med_name | | Medikamentenplan | Medikam... | Name des Medikamentes |
| tab_med_pzn | | Medikamentenplan | Medikam... | PZN des Medikaments |
| tab_med_reichtbis | | Medikamentenplan | Medikam... | Datum bis wann die verordnete Dosierung reicht |
| tab_med_wirkstaerke | | Medikamentenplan | Medikam... | Verordnete Wirkstärke des Medikaments |
| tab_med_wirkstoffe | | Medikamentenplan | Medikam... | Wirkstoffe des Medikaments |

## Patientenliste

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_datum | | Patientenliste | Patient | Datum, an dem der Patient zur Liste hinzugefügt wurde |
| tab_geburtsdatum | | Patientenliste | Patient | Geburtsdatum des Patienten |
| tab_id | | Patientenliste | Patient | Ident (Nummer) des Patienten |
| tab_info | | Patientenliste | Patient | Info des Patienten aus Patientenliste |
| tab_nachname | | Patientenliste | Patient | Nachname des Patienten |
| tab_plz | | Patientenliste | Patient | Postleitzahl des Patienten |
| tab_strasse | | Patientenliste | Patient | Straße des Patienten |
| tab_telefon | | Patientenliste | Patient | Telefonnummer des Patienten |
| tab_titel | | Patientenliste | Patient | Titel des Patienten |
| tab_vorname | | Patientenliste | Patient | Vorname des Patienten |
| tab_wohnort | | Patientenliste | Patient | Wohnort des Patienten |
| tab_zeit | | Patientenliste | Patient | Zeit, zu der der Patient zur Liste hinzugefügt wurde |

## Karteieinträge

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_ke_dateString | | Patient | Karteiein... | selektierte Karteieinträge – Datum des Karteieintrages |
| tab_ke_text | | Patient | Karteiein... | selektierte Karteieinträge – Text des Karteieintrages |
| tab_ke_typ | | Patient | Karteiein... | selektierte Karteieinträge – Karteieintragtyp des Karteieintrages |
| tab_ke_wert | ✓ | Patient | Karteiein... | Funktioniert wie der Text-Platzhalter karteiEintragWert, mit dem Unterschied, dass nicht der neueste Karteieintrag des angegebenen Typs genommen wird, sondern alle, bzw. alle selektierten |

## Privatrechnung (Leistungstabelle)

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_pr_abrechnenderArzt | | Privatrechnung | Privatrec... | Kürzel des abrechnenden Arztes |
| tab_pr_allgemeine_kosten | | Privatrechnung | Privatrec... | BG-Rechnung: Betrag der allgemeinen Kosten der Leistung |
| tab_pr_anzahl | | Privatrechnung | Privatrec... | Anzahl der Leistungen |
| tab_pr_begruendung | | Privatrechnung | Privatrec... | Begründung der Leistung |
| tab_pr_besondere_kosten | | Privatrechnung | Privatrec... | BG-Rechnung: Betrag der besonderen Kosten der Leistung |
| tab_pr_besondere_kosten_oW | | Privatrechnung | Privatrec... | Betrag der besonderen Kosten der Leistung ohne Währung |
| tab_pr_betrag | | Privatrechnung | Privatrec... | Betrag der Leistung. Berücksichtigt die Anzahl |
| tab_pr_betrag_oW | | Privatrechnung | Privatrec... | Betrag der Leistung ohne Währungszeichen. Berücksichtigt die Anzahl |
| tab_pr_betrag_real | | Privatrechnung | Privatrec... | Betrag der Leistung. Berücksichtigt Anzahl, Umsatzsteuer und eventuelle Abzüge |
| tab_pr_betrag_real_oW | | Privatrechnung | Privatrec... | Betrag der Leistung ohne Währungszeichen. Berücksichtigt Anzahl, Umsatzsteuer und eventuelle Abzüge |
| tab_pr_bezeichnung | | Privatrechnung | Privatrec... | Bezeichnung der Leistung |
| tab_pr_code | | Privatrechnung | Privatrec... | GOÄ-Code der privaten Leistung |
| tab_pr_datum | ✓ | Privatrechnung | Privatrec... | Datum der privaten Leistung. Es kann auch ein eigenes Datumsformat angegeben werden mit dem Argument format_<format>, z.B. $[tab_pr_datum format_MM/yyyy]$ |
| tab_pr_datum2 | | Privatrechnung | Privatrec... | Datum der privaten Leistung vor jeder Leistung |
| tab_pr_einzelbetragNetto | | Privatrechnung | Privatrec... | Netto-Betrag der Einzelkosten |
| tab_pr_einzelbetrag_ohneSteigerung | | Privatrechnung | Privatrec... | Betrag der Leistung wenn Anzahl 1 wäre und Steigerungsfaktor 1 wäre |
| tab_pr_faktor | | Privatrechnung | Privatrec... | Steigerungsfaktor der Leistung |
| tab_pr_kurztext | | Privatrechnung | Privatrec... | Kurztext der Leistung |
| tab_pr_kurztext_ohne_begruendung | | Privatrechnung | Privatrec... | Kurztext der Leistung (ohne Begründung) |
| tab_pr_langtext | | Privatrechnung | Privatrec... | Langtext der Leistung (ohne Begründung) |
| tab_pr_leistungserbringer | | Privatrechnung | Privatrec... | Kürzel des Leistungserbringers |
| tab_pr_mwst | | Privatrechnung | Privatrec... | USt-Satz der aufgeführten Leistung |
| tab_pr_organ | | Privatrechnung | Privatrec... | Zur Leistung zugeordnetes Organ |
| tab_pr_position | | Privatrechnung | Privatrec... | Nummeriert die aufgeführten Leistungen durch |
| tab_pr_sitzungsnummer | | Privatrechnung | Privatrec... | Sitzungsnummer der aufgeführten Leistung |
| tab_pr_zeit | | Privatrechnung | Privatrec... | Zeit der privaten Leistung |

## HZV-Importprotokoll (PTV)

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_ptv_conflict_geburtsdatum | | HZV-Importprotokoll | HZV | Geburtsdatum des Patienten in der Übersicht von Patientenstammdaten-Konflikten |
| tab_ptv_conflict_importwert | | HZV-Importprotokoll | HZV | Im PTV gespeicherter Wert für das Konflikt-Element |
| tab_ptv_conflict_systemwert | | HZV-Importprotokoll | HZV | In der Praxissoftware gespeicherter Wert für das Konflikt-Element |
| tab_ptv_conflict_typ | | HZV-Importprotokoll | HZV | Typ des Konflikts (Name, Vorname oder Geschlecht) |
| tab_ptv_conflict_vollname | | HZV-Importprotokoll | HZV | Name und Vorname des Patienten |
| tab_ptv_normal_geburtsdatum | | HZV-Importprotokoll | HZV | Geburtsdatum des Patienten (normale Teilnehmemeldungen) |
| tab_ptv_normal_grund | | HZV-Importprotokoll | HZV | Grund der Vertragsbeendigung (normale Teilnehmemeldungen) |
| tab_ptv_normal_status | | HZV-Importprotokoll | HZV | Vertragsstatus des Patienten (normale Teilnehmemeldungen) |
| tab_ptv_normal_versichertennummer | | HZV-Importprotokoll | HZV | Versichertennummer (normale Teilnehmemeldungen) |
| tab_ptv_normal_vollname | | HZV-Importprotokoll | HZV | Name und Vorname (normale Teilnehmemeldungen) |
| tab_ptv_normal_zeitraum | | HZV-Importprotokoll | HZV | Teilnahmezeitraum (normale Teilnehmemeldungen) |
| tab_ptv_notfound_geburtsdatum | | HZV-Importprotokoll | HZV | Geburtsdatum des Patienten (nicht gefundene Patienten) |
| tab_ptv_notfound_hinweis | | HZV-Importprotokoll | HZV | Hinweis, aus welcher Quelle die Daten stammen |
| tab_ptv_notfound_status | | HZV-Importprotokoll | HZV | Vertragsstatus (nicht gefundene Patienten) |
| tab_ptv_notfound_versichertennummer | | HZV-Importprotokoll | HZV | Versichertennummer (nicht gefundene Patienten) |
| tab_ptv_notfound_vollname | | HZV-Importprotokoll | HZV | Name und Vorname (nicht gefundene Patienten) |
| tab_ptv_notfound_zeitraum | | HZV-Importprotokoll | HZV | Teilnahmezeitraum (nicht gefundene Patienten) |
| tab_ptv_special_geburtsdatum | | HZV-Importprotokoll | HZV | Geburtsdatum (besondere Teilnehmemeldungen) |
| tab_ptv_special_grund | | HZV-Importprotokoll | HZV | Grund der Vertragsbeendigung (besondere Teilnehmemeldungen) |
| tab_ptv_special_versichertennummer | | HZV-Importprotokoll | HZV | Versichertennummer (besondere Teilnehmemeldungen) |
| tab_ptv_special_vollname | | HZV-Importprotokoll | HZV | Name und Vorname (besondere Teilnehmemeldungen) |
| tab_ptv_special_zeitraum_import | | HZV-Importprotokoll | HZV | Im PTV angegebene Teilnahmezeitraum und Vertragsstatus |
| tab_ptv_special_zeitraum_system | | HZV-Importprotokoll | HZV | In der Praxissoftware gespeicherte Teilnahmezeitraum und Vertragsstatus |

## Warenbestellung

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_bestellung_anzahl | | Warenbestellung | Einkauf | Anzahl der bestellten Medikamente |
| tab_bestellung_artikelnummer | | Warenbestellung | Einkauf | Artikelnummer der bestellten Medikamente |
| tab_bestellung_beschreibung | | Warenbestellung | Einkauf | Beschreibung der bestellten Medikamente |
| tab_bestellung_ean | | Warenbestellung | Einkauf | EAN der bestellten Medikamente |
| tab_bestellung_pharmaCode | | Warenbestellung | Einkauf | Pharmacode der bestellten Medikamente |
| tab_bestellung_pzn | | Warenbestellung | Einkauf | PZN der bestellten Medikamente |

## Steuerkommandos (Tabellen)

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_if | ✓ | ohne | Steuerko... | Analog zum Textplatzhalter mit Argumenten "if", nur eben für Tabellenplatzhalter als auszuführende Kommandos. Tabellenplatzhalter in den Alternativwerten funktionieren hier nicht |
| tab_if_then | ✓ | ohne | Steuerko... | Analog zum Textplatzhalter mit Argumenten "if_then", nur eben für Tabellenplatzhalter als auszuführende Kommandos |
| tab_kommandorahmen | ✓ | ohne | Steuerko... | Ruft das angegebene Kommando (1.Arg) auf. Falls nicht leer, dann füge Zeichen am Anfang (2.Arg) und Zeichen am Ende (3.Arg) hinzu. \n erlaubt Zeilenvorschub, _ wird als Leerzeichen gewertet. Soll kein Text vorangestellt werden, ist als zweites Argument "<leer>" zu übergeben |

## Patiententermine

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| info | | Patiententermine | Termine | Info des Termins |
| kalender | | Patiententermine | Termine | Gibt aus, in welchen Kalendern der Termin eingetragen ist |
| laenge | | Patiententermine | Termine | Voraussichtliche Dauer des Arzt-Patienten-Kontaktes |
| name | | Patiententermine | Termine | Voller Name des Patienten, Version 1 |
| patientenname | | Patiententermine | Termine | Voller Name des Patienten, Version 2 |
| terminart | | Patiententermine | Termine | Terminart des Termins |
| todos | | Patiententermine | Termine | ToDos für den Termin |
| wochentag | | Patiententermine | Termine | Wochentag des Termins |
| wochentagKurz | | Patiententermine | Termine | Wochentag des Termins (Kurzform) |
| zeit | | Patiententermine | Termine | Uhrzeit des Termins |

## Kalendertag

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| gebdatum | | Kalendertag | Termine | Geburtsdatum des Patienten |
| handy | | Kalendertag | Termine | Handynummer des Patienten für Termin |
| info | | Kalendertag | Termine | Freitext – Info für Termin |
| patientenname | | Kalendertag | Termine | Name des Patienten für Termin |
| patientennummer | | Kalendertag | Termine | Patientennummer für Termin |
| plz | | Kalendertag | Termine | PLZ des Patienten |
| strasse | | Kalendertag | Termine | Straße des Patienten |
| tel | | Kalendertag | Termine | Telefonnummer des Patienten für Termin |
| terminart | | Kalendertag | Termine | Terminart des Termins (Bezeichner) |
| todos | | Kalendertag | Termine | ToDos des Termins |
| wohnort | | Kalendertag | Termine | Wohnort des Patienten |

## Marcumarplan

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| fr | | Marcumarplan | Medikam... | Wert für Freitag |
| inr | | Marcumarplan | Medikam... | INR-Wert |
| mi | | Marcumarplan | Medikam... | Wert für Mittwoch |
| mo | | Marcumarplan | Medikam... | Wert für Montag |
| quick | | Marcumarplan | Medikam... | Quick-Wert |
| sa | | Marcumarplan | Medikam... | Wert für Samstag |
| so | | Marcumarplan | Medikam... | Wert für Sonntag |

## Sammelrechnung

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| ll_tab_anzahl | | Sammelrechnung | Privatrec... | Tabellenkommando: Anzahl der Leistung |
| ll_tab_code | | Sammelrechnung | Privatrec... | Tabellenkommando: Code der Leistung |
| ll_tab_einzelkosten | | Sammelrechnung | Privatrec... | Tabellenkommando: Kosten der Einzelleistung |
| ll_tab_einzelkostenMwst | | Sammelrechnung | Privatrec... | Tabellenkommando: USt.-Anteil der Einzelleistung |
| ll_tab_einzelkostenNetto | | Sammelrechnung | Privatrec... | Tabellenkommando: Nettokosten der Einzelleistung |
| ll_tab_kosten | | Sammelrechnung | Privatrec... | Tabellenkommando: Kosten aller Leistungen aufsummiert |
| ll_tab_kostenreal | | Sammelrechnung | Privatrec... | Tabellenkommando: Realkosten aller Leistungen aufsummiert |
| ll_tab_mwst | | Sammelrechnung | Privatrec... | Tabellenkommando: USt.-Satz der Leistung |
| ll_tab_text | | Sammelrechnung | Privatrec... | Tabellenkommando: Kurztext der Leistung |
| ll_tab_zeitraum | | Sammelrechnung | Privatrec... | Tabellenkommando: Zeitraum, in dem diese Leistung erbracht wurde |
| sr_tab_betrag | | Sammelrechnung | Privatrec... | Tabellenkommando: Betrag der Teilrechnung |
| sr_tab_patient | | Sammelrechnung | Privatrec... | Tabellenkommando: Name des Patienten |
| sr_tab_patient_geb | | Sammelrechnung | Privatrec... | Tabellenkommando: Geburtsdatum des Patienten |
| sr_tab_patient_nachname | | Sammelrechnung | Privatrec... | Tabellenkommando: Nachname des Patienten |
| sr_tab_patient_vorname | | Sammelrechnung | Privatrec... | Tabellenkommando: Vorname des Patienten |
| sr_tab_teilrechnungsnummer | | Sammelrechnung | Privatrec... | Tabellenkommando: Teilrechnungsnummer |
| sr_tab_zeitraum | | Sammelrechnung | Privatrec... | Tabellenkommando: Behandlungszeitraum des Patienten |

## Medikamentenetikett

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| verkaufspreis | | Medikamentenetikett | Medikam... | Verkaufspreis des Produktes |

## Labortabelle (tab_lab_)

| Name | Param | Kontext | Themen | Beschreibung |
|---|---|---|---|---|
| tab_lab_bezeichnung | | Laborwertedruck | Labor | Bezeichnung des Labortests |
| tab_lab_daten | | Laborwertedruck | Labor | Daten der Labortests |
| tab_lab_daten_kurz | | Laborwertedruck | Labor | Daten der Labortests ohne Jahreszahl |
| tab_lab_einheit | | Laborwertedruck | Labor | Einheit des Labortests |
| tab_lab_ergebniswerte | | Laborwertedruck | Labor | Ergebniswerte der Labortests |
| tab_lab_gruppenName | | Laborwertedruck | Labor | Gruppe des Labortests |
| tab_lab_normalwert | | Laborwertedruck | Labor | Normalwert des Labortests |
| tab_lab_testkuerzel | | Laborwertedruck | Labor | Testkürzel des Labortests |

---

## Statistik

**Gesamt: ~140 Tabellen-Kommandos** (aus 4 Screenshot-Seiten extrahiert)

### Nach Kontext:
- Privatrechnung: ~25 Kommandos (tab_pr_*)
- Medikamentenplan: ~20 Kommandos (tab_med_*)
- Laborbefund/Laborwertedruck: ~25 Kommandos
- Patiententermine: ~12 Kommandos
- HZV-Importprotokoll: ~22 Kommandos (tab_ptv_*)
- Kalendertag: ~12 Kommandos
- Patientenliste: ~12 Kommandos
- Sammelrechnung: ~17 Kommandos
- Marcumarplan: ~7 Kommandos
- Arbeitsmedizin: ~8 Kommandos
- Warenbestellung: ~6 Kommandos
- Medikamentenetikett: ~3 Kommandos
- ohne (Steuerkommandos): ~3 Kommandos
- Patient (Karteieinträge): ~4 Kommandos
