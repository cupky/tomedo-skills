# Vollständiger Katalog: KeyPath-Kommandos

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Art → KeyPath).
Stand: März 2026.

---

## Konzept

KeyPath-Kommandos greifen **direkt auf das interne Datenmodell** von tomedo zu. Sie verwenden die Syntax `$[&objekt.attribut.unterattribut]$`.

**4 Basis-Objekte:**
- `p` — Patient
- `pr` — Privatrechnung
- `besuch` — aktueller Besuch
- `termin` — aktueller Termin

**Wichtiger Hinweis von zollsoft:** KeyPaths sind bewusst nicht vollständig dokumentiert, da sie direkt auf das interne Datenmodell zugreifen, das sich laufend ändert. Der **Konfigurator** unter Admin → Kommandos → KeyPath ist das offizielle Werkzeug zum Erkunden der verfügbaren Attribute.

### KeyPath-Konfigurator (Screenshot: kommandos_bauen.png)

```
┌─────────────────────────────────────────────────────┐
│  Patientennummer: p.  [________]                      │
│  Privatrechnungsnummer: pr.  [________]  von:         │
│  Termin Ident: termin.  [________]  von:              │
│                                                       │
│  $[&  [Muss mit "p" (Patient), "besuch",             │
│       "pr" (Privatrechnung) oder "termin" beginnen]  │
│                                                      ]$ │
│                                                       │
│  Ergebnis: [____________________________]             │
│                                                       │
│  Attribute: [Tabelle mit verfügbaren Attributen]      │
└─────────────────────────────────────────────────────┘
```

Man gibt eine Patientennummer / Rechnungsnummer / Termin-Ident ein, schreibt den KeyPath in das Eingabefeld, und die "Attribute"-Tabelle zeigt die verfügbaren Unterattribute des gewählten Objekts.

---

## Dokumentierte KeyPaths (aus Screenshot)

### Besuch-KeyPaths

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&besuch.abgerechnetForLoggedInUser` | Besuch | | Besuch | Ja/Nein-Feld Besuch 3 – Abgerechnet |
| `&besuch.boolCol1` | Besuch | | Besuch | Ja/Nein-Feld Besuch 1 – J/N Besuch 1 |
| `&besuch.boolCol2` | Besuch | | Besuch | Ja/Nein-Feld Besuch 2 – J/N Besuch 2 |
| `&besuch.dokumentiertForLoggedInUser` | Besuch | | Besuch | Ja/Nein-Feld Besuch 4 – Dokumentiert |
| `&besuch.stringCol1` | Besuch | | Besuch | Textfeld Besuch 1 – Text Besuch 1 |
| `&besuch.stringCol2` | Besuch | | Besuch | Textfeld Besuch 2 – Haus |

### Patient: Mutterpass-KeyPaths

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&p.aktuellerMutterpass.entbindungstermin` | Patient | ✓ | Mutterp... | Entbindungstermin aus dem aktuellen Mutterpass. Im aktuellen Mutterpass ist dieser immer synchron mit dem |
| `&p.aktuellerMutterpass.entbindungsterminKorr` | Patient | ✓ | Mutterp... | Berechneter Entbindungstermin aus dem |
| `&p.aktuellerMutterpass.gravida` | Patient | ✓ | Mutterp... | Gravida aus dem aktuellen Mutterpass |
| `&p.aktuellerMutterpass.letzteRegel` | Patient | ✓ | Mutterp... | Datum der letzten Periode aus dem aktuellen Mutterpass |
| `&p.aktuellerMutterpass.mpassText_datekonzeption` | Patient | ✓ | Mutterp... | Konzeptionstermin aus dem aktuellen Mutterpass |
| `&p.aktuellerMutterpass.mpassText_terminZyklus2` | Patient | ✓ | Mutterp... | Durchschnittliche Dauer der Regelblutung aus dem |
| `&p.aktuellerMutterpass.para` | Patient | ✓ | Mutterp... | Para aus dem aktuellen Mutterpass |
| `&p.aktuellerMutterpass.zyklusdauer` | Patient | ✓ | Mutterp... | Durchschnittliche Dauer des Menstruationszyklus aus |

### Patient: Patientendetails-KeyPaths

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&p.patientenDetails.boolCol1` | Patient | ✓ | Patient | Ja/Nein-Feld Patient 1 – J/N Patient 1 |
| `&p.patientenDetails.boolCol2` | Patient | ✓ | Patient | Ja/Nein-Feld Patient 2 – J/N Patient 2 |
| `&p.patientenDetails.datenTransferProxy.erlaubtMassenTransfer` | Patient | ✓ | Patient | Einverständnis massenhaftes setzen von |
| `&p.patientenDetails.freitext` | Patient | ✓ | Patient | Freitext aus den Patientendetails |
| `&p.patientenDetails.kilometerZumWohnort` | Patient | ✓ | Patient | Entfernung zwischen Patientenwohnsitz und Praxis |
| `&p.patientenDetails.stringCol1` | Patient | ✓ | Patient | Textfeld Patient 1 – Betreuer |
| `&p.patientenDetails.stringCol2` | Patient | ✓ | Patient | Textfeld Patient 2 – Vollmacht |
| `&p.patientenDetails.stringCol3` | Patient | ✓ | Patient | Textfeld Patient 3 – Text |
| `&p.patientenDetails.stringCol4` | Patient | ✓ | Patient | Textfeld Patient 4 – Text |

### Patient: ePA-Datenschutz-KeyPaths

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&p.patientenDetails.ensuredEpaDatenschutzAngaben.allowsEpaArztbriefe` | Patient | ✓ | EPA | EPA-Nutzung – Erlaubnis Arztbriefe hochzuladen |
| `&p.patientenDetails.ensuredEpaDatenschutzAngaben.allowsEpaGeneral` | Patient | ✓ | EPA | EPA-Nutzung – allgemeine Erlaubnis |
| `&p.patientenDetails.ensuredEpaDatenschutzAngaben.allowsEpaLaborbefund` | Patient | ✓ | EPA | EPA-Nutzung – Erlaubnis Laborbefunde hochzuladen |
| `&p.patientenDetails.ensuredEpaDatenschutzAngaben.wantsEpaBmp` | Patient | ✓ | EPA | EPA-Nutzung – Erlaubnis BMP hochzuladen |
| `&p.patientenDetails.ensuredEpaDatenschutzAngaben.wantsEpaEau` | Patient | ✓ | EPA | EPA-Nutzung – Erlaubnis eAU hochzuladen |

### Patient: Mutterpass aus letztem Mutterpass

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&p.patientenDetails.schwangerschaftsdetails.letzterMutterpass.mpassText_EpiGebDatum` | Patient | ✓ | Mutterp... | Tatsächlicher Geburtstermin aus letztem Mutterpass |

### Patient: Weitere Ärzte

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.nachname.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Nachname |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.praxiskontakt.adresse.ort.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Ort |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.praxiskontakt.adresse.plz.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Postleitzahl |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.praxiskontakt.adresse.strasse.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Straße |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.praxiskontakt.fax.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Faxnummer |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.praxiskontakt.telefon.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Telefonnummer |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.titel.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Titel |
| `&p.patientenDetails.weitereAerzteAsSortedArray.arzt.vorname.@firstObject` | Patient | ✓ | Patient | Weitere Ärzte, erster Eintrag – Vorname |

### Privatrechnung-KeyPaths

| KeyPath | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|
| `&pr.abrechnenderArzt.nachname` | Patient | | Privatrec... | Nachname des abrechnenden Arztes der Rechnung |
| `&pr.abrechnenderArzt.vorname` | Patient | | Privatrec... | Vorname des abrechnenden Arztes der Rechnung |
| `&pr.bezahlt` | Patient | | Privatrec... | Bezahlt-Status der Rechnung – 0 bei unbezahlt, 1 |

---

## Statistik

**Gesamt: ~40 dokumentierte KeyPaths** (aus 1 Screenshot-Seite)

**Hinweis:** Die tatsächliche Anzahl verfügbarer KeyPaths ist deutlich höher. Der Konfigurator (Admin → Kommandos → KeyPath) erlaubt die Exploration ALLER Attribute des Datenmodells über die "Attribute"-Tabelle. Die hier dokumentierten sind die von zollsoft in der Kommandoliste explizit aufgeführten.

### Wichtige Muster:
- `@firstObject` — Zugriff auf das erste Element einer Sammlung (z.B. erster weiterer Arzt)
- Verschachtelte Pfade: `p.patientenDetails.ensuredEpaDatenschutzAngaben.allowsEpaGeneral`
- Boolean-Felder: `boolCol1/2` liefern 0 oder 1
- String-Felder: `stringCol1-4` liefern Freitext

---
---

# Vollständiger Katalog: Bild-Kommandos

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Art → Bild).
Stand: März 2026.

---

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| anhang | ✓ | Patient | | Patient | Fügt die im Brief-erstellen-Fenster über den Anhang-Button ausgewählten Anhänge/Bilder ein |
| bLogo | ✓ | Betriebsstätte | | Praxis | Gibt das in der Betriebsstättenverwaltung hinterlegte Logo aus |
| bilder | | Patient | ✓ | Patient | Fügt Bilder aus allen selektierten Karteieinträgen ein |
| pr_qrcode_ueberweisung | | Privatrechnung | | Privatrec... | EPC-standardisierter QR-Code zum Begleichen des Restbetrags der Rechnung mittels SEPA-Überweisung. Der Code kann von gängigen Online-Banking-Apps eingelesen werden. Als Verwendungszweck wird die Rechnungsnummer übermittelt. IBAN und Empfänger werden vorrangig vom Konto bzw. der Kostenstelle der Rechnung genommen. Wenn dort nichts gültiges angegeben ist, werden die Daten der Betriebsstätte verwendet |
| pr_zahlungsbeleg_qrcode_tse | ✓ | Privatrechnung | | Privatrec... | QR-Code für Kassenbucheinträge die in einem Kassenbuch das an eine TSE angeschlossen ist erzeugt wurden |
| qrCode | ✓ | ohne | ✓ | Steuerko... | Wandelt Text in einen QR-Code um |
| unterschrift | | Nutzer | ✓ | Praxis | Fügt Unterschrift-Bild aus Nutzerverwaltung ein. Platzhalter wird nur bei Briefen und erst bei Klick auf Drucken ersetzt. (Auslösezeitpunkt: Drucken) |
| unterschriftArzt | | Nutzer | ✓ | Praxis | Fügt Unterschrift-Bild aus Nutzerverwaltung ein |

**Gesamt: 8 Bild-Kommandos**

---
---

# Vollständiger Katalog: PDF-Kommandos

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Art → pdf).
Stand: März 2026.

PDF-Kommandos werden zur Übernahme von Karteieintrags-Daten in PDF-Formulare verwendet.
Alle haben Kontext "Patient".

---

| Name | Themen | Beschreibung |
|---|---|---|
| ana | Karteiein... | Übernahme letzter Anamnese-Eintrag |
| bef | Karteiein... | Übernahme letzter Befund-Eintrag |
| d1 | Diagnosen | 1. Diagnosetext aus Selektion in Kartei |
| d1c | Diagnosen | 1. Diagnose-Code aus Selektion in Kartei (ohne Punkt) |
| d2 | Diagnosen | 2. Diagnosetext aus Selektion in Kartei |
| d2c | Diagnosen | 2. Diagnose-Code aus Selektion in Kartei (ohne Punkt) |
| d3 | Diagnosen | 3. Diagnosetext aus Selektion in Kartei |
| d3c | Diagnosen | 3. Diagnose-Code aus Selektion in Kartei (ohne Punkt) |
| d4 | Diagnosen | 4. Diagnosetext aus Selektion in Kartei |
| d4c | Diagnosen | 4. Diagnose-Code aus Selektion in Kartei (ohne Punkt) |
| d5 | Diagnosen | 5. Diagnosetext aus Selektion in Kartei |
| d5c | Diagnosen | 5. Diagnose-Code aus Selektion in Kartei (ohne Punkt) |
| dias1 | Diagnosen | 1. Diagnose-Sicherheit aus Selektion in Kartei |
| dias2 | Diagnosen | 2. Diagnose-Sicherheit aus Selektion in Kartei |
| dias3 | Diagnosen | 3. Diagnose-Sicherheit aus Selektion in Kartei |
| dias4 | Diagnosen | 4. Diagnose-Sicherheit aus Selektion in Kartei |
| dias5 | Diagnosen | 5. Diagnose-Sicherheit aus Selektion in Kartei |
| seitenlok1 | Diagnosen | 1. Diagnose-Seitenlokalisation aus Selektion in Kartei |
| seitenlok2 | Diagnosen | 2. Diagnose-Seitenlokalisation aus Selektion in Kartei |
| seitenlok3 | Diagnosen | 3. Diagnose-Seitenlokalisation aus Selektion in Kartei |
| seitenlok4 | Diagnosen | 4. Diagnose-Seitenlokalisation aus Selektion in Kartei |
| seitenlok5 | Diagnosen | 5. Diagnose-Seitenlokalisation aus Selektion in Kartei |
| the | Karteiein... | Übernahme letzter Therapie-Eintrag |

**Gesamt: 23 PDF-Kommandos**
