# LLM-Toolebene: Kommandos im KI-Kontext

> Teil des Skills `tomedo-kommandos`. Der Navigator ist `SKILL.md`.

---

**Belegbasis:** Export der tomedo-LLM-Tool-Definitionen (09/2026, 112 Funktionsdefinitionen im Function-Calling-Format). Ausgewertet wurden Namen, Beschreibungen und Parameterschemata.

**Statusregel für diese Datei:** Alles hier ist **dokumentiert** — es steht so in der Tool-Beschreibung des Herstellers, ist aber **nicht** von uns empirisch geprüft. Der Export ist zudem die Union aller Toolsets (Kartei-Chat, Support-Chat, Dental), nicht das Kontextabbild eines einzelnen Chats. **Welche dieser Tools im KarteiChat tatsächlich exponiert sind, ist unbelegt.** Vor produktivem Einsatz Sonde fahren (siehe `karteichat-prompting/references/toolinventar-und-hebel.md`, §7).

---

## 1 · Drei Pfade, auf denen ein Kommando ausgewertet werden kann

| Pfad | Wer wählt das Kommando? | Wer wertet aus? | Deterministisch |
|---|---|---|---|
| **A — Eingabefeld** | Mensch (fügt `$[…]$` in den Chat-Prompt ein) | Client, rund eine Sekunde nach dem Einfügen | ja, sichtbar prüfbar |
| **B — `run_briefkommando`** | **Modell** | Server im Patientenkontext, Ergebnis kommt als Tool-Antwort zurück | nein |
| **C — `LLMToolCreateBriefkommando`** | Modell erzeugt ein **neues** Kommando aus Name + Wert | – der Wert *ist* Modelloutput | nein |

Dazu `list_briefkommandos`: liefert Name, Beschreibung und Kontext aller Kommandos, wertet ausdrücklich **nicht** aus.

**Regel:** Produktionskritische Werte gehören auf Pfad A. Pfad B verschiebt die Kommando- und Argumentwahl in das Modell und damit in dieselbe Fehlerzone, für die der Anker-Fehlerkatalog in `karteichat-prompting` gilt.

### Pfad B im Detail

`run_briefkommando(kommando)` — „wertet ein oder mehrere Briefkommandos im Kontext des aktuellen Patienten aus". Mehrere Kommandos dürfen in einem String stehen. In der Tool-Beschreibung nennt der Hersteller als Beispiele `$[pv]$`, `$[pn]$`, `$[pa]$`, `$[if_frau Frau Herr]$`, `$[d E dd.MM.yyyy BES]$` — also genau die Syntax aus `references/text-kommandos.md` und `references/konfiguratoren-steuerkommandos.md`, ohne Abweichung.

### Pfad C im Detail

`LLMToolCreateBriefkommando(command, value)` — erzeugt ein Kommando, das „nur im Kontext des Chats (z.B. für die folgenden Einträge einer laufenden Aktionskette)" existiert und nicht darüber hinaus. Damit ist erstmals die Richtung *LLM füllt einen Platzhalter, die Struktur bleibt in tomedo* technisch vorhanden. Zwei Auflagen aus der Beschreibung:

- Der `value` darf keine unaufgelösten Platzhalter oder Kommandos mehr enthalten.
- Er darf keine Quellenverweise enthalten (§3).

Das Kommando wird **ohne** `$`-Zeichen angegeben.

---

## 2 · `run_briefkommando` als Test-Harness

Praktisch der wichtigste Punkt dieser Datei. Eine Kommando-Variante zu prüfen erforderte bisher: Briefvorlage bauen, Patient öffnen, Brief erzeugen, Ergebnis ansehen. Über Pfad B lässt sich eine Variante direkt am lebenden Patientenkontext durchprobieren.

Kandidaten aus unserem offenen Bestand:

- `$[formularEintrag <formulartyp> <bezeichner> d]$` — Feldnamen matchen exakt; Varianten mit und ohne Leerzeichen, mit und ohne Anführungszeichen
- `$[karteiEintragWert FOR text _ N -1]$` — Verhalten des fünften Arguments bei mehreren FOR-Einträgen
- Unterstrich-Felder: Rohübergabe gegen Quotierung
- Matrix-Rückgaben `{ZeileN=SpalteM}` gegen berechnete Score-Felder

**Grenzen des Harness:** Pfad B ist modellvermittelt. Das Modell kann ein Argument stillschweigend korrigieren, ein Kommando durch ein ähnliches ersetzen oder ein Ergebnis paraphrasieren. Ein Testergebnis ist deshalb nur belastbar, wenn

1. das Kommando **wörtlich** im Auftrag steht und die Rückgabe **wörtlich und unkommentiert** verlangt wird,
2. mindestens ein Kontrolllauf mit einem Kommando gefahren wird, dessen Ergebnis unabhängig bekannt ist,
3. ein negativer Kontrolllauf mit bewusst falscher Syntax mitläuft — er muss fehlschlagen, nicht „hilfsbereit" ein Ergebnis liefern.

Ohne diese drei Kontrollen ist der Harness eine Fehlerquelle statt einer Messung.

---

## 3 · Quellenverweise: das Ident-Format

Der Karteikontext eines KI-Chats trägt die Idents mit. Das Modell zitiert sie regulär im Format `[1235]` bzw. `[&diag1224]`; für ePA-Dokumente ist `[&epadoc<token>]` dokumentiert.

Vier schreibende Tools — Karteieintrag anlegen, Karteieintrag bearbeiten, Formular öffnen und vorbefüllen, Briefkommando erzeugen — verlangen gleichlautend, dass der übergebene Inhalt **keine** solchen Verweise mehr enthält. Für unsere Zwecke:

- Im **Prüflauf** ist ein erzwungener Quellen-ID-Zwang der schärfste verfügbare Fabrikationsdetektor.
- Im **produktiven** Lauf, dessen Output in Kartei, Formular oder Brief landet, müssen die IDs raus.

---

## 4 · Präzisionsfalle bei Idents

`LLMToolCreateFormular` warnt ausdrücklich: die Formular-ID ist als **String** zu übergeben, „NIEMALS als Zahl: Eine Zahl dieser Länge wird beim Verarbeiten gerundet (z.B. zu 1.29...e+17) und zeigt dann auf ein anderes oder gar kein Formular".

Das ist keine Eigenheit der Formulare, sondern eine Eigenschaft 18-stelliger tomedo-Idents in jeder JSON-Verarbeitung mit Double-Zahlen. Gilt gleichermaßen für Karteieintrags-Idents in eigenen Skripten, Exporten und Auswertungen. Idents immer als String führen.

---

## 5 · Fragen-zu-Kommando-Zuordnung

`LLMToolMatchBriefkommandosAgent` nimmt eine JSON-Liste im Format `[{'id': 1234, 'frage': '…'}, …]` und ordnet jeder Frage ein passendes Briefkommando zu.

Anwendungsfall bei uns: bestehende Dialogfragen-Kataloge — etwa aus Textbaustein-Generatoren — gegen den Kommando-Bestand spiegeln, um Fragen zu finden, die sich automatisch befüllen ließen statt abgefragt zu werden. Auflage: der Sub-Agent „sieht den bisherigen Chatverlauf nicht", der Auftrag muss selbsttragend sein.

---

## 6 · Was die Toolebene **nicht** ändert

- Die Kommando-Syntax selbst ist unverändert; alle Referenzdateien dieses Skills gelten unverändert.
- Die kontextabhängigen Operatornamen (`zs_equals` gegen `zsEquals` gegen deutsche UI-Labels) bleiben, wie sie sind.
- Es gibt **kein** Tool, das Briefvorlagen, Aktionsketten oder Textbausteine anlegt. Der Bau bleibt Handarbeit im Konfigurator.

---

*Referenz zu `tomedo-kommandos`, Stand 2026-09-10. Belegbasis: Tool-Definitions-Export 09/2026. Alle Aussagen **dokumentiert**, keine empirisch geprüft. Kernaussage: Kommandos werden im KI-Kontext auf drei verschieden zuverlässigen Pfaden ausgewertet — Anker gehören ins Eingabefeld, `run_briefkommando` ist ein Test-Harness mit Kontrollpflicht.*
