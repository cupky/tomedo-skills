# Vollständiger Katalog: Text-Kommandos

Extrahiert aus der tomedo-Oberfläche (Admin → Kommandos → Kommandos nach Art → Text).
Stand: März 2026. Sortiert alphabetisch nach Name.

Spalten: **Name** | **Parameter** (✓ = hat Parameter) | **Kontext** | **iOS** (✓ = iOS-fähig) | **Themen** | **Beschreibung**

---

## A

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| a | ✓ | Patient | | Patient | Anrede-Platzhalter für Briefe, um Fallunterscheidung nach Empfänger und Geschlecht von |
| abZeichen | ✓ | ohne | | Steuerko... | Platzhalter benötigt mindestens zwei Argumente: eine natürliche Zahl n und ein auszuführendes Kommando (evtl. mit Argumenten). Das Ergebnis des Kommandos wird ab zum n-ten Zeichen ausgegeben |
| abgearbeiteTodos | | Besuch | | Besuch | Abgearbeitete ToDos des Besuchs |
| abrechnenderArzt_name | | Patient | | Patient | Name des abrechnenden Arztes bezogen auf den Leistungserbringer-Arzt, der im Neuer- |
| adressfeld_absender | | Patient | ✓ | Patient | Mehrzeiliges Feld für Arztstempel oder Betriebsstätten-Anschrift |
| adressfeld_empfaenger | | Brief | | Brief | Mehrzeiliges Empfänger-Feld (DIN 5008), wie in Brief-Fenster vorgegeben. Nur für |
| adressfeld_empfaenger_neutral | | Brief | ✓ | Brief | geschlechterneutrale Variante von adressfeld_empfaenger, d.h. ohne Frau oder Herrn |
| adressfeld_facharzt | | Patient | | Patient | Mehrzeiliges Adressfeld des in den Patientendetails hinterlegten Facharztes |
| adressfeld_folgearzt | | Patient | | Patient | Mehrzeiliges Adressfeld des in den Patientendetails hinterlegten Folgearztes |
| adressfeld_hauptversicherter | | Patient | | Patient | Mehrzeiliges Adressfeld des in den Patientendetails hinterlegten Hauptversicherten |
| adressfeld_hausarzt | | Patient | | Patient | Mehrzeiliges Adressfeld des in den Patientendetails hinterlegten Hausarztes |
| adressfeld_patient | | Patient | | Patient | Mehrzeiliges Adressfeld für den Patienten |
| adresszeile_absender | | Patient | | Patient | Anschrift der Betriebsstätte in einer Zeile, separiert durch Bullet-Zeichen (Nicht-PDF-Anschrift) |
| adresszeile_absender2 | | Patient | | Patient | Anschrift der Betriebsstätte in einer Zeile, separiert durch \|-Zeichen |
| agkn | | Patient | | Patient | Arbeitgeber: Name der Kontaktperson |
| agn | | Patient | | Patient | Arbeitgeber: Name |
| ago | | Patient | | Patient | Arbeitgeber: Ort |
| agp | | Patient | | Patient | Arbeitgeber: PLZ |
| ags | | Patient | | Patient | Arbeitgeber: Straße |
| agtel | | Patient | | Patient | Arbeitgeber: Telefonnummer |
| agz | | Patient | | Patient | Arbeitgeber: Adresszusatz |
| aktiveHZVTeilnahmen | | Patient | | Patient | Alle aktiven HÄVG/mediverbund-Teilnahmen, so wie in tomedo hinterlegt. Es wird keine |
| aktiveSelektivvertragsTeilnahmen | ✓ | Patient | | Patient | Mit diesem Platzhalter können alle Selektivvertragsteilnahmen eines Patienten als kommaseparierte Liste ausgegeben werden. Argument: I = inklusive der |
| aktuellerTerminInfofeld | | Patient | | Termine | Infofeld des heutigen Termins |
| aktuellerTodoRaum | | Patient | | Patient | Raumkürzel des aktuellen ToDos des aktiven Patienten |
| aktuellesTodo | | Patient | | Patient | ToDo-Name des aktuellen ToDos |
| allergien | ✓ | Patient | | Patient | Mit diesem Platzhalter kann man die Allergien des ausgewählten Patienten auflisten. Es werden alle Karteieinträge berücksichtigt, die den Medientyp 'Allergie' besitzen. Argument: K |
| anaesthesieGesamtDosis | ✓ | Patient | | Formulare | Summe der Dosen einer Zeile im Anästhesie Custom- |
| anaesthesieProtokollAnaesthesiezeit | ✓ | Patient | | Formulare | Anästhesiezeit in Minuten aus dem Anästhesie Custom- |
| anaesthesieProtokollOPZeit | ✓ | Patient | | Formulare | OP-Zeit in Minuten aus dem Anästhesie Custom- |
| anerkennungsbescheid | ✓ | Patient | | Psychot... | Briefkommando zur Abfrage relevanter Informationen vom aktuellen Anerkennungsbescheid |
| anforderungsident | | Laborbefund | | Labor | Anforderungsident (Nicht bei kumulativ oder chronologisch!) |
| anr | ✓ | Privatrechnung | | Privatrec... | Anrede-Bastel-Kommando für Privatrechnung |
| anrede | | Patient | | Patient | Anrede wie im Brief-Fenster vorgegeben. → Wird im Serienbrief angepasst — |
| anschrift_BG | | Patient | | Patient | Berufsgenossenschaft (BG): Mehrzeilige Anschrift für DOCX-Brief |
| anschrift_BG2 | | Patient | | Patient | Berufsgenossenschaft (BG): Mehrzeilige Anschrift für PDF-Formular |
| anschriftenKopf_empfaenger | | Brief | | Brief | Kopfbereich der Anschrift des Empfängers |
| ansprechpartner_mail | | Patient | | Patient | Nur für Patiententyp "Firma/Arbeitgeber": E-Mail-Adresse des Ansprechpartners |
| ansprechpartner_name | | Patient | | Patient | Nur für Patiententyp "Firma/Arbeitgeber": Name des Ansprechpartners |
| ansprechpartner_tel | | Patient | | Patient | Nur für Patiententyp "Firma/Arbeitgeber": Telefonnummer des Ansprechpartners |
| anstehendesTodo | | Besuch | | Besuch | Nächstes anstehendes ToDo des Besuchs |
| anzahlTabelleneintraege | | ohne | | Steuerko... | Anzahl der Einträge der Tabelle. Kann in allen internen Vorlagen zum Drucken einer Tabelle |
| anzahlTabelleneintraege mit | ✓ | ohne | | Steuerko... | Wie anzahlTabelleneintraege, allerdings mit einer Bedingung der Form <Name der |
| apsyTherapieArt | | Patient | | Psychot... | aPSY: Gibt die Art der Therapie (Einzel- oder Gruppen-/Kombitherapie) zurück |
| apsyTherapieBeendigungsziffer | | Patient | | Psychot... | aPSY: Gibt die Beendigungsziffer der Therapie zurück |
| apsyTherapieBeginn | ✓ | Patient | | Psychot... | aPSY: Datum des Therapiebeginns aus dem Formularkontext |
| apsyTherapieDiagnosen | ✓ | Patient | | Psychot... | aPSY: <n>te Diagnose der Therapie |
| apsyTherapieEnde | | Patient | | Psychot... | aPSY: Datum des Therapieendes aus dem Formularkontext |
| apsyTherapieIsKJP | | Patient | | Psychot... | aPSY: Rückgabe, ob die Therapie eine Kinder-/Jugendtherapie ist |
| apsyTherapieVerfahrensCode | ✓ | Patient | | Psychot... | aPSY: <n>ter Verfahrenscode der Therapie (optional: Index, Standard: 0) |
| arbeitsplatz | | Patient | | Betriebs... | aktiver Arbeitsplatz-Kürzel |
| arztkuerzel | | Patient | | Brief | Kürzel des Leistungserbringer-Arztes, wie im Neuer-Brief-Fenster angegeben, bzw. des Arztes der Rechnung / des Besuchs |
| arztname | | Patient | | Brief | Name des Leistungserbringer-Arztes, wie im Neuer-Brief-Fenster angegeben, bzw. des Arztes der Rechnung / des Besuchs |
| arztstempel | | Patient | | Patient | Übernimmt den Stempel des Abrechnenden Arztes. (Nadeldrucker-Version) |
| arztstempelLeistungserbringer | | Patient | | Patient | Übernimmt Stempel des Leistungserbringers (sofern dieser ein Arzt ist). (Nadeldrucker-Version) |
| auftragsnummerLabor | | Laborbefund | | Labor | Auftragsnummer des Labors (Nicht bei kumulativ oder chronologisch!) |

## B

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| bUstId | | Patient | | Betriebs... | Umsatzsteuer-Identifikationsnummer der Betriebsstätte |
| bbank | | Betriebsstätte | | Betriebs... | Betriebsstätte: Bank-Name |
| bbic | | Betriebsstätte | | Betriebs... | Betriebsstätte: Bank-BIC |
| bemail | | Betriebsstätte | | Betriebs... | Betriebsstätte: E-Mail |
| bereich | ✓ | ohne | | Steuerko... | Das Ergebnis eines Kommandos in einem definierten Bereich bezüglich der Zeichenanzahl ausgeben |
| beruf | | Patient | | Patient | Beruf des Patienten |
| berufsinfo_abteilung | | Patient | | Patient | Arbeitsmedizin: Abteilung |
| berufsinfo_arbeitsunfaehig | | Patient | | Patient | Arbeitsmedizin: 1 wenn arbeitsunfähig, 0 sonst |
| berufsinfo_ausbildung | | Patient | | Patient | Arbeitsmedizin: Ausbildung des Patienten |
| berufsinfo_berufsunfaehig | | Patient | | Patient | Arbeitsmedizin: 1 wenn berufsunfähig, 0 sonst |
| berufsinfo_erwerbsgemindert | | Patient | | Patient | Arbeitsmedizin: 1 wenn erwerbsgemindert, 0 sonst |
| berufsinfo_fuehrerscheinnummer | | Patient | | Patient | Arbeitsmedizin: Führerscheinnummer des Patienten |
| berufsinfo_personalnummer | | Patient | ✓ | Patient | Arbeitsmedizin: Personalnummer |
| berufsinfo_schichtarbeit | | Patient | ✓ | Patient | Arbeitsmedizin: Schichtarbeit |
| bes_adresse | | Patient | | Patient | Patient: Adresse |
| bes_gebDatum | | Patient | | Patient | Patient: Geburtsdatum |
| bes_patient | | Patient | ✓ | Patient | Name des Patienten mit Anrede (bei Erwachsenen) |
| besuchAnkunftZeit | | Besuch | ✓ | Besuch | Beginn des Besuchs |
| besuchBehandler_daleUvNr | | Besuch | ✓ | Besuch | DALE-UV-Nummern aller Behandler des derzeitigen Besuchs, kommasepariert |
| besuchGegangenZeit | | Besuch | | Besuch | Ende des Besuchs |
| besuchHauptbehandler_Hauptfachgruppe | | Besuch | | Besuch | Hauptbehandler des aktuellen Besuchs: Hauptfachgruppe |
| besuchHauptbehandler_fachgruppen | | Besuch | | Besuch | Hauptbehandler des aktuellen Besuchs: Fachgruppen, kommasepariert |
| besuchHauptbehandler_nachname | | Besuch | | Besuch | Hauptbehandler des aktuellen Besuchs: Nachname |
| besuchHauptbehandler_titel | | Besuch | | Besuch | Hauptbehandler des aktuellen Besuchs: Titel |
| besuchHauptbehandler_vorname | | Besuch | | Besuch | Hauptbehandler des aktuellen Besuchs: Vorname |
| besuchInfo | | Besuch | | Besuch | Info-Text zum aktuellen Besuch |
| besuchTodos | | Besuch | | Besuch | ToDos zum Besuch |
| besuchTotalTodosOvertimeForCritical | | Besuch | | Besuch | Gesamtzeit, die die ToDos eines Besuchs überzogen wurden (geplante Zeit ist die kritische Zeit) |
| besuchTotalTodosOvertimeForWarning | | Besuch | | Besuch | Gesamtzeit, die die ToDos eines Besuchs überzogen wurden (geplante Zeit ist die Warnzeit) |
| besuchUeberweiser_anrede | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Anrede (Radiologenmodul) |
| besuchUeberweiser_fachgebiet | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Fachgebiet (Radiologenmodul) |
| besuchUeberweiser_fax | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: FAX (Radiologenmodul) |
| besuchUeberweiser_nachname | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Nachname (Radiologenmodul) |
| besuchUeberweiser_ort | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Ort (Radiologenmodul) |
| besuchUeberweiser_plz | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: PLZ (Radiologenmodul) |
| besuchUeberweiser_strasse | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Straße + Hausnummer (Radiologenmodul) |
| besuchUeberweiser_titel | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Titel (Radiologenmodul) |
| besuchUeberweiser_vorname | | Besuch | | Besuch | Überweiser des aktuellen Besuchs: Vorname (Radiologenmodul) |
| besuchUntersuchungModalitaet | | Besuch | | Besuch | Untersuchungsmodalität des Besuchs (Radiologenmodul) |
| besuchUntersuchungRegion | | Besuch | | Besuch | Untersuchungsregion des aktuellen Besuchs (Radiologenmodul) |
| besuch_ident | | Besuch | | Besuch | Besuch: eindeutige ident des Besuchs |
| besuch_textfeld1 | | Besuch | | Besuch | Text aus dem Text-Feld Besuch 1 |
| besuch_textfeld2 | | Besuch | | Besuch | Text aus dem Text-Feld Besuch 2 |
| bestellung_adressfeld | | Warenbestellung | | Einkauf | Adressfeld des Händlers der Bestellung |
| bestellung_email | | Warenbestellung | | Einkauf | E-Mail des Händlers der Bestellung |
| bestellung_kundennummer | | Warenbestellung | | Einkauf | Kundennummer des Händlers der Bestellung |
| bfax | | Betriebsstätte | | Betriebs... | Betriebsstätte: Faxnummer |
| bgaktenzeichen | | Patient | | Patient | Aktenzeichen der Berufsgenossenschaft (BG) für den Patienten |
| bgzeile | | Patient | | Patient | Berufsgenossenschaft (BG) des Patienten: Anschrift als Zeile, z.B. für Formulare |
| biban | | Betriebsstätte | | Betriebs... | Betriebsstätte: Bank-IBAN ohne führendes DE (genauer: ohne die ersten zwei Zeichen) |
| biban2 | | Betriebsstätte | | Betriebs... | Betriebsstätte: Bank-IBAN ohne formatierende Leerzeichen |
| biban3 | | Betriebsstätte | | Betriebs... | — |
| bisZeichen | ✓ | ohne | | Steuerko... | Platzhalter benötigt mindestens zwei Argumente: eine natürliche Zahl n und ein auszuführendes Kommando (evtl. mit Argumenten). Das Ergebnis des Kommandos wird bis zum n-ten Zeichen ausgegeben |
| bk | | Betriebsstätte | | Betriebs... | Betriebsstätte: Kürzel |
| bkontoinhaber_adresse | | Betriebsstätte | | Betriebs... | Adresse des Kontoinhabers – wenn kein abweichender Kontoinhaber angegeben ist, wird die Adresse der Betriebsstätte zurückgegeben |
| bkontoinhaber_name | | Betriebsstätte | | Betriebs... | Name des Kontoinhabers – wenn kein abweichender Kontoinhaber angegeben ist, wird der Name der Betriebsstätte zurückgegeben |
| bkopf | | Patient | | Betriebs... | Briefkopf: Übernimmt gesamten Briefkopf aus Betriebsstätte |
| bkopfLine | ✓ | Patient | | Betriebs... | Briefkopf, einzelne Zeilen: Argument = Zeilen-Nr beginnend mit 1 |
| bn | | Betriebsstätte | | Betriebs... | Betriebsstätte: Name |
| bo | | Betriebsstätte | | Betriebs... | Betriebsstätte: Ort |
| bp | | Betriebsstätte | | Betriebs... | Betriebsstätte: Postleitzahl PLZ |
| bratekopf | | Betriebsstätte | | Betriebs... | Betriebsstätte: Komplexkommando für Arztname und Fachgruppen |
| bratekopfLine | ✓ | Betriebsstätte | | Betriebs... | Betriebsstätte/Ärzte/Arzt: Komplexkommando für Arztname und Fachgruppen. Gibt Zeilen einzeln aus. Argument = ZeilenNr beginnend mit 1 |
| bs | | Betriebsstätte | | Betriebs... | Betriebsstätte: Straße und Hausnummer |
| bsFaKopfLine | | Betriebsstätte | | Betriebs... | Betriebsstätte/Anwälte: Komplexkommando für Liste von Namen der Anwälte und zugehöriger Fachanwaltsbezeichnung. Gibt Zeilen einzeln aus. Argument = ZeilenNr beginnend mit 1 |
| bsnr | | Patient | ✓ | Patient | Betriebsstätten-Nummer |
| btel | | Betriebsstätte | | Betriebs... | Betriebsstätte: Telefonnummer |
| bundesland | | Patient | | Betriebs... | Bundesland der Betriebsstätte |
| bwww | | Betriebsstätte | | Betriebs... | Betriebsstätte: Homepage |

## C

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| c | ✓ | Patient | | Karteiein... | Kommando zur Anzahlbestimmung von Karteieinträgen. Syntax: |
| cd_sterilgut_barcode | | Nutzer | | Praxis | Briefkommando, um den Barcode eines Sterilguts zu erhalten |
| cd_sterilgut_charge | | Nutzer | | Praxis | Briefkommando, um die Nummer der Charge eines Sterilguts zu erhalten |
| cd_sterilgut_erstellt_von | | Nutzer | | Praxis | Briefkommando, um den erstellenden Nutzer eines Sterilguts zu erhalten |
| cd_sterilgut_freigegeben_von | | Nutzer | | Praxis | Briefkommando, um den freigebenden Nutzer eines Sterilguts zu erhalten |
| cd_sterilgut_nummer | | Nutzer | | Praxis | Briefkommando, um die Nummer eines Sterilguts innerhalb einer Charge zu erhalten |
| cd_sterilgut_verfallsdatum | | Nutzer | | Praxis | Briefkommando, um das Verfallsdatum eines Sterilguts zu erhalten |
| cd_sterilpackung_barcode | | Nutzer | | Praxis | Briefkommando, das den Barcode einer Sterilpackung zurückgibt |
| cd_sterilpackung_bezeichnung | | Nutzer | | Praxis | Briefkommando, das für eine Sterilcharge die Bezeichnung der zugehörigen Sterilpackung zurückgibt |
| customFormularEintrag | ✓ | Patient | ✓ | Formulare | Obsolet. Nutzen Sie besser das Kommando formularEintrag und den zugehörigen Konfigurator! |

## D

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| d | ✓ | ohne | | Datum | vielseitiges Datum-Kommando (auch für Uhrzeiten) |
| d_geburt | | Patient | | Patient | Schwangerschaftsdetails: Geburtstermin |
| datum | | Patient | | Patient | Datum des Rechners. (Systemdatum) |
| datum | | Kalendertag | | Termine | Datum für ALLE Termine |
| datumTherapiebeginn | | Patient | | Patient | Psychotherapie: Datum des Therapiebeginns (erste Leistung) |
| datumTherapieende | | Patient | | Patient | Psychotherapie: Datum des Therapieendes (letzte Leistung) |
| datum_aktuell | | Patient | | Patient | Datum des Rechners. (Systemdatum) |
| datum_withArgs | ✓ | ohne | | Datum | Anderes Datum von heute ausgehend: <Anzahl Tage> (+/-) |
| diagnosenMitDiagnosesicherheit | | Patient | ✓ | Patient | Ausgabe der aktuellen Scheindiagnosen mit vorgestellter Diagnosesicherheit. Diagnosen mit Diagnosesicherheiten A und Z werden nicht ausgegeben |
| dmp | ✓ | Patient | | DMP | Liest Informationen aus einer DMP-Doku aus |
| dokument | ✓ | ohne | | Praxis | Fügt ein Dokument aus der Dokumentenverwaltung als Bild oder als Text ein. Dafür muss als Parameter der Name des Dokuments angegeben werden |
| druckdatum | | Patiententermine | | Termine | Datum und Uhrzeit des Druckens |
| druckdatum | | Brief | | Brief | Nur Radiologen-Modus / Strenges Druckfreigeben: Fügt beim Drucken eines Arztbriefs das aktuelle Datum ein |
| ds_key | | Patient | | Patient | Der Schlüssel zur Verschlüsselung von PDF-Dateien in E-Mail Anhängen |
| eingeloggt_arzt | | Nutzer | | Praxis | Name des aktiven Nutzers, falls Arzt |
| eingeloggt_betriebsstaette | | Nutzer | | Praxis | Name der aktiven Betriebsstätte (Arbeitsplatz) |
| einleitung | | Patient | | Patient | Konfigurierbarer Einleitungstext für den Arztbrief, unterschieden nach Original/Kopie/Patientenbrief. Anpassung im Einstellungsfenster |
| einleitung2 | | Patient | | Patient | Phrase für Arztbrief mit Alter, z.B.: 'Der 12-jährige Patient' |
| email_empfaenger | | Brief | | Brief | E-Mail-Adresse des Empfängers |
| ersetze | ✓ | ohne | | Steuerko... | Text-Ersetzungen im Ergebnis eines Platzhalters |
| erstaufnahme | | Patient | | Patient | Datum der Erstaufnahme des Patienten |

## E–F

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| facharzt_nachname | | Patient | | Patient | Facharzt: Nachname |
| facharzt_titel | | Patient | | Patient | Facharzt: Titel |
| facharzt_vorname | | Patient | | Patient | Facharzt: Vorname |
| fachgebiet_empfaenger | | Brief | | Brief | Fachgebiet des Empfängers, sofern der Empfänger ein Arzt ist |
| familie | ✓ | Patient | | Patient | Syntax: $[familie <Familienbeziehung(en)> <auszuführender Platzhalter>]$ |
| fax_empfaenger | | Brief | | Brief | Faxnummer des Empfängers |
| folgearzt_nachname | | Patient | | Patient | Folgearzt: Nachname |
| folgearzt_titel | | Patient | | Patient | Folgearzt: Titel |
| folgearzt_vorname | | Patient | | Patient | Folgearzt: Vorname |
| formularEintrag | ✓ | Patient | | Formulare | Mit diesem Platzhalter kann man einzelne Werte aus einem tomedo-Formular auslesen. Es müssen drei Argumente angegeben werden: |
| formularLinks | ✓ | Patient | | Formulare | Erzeugt einen Link für die mit Kürzel angegebenen Patientenformulare, z.B. $[formularLinks PatF-Anamnesebogen PatF-Allgemeine-Beschwerden]$ erzeugt einen Link für die entsprechenden Patientenformulare |
| formularLinksOhneName | ✓ | Patient | | Formulare | Erzeugt einen Link für die mit Kürzel angegebenen Patientenformulare, ohne den Namen der Patientenformulare anzugeben. Mit dem Parameter "fälligeFormulare" werden alle fälligen Patientenformulare eingesetzt |
| frueherkennung_blinkt | | Patient | | Patient | Wenn für den gewählten Besuch der Früherkennungsradar blinkt, gibt dieses Briefkommando 1 zurück, sonst 0 |
| frueherkennung_faellig | ✓ | Patient | | Patient | Gibt aus, ob die im Argument benannte Früherkennung fällig ist für den Patienten. Mögliche Antworten: 1) Fällig 2) Untersuchung bald möglich 3) Erledigt 4) Inaktiv 5) Status unbekannt |
| fusszeile | | Patient | | Patient | Komplex-Kommando für Arztbrief. Falls Serienbrief, dann werden bei Original über 'Nachrichtlich an:' die anderen Empfänger aufgelistet |
| fusszeile2 | | Patient | | Patient | Wie fusszeile, jedoch mit kürzerer Ausgabe |
| fusszeile_vollstaendig | | Patient | | Patient | Wie fusszeile, jedoch werden Kopien bei allen Empfängern aufgelistet |

## G

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| ganzzahlAufrunden | ✓ | ohne | | Steuerko... | Es werden mindestens zwei Argumente benötigt: 1.Argument – eine ganze Zahl oder ein Platzhalter, der eine ganze Zahl liefert, ggf. gefolgt von Argumenten des Platzhalters; letztes – eine positive ganze Zahl, auf deren Vielfache aufgerundet werden soll |
| geschlecht_empfaenger | | Brief | ✓ | Brief | Geschlecht des Empfängers als Buchstabe – W für weiblich, M für männlich, D für divers, X für unbestimmt, U für unbekannt |
| gesetzteMarkerVonGruppe | | Patient | | Patient | Gibt als Komma-separierte Liste alle gesetzten Marker zurück, die zu der gefragten Gruppe gehören |
| gewichtAusLetztemBMI | | Patient | | Patient | Gewicht aus neuestem CustomKarteieintrag mit BMI-Eintrag |
| gk | | Patient | | Patient | Kassenname, Gesetzlich |
| gradDerBehinderung_kurz | | Patient | | Patient | Grad der Behinderung des Patienten – Kurzform: 0,10,20,... |
| gradDerBehinderung_lang | | Patient | | Patient | Grad der Behinderung des Patienten – Langform: 🔳. GdB 40, B |

## H

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| handy_empfaenger | | Brief | | Brief | Handynummer des Empfängers |
| hauptvers_adresse | | Patient | | Patient | Hauptversicherter: Adresse |
| hauptvers_geburtsdatum | | Patient | | Patient | Hauptversicherter: Geburtsdatum |
| hauptvers_name | | Patient | | Patient | Hauptversicherter: Nachname |
| hauptvers_titel | | Patient | ✓ | Patient | Hauptversicherter: Titel |
| hauptvers_verwandtschaft | | Patient | | Patient | Hauptversicherter: Verwandtschaftsverhältnis |
| hauptvers_vorname | | Patient | | Patient | Hauptversicherter: Vorname |
| hauptvers_vsnr | | Patient | | Patient | Hauptversicherter: Versicherungsnummer |
| hausarzt_adresse | | Patient | | Patient | Hausarzt: Adresse |
| hausarzt_fax | | Patient | | Patient | Hausarzt: Fax |
| hausarzt_nachname | | Patient | | Patient | Hausarzt: Nachname |
| hausarzt_name | | Patient | | Patient | Hausarzt: Name (vollständig) |
| hausarzt_ort | | Patient | | Patient | Hausarzt: Ort |
| hausarzt_plz | | Patient | | Patient | Hausarzt: PLZ |
| hausarzt_strasse | | Patient | | Patient | Hausarzt: Straße |
| hausarzt_tel | | Patient | | Patient | Hausarzt: Telefon |
| hausarzt_titel | | Patient | | Patient | Hausarzt: Titel |
| hausarzt_vorname | | Patient | | Patient | Hausarzt: Vorname |
| heilmittelverordnung_abgebrochen | | Patient | | Patient | Gibt an, ob eine Behandlung abgebrochen wurde: 1 für ja, 0 für nein |
| heilmittelverordnung_anzahlStattgefundenerTherapieEinheiten | | Patient | | Patient | Ausgabe der tatsächlich geleisteten Anzahl an Therapieeinheiten der jeweiligen Heilmittelverordnung |
| heilmittelverordnung_anzahlTherapieEinheitenBehandlungsabbruch | | Patient | | Patient | Ausgabe der tatsächlich geleisteten Anzahl an Therapieeinheiten der jeweiligen Heilmittelverordnung im Falle eines Behandlungsabbruchs |
| heilmittelverordnung_anzahlTherapieeinheiten | | Patient | | Patient | Ausgabe der vereinbarten Anzahl an Therapieeinheiten der jeweiligen Heilmittelverordnung |
| heilmittelverordnung_ausstellenderArzt_name | | Patient | | Patient | Ausgabe des Namens des Arztes, der die Heilmittelverordnung ausgestellt hat |
| heilmittelverordnung_ausstellenderArzt_ort | | Patient | | Patient | Ausgabe des hinterlegten Ortes des Arztes, der die Heilmittelverordnung ausgestellt hat |
| heilmittelverordnung_ausstellenderArzt_plz | | Patient | | Patient | Ausgabe der hinterlegten PLZ des Arztes |
| heilmittelverordnung_ausstellenderArzt_strasse | | Patient | | Patient | Ausgabe der hinterlegten Straße des Arztes |
| heilmittelverordnung_behandlungsabbruchAm | | Patient | | Patient | Ausgabe des Abbruchdatums der jeweiligen Heilmittelverordnung |
| heilmittelverordnung_diagnose | | Patient | | Patient | Ausgabe der auf der Heilmittelverordnung hinterlegten Diagnose |
| heilmittelverordnung_therapiebeginn | | Patient | | Patient | Ausgabe des Therapiebeginns für die jeweilige Heilmittelverordnung. Genommen wird der letzte Termin |
| heilmittelverordnung_therapieende | | Patient | | Patient | Ausgabe des Therapieendes für die jeweilige Heilmittelverordnung. Genommen wird der letzte Termin |

## I

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| if | ✓ | ohne | ✓ | Steuerko... | Die Idee dieses Kommandos ist es, ein bereits existierendes Kommando auszuführen, das Ergebnis gegen beliebig viele mögliche Werte zu vergleichen und gegebenenfalls eine alternative Zeichenkette auszugeben. Operatoren: zsEquals, zsNotEqual, zsContains, zsNotContains |
| if_frau | ✓ | Patient | | Patient | geschlechtsspezifisch, Patient. $[if_frau Sehr_geehrte_Frau Sehr_geehrter_Herr]$ |
| if_then | ✓ | ohne | | Steuerko... | Führt ein anderes Kommando aus, das mit einem Vergleichswert verglichen wird. Bei positivem Vergleich wird ein anderes Kommando ausgeführt. Syntax analog zum if-Kommando |
| impfstatus | ✓ | Patient | | Impfung | Erzeugt eine Tabelle mit dem aktuellen Impfstatus |
| impfstatusVorhanden | | Patient | | Patient | Ergibt 1, falls der Impfstatus des Patienten in ImpfDocNE mindestens einen Eintrag hat, ansonsten 0 |
| istMarkerGesetzt | ✓ | Patient | ✓ | Patient | Testet, ob ein bestimmter Marker beim Patienten gesetzt ist. Dafür muss der Name des Markers als Parameter angegeben werden. Ergebnis ist 0 oder 1 |

## K

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| kalender | | Kalendertag | | Termine | Name des Kalenders |
| karteiEintragWert | ✓ | Patient | | Karteiein... | Einzelne Werte aus einem Karteieintrag bekommen (dieses Kommando hieß früher karteiEintragValue_withArgs), mindestens vier Argumente werden benötigt: |
| kartennummerBasisversicherung | | Patient | | Patient | Patient: Nummer der Versichertenkarte der Basisversicherung |
| kartennummerZusatzversicherung | | Patient | | Patient | Patient: Nummer der Versichertenkarte der Zusatzversicherung |
| kasse_ik | | Patient | ✓ | Patient | Kasse: Institutionskennzeichen (Kassennummer) |
| kasse_name | | Patient | ✓ | Patient | Kasse: Name (Logik für Privat oder Gesetzlich) |
| kasse_ort | | Patient | | Patient | Kasse: Ort |
| kasse_plz | | Patient | | Patient | Kasse: PLZ |
| kasse_postfach | | Patient | | Patient | Kasse: Postfach |
| kasse_status | | Patient | | Patient | Status der GKV des Patienten – Ziffer (Abgeleitet aus Kartendaten) |
| kasse_status_string | | Patient | | Patient | Status der GKV des Patienten – Bezeichnung (Abgeleitet aus Kartendaten) |
| kasse_strasse | | Patient | | Patient | Kasse: Straße |
| kb_belegdruck_belegdatum | | Kassenbuch | | Kassenb... | Belegdatum des Kassenbucheintrags |
| kb_belegdruck_belegnummer | | Kassenbuch | | Kassenb... | Belegnummer des Kassenbucheintrags |
| kb_belegdruck_beschreibung | | Kassenbuch | | Kassenb... | Briefkommando, das falls eine Rechnungsnummer existiert, diese und die Patientendient in folgender Form zurückgibt: Re-Nr: .... Pat-Nr: .... oder falls keine Rechnungsnummer existiert den Text zum Kassenbucheintrag |
| kb_belegdruck_betrag | | Kassenbuch | | Kassenb... | Betrag für den Kassenbucheintrag |
| kb_belegdruck_bkopf | | Kassenbuch | | Kassenb... | Briefkopf für den Ersteller des Kassenbucheintrags |
| kb_belegdruck_bkopfArzt | | Kassenbuch | | Kassenb... | Briefkopf für den abrechnenden Arzt der zugehörigen Privatrechnung |
| kb_belegdruck_ersSeriennummer | | Kassenbuch | | Kassenb... | Briefkommando, um die Seriennummer des Kassenbuches eines Kassenbuchbeleges zu erhalten |
| kb_belegdruck_kassenbuchname | | Kassenbuch | | Kassenb... | Name des Kassenbuchs für den Kassenbucheintrag |
| kb_belegdruck_nettobetrag | | Kassenbuch | | Kassenb... | Nettobetrag für den Kassenbucheintrag |
| kb_belegdruck_patientname | | Kassenbuch | | Kassenb... | Patientenname für den Kassenbucheintrag |
| kb_belegdruck_rechnungsnummer | | Kassenbuch | | Kassenb... | Rechnungsnummer, falls der Kassenbucheintrag aus einer Rechnung erzeugt wurde |
| kb_belegdruck_signatur | | Kassenbuch | | Kassenb... | Briefkommando, um die Signatur des Kassenbucheintrages bei Verwendung einer TSE zu erhalten |
| kb_belegdruck_text | | Kassenbuch | | Kassenb... | Text für den Kassenbucheintrag |
| kb_belegdruck_tseSeriennummer | | Kassenbuch | | Kassenb... | Briefkommando, um die Seriennummer der TSE eines Kassenbuches zu erhalten |
| kb_belegdruck_tseTransaktionsBegin | | Kassenbuch | | Kassenb... | Briefkommando, um den Startzeitpunkt der Transaktion eines Kassenbuchbeleges zu erhalten |
| kb_belegdruck_tseTransaktionsEnde | | Kassenbuch | | Kassenb... | Briefkommando, um den Endzeitpunkt der Transaktion eines Kassenbuchbeleges zu erhalten |
| kb_belegdruck_tseTransaktionsNummer | | Kassenbuch | | Kassenb... | Briefkommando, um die Transaktionsnummer eines Kassenbuchbeleges zu erhalten |
| kb_belegdruck_umsatzsteuerAbsolut | | Kassenbuch | | Kassenb... | Umsatzsteuerbetrag für den Kassenbucheintrag |
| kb_belegdruck_umsatzsteuerProzent | | Kassenbuch | | Kassenb... | Umsatzsteuer in Prozent für den Kassenbucheintrag |
| kb_tseQRCodeText | | Kassenbuch | | Kassenb... | Briefkommando, um den QR-Code Text für die Informationen der TSE zu erzeugen. Nur für CustomFormular |
| kbvArztnr | | Patient | ✓ | Formulare | KBV-Header: Lebenslange Arztnummer |
| kbvBereich | | Patient | | Formulare | Abrechnungsbereich des KBV-Headers (auch WOK, VKNr) |
| kbvBsnr | | Patient | ✓ | Formulare | KBV-Header: Betriebsstättennummer |
| kbvDatum | | Patient | | Formulare | KBV-Header: Datum |
| kbvGebDatum | | Patient | | Formulare | KBV-Header: Geburtsdatum des Patienten |
| kbvHeader | | Patient | ✓ | Formulare | KBV-Header |
| kbvHeader_hzv | | Patient | | Formulare | KBV-Header für HZV |
| kbvKassennr | | Patient | | Formulare | KBV-Header: Kassen-Nummer |
| kbvKrankenkasse | | Patient | | Formulare | KBV-Header: Krankenkasse |
| kbvName | | Patient | ✓ | Formulare | KBV-Header: Patientenname, Vor- & Nachname |
| kbvQuartal | | Patient | | Formulare | Gültig-Bis-Datum des KBV-Headers im Format mm/YY |
| kbvStatus | | Patient | | Formulare | KBV-Header: Status |
| kbvVersnr | | Patient | | Formulare | KBV-Header: Versicherten-Nummer |
| koerpergroesseAusLetztemBMI | | Patient | | Patient | Körpergröße aus dem neuesten CustomKarteieintrag mit BMI-Eintrag |
| koerperoberflaeheAusLetztemBMI | | Patient | | Patient | Körperoberfläche, berechnet aus den Daten des letzten CustomKarteieintrags mit BMI-Eintrag |
| kommandorahmen | ✓ | ohne | | Steuerko... | Dieses Kommando benötigt mindestens drei Argumente. Als erstes Argument wird ein auszuführendes Briefkommando angegeben und anschließend gegebenenfalls Argumente dieses auszuführenden Kommandos. Das vorletzte und letzte Argument sind jeweils Text, bei dem Leerzeichen als Unterstrich und \n als Zeilenumbruch dargestellt werden. Liefert die Ausführung des Briefkommandos eine nichtleere Zeichenkette, besteht die Ausgabe aus dem formatierten Text des vorletzten Arguments, daran wird das Ergebnis des Briefkommandos angehängt und schließlich der Text des letzten Arguments. |
| kommandovergleich | ✓ | ohne | | Steuerko... | Es wird getestet, ob zwei Kommandos das gleiche Ergebnis liefern. Die Argumente sind das erste Vergleichskommando, die Trennsequenz "UND" und anschließend das zweite Vergleichskommando. Bei Gleichheit ist das Ergebnis "1", bei Ungleichheit "0" |
| kontingent | | Patient | | Patient | Mit diesem Platzhalter kann man das aktuelle Kontingent einer Psychotherapie auslesen. Die Ausgabe erfolgt in der Form 'Anzahl bisheriger Sitzungen' / 'Gesamtanzahl bewilligter Sitzungen'. Für die zweite Sitzung einer KZT1 ergäbe sich z.B. '2/12' |

## L

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| l | ✓ | Patient | | Leistung... | Leistungen des/der in der Kartei ausgewählten Scheins/(BG-)Rechnung – dieser Platzhalter hat drei Parameter: |
| l_alle | ✓ | Patient | | Leistung... | Alle Leistungen, die in der geöffneten Kartei abgerechnet wurden, wobei sämtliche Scheine und Privatrechnungen berücksichtigt werden. Bis zu vier Parameter |
| l_ohneKartei | ✓ | Patient | | Leistung... | Leistungen des aktiven Scheins/Rechnung (was der aktive Schein des Patienten ist, wird heuristisch von tomedo bestimmt). Bis zu vier Parameter |
| lab | | Laborwertedruck | | Labor | Siehe Reiter Medizinische Dok. → lab |
| labor | | Laborwertedruck | | Labor | Erzeugt eine Tabelle aus den ausgewählten Laborwerten |
| laborBefundeAusgewaehlt | | Patient | | Patient | Ergibt 1, falls Laborbefunde ausgewählt sind, ansonsten 0 |
| laborwert | ✓ | Patient | | Labor | Gibt Informationen zu einem oder mehreren Laborwerten mit dem gleichen Testkürzel aus. Mindestens vier Parameter benötigt: |
| lanr | | Patient | ✓ | Patient | Lebenslange Arztnummer des abrechnenden Arztes |
| lanr2 | | Patient | | Patient | Lebenslange Arztnummer des Leistungserbringers, sofern vorhanden, sonst wird die des abrechnenden Arztes genommen |
| laufendeNummer | ✓ | ohne | ✓ | Praxis | Gibt eine fortlaufende Nummer aus. Als Parameter muss der Kontext angegeben werden (beliebige Zeichenkette ohne Leerzeichen). Mit verschiedenen Kontexten werden verschiedene Zähler angelegt. Stellenanzahl 1–10 oder Wertebereich 'ersteZahl-letzteZahl' |
| leistungsZaehler | ✓ | ohne | | Psychot... / Leistung... | Mit diesem Platzhalter kann man den aktuellen Wert eines Leistungszählers auslesen. Das Kommando liefert nur für psychotherapeutische Praxen mit aktivierter Patientenübersicht Werte. Mögliche Zähler sind z.B. Probatorik, Sprechstunde |
| leistungsgruppeBezeichnung | | Patient | | Patient | Bezeichnung der Leistungsgruppe – funktioniert nur innerhalb eines nach Leistungsgruppen gruppierten Abschnitts |
| letzteChargennummer | | Patient | | Patient | Gibt die letzte hinterlegte Chargennummer (FK 5010 in EBM-Leistung) des Patienten aus |
| letzteLaborwerte | ✓ | Patient | | Labor | Gibt die Laborwerte des letzten Befundes aus. Der erste Parameter ist das Ausgabe-Format. Zweiter Parameter: Trennsequenz, Standard ist ", " |
| letzterBMI | | Patient | ✓ | Patient | BMI aus neuestem CustomKarteieintrag vom Typ 'BMI' |
| letzterBlutdruckDiastolisch | | Patient | | Patient | Diastolischer Blutdruck aus dem neuesten CustomKarteieintrag mit Blutdruck-Eintrag |
| letzterBlutdruckSystolisch | | Patient | | Patient | Systolischer Blutdruck aus dem neuesten CustomKarteieintrag mit Blutdruck-Eintrag |
| listenname | | Patientenliste | | Patient | Name der Patientenliste |

## M

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| med | ✓ | Patient | | Medikam... | Platzhalter muss in Tabelle geschrieben werden. Als Parameter werden die gewünschten Spaltenkürzel angegeben. Verfügbar sind die gleichen Kürzel wie für den Platzhalter medikamentenplan |
| medikamenteVorhanden | | Patient | | Patient | Ergibt 1, falls der Patient einen Medikamentenplan mit mindestens einem Medikament hat, ansonsten 0 |
| medikamentenplan | ✓ | Patient | | Medikam... | Erzeugt eine Tabelle mit dem aktuellen Medikamentenplan |
| mittelwert_ke_wert | ✓ | Patient | | Karteiein... | Dieses Kommando liefert den Mittelwert der Variablen eines Karteieintrags. Argument 1 ist der Name des Karteieintrags und danach eine beliebige Anzahl von Variablennamen. Leere Felder oder Felder mit Inhalten die keine Zahl enthalten werden ignoriert |
| monatAnfang | ✓ | ohne | ✓ | Datum | Erster Tag des aktuellen Monats. Um auf vergangene oder zukünftige Monate zuzugreifen, kann als Argument eine Zahl angegeben werden |
| monatEnde | ✓ | ohne | | Datum | Analog zu monatAnfang |
| mutterpassEintrag | ✓ | Patient | | Mutterp... | Gibt Felder aus dem Mutterpass aus. Als Parameter muss der Feldname angegeben werden. Der kann via Rechtsklick auf das entsprechende Feld im Mutterpass bestimmt werden |

## N

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| nachKommaWert | ✓ | ohne | | Steuerko... | Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis eine Gleitkommazahl enthält. Von dieser Zahl wird der Wert nach dem Komma genommen |
| nachLeistungsgruppenGruppierenAnfang | | Patient | | Patient | Markiert den Beginn eines Abschnitts einer Rechnung, der nach Leistungsgruppen gruppiert werden soll. In einem solchen Bereich funktionieren die Tabellenplatzhalter für Privatrechnungen, sowie die Platzhalter leistungsgruppeBezeichnung, pr_betrag, pr_betragReal und pr_mwst, jeweils bezogen auf die Leistungen der jeweiligen Leistungsgruppe |
| nachLeistungsgruppenGruppierenEnde | | Patient | | Patient | Markiert das Ende eines Abschnitts einer Rechnung, der nach Leistungsgruppen gruppiert werden soll |
| nachname_empfaenger | | Brief | | Brief | Nachname des Empfängers, falls Arzt oder Patient |
| nachrichtText | | Nachricht | | Praxis | Text der gerade betrachteten Nachricht |
| nachrichtenThreadText | | Nachricht | | Praxis | Text aller Nachrichten im ausgewählten Thread separiert durch Absätze |
| name | | Patiententermine | | Termine | Voller Name des Patienten, Version 1 |

## Nutzer-Kommandos

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| nutzerDaleUvNr | | Nutzer | | Praxis | DALE-UV-Nummer des eingeloggten Nutzers |
| nutzerDienstTel | | Nutzer | | Praxis | Telefonnummer (dienstlich) des eingeloggten Nutzers |
| nutzerEmail | | Nutzer | | Praxis | E-Mail des eingeloggten Nutzers |
| nutzerFachgruppen | | Nutzer | ✓ | Praxis | Fachgruppen des eingeloggten Nutzers, kommasepariert |
| nutzerGeschlecht | | Nutzer | | Praxis | Geschlecht des eingeloggten Nutzers als Großbuchstabe |
| nutzerGruppen | | Nutzer | | Praxis | Nutzergruppen, denen der eingeloggte Nutzer zugeordnet ist, durch Komma |
| nutzerHauptfachgruppe | | Nutzer | | Praxis | Hauptfachgruppe des eingeloggten Nutzers |
| nutzerHerrFrau | | Nutzer | | Praxis | Herr oder Frau oder leer, je nach Geschlecht des Nutzers |
| nutzerLanr | | Nutzer | | Praxis | LANR des eingeloggten Nutzers |
| nutzerMobil | | Nutzer | | Praxis | Telefonnummer (mobil) des eingeloggten Nutzers |
| nutzerNachname | | Nutzer | ✓ | Praxis | Nachname des eingeloggten Nutzers |
| nutzerTel | | Nutzer | ✓ | Praxis | Telefonnummer (privat) des eingeloggten Nutzers |
| nutzerTitel | | Nutzer | ✓ | Praxis | Titel des eingeloggten Nutzers |
| nutzerVorname | | Nutzer | ✓ | Praxis | Vorname des eingeloggten Nutzers |
| nutzerkuerzel | | Nutzer | | Praxis | Kürzel des eingeloggten Nutzers |
| nutzername | | Nutzer | | Praxis | Name des eingeloggten Nutzers |

## O

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| ohneWaehrung | ✓ | ohne | | Steuerko... | Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis einen Betrag mit Währung enthält. Davon wird der Betrag ohne Währungszeichen zurückgegeben |
| okfe | ✓ | Patient | | Patient | Abfrage einzelner Informationen aus der oKFE-Dokumentation |
| onlineSprechstundeCode | | Patient | | Patient | Code für die Online-Sprechstunde |
| onlineSprechstundeURL | | Patient | | Patient | URL für den Arzt für die Online-Sprechstunde |
| op_anaesthesist | | Patient | ✓ | OP | OP-Termin: Anästhesist Name |
| op_anaesthesist_kuerzel | | Patient | ✓ | OP | OP-Termin: Nutzerkürzel des Anästhesisten |
| op_infotext | | Patient | ✓ | OP | OP-Termin: Infotext |
| op_operateur_1 | | Patient | ✓ | OP | OP-Termin: Operateur 1 Name |
| op_operateur_1_kuerzel | | Patient | ✓ | OP | OP-Termin: Nutzerkürzel von Operateur 1 |
| op_operateur_2 | | Patient | ✓ | OP | OP-Termin: Operateur 2 Name |
| op_operateur_2_kuerzel | | Patient | ✓ | OP | OP-Termin: Nutzerkürzel von Operateur 2 |
| op_termin_beginn | | Patient | ✓ | OP | OP-Termin: Beginn Datum und Zeit |
| op_termin_datum | | Patient | ✓ | OP | OP-Termin: Beginn Datum und Zeit |
| op_termin_ende | | Patient | ✓ | OP | OP-Termin: Ende Datum und Zeit |
| op_ueberweiser | | Patient | ✓ | OP | OP-Termin: Überweiser |
| op_weiterbehandler | | Patient | ✓ | OP | OP-Termin: Weiterbehandler |
| ort | | Patient | | Patient | Ort der Betriebsstätte |
| ort_empfaenger | | Brief | | Brief | Ort des Empfängers |

## P (Patient-Stammdaten)

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| p0 | | Patient | | Patient | Geburtsdatum 6-stellig, z.B. 241299 |
| pAlterInTagen | | Patient | | Patient | Patient: Alter in Tagen |
| pAlterInWochen | | Patient | | Patient | Patient: Alter in Wochen |
| pAWNr | | Patient | | Patient | Personalausweisnummer des Patienten |
| pErlaubtArztdirekt | | Patient | | Patient | Einverständnis für Kontakt via arzt-direkt App |
| pErlaubtEmail | | Patient | | Patient | Einverständnis für Kontakt via E-Mail |
| pErlaubtFax | | Patient | | Patient | Einverständnis für Kontakt via Fax |
| pErlaubtMedDokuVersand | | Patient | | Patient | Einverständnis für das (elektronische) Versenden von medizinischen Dokumenten |
| pErlaubtRecall | | Patient | | Patient | Einverständnis für Recall |
| pErlaubtRechnungsVersand | | Patient | | Patient | Einverständnis für das (elektronische) Versenden von Rechnungen |
| pErlaubtRundschreiben | | Patient | | Patient | Einverständnis für das Versenden von Rundschreiben |
| pErlaubtSms | | Patient | | Patient | Einverständnis für Kontakt via SMS |
| pErlaubtTel | | Patient | | Patient | Einverständnis für Kontakt via Telefon |
| pErlaubtTermindetailsVersand | | Patient | | Patient | Einverständnis für das Versenden von Termindetails |
| pLand | | Patient | | Patient | Land des Patienten |
| pMW | | Patient | | Patient | Geschlecht des Patienten als Großbuchstabe (M/W/D/X/U) |
| palter | | Patient | | Patient | Patient: Alter |
| palter_formatiert | | Patient | | Patient | Alter des Patienten am Karteidatum mit altersabhängigem Format: |
| patientAnkunftszeit | | Patient | | Patient | Beginn des Besuches |
| patient_auftragsbezogeneHinweise | | Laborbefund | | Labor | Auftragsbezogene Hinweise (Nicht bei kumulativ oder chronologisch!) |
| patient_ausgegebeneNummern | | Patient | | Patient | Die Warteschlangennummern des Patienten für den heutigen Tag |
| patient_berichtsdatum | | Laborbefund | | Labor | Datum der Labor-Antwort (Nicht bei kumulativ oder chronologisch!) |
| patient_bez | | Patient | ✓ | Patient | Patient: 'Patientin' oder 'Patient' |
| patient_bundesland | | Patient | | Patient | Patient: Bundesland |
| patient_chiffre | | Patient | | Patient | Chiffre des Patienten aus Anfangsbuchstabe des Nachnamens und Geburtsdatum im Format TTMMJJ |
| patient_eingangsdatumLabor | | Laborbefund | | Labor | Datum des Labor-Eingangs (Nicht bei kumulativ oder chronologisch!) |
| patient_fax | | Patient | | Patient | Patient: Feld Fax |
| patient_geschlecht | | Patient | | Patient | Patient: Geschlecht: 'weiblich' oder 'männlich' |
| patient_guthaben | | Patient | | Patient | Verfügbares Guthaben des Patienten – dieses ist auch einsehbar in den Patientendetails unter "Guthaben" |
| patient_id | | Patient | ✓ | Patient | Patient: Titel, Vorname, Namenszusatz, Nachname, Geburtsdatum des Patienten |
| patient_information | | Patient | ✓ | Patient | Zweizeilige Information über Patient mit Name, Geb.-Datum und Anschrift |
| patient_information_eArztbrief | | Patient | | Patient | Mehrzeilige Information über Patient für eArztbrief (KIM) |
| patient_name | | Patient | ✓ | Patient | Patient: Nachname |
| patient_ort | | Patient | ✓ | Patient | Patient: Ort |
| patient_plz | | Patient | ✓ | Patient | Patient: PLZ |
| patient_rufname | | Patient | ✓ | Patient | Patient: Rufname. Damit die der Rufname in den Patientendetails hinterlegt werden kann, muss die entsprechende Einstellung aktiviert sein |
| patient_strasse | | Patient | ✓ | Patient | Patient: Straße |
| patient_stringCol1 | | Patient | ✓ | Patient | Text Patient 1 |
| patient_stringCol2 | | Patient | ✓ | Patient | Text Patient 2 |
| patient_stringCol3 | | Patient | | Patient | Text Patient 3 |
| patient_stringCol4 | | Patient | | Patient | Text Patient 4 |
| patient_versichertenstatus | | Patient | | Patient | Versichertenstatus des Patienten ("gesetzlich" oder "privat") |
| patient_vorname | | Patient | | Patient | Patient: Vorname |
| patientenTermine | ✓ | Patient | | Termine | Patiententermine. Alle nicht gelöschten Termine des Patienten ab dem morgigen Tag werden zeitlich aufsteigend ausgegeben. Folgende Parameter beeinflussen die Auswahl der Termine: |
| patientenTermineICALFormat | | Patient | ✓ | Patient | Patiententermine im iCal-Format. Alle nicht gelöschten Termine des Patienten ab dem morgigen Tag werden zurückgegeben |
| patientenname | | Patiententermine | | Termine | Voller Name des Patienten, Version 2 |
| paz | | Patient | ✓ | Patient | Patient: Adresszusatz |
| pb | | Patient | | Patient | Patient: Beruf |
| pbs | | Patient | | Patient | seit wann der Patient den aktuellen Beruf ausübt |
| pderdie | | Patient | | Patient | der (männlich) oder die (weiblich) |
| pemail | | Patient | ✓ | Patient | E-Mail des Patienten |
| perspektivischeTodos | | Besuch | ✓ | Besuch | Offene ToDos des Besuchs nach dem nächsten anstehenden ToDo |
| pflegegrad_kurz | | Patient | | Patient | Pflegegrad des Patienten – Kurzform: 1,2,3,4,5 |
| pflegegrad_lang | | Patient | | Patient | Pflegegrad des Patienten – Langform: Pflegegrad 3 (dau.Mob.) |
| pg | | Patient | ✓ | Patient | Patient: Geburtsdatum |
| pg2 | | Patient | ✓ | Patient | Patient: Geburtsdatum, alternatives Format |
| pgo | | Patient | | Patient | Patient: Geburtsort |
| phandy | | Patient | | Patient | Handy-Nummer des Patienten |
| pherr | | Patient | | Patient | Herr oder Frau bei Erwachsenen, bei Kindern leer |
| pid | | Patient | | Patient | Patient: Patienten-Nummer bzw. Patienten-Id bzw. Patienten-Ident |
| pid_infoelement | ✓ | Patient | | Patient | Patient: Patienten-Nummer aus den patientdetailsinfoelementen per name anfordern... wenn das nicht definiert, so nimm die tomedo Patienten-Id |
| pid_plus | ✓ | Patient | ✓ | Patient | Patient: Patienten-Nummer bzw. Patienten-Id PLUS den angegebenen Wert |
| pinfo | | Patient | ✓ | Patient | Inhalt des Info-Feldes im Patienteninfobereich der Kartei |
| pk | | Patient | | Patient | Kassenname, Privat |
| plz_empfaenger | | Brief | | Brief | Postleitzahl des Empfängers |
| pmutterschutz | | Patient | ✓ | Patient | Datum des Beginns des Mutterschutzes |
| pn | | Patient | | Patient | Patient: Nachname |
| pngeburt | | Patient | | Patient | Patient: Geburtsname |
| pngeburtExp | | Patient | | Patient | Patient: Geburtsname in der Form (geb. xxx) |
| pnotiz | | Patient | ✓ | Patient | Inhalt des Notizfeldes im Patienteninfobereich der Kartei |
| pnz | | Patient | | Patient | Patient: Namenszusatz |
| po | | Patient | ✓ | Patient | Patient: Ort |
| pp | | Patient | ✓ | Patient | Patient: PLZ |
| protokollnummer | ✓ | Patient | ✓ | Formulare | Mit diesem Platzhalter kann man eine Protokollnummer erzeugen. Sie ergibt sich aus der Anzahl gespeicherter Formulare mit dem gegebenen Formulartyp plus 1. Beispiel: $[protokollnummer Stundenprotokoll]$ |
| ps | | Patient | | Patient | Patient: Straße |
| psychProb | ✓ | Patient | | Psychot... | Das Datum der <n>-ten probatorischen Sitzung (EBM 35150), z.B. $[psychProb 1]$ für die erste. Ohne Argument: Datum der letzten Sitzung. Negative Argumente durchlaufen die Sprechstunden rückwärts |
| psychSprechst | ✓ | Patient | | Psychot... | Das Datum der <n>-ten psychotherapeutischen Sprechstunde (EBM 35151). Analog zu psychProb |
| pt | | Patient | ✓ | Patient | Patient: Titel |
| ptel | | Patient | | Patient | Patient: Telefonnummer |
| ptyp | | Patient | | Patient | Typ des Patienten 0 – Patient, 1 – Firma |
| pupillendistanz | | Patient | ✓ | Augen | Augenarzt: Pupillendistanz |
| pv | | Patient | | Patient | Patient: Vorname |
| pverskartennr | | Patient | | Patient | Patient: Nummer der Versichertenkarte |
| pversnr | | Patient | | Patient | Patient: Versicherten-Nummer. Je nachdem, ob es sich um einen Privat-Patienten handelt, wird die PKV-Versichertennummer bzw. die GKV-Versichertennummer genommen |
| pvoll | | Patient | | Patient | Patient: Voller Name mit Titel und Namenszusatz |

## PR_ (Privatrechnung)

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| pr_adressfeld_empfaenger | | Privatrechnung | | Privatrec... | Mehrzeiliges Adressfeld des Empfängers für DOCX |
| pr_adressfeld_empfaenger_KopieArbeitgeber | | Privatrechnung | | Privatrec... | Adressfeld des Empfängers, bei reinem Kopiedruck Adressfeld des Arbeitgebers |
| pr_adressfeld_empfaenger_KopieKasse | | Privatrechnung | | Privatrec... | Adressfeld des Empfängers, bei reinem Kopiedruck Adressfeld der Kasse |
| pr_adressfeld_empfaenger_neutral | | Privatrechnung | | Privatrec... | geschlechterneutrale Variante von pr_adressfeld_empfaenger, d.h. ohne Frau oder Herrn |
| pr_adressfeld_kasse | | Privatrechnung | | Privatrec... | Adressfeld der Kasse der Rechnung |
| pr_aktenzeichen | | Privatrechnung | | Privatrec... | Aktenzeichen der Rechnung |
| pr_anrede | | Privatrechnung | | Privatrec... | 'Sehr geehrter Herr' oder 'Sehr geehrte Frau' |
| pr_behandlungsgrund | | Privatrechnung | | Privatrec... | Behandlungsgrund |
| pr_behandlungszeitraum | | Privatrechnung | | Privatrec... | Behandlungszeitraum |
| pr_bemerkung | | Privatrechnung | | Privatrec... | Bemerkung-Feld der Rechnung (Rechnungsdetails, Reiter Info). Nützlich für IGeL-Vorlagen |
| pr_betrag | | Privatrechnung | | Privatrec... | Netto-Summe (ohne Umsatzsteuer/Abzüge, ohne Mahngebühr) |
| pr_betragReal | | Privatrechnung | | Privatrec... | Brutto-Summe (mit Umsatzsteuer/Abzügen, ohne Mahngebühr) |
| pr_betragReal_gerundet | | Privatrechnung | | Privatrec... | Als Argument muss eine natürliche Zahl angegeben werden, auf deren Vielfache die Brutto-Summe der Rechnung in der kleinsten Währungseinheit gerundet werden soll |
| pr_betrag_gerundet | | Privatrechnung | | Privatrec... | Als Argument muss eine natürliche Zahl angegeben werden, auf deren Vielfache die Netto-Summe in der kleinsten Währungseinheit gerundet werden soll |
| pr_bgtarif | | Privatrechnung | | Privatrec... | BG: Tarif von F1000 |
| pr_datum | | Privatrechnung | | Privatrec... | Druckdatum der Rechnung – auch zur Verwendung auf Mahnungen |
| pr_datum_ersteLeistung | | Privatrechnung | | Privatrec... | Datum der ersten Leistung auf der Rechnung |
| pr_datum_letzteLeistung | | Privatrechnung | | Privatrec... | Datum der letzten Leistung auf der Rechnung |
| pr_datum_withArgs | ✓ | Privatrechnung | | Privatrec... | Druckdatum der Rechnung + Tagesanzahl |
| pr_diagnose | | Privatrechnung | | Privatrec... | Diagnosen mit ICD-Code (kommasepariert) |
| pr_diagnoseMitDatum | | Privatrechnung | | Privatrec... | Diagnosen mit ICD-Code und Datum (kommasepariert) |
| pr_diagnoseMitDatumOhneICD | | Privatrechnung | | Privatrec... | Diagnosen mit Datum ohne ICD-Code |
| pr_diagnoseNurICD | | Privatrechnung | | Privatrec... | Diagnose nur als ICD-Code (kommasepariert) |
| pr_diagnoseOhneICD | | Privatrechnung | | Privatrec... | Diagnosen ohne ICD-Code (kommasepariert) |
| pr_faelligBis | | Privatrechnung | | Privatrec... | Fälligkeitsdatum der Rechnung |
| pr_faelligIn | | Privatrechnung | | Privatrec... | Zahlungsfrist in Tagen |
| pr_identifikationsnummer_tardoc | | Privatrechnung | | Privatrec... | Identifikationsnummer der TARDOC-Rechnung |
| pr_if_frau | ✓ | Privatrechnung | | Privatrec... | geschlechtsspezifisch, Empfänger: $[pr_if_frau Sehr_geehrte_Frau Sehr_geehrter_Herr]$ |
| pr_kontonr | | Privatrechnung | | Privatrec... | Konto-Feld aus Privatrechnungstyp |
| pr_kopie | | Privatrechnung | | Privatrec... | Ausgabe ist 0 bei Originaldruck der Rechnung und 1 bei reinem Kopiedruck. Kann beispielsweise in Kombination mit dem if-Kommando verwendet werden |
| pr_kostenstelle | | Privatrechnung | | Privatrec... | Kostenstelle-Feld aus Privatrechnungstyp |
| pr_land | | Privatrechnung | | Privatrec... | Land des Rechnungsempfängers in Großbuchstaben |
| pr_mahndatum1 | | Privatrechnung | | Privatrec... | Druckdatum der Zahlungserinnerung/1. Mahnung – auch zur Verwendung auf den weiteren Mahnungen |
| pr_mahndatum2 | | Privatrechnung | | Privatrec... | Druckdatum der 2. Mahnung – auch zur Verwendung auf den weiteren Mahnungen |
| pr_mahndatum3 | | Privatrechnung | | Privatrec... | Druckdatum der 3. Mahnung – zur Verwendung auf den weiteren Mahnungen |
| pr_mahndatum4 | | Privatrechnung | | Privatrec... | Druckdatum der 4. Mahnung |
| pr_mahngebuehr | | Privatrechnung | | Privatrec... | Mahngebühr |
| pr_mwst | | Privatrechnung | | Privatrec... | Umsatzsteuer bezogen auf Netto-Betrag |
| pr_mwstp | | Privatrechnung | | Privatrec... | Umsatzsteuer in Prozent |
| pr_n | | Privatrechnung | | Privatrec... | Nachname des Empfängers |
| pr_notiz | | Privatrechnung | | Privatrec... | Notiz-Feld der Rechnung |
| pr_nurRestbetrag | ✓ | Privatrechnung | | Privatrec... | Restbetrag in Euro. Möglicher Parameter um den Restbetrag ohne Mahngebühr auszugeben: -ohneMahngebuehr |
| pr_nurTeilbetrag | | Privatrechnung | | Privatrec... | Teilbetrag in Euro |
| pr_patient_bez | | Privatrechnung | | Privatrec... | Bezeichnung 'Patient' oder 'Patientin', je nach Geschlecht |
| pr_patient_geburtsdatum | | Privatrechnung | | Privatrec... | BG: Geburtsdatum des Patienten von F1000 |
| pr_rechnungsSumme | | Privatrechnung | | Privatrec... | Netto-Summe mit Mahngebühr (netto = ohne Umsatzsteuer/Abzüge) |
| pr_rechnungsSummeMwst | | Privatrechnung | | Privatrec... | Rechnungssumme (ohne mögliche Abzüge) der Privatrechnung mit Umsatzsteueranteil |
| pr_rechnungsSummeReal | | Privatrechnung | | Privatrec... | Brutto-Summe mit Mahngebühr (brutto = mit Umsatzsteuer/Abzügen) |
| pr_rechnungsSummeRealOhneMwst | | Privatrechnung | | Privatrec... | Realsumme (berücksichtigt mögliche Abzüge) der Privatrechnung ohne Umsatzsteueranteil |
| pr_rechnungsnr | | Privatrechnung | | Privatrec... | Rechnungsnummer |
| pr_referenznummerDE | | Privatrechnung | | Privatrec... | Referenznummer |
| pr_referenznummerSCOR | | Privatrechnung | | Privatrec... | Referenznummer SCOR |
| pr_restbetrag | | Privatrechnung | | Privatrec... | Wenn Patienten bereits Teilbetrag/-beträge geleistet hat: 'Diese Mahnung bezieht sich auf den fälligen Restbetrag von 5365,17 €.' Wenn nicht: leer |
| pr_restbetragMitZusammensetzung | | Privatrechnung | | Privatrec... | Analog zum Kommando pr_summeTotalMitZusammensetzung mit den gleichen möglichen Parametern. Falls Teilzahlungen geleistet wurden, wird zusätzlich zum Gesamtbetrag auch der Restbetrag aufgeführt |
| pr_sachkosten_ueber_25_56 | | Privatrechnung | | Privatrec... | Gibt eine Liste aller Sachkostennamen auf der Privatrechnung zurück, die jeweils über 25,56 € liegen und daher einen Beleg benötigen |
| pr_stationaerBeleg_FaktorAbzug | | Privatrechnung | | Privatrec... | 0 für ambulant, 15 für belegärztlich, 25 für stationär |
| pr_summe15 | | Privatrechnung | | Privatrec... | Gibt 15% der Rechnungs-Gesamtsumme (einschl. Mahngebühr) aus. Achtung! Nur für Konsiliarrechnung benutzen |
| pr_summe85 | | Privatrechnung | | Privatrec... | Gibt 85% der Rechnungs-Gesamtsumme (einschl. Mahngebühr) aus. Nur für Konsiliarrechnung |
| pr_summeStationaerOderBeleg_abzug | | Privatrechnung | | Privatrec... | Differenz zwischen unreduzierter Summe und jener Summe, die belegärztliche/stationäre Behandlung beachtet |
| pr_summeStationaerOderBeleg_leistungen | | Privatrechnung | | Privatrec... | Summe der ärztlichen Leistungen, reduziert um die Faktoren 15%/15%/25%/25%$ für stationäre/belegärztliche Behandlung (außer Ziffer J) |
| pr_summeTotalMitZusammensetzung | ✓ | Privatrechnung | | Privatrec... | Rechnungssumme aufgeschlüsselt nach ärztlichen Leistungen und Sachkosten sowie allen vorhandenen USt.-Sätzen. Folgende Parameter sind möglich: |
| pr_summe_aerztliche_leistungen | | Privatrechnung | | Privatrec... | Netto-Summe der ärztlichen Leistungen ohne eventuelle Abzüge |
| pr_summe_belegaerztliche_leistungen_85 | | Privatrechnung | | Privatrec... | — |
| pr_summe_belegaerztlicher_abzug | | Privatrechnung | | Privatrec... | Privatrg |
| pr_summe_sachkostenBrutto | | Privatrechnung | ✓ | Privatrec... | Sachkosten – Bruttoanteil. Soll dies nur für Sachkosten eines bestimmten USt.-Satzes ausgegeben werden, so ist dieser Satz als Parameter anzugeben |
| pr_summe_sachkostenMwst | | Privatrechnung | | Privatrec... | Sachkosten – Umsatzsteuer. Soll dies nur für Sachkosten eines bestimmten USt.-Satzes ausgegeben werden, so ist dieser Satz als Parameter anzugeben |
| pr_summe_sachkostenNetto | | Privatrechnung | | Privatrec... | Sachkosten – Nettoanteil. Soll dies nur für Sachkosten eines bestimmten USt.-Satzes ausgegeben werden, so ist dieser Satz als Parameter anzugeben |
| pr_summe_sachkosten_oW | | Privatrechnung | | Privatrec... | Wie pr_summe_sachkosten nur ohne Währungszeichen |
| pr_summe_stationaerer_abzug | | Privatrechnung | | Privatrec... | Abgezogener Betrag – stationär |
| pr_tarif | | Privatrechnung | | Privatrec... | Übernimmt den Tarif der Privatrechnung |
| pr_teilbetraegeMitDatum | | Privatrechnung | | Privatrec... | Teilbeträge in Euro mit dem jeweiligen Eingangsdatum |
| pr_teilbetraegeMitGuthabenBeglichen | | Privatrechnung | | Privatrec... | Summe der Teilbeträge dieser Rechnung, die mit dem Guthaben des Patienten beglichen wurden |
| pr_teilbetrag | | Privatrechnung | | Privatrec... | Wenn Patienten bereits Teilbetrag/-beträge geleistet hat: 'Einen Teilbetrag von 30,00 € haben wir bereits dankend erhalten.' Wenn nicht: leer |
| pr_teilsumme | ✓ | Privatrechnung | | Privatrec... | Wie pr_summe85, nur dass man den prozentualen Anteil als Argument selbst angeben kann, z.B. $[pr_teilsumme 24]$ |
| pr_teilsummen_nach_Arzt | | Privatrechnung | | Privatrec... | Aufschlüsselung des Rechnungsbetrags einer Privatrechnung nach abrechnendem Arzt. Dabei werden Umsatzsteuer und Abzüge für belegärztliche, stationäre und konsiliare Leistungen nicht berücksichtigt |
| pr_titel | | Privatrechnung | | Privatrec... | Titel des Empfängers |
| pr_unfallbetrieb | | Privatrechnung | | Privatrec... | BG: Unfallbetrieb des Unfalls (DALE-UV). Falls kein Unfall, dann BG aus Patientendetails |
| pr_unfalldatum | | Privatrechnung | | Privatrec... | BG: Unfalldatum des Unfalls (DALE-UV). Falls kein Unfall, dann Unfalldatum aus Besuch |
| pr_v | | Privatrechnung | | Privatrec... | Vorname des Empfängers |
| pr_zahlungsbeleg_ersSeriennummer | | Privatrechnung | | Privatrec... | Die Seriennummer des Kassenbuches, an dem ein Teilbetrag der Rechnung gebucht wurde |
| pr_zahlungsbeleg_tseTransaktionsBegin | | Privatrechnung | | Privatrec... | Der Beginn der Transaktion eines Teilbetrages an der TSE für eine Rechnung, die genau einen Teilbetrag hat |
| pr_zahlungsbeleg_tseTransaktionsEnde | | Privatrechnung | | Privatrec... | Das Ende der Transaktion eines Teilbetrages |
| pr_zahlungsbeleg_tseTransaktionsNummer | | Privatrechnung | | Privatrec... | Die Nummer der Transaktion eines Teilbetrages |

## PTV_ (HZV-Importbericht)

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| ptv_arzt_lanr | | HZV-Importbericht | | HZV | LANR des Arztes, für den das Patientenverteilnehmerverzeichnis gültig ist |
| ptv_arzt_vollname | | HZV-Importbericht | | HZV | Name und Vorname des Arztes |
| ptv_arzt_vpid | | HZV-Importbericht | | HZV | VP-ID des Arztes |
| ptv_importdatum | | HZV-Importbericht | | HZV | Datum und Uhrzeit der Durchführung des PTV-Imports (Startdatum) |
| ptv_importnutzer | | HZV-Importbericht | | HZV | Benutzername des Benutzers, der den PTV-Prüflauf durchgeführt hat |
| ptv_normalparticipance_inprocess | | HZV-Importbericht | | HZV | Anzahl der in Prüfung befindlichen Patienten unter normalen Teilnahmemeldungen |
| ptv_normalparticipance_nochange | | HZV-Importbericht | | HZV | Anzahl der unveränderten Teilnehmer unter normalen Teilnahmemeldungen |
| ptv_normalparticipance_registered | | HZV-Importbericht | | HZV | Anzahl der neu eingeschriebenen Teilnehmer unter normalen Teilnahmemeldungen |
| ptv_normalparticipance_rejected | | HZV-Importbericht | | HZV | Anzahl der neu abgelehnten Patienten unter normalen Teilnahmemeldungen |
| ptv_normalparticipance_terminated | | HZV-Importbericht | | HZV | Anzahl der neu beendeten Teilnehmer unter normalen Teilnahmemeldungen |
| ptv_notfound_import | | HZV-Importbericht | | HZV | Anzahl der in der Praxissoftware vorhandenen Patienten, mit dem Teilnahmestatus beantragt oder aktiviert, die nicht im Patientenverteilnehmerverzeichnis gefunden werden |
| ptv_notfound_system | | HZV-Importbericht | | HZV | Anzahl der im Patientenverteilnehmerverzeichnis gemeldeten Patienten, die nicht in der Praxissoftware gefunden werden |
| ptv_participantcount_after_import | | HZV-Importbericht | | HZV | Anzahl eingeschriebener Teilnehmer in der Praxissoftware im Quartal der Gültigkeit des Patientenverteilnehmerverzeichnisses nach dem Import |
| ptv_participantcount_import | | HZV-Importbericht | | HZV | Anzahl eingeschriebener Teilnehmer in der Praxissoftware im Quartal der Gültigkeit des Patientenverteilnehmerverzeichnisses |
| ptv_participantcount_previous | | HZV-Importbericht | | HZV | Anzahl eingeschriebener Teilnehmer im Vorquartal der Gültigkeit des Patientenverteilnehmerverzeichnisses |
| ptv_prueflaufdatum | | HZV-Importbericht | | HZV | Datum und Uhrzeit der Durchführung des PTV-Prüflaufes (Startdatum) |
| ptv_prueflaufnutzer | | HZV-Importbericht | | HZV | Benutzername des Benutzers, der den PTV-Prüflauf durchgeführt hat |
| ptv_quartal | | HZV-Importbericht | | HZV | Quartal/Jahr der Gültigkeit des Patientenverteilnehmerverzeichnisses |
| ptv_quartal_import | | HZV-Importbericht | | HZV | Quartal/Jahr der Gültigkeit des Patientenverteilnehmerverzeichnisses zum Anzeigen der Patientenanzahl im Import-Bericht |
| ptv_quartal_previous | | HZV-Importbericht | | HZV | Vorquartal/Jahr der Gültigkeit des Patientenverteilnehmerverzeichnisses |
| ptv_specialparticipance | | HZV-Importbericht | | HZV | Anzahl der besonderen Teilnahmemeldungen |
| ptv_vertragsname | | HZV-Importbericht | | HZV | HZV Vertragsname des Patientenverteilnehmerverzeichnisses (PTV) |

## Q–R

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| quartalAnfang | ✓ | ohne | ✓ | Datum | Erster Tag des aktuellen Quartals. Um auf vergangene oder zukünftige Quartale zuzugreifen, kann als Argument eine Zahl angegeben werden |
| quartalEnde | ✓ | ohne | ✓ | Datum | Analog zum Platzhalter quartalAnfang |
| raddl | ✓ | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: ADD links; optionaler Parameter: Kürzel der relevanten Karteieinträge kommasepariert |
| raddr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: ADD rechts |
| ral | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Achse links |
| rar | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Achse rechts |
| rbemerkung | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Bemerkung |
| rbl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Basis, links |
| rbr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Basis, rechts |
| rccvfb | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, con correctum, Fern, beidseitig |
| rccvfl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, con correctum, Fern, links |
| rccvfr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, con correctum, Fern, rechts |
| rccvnb | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, con correctum, Nah, beidseitig |
| rccvnl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, con correctum, Nah, links |
| rccvnr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, con correctum, Nah, rechts |
| regex | ✓ | ohne | | Steuerko... | Extrahiert einen Teil des Ergebnisses eines Platzhalters mittels Regular Expression. Erstes Argument ist der Regular Expression (ohne Leerzeichen), anschließend ist ein Kommando mit beliebig vielen Parametern anzugeben. Ausgabe ist der Inhalt der ersten Gruppierung |
| rhsal | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Hornhautscheitelabstand, links |
| rhsar | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Hornhautscheitelabstand, rechts |
| rpl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Prisma links |
| rpr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Prisma rechts |
| rscvfb | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, sin correctum, Fern, beidseitig |
| rscvfl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, sin correctum, Fern, links |
| rscvfr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, sin correctum, Fern, rechts |
| rscvnb | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, sin correctum, Nah, beidseitig |
| rscvnl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, sin correctum, Nah, links |
| rscvnr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Visus, sin correctum, Nah, rechts |
| rsl | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Sphäre links |
| rsr | | Patient | ✓ | Augen | Augenarzt: Neuester Eintrag: Sphäre rechts |
| rzl | | Patient | | Augen | Augenarzt: Neuester Eintrag: Zylinder links |
| rzr | | Patient | | Augen | Augenarzt: Neuester Eintrag: Zylinder rechts |

## S

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| scheinDiagnoseVerdacht | | Patient | | Patient | Gibt vom ausgewählten KV-Schein das Feld Diagnose/Verdacht wieder |
| score | ✓ | ohne | | Steuerko... | Mit diesem Kommando können Berechnungen wie Addition, Multiplikation, Subtraktion, Division, Maximum, Minimum, u.a. ausgeführt werden |
| selektierteTermineEinzahlMehrzahl | ✓ | Terminerinnerung | | Termine | Briefkommando mit 2 Argumenten für von der Anzahl selektierter Termine abhängige Texte. Innerhalb eines Arguments müssen Leerzeichen durch Unterstriche ersetzt werden |
| selektierteTermineErster | ✓ | Terminerinnerung | | Termine | Identisch zum Kommando 'selektierterTermin' |
| selektierteTermineLetzter | ✓ | Terminerinnerung | | Termine | Wie Kommando 'selektierterTermin' – liefert allerdings die Informationen des zeitlich letzten selektierten Termins |
| selektierteTermineListe | ✓ | Terminerinnerung | | Termine | Briefkommando mit 2 Argumenten zur Ausgabe von Informationen aller selektierter Termine. Syntax: |
| selektierteTermineMWU | ✓ | Terminerinnerung | | Termine | Briefkommando mit 3 Argumenten für geschlechtsspezifische Texte. Innerhalb eines Arguments müssen Leerzeichen durch Unterstriche ersetzt werden. Also z.B. $[selektierteTermineMWU Lieber_Herr Liebe_Frau Sehr_geehrte/r]$ |
| selektierterTermin | ✓ | Terminerinnerung | | Termine | Informationen des selektierten Termins. (Bei mehreren selektierten Terminen Informationen des zeitlich ersten Termins) Kann aber nur unter bestimmten Bedingungen ermittelt werden wie bei Terminzetteln. Ersetzungsmuster mit %: (siehe Detail-Popup) |

### Detail: selektierterTermin — Ersetzungsmuster

Muster für die Beschriftung. Ersetzungen gehen mit %:
- `%a` — Terminart (Kürzel)
- `%A` — Terminart (Beschreibung)
- `%anh` — Ob Termin Anhang hat (📎)
- `%b` — Termin Zeit bis
- `%c` — Terminlokalität (Kürzel)
- `%cA` — Terminlokalität (Adresse der Betriebsstätte)
- `%cB` — Terminlokalität (Beschreibung)
- `%C` — Kalendername(n), kommasepariert
- `%d` — Datum mit Zeit
- `%doz` — Datum ohne Zeit
- `%e` — Dokumentierender Nutzer (Kürzel)
- `%ed` — Erstellungszeitpunkt
- `%edoz` — Erstellungsdatum ohne Zeit
- `%i` — Termininfo
- `%if` — Erlaubt je nach Inhalt eines Textes, einen anderen Text anzuzeigen. Syntax: `%if((<zu prüfender Text> <Operator> <Vergleichswert1> <Ausgabewert1>) (<Vergleichswert2> <Ausgabewert2>) ... (<VergleichswertX> <AusgabewertX>) (<Rückfallwert>))`
  - Mögliche Operatoren: `zsEquals` (Gleichheit), `zsNotEqual` (Ungleichheit), `zsContains` (Enthaltensein), `zsNotContains` (Nicht-Enthaltensein)
  - Alle Eingabewerte außer dem Operator können auch weitere Kommandos enthalten
  - Runde Klammern in Werten mit vorangestelltem `\` escapen

## SR_ (Sammelrechnung)

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| sr_adressfeld_empfaenger | | Sammelrechnung | | Privatrec... | Adressfeld des Empfängers |
| sr_gesamtbetrag | | Sammelrechnung | | Privatrec... | Gesamtbetrag der Rechnung |
| sr_gesamtbetrag_netto | | Sammelrechnung | | Privatrec... | Netto-Gesamtbetrag der Rechnung |
| sr_rechnungsnummer | | Sammelrechnung | | Privatrec... | Rechnungsnummer der Sammelrechnung |
| sr_summe_brutto_sachkosten_mwst19 | | Sammelrechnung | | Privatrec... | Summe der Brutto-Sachkosten zum Steuersatz 19 Prozent |
| sr_summe_mwst | | Sammelrechnung | | Privatrec... | Summe Umsatzsteuer der Rechnung |
| sr_summe_mwst19_sachkosten | | Sammelrechnung | | Privatrec... | Summe der Umsatzsteuer für Leistungen mit Steuersatz 19 Prozent |
| sr_summe_netto_sachkosten_mwst0 | | Sammelrechnung | | Privatrec... | Summe der Netto-Sachkosten zum Steuersatz 0 Prozent |
| sr_summe_netto_sachkosten_mwst19 | | Sammelrechnung | | Privatrec... | Summe der Netto-Sachkosten zum Steuersatz 19 Prozent |
| sr_summe_restbetrag | | Sammelrechnung | | Privatrec... | Summe der Restbeträge |
| sr_summe_teilbetrag | | Sammelrechnung | | Privatrec... | Summe der Teilbeträge |

## SSW (Schwangerschaft)

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| ssw | | Patient | ✓ | Patient | Schwangerschaftsdetails: Schwangerschaftswoche im Format Wochen + Tage bezogen auf das Karteidatum |
| ssw2 | | Patient | ✓ | Patient | Schwangerschaftswoche ausgedrückt in Anzahl an Tagen bezogen auf das Karteidatum |
| ssw3 | | Patient | | Patient | Anzahl vollendeter Schwangerschaftswochen bezogen auf das Karteidatum – bei SSW 15+3: 15 |
| ssw4 | | Patient | | Patient | angebrochene Schwangerschaftswoche bezogen auf das Karteidatum – bei SSW 15+3: 16 |

## ST–SU

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| strasse_empfaenger | | Brief | | Brief | Straße des Empfängers |
| summe_ke_wert | ✓ | Patient | | Karteiein... | Summe von Werten aus Feldern von CustomKarteieinträgen, wobei die Werte ganze Zahlen sein müssen. Die Syntax der Parameter ist wie beim Tabellenplatzhalter 'tab_ke_wert' |

## T

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| tel2_empfaenger | | Brief | ✓ | Brief | Telefonnummer 2 des Empfängers |
| tel3_empfaenger | | Brief | ✓ | Brief | Telefonnummer 3 des Empfängers |
| tel_empfaenger | | Brief | ✓ | Brief | Telefonnummer des Empfängers |
| tensioKL | | Patient | ✓ | Augen | Augenarzt: Neuester Augendruck-Eintrag – Druck links mit Korrektur |
| tensioKR | | Patient | ✓ | Augen | Augenarzt: Neuester Augendruck-Eintrag – Druck rechts mit Korrektur |
| tensioL | | Patient | ✓ | Augen | Augenarzt: Neuester Augendruck-Eintrag – Druck links |
| tensioR | | Patient | ✓ | Augen | Augenarzt: Neuester Augendruck-Eintrag – Druck rechts |
| terminArtBezeichnung | | Patient | ✓ | Termine | Terminart des heutigen Termins des aktuellen Patienten, falls vorhanden |
| text | | Brief | ✓ | Brief | Platzhalter für manuellen Karteieintrag aus dem Brief-Dialog (runder Button) |
| therapiephase | | Patient | ✓ | Patient | Mit diesem Platzhalter kann man die aktuelle Therapiephase auslesen (nur Psychotherapie). Die Therapiephase KZT1, KZT2, KZT, LZT oder 'Rezidiv.' sein |
| titel_empfaenger | | Brief | ✓ | Brief | Titel des Empfängers, falls Arzt oder Patient |
| todestag | | Patient | ✓ | Patient | Patient: Todestag/Sterbedatum |
| todo_dauer | ✓ | Besuch | ✓ | Patient | Dauer des aktuellen oder letzten abgearbeiteten ToDos in Minuten. Verwendung $[todo_dauer X]$, wobei X entweder das Wort 'abgearbeitet' oder das Wort 'inarbeit' ist |

## U

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| ua_fachgebiet | | Patient | ✓ | Patient | Überweisender Arzt: Fachgebiet |
| ua_fax | | Patient | ✓ | Patient | Überweisender Arzt: Fax-Nummer |
| ua_herrfrau | | Patient | ✓ | Patient | Überweisender Arzt: Anrede mit 'Herr' oder 'Frau'. Bei keinem Geschlecht auch keine Anrede bzw. leerer String |
| ua_name | | Patient | ✓ | Patient | Überweisender Arzt: Nachname |
| ua_ort | | Patient | ✓ | Patient | Überweisender Arzt: Ort |
| ua_plz | | Patient | ✓ | Patient | Überweisender Arzt: PLZ |
| ua_postfach | | Patient | ✓ | Patient | Überweisender Arzt: Postfach |
| ua_praxisname | | Patient | ✓ | Patient | Überweisender Arzt: Praxisname |
| ua_strasse | | Patient | ✓ | Patient | Überweisender Arzt: Straße |
| ua_titel | | Patient | ✓ | Patient | Überweisender Arzt: Titel |
| ua_vorname | | Patient | ✓ | Patient | Überweisender Arzt: Vorname |
| uhrzeitAktuellerTermin | | Patient | ✓ | Patient | Uhrzeit des heutigen (des aktuellen) Termins |
| unfallort | | Patient | ✓ | Patient | Patient: Unfallort nach Patientendetails |
| unfalltag | | Patient | ✓ | Patient | Patient: Unfalltag nach Patientendetails |
| unfallzeit | | Patient | ✓ | Patient | Patient: Unfallzeit nach Patientendetails |
| unterschriftName | | Nutzer | ✓ | Praxis | Fügt Namen des dem Brief zugeordneten Arztes ein. (Auslösezeitpunkt: Drucken) |
| unterschriftNameArzt | | Nutzer | ✓ | Praxis | Fügt Namen des dem Brief zugeordneten Arztes ein |

## V–Z

| Name | Param | Kontext | iOS | Themen | Beschreibung |
|---|---|---|---|---|---|
| verordnungsdatum | | Patient | | Patient | Platzhalter für Rechnung/Quittung: Ausstellungdatum der aktuellen Verordnung |
| vorKommaWert | ✓ | ohne | ✓ | Steuerko... | Als Argument muss ein anderer Platzhalter angegeben werden, dessen Ergebnis eine Gleitkommazahl enthält. Von dieser Zahl wird der Wert vor dem Komma genommen |
| vorname_empfaenger | | Brief | ✓ | Brief | Vorname des Empfängers, falls Arzt oder Patient |
| x | ✓ | Patient | | Karteiein... | Komplexes Kommando zur Übernahme von Karteieinträgen mit vielen Filter- und Formatierungsmöglichkeiten. Siehe Konfigurator! |
| zwischenablage | | ohne | | Steuerko... | Gibt den Text aus der Zwischenablage aus, sofern vorhanden |

---

## Statistik

**Gesamt: ~370 Text-Kommandos** (aus 10 Screenshot-Seiten extrahiert)

### Nach Kontext:
- Patient: ~200 Kommandos (größte Gruppe)
- Privatrechnung: ~80 Kommandos
- Brief: ~20 Kommandos
- Besuch: ~20 Kommandos
- Betriebsstätte: ~20 Kommandos
- Nutzer: ~20 Kommandos
- Kassenbuch: ~15 Kommandos
- HZV-Importbericht: ~20 Kommandos
- Sammelrechnung: ~10 Kommandos
- Terminerinnerung: ~6 Kommandos
- Laborbefund: ~5 Kommandos
- ohne (Steuerkommandos): ~15 Kommandos
- Formulare: ~10 Kommandos
- Nachricht: ~2 Kommandos
- Kalendertag: ~2 Kommandos
- Patiententermine: ~3 Kommandos
- Warenbestellung: ~3 Kommandos

### Nach Themen:
- Patient: größte Gruppe
- Privatrec...: Privatrechnung
- Praxis: Nutzer/Betriebsstätte
- Betriebs...: Betriebsstätte
- Besuch: Besuchsdaten
- Augen: Ophthalmologie (~30 Kommandos)
- Steuerko...: Steuerkommandos (if, regex, score etc.)
- Termine: Terminverwaltung
- Psychot...: Psychotherapie
- Labor: Laborwerte
- Formulare: Formular-Zugriff
- Karteiein...: Karteieinträge
- Leistung...: Leistungen
- Medikam...: Medikamente
- DMP: Disease-Management
- Datum: Datumskommandos
- Kassenb...: Kassenbuch
- HZV: Hausarztzentrierte Versorgung
- OP: OP-Termin
- Impfung: Impfstatus
- Einkauf: Warenbestellung
- Mutterp...: Mutterpass
- EPA: Elektronische Patientenakte
