---
name: tomedo-kommandos
description: >-
  Dokumentiert das vollstaendige tomedo-Kommandosystem (Briefkommandos/Platzhalter). Verwende
  diesen Skill IMMER wenn tomedo-Briefkommandos, Platzhalter, Kommandos, Briefvorlagen-
  Platzhalter, Vorbefuellung, selektierterTermin, Terminerinnerung, if-Kommando, d-Kommando,
  x-Kommando, karteiEintragWert, formularEintrag, KeyPath, regex, score, Steuerkommando,
  Tabellenplatzhalter, Bildkommando, PDF-Kommando, Patientenformular-Auslesen, CKE-Feldwerte, oder
  Kommando-Syntax erwaehnt werden. Auch verwenden bei: Briefvorlage erstellen, Kommando
  nachschlagen, Platzhalter-Syntax, Karteieintrag auslesen, Formularwert abfragen, bedingten Text,
  Datum formatieren, Laborwerte im Brief, Leistungen auflisten, Diagnose pruefen, Termin-
  Platzhalter konfigurieren, oder jede Frage zu $[...]$-Syntax in tomedo. Der Skill enthaelt rund 600
  Kommandos, 16 Konfiguratoren mit vollstaendiger Syntax, Steuerkommandos, %-Ersetzungsmuster fuer
  Termine, und Praxis-Patterns.
metadata:
  version: 1.7
---

# tomedo Kommandos-Skill

Dieser Skill dokumentiert das gesamte tomedo-Kommandosystem (Briefkommandos/Platzhalter), das an vielen Stellen in tomedo verwendet wird:

- **Briefvorlagen** — Platzhalter in Arztbriefen (`$[anrede]$`, `$[patient_id]$`)
- **Aktionsketten-Bedingungen** — Logische Prüfungen (`$[&p.alter]$` ist größer als 65)
- **Aktionsketten-Vorbefüllung** — Karteieintrag mit dynamischem Inhalt vorbefüllen
- **Textbausteine** — Dynamische Inhalte in Textbausteinen
- **Custom-Karteieinträge (CKE)** — Vorbefüllung von Feldern
- **Formulare** — Dynamische Feldwerte in Custom-Formularen
- **Terminerinnerungen / Terminzettel** — %-Platzhalter für Termininfos
- **Privatrechnungen** — Rechnungsvorlagen mit Leistungsdetails

## Kommando-Syntax — Grundregeln

```
Einfach:           $[kommandoName]$
Mit Parametern:    $[kommandoName param1 param2 ... paramN]$
KeyPath:           $[&objekt.attribut.unterattribut]$
```

### Parameter-Regeln
- Parameter durch **einfache Leerzeichen** getrennt; mehrere Leerzeichen hintereinander zählen wie eines
- `_` (Unterstrich) = Leerzeichen **innerhalb** eines Parameter-Werts — aber nur bei den Argumenten, für die
  das Kommando das vorsieht (z. B. Werte im `if`, Text bei `kommandorahmen`, Paare bei `ersetze`). **Nicht**
  beim Ausdruck von `regex`, bei Typ und Key von `karteiEintragWert`, beim Feldnamen von `formularEintrag`
  und im Muster von `patientenTermine`/`selektierteTermine` [ungeprüft]
- `\n` = Zeilenumbruch, `\u` = echter Unterstrich, `\t` = Tabulator, `\\` = Backslash
- Einfache Anführungszeichen `'` umschließen Werte mit Leerzeichen — nur bei `if`/`tab_if`
  (Werte nach dem Operator) und beim Format des `d`-Kommandos; `patientenTermine` und `-trenner` nutzen
  doppelte Anführungszeichen [ungeprüft]
- `%@` = Platzhalter für Variable in Beschreibungen (kein Kommando-Platzhalter)
- `<leer>` = leere Zeichenkette (in if-Vergleichen), `<nichtleer>` = beliebiger nicht leerer Wert (mit `zs_equals`)
- `XXX` = Ergebnis des Originalkommandos als Rückfallwert (in if-Kommandos) — nur als **ganzer** Rückfallwert,
  nie als Teil eines Textes

### 5 Kommando-Arten

| Art | Anzahl | Verwendung |
|---|---|---|
| **Text** | ~570 | Einfache Platzhalter, ggf. mit Parametern |
| **Tabelle** | ~60 frei + ~120 interne | In Tabellenvorlagen (Leistungen, Labor, Medikamente); interne nur in ihrer eigenen Vorlage |
| **KeyPath** | 45 dokumentiert | Direktzugriff auf Datenmodell (`$[&p.vorname]$`) |
| **Bild** | 9 | Logo, Unterschrift, QR-Code, Anhänge — nur in DOCX-Vorlagen |
| **PDF** | 23 | Karteieintrags-Übernahme in PDF-Formulare (Syntax `ana$` im Feld) |

Zahlen für eine deutsche Arztpraxis (Stand Oktober 2026). Die Kommandoliste zeigt
nur Kommandos des eigenen Produkts (Österreich, Schweiz, Zahnarzt, kuto und Heilmittelerbringer haben
eigene). **Veraltete** Kommandos sind ausgeblendet, laufen in bestehenden Vorlagen aber weiter.

### 27 Kontexte

Kommandos operieren in einem spezifischen Kontext: ohne (= Steuerkommandos), Arbeitsmedizin, Behandlungsfall, Besuch, Betriebsstätte, Brief, HZV-Importbericht, HZV-Importprotokoll, Kalendertag, Kassenbuch, Laborbefund, Laborwertedruck im Brief, Laborwertedruck kumulativ im Brief, Laborrechnung, Marcumarplan, Medikamentenetikett, Medikamentenplan, Nachricht, Nutzer, Operationsplan, Patient, Patientenliste, Patiententermine, Privatrechnung, Sammelrechnung, Terminerinnerung, Warenbestellung. („Formulare“ ist ein Thema, kein Kontext.)

### 16 Konfiguratoren

Komplexe Kommandos mit eigenem Builder-UI unter Admin → Kommandos → Konfiguratoren:
`a`, `d`, `dmp`, `formularEintrag`, `if`, `impfstatus`, `karteiEintragWert`, `kommandorahmen`, `KeyPath`, `lab`, `labor`, `Leistungen`, `medikamentenplan`, `regex`, `Termine`, `x`

### Auswertungsregeln [ungeprüft]

- **Reihenfolge der Auflösung:** Textkommando → KeyPath (`&…`) → Werte der Aktionskette/Statistik →
  **Textbaustein mit gleichem Kürzel** → nicht dokumentierte interne Namen. Ein Textbaustein, dessen
  Kürzel wie ein Kommando heißt, wird also nie eingesetzt. Kommandonamen unterscheiden Groß-/Kleinschreibung.
- **Nicht auflösbar:** Meldung „Die Sequenz … konnte nicht aufgelöst werden.“, der Rohtext `$[…]$` bleibt
  stehen (im KarteiChat-Eingabefeld wird er gelöscht). Ein **leeres** Ergebnis verschwindet ohne Meldung.
- **Verschachtelte `$[…]$`** werden zuerst ausgeführt und kodiert eingesetzt (Leerzeichen als `_`, leer als
  `<leer>`). Im `if` das Kommando deshalb direkt angeben (`$[if pt …]$`, nicht `$[if $[pt]$ …]$`) und
  Platzhalter in Ausgabewerten als `${…}$` schreiben.
- **Nur in DOCX-Briefvorlagen** laufen `a`, `labor`, `medikamentenplan`, `impfstatus`, `med`, die
  Leistungsgruppen-Klammern sowie alle Bild- und Tabellenkommandos — nicht in Aktionsketten, CKE,
  Textbausteinen, Skripten oder im KarteiChat.
- **Der Kontext wird zur Laufzeit nicht geprüft.** Fehlt das Objekt, ist das Ergebnis leer. Im Patientenumfeld
  setzt tomedo als Privatrechnung die gewählte, sonst die **jüngste sichtbare** Rechnung — Rechnungskommandos
  liefern dort also oft doch einen Wert.

## Workflow

1. **Referenzdatei nach Bedarf lesen:**
   - Welches Kommando gibt es? → `references/text-kommandos.md` (370 Kommandos)
   - Tabellenplatzhalter? → `references/tabellen-kommandos.md` (140 Kommandos)
   - KeyPath / Bild / PDF? → `references/keypath-bild-pdf-kommandos.md`
   - Konfigurator-Syntax (if, d, x, karteiEintragWert, formularEintrag, regex, l, selektierterTermin)? → `references/konfiguratoren-steuerkommandos.md`

2. **Kontext beachten:** Kommandos funktionieren nur im passenden Kontext. Ohne Privatrechnung bleibt ein Privatrechnungs-Kommando (`pr_betrag`) leer; im Patientenumfeld nimmt tomedo die jüngste sichtbare Rechnung [ungeprüft]. Termin-Kommandos brauchen einen mitgegebenen Termin (siehe Konfiguratoren-Referenz, `selektierterTermin`).

3. **Vorlagen-Abhängigkeit prüfen:** Viele Kommandos setzen vorhandene Daten voraus (CKE mit Variablenname, Patientenformular mit Kürzel, etc.)

4. **Testen empfehlen:** Admin → Kommandos → Kommando auswählen → Knopf **„Testen“** führt den Platzhalter im Textfeld aus. Bezug laut Tooltip: Besuch der zuletzt geöffneten Kartei (nach aktuellem Stand der im Hauptfenster gewählte Besuch [ungeprüft]). Bei `if`, `x`, `if_then` und anderen DOCX-Kommandos öffnet „Testen“ ein DOCX statt des Ergebnisfensters [ungeprüft]. Für Bedingungen gibt es zusätzlich „Testen“ in der Bedingungsverwaltung.

## Die wichtigsten Kommandos für Aktionsketten

| Kommando | Zweck | Häufigkeit |
|---|---|---|
| `$[palter]$` oder `$[&p.alter]$` | Patientenalter in Jahren | ⭐⭐⭐ |
| `$[patient_geschlecht]$` | Geschlecht als Langtext („männlich“ / „weiblich“) | ⭐⭐⭐ |
| `$[patient_versichertenstatus]$` | „privat“ / „gesetzlich“ | ⭐⭐⭐ |
| `$[formularEintrag KÜR VAR N]$` | Wert aus Patientenformular | ⭐⭐⭐ |
| `$[karteiEintragWert TYP KEY FMT SEL]$` | Wert aus Karteieintrag/CKE | ⭐⭐⭐ |
| `$[d S SS]$` | Datum formatiert | ⭐⭐⭐ |
| `$[istMarkerGesetzt NAME]$` | Marker-Check (0 oder 1) | ⭐⭐⭐ |
| `$[if KMD OP V1 A1 V2 A2 RW]$` | Bedingte Auswertung (erster Treffer gewinnt) | ⭐⭐⭐ |
| `$[if_then KMD1 OP V KMD2]$` | Bedingte Kommandoausführung | ⭐⭐ |
| `$[x (DIA;DDI) _ _ _ NN NNNN NNNN ICDvornauchAbgesetzteDiagnosen K _]$` mit Relation „enthält“ | Diagnose vorhanden? (ICD-Liste aller Diagnosen; `DIA+DDI` aus Fassung 1.5 liefert leer, ohne `auchAbgesetzteDiagnosen` fehlen ältere Akutdiagnosen [ungeprüft]) | ⭐⭐ |
| `$[x KE-TYP ...]$` | Komplexes KE-Auslesen | ⭐⭐ |
| `$[pr_rechnungsSummeReal]$` | Privatrechnungssumme | ⭐⭐ |
| `$[regex PATTERN KMD]$` | Regex auf Kommando-Ergebnis | ⭐ |

**Nicht verwenden** (Stand Oktober 2026): `$[&p.geschlecht]$` und
`$[&p.versicherungsart]$` — der Patient hat diese Attribute nicht, das Geschlecht liegt in den
Patientendetails; `$[&heute]$` — einen Keypath `heute` gibt es nicht. Ein solcher Keypath liefert keinen
leeren Wert, sondern den Text „Fehler: Keypath … konnte nicht aufgelöst werden!“, und die Bedingung rechnet
still damit weiter. `$[d …]$` ist das **Datums-Kommando**, kein Diagnose-Check: `$[d I48.1]$` prüft keine Diagnose;
`I` ist keine Datumsart, und `d` liefert dann das **heutige Datum** [ungeprüft] (Fassung 1.5 nannte
hier „-“; „-“ kommt nur, wenn eine gültige Datumsart kein Datum findet).

## Achtung: Operatornamen sind kontextabhängig!

| Kontext | Gleichheit | Ungleichheit | Enthält | Enthält nicht |
|---|---|---|---|---|
| `$[if ...]$` Kommando | `zs_equals` | `zs_not_equal` | `zs_contains` | `zs_not_contains` (dazu `zs_less_than`, `zs_greater_than`) |
| `%if(...)` Termin-Platzhalter | `zsEquals` | `zsNotEqual` | `zsContains` | `zsNotContains` |
| Aktionsketten-Bedingung | `ist` | `ist nicht` | `enthält` | `enthält nicht` |

`%if` kennt kein kleiner/größer. Alle Vergleiche unterscheiden Groß-/Kleinschreibung.

## Validierte Praxis-Patterns (Realfälle 2026)

Am Echtfall geprüfte Muster und Fallstricke aus dem Arztbrief-Export. Jede Aussage ist
in tomedo gegengeprüft; abweichende Vermutungen aus der Onlinehilfe sind als solche
gekennzeichnet.

### x-Kommando: Datum in der Ausgabe (validiert 06/2026)

- Die **Befund-Familie** (`SOZ`, `BEF`, `BEH_AB`) mit Flag-Block `… NJ NNJN NNNN _ …` gibt **KEIN** Datum pro Eintrag aus.
- Die **Verlaufs-Familie** (`ANA`) mit `… JN NJ22 NNND invTime …` stellt jedem Eintrag das **Datum voran** (`TT.MM.JJJJ <Text>`), chronologisch sortiert. Am selben Arztbrief-Export gegengeprüft.
- **Mehrfachtyp**: kommasepariert `$[x <KÜRZEL-A>,<KÜRZEL-B> …]$` (wie `DIA,DIAX`) = getrennte Gruppen nacheinander; `$[x (<KÜRZEL-A>;<KÜRZEL-B>) …]$` = eine gemischte Gruppe. **Berichtigt:** Die Plus-Form `DIA+DDI` (Fassung 1.5: „funktioniert“) wertet tomedo nicht aus — sie gilt als ein unbekanntes Kürzel und liefert leer [ungeprüft]. Immer mit **[Testen]** verifizieren.
- **Doku-Gap geschlossen (Beschreibung in der Kommandoliste):** In `… JN NJ22 NNND invTime …` ist `NJ22` die Umbruch-Gruppe (d₁–d₄), `NNND` die Ausgabe-Gruppe (e₁–e₄, `D` = Datum als Überschrift je neuem Tag), `invTime` sortiert aufsteigend. Vollständige Parameter in `references/konfiguratoren-steuerkommandos.md` → x.

### Matrix-Zellen als Klartext: if-Mapping ZeileN=SpalteM (validiert 06/2026)

PatF-Matrix-Felder liefern roh `{Zeile1=Spalte8, Zeile2=…}`. Statt diese Rohindizes auszugeben (oder per `regex` zu zerlegen — schlug fehl), die Zelle per `if … zs_contains` auf den Klartextwert mappen:

```
$[if formularEintrag <Formular> <matrixfeld> N zs_contains Zeile1=Spalte11 0 Zeile1=Spalte10 10 Zeile1=Spalte1 1 Zeile1=Spalte2 2 ... Zeile1=Spalte9 9]$
```

- **Selektion `N`** (nicht `d`); Formularkürzel muss zum Formular passen, in dem das Feld liegt (Matrix-Scores liegen oft im Quartalfragebogen, nicht in der Erstanamnese). Nach aktuellem Stand wirkt `d` wie `N` (jeder Wert ohne Ziffer = alle Formulare); der damalige Fehler hatte vermutlich eine andere Ursache [ungeprüft]. **Nicht** `0` verwenden: `0` heißt „nur heute ausgefüllte Bögen“.
- **Teilstring-Falle:** `zs_contains` ist Substring-Test → längere/kollidierende Vergleichswerte zuerst listen (`Spalte11`, `Spalte10` vor `Spalte1`), sonst Fehlmatch.
- `regex` über `formularEintrag` zum Zerlegen der Matrix hat im Test **nicht** funktioniert (leeres Ergebnis) — `if`-Mapping ist der validierte Weg.

### Briefvorlagen: Kompaktnotation wird wörtlich gedruckt

Dokumentations-Kurzschreibweisen sind **kein gültiger Vorlageninhalt**. In der Briefvorlage wird alles außerhalb von `$[…]$` als Klartext gedruckt. Im Echtexport erschienen wörtlich:
- `+ feldname` und `(2/3 analog)` (Sammelzeilen für Med 1–3 etc.),
- `<sys>` / `Systeme: …` / `Pro System: …` (Komorbiditäts-Platzhalterbeschreibung),
- `Wirkung/NW je Substanzklasse: zn-…{…}`, `/ risikofaktoren`, `/ psysoz-andere`.

**Regel:** Jedes auszulesende Feld bekommt eine **eigene, voll ausgeschriebene** `Label: $[…]$`-Zeile. Keine „analog"-Sammelzeilen, keine Prosa/Meta-Notizen (auch „Feld entfernt"-Hinweise werden gedruckt) im Vorlagenkörper. Reference-`.md` (kompakt) und tomedo-Vorlage (ausgeschrieben) sind zwei verschiedene Artefakte.

### x-Kommando: Auswahl-Fenster — Anzahl-Cap schlägt Quartalsfenster (validiert 06/2026)

> **⚠️ Überarbeitung Oktober 2026 [ungeprüft] — widerspricht Teilen dieses Abschnitts:**
> (1) Position 5 (`NN`/`JN`) steuert laut Kommandoliste **nur den Fettdruck**; die Richtung der
> Auswahl steuert `invTime` (Position 8), und zwar **vor** dem Deckel — mit `invTime` und Cap n kommen die
> n **ältesten**. (2) `Nq` ist dokumentiert (Position 4, „1q = höchstens ein Quartal“). (3) Erst wird
> gefiltert, dann gekappt (T-47 damit vorläufig geklärt). (4) Bezug des Zeitfensters ist das **Datum der
> Tagesliste**, nicht zwingend das laufende Quartal. Die Messungen unten bleiben stehen, bis die Prüfung
> in der Testinstanz entschieden hat; beim Bauen neuer Kommandos `invTime` bewusst setzen oder weglassen.

- **Quartalsfenster (`4q`, `5q`, …) sind KEINE dokumentierte Zeitraum-Syntax.** Arg 3
  (`c`, Zeitraum) kennt laut Referenz nur `_` (kein Filter), `aq` (aktuelles Quartal) und
  `0-<Zahl>d` (letzte N Tage). Empirisch greifen `Nq`-Werte trotzdem — `4q` ist im
  Diagnose-Kommando (`konfiguratoren-steuerkommandos.md` → „ICD-Code-Ausgabe") produktiv
  belegt. Sie fenstern rückwärts vom Bezugsquartal: liegt dieses in einem alten Jahr, fallen
  aktuelle Einträge heraus (Symptom: „Export nur bis 2025"). **Undokumentiert = keine
  Bestandsgarantie über tomedo-Updates hinweg** → für neue Kommandos den Anzahl-Cap
  bevorzugen, bestehende `Nq`-Kommandos nach Updates gegenprüfen.
- **Sauberer Weg für „die N neuesten Einträge, jahresunabhängig":** Anzahl an **Arg 2
  (`b₁`)** setzen (`10` = max. 10; `_`/`inf` = alle) UND Arg 3 (`c`) = `_` (kein Zeitfilter).
- **Die Auswahl-Richtung steuert Arg 5 (`d₁d₂`, Sortierung), NICHT `invTime`.** Erstes
  Zeichen `N` = neueste zuerst, `J` = älteste zuerst. Der Anzahl-Cap greift am vorderen
  Ende der Sortierung: `NN` + Cap 10 → die **10 neuesten**; `JN` + Cap 10 → die 10 ältesten.
  `invTime` (Arg 8) dreht nur die **Anzeige**-Reihenfolge, nicht die Auswahl.
- **Belegt am Arztbrief-Export 06/2026:** `$[x ANA 10 _ _ JN … invTime …]$` lieferte die
  ältesten 10; nach `JN`→`NN` die neuesten 10 (inkl. 2026er-Einträge).
- Zweites Zeichen von `d₁d₂` weiterhin unbelegt (B57). `BEH_AB` blieb bewusst auf `NJ`
  (lief in der alten Form), Gegenprobe offen (B61).


**Nachtrag 08/2026 — Bezugspunkt des `Nq`-Fensters belegt.** `Nq` fenstert rückwärts vom
LAUFENDEN Quartal, dieses eingeschlossen: `8q` erfasst rund zwei Jahre, `16q` rund vier Jahre.
Am Realfall gegengeprüft (Arztbrief-Export der Referenzinstallation, 18.08.2026): ältester Eintrag ~24 Monate
zurück, jüngster enthalten, Ausgabe beginnt beim neuesten Eintrag (`d₁` = `N`).

- Die Warnung oben bleibt gültig — sie beschreibt den Fall, dass der Bezugspunkt **nicht** das
  laufende Quartal ist (Symptom „Export nur bis 2025"). Solange das Kommando aus einer
  Briefvorlage ohne eigenen Quartalsbezug läuft, ist der Bezugspunkt aktuell.
- Auch belegt: **`Nq` ist mit dem Anzahl-Deckel und mit `JN`/`NN` frei kombinierbar** — Arg 2
  (Anzahl) und Arg 3 (Zeitraum) sind getrennte Slots. `JN` + `Nq` + Cap 1 liefert damit den
  **ältesten Eintrag innerhalb** des Fensters, nicht den ältesten überhaupt. Diese Kombination
  ist die brauchbare Näherung an einen Stichtag, weil Arg 3 **keine absoluten Daten** kennt
  (nur `_`, `aq`, `0-<Zahl>d`, empirisch `Nq`). Ein per `0-<Zahl>d` nachgebauter Stichtag
  verfällt still und ist deshalb keine Option für dauerhafte Vorlagen.
- Offen: greifen Deckel und Fenster in dieser Kombination in der richtigen Reihenfolge
  (erst filtern, dann kappen)? Fällt der Deckel zuerst, ist das Fenster wirkungslos und der
  Output sieht trotzdem plausibel aus. Am Zielprojekt als Test **T-47** geführt.


> **⚠️ Überarbeitung Oktober 2026 [ungeprüft]:** Nach aktuellem Stand gilt der Deckel bei `A,B,C` **je
> Gruppe**, also je Typ; einen gemeinsamen Deckel gibt es nur mit `(A;B;C)`. Die Messung unten muss eine
> andere Ursache gehabt haben (z. B. `invTime`, Tageslisten-Datum, Rechte oder nicht exportierbarer Typ).
> Sie wird in der Testinstanz nachgestellt.

**Nachtrag 08/2026 — Mehrfachtyp-Listen: der Anzahl-Deckel gilt für die VEREINIGUNGSMENGE der
Typliste.** Bei `$[x A,B,C <Cap> …]$` werden **nicht** je Typ `<Cap>` Einträge geliefert,
sondern insgesamt. Ein häufiger Typ verdrängt damit die Einträge eines seltenen Typs
vollständig — **still**: der Block sieht gefüllt und plausibel aus, es fehlt nur eine Sorte.

- Gemessen am Arztbrief-Export der Referenzinstallation 18.08.2026: `$[x T,THE,SCHMA 20 …]$` an einem Patienten
  mit vielen `THE`- und wenigen `T`-Einträgen lieferte die `T`-Einträge nicht mehr.
- **Konsequenz für den Bau:** Sammelblöcke nur dort verwenden, wo die Typen inhaltlich
  gleichrangig sind **und** ähnlich häufig auftreten. Sonst je Typ ein eigenes Kommando mit
  eigenem Deckel — das kostet drei Zeilen und macht die Verdrängung unmöglich, statt sie
  hinterher melden zu müssen.
- Den Deckel anzuheben löst das Problem **nicht**: es verschiebt nur die Grenze, ohne die
  Zuordnung sichtbar zu machen. Welcher Typ wieviel Platz bekommt, bleibt unbestimmt.
- Gegenprobe beim Debuggen: dasselbe Kommando einmal je Einzeltyp absetzen und die Summen
  vergleichen. Ein leerer Einzeltyp bei gefülltem Sammelblock ist der Beweis.

**Fehlt Inhalt in einer x-Kommando-Ausgabe: Argumentbelegung lesen, bevor eine Ursache
vermutet wird.** Arg 2 (Anzahl-Cap) und Arg 3 (Zeitfenster) auf `_` schliessen Deckel und
Fenster als Ursache aus — dann bleiben nur Typliste und Ausgabeformat. Zwei stille Luecken sind
belegt (28.08.2026): eine unvollstaendige **Typliste** (`DIA,DIAX` ohne `DDI` verliert alle
Dauerdiagnosen) und ein filterndes **Ausgabeformat** (`nurAktiveDiagnosen` unterdrueckt
abgeschlossene Eintraege). Beide sind stumm — die Ausgabe sieht vollstaendig aus. Details,
Realfall und Korrekturkandidat: `references/konfiguratoren-steuerkommandos.md` →
„Diagnose-Kommando: zwei stille Luecken".

### formularEintrag: Feldnamen matchen EXAKT (validiert 07/2026)

- **Arg2 ist ein exakter Feldnamen-Match** — inklusive Groß-/Kleinschreibung und Umlauten.
  `Schmerz-vKorff` ≠ `schmerz-vkorff`. Ebenso: Arg2 nimmt **ausschließlich Element-Variablennamen**,
  **keine Metafelder** (`erstelltAm`/`created`/`datum` sind grundsätzlich nicht erreichbar).
- **Feldnamen-Umbenennungen im Formular brechen bestehende Briefkommandos STILL** — leeres Ergebnis,
  keine Fehlermeldung. Steht das Kommando in einem `if … zs_contains`-Mapping, ist die Leere zusätzlich
  unsichtbar, weil das `if` bei „kein Treffer" ebenfalls leer liefert.
- **Konsequenz bei Bogen-Versionswechseln:** alten Feldnamen als **Parallelzeile** mitführen, nicht
  ersetzen. Pro Patient ist dann konstruktionsgemäß nur eine der beiden Zeilen gefüllt.
- **Diagnose-Pflichtschritt bei jedem Leerbefund:** zuerst **Rohabfrage ohne `if`** absetzen. Ergebnis
  leer → Feld/Bogen fehlt. Ergebnis `{ZeileN=SpalteM}` → Feld da, Mapping trifft nicht. Ergebnis nackte
  Zahl → Element ist keine Matrix, `if`-Mapping muss weg.
- **Feldkataloge sind generationsabhängig:** ein per SQL erhobenes Bezeichner-Inventar belegt nur die
  Bogen-Generation, aus der es stammt — kein Nachweis für Altbögen.

### Kommandos in tomedo-Skripten (validiert 07/2026)

`Admin › Skripte (Python- und AppleScripts)` ist ein **weiterer Kommando-Kontext**: Skripte
werden vor der Ausfuehrung durch tomedo substituiert — dieselbe `$[…]$`-Syntax wie im Brief.
Nach aktuellem Stand [ungeprüft]: belegt für **AppleScripts**; für Python-Skripte ist keine Ersetzung
bekannt. Ausgewertet wird dort mit Patient und Besuch, aber ohne Arzt. `$[patientID]$`,
`$[patientVN]$`, `$[patientNN]$`, `$[patientGebDatum]$`, `$[home]$` u. a. sind **skripteigene** Ersetzungen,
keine Briefkommandos; `$[patientHerrFrau]$` wird dabei nicht ersetzt.
Im Bestand tatsaechlich verwendet:

`$[nutzerkuerzel]$` · `$[arbeitsplatz]$` · `$[pid]$` · `$[patientID]$` · `$[bk]$` · `$[pv]$` ·
`$[pn]$` · `$[patientVN]$` · `$[patientNN]$` · `$[bes_gebDatum]$` · `$[aktuellerTodoRaum]$`

**`$[arbeitsplatz]$` loest das Mehrfachausfuehrungs-Problem:** ein periodisches Skript, das
arbeitsplatzweit aktiviert ist, kann sich damit selbst auf genau einen Arbeitsplatz
einschraenken. Ausloesung: Zeitintervall (belegt: 1 s / 10 s / 60 s), Startup, Toolbar-Button
(Kartei / Tagesliste / Formular) und **Ereignis-Hooks** (belegt: Kartei geoeffnet/geschlossen).

⚠ Skripttexte liegen im **Klartext** in der Server-DB und im Cache jedes Arbeitsplatzes —
**keine Zugangsdaten in Skripten**.

### `formularEintrag`: leerzeichengetrennt → `shortTitle` ohne Leerzeichen

`$[formularEintrag <PatF> <shortTitle> N]$` trennt seine Parameter per **Leerzeichen**. Bisher galt: ein
`shortTitle` mit Leerzeichen ist damit **nicht adressierbar**. **Nach aktuellem Stand [ungeprüft]** setzt
`formularEintrag` aber alle Wörter zwischen erstem und letztem Argument mit einem Leerzeichen wieder zum
Feldnamen zusammen — einfache Leerzeichen wären adressierbar, doppelte nicht. Die Empfehlung „nur
Buchstaben" bleibt trotzdem richtig: sie vermeidet die Falle sicher. (Frühere Fassungen zeigten als
Auswahl `0`; `0` heißt „nur heute ausgefüllte Bögen“, für „neuestes“ `N` verwenden.)
Ebenso gilt weiter: `name` und `shortTitle` bestehender Felder **nie** aendern (bricht
Briefkommandos und Aktionsketten). Solange ein Bogen keine echten Antworten hat, ist
Umbenennen billig — danach nie wieder.

## Kommandos im KI-Kontext (LLM-Toolebene)

> Status: **dokumentiert** — Herstellerexport der LLM-Tool-Definitionen 09/2026, von uns nicht empirisch geprüft. Details, Auflagen und Kontrollpflichten: `references/llm-toolebene.md`.

Ein Kommando kann auf **drei** Pfaden ausgewertet werden, und sie sind unterschiedlich zuverlässig:

| Pfad | Wer wählt das Kommando? | Deterministisch |
|---|---|---|
| **A** Eingabefeld des KI-Chats — Client löst `$[…]$` nach dem Einfügen auf | Mensch | ja, sichtbar prüfbar |
| **B** `run_briefkommando` — das Modell ruft das Kommando im Patientenkontext auf; ausgewertet im Client auf dieselbe Weise wie A | **Modell** | nein |
| **C** `LLMToolCreateBriefkommando` — das Modell **erzeugt** ein chat-flüchtiges Kommando aus Name + Wert | Modell | nein, der Wert ist Modelloutput |

Dazu `list_briefkommandos`: listet Name, Beschreibung und Kontext, wertet ausdrücklich **nicht** aus.

**Regel:** Produktionskritische Werte gehören auf Pfad A. Pfad B ist wertvoll als **Test-Harness** — Kommando-Varianten am lebenden Patientenkontext durchprobieren, ohne eine Briefvorlage zu bauen — aber nur mit den drei Kontrollen aus `references/llm-toolebene.md` §2 (wörtliche Rückgabe verlangen, Positivkontrolle, Negativkontrolle mit falscher Syntax).

**Zwei Auflagen aus den Tool-Beschreibungen, die jeden Kommando-Einsatz im KI-Kontext betreffen:**

1. **Quellenverweise.** Der Chatkontext trägt die Idents mit; das Modell zitiert sie als `[1235]` bzw. `[&diag1224]`. Alle schreibenden Tools verlangen, dass der übergebene Inhalt **keine** solchen Verweise mehr enthält.
2. **Ident-Rundungsfalle.** 18-stellige tomedo-Idents sind immer als **String** zu führen, nie als Zahl — eine Zahl dieser Länge wird in JSON-Verarbeitung gerundet (`1.29...e+17`) und zeigt dann auf ein anderes oder gar kein Objekt.

## Synergie mit anderen Skills

### tomedo-aktionsketten
Kommandos werden in **Aktionsketten-Bedingungen** (Kommando-Spalte) und **Vorbefüllungen** (Karteieintrag anlegen → Vorbefüllung) verwendet. Die Bedingungen nutzen dieselben Kommandos, aber die **Relationen** sind UI-basiert (ist/ist nicht/enthält/größer als).

### tomedo-statistik-hql
Aktionskettenbedingungen und HQL-Queries nutzen teils **dieselben Datenpfade** (Keypaths), aber in unterschiedlicher Syntax:
- Bedingung: `$[&p.alter]$` → HQL: `EXTRACT(YEAR FROM AGE(p.geburtsdatum))`
- Bedingung: `$[x (DIA;DDI) _ _ _ NN NNNN NNNN ICDvornauchAbgesetzteDiagnosen K _]$` enthält `I48.1` → HQL: `WHERE d.icdCode = 'I48.1'` [ungeprüft]

### tomedo-textbausteine
Textbausteine können Kommandos enthalten. Besonders nützlich: `$[formularEintrag]$` zum Einbetten von Patientenformular-Antworten und `$[karteiEintragWert]$` zum Einbetten von CKE-Feldwerten.

### tomedo-karteichat-prompting
Kommandos sind dort der **Anker-Mechanismus**: ein im Chat-Eingabefeld aufgelöstes Kommando gibt dem Modell eine Tatsache vor, statt sie erschließen zu lassen. Der Fehlerkatalog dort (falsch beschrifteter Anker, leerer Anker, Anker ohne Auftrag) ist die Gegenseite dieses Skills — die Syntax kommt von hier, die Wirkungsregeln von dort. Für die Toolebene: `tomedo-karteichat-prompting/references/toolinventar-und-hebel.md`.

### tomedo-cke
Custom-Karteieinträge werden dort als `.dict` gebaut. Der **Variablenname** eines CKE-Feldes
ist der KEY für `$[karteiEintragWert …]$`; sprechende Namen (`nrs`, `bemerkung`) nimmt tomedo
beim Import an (belegt 28.09.2026). Der **Karteitext** eines CKE (`customKarteitextFormat`)
setzt Feldwerte mit `$[variable]$` zusammen — Import belegt, Auflösung am Patienten ungeprüft.
Nach dem ersten Produktiveinsatz keine Variablennamen mehr umbenennen: Briefvorlagen,
Statistik und KarteiChat-Prompts hängen daran.

### tomedo-marker
`$[istMarkerGesetzt NAME]$` liefert `1` oder `0`, `$[gesetzteMarkerVonGruppe GRUPPE]$` die gesetzten Marker
einer Gruppe als Komma-Liste. Den Markernamen genau wie angezeigt schreiben, mit Leerzeichen, ohne
Anführungszeichen. Umgekehrt gilt: Markerskripte können **keine** Briefkommandos oder Keypaths verwenden,
nur die Skriptvariablen des Markers. Automatische Marker baut `tomedo-marker` (Belege dort, Datei
`zusammenspiel.md`, §3 und §4).

## Status der Referenzdateien

| Datei | Status | Inhalt |
|---|---|---|
| `references/text-kommandos.md` | ✅ FERTIG, überarbeitet 10/2026 | rund 630 Text-Kommandos, alphabetisch, mit Kontext/Thema/Beschreibung; Nachtrag neuer Kommandos |
| `references/tabellen-kommandos.md` | ✅ FERTIG, überarbeitet 10/2026 | rund 180 Tabellen-Kommandos nach Kontext gruppiert, Hinweise zu internen Kommandos |
| `references/keypath-bild-pdf-kommandos.md` | ✅ FERTIG, überarbeitet 10/2026 | 45 KeyPaths + 9 Bild + 23 PDF |
| `references/konfiguratoren-steuerkommandos.md` | ✅ FERTIG | Vollständige Syntax für if, if_then, d, l, karteiEintragWert, formularEintrag, x, regex, score, bereich, ersetze, kommandorahmen + selektierterTermin %-Referenz (~60 Platzhalter) + patientenTermine-Parameter |
| `references/llm-toolebene.md` | 🟡 DOKUMENTIERT | Kommando-Auswertung im KI-Kontext: drei Pfade, `run_briefkommando` als Test-Harness mit Kontrollpflicht, Ident-Format der Quellenverweise, Rundungsfalle, Fragen-zu-Kommando-Zuordnung. **Nicht empirisch geprüft** |

---

*Stand 2026-10-22 (Fassung 1.6): alle Referenzen überarbeitet — rund 30 fehlende Kommandos und %-Codes ergänzt, x-Parameter, if-Ersetzungen, Alt-Syntax, `%if`, `patientenTermine`, `karteiEintragWert`, `formularEintrag`, `a`, `laborwert`, `d` berichtigt, 16 Konfiguratoren, 27 Kontexte. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt oder im Widerspruch zu früheren Messungen — vor dem Einsatz an einer Testakte prüfen. · Stand 2026-09-10: Referenz `llm-toolebene.md` ergänzt und Abschnitt „Kommandos im KI-Kontext" eingefügt (drei Auswertungspfade, Test-Harness, Ident-Rundungsfalle) — Quelle ist ein Herstellerexport, Status dokumentiert, nicht geprüft. · Stand 2026-08-05 (Admin-Review vor Org-Upload: Widerruf-Marker am Guard-Block, `Nq`-Zeitfilter als undokumentiert-aber-belegt eingeordnet) · Stand 2026-08-04 · Refactoring-Lauf tomedo-Tools: Abschnitt „Validierte Praxis-Patterns" ergänzt (x-Kommando-Datum, Matrix-Mapping per `if`, Kompaktnotation-Falle, Auswahl-Fenster `d₁d₂` vs. `invTime`, `formularEintrag`-Feldnamen exakt). Referenz `konfiguratoren-steuerkommandos.md` im selben Lauf um `AQ`/`AQ-n`, `AD`/`AD-n` und `soundsovielter` ergänzt.*
