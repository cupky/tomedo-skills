---
name: tomedo-kommandos
description: >-
  Dokumentiert das vollstaendige tomedo-Kommandosystem (Briefkommandos/Platzhalter). Verwende
  diesen Skill IMMER wenn tomedo-Briefkommandos, Platzhalter, Kommandos, Briefvorlagen-
  Platzhalter, Vorbefuellung, selektierterTermin, Terminerinnerung, if-Kommando, d-Kommando,
  x-Kommando, karteiEintragWert, formularEintrag, KeyPath, regex, score, Steuerkommando,
  Tabellenplatzhalter, Bildkommando, PDF-Kommando, Patientenformular-Auslesen, CKE-Feldwerte, oder
  Kommando-Syntax erwaehnt werden. Auch verwenden bei: Briefvorlage erstellen, Kommando
  nachschlagen, Platzhalter-Syntax, Karteieintrag auslesen, Formularwert abfragen, bedingten Text,
  Datum formatieren, Laborwerte im Brief, Leistungen auflisten, Diagnose pruefen, Termin-
  Platzhalter konfigurieren, oder jede Frage zu $[...]$-Syntax in tomedo. Der Skill enthaelt ~580
  Kommandos, 14 Konfiguratoren mit vollstaendiger Syntax, Steuerkommandos, %-Ersetzungsmuster fuer
  Termine, und Praxis-Patterns.
metadata:
  version: 1.1
---

# tomedo Kommandos-Skill

Dieser Skill dokumentiert das gesamte tomedo-Kommandosystem (Briefkommandos/Platzhalter), das an vielen Stellen in tomedo verwendet wird:

- **Briefvorlagen** — Platzhalter in Arztbriefen (`$[anrede]$`, `$[patient_id]$`)
- **Aktionsketten-Bedingungen** — Logische Prüfungen (`$[&p.alter]$` ist größer als 65)
- **Aktionsketten-Vorbefüllung** — Karteieintrag mit dynamischem Inhalt vorbefüllen
- **Textbausteine** — Dynamische Inhalte in Textbausteinen
- **Custom-Karteieinträge (CKE)** — Vorbefüllung von Feldern
- **Formulare** — Dynamische Feldwerte in Custom-Formularen
- **Terminerinnerungen / Terminzettel** — %-Platzhalter für Termininfos
- **Privatrechnungen** — Rechnungsvorlagen mit Leistungsdetails

## Kommando-Syntax — Grundregeln

```
Einfach:           $[kommandoName]$
Mit Parametern:    $[kommandoName param1 param2 ... paramN]$
KeyPath:           $[&objekt.attribut.unterattribut]$
```

### Parameter-Regeln
- Parameter durch **Leerzeichen** getrennt
- `_` (Unterstrich) = Leerzeichen **innerhalb** eines Parameter-Werts
- `\n` = Zeilenumbruch
- Einfache Anführungszeichen `'` umschließen Parameter mit Sonderzeichen
- `%@` = Platzhalter für Variable in Beschreibungen
- `<leer>` = leere Zeichenkette (in if-Vergleichen)
- `XXX` = Ergebnis des Originalkommandos als Rückfallwert (in if-Kommandos)

### 5 Kommando-Arten

| Art | Anzahl | Verwendung |
|---|---|---|
| **Text** | ~370 | Einfache Platzhalter, ggf. mit Parametern |
| **Tabelle** | ~140 | In Tabellenvorlagen (Leistungen, Labor, Medikamente) |
| **KeyPath** | ~40+ | Direktzugriff auf Datenmodell (`$[&p.vorname]$`) |
| **Bild** | 8 | Logo, Unterschrift, QR-Code, Anhänge |
| **PDF** | 23 | Karteieintrags-Übernahme in PDF-Formulare |

### ~25 Kontexte

Kommandos operieren in einem spezifischen Kontext: Patient, Privatrechnung, Brief, Besuch, Betriebsstätte, Nutzer, Kassenbuch, Laborbefund, Laborwertedruck, Medikamentenplan, Patiententermine, Kalendertag, Terminerinnerung, Sammelrechnung, HZV-Importbericht, Formulare, Nachricht, Warenbestellung, Arbeitsmedizin, Marcumarplan, Medikamentenetikett, Patientenliste, ohne (= Steuerkommandos)

### 14 Konfiguratoren

Komplexe Kommandos mit eigenem Builder-UI unter Admin → Kommandos:
`a`, `d`, `dmp`, `formularEintrag`, `if`, `impfstatus`, `karteiEintragWert`, `KeyPath`, `lab`, `labor`, `Leistungen`, `medikamentenplan`, `regex`, `x`

## Workflow

1. **Referenzdatei nach Bedarf lesen:**
   - Welches Kommando gibt es? → `references/text-kommandos.md` (370 Kommandos)
   - Tabellenplatzhalter? → `references/tabellen-kommandos.md` (140 Kommandos)
   - KeyPath / Bild / PDF? → `references/keypath-bild-pdf-kommandos.md`
   - Konfigurator-Syntax (if, d, x, karteiEintragWert, formularEintrag, regex, l, selektierterTermin)? → `references/konfiguratoren-steuerkommandos.md`

2. **Kontext beachten:** Kommandos funktionieren nur im passenden Kontext. Ein Privatrechnungs-Kommando (`pr_betrag`) funktioniert nicht im Patienten-Kontext.

3. **Vorlagen-Abhängigkeit prüfen:** Viele Kommandos setzen vorhandene Daten voraus (CKE mit Variablenname, Patientenformular mit Kürzel, etc.)

4. **Testen empfehlen:** Admin → Kommandos → Kommando auswählen → "Ausführen"-Button testet gegen einen Patienten.

## Die wichtigsten Kommandos für Aktionsketten

| Kommando | Zweck | Häufigkeit |
|---|---|---|
| `$[&p.alter]$` | Patientenalter | ⭐⭐⭐ |
| `$[&p.geschlecht]$` | Geschlecht (m/w/d) | ⭐⭐⭐ |
| `$[&p.versicherungsart]$` | GKV/PKV | ⭐⭐⭐ |
| `$[formularEintrag KÜR VAR N]$` | Wert aus Patientenformular | ⭐⭐⭐ |
| `$[karteiEintragWert TYP KEY FMT SEL]$` | Wert aus Karteieintrag/CKE | ⭐⭐⭐ |
| `$[d S SS]$` | Datum formatiert | ⭐⭐⭐ |
| `$[istMarkerGesetzt NAME]$` | Marker-Check (0 oder 1) | ⭐⭐⭐ |
| `$[if KMD OP V1 A1 V2 A2 RW]$` | Bedingte Auswertung | ⭐⭐⭐ |
| `$[if_then KMD1 OP V KMD2]$` | Bedingte Kommandoausführung | ⭐⭐ |
| `$[d ICD-CODE]$` (Diagnose) | Diagnose vorhanden? | ⭐⭐ |
| `$[x KE-TYP ...]$` | Komplexes KE-Auslesen | ⭐⭐ |
| `$[pr_rechnungsSummeReal]$` | Privatrechnungssumme | ⭐⭐ |
| `$[regex PATTERN KMD]$` | Regex auf Kommando-Ergebnis | ⭐ |

## Achtung: Operatornamen sind kontextabhängig!

| Kontext | Gleichheit | Ungleichheit | Enthält | Enthält nicht |
|---|---|---|---|---|
| `$[if ...]$` Kommando | `zs_equals` | `zs_not_equal` | `zs_contains` | `zs_not_contains` |
| `%if(...)` Termin-Platzhalter | `zsEquals` | `zsNotEqual` | `zsContains` | `zsNotContains` |
| Aktionsketten-Bedingung | `ist` | `ist nicht` | `enthält` | `enthält nicht` |

## Validierte Praxis-Patterns (Realfälle 2026)

Am Echtfall geprüfte Muster und Fallstricke aus dem Arztbrief-Export. Jede Aussage ist
in tomedo gegengeprüft; abweichende Vermutungen aus der Onlinehilfe sind als solche
gekennzeichnet.

### x-Kommando: Datum in der Ausgabe (validiert 06/2026)

- Die **Befund-Familie** (`SOZ`, `BEF`, `BEH_AB`) mit Flag-Block `… NJ NNJN NNNN _ …` gibt **KEIN** Datum pro Eintrag aus.
- Die **Verlaufs-Familie** (`ANA`) mit `… JN NJ22 NNND invTime …` stellt jedem Eintrag das **Datum voran** (`TT.MM.JJJJ <Text>`), chronologisch sortiert. Am selben Arztbrief-Export gegengeprüft.
- **Mehrfachtyp**: kommasepariert `$[x <KÜRZEL-A>,<KÜRZEL-B> …]$` (wie `DIA,DIAX`) oder plus `$[x <KÜRZEL-A>+<KÜRZEL-B> …]$` (wie `DIA+DDI`). Beide funktionieren; immer mit **[Testen]** verifizieren.
- **Doku-Gap**: Die Einzel-Semantik der `e₁e₂e₃e₄`/`f₁f₂f₃f₄`-Flags (insb. die `2`er in `NJ22`, das `D` in `NNND`) und `invTime` ist in der Referenz nicht vollständig erschlossen → für gezieltes „nur Datum" den **x-Konfigurator** (Admin → Kommandos → x) nutzen, dort ist das Datum eine beschriftete Option.

### Matrix-Zellen als Klartext: if-Mapping ZeileN=SpalteM (validiert 06/2026)

PatF-Matrix-Felder liefern roh `{Zeile1=Spalte8, Zeile2=…}`. Statt diese Rohindizes auszugeben (oder per `regex` zu zerlegen — schlug fehl), die Zelle per `if … zs_contains` auf den Klartextwert mappen:

```
$[if formularEintrag <Formular> <matrixfeld> N zs_contains Zeile1=Spalte11 0 Zeile1=Spalte10 10 Zeile1=Spalte1 1 Zeile1=Spalte2 2 ... Zeile1=Spalte9 9]$
```

- **Selektion `N`** (nicht `d`); Formularkürzel muss zum Formular passen, in dem das Feld liegt (Matrix-Scores liegen oft im Quartalfragebogen, nicht in der Erstanamnese).
- **Teilstring-Falle:** `zs_contains` ist Substring-Test → längere/kollidierende Vergleichswerte zuerst listen (`Spalte11`, `Spalte10` vor `Spalte1`), sonst Fehlmatch.
- `regex` über `formularEintrag` zum Zerlegen der Matrix hat im Test **nicht** funktioniert (leeres Ergebnis) — `if`-Mapping ist der validierte Weg.

### Briefvorlagen: Kompaktnotation wird wörtlich gedruckt

Dokumentations-Kurzschreibweisen sind **kein gültiger Vorlageninhalt**. In der Briefvorlage wird alles außerhalb von `$[…]$` als Klartext gedruckt. Im Echtexport erschienen wörtlich:
- `+ feldname` und `(2/3 analog)` (Sammelzeilen für Med 1–3 etc.),
- `<sys>` / `Systeme: …` / `Pro System: …` (Komorbiditäts-Platzhalterbeschreibung),
- `Wirkung/NW je Substanzklasse: zn-…{…}`, `/ risikofaktoren`, `/ psysoz-andere`.

**Regel:** Jedes auszulesende Feld bekommt eine **eigene, voll ausgeschriebene** `Label: $[…]$`-Zeile. Keine „analog"-Sammelzeilen, keine Prosa/Meta-Notizen (auch „Feld entfernt"-Hinweise werden gedruckt) im Vorlagenkörper. Reference-`.md` (kompakt) und tomedo-Vorlage (ausgeschrieben) sind zwei verschiedene Artefakte.

### x-Kommando: Auswahl-Fenster — Anzahl-Cap schlägt Quartalsfenster (validiert 06/2026)

- **Quartalsfenster (`4q`, `5q`, …) sind KEINE dokumentierte Zeitraum-Syntax.** Arg 3
  (`c`, Zeitraum) kennt laut Referenz nur `_` (kein Filter), `aq` (aktuelles Quartal) und
  `0-<Zahl>d` (letzte N Tage). Empirisch greifen `Nq`-Werte trotzdem — `4q` ist im
  Diagnose-Kommando (`konfiguratoren-steuerkommandos.md` → „ICD-Code-Ausgabe") produktiv
  belegt. Sie fenstern rückwärts vom Bezugsquartal: liegt dieses in einem alten Jahr, fallen
  aktuelle Einträge heraus (Symptom: „Export nur bis 2025"). **Undokumentiert = keine
  Bestandsgarantie über tomedo-Updates hinweg** → für neue Kommandos den Anzahl-Cap
  bevorzugen, bestehende `Nq`-Kommandos nach Updates gegenprüfen.
- **Sauberer Weg für „die N neuesten Einträge, jahresunabhängig":** Anzahl an **Arg 2
  (`b₁`)** setzen (`10` = max. 10; `_`/`inf` = alle) UND Arg 3 (`c`) = `_` (kein Zeitfilter).
- **Die Auswahl-Richtung steuert Arg 5 (`d₁d₂`, Sortierung), NICHT `invTime`.** Erstes
  Zeichen `N` = neueste zuerst, `J` = älteste zuerst. Der Anzahl-Cap greift am vorderen
  Ende der Sortierung: `NN` + Cap 10 → die **10 neuesten**; `JN` + Cap 10 → die 10 ältesten.
  `invTime` (Arg 8) dreht nur die **Anzeige**-Reihenfolge, nicht die Auswahl.
- **Belegt am Arztbrief-Export 06/2026:** `$[x ANA 10 _ _ JN … invTime …]$` lieferte die
  ältesten 10; nach `JN`→`NN` die neuesten 10 (inkl. 2026er-Einträge).
- Zweites Zeichen von `d₁d₂` weiterhin unbelegt (B57). `BEH_AB` blieb bewusst auf `NJ`
  (lief in der alten Form), Gegenprobe offen (B61).


**Nachtrag 08/2026 — Bezugspunkt des `Nq`-Fensters belegt.** `Nq` fenstert rückwärts vom
LAUFENDEN Quartal, dieses eingeschlossen: `8q` erfasst rund zwei Jahre, `16q` rund vier Jahre.
Am Realfall gegengeprüft (Arztbrief-Export der Referenzinstallation, 18.08.2026): ältester Eintrag ~24 Monate
zurück, jüngster enthalten, Ausgabe beginnt beim neuesten Eintrag (`d₁` = `N`).

- Die Warnung oben bleibt gültig — sie beschreibt den Fall, dass der Bezugspunkt **nicht** das
  laufende Quartal ist (Symptom „Export nur bis 2025"). Solange das Kommando aus einer
  Briefvorlage ohne eigenen Quartalsbezug läuft, ist der Bezugspunkt aktuell.
- Auch belegt: **`Nq` ist mit dem Anzahl-Deckel und mit `JN`/`NN` frei kombinierbar** — Arg 2
  (Anzahl) und Arg 3 (Zeitraum) sind getrennte Slots. `JN` + `Nq` + Cap 1 liefert damit den
  **ältesten Eintrag innerhalb** des Fensters, nicht den ältesten überhaupt. Diese Kombination
  ist die brauchbare Näherung an einen Stichtag, weil Arg 3 **keine absoluten Daten** kennt
  (nur `_`, `aq`, `0-<Zahl>d`, empirisch `Nq`). Ein per `0-<Zahl>d` nachgebauter Stichtag
  verfällt still und ist deshalb keine Option für dauerhafte Vorlagen.
- Offen: greifen Deckel und Fenster in dieser Kombination in der richtigen Reihenfolge
  (erst filtern, dann kappen)? Fällt der Deckel zuerst, ist das Fenster wirkungslos und der
  Output sieht trotzdem plausibel aus. Am Zielprojekt als Test **T-47** geführt.


**Nachtrag 08/2026 — Mehrfachtyp-Listen: der Anzahl-Deckel gilt für die VEREINIGUNGSMENGE der
Typliste.** Bei `$[x A,B,C <Cap> …]$` werden **nicht** je Typ `<Cap>` Einträge geliefert,
sondern insgesamt. Ein häufiger Typ verdrängt damit die Einträge eines seltenen Typs
vollständig — **still**: der Block sieht gefüllt und plausibel aus, es fehlt nur eine Sorte.

- Gemessen am Arztbrief-Export der Referenzinstallation 18.08.2026: `$[x T,THE,SCHMA 20 …]$` an einem Patienten
  mit vielen `THE`- und wenigen `T`-Einträgen lieferte die `T`-Einträge nicht mehr.
- **Konsequenz für den Bau:** Sammelblöcke nur dort verwenden, wo die Typen inhaltlich
  gleichrangig sind **und** ähnlich häufig auftreten. Sonst je Typ ein eigenes Kommando mit
  eigenem Deckel — das kostet drei Zeilen und macht die Verdrängung unmöglich, statt sie
  hinterher melden zu müssen.
- Den Deckel anzuheben löst das Problem **nicht**: es verschiebt nur die Grenze, ohne die
  Zuordnung sichtbar zu machen. Welcher Typ wieviel Platz bekommt, bleibt unbestimmt.
- Gegenprobe beim Debuggen: dasselbe Kommando einmal je Einzeltyp absetzen und die Summen
  vergleichen. Ein leerer Einzeltyp bei gefülltem Sammelblock ist der Beweis.

**Fehlt Inhalt in einer x-Kommando-Ausgabe: Argumentbelegung lesen, bevor eine Ursache
vermutet wird.** Arg 2 (Anzahl-Cap) und Arg 3 (Zeitfenster) auf `_` schliessen Deckel und
Fenster als Ursache aus — dann bleiben nur Typliste und Ausgabeformat. Zwei stille Luecken sind
belegt (28.08.2026): eine unvollstaendige **Typliste** (`DIA,DIAX` ohne `DDI` verliert alle
Dauerdiagnosen) und ein filterndes **Ausgabeformat** (`nurAktiveDiagnosen` unterdrueckt
abgeschlossene Eintraege). Beide sind stumm — die Ausgabe sieht vollstaendig aus. Details,
Realfall und Korrekturkandidat: `references/konfiguratoren-steuerkommandos.md` →
„Diagnose-Kommando: zwei stille Luecken".

### formularEintrag: Feldnamen matchen EXAKT (validiert 07/2026)

- **Arg2 ist ein exakter Feldnamen-Match** — inklusive Groß-/Kleinschreibung und Umlauten.
  `Schmerz-vKorff` ≠ `schmerz-vkorff`. Ebenso: Arg2 nimmt **ausschließlich Element-Variablennamen**,
  **keine Metafelder** (`erstelltAm`/`created`/`datum` sind grundsätzlich nicht erreichbar).
- **Feldnamen-Umbenennungen im Formular brechen bestehende Briefkommandos STILL** — leeres Ergebnis,
  keine Fehlermeldung. Steht das Kommando in einem `if … zs_contains`-Mapping, ist die Leere zusätzlich
  unsichtbar, weil das `if` bei „kein Treffer" ebenfalls leer liefert.
- **Konsequenz bei Bogen-Versionswechseln:** alten Feldnamen als **Parallelzeile** mitführen, nicht
  ersetzen. Pro Patient ist dann konstruktionsgemäß nur eine der beiden Zeilen gefüllt.
- **Diagnose-Pflichtschritt bei jedem Leerbefund:** zuerst **Rohabfrage ohne `if`** absetzen. Ergebnis
  leer → Feld/Bogen fehlt. Ergebnis `{ZeileN=SpalteM}` → Feld da, Mapping trifft nicht. Ergebnis nackte
  Zahl → Element ist keine Matrix, `if`-Mapping muss weg.
- **Feldkataloge sind generationsabhängig:** ein per SQL erhobenes Bezeichner-Inventar belegt nur die
  Bogen-Generation, aus der es stammt — kein Nachweis für Altbögen.

### Kommandos in tomedo-Skripten (validiert 07/2026)

`Admin › Skripte (Python- und AppleScripts)` ist ein **weiterer Kommando-Kontext**: Skripte
werden vor der Ausfuehrung durch tomedo substituiert — dieselbe `$[…]$`-Syntax wie im Brief.
Im Bestand tatsaechlich verwendet:

`$[nutzerkuerzel]$` · `$[arbeitsplatz]$` · `$[pid]$` · `$[patientID]$` · `$[bk]$` · `$[pv]$` ·
`$[pn]$` · `$[patientVN]$` · `$[patientNN]$` · `$[bes_gebDatum]$` · `$[aktuellerTodoRaum]$`

**`$[arbeitsplatz]$` loest das Mehrfachausfuehrungs-Problem:** ein periodisches Skript, das
arbeitsplatzweit aktiviert ist, kann sich damit selbst auf genau einen Arbeitsplatz
einschraenken. Ausloesung: Zeitintervall (belegt: 1 s / 10 s / 60 s), Startup, Toolbar-Button
(Kartei / Tagesliste / Formular) und **Ereignis-Hooks** (belegt: Kartei geoeffnet/geschlossen).

⚠ Quelltexte liegen im **Klartext** in der Server-DB und im Cache jedes Arbeitsplatzes —
**keine Zugangsdaten in Skripten**.

### `formularEintrag`: leerzeichengetrennt → `shortTitle` ohne Leerzeichen

`$[formularEintrag <PatF> <shortTitle> 0]$` trennt seine Parameter per **Leerzeichen**. Ein
`shortTitle` mit Leerzeichen ist damit **nicht adressierbar** — die bisherige Empfehlung
„nur Buchstaben" ist keine Stilfrage, sondern die Bedingung der Adressierbarkeit.
Ebenso gilt weiter: `name` und `shortTitle` bestehender Felder **nie** aendern (bricht
Briefkommandos und Aktionsketten). Solange ein Bogen keine echten Antworten hat, ist
Umbenennen billig — danach nie wieder.

## Kommandos im KI-Kontext (LLM-Toolebene)

> Status: **dokumentiert** — Herstellerexport der LLM-Tool-Definitionen 09/2026, von uns nicht empirisch geprüft. Details, Auflagen und Kontrollpflichten: `references/llm-toolebene.md`.

Ein Kommando kann auf **drei** Pfaden ausgewertet werden, und sie sind unterschiedlich zuverlässig:

| Pfad | Wer wählt das Kommando? | Deterministisch |
|---|---|---|
| **A** Eingabefeld des KI-Chats — Client löst `$[…]$` nach dem Einfügen auf | Mensch | ja, sichtbar prüfbar |
| **B** `run_briefkommando` — das Modell ruft das Kommando im Patientenkontext auf | **Modell** | nein |
| **C** `LLMToolCreateBriefkommando` — das Modell **erzeugt** ein chat-flüchtiges Kommando aus Name + Wert | Modell | nein, der Wert ist Modelloutput |

Dazu `list_briefkommandos`: listet Name, Beschreibung und Kontext, wertet ausdrücklich **nicht** aus.

**Regel:** Produktionskritische Werte gehören auf Pfad A. Pfad B ist wertvoll als **Test-Harness** — Kommando-Varianten am lebenden Patientenkontext durchprobieren, ohne eine Briefvorlage zu bauen — aber nur mit den drei Kontrollen aus `references/llm-toolebene.md` §2 (wörtliche Rückgabe verlangen, Positivkontrolle, Negativkontrolle mit falscher Syntax).

**Zwei Auflagen aus den Tool-Beschreibungen, die jeden Kommando-Einsatz im KI-Kontext betreffen:**

1. **Quellenverweise.** Der Chatkontext trägt die Idents mit; das Modell zitiert sie als `[1235]` bzw. `[&diag1224]`. Alle schreibenden Tools verlangen, dass der übergebene Inhalt **keine** solchen Verweise mehr enthält.
2. **Ident-Rundungsfalle.** 18-stellige tomedo-Idents sind immer als **String** zu führen, nie als Zahl — eine Zahl dieser Länge wird in JSON-Verarbeitung gerundet (`1.29...e+17`) und zeigt dann auf ein anderes oder gar kein Objekt.

## Synergie mit anderen Skills

### tomedo-aktionsketten
Kommandos werden in **Aktionsketten-Bedingungen** (Kommando-Spalte) und **Vorbefüllungen** (Karteieintrag anlegen → Vorbefüllung) verwendet. Die Bedingungen nutzen dieselben Kommandos, aber die **Relationen** sind UI-basiert (ist/ist nicht/enthält/größer als).

### tomedo-statistik-hql
Aktionskettenbedingungen und HQL-Queries nutzen teils **dieselben Datenpfade** (Keypaths), aber in unterschiedlicher Syntax:
- Bedingung: `$[&p.alter]$` → HQL: `EXTRACT(YEAR FROM AGE(p.geburtsdatum))`
- Bedingung: `$[d I48.1]$` → HQL: `WHERE d.icdCode = 'I48.1'`

### tomedo-textbausteine
Textbausteine können Kommandos enthalten. Besonders nützlich: `$[formularEintrag]$` zum Einbetten von Patientenformular-Antworten und `$[karteiEintragWert]$` zum Einbetten von CKE-Feldwerten.

### tomedo-karteichat-prompting
Kommandos sind dort der **Anker-Mechanismus**: ein im Chat-Eingabefeld aufgelöstes Kommando gibt dem Modell eine Tatsache vor, statt sie erschließen zu lassen. Der Fehlerkatalog dort (falsch beschrifteter Anker, leerer Anker, Anker ohne Auftrag) ist die Gegenseite dieses Skills — die Syntax kommt von hier, die Wirkungsregeln von dort. Für die Toolebene: `tomedo-karteichat-prompting/references/toolinventar-und-hebel.md`.

## Status der Referenzdateien

| Datei | Status | Inhalt |
|---|---|---|
| `references/text-kommandos.md` | ✅ FERTIG | ~370 Text-Kommandos, alphabetisch, mit Kontext/Thema/Beschreibung |
| `references/tabellen-kommandos.md` | ✅ FERTIG | ~140 Tabellen-Kommandos nach Kontext gruppiert |
| `references/keypath-bild-pdf-kommandos.md` | ✅ FERTIG | ~40 KeyPaths + 8 Bild + 23 PDF |
| `references/konfiguratoren-steuerkommandos.md` | ✅ FERTIG | Vollständige Syntax für if, if_then, d, l, karteiEintragWert, formularEintrag, x, regex, score, bereich, ersetze, kommandorahmen + selektierterTermin %-Referenz (~60 Platzhalter) + patientenTermine-Parameter |
| `references/llm-toolebene.md` | 🟡 DOKUMENTIERT | Kommando-Auswertung im KI-Kontext: drei Pfade, `run_briefkommando` als Test-Harness mit Kontrollpflicht, Ident-Format der Quellenverweise, Rundungsfalle, Fragen-zu-Kommando-Zuordnung. **Nicht empirisch geprüft** |

---

*Stand 2026-09-10: Referenz `llm-toolebene.md` ergänzt und Abschnitt „Kommandos im KI-Kontext" eingefügt (drei Auswertungspfade, Test-Harness, Ident-Rundungsfalle) — Quelle ist ein Herstellerexport, Status dokumentiert, nicht geprüft. · Stand 2026-08-05 (Admin-Review vor Org-Upload: Widerruf-Marker am Guard-Block, `Nq`-Zeitfilter als undokumentiert-aber-belegt eingeordnet) · Stand 2026-08-04 · Refactoring-Lauf tomedo-Tools: Abschnitt „Validierte Praxis-Patterns" ergänzt (x-Kommando-Datum, Matrix-Mapping per `if`, Kompaktnotation-Falle, Auswahl-Fenster `d₁d₂` vs. `invTime`, `formularEintrag`-Feldnamen exakt). Referenz `konfiguratoren-steuerkommandos.md` im selben Lauf um `AQ`/`AQ-n`, `AD`/`AD-n` und `soundsovielter` ergänzt.*
