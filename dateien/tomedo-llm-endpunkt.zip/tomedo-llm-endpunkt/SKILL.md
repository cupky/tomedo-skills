---
name: tomedo-llm-endpunkt
description: >-
  Baut und debuggt Aufrufe an den OpenAI-kompatiblen LLM-Service-Endpunkt des tomedo-Servers — den
  einzigen tomedo-KI-Pfad mit freier Modellwahl. Verwende diesen Skill IMMER wenn LLM-Service-
  Endpunkt, llmservice, chat/completions an tomedo, Modellwahl per Feld `model`, gemini-2.5-pro
  oder gemini-2.5-flash ueber tomedo, oder ein direkter API-Aufruf an den tomedo-Server erwaehnt
  werden. Auch verwenden bei: Endpunkt antwortet nicht, HTTP 404 auf llmservice, HTTP 422
  Unbekanntes Modell, HTTP 400 mit leerem Koerper, Antwort ohne Feld content, finish_reason
  length, Kosten hochrechnen, 5-Dollar-Limit, Monatsbudget, Token-Verbrauch unplausibel, Denk-Tokens,
  reasoning_effort, max_tokens, Streaming geht nicht, tools werden ignoriert, Modell zu langsam,
  Ausgabe streut zu stark, Stapellauf gegen den Endpunkt, Hintergrundprozess ruft tomedo-KI. NICHT
  fuer KarteiChat-Prompts (→ tomedo-karteichat-prompting), nicht fuer KI-Prompts in Aktionsketten (→
  tomedo-aktionsketten), nicht fuer HQL-Statistiken (→ tomedo-statistik-hql).
metadata:
  version: 1.4
---

# tomedo LLM-Service-Endpunkt

Dieser Skill ist ein **Navigator**. Die Belege, Messwerte und Codebausteine
liegen in `references/`. Hier stehen nur Einordnung, Schnellstart, die Fallen
und der Wegweiser.

Alle Angaben belegt am Produktivsystem, tomedo **v1.170.0.16**, Stand
2026-09-13, aus 143 Messaufrufen, davon 95 als Datei gesichert — nicht aus
Dokumentation.

Ueberarbeitet im Oktober 2026: tomedo selbst nutzt diesen Endpunkt nicht, sondern
eigene Wege zum Server mit eigenem Anfrageformat. Das Verhalten des Endpunkts bleibt
deshalb Messbefund. **[ungeprüft]** = nicht gemessen, noch nicht nachgestellt — vor dem
Einsatz an einer Testakte pruefen.

---

## 1 · Einordnung: drei KI-Pfade, nur einer mit Modellwahl

| Pfad | Modellwahl | Werkzeugzugriff | Zustaendiger Skill |
|---|---|---|---|
| KarteiChat | nein | **ja** | `tomedo-karteichat-prompting` |
| KI-Prompt in Aktionskette | nein | **ja** | `tomedo-aktionsketten` |
| **LLM-Service-Endpunkt** | **ja, pro Anfrage** | **nein** | dieser Skill |
| KI-Textgenerator (Kontexte) | nein | indirekt — nur die im Kontext hinterlegten, aufgeloesten Briefkommandos | `tomedo-karteichat-prompting` |
| KI-Zusammenfassung / Brief-Generatoren | nein | **nein** — nur uebergebene Stichpunkte, festes Abschnittsgeruest | `tomedo-karteichat-prompting` |

**Die Kernabwaegung:** Der Endpunkt gibt Modellwahl und Parameter, bietet aber
keinen Werkzeugzugriff. **Er sieht keine Akte.** Alles, was das Modell wissen
soll, muss in den Prompt. Fuer Aufgaben ueber Akteninhalte sind die beiden
anderen Pfade zustaendig — oder der Akteninhalt muss vorher beschafft und
eingebettet werden.

**Feste Modelle in tomedo selbst [ungeprüft]:** KarteiChat und KI-Prompt der
Aktionskette arbeiten mit einem von tomedo vorgegebenen Modell (derzeit
Gemini 2.5 Flash; beim KarteiChat entscheidet der Server). Eine Modellwahl je
Funktion gibt es in der Oberflaeche nicht — wer ein bestimmtes Modell braucht,
kommt nur ueber diesen Endpunkt.

---

## 2 · Schnellstart

```bash
SRV="http://{host}:{port}/{db}"   # tomedo > Ueber tomedo > Serveradresse
IDENT="{userIdent}"               # Testnutzer, nie ein Produktivnutzer

curl -i --max-time 60 \
  "$SRV/llmservice/$IDENT/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"gemini-2.5-pro","stream":false,
       "reasoning_effort":"minimal",
       "messages":[{"role":"user","content":"Antworte nur mit: OK"}]}'
```

`$SRV` enthaelt den Datenbanknamen mit — die vollstaendige Route steht in
`references/aufruf-und-parameter.md` Abschnitt 1, die Beschaffung der beiden
Werte in Abschnitt 2.

Drei Dinge, die im Schnellstart schon stecken:

- **`"messages"` ist ein Array.** Die offizielle Vorlage zeigt faelschlich ein
  Objekt.
- **Nie `curl -s` allein** — das verschluckt Fehler und liefert leere Ausgabe
  ohne Diagnose. Immer `-i` oder `-w '%{http_code}'`.
- **`reasoning_effort: minimal` gehoert in fast jeden Aufruf.** Es senkt die
  realen Kosten auf ein Drittel bis Viertel und die Latenz etwa auf die
  Haelfte. Siehe `references/kosten-und-budget.md`.

---

## 3 · Die fuenf Fallen

Jede einzelne hat in der Erprobung Zeit oder Geld gekostet.

1. **`HTTP 200` ist kein Beleg fuer eine Antwort.** Bei `finish_reason:
   "length"` fehlt das Feld `content` **vollstaendig** — nicht leer, es
   existiert nicht. Jeder Client muss das abfangen.
   → `references/fehlerdiagnose.md`

2. **`max_tokens` begrenzt Denken *und* Ausgabe zusammen.** Bei Pro reichten
   selbst 2000 Tokens nicht fuer eine einzige Antwortzeile — das Kontingent
   ging vollstaendig fuers Nachdenken drauf.
   → `references/kosten-und-budget.md`

3. **Das Feld `cost` untertreibt um Faktor 11 bis 543.** Es rechnet die
   Denk-Tokens nicht mit, Google berechnet sie aber.
   → `references/kosten-und-budget.md`

4. **Das Nutzerbudget bremst direkte Aufrufe nicht.** Belegt: 10,10 $ reale
   Kosten an einem frischen Nutzer, null Ablehnungen. Grund: Die
   Budgetsperre prueft tomedo vor seinen eigenen KI-Aufrufen — ein
   direkter Endpunkt-Aufruf laeuft daran vorbei **[ungeprüft]**.
   **Kostenkontrolle selbst bauen.**
   → `references/kosten-und-budget.md`

5. **`tools` und `stream` werden stillschweigend ignoriert** — kein Fehler,
   nur Wirkungslosigkeit. Wer `tools` mitschickt und auf Werkzeugaufrufe
   wartet, bekommt eine plausible, **frei erfundene** Textantwort.
   → `references/aufruf-und-parameter.md`

---

## 4 · Wegweiser

| Anliegen | Datei |
|---|---|
| Aufruf bauen, Werte beschaffen, Modellliste, welche Parameter gehen | `references/aufruf-und-parameter.md` |
| Kosten hochrechnen, Denk-Tokens, `reasoning_effort`, `max_tokens`, Budgetlage | `references/kosten-und-budget.md` |
| Fehlermeldung deuten, Antwort robust auswerten | `references/fehlerdiagnose.md` |
| Flash oder Pro? Latenz, Streuung, Formattreue | `references/modellwahl.md` |
| Stapelbetrieb, Hintergrundprozesse, Durchsatz, Messmethodik | `references/betrieb-und-messung.md` |

---

## 5 · Harte Randbedingungen

**Keine echten Patientendaten an den Endpunkt.** Die Antwort des Servers
enthaelt ein `Set-Cookie` fuer `.generativelanguage.googleapis.com` — die
Anfragen gehen nachweislich an Googles Generative Language API. Ob ein
Anonymisierungs-Gate davor noetig ist, ist eine **rechtliche** Frage fuer den
Datenschutzbeauftragten und in diesem Skill nicht zu entscheiden. Bis zu einer
dokumentierten Freigabe gilt: nur synthetische Demoakten.

Die tomedo-Oberflaeche nennt als Empfaenger der KI-Daten **zollsoft**;
abschaltbar ist das praxisweit unter Einstellungen › Praxis › Datenschutz ›
„tomedo Intelligence nutzen“ **[ungeprüft]**. Ob der Schalter auch diesen Endpunkt
sperrt, ist nicht belegt. Eine Einwilligungsabfrage vor der KI-Nutzung hat
tomedo nicht **[ungeprüft]**.

**Kostenkontrolle selbst fuehren.** Das Nutzerbudget greift bei direkten
Aufrufen nachweislich nicht. Nach jedem Aufruf die echten Kosten mitrechnen — der
Baustein steht in `references/kosten-und-budget.md`.

**Testnutzer statt Produktivnutzer.** Das Budget haengt am tomedo-Nutzer —
je Nutzer und Kalendermonat, Vorgabe 10 USD **[ungeprüft]**.

**Keine Reproduzierbarkeit erwarten.** `seed` wird abgelehnt; 20 Laeufe je
Modell mit identischem Prompt ergaben 20 verschiedene Ausgaben.

---


### Verbrauch ist serverseitig auslesbar

Die Tabelle `llmcall` protokolliert jeden Modellaufruf des tomedo-Servers — nicht nur den
freien Endpunkt, sondern auch KarteiChat und die Agent-Unteraufrufe. Felder: `date`,
`nutzer_ident`, `typ`, `modelname`, `tokeninputcount`, `tokenoutputcount`, `costincent`,
`visible`.

Damit ist Budgetkontrolle eine Abfrage statt einer Schaetzung: Verbrauch je Nutzer, je
Modell, je Aufruftyp, ueber jeden Zeitraum.

**`costincent` ist US-Cent zum Listenpreis des Modells.** Belegt am 22.09.2026: die
Gegenrechnung fuer `AgentSubcall` gegen Gemini 2.5 Flash (0,30 USD je Mio. Input, 2,50 USD
je Mio. Output) traf auf 0,2 Prozent genau. Beim Modellwechsel ist die Gegenrechnung zu
wiederholen — die Einheit gilt je Preisliste.

**Zwei Messhinweise, die Hochrechnungen sonst verfaelschen:**

- **Input dominiert.** Gemessen ueber einen Testvormittag: 4,34 Mio. Input-Token gegen
  170 Tsd. Output-Token, Verhaeltnis 0,04. Die Kosten haengen an der Kontextgroesse, nicht
  an der Antwortlaenge. Wer Kosten senken will, kuerzt den Kontext, nicht die Ausgabe.
- **Ein Nutzerschritt ist nicht ein Aufruf.** Eine KarteiChat-Interaktion erzeugte im
  Mittel zwei `KarteiChat`-Aufrufe plus drei bis vier `AgentSubcall`. Hochrechnungen je
  Nutzerfrage muessen den Faktor fuenf tragen.
- `modelname` traegt je nach `typ` unterschiedliche Praefixe (`gemini/gemini-2.5-flash`
  gegen `gemini-2.5-flash`) — nie auf Gleichheit filtern.
- Weitere `typ`-Werte, die tomedo-Funktionen setzen **[ungeprüft]**:
  `KarteiChatPreprocessing`, `AKEintrag_KI-Prompt` (KI-Prompt der Aktionskette),
  `LLMDocu` (Sprechstunden-Assistent), `IntelligentDictation`, `DokAssist`,
  `FormFieldAnalysis`, `textGeneration`. Welchen `typ` direkte Endpunkt-Aufrufe
  tragen, ist nicht gemessen.
- tomedo-Funktionen wiederholen eine unvollstaendige Antwort (Abbruch oder
  `finish_reason` nicht `stop`) bis zu dreimal **[ungeprüft]** — mehrere Zeilen
  fuer eine Frage koennen also auch Wiederholungen sein, jede mit Kosten.

## 6 · Was dieser Endpunkt nicht kann

- **Keinen Werkzeugzugriff** — er sieht keine Akte, keinen Termin, keine Leistung
- **Keine Reproduzierbarkeit** — `seed` wird abgelehnt
- **Kein Streaming** — `stream` wird stillschweigend ignoriert
- **Keine Embeddings** — also kein RAG ueber diesen Weg
- **Keine Kontostandsabfrage am Endpunkt** — tomedo selbst liest die
  Monatssumme des Nutzers anders, zaehlt dabei aber nur die gemeldeten Kosten
  (`references/kosten-und-budget.md` Abschnitt 4)
- **Keine Modellliste** — `/v1/models` gibt es nicht
- **Keine verlaessliche Kostenbremse** — siehe Falle 4

---

## 7 · Wirkungsbereich im tomedo-KI-Handbuch

Dieser Skill ist die Quelle fuer mehrere Abschnitte des Handbuchs (Stand v0.7).
**Wer hier eine Messzahl aendert, zieht sie dort in derselben Sitzung nach** —
in allen betroffenen Abschnitten, nicht nur in dem, der den Anlass gab.

| Handbuch | Was von hier einfliesst | Referenzdatei |
|---|---|---|
| **§8** LLM-Service-Endpunkt | Route und Routeninventar, Parameter-Positivliste, wirkungslose Felder, Fehlerbilder, launchd-Erreichbarkeit, Durchsatzgrenze | `aufruf-und-parameter.md`, `fehlerdiagnose.md`, `betrieb-und-messung.md` |
| **§9** Modellwahl und Modelleffekt | Vergleich bei n=20, Formattreue, Streuungsmasse, Empfehlung Pro mit `reasoning_effort: minimal` | `modellwahl.md` |
| **§12** Kosten | Untertreibung von `cost`, Denk-Tokens, `reasoning_effort`, `max_tokens`-Falle, Lasttest zum 5-$-Limit | `kosten-und-budget.md` |
| **§14** Grenzen und Fehlerquellen | Endpunkt-Systemgrenzen, Fehlerklassen „leere Antwort trotz HTTP 200" und „kleine Stichprobe taeuscht" | alle fuenf |
| **§15** Offene Fragen | F18 Promptgroesse, F19 Limitanrechnung, F20 ungemessene Modelle, F21 Systemdomaene | `kosten-und-budget.md`, `betrieb-und-messung.md` |

> **Warum das hier steht.** Handbuch v0.5 hat aus diesem Skill nur die
> Kostenaussage (§12) uebernommen und die Latenzkorrektur in §9 liegen lassen —
> obwohl beide aus derselben Messreihe stammen. Die falsche Zahl blieb eine
> Fassung laenger stehen. Die Tabelle oben ist die Gegenmassnahme.

> **Beim Erweitern dieses Skills:** Die Korrekturen an Beschreibungslaenge,
> Schnellstart und Kosten-Baustein sind kein Beiwerk — ohne sie scheitert der
> Org-Import. Nach jedem Neubau gegen die Checkliste in Abschnitt 4 des
> Handbuch-Anhangs beziehungsweise gegen das Gate-Script pruefen.
