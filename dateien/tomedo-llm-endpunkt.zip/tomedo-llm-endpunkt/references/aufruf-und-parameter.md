# Aufruf und Parameter

Gehoert zu `tomedo-llm-endpunkt`. Belegt an tomedo v1.170.0.16, 2026-09-13.

---

## 1 · Aufrufform

```text
http://{host}:{port}/{db}/llmservice/{userIdent}/v1/chat/completions
```

**Es gibt genau diese eine Route.** Geprueft und jeweils mit HTTP 404
beantwortet (RESTEasy-Meldung des Applikationsservers):

`/v1/models` · `/v1/models/{name}` · `/v1` · Wurzel · `/v1/embeddings` ·
`/v1/usage` · `/v1/limits` · `/usage` · `/limits`

Drei Folgen:

1. **Die Modellliste ist nicht abfragbar.** Sie muss aus der
   zollsoft-Dokumentation kommen; gueltige Namen lassen sich nur durch
   Ausprobieren pruefen (HTTP 422, Abschnitt 3).
2. **Der Kontostand ist nicht abfragbar.** Kein Weg, das verbleibende Guthaben
   programmatisch zu lesen.
3. **Keine Embeddings** — kein RAG ueber diesen Weg.

### Keine Kontingent-Header

Die Antwort enthaelt ausser den ueblichen Sicherheits-Headern
(`x-content-type-options`, `x-frame-options`, `x-robots-tag`,
`x-xss-protection`) **keinen einzigen** Header zu Rate Limit, Kontingent oder
Restguthaben. Ein Client kann eine drohende Sperre nicht vorhersehen.

---

## 2 · Die drei Werte beschaffen

| Wert | Woher |
|---|---|
| Server-URL inkl. Datenbankname | tomedo-Client: **tomedo > Ueber tomedo > Server-URL** |
| `userIdent` | tomedo-Statistik: `select Ident from Nutzer where Kuerzel = 'XXX'` — Statistikrechte noetig |
| Testnutzer | **nie** das Kuerzel eines produktiv arbeitenden Nutzers, wegen des Budgets |

**Diese Werte nie erraten und nie aus Foren uebernehmen.** Dort kursieren
Hostnamen und Idents, die nur beim jeweiligen Autor gelten.

Zugangsdaten nicht in Dateien ablegen, die spaeter weitergegeben werden. Ein
bewaehrtes Muster: eine Datei ausserhalb des Projektverzeichnisses mit
Dateirechten 600, die das Aufrufskript einliest.

---

## 3 · Modelle

`mistral-medium-latest`, `mistral-medium-2508`, `mistral-medium-2505`,
`mistral-small-latest`, `mistral-small-2506`, `mistral-small-2503`,
`mistral-small-2501`, `gemini-2.5-pro`, `gemini-2.5-flash`,
`gemini-2.5-flash-lite`

Das Feld `model` wird **serverseitig geprueft**. Ein unbekannter Name liefert
**HTTP 422** mit dem deutschsprachigen Klartext `Unbekanntes Modell` — ohne
JSON-Huelle. Die Meldung stammt damit aus der tomedo-Schicht, nicht von
Google: Der Server fuehrt eine eigene Positivliste. Die erfolgreiche Antwort
spiegelt den Namen im Feld `model` zurueck.

> **Nie das Modell nach seiner Identitaet fragen.** Sprachmodelle geben
> darueber haeufig Falsches an. Der Nachweis, dass die Modellwahl wirkt,
> laeuft ueber den 422-Test mit einem erfundenen Namen.

---

## 4 · Parameter — strenge Positivliste

| Parameter | Verhalten |
|---|---|
| `temperature` | akzeptiert (0 und 2 geprueft) |
| `top_p` | akzeptiert |
| `stop` | akzeptiert |
| `n` | akzeptiert, liefert tatsaechlich mehrere `choices` — kostet auch mehrfach |
| `response_format` | akzeptiert (`json_object` belegt) |
| `reasoning_effort` | akzeptiert — der Kostenhebel, siehe `kosten-und-budget.md` |
| `max_tokens` / `max_completion_tokens` | akzeptiert — **Falle**, siehe `kosten-und-budget.md` |
| `seed` | **HTTP 400** |
| `presence_penalty` | **HTTP 400** |
| `frequency_penalty` | **HTTP 400** |
| `thinking_budget` | **HTTP 400** |
| `extra_body` | **HTTP 400** |
| jeder unbekannte Name | **HTTP 400** |

Der Endpunkt fuehrt eine **Positivliste**: Was nicht darauf steht, wird
abgelehnt — auch OpenAI-uebliche Felder.

> **Der Antwortkoerper der 400er ist leer.** Keine Angabe, welcher Parameter
> stoerte. Beim Bau eines Aufrufs Parameter deshalb **einzeln** zuschalten und
> nach jedem Schritt testen.

### `seed` fehlt — keine Reproduzierbarkeit

20 Laeufe je Modell mit identischem Prompt ergaben **20 verschiedene
Ausgaben**. Wer deterministische Ergebnisse braucht, bekommt sie an diesem
Endpunkt nicht. Konstanz laesst sich nur annaehern — ueber Modellwahl
(Pro streut deutlich weniger, siehe `modellwahl.md`) und ueber strenge
Formatvorgaben im Prompt.

---

## 5 · Akzeptiert, aber wirkungslos

| Feld | Verhalten |
|---|---|
| `stream: true` | **kein** SSE-Strom — die Antwort kommt als `application/json` am Stueck |
| `tools` | **kein** Function Calling — normale Textantwort, kein `tool_calls` |

Beide erzeugen **keinen Fehler**, sie tun nur nichts.

> **Gefaehrlich bei `tools`:** Wer Werkzeuge definiert und auf Werkzeugaufrufe
> wartet, bekommt stattdessen eine plausible, **frei erfundene** Textantwort.
> Das Scheitern ist unsichtbar.

Das Fehlen von `stream` ist praktisch relevant: Bei einer langen
Briefgenerierung gibt es keine Zwischenausgabe, der Anwender sieht bis zum
Ende nichts.

---

## 6 · Was funktioniert

| Faehigkeit | Beleg |
|---|---|
| `system`-Rolle | Anweisung „Antworte ausschliesslich auf Latein" befolgt, Antwort `Salve.` |
| Mehrfachverlauf | dreiteiliger Verlauf mit `assistant`-Zwischenzug korrekt aufgeloest |
| `n` > 1 | liefert mehrere `choices` — kostet aber auch mehrfach |
| `response_format` | `json_object` wird angenommen |

**Der Endpunkt haelt keinen Zustand.** Fuer Prompt-Ketten muss der Verlauf bei
jedem Aufruf vollstaendig mitgeschickt werden.
