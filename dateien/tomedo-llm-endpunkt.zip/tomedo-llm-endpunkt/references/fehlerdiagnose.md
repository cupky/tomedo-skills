# Fehlerdiagnose und robuste Auswertung

Gehoert zu `tomedo-llm-endpunkt`. Belegt an tomedo v1.170.0.16, 2026-09-13;
HTTP 500 durch doppelten Schraegstrich nachgetragen 2026-09-28.

---

## 1 · Fehlertabelle

| Beobachtung | Ursache / Vorgehen |
|---|---|
| Verbindung scheitert, Timeout | Host oder Port falsch, oder Rechner nicht im Praxisnetz |
| HTTP 404 mit Hinweis auf die Authentifizierungsanfrage | serverseitig; trat Januar 2026 auf und wurde behoben — einmal wiederholen, dann zollsoft fragen |
| HTTP 404 sonst | Datenbankname im Pfad falsch, oder tomedo-Version aelter als das Quartalsupdate mit dem Endpunkt |
| HTTP 404 auf `/v1/models`, `/v1/usage` u.ae. | **kein Fehler** — es gibt nur `/v1/chat/completions` |
| **HTTP 500 nach etwa 20 ms**, Pfad in der Meldung mit `//llmservice` | doppelter Schraegstrich: die Server-URL endet auf `/` und wird mit `/llmservice` verkettet. Schraegstrich am Ende entfernen, etwa mit `${SRV%/}`. Sieht aus wie ein Serverausfall, ist aber nur eine falsch zusammengesetzte Adresse; eine unbekannte Route liefert dagegen HTTP 404 (belegt 2026-09-28) |
| HTTP 403 / Ablehnung | falscher `userIdent` |
| **HTTP 422** `Unbekanntes Modell` | Modellname nicht auf der Serverliste → `aufruf-und-parameter.md` Abschnitt 3 |
| **HTTP 400, leerer Koerper** | nicht unterstuetzter Parameter — Parameter einzeln durchprobieren → `aufruf-und-parameter.md` Abschnitt 4 |
| **HTTP 200, aber `content` fehlt** | `finish_reason: length`, `max_tokens` zu klein → `kosten-und-budget.md` Abschnitt 3 |
| HTTP 200, Inhalt leer | Antwortextraktion pruefen: `choices[0].message.content` |
| `total_tokens` unplausibel hoch | Denk-Tokens — **kein Fehler** → `kosten-und-budget.md` Abschnitt 1 |
| `tools` bleibt ohne Wirkung | erwartet, wird stillschweigend ignoriert |
| Antwort kommt nicht stueckweise | erwartet, `stream` ist wirkungslos |
| Gleicher Prompt, jedes Mal andere Ausgabe | erwartet, `seed` wird abgelehnt |
| Antwortzeit unter Last verdoppelt | erwartet, der Server serialisiert → `betrieb-und-messung.md` |

---

## 2 · Diagnosereihenfolge

Bei einem neuen oder kaputten Aufruf in dieser Reihenfolge vorgehen:

1. **Minimalaufruf** mit `gemini-2.5-flash` und `"Antworte nur mit: OK"`.
   Kommt HTTP 200? Wenn nein, liegt es an URL, Ident oder Netz — nicht am
   Prompt. Zuerst den Pfad in der Fehlermeldung auf `//` pruefen.
2. **Modellname** tauschen. HTTP 422 heisst: Name nicht auf der Liste.
3. **Parameter einzeln zuschalten.** Ein leerer 400 sagt nicht, welcher
   stoerte — also nacheinander.
4. **`finish_reason` ansehen**, bevor der Text verwendet wird.
5. **Erst dann den Prompt verdaechtigen.**

Immer mit `-i` oder `-w '%{http_code}'` arbeiten. `curl -s` allein verschluckt
Fehlermeldungen und hat schon zu einer leeren Ausgabe ohne jede Diagnose
gefuehrt.

---

## 3 · Baustein: robuste Antwortauswertung

```python
def inhalt_aus_antwort(antwort):
    """Gibt (text, hinweis) zurueck. text ist None, wenn nichts Brauchbares kam.

    Faengt den stillen Fehlerfall ab: Bei finish_reason 'length' liefert der
    Endpunkt HTTP 200, aber das Feld 'content' fehlt im message-Objekt
    vollstaendig — es ist nicht leer, es existiert nicht.
    """
    try:
        wahl = antwort["choices"][0]
    except (KeyError, IndexError):
        return None, "keine choices im Antwortobjekt"

    grund = wahl.get("finish_reason")
    text = wahl.get("message", {}).get("content")

    if text is None:
        return None, (f"kein content, finish_reason={grund!r} — "
                      "max_tokens zu klein, das Budget ging fuer Denk-Tokens drauf")
    if grund == "length":
        return text, "ACHTUNG abgeschnitten, finish_reason=length"
    return text, None
```

Verwendung:

```python
text, hinweis = inhalt_aus_antwort(antwort)
if text is None:
    raise RuntimeError(f"Endpunkt lieferte keine Antwort: {hinweis}")
if hinweis:
    print(f"Warnung: {hinweis}")
```

---

## 4 · Baustein: Aufruf ohne Fehlerunterdrueckung

```python
import json, urllib.error, urllib.request


def aufruf(url, nutzlast, timeout=300):
    """Gibt (status, objekt_oder_text) zurueck. Verschluckt nichts."""
    req = urllib.request.Request(
        url, data=json.dumps(nutzlast).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        # Wichtig: Koerper mitlesen. Bei 422 steht dort der Klartext,
        # bei 400 ist er leer — das ist selbst die Diagnose.
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"
```

**Timeout grosszuegig setzen.** 300 s sind angemessen: Unter Last wurden
einzelne Pro-Aufrufe mit `reasoning_effort: high` ueber 130 s gemessen.
tomedo selbst wartet 180 s, bei Agenten 300 s **[ungeprüft]**.

---

## 5 · Meldungen in der tomedo-Oberflaeche **[ungeprüft]**

Diese Meldungen gehoeren zu den KI-Funktionen von tomedo (KarteiChat,
KI-Prompt der Aktionskette), nicht zu direkten Aufrufen. Sie helfen bei der
Frage, ob der Server oder tomedo selbst blockt. Alle Zeilen nicht gemessen.

| Meldung | Bedeutung |
|---|---|
| „Netzwerkfehler“ mit „(Code: n)“ | n ist der HTTP-Status des Servers. Jeder Fehlerstatus ausser 504 erscheint so; der Klartext des Servers (etwa `Unbekanntes Modell`) wird nicht angezeigt |
| „Netzwerkfehler“ ohne Code | Verbindungsfehler oder Zeitlimit von tomedo, nach drei Wiederholungen |
| „Zeitüberschreitung“ | HTTP 504 vom Server |
| „Budgetlimit überschritten“ | Monatsbudget des Nutzers erreicht — Pruefung in tomedo, siehe `kosten-und-budget.md` Abschnitt 4 |
| „Verarbeitungsfehler“ | Antwort nicht lesbar, oder die Monatssumme fuer die Budgetpruefung war nicht abrufbar |
| „tomedo Intelligence ist deaktiviert“ | Schalter „tomedo Intelligence nutzen“ unter Einstellungen › Praxis › Datenschutz ist aus |
| „Registrierung fehlt“ | Installation nicht bei zollsoft registriert; Registrierung unter tomedo › Über tomedo, neben der Kundennummer |

