# Betrieb, Durchsatz und Messmethodik

Gehoert zu `tomedo-llm-endpunkt`. Belegt an tomedo v1.170.0.16, 2026-09-13.

---

## 1 · Erreichbarkeit aus Hintergrundprozessen

Belegt: Der Endpunkt ist aus einem **launchd-Job ohne Terminal** erreichbar.

| Merkmal | Wert |
|---|---|
| TTY | `not a tty` |
| launchd-Domaene | Aqua (angemeldete Nutzersitzung) |
| PATH | `/usr/bin:/bin:/usr/sbin:/sbin` |
| **HTTP** | **200** |
| Antwortzeit | 0,82 s |

Ein naechtlicher Stapellauf als LaunchAgent ist technisch moeglich.

**Nicht belegt** und vor Produktivnutzung einzeln zu pruefen:

- LaunchDaemon in der **Systemdomaene** (root, ohne GUI-Sitzung)
- Lauf **ohne angemeldeten Nutzer**
- Lauf bei **gesperrtem Bildschirm**

---

## 2 · Durchsatzgrenze — Parallelisierung bringt wenig

Sechs parallele Faeden gegen `gemini-2.5-pro` mit `reasoning_effort: high`:

| Groesse | Wert |
|---|---:|
| Durchsatz | **2,7 Aufrufe/min** |
| Latenz je Aufruf im Einzelbetrieb | 51 s |
| Latenz je Aufruf unter Last | rund 90 s |

> **Der Server serialisiert spuerbar.** Sechs Faeden lieferten nicht den
> sechsfachen Durchsatz, sondern etwa den doppelten. Fuer Stapelbetrieb heisst
> das: Mehr Parallelitaet loest das Zeitproblem nicht. Den Hebel stattdessen
> bei `reasoning_effort` ansetzen — `minimal` halbiert die Latenz je Aufruf.

**Kosten sind nach oben schlecht vorhersagbar.** Unter `reasoning_effort:
high` schwankten die Denk-Tokens je Aufruf zwischen **5 458 und 23 372**,
im Mittel 13 628 — deutlich ueber den 7 374 einer Einzelkalibrierung
desselben Prompts. Wer mit `high` arbeitet, sollte je Aufruf mit dem
Dreifachen des kalibrierten Werts rechnen.

---

## 3 · Messmethodik — wie man hier sauber misst

Aus dieser Messreihe uebernehmbar:

### Stichprobengroesse

**Mindestens 15 Laeufe je Arm.** Fuenf reichen nicht — Latenz und
Ausgabelaenge streuen so stark, dass kleine Stichproben falsche Mittelwerte
erzeugen. Der Fehlschluss ist in `modellwahl.md` Abschnitt 5 dokumentiert.

Immer **Streuungsmasse mitberichten**, nicht nur Mittelwerte:
Standardabweichung der Latenz, Variationskoeffizient der Ausgabelaenge,
Laengenspanne.

### Verblindung bei inhaltlicher Bewertung

Vor der Bewertung: Modellnamen aus den Dateinamen entfernen, Reihenfolge
mischen, neutrale Laufnummern vergeben, Zuordnungsschluessel in eine separate
Datei schreiben und **erst nach abgeschlossener Bewertung** oeffnen. Sonst
faerbt die Erwartung das Urteil.

### Maschinelle Pruefung validieren

Wer objektive Kriterien automatisiert, sollte den Pruefer **zuerst gegen eine
bereits von Hand bewertete Runde** laufen lassen. Reproduziert er dort jede
Einzelbewertung, ist er auf die groessere Stichprobe anwendbar — vorher nicht.

Automatisierbar sind nur ermessensfreie Kriterien (Formatzeichen, Rubrikzahl,
Vorkommen von Begriffen). Fachliche Richtigkeit und Literaturdeckung bleiben
manuell.

### Vollstaendigkeit als eigenes Kriterium

Ein formal einwandfreier Lauf kann einen ganzen geforderten Punkt weglassen.
Pruefraster, die nur Form pruefen, sehen das nicht. **Vollstaendigkeit
getrennt pruefen.**

### Kosten mitschreiben

Bei jedem Messlauf die realen Kosten je Aufruf protokollieren, nicht nur das
Feld `cost` — sonst ist der Verbrauch am Ende um Faktor 11 bis 543 falsch.
Baustein in `kosten-und-budget.md` Abschnitt 5.

---

## 4 · Zugangsdaten sauber halten

Bewaehrtes Muster aus dieser Messreihe:

- Server-URL und `userIdent` in **eine Datei ausserhalb** des
  Projektverzeichnisses, Dateirechte **600**
- Aufrufskripte lesen sie von dort ein
- Im Projektverzeichnis und in allen Berichten nur **Platzhalter**
- Vor Weitergabe per Volltextsuche nach Hostname und Ident gegenpruefen

So bleibt das Arbeitsverzeichnis als Ganzes weitergabefaehig.

---

## 5 · Datenschutz — Tatsachen, keine Bewertung

Die HTTP-Antwort des Endpunkts enthaelt ein `Set-Cookie` fuer die Domain
`.generativelanguage.googleapis.com`. Das belegt, dass die Anfragen an Googles
Generative Language API gehen und der tomedo-Server deren Antwortheader
durchreicht.

**Das ist eine Tatsachenfeststellung zur Vorlage beim Datenschutzbeauftragten
— keine Bewertung.** Ob ein Anonymisierungs-Gate vor dem Endpunkt noetig ist,
ist eine rechtliche Frage und in diesem Skill nicht zu entscheiden.

Bis zu einer dokumentierten Freigabe gilt: **keine echten Patientendaten an
den Endpunkt, nur synthetische Demoakten.**
