# Modellwahl: Flash oder Pro

Gehoert zu `tomedo-llm-endpunkt`. Belegt an tomedo v1.170.0.16, 2026-09-13.

Grundlage: **20 Laeufe je Modell** mit identischem Fachprompt. Alle 40 Laeufe
maschinell auf Form geprueft; davon **10 zusaetzlich verblindet auf fachliche
Richtigkeit** bewertet (5 je Arm). Alle Kennzahlen unten beziehen sich auf
n=20, sofern nicht anders angegeben.

---

## 1 · Die Messwerte

| Kennzahl (n=20) | `gemini-2.5-flash` | `gemini-2.5-pro` |
|---|---:|---:|
| Erfolgreiche Laeufe | 20/20 | 20/20 |
| Distinkte Ausgaben | 20/20 | 20/20 |
| Latenz Mittel | **9,8 s** | 16,9 s |
| Latenz Standardabweichung | 7,7 s | **1,5 s** |
| Latenz min / max | 5,3 / 35,2 s | 14,2 / 20,0 s |
| Laenge min / max | 530 / 3045 | 437 / 764 |
| Variationskoeffizient Ausgabelaenge | 59,4 % | **16,2 %** |
| Formatverstoesse, maschinell geprueft | **5 von 20** | **0 von 20** |
| Fachlich falsche Aussagen | 0 von 5 bewertet | 0 von 5 bewertet |
| Kosten real je Lauf | **0,0049 $** | 0,0214 $ |

---

## 2 · Was das heisst

**Der Unterschied ist Formattreue und Konstanz, nicht Fachqualitaet.** In den
**zehn verblindet bewerteten** Laeufen — fuenf je Arm — stand keine fachlich
falsche und keine literaturferne Aussage. Wer ein staerkeres Modell waehlt, um
Fachfehler zu vermeiden, loest damit ein Problem, das in dieser Messung nicht
auftrat.

> **Reichweite dieser Aussage:** Die uebrigen 30 Laeufe wurden nur maschinell
> auf Form geprueft. Ueber ihre fachliche Richtigkeit ist nichts ausgesagt —
> fachliche Kriterien lassen sich nicht automatisieren.

**Pro verstiess in keinem der 20 Laeufe gegen die maschinell geprueften
Formatkriterien, Flash in 5 von 20 Faellen** — Nummerierungen trotz
ausdruecklichen Verbots, einmal eine voellig andere Gliederung. Das ist der
Unterschied, der die Vergroesserung der Stichprobe von 5 auf 20 Laeufe je Arm
ueberstanden hat.

**Pro ist dabei nicht fehlerfrei:** In der Blindrunde verfehlte ein Pro-Lauf
die Vorgabe *genau zwei Merkmale je Rubrik* — er packte drei Aspekte in einen
Satz. Dieses Kriterium ist nicht maschinell pruefbar und in den 5 von 20 oben
daher nicht enthalten.

**Konstanz ist der eigentliche Befund.** Die Standardabweichung der Latenz
liegt bei Flash beim **5,3-fachen** von Pro (7,7 gegen 1,5 s), der
Variationskoeffizient der Ausgabelaenge beim **3,7-fachen** (59,4 gegen
16,2 %). Flash ist im Mittel schneller, aber unberechenbar: Der langsamste
Flash-Lauf brauchte 35,2 s, der langsamste Pro-Lauf 20,0 s.

**Ein Flash-Lauf liess einen von drei geforderten Punkten komplett weg**, ohne
dass die formalen Kriterien das erfasst haetten. Lehre fuer eigene
Pruefraster: **Vollstaendigkeit als eigenes Kriterium aufnehmen.** Formale
Korrektheit und inhaltliche Vollstaendigkeit sind verschiedene Dinge.

---

## 3 · Empfehlung

| Lage | Wahl |
|---|---|
| Festes Ausgabeformat noetig — Bausteine, strukturierte Abschnitte, maschinelle Weiterverarbeitung | **Pro** mit `reasoning_effort: minimal` |
| Nur Inhalt zaehlt, Tempo wichtig, Format wird ohnehin nachbearbeitet | **Flash** |
| Interaktiv, Anwender wartet | beide zumutbar — der langsamste Lauf der Messreihe lag bei 35 s |

> **`reasoning_effort: minimal` dreht die Rechnung um.** Damit faellt Pro auf
> 0,0086 $ je Lauf und 8,0 s — **schneller als Flash in der Grundeinstellung
> (9,8 s) und kostenmaessig in derselben Groessenordnung (0,0049 $)**, bei
> besserer Formattreue. Details in `kosten-und-budget.md` Abschnitt 2.

**Kein Modell ersetzt die fachliche Endkontrolle.** Dass in den zehn
bewerteten Laeufen kein Fachfehler auftrat, ist eine Aussage ueber eine
Wissensabruf-Aufgabe mit genau einer richtigen Antwortmenge — nicht ueber
Verdichtungsaufgaben mit Ermessensspielraum.

---

## 4 · Grenzen dieser Aussage

- Gemessen wurde **ein** Prompt: eine fachliche Abgrenzungsaufgabe ohne
  Ermessensspielraum und ohne Werkzeugbedarf.
- **Nicht gemessen** ist, ob Pros Konstanzvorsprung bei Verdichtungsaufgaben
  traegt — etwa einem Brief aus einer Mehrjahres-Akte. Das ist Verdichtung mit
  echten Ermessensstellen, keine Extraktion.
- **Fachliche Richtigkeit ist nur an 10 der 40 Laeufe geprueft** (5 je Arm,
  verblindet). Die uebrigen 30 sind ausschliesslich auf Form geprueft.
- Die Mistral-Modelle der Liste wurden **nicht** gemessen.
- `gemini-2.5-flash-lite` wurde **nicht** gemessen.

---

## 5 · Methodische Warnung aus dieser Messreihe

Die erste Auswertung beruhte auf 5 Laeufen je Modell und kam zu dem Schluss,
Pro sei **nicht langsamer** als Flash (16,6 s gegen 16,1 s). **Das war falsch.**
Zwei Ausreisser im Flash-Arm mit 35,2 s und 22,9 s hatten den Mittelwert auf
Pro-Niveau gezogen. Ueber alle 20 Laeufe je Arm liegt Flash bei **9,8 s** und
Pro bei **16,9 s**.

> **Fuenf Laeufe reichen nicht.** Latenz und Ausgabelaenge streuen an diesem
> Endpunkt so stark, dass kleine Stichproben belastbar aussehende, aber
> falsche Mittelwerte erzeugen. Fuer Modellvergleiche mindestens 15 Laeufe je
> Arm ansetzen — und Streuungsmasse mitberichten, nicht nur Mittelwerte.

**Eine zweite Lehre aus derselben Reihe:** Auch die realen Kosten je Lauf
waren bei n=5 verzerrt. Fuer Flash standen dort 0,0085 $; ueber 20 Laeufe sind
es **0,0049 $**. Kennzahlen, die von Ausreissern getrieben werden, brauchen
dieselbe Stichprobendisziplin wie Mittelwerte.
