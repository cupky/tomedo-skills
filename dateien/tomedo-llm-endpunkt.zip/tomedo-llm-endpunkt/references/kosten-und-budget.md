# Kosten, Denk-Tokens und Budget

Gehoert zu `tomedo-llm-endpunkt`. Belegt an tomedo v1.170.0.16, 2026-09-13.
**Der wichtigste Referenztext dieses Skills.**

---

## 1 · Das Feld `cost` untertreibt um Faktor 11 bis 543

Jede Antwort enthaelt ein `cost`-Objekt in USD und ein `usage`-Objekt. Darin
ist **`total_tokens` weit groesser** als die Summe aus `prompt_tokens` und
`completion_tokens`. Die Differenz sind **Denk-Tokens** (Thinking).

Nachgewiesen dadurch, dass die Luecke mit der Denklast waechst:

| Aufgabe | Luecke Flash | Luecke Pro |
|---|---:|---:|
| „Antworte nur mit: OK" | 17 | 120 |
| Ein-Satz-Definition | 595 | 1192 |
| Dosisumrechnung | 339 | 557 |
| Logikraetsel, drei Zuordnungen | 1358 | 1672 |
| Logikraetsel, fuenf Zuordnungen, `reasoning_effort: high` | — | 7374 |

Das Feld `reasoning_tokens` steht dabei durchgaengig auf **0**, meldet sie
also nicht.

**Entscheidend fuer die Abrechnung:** `cost` rechnet **nur**
`prompt + completion`, exakt nach Google-Listenpreis. Nachgerechnet und auf
die Stelle genau bestaetigt — fuer Flash mit 0,30 / 2,50 $ je Mio. Tokens
ein/aus, fuer Pro mit 1,25 / 10,00 $ je Mio. Die Denk-Tokens bleiben
unberuecksichtigt, **werden von Google aber zum Ausgabepreis berechnet.**

| Fall | gemeldet | real | Faktor |
|---|---:|---:|---:|
| Flash, Fachprompt | 0,000778 $ | 0,008490 $ | 10,9× |
| Pro, Fachprompt | 0,001446 $ | 0,021100 $ | 14,6× |
| Pro, `max_tokens` 2000, Abbruch | 0,000116 $ | rund 0,020 $ | 172× |
| Pro, Logikraetsel, `reasoning_effort: high` | 0,000255 $ | 0,073995 $ | 290× |
| Pro, 74 Aufrufe unter Last | 0,01860 $ | 10,104 $ | **543×** |

> **Regel: Fuer Budgethochrechnungen nie `cost` allein verwenden.** Immer
> `total_tokens - prompt_tokens - completion_tokens` als Denk-Tokens zum
> Ausgabepreis mitrechnen. Baustein in Abschnitt 5.

---

## 2 · `reasoning_effort` ist der Hebel

Gemessen am selben Fachprompt, je ein Lauf:

| Modell | Einstellung | Denk-Tokens | Latenz | real |
|---|---|---:|---:|---:|
| Flash | ohne Zusatz | 3024 | 17,3 s | 0,00923 $ |
| Flash | `minimal` | **817** | **5,9 s** | **0,00252 $** |
| Flash | `low` | 848 | 5,1 s | 0,00260 $ |
| Flash | `high` | 3672 | 20,3 s | 0,01050 $ |
| Pro | ohne Zusatz | 2380 | 19,9 s | 0,02537 $ |
| Pro | `minimal` | **741** | **8,0 s** | **0,00857 $** |
| Pro | `low` | 762 | 8,6 s | 0,00986 $ |
| Pro | `high` | 1693 | 14,7 s | 0,01847 $ |

**`minimal` senkt die realen Kosten auf ein Viertel (Flash) bis Drittel (Pro)
und die Latenz auf ein Drittel bis die Haelfte.**

Die Formattreue hielt in der Stichprobe. Auffaellig: Bei Flash bestanden
ausgerechnet `minimal` und `low` die Strukturpruefung, waehrend *ohne Zusatz*
und `high` durchfielen. **Mehr Nachdenken erzeugte hier keine bessere
Formattreue.**

> **Empfehlung: `gemini-2.5-pro` mit `reasoning_effort: minimal`.** Damit ist
> Pro guenstiger *und* schneller als Flash in der Grundeinstellung, bei
> besserer Formattreue.
>
> **Belastbarkeit:** je ein Lauf pro Einstellung. Die Kosten- und Latenzeffekte
> sind zu gross fuer Zufall; die Qualitaetsaussage ist es nicht und braucht
> eine eigene Messreihe vor dem produktiven Dauereinsatz.

---

## 3 · Falle: `max_tokens` begrenzt Denken **und** Ausgabe zusammen

Es ist **keine** Ausgabelaengenbegrenzung. Das Modell verbraucht das
Kontingent zuerst beim Nachdenken.

| Aufruf | HTTP | `finish_reason` | Denk | Completion | Ergebnis |
|---|---|---|---:|---:|---|
| Flash, `max_tokens` 600 | 200 | `length` | 572 | 24 | mitten im Satz abgeschnitten |
| Pro, `max_tokens` 600 | 200 | `length` | 597 | **0** | **kein Feld `content`** |
| Pro, `max_tokens` 2000 | 200 | `length` | 1997 | **0** | **kein Feld `content`** |

> **Stiller Fehlerfall.** Der Server antwortet mit **HTTP 200**, meldet winzige
> Kosten — und im `message`-Objekt fehlt das Feld `content` vollstaendig. Die
> uebliche Ersatzkette (`choices[0].message.content`, dann `message.content`,
> dann `content`) greift nicht, weil das Feld gar nicht existiert.

**Zwei Pflichten:**

1. **`max_tokens` bei Pro nicht ohne Not setzen.** Selbst 2000 Tokens reichten
   nicht fuer eine einzige Antwortzeile.
2. **Immer `finish_reason` pruefen** und das Fehlen von `content` abfangen.
   `HTTP 200` ist **kein** Beleg fuer eine brauchbare Antwort.

---

## 4 · Das 5-$-Limit bremst nicht — belegt

Ein frisch angelegter Testnutzer wurde gezielt ausgeschoepft:

| Groesse | Wert |
|---|---:|
| Aufrufe | **74** |
| davon HTTP 200 | **74** |
| **Abgelehnte Aufrufe** | **0** |
| Denk-Tokens gesamt | **1 008 495** |
| Kosten gemeldet | 0,01860 $ |
| Kosten real (berechnet) | **10,104 $** |

**Die reale 5-$-Marke fiel bei Aufruf 36. Danach liefen 38 weitere Aufrufe
fehlerfrei durch** — rund 102 % ueber der nominalen Grenze, ohne Sperre, ohne
Warnung, ohne veraenderte Antwortheader.

> **Das Limit rechnet nicht auf den realen Token-Verbrauch an und taugt damit
> nicht als Schutz vor unbeabsichtigten Kosten.** Wer denklastig arbeitet,
> kann ein Vielfaches des Nominalbetrags verbrauchen, ohne gebremst zu werden.

**Offen bleibt**, was stattdessen zaehlt: das gemeldete `cost`-Feld (stand am
Ende bei 0,37 % von 5 $), gar keine Durchsetzung an diesem Endpunkt, oder eine
verzoegerte Verrechnung. Ebenso offen, ob Tages-, Wochen- oder Gesamtlimit —
im Versuch wurde nie eine Grenze erreicht.

Mit denkintensiven Aufrufen ist das gemeldete Limit **praktisch unerreichbar**:
rund 19 900 Aufrufe, 83 Stunden, rund 2720 $ reale Kosten.

**Praktische Folge: Kostenkontrolle selbst bauen** — Baustein unten.

---

## 5 · Baustein: echte Kosten mitrechnen

```python
PREIS = {  # USD je Token, Google-Liste, am Endpunkt bestaetigt
    "gemini-2.5-flash": (0.30e-6, 2.50e-6),
    "gemini-2.5-pro":   (1.25e-6, 10.00e-6),
}


def echte_kosten(antwort):
    """Kosten inklusive der nicht gemeldeten Denk-Tokens.

    Das Feld `cost` der Antwort rechnet nur prompt+completion und untertreibt
    dadurch um Faktor 11 bis 543. Diese Funktion schliesst die Luecke.
    """
    modell = antwort["model"]
    if modell not in PREIS:
        raise KeyError(
            f"Kein Preis hinterlegt fuer {modell!r}. Nur die beiden gemessenen "
            "Gemini-Modelle sind belegt; Mistral und flash-lite wurden nicht "
            "geprueft. Preis ergaenzen statt still weiterrechnen.")
    u = antwort["usage"]
    p, c, t = u["prompt_tokens"], u["completion_tokens"], u["total_tokens"]
    denk = t - p - c                      # Thinking, nicht separat gemeldet
    preis_ein, preis_aus = PREIS[modell]
    return p * preis_ein + (c + denk) * preis_aus
```

Ein eigenes Budget mitfuehren und **vor** dem Aufruf pruefen, statt sich auf
die Serversperre zu verlassen.

---

## 6 · Hochrechnung auf Aktenlaenge

Alle obigen Zahlen beruhen auf einem Prompt mit **93 Prompt-Tokens**. Eine
Mehrjahres-Akte liegt zwei bis drei Groessenordnungen darueber. Die Zahlen
sind daher **keine** Aussage ueber den Briefbetrieb.

Faustregel fuer grosse Prompts: Dort dominieren die Prompt-Tokens, die in
`cost` **voll** enthalten sind — gemeldete und reale Kosten laufen dann wieder
zusammen. Der Untertreibungsfaktor ist also bei kurzen, denklastigen Aufrufen
am groessten und bei langen, eingabelastigen am kleinsten.

Die **maximale Promptgroesse** des Endpunkts ist noch nicht gemessen.
