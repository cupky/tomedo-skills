---
name: tomedo-marker
description: >-
  Baut, prüft und erklärt tomedo-Patientenmarker, vor allem automatische Marker in den Modi
  einfach (Python-Ausdruck), erweitert (Python mit returnvalue) und modular (Elemente A, B, C,
  verknüpft mit -, &, +). Verwende diesen Skill IMMER bei Marker, automatischer Marker,
  Markerskript, Marker-Verwaltung, Patientenmarker, Checkbox-Marker oder Marker zurücksetzen.
  Auch bei: Marker soll sich automatisch setzen (Diagnose, Ziffer, Kasse, Alter), returnvalue,
  markerliste, heuteQuartal, select(), kvdiagnosen, karteieintraege, Skripte testen, Skript
  kopieren, Vorberechnung, Marker setzt sich nicht oder bei allen, Python Fehler in Tag,
  logische Verknüpfung, enthält nicht greift falsch, Marker-Bestand prüfen. NICHT für
  Aktionsketten, die Marker setzen (→ tomedo-aktionsketten), Briefkommandos istMarkerGesetzt
  (→ tomedo-kommandos) oder Statistik über gesetzte Marker (→ tomedo-statistik-hql).
metadata:
  version: 1.1
---

# tomedo-Marker

Ein Marker ist ein farbiges Symbol mit Beschreibung am Patientenbild (Kartei, Patientendetails,
Patienteninfo). **Manuelle** Marker setzt das Team von Hand. **Automatische** Marker berechnet
tomedo mit einer Regel, sobald der Patient angezeigt wird oder sich an ihm etwas ändert (Einzelheiten
unter „Wann wird gerechnet?“). Diesen Skill brauchen Sie vor allem für die Regeln.

> **Belegbasis:** Erkundung der Referenzinstallation am 12.10.2026. Dazu gehören ein Export aller
> 142 Marker aus dem lokalen Cache, Demo-Marker in allen drei Modi, eine Abtastung aller
> 25 Elementtypen des modularen Modus, der echte Ausführungsrahmen über „Skript kopieren“ an
> Demo-Akten und Python **3.9.7**. Außerdem das Handbuch (Stand 10/2026) und 116 Forumsthreads.
> Fassung 1.1 wurde im Oktober 2026 überarbeitet:
> Berechnungszeitpunkt, Python-Rahmen, Verknüpfungslogik, Operatoren und Datumsrechnung. Was in der
> Oberfläche noch nicht nachgestellt ist, trägt die Marke **[ungeprüft]** —
> vor dem Einsatz kurz testen. Belegstatus steht in den Referenzen an jeder Aussage.

---

## Den Modus wählen

| Frage | Modus |
|---|---|
| Ein Feld des Patienten, ein Vergleich (Alter, Geschlecht, Kasse, Pflegegrad, anderer Marker) | **einfach**: ein Python-Ausdruck, z. B. `p_geschlecht == 'W' and jahre(p_geburt) >= 50` |
| Kombination aus Karteieintrag, Diagnose, Leistung, Medikament, Versicherung **ohne** Rechnen, von der Praxis selbst pflegbar | **modular**: Elemente A, B … mit Feld/Operator/Wert, Verknüpfung `A&-B` |
| Zählen, Zeitfenster rechnen, Text aus Einträgen ziehen, mehrere Quellen bündeln, Ausnahmen | **erweitert**: Python-Programm, Ergebnis in `returnvalue` |

Faustregel: **modular, solange es reicht**, weil die Praxis es ohne Python warten kann. Auf
**erweitert** umsteigen, sobald eine dieser Fallen droht:

- „enthält nicht“ als Ausschluss,
- Bedingungen, die denselben Datensatz brauchen, aber auf zwei Elemente verteilt sind,
- Teiltexte wie „AP“, die auch „APK“ treffen,
- Zählungen über mehrere Einträge.

## Ablauf

1. **Anforderung klären.** Was soll den Marker setzen, was soll ihn wieder entfernen, für welches
   Zeitfenster? Manuell oder automatisch? Soll er zurückgesetzt werden (Kalenderstichtag)? Soll er
   als Checkbox im Patienteninfo-Panel erscheinen? Fachliche Codes (ICD, GOP, Karteieintragstypen)
   gibt die Praxis vor und werden nicht geraten. Den Bestand vorher ansehen, mit Zustimmung
   des Anwenders (liest den lokalen Cache): `python3 scripts/marker_inventar.py skripte`.
2. **Regel schreiben.**
   - einfach/erweitert: Variablen ausschließlich aus `references/variablen.md`; Syntax und Rahmen
     stehen in `references/skriptsprache.md`.
   - modular: Felder und Operatoren aus `references/modular.md`.
3. **Offline prüfen** (einfach/erweitert):
   ```bash
   python3 scripts/marker_skript.py testlauf regel.py [--modus einfach] [--daten testpatient.json]
   ```
   Das Werkzeug baut den echten tomedo-Rahmen nach, meldet die typischen Fallen und führt die Regel
   gegen einen synthetischen Patienten aus. Jedes `ERROR` wird behoben, jedes `WARN` dem Anwender
   genannt. Für modulare Regeln gibt es keinen Offline-Test; dort die Verknüpfung gegen die Fallen
   in `modular.md` lesen.
4. **In tomedo testen**, nur an Demo-Akten: Testpatient über das Suchfeld oben in der Mitte der
   Marker-Verwaltung laden, dann „Skripte testen“. Fehler erscheinen als „Python Fehler in Tag …“.
   Den Wert selbst zeigt „Skript kopieren“ + lokal ausführen (`references/skriptsprache.md` §7).
5. **Übergeben** mit:
   - Einrichtungsanleitung: Gruppe, Beschreibung, Modus-Reiter, Regel, Haken, Farbe,
   - Hinweis auf den Berechnungszeitpunkt (Vorberechnung bei zeitabhängigen Markern),
   - den offenen Punkten.

## Regeln, an denen es sonst schiefgeht

- **Ein Klick auf einen Reiter ist eine Änderung.** einfach/erweitert/modular schaltet den Modus
  des gewählten Markers um und speichert sofort, ohne OK. Wer einen bestehenden Marker nur
  ansehen will, klickt keinen Reiter an. Zum Lesen dient der Cache-Export.
- **„automatisch setzen“ schaltet sich selbst ein**, sobald ein Skript übernommen, eine Variable per
  Doppelklick eingefügt oder im modularen Modus das Menü „+“ geöffnet, eine Zeile angelegt, gelöscht
  oder ein Wert getippt wird. Eine halbfertige Regel ist damit sofort für alle Patienten aktiv, deren
  Kartei geladen wird. Deshalb erst testen, dann aktivieren, und Testregeln auf
  `p_nachname.startswith('Demo-')` begrenzen.
- **Nur Variablen, deren Name im Skript steht, werden geladen.** Dynamische Namen
  (`globals()[name]`) funktionieren nur, wenn der Name zusätzlich im Text vorkommt.
  **`svTeilnahme` steht im Katalog, ist aber nicht definiert** (NameError).
- **Codes sind Strings.** GOP `'03220'`, ICD-Gruppen mit `.startswith('F45')`, ATC als
  `'N06AA09 (Amitriptylin)'`, also mit Klartext. Deshalb `in` bzw. `startswith` statt `==`.
- **Diagnosen filtern:** `typ == 'G'` (gesichert), `abgesetzt == 0`, gegebenenfalls
  `dauerdiagnose == 1`. `kvdiagnosen` umfasst die Scheine aller Jahre. Der Schlüssel
  `'manuell abgesetzt'` enthält ein Leerzeichen.
- **Zeitfenster:** `heuteQuartal` ist ein Float (Q4/2026 = 2026.75). Die letzten 4 Quartale
  inklusive des laufenden = `heuteQuartal - 0.75`. `heuteQuartal - 1` umfasst 5 Quartale.
  `select()` ohne vollständige Grenzen gibt **alles** zurück.
- **Modular, Datum:** **Positive Zahlen zählen in die Zukunft**, „zurück“ braucht einen negativen
  Wert (Quartal Anfang −2 → 01.04.2026). Zeitraum = zwei Datumszeilen im selben Element.
- **Modular, Logik:** Alle Zeilen eines Elements gelten per UND für **denselben** Datensatz.
  Getrennte Elemente prüfen unabhängig. Für „hat kein …“ das Element **positiv** formulieren und
  in der Verknüpfung mit `-A` negieren, nicht „enthält nicht“ verwenden. `-` steht nur **vor** einem
  Element: „A ohne B“ heißt `A&-B`, nicht `A-B`.
- **Modular, Verknüpfung pflegen:** Wer ein Element löscht, muss seinen Buchstaben **selbst** aus der
  Verknüpfung entfernen; tomedo tut das nicht. Ein Buchstabe ohne Element macht den Marker
  unberechenbar, er bleibt dann einfach, wie er ist **[ungeprüft]**. Keine Bezeichner wählen, die in
  einem anderen stecken (`A` und `AB`) **[ungeprüft]**.
- **Namen exakt:** Markernamen in `markerliste` bzw. im Element *Markerliste* sowie Betriebsstätten
  und Nutzerkürzel müssen buchstabengenau passen. An der Referenzinstallation trifft eine Regel nie,
  weil im Markernamen ein „h“ fehlt (Beispiel in `references/praxis-interna.md`).
- **Fehler bleiben in der Kartei stumm, und der Marker bleibt, wie er war.** Liefert die Regel einen
  Fehler, setzt tomedo den Marker weder noch entfernt es ihn. Ein kaputtes Skript fällt also nur auf,
  wenn der Marker nie kommt, bei allen steht oder nicht mehr verschwindet. Meldungen gibt es nur beim
  Knopf „Skripte testen“. Darum gehört jede neue Regel durch Schritt 3 und 4.
- **Ergebnis:** Nur genau `1` setzt den Marker; `0` **und jede andere Zahl** entfernen ihn.
- **Leere Datumsfelder** kommen im Skript als Text `'(null)'` an, nicht als `''`. `jahre(p_geburt)` scheitert
  dann; vorher mit `p_geburt != '(null)'` prüfen **[ungeprüft]**.
- **Apostroph in Patientendaten:** Ein `'` in einem Textfeld, das ein Skript benutzt (z. B. Nachname
  „O'Brien“, Patienteninfo-Freitext), lässt die Berechnung **aller** Marker dieses Patienten **[ungeprüft]**
  ausfallen, ohne Meldung **[ungeprüft]**. Details `references/fehlerbilder.md`.
- **Patientendaten:** „Skript kopieren“ legt die Daten des Testpatienten im Klartext in die
  Zwischenablage. Das nur mit Demo-Akten tun. Den lokalen Cache nur schreibgeschützt und nur in
  den Marker-Tabellen lesen, mit Zustimmung des Anwenders.

## Wann wird gerechnet?

Gerechnet wird **im Client**, an dem Arbeitsplatz, der den Patienten anzeigt:

- beim **ersten** Anzeigen des Patienten (Patientenbild in Kartei, Tagesliste, Details) und sobald dort
  Karteieinträge, Scheine, Rechnungen usw. nachgeladen sind. Ein erneutes Öffnen rechnet bereits
  berechnete Marker **nicht** neu **[ungeprüft]**;
- 2 Sekunden nach jeder **Änderung am Patienten auf diesem Arbeitsplatz** (Karteieintrag, Diagnose,
  Leistung, Schein, Verordnung, Stammdaten …);
- für **alle** Patienten neu, sobald in der Marker-Verwaltung ein Skript, ein Modus oder der Haken
  „automatisch setzen“ geändert wird (beim nächsten Anzeigen);
- bei „Skripte testen“ und bei der **Vorberechnung** (Arbeitsplatzeinstellungen der Marker-Verwaltung).

**Eine Hintergrundrechnung für alle Patienten gibt es nicht.** Zeitabhängige Marker („seit 3 Monaten
fällig“) veralten, bis sich am Patienten etwas ändert oder jemand die **Vorberechnung** startet. Diese
geht alle Patienten durch (gesperrte nicht), beginnt am Ende **von vorn** und läuft, bis man sie
abbricht; war sie beim Beenden aktiv, startet sie beim nächsten Programmstart wieder. Das wirkt auf
Statistik, Recall und Aktionsketten. Die Arbeitsplatzeinstellung „keine Aktualisierung von Markern an
diesem Arbeitsplatz“ schaltet die Berechnung an einem Rechner ganz ab.

**Automatik je Patient:** Im Marker-Popover schaltet ein Klick auf die **Kreispfeile** die Automatik für diesen
Patienten ab (Pfeile durchgestrichen), ein Klick auf die durchgestrichenen Pfeile wieder an. Der **Haken allein**
ändert nur den Marker, nicht die Automatik; die nächste Neuberechnung setzt ihn zurück **[ungeprüft]**. Ältere
Handbuch- und Forumsangaben sagen hier anderes. Das Zurücksetzen erfolgt kalendarisch (monatlich,
quartalsweise, halbjährlich, jährlich) durch den Server, Prüfung alle 24 h. Details:
`references/zusammenspiel.md`.

## Muster (geprüft im nachgebauten Rahmen)

```python
# einfach: Frauen 50–69 (Altersband)
p_geschlecht == 'W' and 50 <= jahre(p_geburt) <= 69

# einfach: gesicherte F45.4x-Diagnose vorhanden
any(d['code'].startswith('F45.4') and d['typ'] == 'G' and d['abgesetzt'] == 0 for d in kvdiagnosen + karteidiagnosen)
```

```python
# erweitert: Erinnerung — Schmerzpatient ohne Verlaufsdoku im laufenden Quartal
returnvalue = 0
if 'Schmerzpatient' in markerliste:
    returnvalue = 1
    for e in select(karteieintraege, startQuartal=heuteQuartal, endQuartal=heuteQuartal):
        if e['typ'] == 'DOK' and 'Schmerzverlauf' in e['eintrag']:
            returnvalue = 0
            break
```

```text
modular: PSY-Gruppe besucht?  A = Karteieintrag · Typ ist PSY · Eintrag enthält mind. einen von
         "Basisgruppe, Schmerzschulung" · Datum Quartal Anfang −3 Quartal(e) von
         Verknüpfung:  -A   (Marker = „Gruppe noch nicht besucht“)
```

Weitere Beispiele: einfache Ausdrücke in `references/skriptsprache.md` §2, Ziffer im
Quartalsfenster in §3, typische Fehlmuster in `references/fehlerbilder.md`.

## Referenz-Routing

| Frage | Datei |
|---|---|
| Welche Variable gibt es, welcher Typ, woher kommt der Wert? | `references/variablen.md` (alle 150) |
| Wie führt tomedo das Skript aus? Schlüssel der Listen? Testen und Debuggen? | `references/skriptsprache.md` |
| Welche Elemente, Felder, Operatoren und Werte bietet *modular*? | `references/modular.md` |
| Meldung X, Marker setzt sich nie oder bei allen | `references/fehlerbilder.md` |
| Wann wird berechnet? Aktionsketten, Kommandos, Statistik, Zurücksetzen, Systemmarker | `references/zusammenspiel.md` |
| Fenster, Knöpfe, was speichert sofort? Fernsteuerung per AX | `references/bedienung.md` |
| Tabellen und Felder im Cache, Inventar und Diff | `references/datenmodell.md` |
| Bestand der eigenen Installation | `references/praxis-interna.md` |

## Werkzeuge

| Datei | Zweck |
|---|---|
| `scripts/marker_skript.py` | `pruefen` und `testlauf`: Regel im echten tomedo-Rahmen (Python 3) prüfen und gegen synthetische Daten ausführen |
| `scripts/marker_inventar.py` | `export`, `skripte`, `diff`: Marker-Bestand schreibgeschützt aus dem lokalen Cache, Vergleich vorher/nachher |
| `scripts/ax/*` | Fernsteuerung der Marker-Verwaltung per Accessibility (Zustand lesen, Zeile wählen, Skript tippen, Demo-Testpatient laden, Skripte testen, Skript kopieren) |

## Referenzen auf andere Skills

- `tomedo-aktionsketten`: Auslöser „Marker“, Aktion „Marker setzen“ (automatische Marker sind dort
  nicht wählbar), Bedingung `$[istMarkerGesetzt NAME]$` = 1.
- `tomedo-kommandos`: `istMarkerGesetzt`, `gesetzteMarkerVonGruppe`.
- `tomedo-statistik-hql`: gesetzte Marker in Abfragen (`tags_idents`), Karteieintragstypen.
- `tomedo-navigation`: Menüpfade, AppleScript-Grundlagen.

## Versionsverlauf

- **Fassung 1.1 (10/2026):** Überarbeitet im Oktober 2026:
  Berechnungszeitpunkt und Vorberechnung, Ergebnis ≠ 1 entfernt, Fehler lassen den Marker unverändert,
  leere Datumswerte als `'(null)'`, Verknüpfungsfallen, Operatoren mit und ohne Groß-/Kleinschreibung,
  Datumsrechnung, Schlüssel aller Listen; Haken im Popover schaltet die Automatik nicht mehr ab; Prüfwerkzeug angepasst. Unsicheres ist mit **[ungeprüft]** markiert.
- **Fassung 1.0 (10/2026):** Erste Fassung aus der Erkundung vom 12.10.2026 (Referenzinstallation,
  Demo-Marker, Demo-Akten), dem Handbuch und 116 Forumsthreads.
