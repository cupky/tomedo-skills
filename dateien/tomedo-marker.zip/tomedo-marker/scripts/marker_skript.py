#!/usr/bin/env python3
"""Marker-Skripte (einfach/erweitert) prüfen und lokal testen, so wie tomedo sie ausführt.

  marker_skript.py pruefen  SKRIPT.py [--modus einfach|erweitert]
  marker_skript.py testlauf SKRIPT.py [--modus …] [--daten PATIENT.json] [--zeigen]

pruefen   statische Prüfung: Syntax im echten tomedo-Rahmen, returnvalue, Anführungszeichen,
          unsichtbare Zeichen, unbekannte bzw. fehlerhafte Variablen, typische Logikfallen.
testlauf  baut den Rahmen nach, den „Skript kopieren“ in tomedo liefert (Stand 10/2026,
          Python 3.9): Variablen nur, wenn ihr Name im Skript vorkommt; erweitert = Code eingerückt in
          def testTag(): try:, Ergebnis int(returnvalue); einfach = eval('''int(<Ausdruck>)''').
          Ohne --daten nimmt das Skript einen kleinen synthetischen Patienten. Mit --daten wird eine
          JSON-Datei {variable: wert} eingespielt, z. B. aus einem „Skript kopieren“-Export einer
          DEMO-Akte (niemals echte Patientendaten).

Nur Standardbibliothek. Rückgabe: 0 = ok, 1 = Befund/Fehler.
"""
import argparse
import json
import keyword
import os
import re
import subprocess
import sys
import tempfile

HIER = os.path.dirname(os.path.abspath(__file__))

# Vordefinierte Funktionen — Wortlaut wie im tomedo-Vorspann bzw. in ZTAGSCRIPTVARIABLE
FUNKTIONEN = {
    'select': """def select(array, startDatum = '', endDatum = '', startQuartal = 0, endQuartal = 0):
\tif(startDatum != '' and endDatum != ''):
\t\treturn [e for e in array if ((datetime.datetime.strptime(endDatum,'%d.%m.%Y') >= datetime.datetime.strptime(e['datum'],'%d.%m.%Y')) and (datetime.datetime.strptime(startDatum,'%d.%m.%Y') <= datetime.datetime.strptime(e['datum'],'%d.%m.%Y')))]
\tif(startQuartal != 0 and endQuartal != 0):
\t\treturn [e for e in array if ((endQuartal >= (e['jahr']+0.25*(e['quartal']-1))) and (startQuartal <= (e['jahr']+0.25*(e['quartal']-1))))]
\treturn array
""",
    'heuteQuartal': "heuteQuartal = datetime.datetime.now().year + 0.25*int((datetime.datetime.now().month-1)/3)\n",
    'heuteDatum': "heuteDatum = datetime.datetime.strftime(datetime.datetime.now(),'%d.%m.%Y')\n",
    'jahre': """def jahre(string_date):
\tborn = datetime.datetime.strptime(string_date,'%d.%m.%Y')
\ttoday = datetime.date.today()
\treturn today.year - born.year - ((today.month, today.day) < (born.month, born.day))
""",
    'mutterschutz': """def mutterschutz(date_string):
\taux = datetime.datetime.strptime(date_string,'%d.%m.%Y') - datetime.timedelta(days=42)
\treturn aux.strftime('%d.%m.%Y')
""",
    'schwangerschaftstage': """def schwangerschaftstage(date_string, dauer_int):
\ttoday = datetime.datetime.now()
\tgeburt = datetime.datetime.strptime(date_string,'%d.%m.%Y')
\tdauer = 280
\tif int(dauer_int) > 0:
\t\tdauer = dauer + int(dauer_int) - 28
\tdt = geburt - today
\treturn dauer - dt.days
""",
}

# Synthetischer Standardpatient (frei erfunden). Schlüssel wie im tomedo-Vorspann belegt.
STANDARD = {
    'p_nachname': 'Demo-Muster', 'p_vorname': 'Erika', 'p_geschlecht': 'W', 'p_geburt': '15.03.1961',
    'p_privatpatient': 0, 'p_email': '', 'p_tel': '', 'p_handy': '0151 000000', 'p_pflegegrad': 0,
    'p_behinderungsgrad': 50, 'p_arztDirektStatus': 0, 'p_epaDatenschutzeinstellung': 'Z',
    # Leere Datumsvariablen setzt tomedo als Text '(null)', nicht als ''
    'gk_kostentraeger': 'AOK PLUS', 'gk_ik': '107299005', 'zyklusdauer': 28, 'entbindung': '(null)',
    'markerliste': ['Schmerzpatient'],
    'karteieintraege': [
        {'typ': 'DOK', 'datum': '05.10.2026', 'quartal': 4, 'jahr': 2026, 'eintrag': 'Schmerzverlauf stabil',
         'doku': 'ABC', 'betriebsstaette': 'HBS', 'medientyp': 'Text'},
        {'typ': 'PSY', 'datum': '12.08.2026', 'quartal': 3, 'jahr': 2026, 'eintrag': 'Basisgruppe Sitzung 3',
         'doku': 'XYZ', 'betriebsstaette': 'HBS', 'medientyp': 'Text'},
        {'typ': 'ANA', 'datum': '03.02.2025', 'quartal': 1, 'jahr': 2025, 'eintrag': 'Erstanamnese',
         'doku': 'ABC', 'betriebsstaette': 'HBS', 'medientyp': 'Text'},
    ],
    'kvdiagnosen': [
        {'datum': '01.10.2026', 'quartal': 4, 'jahr': 2026, 'code': 'F45.41', 'bezeichnung': 'Chronische Schmerzstörung',
         'typ': 'G', 'dauerdiagnose': 1, 'abgesetzt': 0, 'manuell abgesetzt': 0, 'meldepflicht': 0, 'ort': '', 'freitext': ''},
        {'datum': '01.07.2026', 'quartal': 3, 'jahr': 2026, 'code': 'M54.5', 'bezeichnung': 'Kreuzschmerz',
         'typ': 'V', 'dauerdiagnose': 0, 'abgesetzt': 0, 'manuell abgesetzt': 0, 'meldepflicht': 0, 'ort': '', 'freitext': ''},
    ],
    'hzvdiagnosen': [],
    'karteidiagnosen': [
        {'datum': '04.02.2021', 'quartal': 1, 'jahr': 2021, 'code': 'I10.90', 'bezeichnung': 'Hypertonie',
         'typ': 'G', 'dauerdiagnose': 1, 'abgesetzt': 0, 'manuell abgesetzt': 0, 'meldepflicht': 0, 'ort': '', 'freitext': ''},
    ],
    'kvleistungen': [
        {'datum': '05.10.2026', 'quartal': 4, 'jahr': 2026, 'code': '30700', 'anzahl': 1},
        {'datum': '12.08.2026', 'quartal': 3, 'jahr': 2026, 'code': '30702', 'anzahl': 1},
    ],
    'hzvleistungen': [], 'privatleistungen': [], 'bgleistungen': [], 'bgfacharztleistungen': [],
    'bgunfallleistungen': [], 'bebleistungen': [], 'belleistungen': [], 'bemaleistungen': [], 'materialleistungen': [],
    'privatrechnungen': [], 'bgrechnungen': [], 'bgfacharztrechnungen': [], 'bgunfallrechnungen': [],
    'kvscheine': [{'freitext': '', 'quartal': 4, 'jahr': 2026, 'sachkosten': 0.0, 'vermittlungsart': 0, 'scheinart': 0}],
    'medikamentenplan': [
        {'datum': '22.09.2026', 'quartal': 3, 'jahr': 2026, 'pzn': '00000000', 'atc': 'N06AA09 (Amitriptylin)',
         'autIdem': 0, 'abgesetzt': 0, 'name': 'Amitriptylin 25 mg', 'freitext': ''},
    ],
    'verordnungen': [], 'orgCaves': [], 'hzvTeilnahmen': [], 'guthabenEinzahlungen': [], 'guthabenAuszahlungen': [],
}

BEKANNT_FEHLT = {'svTeilnahme': "steht im Variablenkatalog, ist im Vorspann aber nicht definiert "
                                "(NameError an der Referenzinstallation, 12.10.2026)"}


def katalog():
    p = os.path.join(HIER, '..', 'references', 'variablen.md')
    namen = set()
    if os.path.exists(p):
        namen |= set(re.findall(r'^\| `([A-Za-z_][A-Za-z0-9_]*)` \|', open(p, encoding='utf-8').read(), re.M))
    return namen | set(FUNKTIONEN) | set(STANDARD)


def rahmen(code, modus, daten):
    benutzt = set(re.findall(r'[A-Za-z_][A-Za-z0-9_]*', code))
    kopf = ['# -*- coding: utf-8 -*-', 'import datetime', '', 'def long(x):', '\treturn int(x)', '']
    for name, wert in daten.items():
        if name in benutzt and name not in FUNKTIONEN:
            kopf.append(f'{name} = {wert!r}')
    for name, quelle in FUNKTIONEN.items():
        if name in benutzt:
            kopf.append(quelle)
    if modus == 'einfach':
        rumpf = ['def testTag():', '    try:', f"        return eval('''int({code.strip()})''')",
                 '    except Exception as e:', '        return str(e)', '', 'print(testTag())']
    else:
        eingerueckt = '\n'.join('      ' + z for z in code.split('\n'))
        rumpf = ['def testTag():', '    returnvalue=0', '    try:', eingerueckt, '', '    except Exception as e:',
                 '      return str(e)', '', '    try:', '      return int(returnvalue)', '    except Exception as e:',
                 '      return str(e)', 'print(testTag())']
    return '\n'.join(kopf + rumpf) + '\n'


def pruefen(code, modus):
    befunde = []  # (stufe, text)
    if '﻿' in code or '​' in code or ' ' in code:
        befunde.append(('ERROR', 'unsichtbare Zeichen (BOM, Nullbreite oder geschütztes Leerzeichen) – Text neu tippen'))
    if re.search('[‚‘’„“”]', code):
        befunde.append(('ERROR', 'typografische Anführungszeichen – durch \' ersetzen'))
    zeilen = [z for z in code.split('\n') if z.strip()]
    if modus == 'einfach':
        if len(zeilen) > 1:
            befunde.append(('ERROR', 'Modus einfach erlaubt genau eine Zeile – Mehrzeiler gehören in „erweitert“'))
        if "'''" in code:
            befunde.append(('ERROR', "''' im Ausdruck bricht den eval-Rahmen von tomedo"))
        if re.search(r'(^|[^=!<>])=([^=]|$)', code.split('#')[0]):
            befunde.append(('WARN', 'Zuweisung „=“ im Ausdruck? Vergleich ist „==“'))
    else:
        if not re.search(r'^\s*returnvalue\s*=', code, re.M):
            befunde.append(('ERROR', 'returnvalue wird nie gesetzt – der Marker bleibt immer aus (oder ist das ein Einzeiler für Modus „einfach“? → --modus einfach)'))
        erste = next((z for z in zeilen if not z.strip().startswith('#')), '')
        if erste and not re.match(r'\s*(returnvalue\s*=\s*0|import |from |[A-Za-z_][A-Za-z0-9_]*\s*=)', erste):
            befunde.append(('HINWEIS', 'returnvalue = 0 ausdrücklich ganz oben setzen (der heutige Rahmen setzt 0 vor; ältere Versionen meldeten „referenced before assignment“)'))
        if re.search(r'^\s*else\s*:\s*\n\s*returnvalue\s*=\s*0', code, re.M):
            befunde.append(('WARN', 'returnvalue = 0 im else-Zweig einer Schleife: nur das letzte Element zählt'))
        if '\t' in code and re.search(r'^ +\S', code, re.M):
            befunde.append(('WARN', 'Tabs und Leerzeichen gemischt – einheitlich 4 Leerzeichen verwenden'))
    if re.search(r'heuteQuartal\s*-\s*1(?![\d.])', code):
        befunde.append(('HINWEIS', 'heuteQuartal-1 umfasst 5 Quartale (laufendes + 4 zurück); „letzte 4 Quartale“ = heuteQuartal-0.75'))
    if re.search(r"\['code'\]\s*==\s*'[A-Z]\d\d(\.-)?'", code):
        befunde.append(('HINWEIS', "ICD-Gruppe mit == verglichen – für Gruppen d['code'].startswith('F45') verwenden"))
    if re.search(r"\['code'\]\s*==\s*0\d", code):
        befunde.append(('ERROR', "Ziffer als Zahl verglichen – GOP/Codes sind Strings: '03220'"))
    if re.search(r"select\([^)]*(startDatum|endDatum)\s*=\s*(datetime|heute\b)", code):
        befunde.append(('WARN', "select() erwartet Datums-Strings 'TT.MM.JJJJ' (strftime('%d.%m.%Y'))"))
    if re.search(r'\bprint\s*\(', code):
        befunde.append(('HINWEIS', 'print() erscheint in tomedo nirgends – für Diagnose raise Exception(text) im Test nutzen und danach entfernen'))
    for n, warum in BEKANNT_FEHLT.items():
        if re.search(rf'\b{n}\b', code):
            befunde.append(('ERROR', f'{n}: {warum}'))
    # unbekannte Namen (grob): Bezeichner, die weder Katalog, Python-Builtin, Keyword noch lokal zugewiesen sind
    bek = katalog()
    lokal = set(re.findall(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=(?!=)', code, re.M))
    lokal |= set(re.findall(r'\bfor\s+([A-Za-z_][A-Za-z0-9_]*)', code))
    lokal |= set(re.findall(r'\bfor\s+[A-Za-z_][A-Za-z0-9_]*\s*,\s*([A-Za-z_][A-Za-z0-9_]*)', code))
    lokal |= set(re.findall(r'\bdef\s+([A-Za-z_][A-Za-z0-9_]*)', code))
    lokal |= set(re.findall(r'\bimport\s+([A-Za-z_][A-Za-z0-9_]*)', code))
    lokal |= set(re.findall(r'\bas\s+([A-Za-z_][A-Za-z0-9_]*)', code))
    for argliste in re.findall(r'def\s+\w+\(([^)]*)\)', code):
        lokal |= {a.strip().split('=')[0].strip() for a in argliste.split(',') if a.strip()}
    ohne_strings = re.sub(r"'''.*?'''|\"\"\".*?\"\"\"|'[^'\n]*'|\"[^\"\n]*\"|#[^\n]*", ' ', code, flags=re.S)
    builtins = set(dir(__builtins__)) | {'datetime', 're', 'math', 'e', 'True', 'False', 'None'}
    fremd = set()
    for m in re.finditer(r'(?<![.\w])([A-Za-z_][A-Za-z0-9_]*)\b(?!\s*=[^=])', ohne_strings):
        n = m.group(1)
        if n in bek or n in lokal or n in builtins or keyword.iskeyword(n):
            continue
        if re.search(rf'\b{n}\s*=', ohne_strings[m.end():m.end() + 3]):
            continue
        fremd.add(n)
    for n in sorted(fremd):
        befunde.append(('WARN', f'unbekannter Name „{n}“ – nicht im Variablenkatalog (Tippfehler? Groß-/Kleinschreibung?)'))
    return befunde


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('aktion', choices=['pruefen', 'testlauf'])
    ap.add_argument('skript')
    ap.add_argument('--modus', choices=['einfach', 'erweitert'])
    ap.add_argument('--daten', help='JSON {variable: wert} (synthetisch oder DEMO-Akte)')
    ap.add_argument('--zeigen', action='store_true', help='erzeugten Rahmen ausgeben')
    a = ap.parse_args()
    code = open(a.skript, encoding='utf-8').read()
    modus = a.modus or ('einfach' if len([z for z in code.split('\n') if z.strip()]) == 1
                        and 'returnvalue' not in code else 'erweitert')
    befunde = pruefen(code, modus)
    # Syntax im echten Rahmen
    try:
        compile(rahmen(code, modus, {}), '<tomedo-rahmen>', 'exec')
    except SyntaxError as e:
        befunde.insert(0, ('ERROR', f'Syntaxfehler im tomedo-Rahmen: {e.msg} (Rahmenzeile {e.lineno})'))
    print(f'Modus: {modus}')
    for stufe, text in befunde:
        print(f'{stufe:7} {text}')
    fehler = any(s == 'ERROR' for s, _ in befunde)
    if a.aktion == 'testlauf' and not any('Syntaxfehler' in t for _, t in befunde):
        daten = dict(STANDARD)
        if a.daten:
            daten.update(json.load(open(a.daten, encoding='utf-8')))
        quelle = rahmen(code, modus, daten)
        if a.zeigen:
            print('----- Rahmen -----\n' + quelle + '------------------')
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'tag.py')
            open(p, 'w', encoding='utf-8').write(quelle)
            r = subprocess.run([sys.executable, '-I', p], capture_output=True, text=True, timeout=30, cwd=d)
        ausgabe = (r.stdout.strip().split('\n') or [''])
        ergebnis = ausgabe[-1] if ausgabe else ''
        if len(ausgabe) > 1:
            print('print-Ausgaben (in tomedo unsichtbar):\n  ' + '\n  '.join(ausgabe[:-1]))
        if r.stderr.strip():
            print('Python-Fehler außerhalb von testTag:\n' + r.stderr.strip())
            fehler = True
        elif re.fullmatch(r'-?\d+', ergebnis):
            # tomedo setzt nur bei genau 1; jede andere Ganzzahl entfernt den Marker
            print(f'Ergebnis: {ergebnis} → Marker {"gesetzt" if ergebnis == "1" else "entfernt bzw. nicht gesetzt"}')
        else:
            print(f'Ergebnis: Fehler → in tomedo „Python Fehler in Tag …: {ergebnis}“, '
                  'der Marker bleibt am Patienten unverändert')
            fehler = True
    sys.exit(1 if fehler else 0)


if __name__ == '__main__':
    main()
