#!/usr/bin/env python3
"""Marker-Inventar aus dem lokalen tomedo-Cache (nur lesend, nur Marker-Tabellen).

Aufrufe:
  marker_inventar.py export [ZIELORDNER]      -> ZIELORDNER/marker_export.json + inventar.md
  marker_inventar.py diff ALT.json NEU.json   -> was hat sich geändert?
  marker_inventar.py skripte [ZIELORDNER]     -> nur Marker mit Skript/Elementen (Kurzbericht)

Liest ausschließlich ZTAG, ZTAGAUTOMATIONELEMENT, ZTAGAUTOMATIONELEMENTENTRY, ZTAGSCRIPTVARIABLE.
Die Patient-Marker-Verknüpfung wird bewusst nicht gelesen (Patientendaten).
Nur Standardbibliothek.
"""
import json
import os
import sqlite3
import sys

DB = os.path.expanduser('~/Library/tomedo/ServerEntities.sqlite')
MODUS = {0: 'einfach', 1: 'erweitert', 2: 'modular', None: '–'}
TEXT_OPS = ['enthält', 'ist', 'enthält nicht', 'beginnt mit', 'endet mit',
            'enthält mind. einen', 'enthält alle', 'enthält keinen']
DATUM_OPS = ['von', 'bis', 'am']
DATUM_BEZUG = ['Jahr Anfang', 'Quartal Anfang', 'Monat Anfang', 'Jahr Ende', 'Quartal Ende',
               'Monat Ende', 'heute', 'Datum']
DATUM_EINHEIT = ['Jahr(e)', 'Quartal(e)', 'Monat(e)', 'Tag(e)']
RESET = {1: 'monatlich', 2: 'quartalsweise', 3: 'halbjährlich', 4: 'jährlich'}


def lesen():
    con = sqlite3.connect(f'file:{DB}?mode=ro', uri=True)
    con.row_factory = sqlite3.Row

    def q(sql):
        return [dict(r) for r in con.execute(sql)]
    tags = q('SELECT * FROM ZTAG')
    for t in tags:
        if t.get('ZSYMBOL') is not None:
            t['ZSYMBOL'] = f"<{len(t['ZSYMBOL'])} Zeichen>"
    return {'tags': tags,
            'elements': q('SELECT * FROM ZTAGAUTOMATIONELEMENT'),
            'entries': q('SELECT * FROM ZTAGAUTOMATIONELEMENTENTRY'),
            'variables': q('SELECT * FROM ZTAGSCRIPTVARIABLE')}


def idx(liste, i):
    return liste[i] if isinstance(i, int) and 0 <= i < len(liste) else i


def eintrag_text(x):
    if x['ZTYP'] is not None or x['ZEINHEIT'] is not None:
        return (f"{x['ZEINTRAG']}: {idx(DATUM_BEZUG, x['ZTYP'])} {x['ZWERT']} "
                f"{idx(DATUM_EINHEIT, x['ZEINHEIT'])} – {idx(DATUM_OPS, x['ZOPERATION'])}")
    op = idx(TEXT_OPS, x['ZOPERATION']) if x['ZOPERATION'] is not None else '='
    return f"{x['ZEINTRAG']} {op} {x['ZWERT']!r}"


def bericht(d, nur_skripte=False):
    els, ents = {}, {}
    for e in d['elements']:
        els.setdefault(e['ZINV_TAGAUTOMATIONELEMENT'], []).append(e)
    for e in d['entries']:
        ents.setdefault(e['ZINV_TAGAUTOMATIONELEMENTENTRY'], []).append(e)
    gruppen = sorted([t for t in d['tags'] if t['ZGRUPPE'] == 1], key=lambda t: t['ZPOSITION'] or 0)
    out = ['# Marker-Inventar', '']
    for g in gruppen:
        ms = sorted([t for t in d['tags'] if t['ZGRUPPE'] != 1 and t['ZINV_PARENT'] == g['Z_PK']],
                    key=lambda t: t['ZPOSITION'] or 0)
        if nur_skripte:
            ms = [m for m in ms if m['ZSCRIPT'] or els.get(m['Z_PK'])]
            if not ms:
                continue
        sicht = '' if g['ZVISIBLE'] else ' (gelöscht)'
        out += [f"## {g['ZBESCHREIBUNG']}{sicht}", '']
        for m in ms:
            flags = [f"Modus {MODUS.get(m['ZSCRIPTMODE'], m['ZSCRIPTMODE'])}"]
            if m['ZSCRIPTSTATUS']:
                flags.append('automatisch')
            if not m['ZVISIBLE']:
                flags.append('gelöscht')
            if m['ZRESETMODE']:  # NULL/0 = aus
                flags.append(f"zurücksetzen {RESET.get(m['ZRESETMODE'], m['ZRESETMODE'])}")
            if m['ZADDITIONALFEATURE']:
                flags.append('Checkbox')
            out.append(f"### {m['ZBESCHREIBUNG']}  [{', '.join(flags)}]")
            for e in sorted(els.get(m['Z_PK'], []), key=lambda e: e['ZBEZEICHNUNG'] or '~'):
                if not e['ZVARIABLE'] or e['ZREMOVED']:
                    continue
                zeilen = [eintrag_text(x) for x in ents.get(e['Z_PK'], []) if x['ZEINTRAG'] and not x['ZREMOVED']]
                out.append(f"- **{e['ZBEZEICHNUNG']}** {e['ZVARIABLE']}: " + ' UND '.join(zeilen))
            if m['ZSCRIPT']:
                out += ['```', m['ZSCRIPT'].rstrip(), '```']
            out.append('')
    return '\n'.join(out)


def diff(a, b):
    zeilen = []
    for k in ['tags', 'elements', 'entries', 'variables']:
        A = {r['Z_PK']: r for r in a[k]}
        B = {r['Z_PK']: r for r in b[k]}
        for pk in sorted(set(A) | set(B)):
            if pk not in A:
                zeilen.append(f"{k} NEU {json.dumps({x: y for x, y in B[pk].items() if y not in (None, '')}, ensure_ascii=False)}")
            elif pk not in B:
                zeilen.append(f"{k} WEG {pk}")
            else:
                ch = {f: (A[pk][f], B[pk][f]) for f in B[pk] if A[pk].get(f) != B[pk][f] and f != 'Z_OPT'}
                if ch:
                    name = A[pk].get('ZBESCHREIBUNG') or A[pk].get('ZBEZEICHNUNG') or A[pk].get('ZEINTRAG')
                    zeilen.append(f"{k} GEÄNDERT {pk} {name} {json.dumps(ch, ensure_ascii=False, default=str)}")
    return '\n'.join(zeilen) or 'keine Änderungen'


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ('export', 'diff', 'skripte'):
        print(__doc__)
        sys.exit(1)
    if sys.argv[1] == 'diff':
        a, b = (json.load(open(p, encoding='utf-8')) for p in sys.argv[2:4])
        print(diff(a, b))
        return
    ziel = sys.argv[2] if len(sys.argv) > 2 else '.'
    os.makedirs(ziel, exist_ok=True)
    d = lesen()
    if sys.argv[1] == 'export':
        json.dump(d, open(os.path.join(ziel, 'marker_export.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1, default=str)
        open(os.path.join(ziel, 'inventar.md'), 'w', encoding='utf-8').write(bericht(d))
        print(f"{len(d['tags'])} Zeilen ZTAG, {len(d['elements'])} Elemente, {len(d['entries'])} Einträge, "
              f"{len(d['variables'])} Variablen -> {ziel}")
    else:
        print(bericht(d, nur_skripte=True))


if __name__ == '__main__':
    main()
