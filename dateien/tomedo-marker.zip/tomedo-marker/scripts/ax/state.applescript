on rowsOf(tbl)
	tell application "System Events"
		set out to {}
		repeat with r in (rows of tbl)
			set t to ""
			try
				set t to value of static text 1 of UI element 1 of r
			end try
			try
				if selected of r then set t to "*" & t
			end try
			set end of out to t
		end repeat
		return out
	end tell
end rowsOf
on run
	set AppleScript's text item delimiters to " | "
	tell application "System Events" to tell process "tomedo" to tell window "Marker-Verwaltung"
		set sg to splitter group 1
		set gr to my rowsOf(table 1 of scroll area 1 of sg)
		set mk to my rowsOf(table 1 of scroll area 2 of sg)
		set gb to value of text field 1 of group 2
		set mb to "-"
		try
			set mb to value of text field 1 of group 1
		end try
		set cks to {}
		repeat with c in checkboxes of group 1
			set end of cks to ((title of c) & "=" & (value of c))
		end repeat
		set pp to {}
		repeat with p in pop up buttons of group 1
			set end of pp to (value of p as text)
		end repeat
		set tbs to {}
		repeat with rb in radio buttons of tab group 1
			set end of tbs to ((title of rb) & "=" & (value of rb))
		end repeat
	end tell
	return "GRUPPEN: " & (gr as text) & linefeed & "MARKER: " & (mk as text) & linefeed & "Gruppe=" & gb & "  Marker=" & mb & linefeed & "CHECKS: " & (cks as text) & "  POPUP: " & (pp as text) & linefeed & "TABS: " & (tbs as text)
end run
