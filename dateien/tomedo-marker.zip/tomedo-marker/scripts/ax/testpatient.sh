#!/bin/zsh
# testpatient.sh <Suchtext>  — lädt den Testpatienten über das Suchfeld oben (nur Demo-Akten!)
[[ "$1" != Demo-* ]] && { echo "Nur Demo-Akten erlaubt"; exit 1; }
osascript -e "tell application \"System Events\" to tell process \"tomedo\"
set frontmost to true
tell window \"Marker-Verwaltung\"
set f to text field 1
set focused of f to true
delay 0.2
set alt to value of static text 1
keystroke \"a\" using command down
keystroke \"$1\"
key code 36
repeat 30 times
delay 0.3
if value of static text 1 is not alt and value of static text 1 contains \"Demo-\" then exit repeat
end repeat
delay 0.5
return value of static text 1
end tell
end tell"
