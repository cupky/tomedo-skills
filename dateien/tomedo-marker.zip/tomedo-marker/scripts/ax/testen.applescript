-- klickt "Skripte testen" und sammelt ~10 s lang die Texte aller Hinweis-Fenster (Laufzeit + Fehler)
tell application "System Events" to tell process "tomedo"
	set frontmost to true
	repeat 10 times
		if not (exists window "Hinweis") then exit repeat
		perform action "AXPress" of button 2 of window "Hinweis"
		delay 0.3
	end repeat
	click button "Skripte testen" of window "Marker-Verwaltung"
	set seen to {}
	repeat 30 times
		delay 0.2
		try
			set hw to (windows whose name is "Hinweis")
		on error
			set hw to {}
		end try
		repeat with w in hw
		try
			set ts to {}
			repeat with e in UI elements of w
				try
					set v to value of e
					if v is not missing value and v is not "" then set end of ts to (v as text)
				end try
			end repeat
			set AppleScript's text item delimiters to " ¶ "
			set t to ts as text
			if t is not "" and seen does not contain t then
				set end of seen to t
			end if
		end try
		end repeat
	end repeat
	repeat 10 times
		if not (exists window "Hinweis") then exit repeat
		perform action "AXPress" of button 2 of window "Hinweis"
		delay 0.3
	end repeat
	set AppleScript's text item delimiters to linefeed & "---" & linefeed
	return seen as text
end tell
