#!/bin/zsh
# typescript.sh <datei>  — klickt ins Skriptfeld (einfach/erweitert), leert es und tippt die Datei zeilenweise
# Zeilenumbruch = ⌥↩ (↩ allein übernimmt das Feld). Autovervollständigung vorher ausschalten!
D=$(dirname $0)
XY=$(osascript -e 'tell application "System Events" to tell process "tomedo" to tell window "Marker-Verwaltung"
set f to text field 1 of tab group 1
set {x, y} to position of f
return ((x + 200) as text) & " " & ((y + 80) as text)
end tell')
osascript -l JavaScript $D/mclick.js ${=XY} >/dev/null
sleep 0.3
osascript - "$1" <<'AS'
on run argv
set t to read POSIX file (item 1 of argv) as «class utf8»
set AppleScript's text item delimiters to linefeed
set ls to text items of t
tell application "System Events"
keystroke "a" using command down
key code 51
repeat with i from 1 to count of ls
keystroke (item i of ls)
if i < (count of ls) then key code 36 using option down
end repeat
key code 36
end tell
end run
AS
