// osascript -l JavaScript mclick.js x y [doppel]
ObjC.import('CoreGraphics'); ObjC.import('Foundation');
function run(argv){
 const x=parseFloat(argv[0]), y=parseFloat(argv[1]); const n=argv[2]==="2"?2:1;
 const p=$.CGPointMake(x,y);
 const mv=$.CGEventCreateMouseEvent(null,$.kCGEventMouseMoved,p,0); $.CGEventPost($.kCGHIDEventTap,mv);
 delay(0.05);
 for(let i=1;i<=n;i++){
  const d=$.CGEventCreateMouseEvent(null,$.kCGEventLeftMouseDown,p,0); $.CGEventSetIntegerValueField(d,$.kCGMouseEventClickState,i); $.CGEventPost($.kCGHIDEventTap,d);
  const u=$.CGEventCreateMouseEvent(null,$.kCGEventLeftMouseUp,p,0); $.CGEventSetIntegerValueField(u,$.kCGMouseEventClickState,i); $.CGEventPost($.kCGHIDEventTap,u);
  delay(0.05);
 }
 return "click "+x+","+y+" x"+n;
}
