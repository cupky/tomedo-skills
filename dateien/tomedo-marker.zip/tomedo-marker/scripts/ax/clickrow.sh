#!/bin/zsh
# clickrow.sh <scrollarea-index 1=Gruppen 2=Marker> <Zeilentext>  — echter Mausklick (CGEvent)
D=$(dirname $0)
XY=$(osascript -e "tell application \"System Events\" to tell process \"tomedo\"
set frontmost to true
tell window \"Marker-Verwaltung\"
set tbl to table 1 of scroll area $1 of splitter group 1
repeat with r in rows of tbl
if value of static text 1 of UI element 1 of r is \"$2\" then
set {x, y} to position of r
set {w, h} to size of r
return ((x + 40) as text) & \" \" & ((y + (h div 2)) as text)
end if
end repeat
return \"\"
end tell
end tell")
[[ -z "$XY" ]] && { echo "nicht gefunden: $2"; exit 1; }
osascript -l JavaScript $D/mclick.js ${=XY}
