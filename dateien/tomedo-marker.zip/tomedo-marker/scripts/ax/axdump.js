// Usage: osascript -l JavaScript axdump.js "<Fenstername>" [maxDepth] [maxRowsPerTable]
function run(argv){
  const se = Application("System Events");
  const p = se.processes.byName("tomedo");
  const w = p.windows.byName(argv[0]);
  const maxD = parseInt(argv[1]||"12"), maxRows = parseInt(argv[2]||"3"); const only = argv[3]||"";
  const out=[];
  function s(f){try{const v=f(); return v===null||v===undefined?"":String(v);}catch(e){return "";}}
  function walk(el, path, d){
    const role=s(()=>el.role()), title=s(()=>el.title()), desc=s(()=>el.description()), help=s(()=>el.help());
    let val=s(()=>el.value()); if(val.length>200) val=val.slice(0,200)+"…("+val.length+")";
    const pos=s(()=>el.position()), size=s(()=>el.size());
    out.push("  ".repeat(d)+path+" ["+role+"] t="+JSON.stringify(title)+" d="+JSON.stringify(desc)+(help?" h="+JSON.stringify(help):"")+" v="+JSON.stringify(val)+" @"+pos+" "+size);
    if(d>=maxD) return;
    let kids=[]; try{kids=el.uiElements();}catch(e){}
    const isTable = role==="AXTable"||role==="AXOutline";
    let rowCount=0;
    for(let i=0;i<kids.length;i++){
      const r=s(()=>kids[i].role());
      if(isTable && r==="AXRow"){ rowCount++; if(rowCount>maxRows) continue; }
      const np=path+"."+(i+1); if(only && !(only.startsWith(np)||np.startsWith(only))) continue; walk(kids[i], np, d+1);
    }
    if(isTable && rowCount>maxRows) out.push("  ".repeat(d+1)+"… "+rowCount+" rows total");
  }
  walk(w,"W",0);
  return out.join("\n");
}
