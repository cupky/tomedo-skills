#!/bin/zsh
# kopieren_lokal.sh <Ausgabedatei>  — „Skript kopieren“ für den gewählten Marker am geladenen (Demo-)Testpatienten,
# Zwischenablage sichern und lokal mit python3 ausführen
D=$(dirname $0)
N=$(osascript -e 'tell application "System Events" to tell process "tomedo" to get value of static text 1 of window "Marker-Verwaltung"')
[[ "$N" != *Demo-* ]] && { echo "Testpatient ist keine Demo-Akte: abgebrochen"; exit 1; }
printf "" | pbcopy
osascript -e 'tell application "System Events" to tell process "tomedo" to click button "Skript kopieren" of window "Marker-Verwaltung"' >/dev/null
sleep 1.5
LANG=en_US.UTF-8 pbpaste > "$1"
printf "" | pbcopy
echo "Patient: $N  ($(wc -c < "$1") Bytes)"
(cd "$(dirname "$1")" && python3 -I "$(basename "$1")")
