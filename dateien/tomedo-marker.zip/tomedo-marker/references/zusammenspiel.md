# Marker im Zusammenspiel: Berechnung, Aktionsketten, Kommandos, Statistik

Statuskennzeichnung: `[Hersteller]` = Handbuch bzw. zollsoft im Forum · `[Fremdbericht]` = Nutzer
im Forum, nicht nachgeprüft · `[Referenzinstallation]` = eigene Beobachtung. Forumsthreads mit ID
(forum.tomedo.de/d/<ID>).

---

## 1 · Wann ein automatischer Marker berechnet wird

| Anlass | Status |
|---|---|
| Laden des Patienten in Kartei, Patientendetails, Patienteninfo und jede Änderung in Kartei bzw. Details | `[Hersteller, Handbuch 10/2026]` |
| Speichern bzw. Ändern des Markers in der Marker-Verwaltung (für den geöffneten Patienten) | `[Hersteller, 11818]` |
| „Skripte testen“ in der Marker-Verwaltung am Testpatienten: Der Marker wird **sofort** gesetzt | `[Hersteller, 67779]` |
| „Vorberechnung der Marker starten“ (Arbeitsplatzeinstellungen): Ein Client lädt alle Karteien und rechnet praxisweit neu | `[Hersteller, Handbuch; 48112]` |
| **Keine** Hintergrundberechnung für alle Patienten. Zeitabhängige Marker („seit 3 Monaten fällig“) veralten, bis die Kartei wieder geladen wird | `[Hersteller, 38777; Handbuch]` |

**Widerspruch im Forum:** Ein späterer zollsoft-Beitrag (67779, 2023) sagt, das bloße Öffnen
reiche nicht immer, etwa bei Scans aus dem Dateilauscher. Auch extern ausgefüllte Patientenformulare
lösen teils nichts aus (125007, offen 2026). → Wer sich auf einen Marker verlässt (Recall, Statistik,
Aktionskette), plant die **Vorberechnung** ein und testet mit „Skripte testen“.

**Reihenfolge:** Die Skripte laufen in keiner festen Reihenfolge. `markerliste` enthält den Stand
**vor** der Automatisierung. Ein Marker, der auf einem anderen automatischen Marker aufbaut, kann
deshalb einen Durchlauf hinterherhinken. `[Hersteller: Variablenbeschreibung; Fremdbericht 108231]`
→ Abhängige Logik besser direkt in ein Skript schreiben, statt Marker zu verketten.

**Python am Client:** Die Berechnung braucht den Python-Interpreter des Clients. Fehlt er, kommt die
Meldung „Marker könnten nicht aktualisiert werden, da der Python-Interpreter nicht initialisiert
wurde“, und es ist Support nötig (90955). Der Client bringt `Python.framework` mit, an der
Referenzinstallation die Versionen 3.7 und 3.9 (`~/Library/tomedo/Python.framework.zip`).
`[Referenzinstallation]`

## 2 · Automatik pro Patient

- Das Symbol mit zwei Kreispfeilen an einem Marker in der Markeransicht bedeutet „wird automatisch
  berechnet“. **Durchgestrichen** heißt, die Automatik ist für diesen Patienten aus. `[Hersteller]`
- Wer einen automatischen Marker **im Marker-Popover manuell** setzt oder entfernt, schaltet die
  Automatik für diesen Patienten ab. Ein Klick auf die Pfeile schaltet sie wieder ein, ein Klick auf die
  Checkbox nicht. `[Hersteller, Handbuch; 24368, 31421]`
- Einen automatisch gesetzten Marker dauerhaft entfernen: zuerst die Automatik abschalten, dann den
  Marker abwählen. `[Hersteller]`
- Im Patienteninfo-Panel lässt sich die Automatik nicht schalten. Dort deaktiviert verschwindet der
  Marker und wird bei der nächsten Karteiänderung wieder automatisiert. `[Hersteller]`

## 3 · Aktionsketten

| Baustein | Verhalten |
|---|---|
| Auslöser **„Marker“** (gesetzt/entfernt) | startet eine Kette, wenn der Marker sich ändert. Passt gut zu Checkbox-Markern `[Hersteller, 19689]` |
| Aktion **„Marker setzen“** | setzt einen manuellen Marker. **Automatische Marker sind dort nicht auswählbar**, damit Skript und Kette sich nicht widersprechen `[Fremdbericht/Hersteller, 74422, 122450]` |
| Bedingung | `$[istMarkerGesetzt Markername]$` **ist** `1`. Den Namen genau wie angezeigt schreiben, mit Leerzeichen und ohne Anführungszeichen. **Kein Leerzeichen nach dem `1`** `[Hersteller, 19689, 95059]` |
| Diagnose bei Fehlschlag | Hilfe → Logs → LogLevels: `LogLevelBriefkommandos`, `LogLevelAktionsKettenBedingung` `[Hersteller, 95059]` |

Weitere Hinweise:

- `$[if istMarkerGesetzt Name zs_equals 1 TEXT]$` liefert `TEXT`, nicht `1`. `[Hersteller, 81630]`
- Der Trick „Haken *automatisch setzen* kurz aus, Kette konfigurieren, Haken wieder an“ funktioniert.
  Das Skript überschreibt das Ergebnis der Kette aber beim nächsten Lauf. Nicht empfehlen.
  `[Fremdbericht, 122450]`
- Musterbeispiel des Herstellers: HzV-Automatisierung, Handbuch „Tipps und Tricks“. Dort stehen
  automatische Marker (Kassenprüfung, Zeitfenster für Ziffern) **und** manuelle Teilnahme-Marker,
  dazu Ketten mit `istMarkerGesetzt` als Bedingung. → Skill `tomedo-aktionsketten`.
- Die Arbeitsteilung, die sich bewährt: **Der Marker rechnet** (Kasse, Alter, Ziffer im
  Zeitfenster), **die Kette handelt** (Hinweis, Ziffer anlegen, ToDo). Das ist schneller, als jede
  Kettenbedingung alle Leistungen laden zu lassen. `[Hersteller-Einschätzung, 97800]`

## 4 · Briefkommandos (→ `tomedo-kommandos`)

| Kommando | Ergebnis |
|---|---|
| `$[istMarkerGesetzt NAME]$` | `1` oder `0` |
| `$[gesetzteMarkerVonGruppe GRUPPE]$` | durch Komma getrennte Liste der gesetzten Marker einer Gruppe |

Python-Markerskripte können **keine** Briefkommandos oder Keypaths (`$[&p.…]$`) verwenden. Es gelten
nur die Variablen aus `variablen.md`. `[Hersteller, 112845]`

## 5 · Statistik und HQL (→ `tomedo-statistik-hql`)

- Die Statistik „Patient“ bietet unten einen Marker-Filter. `[112391]`
- **Nach einem nicht gesetzten Marker lässt sich nicht filtern.** Auswege: die Ergebnisliste
  nachfiltern oder eine Differenzmenge zweier Statistiken bilden. `[Hersteller, 43886]`
- „Aktionen… → Marker bei allen Patienten setzen/entfernen“ wirkt **einmalig**, nicht dynamisch.
  `[Hersteller, 26000, 79777]`
- Zeitabhängige Marker sind in der Statistik veraltet, solange keine Vorberechnung lief.
  `[Hersteller, Handbuch]`
- HQL/SQL: Die Marker stehen am Patienten als Array von Marker-Idents (`tags_idents`). Bausteine
  zur Abfrage stehen in `tomedo-statistik-hql` (`ARRAY[…] && T.tags_idents`).

## 6 · Zurücksetzen (Reset)

- Die Intervalle sind **kalendarisch absolut**: monatlich zum Monatsersten, quartalsweise zum
  Quartalsbeginn, jährlich zum 1.1. Das gilt auch, wenn der Marker erst kurz davor gesetzt wurde.
  `[Hersteller, 29995, 92998]`
- Der **Server** prüft alle 24 Stunden, gezählt ab dem letzten Serverstart. Ein Reset kann sich
  deshalb um bis zu einen Tag verzögern. `[Hersteller, 89626]`
- Zeiträume von 3 oder 5 Jahren gibt es nicht. `[Hersteller, 97016]`
- Typischer Einsatz: manuelle Quartals- oder Jahresmarker, z. B. „Fragebogen dieses Quartal
  erhalten“, die die Praxis selbst setzt und der Server zum Stichtag leert.

## 7 · Systemmarker und Pakete

- DMP-, HKS- und FEK-Marker setzt tomedo selbst (Einstellungen → Praxis → DMP/eDoku). Sie hängen an
  einem festen `zsIdent`. Umbenennen und Umfärben ist erlaubt, Löschen beendet die Automatik.
  Abschalten entfernt gesetzte Marker nicht. `[Hersteller, 70088, 79777]`
- Fertige Markerpakete gibt es über den tomedo-Marktplatz (Link `tomedo:///marktplatz#…`, z. B.
  HzV-Paket) und das Tauschcenter. `[Hersteller, Handbuch HzV]`
