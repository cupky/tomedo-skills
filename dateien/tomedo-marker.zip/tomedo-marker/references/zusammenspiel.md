# Marker im Zusammenspiel: Berechnung, Aktionsketten, Kommandos, Statistik

Statuskennzeichnung: `[Hersteller]` = Handbuch bzw. zollsoft im Forum · `[Fremdbericht]` = Nutzer
im Forum, nicht nachgeprüft · `[Referenzinstallation]` = eigene Beobachtung · **[ungeprüft]**
**[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz an einer Testakte prüfen. Forumsthreads mit ID
(forum.tomedo.de/d/<ID>).

---

## 1 · Wann ein automatischer Marker berechnet wird

Gerechnet wird **im Client**, an dem Arbeitsplatz, der den Patienten anzeigt oder ändert. **[ungeprüft]**

| Anlass | Was passiert | Status |
|---|---|---|
| Patient wird angezeigt (Patientenbild in Kartei, Tagesliste, Details, Info) | Es rechnet nur, was für diesen Patienten an diesem Arbeitsplatz **noch nicht** gerechnet wurde. tomedo merkt sich das je Datenbereich (Patientendaten, Karteieinträge, Verordnungen, Medikamentenplan, Scheine, Rechnungen, Diagnosen). **Erneutes Öffnen rechnet bereits berechnete Marker nicht neu** | Folge **[ungeprüft]** |
| Daten einer **geöffneten** Kartei werden nachgeladen (Karteieinträge, Scheine, Rechnungen …) | Marker, die diese Daten brauchen, rechnen nach (2 s Verzögerung) | **[ungeprüft]** |
| **Änderung am Patienten auf diesem Arbeitsplatz** (Karteieintrag, Diagnose, Leistung, Schein, Verordnung, Rechnung, Guthaben, Stammdaten, Caves, frei wählbare Felder, Hausarzt …) | volle Neuberechnung nach 2 s | **[ungeprüft]** |
| Änderungen, die nicht über die Oberfläche dieses Arbeitsplatzes laufen (andere Rechner, Stammdatenänderungen wie Arbeitgeber, Karteieintragstyp-Kürzel, GKV-Status) | lösen hier nichts aus | **[ungeprüft]** |
| In der Marker-Verwaltung wird Skript, Modus oder „automatisch setzen“ eines Markers geändert | alle Patienten werden beim nächsten Anzeigen neu gerechnet | **[ungeprüft]** |
| „Skripte testen“ am Testpatienten | volle Neuberechnung mit Meldungen; der Marker wird **sofort** gesetzt | `[Hersteller, 67779]` **[ungeprüft]** |
| Klick auf die durchgestrichenen Pfeile (Automatik wieder an) | volle Neuberechnung | **[ungeprüft]** |
| **Vorberechnung** (Marker-Verwaltung › Arbeitsplatzeinstellungen › „Vorberechnung der Marker starten“) | siehe unten | `[Hersteller, Handbuch; 48112]` **[ungeprüft]** |
| **Keine** Hintergrundberechnung für alle Patienten. Zeitabhängige Marker („seit 3 Monaten fällig“) veralten, bis am Patienten etwas geändert wird oder die Vorberechnung läuft | | `[Hersteller, 38777; Handbuch]` **[ungeprüft]** |

**Vorberechnung**: Der Knopf öffnet das Fenster „Markeraktualisierung“, gerechnet wird erst nach „Start“. **[ungeprüft]**
Sie lädt nacheinander alle Daten jedes Patienten vom Server (gesperrte Patienten werden übersprungen), rechnet neu und
**beginnt nach dem letzten Patienten von vorn**. Sie läuft, bis jemand „Abbrechen“ drückt; war sie beim Beenden von
tomedo aktiv, setzt sie beim nächsten Start von selbst fort. Gesetzte oder entfernte Marker lösen dabei **keine
Aktionsketten** aus (so auch der Fenstertext). Darum: auf einem Rechner starten, der nicht für die Sprechstunde
gebraucht wird, und nach einem Durchlauf abbrechen.

**Abschalten**: Die Arbeitsplatzeinstellung „keine Aktualisierung von Markern an diesem Arbeitsplatz **[ungeprüft]**
(s. Tooltipp)“ (sonstige Arbeitsplatzeinstellungen) schaltet jede Markerberechnung an diesem Rechner ab, auch „Skripte
testen“ – der Rechner verlässt sich dann auf die anderen. Die Systemeinstellung „Markerautomatisierung lädt keine
Daten nach“ lässt tomedo für Marker nur noch Karteieinträge nachladen; Marker, die Scheine, Rechnungen oder
Verordnungen brauchen, rechnen dann mit dem, was gerade geladen ist **[ungeprüft]**.

**Datenbedarf**: Welche Daten tomedo für einen Marker nachlädt, entscheidet es an den Variablennamen im Skript **[ungeprüft]**
bzw. an den Elementtypen. Der mitgelieferte Systemmarker „unbez. Rechnung“ lädt bewusst nicht alle Rechnungen nach und
stimmt laut Hersteller nur für die letzten vier Quartale.

**Widerspruch im Forum:** Ein späterer zollsoft-Beitrag (67779, 2023) sagt, das bloße Öffnen
reiche nicht immer, etwa bei Scans aus dem Dateilauscher. Auch extern ausgefüllte Patientenformulare
lösen teils nichts aus (125007, offen 2026). Die Erklärung: Nur Änderungen über die Oberfläche
des eigenen Arbeitsplatzes lösen eine Neuberechnung aus, und erneutes Öffnen rechnet nicht neu. → Wer sich auf einen Marker verlässt (Recall, Statistik, **[ungeprüft]**
Aktionskette), plant die **Vorberechnung** ein und testet mit „Skripte testen“.

**Reihenfolge:** Die Skripte laufen in keiner festen Reihenfolge. `markerliste` enthält den Stand
**vor** der Automatisierung. Ein Marker, der auf einem anderen automatischen Marker aufbaut, kann
deshalb einen Durchlauf hinterherhinken. `[Hersteller: Variablenbeschreibung; Fremdbericht 108231]`
→ Abhängige Logik besser direkt in ein Skript schreiben, statt Marker zu verketten.

**Python am Client:** Die Berechnung braucht den Python-Interpreter des Clients. Fehlt er, kommt die
Meldung „Marker können nicht aktualisiert werden, da der Pythoninterpreter nicht initialisiert
wurde.“, und es ist Support nötig (90955). Der Client bringt `Python.framework` mit
(`~/Library/tomedo/Python.framework.zip`) `[Referenzinstallation]` und verwendet daraus Python 3.9; ohne diese
Laufzeit nimmt er das System-Python. Python 3.7 unterstützen aktuelle tomedo-Versionen nicht mehr. **[ungeprüft]**

## 2 · Automatik pro Patient

- Das Symbol mit zwei Kreispfeilen an einem Marker im Marker-Popover bedeutet „wird automatisch berechnet“.
  **Durchgestrichen** heißt, die Automatik ist für diesen Patienten aus. `[Hersteller]` **[ungeprüft]**
- **Abschalten:** Klick auf die Kreispfeile. **Einschalten:** Klick auf die durchgestrichenen Pfeile; tomedo rechnet
  den Patienten dann sofort neu. **[ungeprüft]**
- **Der Haken allein schaltet die Automatik nicht ab.** In aktuellen tomedo-Versionen setzt oder entfernt ein Klick auf den Haken
  nur den Marker. Ältere Handbuch- und Forumsangaben (24368, 31421), nach denen das manuelle Setzen die Automatik
  abschaltet, sind überholt. Folge: Ein von Hand gesetzter oder entfernter automatischer Marker springt bei **[ungeprüft]**
  der nächsten Neuberechnung zurück **[ungeprüft]**.
- Einen automatischen Marker dauerhaft anders haben: erst die Pfeile anklicken (Automatik aus), dann den Haken setzen
  oder entfernen. `[Hersteller]` **[ungeprüft]**
- Patienteninfo: Die Kachel „Marker“ öffnet beim Klick dasselbe Popover samt Pfeilen. Die Kachel „Checkboxen Marker“
  (Marker mit „Checkbox zuordnen“) hat eigene Pfeil-Knöpfe; ein Klick auf das Kästchen setzt oder entfernt nur den
  Marker. Ob die Pfeil-Knöpfe dort wirken, ist **[ungeprüft]**.
- In der Kartei öffnet das Menü „Patient“ › „Marker“ das Popover. **[ungeprüft]**

## 3 · Aktionsketten

| Baustein | Verhalten |
|---|---|
| Auslöser **„Marker“** mit „Marker setzen (Aktion lokal)“ / „Marker entfernen (Aktion lokal)“ | startet eine Kette, wenn der Marker sich ändert. Passt gut zu Checkbox-Markern `[Hersteller, 19689]`. Auch automatisch gesetzte Marker lösen aus, außer bei der Vorberechnung; nur Änderungen an diesem Arbeitsplatz **[ungeprüft]** |
| Aktion **„Marker“** (setzen/entfernen) | setzt oder entfernt einen manuellen Marker. **Automatische Marker sind dort nicht auswählbar**, damit Skript und Kette sich nicht widersprechen `[Fremdbericht/Hersteller, 74422, 122450]` **[ungeprüft]** |
| Bedingung | `$[istMarkerGesetzt Markername]$` **ist** `1`. Den Namen genau wie angezeigt schreiben, mit Leerzeichen und ohne Anführungszeichen. **Kein Leerzeichen nach dem `1`** `[Hersteller, 19689, 95059]` |
| Diagnose bei Fehlschlag | Hilfe → Logs → LogLevels: `LogLevelBriefkommandos`, `LogLevelAktionsKettenBedingung` `[Hersteller, 95059]` |

Weitere Hinweise:

- `$[if istMarkerGesetzt Name zs_equals 1 TEXT]$` liefert `TEXT`, nicht `1`. `[Hersteller, 81630]`
- Der Trick „Haken *automatisch setzen* kurz aus, Kette konfigurieren, Haken wieder an“ funktioniert.
  Das Skript überschreibt das Ergebnis der Kette aber beim nächsten Lauf. Nicht empfehlen.
  `[Fremdbericht, 122450]`
- Musterbeispiel des Herstellers: HzV-Automatisierung, Handbuch „Tipps und Tricks“. Dort stehen
  automatische Marker (Kassenprüfung, Zeitfenster für Ziffern) **und** manuelle Teilnahme-Marker,
  dazu Ketten mit `istMarkerGesetzt` als Bedingung. → Skill `tomedo-aktionsketten`.
- Die Arbeitsteilung, die sich bewährt: **Der Marker rechnet** (Kasse, Alter, Ziffer im
  Zeitfenster), **die Kette handelt** (Hinweis, Ziffer anlegen, ToDo). Das ist schneller, als jede
  Kettenbedingung alle Leistungen laden zu lassen. `[Hersteller-Einschätzung, 97800]`

## 4 · Briefkommandos (→ `tomedo-kommandos`)

| Kommando | Ergebnis |
|---|---|
| `$[istMarkerGesetzt NAME]$` | `1` oder `0`. Der Name muss **genau** passen, auch in Groß-/Kleinschreibung; ein unbekannter Name ergibt `0` **[ungeprüft]** |
| `$[gesetzteMarkerVonGruppe GRUPPE]$` | Liste der gesetzten Marker einer Gruppe, alphabetisch, getrennt mit „, “; keine Treffer → leer **[ungeprüft]** |

Python-Markerskripte können **keine** Briefkommandos oder Keypaths (`$[&p.…]$`) verwenden. Es gelten
nur die Variablen aus `variablen.md`. `[Hersteller, 112845]`

## 5 · Statistik und HQL (→ `tomedo-statistik-hql`)

- Die Statistik „Patient“ bietet unten einen Marker-Filter. `[112391]`
- **Nach einem nicht gesetzten Marker lässt sich nicht filtern.** Auswege: die Ergebnisliste
  nachfiltern oder eine Differenzmenge zweier Statistiken bilden. `[Hersteller, 43886]`
- „Aktionen… → Marker bei allen Patienten setzen/entfernen“ wirkt **einmalig**, nicht dynamisch.
  `[Hersteller, 26000, 79777]` Die Liste bietet auch automatische Marker an; deren Wert überschreibt die nächste
  Neuberechnung **[ungeprüft]**.
- Zeitabhängige Marker sind in der Statistik veraltet, solange keine Vorberechnung lief.
  `[Hersteller, Handbuch]`
- HQL/SQL: Die Marker stehen am Patienten als Array von Marker-Idents (`tags_idents`). Bausteine
  zur Abfrage stehen in `tomedo-statistik-hql` (`ARRAY[…] && T.tags_idents`).

## 6 · Zurücksetzen (Reset)

- Die Intervalle sind **kalendarisch absolut**: monatlich zum Monatsersten, quartalsweise zum
  Quartalsbeginn, jährlich zum 1.1. Das gilt auch, wenn der Marker erst kurz davor gesetzt wurde.
  `[Hersteller, 29995, 92998]`
- Der **Server** prüft alle 24 Stunden, gezählt ab dem letzten Serverstart. Ein Reset kann sich
  deshalb um bis zu einen Tag verzögern. `[Hersteller, 89626]` Der Client setzt Patientenmarker nicht zurück; er
  merkt sich beim Ändern der Einstellung nur das Datum. **[ungeprüft]**
- Werte: kein Zurücksetzen, monatlich, quartalsweise, halbjährlich, jährlich; der Haken wählt quartalsweise vor. **[ungeprüft]**
- Zeiträume von 3 oder 5 Jahren gibt es nicht. `[Hersteller, 97016]`
- Typischer Einsatz: manuelle Quartals- oder Jahresmarker, z. B. „Fragebogen dieses Quartal
  erhalten“, die die Praxis selbst setzt und der Server zum Stichtag leert.

## 7 · Systemmarker und Pakete

- DMP-, HKS- und FEK-Marker setzt tomedo selbst (Einstellungen → Praxis → DMP/eDoku). Sie hängen an
  einem festen `zsIdent`. Umbenennen und Umfärben ist erlaubt, Löschen beendet die Automatik.
  Abschalten entfernt gesetzte Marker nicht. `[Hersteller, 70088, 79777]` Der Client setzt sie beim Anlegen oder
  Löschen einer Dokumentation je Indikation (Diabetes 1/2, Asthma, COPD, KHK, Brustkrebs, HKS, FEK, Herzinsuffizienz,
  Osteoporose, Rheuma, Adipositas, oKFE), wenn die Indikation in den DMP-Einstellungen angehakt ist. **[ungeprüft]**
- Weitere Marker mit Sonderbehandlung: Schwangerschaft (tomedo fragt nach der Automatik), Rhesus, „unbez. Rechnung“. **[ungeprüft]**
- Fertige Markerpakete gibt es über den tomedo-Marktplatz (Link `tomedo:///marktplatz#…`, z. B.
  HzV-Paket) und das Tauschcenter. `[Hersteller, Handbuch HzV]`
