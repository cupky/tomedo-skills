# Fehlerbilder: Meldung → Ursache → Abhilfe

Quellen: Forumsthreads (ID = forum.tomedo.de/d/<ID>), Handbuch, Referenzinstallation (RI).
Fehler beim Test erscheinen als Mitteilung oben rechts, **in der Kartei werden sie unterdrückt**
(16472). Ein defektes Skript fällt im Alltag also nur dadurch auf, dass der Marker nie kommt oder bei
allen Patienten steht.

## Meldungen

| Meldung (gekürzt) | Ursache | Abhilfe |
|---|---|---|
| `local variable 'returnvalue' referenced before assignment` | `returnvalue` wird nur im Trefferzweig gesetzt | erste Codezeile `returnvalue = 0` (16472) |
| `invalid syntax (<string>, line 2)` | Mehrzeiler im Modus **einfach** oder eine zerbrochene Zeile | auf *erweitert* umstellen (31691, 37794) |
| „Syntaxfehler in Zeile …“ / „Das Skript ist fehlgeschlagen“ | Doppelpunkt nach `if`/`for`/`else` fehlt | ergänzen (28295, 37794) |
| „Zeilenende … erwartet, aber Identifier gefunden“ | typografische Anführungszeichen oder Umbrüche nach Copy-Paste | in reinem Texteditor neu tippen (69674) |
| `strptime() argument 1 must be string, not datetime.datetime` | `select` hat ein datetime-Objekt bekommen | `.strftime('%d.%m.%Y')` übergeben (31788) |
| `name 'heuteQuartalintervall' is not defined` o. ä. | Operator vergessen | `heuteQuartal - intervall` (34603) |
| „Der Marker … enthält mindestens einen leeren Eintrag. Dieser wird bei der Automatisierung des Markers ignoriert.“ | modular: eine Bedingung ohne Wert | Wert eintragen oder Zeile mit „–“ entfernen (94951, 91363) |
| „Kein Patient zum testen der Skripte ausgewählt.“ | „Skripte testen“ ohne Testpatient | Testpatienten über das Suchfeld oben laden (RI) |
| „Marker könnten nicht aktualisiert werden, da der Python-Interpreter nicht initialisiert wurde“ | Client-Python defekt, z. B. nach Kopierinstallation | Support (90955) |

## Marker steht bei (fast) allen Patienten

1. `returnvalue = 1` ist nicht unter dem `if` eingerückt (94459).
2. Startwert `returnvalue = 1` als Absicht „fehlt noch“, aber die Schleife setzt nie auf 0.
3. Ausschluss- und Verdachtsdiagnosen zählen mit → `d['typ'] == 'G'` (16513, 64297).
4. Abgesetzte bzw. historische Diagnosen zählen mit → `d['abgesetzt'] == 0`; für
   Dauerdiagnosen `d['dauerdiagnose'] == 1` (64297, 101171).
5. Zeitraum zu groß: `heuteQuartal - 1` umfasst **5** Quartale (11026).
6. Modular: „enthält nicht“ als Ausschluss verwendet. Diese Bedingung ist wahr, sobald *irgendein*
   Datensatz den Text nicht enthält → positiv formulieren und das Element negieren, `A&-B`
   (70372, 105440).
7. Modular: Bedingungen auf zwei Elemente verteilt, die zum selben Datensatz gehören müssten.
   Jedes Element prüft für sich, ob es irgendeinen Treffer gibt → beide Bedingungen als weitere
   Zeile (Knopf „+“ in der Elementzeile) in **dasselbe** Element. Das „+“ in der Verknüpfung
   heißt dagegen ODER (97486, 98499, 102601).
8. Modular: Kurzzeichen als Teiltext („AP“ trifft „APK“) → Muster mit Kontext oder *erweitert*
   (97626).
9. Modular, automatisch, aber **ohne Element** (an der RI vorhanden, siehe `praxis-interna.md`). Das Verhalten
   ist nicht belegt, deshalb vermeiden.

## Marker kommt nie

1. `returnvalue` bleibt immer 0: Vergleich mit falschem Format, z. B. GOP als Zahl `03220` statt
   `'03220'`, `'E11.-'` statt `startswith('E11')`, `==` gegen eine Liste statt `in` (20690, 21818, 37794).
2. Unsichtbare Zeichen im Datenfeld lassen „ist“/`==` scheitern → `in`, `.strip()` (78569, 108231).
3. **Name mit Tippfehler** in einer Markerliste-Bedingung: `'Projekt_Teilname'` passt nicht auf
   `Projekt_Teilnahme` (an der RI so vorgefunden). Namen immer aus der Liste kopieren.
4. Die Automatik ist für diesen Patienten abgeschaltet (durchgestrichene Pfeile) (24368).
5. Es kam kein Auslöser (Scan über den Dateilauscher, externes Patientenformular) → „Skripte
   testen“ bzw. Vorberechnung (67779, 125007).
6. Die Laborwerte stehen nicht vollständig im LAB-Karteitext. Es gibt keine eigene Laborliste (122190).
7. Patientenabhängige Checkbox mit `'J'` oder `'X'` geprüft → modular „ja“, im Skript `== 1` (113393).
8. „Patienteninformation – HZV“ liest **nicht** die HZV-Teilnahme → Element **HZV-Teilnahme**
   (105699).

## Marker hinkt hinterher

- Er hängt per `markerliste` von einem anderen automatischen Marker ab, und die Reihenfolge ist
  undefiniert (108231).
- Er ist zeitabhängig („seit 3 Monaten“), und die Kartei wurde nicht neu geladen → Vorberechnung
  (48112).
- Zurücksetzen: Der Server prüft nur alle 24 h ab Serverstart (89626).
