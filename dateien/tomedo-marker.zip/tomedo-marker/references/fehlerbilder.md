# Fehlerbilder: Meldung → Ursache → Abhilfe

Quellen: Forumsthreads (ID = forum.tomedo.de/d/<ID>), Handbuch, Referenzinstallation (RI), Stand
Oktober 2026. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz an einer Testakte prüfen.
Fehler beim Test erscheinen als Mitteilung oben rechts, **in der Kartei werden sie unterdrückt**
(16472). Bei einem Fehler lässt tomedo den Marker **unverändert**: Er wird weder gesetzt noch entfernt. **[ungeprüft]**
Ein defektes Skript fällt im Alltag also nur dadurch auf, dass der Marker nie kommt, bei allen Patienten
steht oder nicht mehr verschwindet.

## Meldungen

| Meldung (gekürzt) | Ursache | Abhilfe |
|---|---|---|
| `local variable 'returnvalue' referenced before assignment` | `returnvalue` wird nur im Trefferzweig gesetzt | erste Codezeile `returnvalue = 0` (16472) |
| `invalid syntax (<string>, line 2)` | Mehrzeiler im Modus **einfach** oder eine zerbrochene Zeile | auf *erweitert* umstellen (31691, 37794) |
| „Syntaxfehler in Zeile …“ / „Das Skript ist fehlgeschlagen“ | Doppelpunkt nach `if`/`for`/`else` fehlt | ergänzen (28295, 37794) |
| „Zeilenende … erwartet, aber Identifier gefunden“ | typografische Anführungszeichen oder Umbrüche nach Copy-Paste | in reinem Texteditor neu tippen (69674) |
| `strptime() argument 1 must be string, not datetime.datetime` | `select` hat ein datetime-Objekt bekommen | `.strftime('%d.%m.%Y')` übergeben (31788) |
| `name 'heuteQuartalintervall' is not defined` o. ä. | Operator vergessen | `heuteQuartal - intervall` (34603) |
| „Der Marker … enthält mindestens einen leeren Eintrag. Dieser wird bei der Automatisierung des Markers ignoriert.“ | modular: eine Bedingung ohne Wert. In aktuellen tomedo-Versionen ist diese Meldung abgeschaltet, die Zeile wird still übersprungen **[ungeprüft]** | Wert eintragen oder Zeile mit „–“ entfernen (94951, 91363) |
| „Der Marker … kann nicht ausgewertet werden. Bitte überprüfen Sie die logische Verknüpfung der Elemente. …“ | modular: Verknüpfung ungültig, z. B. `A-B` statt `A&-B`, Buchstabe eines gelöschten Elements, Bezeichner `A` und `AB` **[ungeprüft]** | Verknüpfung korrigieren (`modular.md`, Bausteine) |
| „Die Automatisierung der Marker … ist deaktiviert.“ (beim Test) | am Testpatienten ist die Automatik dieser Marker abgeschaltet (durchgestrichene Pfeile) | Pfeile anklicken **[ungeprüft]** |
| „time data '(null)' does not match format '%d.%m.%Y'“ | leeres Datumsfeld, z. B. `jahre(p_geburt)` ohne Geburtsdatum; leere Daten kommen als `'(null)'` **[ungeprüft]** | vorher `x != '(null)'` prüfen |
| `KeyError: 'datum'` / `KeyError: 'jahr'` | `select()` auf `kvscheine` bzw. Rechnungen, `orgCaves`, Guthaben, Teilnahmen – diese Listen haben kein `datum` bzw. kein `jahr`/`quartal` **[ungeprüft]** | selbst filtern (`skriptsprache.md` §5) |
| „Die Markervariable … kann nicht verarbeitet werden. Bitte prüfen Sie, ob Client und Server auf der gleichen Hauptversion sind …“ | Variable des Katalogs passt nicht zum Client | Client/Server-Version angleichen; Variable bleibt undefiniert **[ungeprüft]** |
| „Kein Patient zum testen der Skripte ausgewählt.“ | „Skripte testen“ ohne Testpatient | Testpatienten über das Suchfeld oben laden (RI) |
| „Marker können nicht aktualisiert werden, da der Pythoninterpreter nicht initialisiert wurde.“ | Client-Python defekt, z. B. nach Kopierinstallation | Support (90955) |

## Marker steht bei (fast) allen Patienten

1. `returnvalue = 1` ist nicht unter dem `if` eingerückt (94459).
2. Startwert `returnvalue = 1` als Absicht „fehlt noch“, aber die Schleife setzt nie auf 0.
3. Ausschluss- und Verdachtsdiagnosen zählen mit → `d['typ'] == 'G'` (16513, 64297).
4. Abgesetzte bzw. historische Diagnosen zählen mit → `d['abgesetzt'] == 0`; für
   Dauerdiagnosen `d['dauerdiagnose'] == 1` (64297, 101171).
5. Zeitraum zu groß: `heuteQuartal - 1` umfasst **5** Quartale (11026).
6. Modular: „enthält nicht“ als Ausschluss verwendet. Diese Bedingung ist wahr, sobald *irgendein*
   Datensatz den Text nicht enthält → positiv formulieren und das Element negieren, `A&-B`
   (70372, 105440).
7. Modular: Bedingungen auf zwei Elemente verteilt, die zum selben Datensatz gehören müssten.
   Jedes Element prüft für sich, ob es irgendeinen Treffer gibt → beide Bedingungen als weitere
   Zeile (Knopf „+“ in der Elementzeile) in **dasselbe** Element. Das „+“ in der Verknüpfung
   heißt dagegen ODER (97486, 98499, 102601).
8. Modular: Kurzzeichen als Teiltext („AP“ trifft „APK“) → Muster mit Kontext oder *erweitert*
   (97626).
9. Modular, automatisch, aber **ohne Element** (an der RI vorhanden, siehe `praxis-interna.md`). Ein **[ungeprüft]**
   solcher Marker wird gar nicht berechnet; er bleibt am Patienten, wie er ist. Ebenso bei leerer Verknüpfung.
10. Modular, Zahlenvergleich „größer oder gleich“/„kleiner oder gleich“ bei Patienten **ohne** Wert (kein Pflegegrad,
   kein Ausweis) ist wahr **[ungeprüft]** → „größer“ statt „größer oder gleich“.
11. Modular, Merkzeichen „enthält g“ trifft auch aG und Gl **[ungeprüft]**.
12. Ein von Hand gesetzter automatischer Marker: Der Haken allein schaltet die Automatik nicht ab; die nächste
   Neuberechnung setzt den Marker wieder so, wie die Regel sagt. Erst die Pfeile anklicken. **[ungeprüft]**

## Marker kommt nie

1. `returnvalue` bleibt immer 0: Vergleich mit falschem Format, z. B. GOP als Zahl `03220` statt
   `'03220'`, `'E11.-'` statt `startswith('E11')`, `==` gegen eine Liste statt `in` (20690, 21818, 37794).
2. Unsichtbare Zeichen im Datenfeld lassen „ist“/`==` scheitern → `in`, `.strip()` (78569, 108231).
3. **Name mit Tippfehler** in einer Markerliste-Bedingung: `'Projekt_Teilname'` passt nicht auf
   `Projekt_Teilnahme` (an der RI so vorgefunden). Namen immer aus der Liste kopieren.
4. Die Automatik ist für diesen Patienten abgeschaltet (durchgestrichene Pfeile) (24368).
5. Es kam kein Auslöser (Scan über den Dateilauscher, externes Patientenformular) → „Skripte
   testen“ bzw. Vorberechnung (67779, 125007).
6. Die Laborwerte stehen nicht vollständig im LAB-Karteitext. Es gibt keine eigene Laborliste (122190).
7. Patientenabhängige Checkbox mit `'J'` oder `'X'` geprüft → modular „ja“, im Skript `== 1` (113393).
8. „Patienteninformation – HZV“ liest **nicht** die HZV-Teilnahme → Element **HZV-Teilnahme**
   (105699).
9. **Apostroph in Patientendaten:** Benutzt irgendein automatischer Marker ein Textfeld (z. B. `p_nachname`,
   `p_freitext`, Arbeitgeber, KV-Schein-Freitext) und enthält es beim Patienten ein `'` („O'Brien“), scheitert
   der gemeinsame Variablenblock: **kein** Marker dieses Patienten ändert sich, auch „Skripte testen“ meldet
   keinen Python-Fehler **[ungeprüft]**. Prüfen: Testpatient mit Apostroph anlegen; Abhilfe nur über den Hersteller.
10. **Rückgabewert ≠ 1:** `returnvalue = 2` o. Ä. entfernt den Marker; nur genau `1` setzt. **[ungeprüft]**
11. Modular, Karteieintrag „dokumentierender Nutzer“: das Feld ist als Datum dargestellt und trifft praktisch nie
   **[ungeprüft]** → Modus *erweitert* mit `e['doku']`.
12. Modular, Verknüpfung ungültig (siehe Meldungen) → Marker bleibt, wie er war.
13. Modular, Listen-Operator mit Mehrwortbegriff („Basis Gruppe“): wird in Einzelwörter zerlegt. **[ungeprüft]**
14. Modular, „beginnt mit“/„endet mit“ unterscheiden Groß-/Kleinschreibung, „enthält“/„ist“ nicht. **[ungeprüft]**
15. Arbeitsplatz mit „keine Aktualisierung von Markern an diesem Arbeitsplatz“ – dort rechnet nichts, auch „Skripte
   testen“ bleibt stumm. **[ungeprüft]**

## Marker hinkt hinterher

- Er hängt per `markerliste` von einem anderen automatischen Marker ab, und die Reihenfolge ist
  undefiniert (108231).
- Er ist zeitabhängig („seit 3 Monaten“): Erneutes Öffnen der Kartei rechnet nicht neu, erst eine Änderung **[ungeprüft]**
  am Patienten oder die Vorberechnung (48112) **[ungeprüft]**.
- Die Änderung kam von einem anderen Arbeitsplatz oder vom Server: Neu gerechnet wird nur bei Änderungen über die
  Oberfläche des eigenen Arbeitsplatzes. **[ungeprüft]**
- Zurücksetzen: Der Server prüft nur alle 24 h ab Serverstart (89626).
