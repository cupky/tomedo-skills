# Praxisinterna: Marker der eigenen Installation

> Leervorlage. Selbst befüllen, am schnellsten mit `python3 scripts/marker_inventar.py export <ordner>`
> (liest nur die Marker-Tabellen des lokalen Caches, siehe `datenmodell.md`).

## 1 · Bestand

(Anzahl Gruppen und Marker, Verteilung der Modi)

## 2 · Gruppen

(Gruppen in Listenreihenfolge, Zweck je Gruppe. Systemgruppen wie DMP/eDoku kennzeichnen)

## 3 · Automatische Marker mit Praxisbezug

| Marker | Modus | Logik (Kurzform) |
|---|---|---|

## 4 · Karteieintragstypen, die in Markern vorkommen

## 5 · Demo-Akten für Tests

(Namensmuster der Testpatienten. Welche Datenarten haben sie, welche fehlen?)
