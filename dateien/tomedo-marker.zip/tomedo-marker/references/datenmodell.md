# Datenmodell der Marker (lokaler Cache und Server)

Belegt an der Referenzinstallation am 12.10.2026. Jede Feldbedeutung unten wurde **durch eine Aktion in
der Oberfläche und den anschließenden Vergleich des Caches** bestätigt („Diff-Beleg“), sofern nicht als
*abgeleitet* markiert.

## Wo die Daten liegen

| Ort | Zugriff | Wofür |
|---|---|---|
| Lokaler Client-Cache `~/Library/tomedo/ServerEntities.sqlite` (Core Data, SQLite) | `sqlite3 "file:…?mode=ro"`, **nur lesend** | Inventar aller Marker samt Skripten in Sekunden, Diff vor und nach einer Änderung |
| Server-Datenbank (PostgreSQL) | Statistik/HQL, siehe `tomedo-statistik-hql` | praxisweite Auswertung, welche Patienten welchen Marker tragen |

> **Datenschutz.** Der Cache enthält auch Patientendaten. Gelesen werden **ausschließlich** die vier
> Marker-Tabellen unten. Die Verknüpfungstabelle Patient↔Marker (`Z_<n>TAGS`) wird nicht angefasst.
> Vor dem ersten Zugriff holen Sie die Zustimmung des Anwenders ein.
> Schreiben in den Cache ist tabu: Core Data synchronisiert ihn mit dem Server, ein Fremdeingriff
> zerstört die Konsistenz.

Die Tabellen- und Spaltennamen folgen dem Core-Data-Schema (`Z`-Präfix, Großbuchstaben). Die
Entitätsnummern (`Z_ENT`) sind versionsabhängig und werden über `Z_PRIMARYKEY` ermittelt:

```sql
SELECT Z_ENT, Z_NAME FROM Z_PRIMARYKEY WHERE Z_NAME LIKE 'Tag%' OR Z_NAME = 'PatientenDetails';
-- Tag, TagAutomationElement, TagAutomationElementEntry, TagScriptVariable
```

## `ZTAG` — Gruppen und Marker in einer Tabelle

| Spalte | Bedeutung | Beleg |
|---|---|---|
| `Z_PK` | Primärschlüssel im Cache (lokal) | |
| `ZIDENT` | Server-Ident. Altbestand mit kleinen Zahlen, neuere mit 18 Stellen | |
| `ZGRUPPE` | **1 = Gruppe, 0 = Marker** | Diff: neue Gruppe → 1 |
| `ZINV_PARENT` | `Z_PK` der Gruppe, zu der der Marker gehört | Diff |
| `ZPOSITION` | Reihenfolge. Bei Gruppen teils hohe Werte (111, 118, 129, 144, 156), wohl ein Ident-Zähler | Diff: neue Gruppe → 156 |
| `ZBESCHREIBUNG` | Name des Markers bzw. der Gruppe (Feld „Beschreibung“) | Diff |
| `ZVISIBLE` | **0 = gelöscht** (weiches Löschen über „–“). Sichtbar mit „gelöschte Gruppen und Marker anzeigen“ | Diff: Löschen → 1→0 |
| `ZSCRIPTMODE` | **0 = einfach, 1 = erweitert, 2 = modular**. NULL bei Altbestand ohne Automatik | Diff: Reiterklick |
| `ZSCRIPTSTATUS` | Häkchen „automatisch setzen“ (1 = an). tomedo schaltet es **von selbst ein**, sobald ein Skript übernommen oder ein modulares Element angelegt wird | Diff |
| `ZSCRIPT` | einfach: Ausdruck · erweitert: Python-Quelltext · **modular: der Verknüpfungsausdruck** (`A&-B`) | Diff |
| `ZRESETMODE` | „zurücksetzen“: **NULL/0 = aus · 1 monatlich · 2 quartalsweise · 3 halbjährlich · 4 jährlich**. Beim Anhaken setzt tomedo 2 vor | Diff: Haken → 2, „jährlich“ → 4, Haken weg → 0 (1 und 3 aus der Menüreihenfolge abgeleitet) |
| `ZDATELASTRESET` | Zeitstempel (Sekunden seit 01.01.2001), wird bei jeder Änderung der Reset-Einstellung auf „jetzt“ gesetzt | Diff |
| `ZADDITIONALFEATURE` | „Checkbox zuordnen“ (1 = an, 0 = aus) | Diff |
| `ZCOLOR` | Symbolfarbe | |
| `ZCOLORTEXT` | Textfarbe | |
| `ZCOLORBACKGROUND` | Hintergrundfarbe | |
| `ZSYMBOL` | Bilddaten des Markersymbols (Base64/Archiv, 12–700 kB) | |
| `ZIGN_SCRIPTCACHE` | an der Referenzinstallation immer leer | |

**Farbformat:** `r#g#b#a`, jeweils 0…1 als Dezimalzahl mit 6 Stellen, z. B. Rot
`1.000000#0.000000#0.000000#1.000000`. Leerer String oder NULL bedeutet „keine Farbe“.

## `ZTAGAUTOMATIONELEMENT` — modulare Elemente

| Spalte | Bedeutung |
|---|---|
| `ZINV_TAGAUTOMATIONELEMENT` | `Z_PK` des Markers |
| `ZBEZEICHNUNG` | Bezeichner `A`, `B`, … (frei änderbar, so steht er in der Verknüpfung) |
| `ZVARIABLE` | Elementtyp als Menüname: `Karteieintrag`, `Versicherung`, `Patienteninformation`, `Markerliste`, `KV-Diagnose` … |
| `ZREMOVED` | 1 = entfernt. Elemente ohne Bezeichnung/Variable sind Überreste und bleiben ohne Wirkung |

## `ZTAGAUTOMATIONELEMENTENTRY` — Bedingungszeilen eines Elements

| Spalte | Bedeutung |
|---|---|
| `ZINV_TAGAUTOMATIONELEMENTENTRY` | `Z_PK` des Elements |
| `ZEINTRAG` | Feldname, wie im Popup „Datentyp“: `Typ`, `Eintrag`, `Datum`, `Code`, `GKV-Kostenträger`, `Geschlecht` … |
| `ZOPERATION` | Index des Operators. Text: 0 enthält · 1 ist · 2 enthält nicht · 3 beginnt mit · 4 endet mit · 5 enthält mind. einen · 6 enthält alle · 7 enthält keinen. Datum: 0 von · 1 bis · 2 am |
| `ZWERT` | eingegebener Wert (Text, Zahl als Text, Datum `TT.MM.JJJJ`) |
| `ZTYP` | nur Datum: Bezugspunkt 0 Jahr Anfang · 1 Quartal Anfang · 2 Monat Anfang · 3 Jahr Ende · 4 Quartal Ende · 5 Monat Ende · 6 heute · 7 Datum (fest) |
| `ZEINHEIT` | nur Datum: 0 Jahr(e) · 1 Quartal(e) · 2 Monat(e) · 3 Tag(e) |
| `ZREMOVED` | 1 = entfernt |

## `ZTAGSCRIPTVARIABLE` — Variablenkatalog

`ZKUERZEL` (Name im Skript), `ZDATENTYP`, `ZBESCHREIBUNG`, `ZAUSDRUCK` (Objektpfad bzw.
Python-Quelltext der Funktionen), `ZVISIBLE`. Vollständig in `variablen.md`.

## Lese-Rezept (Inventar)

`scripts/marker_inventar.py` liest die vier Tabellen schreibgeschützt und schreibt
`marker_export.json` sowie einen lesbaren Bericht je Gruppe mit Skript bzw. Elementen.
`--diff ALT.json NEU.json` zeigt, was eine Aktion in der Oberfläche geändert hat. Das ist der
Sicherheitsgurt beim Arbeiten per Fernsteuerung: Er zeigt, ob wirklich nur der Ziel-Marker
verändert wurde.
