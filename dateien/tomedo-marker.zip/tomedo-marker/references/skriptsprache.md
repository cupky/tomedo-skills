# Skriptsprache der Marker: einfach und erweitert

Beide Modi sind **Python 3.9** (Client-Interpreter, an der Referenzinstallation `3.9.7` per
`sys.version` am 12.10.2026 ermittelt). Quellen: Handbuch „Automatische Patientenmarker“ (Stand
08.10.2026) `[Hersteller]`, Skripte der Referenzinstallation `[RI]`, eigene Tests an Demo-Markern
mit Demo-Akten `[Test 12.10.2026]`, Forum (Thread-ID).

---

## 1 · Wie tomedo ein Skript ausführt (belegt über „Skript kopieren“)

„Skript kopieren“ legt genau den Code in die Zwischenablage, den tomedo ausführt. Für den Modus
**erweitert** sieht er so aus `[Test 12.10.2026]`:

```python
# -*- coding: utf-8 -*-
import datetime

def long(x):                      # Py2-Altlast, damit alte Skripte mit long() laufen
	return int(x)

kvdiagnosen = [{ 'datum' : '…', 'quartal' : 4, 'jahr' : 2026, 'code' : '''F45.41''', … }, …]
def select(array, startDatum = '', endDatum = '', startQuartal = 0, endQuartal = 0): …
heuteQuartal = datetime.datetime.now().year + 0.25*int((datetime.datetime.now().month-1)/3)
p_nachname = 'Demo-…'

def testTag():
    returnvalue=0
    try:
      <IHR SKRIPT, jede Zeile um 6 Leerzeichen eingerückt>

    except Exception as e:
      return str(e)

    try:
      return int(returnvalue)
    except Exception as e:
      return str(e)
print(testTag())
```

Für den Modus **einfach**:

```python
def testTag():
    try:
        return eval('''int(<IHR AUSDRUCK>)''')
    except Exception as e:
        return str(e)
```

Für den Modus **modular** liefert „Skript kopieren“ **nichts**: Die Zwischenablage bleibt leer.

### Was daraus folgt

| Tatsache | Konsequenz |
|---|---|
| **Nur Variablen, deren Name im Skripttext vorkommt, werden definiert** (auch `select`, `heuteQuartal`, `jahre` …) | `globals()['kvleistungen']` geht nur, wenn `kvleistungen` irgendwo im Text steht. Dynamische Namen aus Strings bauen funktioniert nicht. Der Nebeneffekt ist erwünscht: Ein Skript lädt nur, was es braucht |
| Ihr Code läuft **in einer Funktion** | `returnvalue` ist lokal. Eigene `def` sind verschachtelte Funktionen. `global` ist unnötig |
| Der Rahmen setzt `returnvalue=0` vor | „referenced before assignment“ (Forum 2018) kann heute nicht mehr auftreten. Trotzdem `returnvalue = 0` selbst schreiben, das macht die Absicht lesbar |
| Ergebnis = `int(returnvalue)` | `True`/`False`/`1`/`0` sind erlaubt. Ein String oder `None` wird zum Fehler |
| Jede Exception wird **zum Rückgabetext** | tomedo meldet sie beim Test als „Python Fehler in Tag <Name>: <Text>“. In der Kartei bleibt der Fehler still, und der Marker wird nicht gesetzt |
| einfach = `eval('''int(…)''')` | Nur ein **Ausdruck**, keine Anweisung. `'''` im Ausdruck bricht den Rahmen. Das Ergebnis muss in `int` umwandelbar sein |
| Die eingefügten Zeilen werden mit 6 Leerzeichen vorangestellt | Tab-Einrückung im Skript funktioniert (Herstellerbeispiel mit Tabs läuft), aber nicht mischen. Empfehlung: 4 Leerzeichen |
| `datetime` ist importiert | ohne `import` nutzbar. Weitere Module der Standardbibliothek per `import` (belegt: `re`, `sys`) |

## 2 · Modus einfach — ein einziger Ausdruck

- Genau **eine Zeile**. Ergibt sie `True`/`1`, wird der Marker gesetzt, sonst nicht bzw. entfernt.
  `[Hersteller]`
- Mehrzeiler → `invalid syntax (<string>, line 2)` (Forum 31691).
- ↩ übernimmt den Ausdruck und speichert sofort. `[Test]`

```python
p_arztDirektStatus == 4                                    # arzt-direkt-App gekoppelt   [RI]
p_geschlecht == 'W' and 12 <= jahre(p_geburt) <= 17        # Altersband
p_privatpatient == 1 and p_email == ''                     # Privatpatient ohne E-Mail
'Schmerzpatient' in markerliste                            # Folgemarker
any(d['code'].startswith('F45.4') and d['typ'] == 'G' for d in kvdiagnosen)
```

Der letzte Ausdruck zeigt: Auch im Modus einfach lassen sich Listen über `any()`/`all()`/`sum()`
auswerten, denn es ist echtes Python-`eval`. Geprüft ist das im nachgebauten Rahmen
(`scripts/marker_skript.py`).

## 3 · Modus erweitert — ein Python-Programm

```python
# Parameter
pruefziffer = '03220'
fenster = 0.75            # laufendes + 3 Quartale zurück

# Code
returnvalue = 0
for l in select(kvleistungen, startQuartal=heuteQuartal - fenster, endQuartal=heuteQuartal):
    if l['code'] == pruefziffer:
        returnvalue = 1
        break
```

- Ergebnis in **`returnvalue`**: `1` setzt, `0` entfernt. `[Hersteller]`
- Gliederung „# Parameter“ oben, „# Code“ darunter. So arbeiten alle Herstellerbeispiele. `[RI]`
- In Schleifen nur **auf 1 setzen** und mit `break` abbrechen. Kein `else: returnvalue = 0`,
  sonst zählt nur das letzte Element (Forum 28295).
- Beim Umschalten auf *erweitert* trägt tomedo `returnvalue = 0` als Vorlage ein. Im Editor fügt ↩
  einen Zeilenumbruch ein. Gespeichert wird, wenn das Feld den Fokus verliert. `[Test]`
- `print()` ist erlaubt, die Ausgabe erscheint aber **nirgends** in tomedo. `[Test]`

## 4 · Datentypen und Zeit

| Typ | Form im Skript | Hinweis |
|---|---|---|
| string | `'Text'` | leer = `''`. Codes, PZN und GOP sind **immer Strings** (`'03220'`) |
| integer, float | `3`, `2.5` | |
| bool | `0` / `1` (int) | mit `== 1` prüfen |
| date | String `'TT.MM.JJJJ'` | rechnen über `datetime.datetime.strptime(x, '%d.%m.%Y')` |
| Jahr+Quartal | Float `jahr + 0.25 × (quartal − 1)` | Q4/2026 = `2026.75` `[Test]` |
| Listen | Liste von Dicts | Schlüssel siehe Abschnitt 6 |

- `heuteDatum` = `'12.10.2026'` (mit führenden Nullen), `heuteQuartal` = `2026.75` `[Test]`.
- **Quartalsfenster:** laufendes Quartal = `startQuartal=heuteQuartal, endQuartal=heuteQuartal`.
  Letzte 4 Quartale inklusive laufendem = `heuteQuartal - 0.75`. Die Herstellerbeispiele schreiben
  `heuteQuartal-1`: das sind **5** Quartale.
- `jahre(p_geburt)` liefert ganze Jahre (int). `[Test]`

## 5 · Hilfsfunktionen (Quelltext in `variablen.md`)

| Funktion | Zweck |
|---|---|
| `select(liste, startDatum='TT.MM.JJJJ', endDatum='TT.MM.JJJJ')` | Einträge im Datumsbereich, Grenzen inklusive. Braucht `'datum'` |
| `select(liste, startQuartal=x, endQuartal=y)` | Einträge im Quartalsbereich, inklusive. Braucht `'jahr'` und `'quartal'` |
| `jahre('TT.MM.JJJJ')` | Alter in ganzen Jahren |
| `mutterschutz(datum)` | Datum 42 Tage vor dem Termin |
| `schwangerschaftstage(geburtstermin, zyklusdauer)` | Schwangerschaftstag |

**Fallen in `select`:** Werden beide Paare übergeben, gewinnt das Datum. Fehlt eine Grenze oder ist
sie `0`, gibt `select` **die ganze Liste** zurück, ohne Fehlermeldung. Die Datumsgrenzen müssen
Strings sein, kein `datetime` (Forum 31788).

## 6 · Schlüssel der Listenelemente

Belegt aus „Skript kopieren“ an Demo-Akten `[Test]`. Wo die Demo-Akten keine Daten hatten, stammen
die Angaben aus Herstellerbeispielen, Handbuch und Forum.

| Liste | Schlüssel (Typ) | Quelle |
|---|---|---|
| `karteieintraege` | `typ` `datum` `jahr`(int) `quartal`(int) `eintrag` `doku` (Kürzel des Dokumentierenden) `betriebsstaette` `medientyp` | Test |
| `kvdiagnosen`, `hzvdiagnosen`, `karteidiagnosen` | `code` `bezeichnung` `typ` (A/G/V/Z) `datum` `jahr` `quartal` `dauerdiagnose`(0/1) `abgesetzt`(0/1) **`'manuell abgesetzt'`** (mit Leerzeichen!) `meldepflicht`(0/1) `ort` (L/R/B) `freitext` | Test |
| `medikamentenplan`, `verordnungen` | `name` `atc` (z. B. `'N06AA09 (Amitriptylin)'`, mit Klartext!) `pzn` `autIdem`(0/1) `abgesetzt`(0/1) `datum` `jahr` `quartal` `freitext` | Test |
| `kvscheine` | `jahr` `quartal` `freitext` `sachkosten`(float) `vermittlungsart`(int 0–6) `scheinart`(int) | Test |
| `kvleistungen`, `hzvleistungen`, `privatleistungen`, `bg…leistungen` | `code` `datum` `jahr` `quartal`; laut Handbuch außerdem Abrechner, Anzahl, Betriebsstätte, Kurztext, Leistungserbringer, Steigerungsfaktor | RI, Forum, Hersteller |
| `privatrechnungen`, `bg…rechnungen` | `kostenvoranschlag` `pvs` `bezahlt` (0/1) `freitext` `bemerkung` `druckDatum`; laut Handbuch außerdem Bezahlt-Datum, Erstelldatum, Betrag, Mahnstufe, Sachkosten, Teilbetrag, Versandstatus | RI, Hersteller |
| `guthabenEinzahlungen`, `guthabenAuszahlungen` | `betrag`; laut Handbuch außerdem Datum, Freitext | RI |
| `hzvTeilnahmen` | laut Handbuch Vertragsname, Beginn, Ende | Hersteller |
| `orgCaves` | laut Handbuch Datum, Text | Hersteller |
| `markerliste` | Liste von **Strings** (Markerbeschreibungen) | Test |
| ~~`svTeilnahme`~~ | steht im Katalog, ist aber **nicht definiert** → `name 'svTeilnahme' is not defined` | Test |

Unbelegte Schlüssel **nicht raten**. Lieber vorher an einer Demo-Akte nachsehen, siehe Abschnitt 7.

**Sortierung:** `karteieintraege` ist absteigend nach Datum sortiert, `[0]` ist der jüngste
Eintrag. Diagnosen kommen nicht streng sortiert. `[Test]`
**`kvdiagnosen` enthalten die Diagnosen aller Scheine**, auch alter, deshalb nach `jahr`/`quartal`
filtern. Das `datum` einer KV-Diagnose kann vom Scheinquartal abweichen. `[Test]`

## 7 · Testen und Debuggen

1. **Offline zuerst:** `python3 scripts/marker_skript.py testlauf skript.py` baut den
   tomedo-Rahmen nach, prüft die typischen Fallen und führt das Skript gegen einen synthetischen
   Patienten aus. `--daten x.json` spielt eigene (synthetische) Werte ein.
2. **In tomedo:** Testpatienten über das Suchfeld oben in der Mitte laden, **nur eine Demo-Akte**.
   „Skripte testen“ führt **alle automatischen** Marker an diesem Patienten aus und setzt sie dort
   sofort. Rückmeldung in Hinweis-Fenstern:
   - „Die Analyse aller automatisierten Tags hat N Millisekunden gedauert.“
   - bei Fehlern zusätzlich „Das Skript zur Automatisierung des Tags X ist fehlgeschlagen.“ und
     „Python Fehler in Tag X: <Exception-Text>“.
3. **Debug-Kanal:** Da `print` unsichtbar ist, bringt `raise Exception('…' + str(wert))` einen Wert
   als Fehlermeldung ans Licht. Nur an Demo-Akten verwenden und danach wieder entfernen.
   Beobachtung: Beim wiederholten Test desselben Fehlers blieb die Meldung teils aus. Dann zeigt
   Weg 4 das Ergebnis zuverlässig.
4. **Skript kopieren** am Demo-Testpatienten → Zwischenablage als `.py` speichern → lokal
   `python3 -I datei.py`. Damit sieht man das echte Ergebnis und alle Datenstrukturen. Die
   Zwischenablage enthält die Patientendaten im Klartext, deshalb **ausschließlich mit Demo-Akten**
   arbeiten und die Zwischenablage danach leeren.
