# Bedienung der Marker-Verwaltung — von Hand und per Fernsteuerung (AX)

Pfad: **Admin → Marker** (bzw. Admin → Praxisorganisation → Marker) oder das Zahnrad im
Marker-Popover der Kartei. Belegt an der Referenzinstallation am 12.10.2026.

## Aufbau des Fensters

| Bereich | Inhalt |
|---|---|
| links oben | Gruppenliste mit Suche · `+` neue Gruppe · `–` löschen · `⋀ ⋁` Reihenfolge |
| links unten | Markerliste der gewählten Gruppe · `+ – ⋀ ⋁` · Knopf **Arbeitsplatzeinstellungen** |
| Mitte oben | Gruppe: Beschreibung, Gruppensymbol (`+`/`–`) |
| Mitte | Marker: Beschreibung, Textfarbe, Hintergrundfarbe, Symbolfarbe (je mit `–` zum Entfernen), Markersymbol (`+`/`–`), **automatisch setzen**, **zurücksetzen** (Haken + Menü monatlich · quartalsweise · halbjährlich · jährlich), **Checkbox zuordnen** |
| unter der Mitte | **gelöschte Gruppen und Marker anzeigen**: zeigt nur Gelöschtes, mit Knopf **Wiederherstellen** |
| rechts oben | Testpatient-Suchfeld + Name + Foto · Variablentabelle (Variable, Datentyp, Beschreibung) mit Suchfeld; Doppelklick fügt die Variable ein |
| rechts | Reiter **einfach · erweitert · modular** mit Skriptfeld bzw. Elementtabelle und Feld „logische Verknüpfung“ |
| unten | **Skript kopieren** · **Skripte testen** · Autovervollständigung · `?` (Handbuch) · OK |

**Markersymbole:** `+` öffnet einen Dateidialog im Ordner `tomedo.app/Contents/Resources/markersymbole`
(142 PNG). Eigene Bilder gehen auch, ebenso Drag & Drop auf die Bildfläche.

**Arbeitsplatzeinstellungen** (Popover, gilt nur für diesen Arbeitsplatz): Deckkraft im
kompakten bzw. expandierten Modus, Symbolgröße, minimaler und maximaler Abstand der Symbole,
Abstand zwischen Gruppen, Knopf **„Vorberechnung der Marker starten“**. Die Vorberechnung lädt
alle Karteien neu und rechnet die Marker praxisweit. Sie dauert lange, also nicht nebenbei
auslösen.

## Was sofort gespeichert wird (keine Rückfrage, kein OK nötig)

| Aktion | Wirkung in der Datenbank |
|---|---|
| Beschreibung tippen + ↩ | sofort |
| **Reiter einfach/erweitert/modular anklicken** | **ändert den Modus des Markers** (`ZSCRIPTMODE`). Auch bloßes „Nachsehen“ ist eine Änderung |
| Skript übernehmen bzw. erstes Element anlegen | schaltet **„automatisch setzen“ selbst ein** |
| Haken „automatisch setzen“, „zurücksetzen“, „Checkbox zuordnen“ | sofort |
| `–` in der Markerliste | löscht **ohne Rückfrage**, aber nur weich (wiederherstellbar) |
| Testpatient laden + „Skripte testen“ | setzt alle automatischen Marker **an diesem Patienten** |

→ **Bestehende Marker nur ansehen** heißt: in der Liste anwählen und nichts weiter anklicken. Für
Lesezugriffe ist der Cache-Export (`scripts/marker_inventar.py`) der sichere Weg.

## Sichere Arbeitsweise beim Ausprobieren

1. Eine eigene Gruppe anlegen, z. B. `DEMO-…`. Alles Neue kommt dort hinein.
2. Vor und nach jedem Schritt `marker_inventar.py export` und anschließend `diff`. So ist belegt,
   dass nur Demo-Einträge verändert wurden.
3. Skripte im Rumpf auf Demo-Akten begrenzen: `if p_nachname.startswith('Demo-'):` (erweitert)
   bzw. `p_nachname.startswith('Demo-') and …` (einfach). Modular kennt kein Namensfeld, deshalb
   dort „automatisch setzen“ ausschalten, bis die Logik steht.
4. Am Ende bei allen Demo-Markern „automatisch setzen“ aus. Das gilt auch für **gelöschte**
   Demo-Marker (Ansicht „gelöschte … anzeigen“), denn das Löschen ändert den Automatik-Haken nicht.

## Fernsteuerung per Accessibility (macOS, `osascript`)

Die Werkzeuge liegen in `scripts/ax/`. Voraussetzung ist eine Bedienungshilfen-Freigabe für das
Terminal. Eine Bildschirmaufnahme ist nicht nötig, alles wird über AX gelesen.

| Aufgabe | Werkzeug / Rezept |
|---|---|
| Zustand lesen (Gruppen, Marker, Haken, Reiter) | `osascript ax/state.applescript` |
| Teilbaum ausgeben | `osascript -l JavaScript ax/axdump.js "Marker-Verwaltung" 10 5 "W.4"` |
| Zeile in Gruppen- oder Markerliste wählen | `ax/clickrow.sh 1 <Gruppe>` bzw. `ax/clickrow.sh 2 <Marker>`: **echter Mausklick** (CGEvent). `select row` bzw. `click at` markieren nur, der Controller lädt dann nicht nach |
| Skript eintippen | Autovervollständigung **aus**, dann `ax/typescript.sh datei.py`. Zeilenumbruch über ⌥↩, danach Fokus wegnehmen, dann wird gespeichert |
| Testpatient laden | `ax/testpatient.sh Demo-<Name>` (verweigert alles ohne `Demo-`). Die Suche lädt den **ersten Treffer**, der nicht immer der gesuchte ist. Den angezeigten Namen prüfen |
| Skripte testen + Hinweise einsammeln | `osascript ax/testen.applescript` |
| Skript kopieren + lokal ausführen | `ax/kopieren_lokal.sh ziel.py` (nur bei Demo-Testpatient) |

Fallen der Oberfläche:

- `set value` auf das Skriptfeld landet nur in der Anzeige und wird **nicht gespeichert**.
- ⌘V in das Skriptfeld leert es und nimmt ihm den Fokus. Deshalb tippen statt einfügen.
- Die Autovervollständigung ergänzt gierig: Aus `p` wird `p_optionalText3`.
- Einblendmenüs öffnen erst beim zweiten Klick: im Wiederholungsfall prüfen, ob `menu 1` existiert.
- In der Modular-Tabelle lassen sich Zeilen außerhalb des sichtbaren Bereichs nicht bedienen.
- Nach einem Feldwechsel in einer Modular-Zeile zeigt die Tabelle die alten Eingabeelemente, bis
  der Marker neu gewählt wird (anderen Marker anklicken, dann zurück).
- Hinweis-Fenster schließen sich nach wenigen Sekunden. Zum Lesen kurz hintereinander abfragen;
  schließen über `perform action "AXPress" of button 2 of window "Hinweis"`.
