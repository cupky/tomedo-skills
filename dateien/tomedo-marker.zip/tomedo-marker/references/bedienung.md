# Bedienung der Marker-Verwaltung — von Hand und per Fernsteuerung (AX)

Pfad: **Admin → Marker** (bzw. Admin → Praxisorganisation → Marker) oder das Zahnrad im
Marker-Popover der Kartei. Das Popover selbst öffnet in der Kartei das Menü **Patient → Marker** oder ein Klick auf die
Markerleiste. Belegt an der Referenzinstallation am 12.10.2026, seit Fassung 1.1 überarbeitet (Oktober 2026).
**[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz an einer Testakte prüfen.

## Aufbau des Fensters

| Bereich | Inhalt |
|---|---|
| links oben | Gruppenliste mit Suche · `+` neue Gruppe · `–` löschen · `⋀ ⋁` Reihenfolge |
| links unten | Markerliste der gewählten Gruppe · `+ – ⋀ ⋁` · Knopf **Arbeitsplatzeinstellungen** |
| Mitte oben | Gruppe: Beschreibung, Gruppensymbol (`+`/`–`) |
| Mitte | Marker: Beschreibung, Textfarbe, Hintergrundfarbe, Symbolfarbe (je mit `–` zum Entfernen), Markersymbol (`+`/`–`), **automatisch setzen**, **zurücksetzen** (Haken + Menü monatlich · quartalsweise · halbjährlich · jährlich), **Checkbox zuordnen** |
| unter der Mitte | **gelöschte Gruppen und Marker anzeigen**: zeigt nur Gelöschtes, mit Knopf **Wiederherstellen**. Eine Gruppe kommt mit allen Markern zurück; ein Marker holt seine gelöschte Gruppe mit zurück |
| rechts oben | Testpatient-Suchfeld + Name + Foto · Variablentabelle (Variable, Datentyp, Beschreibung) mit Suchfeld; Doppelklick hängt die Variable **ans Ende** des Skripts (nicht an der Schreibmarke) und schaltet „automatisch setzen“ ein |
| rechts | Reiter **einfach · erweitert · modular** mit Skriptfeld bzw. Elementtabelle und Feld „logische Verknüpfung“ |
| unten | **Skript kopieren** · **Skripte testen** · Autovervollständigung · `?` (Handbuch) · OK |

**Markersymbole:** `+` öffnet einen Dateidialog im Ordner `tomedo.app/Contents/Resources/markersymbole`
(142 Dateien: 141 PNG-Symbole und eine PDF-Datei). Eigene Bilder beliebigen Bildformats gehen auch, ebenso Drag & Drop
auf die Bildfläche. Das Bild wird im Marker gespeichert.

**Gruppen:** Eine Gruppe erlaubt mehrere gesetzte Marker zugleich (keine „nur einer aus der Gruppe“-Regel). Ein Marker
ohne eigenes Symbol zeigt das **Gruppensymbol samt Gruppenfarbe**; seine eigene Symbolfarbe wirkt nur zusammen mit
einem eigenen Symbol **[ungeprüft]**.

**Arbeitsplatzeinstellungen** (Popover, gilt nur für diesen Arbeitsplatz): Deckkraft im
kompakten bzw. expandierten Modus, Symbolgröße, minimaler und maximaler Abstand der Symbole,
Abstand zwischen Gruppen, Knopf **„Vorberechnung der Marker starten“**. Der Knopf öffnet das Fenster
„Markeraktualisierung“; erst „Start“ beginnt. Die Vorberechnung lädt nacheinander die Daten aller Patienten und
rechnet die Marker praxisweit, **beginnt danach von vorn** und läuft, bis „Abbrechen“ gedrückt wird – auch über einen
Neustart von tomedo hinweg. Aktionsketten löst sie nicht aus. Sie dauert lange, also nicht nebenbei auslösen.
Details `zusammenspiel.md` §1.

## Was sofort gespeichert wird (keine Rückfrage, kein OK nötig)

| Aktion | Wirkung in der Datenbank |
|---|---|
| Beschreibung tippen + ↩ | sofort |
| **Reiter einfach/erweitert/modular anklicken** | **ändert den Modus des Markers** (`ZSCRIPTMODE`). Auch bloßes „Nachsehen“ ist eine Änderung. Beim Wechsel zu oder von *modular* tauscht tomedo Skript und Verknüpfung mit einem Zwischenspeicher, sodass beim Zurückwechseln der alte Text wieder erscheint. Jeder Moduswechsel lässt alle Patienten neu rechnen |
| Skript übernehmen, Text tippen, Variable per Doppelklick, im modularen Reiter „+“ öffnen, Zeile anlegen oder löschen | schaltet **„automatisch setzen“ selbst ein** |
| Haken „automatisch setzen“, „zurücksetzen“, „Checkbox zuordnen“ | sofort |
| `–` in der Markerliste | löscht **ohne Rückfrage** und ohne Meldung, aber nur weich (wiederherstellbar). `–` bei einer Gruppe: ebenfalls ohne Rückfrage, danach Meldung „Die Gruppe … wurde mit allen zugehörigen Markern gelöscht.“ |
| `–` bei einem modularen Element oder einer Zeile | **mit** Rückfrage |
| **OK** | schließt nur das Fenster; es gibt kein Abbrechen, alles ist schon gespeichert |
| Testpatient laden + „Skripte testen“ | setzt bzw. entfernt alle automatischen Marker **an diesem Patienten** (echte Änderung) |

→ **Bestehende Marker nur ansehen** heißt: in der Liste anwählen und nichts weiter anklicken. Für
Lesezugriffe ist der Cache-Export (`scripts/marker_inventar.py`) der sichere Weg.

## Sichere Arbeitsweise beim Ausprobieren

1. Eine eigene Gruppe anlegen, z. B. `DEMO-…`. Alles Neue kommt dort hinein.
2. Vor und nach jedem Schritt `marker_inventar.py export` und anschließend `diff`. So ist belegt,
   dass nur Demo-Einträge verändert wurden.
3. Skripte im Rumpf auf Demo-Akten begrenzen: `if p_nachname.startswith('Demo-'):` (erweitert)
   bzw. `p_nachname.startswith('Demo-') and …` (einfach). Modular kennt kein Namensfeld, deshalb
   dort „automatisch setzen“ ausschalten, bis die Logik steht.
4. Am Ende bei allen Demo-Markern „automatisch setzen“ aus. Das gilt auch für **gelöschte**
   Demo-Marker (Ansicht „gelöschte … anzeigen“), denn das Löschen ändert den Automatik-Haken nicht.

## Fernsteuerung per Accessibility (macOS, `osascript`)

Die Werkzeuge liegen in `scripts/ax/`. Voraussetzung ist eine Bedienungshilfen-Freigabe für das
Terminal. Eine Bildschirmaufnahme ist nicht nötig, alles wird über AX gelesen.

| Aufgabe | Werkzeug / Rezept |
|---|---|
| Zustand lesen (Gruppen, Marker, Haken, Reiter) | `osascript ax/state.applescript` |
| Teilbaum ausgeben | `osascript -l JavaScript ax/axdump.js "Marker-Verwaltung" 10 5 "W.4"` |
| Zeile in Gruppen- oder Markerliste wählen | `ax/clickrow.sh 1 <Gruppe>` bzw. `ax/clickrow.sh 2 <Marker>`: **echter Mausklick** (CGEvent). `select row` bzw. `click at` markieren nur, die Ansicht lädt dann nicht nach |
| Skript eintippen | Autovervollständigung **aus**, dann `ax/typescript.sh datei.py`. Zeilenumbruch über ⌥↩, danach Fokus wegnehmen, dann wird gespeichert |
| Testpatient laden | `ax/testpatient.sh Demo-<Name>` (verweigert alles ohne `Demo-`). Die Suche lädt den **ersten Treffer**, der nicht immer der gesuchte ist. Den angezeigten Namen prüfen |
| Skripte testen + Hinweise einsammeln | `osascript ax/testen.applescript` |
| Skript kopieren + lokal ausführen | `ax/kopieren_lokal.sh ziel.py` (nur bei Demo-Testpatient) |

Fallen der Oberfläche:

- `set value` auf das Skriptfeld landet nur in der Anzeige und wird **nicht gespeichert**.
- ⌘V in das Skriptfeld leert es und nimmt ihm den Fokus. Deshalb tippen statt einfügen.
- Die Autovervollständigung ergänzt gierig: Aus `p` wird `p_optionalText3`.
- Einblendmenüs öffnen erst beim zweiten Klick: im Wiederholungsfall prüfen, ob `menu 1` existiert.
- In der Modular-Tabelle lassen sich Zeilen außerhalb des sichtbaren Bereichs nicht bedienen.
- Nach einem Feldwechsel in einer Modular-Zeile zeigt die Tabelle die alten Eingabeelemente, bis
  der Marker neu gewählt wird (anderen Marker anklicken, dann zurück).
- Hinweis-Fenster schließen sich nach wenigen Sekunden. Zum Lesen kurz hintereinander abfragen;
  schließen über `perform action "AXPress" of button 2 of window "Hinweis"`.
