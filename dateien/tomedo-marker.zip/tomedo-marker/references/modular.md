# Modularer Modus: Elementtypen, Felder, Operatoren

Ausgelesen an der Referenzinstallation am 12.10.2026 über die Bedienoberfläche (AX-Sonde an einem Demo-Marker).
Die Spalte *Werte* gibt den Tooltip des Eingabefelds wieder. Leer heißt: kein Tooltip, Freitext.

**Inhalt:** Bausteine · Operatoren · Elementtypen und Felder (Karteieintrag, OrgCAV, Medikamentenverordnung, Medikamentenplan, Karteidiagnose, KV-Diagnose, HZV-Diagnose, KV-Leistung, HZV-Leistung, Privatleistung, BG-Leistung, BG-Facharztleistung, BG-Unfallleistung, Privatrechnung, BG-Rechnung, BG-Facharztrechnung, BG-Unfallrechnung, KV-Scheine, Markerliste, Patienteninformation, Versicherung, Behinderung, Pflegegrad, HZV-Teilnahme, SV-Teilnahme) · Hinweise aus Handbuch und Forum · Bedienfallen der Oberfläche

## Bausteine

- **Element** = ein Datenbereich des Patienten (Menü „+“ unten links). tomedo vergibt den nächsten freien
  Bezeichner (A, B, C …) und legt sofort eine Bedingungszeile an.
- **Bedingungszeile** = Feld (Spalte *Datentyp*) + Operator + Wert (Spalte *Eintrag*). Das „+“ in der Elementzeile legt
  weitere Zeilen an. **Alle Zeilen eines Elements gelten per UND für denselben Datensatz**, z. B. *derselbe*
  Karteieintrag hat Typ PSY und enthält „Basisgruppe“.
- **Datum relativ**: Bezug ± Zahl × Einheit. **Positive Zahlen zählen in die Zukunft, negative zurück** (belegt 12.10.2026: Quartal Anfang −2 Quartale → 01.04.2026; Quartal Anfang +2 → 01.04.2027; heute −90 Tage → 14.07.2026). Ein Zeitraum = zwei Datumszeilen im selben Element (von … / bis …).
- **Logische Verknüpfung** (Feld unten): `-` nicht · `&` und · `+` oder · Klammern. Ohne Klammern gilt der Vorrang
  `-` vor `&` vor `+`. tomedo belegt das Feld beim Anlegen mit `A&B&C…` vor. Gespeichert wird es in `ZTAG.ZSCRIPT`.
- Getrennte Elemente werden **unabhängig** ausgewertet: `A&B` heißt „es gibt irgendeinen Datensatz für A und irgendeinen
  für B“, nicht „denselben“.

## Operatoren

| Art | Operatoren (Index = `ZOPERATION`) |
|---|---|
| Text | 0 enthält · 1 ist · 2 enthält nicht · 3 beginnt mit · 4 endet mit · 5 enthält mind. einen der folgenden Texte · 6 enthält alle der folgenden Texte · 7 enthält keinen der folgenden Texte (5–7: komma- oder leerzeichensepariert) |
| Zahl | gleich · größer · größer oder gleich · kleiner · kleiner oder gleich |
| Datum | Bezug (`ZTYP`): 0 Jahr Anfang · 1 Quartal Anfang · 2 Monat Anfang · 3 Jahr Ende · 4 Quartal Ende · 5 Monat Ende · 6 heute · 7 Datum (fest) — dazu eine Zahl (`ZWERT`), die Einheit (`ZEINHEIT`: 0 Jahr(e) · 1 Quartal(e) · 2 Monat(e) · 3 Tag(e)) und die Richtung (`ZOPERATION`: 0 von · 1 bis · 2 am). Rechts zeigt tomedo das errechnete Datum in Klammern, z. B. „(01.01.2026)“ |
| Wert ohne Operator | exakter Wert laut Tooltip (ja/nein, Buchstabencode) bzw. exakte Schreibweise (Betriebsstätte, Nutzer) |

**„enthält nicht“ ist kein Ausschluss**: Die Bedingung trifft, sobald *ein* Datensatz den Text nicht enthält. Für
„hat keinen …“ das Element positiv formulieren und in der Verknüpfung negieren (`-A`).

## Elementtypen und Felder

### Karteieintrag

| Feld | Art | Werte |
|---|---|---|
| Betriebsstätte | Wert ohne Operator |  |
| Datum | Datum (relativ/fest) |  |
| dokumentierender Nutzer | **unklar**: die Oberfläche zeigt Datumselemente (auch nach Neuladen). Laut Handbuch müssen Nutzernamen exakt passen. Vor Gebrauch an einer Demo-Akte testen |  |
| Eintrag | Text (8 Operatoren) |  |
| Medientyp | Text (8 Operatoren) |  |
| Typ | Text (8 Operatoren) | Karteieintragstyp-Kürzel (z. B. DOK, PSY, ePA) |

### OrgCAV

| Feld | Art | Werte |
|---|---|---|
| Datum | Datum (relativ/fest) |  |
| Text | Text (8 Operatoren) |  |

### Medikamentenverordnung

| Feld | Art | Werte |
|---|---|---|
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| ATC | Text (8 Operatoren) |  |
| aut idem | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Datum | Datum (relativ/fest) |  |
| Freitext | Text (8 Operatoren) |  |
| Medikamentenname | Text (8 Operatoren) |  |
| PZN | Text (8 Operatoren) |  |

### Medikamentenplan

| Feld | Art | Werte |
|---|---|---|
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| ATC | Text (8 Operatoren) |  |
| aut idem | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Datum | Datum (relativ/fest) |  |
| Freitext | Text (8 Operatoren) |  |
| Medikamentenname | Text (8 Operatoren) |  |
| PZN | Text (8 Operatoren) |  |

### Karteidiagnose

| Feld | Art | Werte |
|---|---|---|
| Bezeichnung | Text (8 Operatoren) |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Dauerdiagnose | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Freitext | Text (8 Operatoren) |  |
| Meldepflicht | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Ort | Wert ohne Operator | Geben Sie L für links, R für rechts oder B für beidseitig ein. |
| Typ | Wert ohne Operator | Geben Sie A für Ausschluss, G für Gesichert, V für Verdacht oder Z für symptomfreier Zustand nach Erkrankung ein. |
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| manuell abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |

### KV-Diagnose

| Feld | Art | Werte |
|---|---|---|
| Bezeichnung | Text (8 Operatoren) |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Dauerdiagnose | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Freitext | Text (8 Operatoren) |  |
| Meldepflicht | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Ort | Wert ohne Operator | Geben Sie L für links, R für rechts oder B für beidseitig ein. |
| Typ | Wert ohne Operator | Geben Sie A für Ausschluss, G für Gesichert, V für Verdacht oder Z für symptomfreier Zustand nach Erkrankung ein. |
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| manuell abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |

### HZV-Diagnose

| Feld | Art | Werte |
|---|---|---|
| Bezeichnung | Text (8 Operatoren) |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Dauerdiagnose | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Freitext | Text (8 Operatoren) |  |
| Meldepflicht | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Ort | Wert ohne Operator | Geben Sie L für links, R für rechts oder B für beidseitig ein. |
| Typ | Wert ohne Operator | Geben Sie A für Ausschluss, G für Gesichert, V für Verdacht oder Z für symptomfreier Zustand nach Erkrankung ein. |
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| manuell abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |

### KV-Leistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |

### HZV-Leistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |

### Privatleistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### BG-Leistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### BG-Facharztleistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### BG-Unfallleistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### Privatrechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### BG-Rechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### BG-Facharztrechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### BG-Unfallrechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### KV-Scheine

| Feld | Art | Werte |
|---|---|---|
| Freitext | Text (8 Operatoren) |  |
| Sachkosten | Zahl (Vergleich) |  |
| Vermittlungsart | Zahl (Vergleich) | Geben Sie 1 für TSS-Terminfall, 2 für TSS-Akutfall, 3 für HA-Vermittlungsfall, 4 für Offene Sprechstunde, 5 für Neupatient oder 6 für TSS-Routinefall ein. |
| Scheinart | Wert ohne Operator | Geben Sie den zweistelligen Code der Scheinart ein. |
| erstellt am | Datum (relativ/fest) |  |

### Markerliste

| Feld | Art | Werte |
|---|---|---|
| Beschreibung | Text (8 Operatoren) |  |

### Patienteninformation

| Feld | Art | Werte |
|---|---|---|
| Datum letzter Besuch | Datum (relativ/fest) |  |
| Datum letzter Unfall | Datum (relativ/fest) |  |
| Entbindungsdatum | Datum (relativ/fest) |  |
| Geburtsdatum | Datum (relativ/fest) |  |
| Geschlecht | Wert ohne Operator | Geben Sie W für weiblich, M für männlich, X für unbestimmt, D für divers oder U für unbekannt ein. |
| Verschlüsselungscode gesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| DMP-Fallnummer | Text (8 Operatoren) |  |
| HKS-Nummer | Text (8 Operatoren) |  |
| Privatpatient | Wert ohne Operator | Geben Sie ja oder nein ein. |
| DMP-Kennzeichnung | Wert ohne Operator |  |
| ePA-Datenschutzeinstellung | Wert ohne Operator | Geben Sie Z für Zustimmung, T für Teilzustimmung oder W für Widerspruch ein. |
| Betreuer | Text (8 Operatoren) |  |
| Vollmacht | Text (8 Operatoren) |  |

### Versicherung

| Feld | Art | Werte |
|---|---|---|
| GKV-Kostenträger | Text (8 Operatoren) |  |
| IK-Nummer des GKV-Kostenträgers | Text (8 Operatoren) |  |

### Behinderung

| Feld | Art | Werte |
|---|---|---|
| Grad der Behinderung | Zahl (Vergleich) |  |
| Merkzeichen | Text (8 Operatoren) | Geben Sie B für Berechtigung zur Mitnahme einer Begleitperson, G für Bewegungsfähigkeit im Straßenverkehr erheblich eingeschränkt, aG für Außergewöhnliche Gehbehinderung, H für Hilflos, Bl für Blind, Gl für Gehörlos, TBl für Taubblind, RF für Ermäßigung des Rundfunkbeitrags, 1Kl für Berechtigt zur Nutzung der 1. Klasse in der Deutschen Bahn ein. |
| Kriegsgeschädigt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Gültig von | Datum (relativ/fest) |  |
| Gültig bis | Datum (relativ/fest) |  |

### Pflegegrad

| Feld | Art | Werte |
|---|---|---|
| Pflegegrad | Zahl (Vergleich) |  |
| Dauerhafte Mobilitätseinschränkung | Wert ohne Operator | Geben Sie ja oder nein ein. |

### HZV-Teilnahme

| Feld | Art | Werte |
|---|---|---|
| Vertragsname | Text (8 Operatoren) |  |
| Beginn | Datum (relativ/fest) |  |
| Ende | Datum (relativ/fest) |  |

### SV-Teilnahme

| Feld | Art | Werte |
|---|---|---|
| Beginn | Datum (relativ/fest) |  |
| Ende | Datum (relativ/fest) |  |
| Vertragsname | Text (8 Operatoren) |  |

## Hinweise aus Handbuch und Forum

- Betriebsstätten und Nutzernamen müssen **exakt** den in tomedo hinterlegten Angaben entsprechen. `[Hersteller]`
- Patientenabhängige Checkboxen prüft man mit `ja`/`nein`. `[Hersteller; Forum 113393]`
- **Behinderung** mit Gültigkeitszeitraum findet nur Patienten, bei denen das Gültigkeitsdatum gepflegt ist. `[Hersteller]`
- **Karteieinträge**: maßgeblich ist der älteste Eintrag, der die Bedingung erfüllt. `[Hersteller]`
- **Dauerdiagnosen**: Das Datum ist das Erstdiagnosedatum. Ein Quartalsfilter verfehlt sie deshalb. Besser: Dauerdiagnose = ja,
  abgesetzt = nein, Typ = G, ohne Datum. `[Forum 115821]`
- **abgesetzt** umfasst automatisch und manuell abgesetzte Diagnosen, **manuell abgesetzt** nur die manuell abgesetzten. `[Forum 64297, 87479]`
- **Anzahl** zählt je Eintrag bzw. Schein, **Anzahl (insgesamt)** alle Vorkommen im Zeitraum. `[Forum 102601]`
- **Patienteninformation** hat kein HZV-Feld für den Teilnahmestatus. Dafür gibt es das Element *HZV-Teilnahme*. `[Forum 105699]`
- Mehrere Kassen/IKs/Codes: Operator „enthält mind. einen der folgenden Texte“ mit Komma-Liste. `[Forum 93213]`
- „Skript kopieren“ gibt es für modulare Marker nicht. `[Forum 94951]`
- Leere Bedingung → Warnung „Der Marker … enthält mindestens einen leeren Eintrag“. Die Zeile wird dann ignoriert. `[Forum 94951]`

## Bedienfallen der Oberfläche (Referenzinstallation)

- Nach einem Feldwechsel bleiben die Eingabeelemente des alten Felds stehen, bis der Marker neu
  gewählt wird. Der alte Wert (z. B. `0`) wird ins neue Feld übernommen → nach jedem Feldwechsel den Marker einmal ab-
  und wieder anwählen und den Wert prüfen.
- Ist die Tabelle länger als der sichtbare Bereich, lassen sich die Einblendmenüs unsichtbarer Zeilen per
  Fernsteuerung nicht öffnen. Lange modulare Marker vermeiden, lieber *erweitert*.
- Das erste Element schaltet „automatisch setzen“ von selbst ein.
- Tooltips werden teils von einer früheren Zeile übernommen (z. B. zeigte *Karteieintrag › Typ* den Diagnose-Tooltip A/G/V/Z). Ein Tooltip ist also nur ein Hinweis, kein Beleg.
- Datumszeile mit Bezug **Datum**: Statt der Zahl erscheint eine Datumsauswahl, dazu von/bis/am. Die Elemente ragen über den rechten Tabellenrand hinaus.