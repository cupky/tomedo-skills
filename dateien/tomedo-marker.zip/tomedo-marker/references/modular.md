# Modularer Modus: Elementtypen, Felder, Operatoren

Ausgelesen an der Referenzinstallation am 12.10.2026 über die Bedienoberfläche (AX-Sonde an einem Demo-Marker),
seit Fassung 1.1 überarbeitet (Oktober 2026): Feldnamen und Reihenfolge stimmen,
die Auswertungsregeln stehen unten. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem Einsatz an einer Testakte prüfen.
Die Spalte *Werte* gibt den Tooltip des Eingabefelds wieder. Leer heißt: kein Tooltip, Freitext.

**Inhalt:** Bausteine · Operatoren · Elementtypen und Felder (Karteieintrag, OrgCAV, Medikamentenverordnung, Medikamentenplan, Karteidiagnose, KV-Diagnose, HZV-Diagnose, KV-Leistung, HZV-Leistung, Privatleistung, BG-Leistung, BG-Facharztleistung, BG-Unfallleistung, Privatrechnung, BG-Rechnung, BG-Facharztrechnung, BG-Unfallrechnung, KV-Scheine, Markerliste, Patienteninformation, Versicherung, Behinderung, Pflegegrad, HZV-Teilnahme, SV-Teilnahme) · Hinweise aus Handbuch und Forum · Bedienfallen der Oberfläche

## Bausteine

- **Element** = ein Datenbereich des Patienten (Menü „+“ unten links). tomedo vergibt den nächsten freien
  Bezeichner (A, B, C …) und legt sofort eine Bedingungszeile an.
- **Bedingungszeile** = Feld (Spalte *Datentyp*) + Operator + Wert (Spalte *Eintrag*). Das „+“ in der Elementzeile legt
  weitere Zeilen an. **Alle Zeilen eines Elements gelten per UND für denselben Datensatz**, z. B. *derselbe*
  Karteieintrag hat Typ PSY und enthält „Basisgruppe“. Ein Element ist wahr, sobald es **irgendeinen** solchen
  Datensatz gibt. Bei Patienteninformation, Versicherung, Behinderung und Pflegegrad gibt es nur den einen Patienten.
- **Zeilen ohne Wert werden übersprungen.** Ein Element, dessen Zeilen alle leer sind, ist wahr, sobald es irgendeinen
  Datensatz gibt (bei den Patienten-Elementen immer). Eine Warnung dafür gibt es in aktuellen tomedo-Versionen nicht mehr.
- **Datum relativ**: Bezug ± Zahl × Einheit. **Positive Zahlen zählen in die Zukunft, negative zurück** (belegt 12.10.2026: Quartal Anfang −2 Quartale → 01.04.2026; Quartal Anfang +2 → 01.04.2027; heute −90 Tage → 14.07.2026). Ein Zeitraum = zwei Datumszeilen im selben Element (von … / bis …).
- **Logische Verknüpfung** (Feld unten): `-` nicht · `&` und · `+` oder · Klammern. Ohne Klammern gilt der Vorrang
  `-` vor `&` vor `+` (so auch der Tooltipp des Felds). tomedo belegt das Feld beim Anlegen mit `A&B&C…` vor: jedes
  neue Element hängt `&<Buchstabe>` an. Gespeichert wird es in `ZTAG.ZSCRIPT`.
- **So rechnet tomedo die Verknüpfung:** Jedes Element wird zu 1 oder 0, der Buchstabe wird im Text durch diese Zahl
  **ersetzt**, dann werden `-`/`&`/`+` zu Python `not`/`and`/`or` und der Ausdruck wird ausgewertet. Daraus folgen
  Fallen **[ungeprüft]**:
  - `-` steht nur **vor** einem Element. „A ohne B“ = `A&-B`; `A-B` ist ungültig.
  - **Ein Element löschen entfernt seinen Buchstaben nicht aus der Verknüpfung.** Ein Buchstabe ohne Element macht
    die Verknüpfung ungültig. Nach jedem Löschen die Verknüpfung von Hand anpassen.
  - Bezeichner, die in einem anderen stecken (`A` und `AB`), können sich gegenseitig zerstören. Nach `Z` vergibt
    tomedo `ZA` – mehr als 26 Elemente vermeiden. Bezeichner dürfen nur Buchstaben und Ziffern enthalten.
  - Ist die Verknüpfung ungültig, bleibt der Marker am Patienten, **wie er ist**. „Skripte testen“ meldet dann
    „Der Marker … kann nicht ausgewertet werden. Bitte überprüfen Sie die logische Verknüpfung der Elemente. …“
- Nur Elemente, deren Buchstabe in der Verknüpfung steht, werden ausgewertet. Ein Marker mit „automatisch setzen“, aber
  **ohne Element oder mit leerer Verknüpfung**, wird gar nicht berechnet; sein Zustand am Patienten bleibt.
- Getrennte Elemente werden **unabhängig** ausgewertet: `A&B` heißt „es gibt irgendeinen Datensatz für A und irgendeinen
  für B“, nicht „denselben“.

## Operatoren

| Art | Operatoren (Index = `ZOPERATION`) |
|---|---|
| Text | 0 enthält · 1 ist · 2 enthält nicht · 3 beginnt mit · 4 endet mit · 5 enthält mind. einen der folgenden Texte · 6 enthält alle der folgenden Texte · 7 enthält keinen der folgenden Texte (5–7: komma- oder leerzeichensepariert) |
| Zahl | gleich · größer · größer oder gleich · kleiner · kleiner oder gleich |
| Datum | Bezug (`ZTYP`): 0 Jahr Anfang · 1 Quartal Anfang · 2 Monat Anfang · 3 Jahr Ende · 4 Quartal Ende · 5 Monat Ende · 6 heute · 7 Datum (fest) — dazu eine Zahl (`ZWERT`), die Einheit (`ZEINHEIT`: 0 Jahr(e) · 1 Quartal(e) · 2 Monat(e) · 3 Tag(e)) und die Richtung (`ZOPERATION`: 0 von · 1 bis · 2 am). Rechts zeigt tomedo das errechnete Datum in Klammern, z. B. „(01.01.2026)“ |
| Wert ohne Operator | ja/nein-Felder: „ja“ oder „nein“ (auch „yes“/„no“, Groß-/Kleinschreibung egal); jeder andere Wert macht die Zeile **falsch**. Betriebsstätte, dokumentierender Nutzer, Abrechner, Leistungserbringer: Vergleich „ist“ gegen das **Kürzel**, ohne Groß-/Kleinschreibung. Buchstabencodes (Diagnose-Typ und -Ort, Geschlecht, DMP-Kennzeichnung, ePA, Scheinart): Hier wirkt der **gespeicherte, unsichtbare Operator**, normalerweise „enthält“ („g“ trifft „G“) **[ungeprüft]** |

**„enthält nicht“ ist kein Ausschluss**: Die Bedingung trifft, sobald *ein* Datensatz den Text nicht enthält. Für
„hat keinen …“ das Element positiv formulieren und in der Verknüpfung negieren (`-A`).

**Vergleichsregeln**:

- „enthält“, „ist“, „enthält nicht“ und die Listen-Operatoren 5–7 unterscheiden **nicht** nach Groß-/Kleinschreibung,
  **„beginnt mit“ und „endet mit“ schon**. Leerzeichen werden nirgends abgeschnitten.
- Listen-Operatoren 5–7 trennen an Komma **und** Leerzeichen zugleich. Begriffe aus mehreren Wörtern („Schmerz
  Schulung“) zerfallen in Einzelwörter.
- Ist das Feld am Datensatz **leer**, ist jede Textbedingung falsch, auch „enthält nicht“ und „enthält keinen“.
- Datum: verglichen wird nur der Tag. „von“ = am oder nach, „bis“ = am oder vor, „am“ = derselbe Tag. Fehlt das Datum
  am Datensatz, ist die Zeile falsch.
- Zahl: Fehlt der Wert am Patienten ganz (kein Pflegegrad, kein Schwerbehindertenausweis), sind „größer oder gleich“
  und „kleiner oder gleich“ **wahr**, die übrigen falsch **[ungeprüft]**. Für „hat Pflegegrad 2 oder höher“ daher
  „größer 1“ verwenden. Nachkommawerte bei „gleich“ (z. B. Sachkosten 12,30) treffen unzuverlässig **[ungeprüft]**.
- **Datumsrechnung mit „Monat Ende“/„Quartal Ende“:** Die Einheiten rechnen in Kalendermonaten und kappen am
  Monatsende, z. B. 30.09. + 1 Quartal = 30.12. Der 31. fällt dann bei „bis“ heraus **[ungeprüft]**. Sicherer: „bis
  Quartal Anfang −1 Tag(e)“ für das Ende des Vorquartals, „bis Quartal Ende 0“ für das laufende.

## Elementtypen und Felder

### Karteieintrag

| Feld | Art | Werte |
|---|---|---|
| Betriebsstätte | Wert ohne Operator |  |
| Datum | Datum (relativ/fest) |  |
| dokumentierender Nutzer | **nicht nutzbar**: tomedo hält das Feld wegen des Wortteils „ende“ für ein Datumsfeld und zeigt Datumselemente; verglichen wird aber das Nutzerkürzel mit „ist“ **[ungeprüft]**. Für „dokumentiert von“ den Modus *erweitert* verwenden (`e['doku']`) |  |
| Eintrag | Text (8 Operatoren) |  |
| Medientyp | Text (8 Operatoren) |  |
| Typ | Text (8 Operatoren) | Karteieintragstyp-Kürzel (z. B. DOK, PSY, ePA); bei Formularen das Formulartyp-Kürzel |

Durchsucht werden Karteieinträge, **Formulare und Caves**; gelöschte nicht.

### OrgCAV

| Feld | Art | Werte |
|---|---|---|
| Datum | Datum (relativ/fest) |  |
| Text | Text (8 Operatoren) |  |

Eine per „–“ gelöschte Bedingungszeile wirkt bei OrgCAV **weiter** **[ungeprüft]**: Zeile lieber leeren
oder das ganze Element neu anlegen.

### Medikamentenverordnung

| Feld | Art | Werte |
|---|---|---|
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| ATC | Text (8 Operatoren) |  |
| aut idem | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Datum | Datum (relativ/fest) |  |
| Freitext | Text (8 Operatoren) |  |
| Medikamentenname | Text (8 Operatoren) |  |
| PZN | Text (8 Operatoren) |  |

Hinweise (gelten auch für Medikamentenplan): „ATC“ trifft den ATC-Code **oder** die Bezeichnung in Klammern;
„Freitext“ ist der **Dosierungsfreitext**; abgesetzte Medikamente zählen mit, dafür gibt es die Zeile „abgesetzt“.

### Medikamentenplan

| Feld | Art | Werte |
|---|---|---|
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| ATC | Text (8 Operatoren) |  |
| aut idem | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Datum | Datum (relativ/fest) |  |
| Freitext | Text (8 Operatoren) |  |
| Medikamentenname | Text (8 Operatoren) |  |
| PZN | Text (8 Operatoren) |  |

### Karteidiagnose

| Feld | Art | Werte |
|---|---|---|
| Bezeichnung | Text (8 Operatoren) |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Dauerdiagnose | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Freitext | Text (8 Operatoren) |  |
| Meldepflicht | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Ort | Wert ohne Operator | Geben Sie L für links, R für rechts oder B für beidseitig ein. |
| Typ | Wert ohne Operator | Geben Sie A für Ausschluss, G für Gesichert, V für Verdacht oder Z für symptomfreier Zustand nach Erkrankung ein. |
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| manuell abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |

Hinweise (gelten für alle Diagnose-Elemente):

- „Bezeichnung“ ist der **ICD-Katalogtext**, nicht der in der Kartei geänderte Text; der steht in „Freitext“.
- „abgesetzt“ = ja heißt: Die Diagnose ist zu Beginn des Vorquartals **nicht mehr aktiv**. Das trifft auch alte
  Diagnosen ohne Dauerdiagnose-Kennzeichen und Diagnosen ohne Datum. „manuell abgesetzt“ = ausdrücklich abgesetzt.
- KV- und HZV-Diagnosen kommen aus den Scheinen **aller** Quartale.

### KV-Diagnose

| Feld | Art | Werte |
|---|---|---|
| Bezeichnung | Text (8 Operatoren) |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Dauerdiagnose | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Freitext | Text (8 Operatoren) |  |
| Meldepflicht | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Ort | Wert ohne Operator | Geben Sie L für links, R für rechts oder B für beidseitig ein. |
| Typ | Wert ohne Operator | Geben Sie A für Ausschluss, G für Gesichert, V für Verdacht oder Z für symptomfreier Zustand nach Erkrankung ein. |
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| manuell abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |

### HZV-Diagnose

| Feld | Art | Werte |
|---|---|---|
| Bezeichnung | Text (8 Operatoren) |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Dauerdiagnose | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Freitext | Text (8 Operatoren) |  |
| Meldepflicht | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Ort | Wert ohne Operator | Geben Sie L für links, R für rechts oder B für beidseitig ein. |
| Typ | Wert ohne Operator | Geben Sie A für Ausschluss, G für Gesichert, V für Verdacht oder Z für symptomfreier Zustand nach Erkrankung ein. |
| abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| manuell abgesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |

### KV-Leistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |

**Anzahl und Anzahl (insgesamt):** „Anzahl“ prüft das Anzahl-Feld **einer** Leistungszeile (z. B. 2 × 03230).
„Anzahl (insgesamt)“ **summiert** die Anzahl-Felder aller Leistungen, die die übrigen Zeilen des Elements erfüllen.
Ohne Datumszeile zählt sie über **alle Quartale**; „gleich 0“ ist wahr, wenn es keine passende Leistung gibt. Nur eine
Zeile „Anzahl (insgesamt)“ je Element verwenden. Leistungen kommen aus allen Scheinen bzw. Rechnungen, ohne Filter auf
bezahlt oder abgerechnet.

### HZV-Leistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |

### Privatleistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### BG-Leistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### BG-Facharztleistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### BG-Unfallleistung

| Feld | Art | Werte |
|---|---|---|
| Abrechner | Wert ohne Operator |  |
| Anzahl (insgesamt) | Zahl (Vergleich) |  |
| Anzahl | Zahl (Vergleich) |  |
| Betriebsstätte | Wert ohne Operator |  |
| Code | Text (8 Operatoren) |  |
| Datum | Datum (relativ/fest) |  |
| Leistungserbringer | Wert ohne Operator |  |
| Kurztext | Text (8 Operatoren) |  |
| Langtext | Text (8 Operatoren) |  |
| Steigerungsfaktor | Zahl (Vergleich) |  |

### Privatrechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

Hinweise (gelten für alle Rechnungs-Elemente): „Versicherungsname“ trifft nur, wenn die Rechnung an die Versicherung
adressiert ist. Bezahlte und stornierte Rechnungen werden nicht ausgefiltert. In der Schweiz gibt es zusätzlich das Feld
„Tariftyp“ (Selbstzahler/SZ, KVG, IVG, MVG, UVG, VVG).

### BG-Rechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### BG-Facharztrechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### BG-Unfallrechnung

| Feld | Art | Werte |
|---|---|---|
| Bemerkung | Text (8 Operatoren) |  |
| bezahlt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Bezahldatum | Datum (relativ/fest) |  |
| Datum der letzten Leistung | Datum (relativ/fest) |  |
| Druckdatum | Datum (relativ/fest) |  |
| erstellt am | Datum (relativ/fest) |  |
| Festbetrag | Zahl (Vergleich) |  |
| Freitext | Text (8 Operatoren) |  |
| Kostenvoranschlag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Rechnungsbetrag | Zahl (Vergleich) |  |
| Mahnstufe | Zahl (Vergleich) |  |
| 1. Mahndatum | Datum (relativ/fest) |  |
| 2. Mahndatum | Datum (relativ/fest) |  |
| 3. Mahndatum | Datum (relativ/fest) |  |
| Sachkostenbetrag | Zahl (Vergleich) |  |
| Teilbetrag | Wert ohne Operator | Geben Sie ja oder nein ein. |
| bezahlter Teilbetrag | Zahl (Vergleich) |  |
| versandt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Versicherungsname | Text (8 Operatoren) |  |

### KV-Scheine

| Feld | Art | Werte |
|---|---|---|
| Freitext | Text (8 Operatoren) |  |
| Sachkosten | Zahl (Vergleich) |  |
| Vermittlungsart | Zahl (Vergleich) | Geben Sie 1 für TSS-Terminfall, 2 für TSS-Akutfall, 3 für HA-Vermittlungsfall, 4 für Offene Sprechstunde, 5 für Neupatient oder 6 für TSS-Routinefall ein. |
| Scheinart | Wert ohne Operator | Geben Sie den zweistelligen Code der Scheinart ein. |
| erstellt am | Datum (relativ/fest) | verglichen wird das **Sortierdatum** des Scheins |

Durchsucht werden die KV-Scheine **aller** Quartale.

### Markerliste

| Feld | Art | Werte |
|---|---|---|
| Beschreibung | Text (8 Operatoren) |  |

Geprüft wird der Stand **vor** dieser Berechnung, ohne Markergruppen. Ein Marker, der im selben Lauf gesetzt wird, ist
für andere Marker erst beim nächsten Lauf sichtbar.

### Patienteninformation

| Feld | Art | Werte |
|---|---|---|
| Datum letzter Besuch | Datum (relativ/fest) |  |
| Datum letzter Unfall | Datum (relativ/fest) |  |
| Entbindungsdatum | Datum (relativ/fest) |  |
| Geburtsdatum | Datum (relativ/fest) |  |
| Geschlecht | Wert ohne Operator | Geben Sie W für weiblich, M für männlich, X für unbestimmt, D für divers oder U für unbekannt ein. |
| Verschlüsselungscode gesetzt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| DMP-Fallnummer | Text (8 Operatoren) |  |
| HKS-Nummer | Text (8 Operatoren) |  |
| Privatpatient | Wert ohne Operator | Geben Sie ja oder nein ein. |
| DMP-Kennzeichnung | Wert ohne Operator |  |
| ePA-Datenschutzeinstellung | Wert ohne Operator | Geben Sie Z für Zustimmung, T für Teilzustimmung oder W für Widerspruch ein. |
| *praxisspezifische Felder* | Text (8 Operatoren) | Die Referenzinstallation zeigte hier „Betreuer“ und „Vollmacht“. Das sind **keine** festen Felder, sondern die frei benannten praxisspezifischen Felder (bis zu vier Text- und zwei Ja/Nein-Felder, Einstellungen › Praxis › Praxisspezifische Felder Besuchsliste). Sie erscheinen nur, wenn sie benannt und eingeblendet sind. **Wird ein solches Feld umbenannt, wirkt die Zeile nicht mehr** (Tooltip weist darauf hin) **[ungeprüft]** |

### Versicherung

| Feld | Art | Werte |
|---|---|---|
| GKV-Kostenträger | Text (8 Operatoren) |  |
| IK-Nummer des GKV-Kostenträgers | Text (8 Operatoren) |  |

### Behinderung

| Feld | Art | Werte |
|---|---|---|
| Grad der Behinderung | Zahl (Vergleich) |  |
| Merkzeichen | Text (8 Operatoren) | Geben Sie B für Berechtigung zur Mitnahme einer Begleitperson, G für Bewegungsfähigkeit im Straßenverkehr erheblich eingeschränkt, aG für Außergewöhnliche Gehbehinderung, H für Hilflos, Bl für Blind, Gl für Gehörlos, TBl für Taubblind, RF für Ermäßigung des Rundfunkbeitrags, 1Kl für Berechtigt zur Nutzung der 1. Klasse in der Deutschen Bahn ein. |
| Kriegsgeschädigt | Wert ohne Operator | Geben Sie ja oder nein ein. |
| Gültig von | Datum (relativ/fest) |  |
| Gültig bis | Datum (relativ/fest) |  |

Merkzeichen werden als ein kleingeschriebener Sammeltext verglichen (z. B. „g, ag, rf, “). „enthält g“ trifft daher auch
aG und Gl, „ist“ und „endet mit“ treffen nie **[ungeprüft]**. Ein unbefristeter Ausweis (leeres „Gültig bis“) fällt bei
jeder Datumszeile auf „Gültig bis“ durch.

### Pflegegrad

| Feld | Art | Werte |
|---|---|---|
| Pflegegrad | Zahl (Vergleich) |  |
| Dauerhafte Mobilitätseinschränkung | Wert ohne Operator | Geben Sie ja oder nein ein. „ja“ trifft nur zusammen mit Pflegegrad 3 oder höher |

### HZV-Teilnahme

| Feld | Art | Werte |
|---|---|---|
| Vertragsname | Text (8 Operatoren) |  |
| Beginn | Datum (relativ/fest) |  |
| Ende | Datum (relativ/fest) |  |

HZV- und SV-Teilnahme prüfen **alle** Teilnahmen, auch beendete. Ein fehlendes Ende gilt als „unbegrenzt“. Für „nimmt
derzeit teil“: Zeile „Ende von heute 0 Tag(e)“ ergänzen.

### SV-Teilnahme

| Feld | Art | Werte |
|---|---|---|
| Beginn | Datum (relativ/fest) |  |
| Ende | Datum (relativ/fest) |  |
| Vertragsname | Text (8 Operatoren) |  |

## Elementtypen je Installation

Die Liste oben gilt für Arztpraxen in Deutschland. **Zahnarzt (Deutschland):** zusätzlich BEB-, BEL-, BEMA- und
Materialleistung, dafür **keine** HZV- und SV-Teilnahme. **Schweiz und Österreich:** nur OrgCAV, Karteieintrag,
Medikamentenverordnung, Medikamentenplan, **Diagnose**, **Leistung**, Privatrechnung, Markerliste, Patienteninformation
(ohne DMP-, HKS-, Privatpatient-, ePA-Felder) und Versicherung (Schweiz: nur „Privatversicherung“). Labor oder Termine
gibt es als Elementtyp nicht.

## Hinweise aus Handbuch und Forum

- Betriebsstätten und Nutzernamen müssen **exakt** den in tomedo hinterlegten Angaben entsprechen. `[Hersteller]`
- Patientenabhängige Checkboxen prüft man mit `ja`/`nein`. `[Hersteller; Forum 113393]`
- **Behinderung** mit Gültigkeitszeitraum findet nur Patienten, bei denen das Gültigkeitsdatum gepflegt ist. `[Hersteller]`
- **Karteieinträge**: maßgeblich ist der älteste Eintrag, der die Bedingung erfüllt. `[Hersteller]` Für das Ergebnis
  ist das gleich: Es genügt **irgendein** passender Eintrag. **[ungeprüft]**
- **Dauerdiagnosen**: Das Datum ist das Erstdiagnosedatum. Ein Quartalsfilter verfehlt sie deshalb. Besser: Dauerdiagnose = ja,
  abgesetzt = nein, Typ = G, ohne Datum. `[Forum 115821]`
- **abgesetzt** umfasst automatisch und manuell abgesetzte Diagnosen, **manuell abgesetzt** nur die manuell abgesetzten. `[Forum 64297, 87479]` Genaue Bedeutung siehe Hinweis bei Karteidiagnose.
- **Anzahl** zählt je Eintrag bzw. Schein, **Anzahl (insgesamt)** alle Vorkommen im Zeitraum. `[Forum 102601]` Genauer: siehe Hinweis bei KV-Leistung.
- **Patienteninformation** hat kein HZV-Feld für den Teilnahmestatus. Dafür gibt es das Element *HZV-Teilnahme*. `[Forum 105699]`
- Mehrere Kassen/IKs/Codes: Operator „enthält mind. einen der folgenden Texte“ mit Komma-Liste. `[Forum 93213]`
  Kassennamen mit Leerzeichen („AOK PLUS“) zerfallen dabei in Einzelwörter – besser die IK-Nummer verwenden.
- „Skript kopieren“ gibt es für modulare Marker nicht. `[Forum 94951]` Meldung: „In diesem Modus kann das Skript nicht kopiert werden.“
- Leere Bedingung: Die Zeile wird ignoriert. `[Forum 94951]` Die frühere Warnung „Der Marker … enthält mindestens einen
  leeren Eintrag“ ist in aktuellen tomedo-Versionen abgeschaltet.

## Bedienfallen der Oberfläche (Referenzinstallation)

- Nach einem Feldwechsel bleiben die Eingabeelemente des alten Felds stehen, bis der Marker neu
  gewählt wird. Der alte Wert (z. B. `0`) wird ins neue Feld übernommen → nach jedem Feldwechsel den Marker einmal ab-
  und wieder anwählen und den Wert prüfen. Auch der **Operator** bleibt gespeichert: Wer eine Datumszeile („am“) auf
  ein Feld ohne Operatorauswahl umstellt (z. B. Diagnose-Typ), vergleicht unsichtbar mit „enthält nicht“ **[ungeprüft]**.
  Sicherer: Zeile löschen und neu anlegen.
- Ist die Tabelle länger als der sichtbare Bereich, lassen sich die Einblendmenüs unsichtbarer Zeilen per
  Fernsteuerung nicht öffnen. Lange modulare Marker vermeiden, lieber *erweitert*.
- Das erste Element schaltet „automatisch setzen“ von selbst ein, ebenso schon das Öffnen des Menüs „+“, jede
  Eingabe in der Tabelle und das Löschen von Elementen oder Zeilen. Löschen fragt nach („Soll das markierte Element
  wirklich mit allen Einträgen gelöscht werden?“).
- Tooltips werden teils von einer früheren Zeile übernommen (z. B. zeigte *Karteieintrag › Typ* den Diagnose-Tooltip A/G/V/Z). Ein Tooltip ist also nur ein Hinweis, kein Beleg.
- Datumszeile mit Bezug **Datum**: Statt der Zahl erscheint eine Datumsauswahl, dazu von/bis/am. Die Elemente ragen über den rechten Tabellenrand hinaus.
