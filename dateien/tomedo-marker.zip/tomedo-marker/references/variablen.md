# Skriptvariablen der Marker-Automatisierung

Vollständige Liste der **150 Variablen**, die in den Skriptmodi *einfach* und *erweitert* zur Verfügung stehen.
Quelle: Variablentabelle oben rechts in der Marker-Verwaltung bzw. Tabelle `ZTAGSCRIPTVARIABLE` des lokalen Caches,
ausgelesen an der Referenzinstallation am 12.10.2026. Die Spalte *Ausdruck* zeigt, woraus tomedo den Wert befüllt
(Objektpfad am Patienten); bei Funktionen steht dort der Python-Quelltext, den tomedo vor das Skript setzt.

> **Namen exakt übernehmen.** Groß-/Kleinschreibung zählt (`orgCaves`, `hzvTeilnahmen`, `svTeilnahme` ohne n,
> `guthabenEinzahlungen`). Der Tippfehler `fachartz_tel` ist so im Produkt hinterlegt.

**Datentypen:** `string` 72, `bool` 25, `date` 12, `array:Leistung` 10, `function` 6, `integer` 6, `array:Rechnung` 4, `array:Diagnose` 3, `array:Teilbetrag` 2, `array:Teilnahme` 2, `array:Medikamentenverordnung` 2, `float` 2, `array:KarteiEintrag` 1, `array:Schein` 1, `array:string` 1, `array:OrgCAV` 1

## Funktionen (Python-Hilfen, vordefiniert)

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `heuteDatum` | function | Das heutige Datum im Format 'd.m.YYYY' | `siehe unten` |
| `heuteQuartal` | function | Das heutige Datum im Format Jahr+0.25*Quartal | `siehe unten` |
| `jahre` | function | Wandelt einen Datumsstring in Jahre bis jetzt um, z.B. jahre(p_geburt) ist das Patientenalter | `siehe unten` |
| `mutterschutz` | function | Wandelt einen Datumsstring in den Datumsstring des Beginns des Mutterschutzes um. | `siehe unten` |
| `schwangerschaftstage` | function | Schwangerschaftstage | `siehe unten` |
| `select` | function | Beschneidet das gegebene Array auf den gegebenen Zeitraum. | `siehe unten` |

## Listen (array:…) — Kartei, Abrechnung, Medikation

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `bebleistungen` | array:Leistung | Liste aller Leistungen der BEB | `patient.patientenDetails.patientenDetailsRelationen.kzvscheine.zahnarztLaborkosten` |
| `belleistungen` | array:Leistung | Liste aller Leistungen des BEL | `patient.patientenDetails.patientenDetailsRelationen.kzvscheine.zahnarztLaborkosten` |
| `bemaleistungen` | array:Leistung | Liste aller Leistungen des BEMA | `patient.patientenDetails.patientenDetailsRelationen.kzvscheine.zahnarztLaborkosten` |
| `bgfacharztleistungen` | array:Leistung | Liste aller Leistungen in den BG-Facharzt-Rechnungen | `patient.patientenDetails.patientenDetailsRelationen.bgFacharztRechnungen.goaeLeistungen` |
| `bgfacharztrechnungen` | array:Rechnung | Liste aller BG-Facharzt-Rechnungen | `patient.patientenDetails.patientenDetailsRelationen.bgfacharztrechnungen` |
| `bgleistungen` | array:Leistung | Liste aller Leistungen in den BG-Rechnungen | `patient.patientenDetails.patientenDetailsRelationen.bgRechnungen.goaeLeistungen` |
| `bgrechnungen` | array:Rechnung | Liste aller BG-Rechnungen | `patient.patientenDetails.patientenDetailsRelationen.bgrechnungen` |
| `bgunfallleistungen` | array:Leistung | Liste aller Leistungen in den BG-Unfall-Rechnungen | `patient.patientenDetails.patientenDetailsRelationen.bgUnfallRechnungen.goaeLeistungen` |
| `bgunfallrechnungen` | array:Rechnung | Liste aller BG-Unfall-Rechnungen | `patient.patientenDetails.patientenDetailsRelationen.bgunfallrechnungen` |
| `guthabenAuszahlungen` | array:Teilbetrag | Liste aller Guthabenauszahlungen | `patient.patientenDetails.guthabenAuszahlung` |
| `guthabenEinzahlungen` | array:Teilbetrag | Liste aller Guthabeneinzahlungen | `patient.patientenDetails.guthabenEinzahlung` |
| `hzvdiagnosen` | array:Diagnose | Liste aller Diagnosen in den HZVScheinen | `patient.patientenDetails.patientenDetailsRelationen.hzvscheine.quartalsdiagnosen` |
| `hzvleistungen` | array:Leistung | Liste aller Leistungen in den HZVScheinen | `patient.patientenDetails.patientenDetailsRelationen.hzvScheine.hzvLeistungen` |
| `hzvTeilnahmen` | array:Teilnahme | Liste aller HZV-Teilnahmen | – |
| `karteidiagnosen` | array:Diagnose | Liste aller Diagnosen in der Kartei | `patient.patientenDetails.patientenDetailsRelationen.karteiEintraege.diagnose` |
| `karteieintraege` | array:KarteiEintrag | Liste aller Karteieinträge (inklusive Formulare und med. Caves). | `patient.patientenDetails.patientenDetailsRelationen.karteiEintraege` |
| `kvdiagnosen` | array:Diagnose | Liste aller Diagnosen in den KVScheinen | `patient.patientenDetails.patientenDetailsRelationen.kvscheine.quartalsdiagnosen` |
| `kvleistungen` | array:Leistung | Liste aller Leistungen in den KVScheinen | `patient.patientenDetails.patientenDetailsRelationen.kvscheine.ebmLeistungen` |
| `kvscheine` | array:Schein | Liste aller KVScheine | `patient.patientenDetails.patientenDetailsRelationen.kvscheine` |
| `markerliste` | array:string | Liste aller Beschreibungen der vor Beginn der Automatisierung gesetzten Marker | `patient.patientenDetails.tags` |
| `materialleistungen` | array:Leistung | Liste aller Materialleistungen | `patient.patientenDetails.patientenDetailsRelationen.kzvscheine.zahnarztLaborkosten` |
| `medikamentenplan` | array:Medikamentenverordnung | Liste aller Medikamente im Medikamentenplan | `patient.patientenDetails.patientenDetailsRelationen.medikamentenPlan` |
| `orgCaves` | array:OrgCAV | Liste aller organisatorischen Caves | `patient.patientenDetails.patientenDetailsRelationen.orgCaves` |
| `privatleistungen` | array:Leistung | Liste aller Leistungen in den Privatrechnungen | `patient.patientenDetails.patientenDetailsRelationen.rechnungen.goaeLeistungen` |
| `privatrechnungen` | array:Rechnung | Liste aller Privatrechnungen | `patient.patientenDetails.patientenDetailsRelationen.rechnungen` |
| `svTeilnahme` | array:Teilnahme | Liste aller SV-Teilnahmen | – |
| `verordnungen` | array:Medikamentenverordnung | Liste aller Verordnungen | `patient.patientenDetails.patientenDetailsRelationen.verordnungen` |

## Patient (p_…)

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `p_arbeitszeit` | float | Patient: wöchentliche Arbeitszeit | `patient.patientenDetails.beschaeftigungsstatus.woechentlicheArbeitszeit` |
| `p_arztDirektStatus` | integer | Patient: ArztDirekt-Status. (0 : Unbekannt, 1 : Mehrfache Kopplungsanfrage, 2 : Kopplungsanfrage ohne eindeutige Zuweisung, 3 : Kopplungsanfrage, 4 : Gekoppelt) | `patient.arztDirektStatus` |
| `p_behinderungsgrad` | integer | Patient: Grad der Behinderung | `patient.patientenDetails.schwerbehindertenausweis.gradDerBehinderung` |
| `p_beruf` | string | Patient: Beruf | `patient.patientenDetails.beruf` |
| `p_berufSeit` | date | Patient: Beginn des Berufs. | `patient.patientenDetails.berufSeit` |
| `p_beschaeftigtSeit` | string | Patient: Beginn der letzten Beschäftigung. | `patient.patientenDetails.beschaeftigtSeit` |
| `p_blueEvidenceID` | string | Patient: blueEvidenceID | `patient.patientenDetails.oldPatientIdent_blueEvidence` |
| `p_bundesland` | string | Patient: Bundesland | `patient.patientenDetails.kontaktdaten.adresse.bundesland` |
| `p_dauerhafteMobilitaetseinschraenkung` | bool | Patient: dauerhaft mobilitätseingeschränkt | `patient.patientenDetails.pflegegrad.modifier` |
| `p_distanzOrt` | float | Patient: Kilometer zum Wohnort | `patient.patientenDetails.kilometerZumWohnort` |
| `p_dmpFallnummer` | string | Patient: DMP-Fallnummer | `patient.patientenDetails.dmpFallnummer` |
| `p_dmpFallnummerGesendet` | bool | Patient: Sendestatus der DMP-Fallnummer | `patient.patientenDetails.dmpFallnummerGesendet` |
| `p_dmpKennzeichnung` | string | Patient: DMP-Kennzeichnung | – |
| `p_email` | string | Patient: Email | `patient.patientenDetails.kontaktdaten.email` |
| `p_epaDatenschutzeinstellung` | string | Patient: ePa-Datenschutzbestimmung - Zustimmung 'Z', Teilzustimmung 'T', Widerspruch 'W' | – |
| `p_erhoehterBehandlungsbedarf` | bool | Patient: erhoehterBehandlungsbedarf | `patient.patientenDetails.erhoehterBehandlungsbedarf` |
| `p_erstbesuch` | date | Patient: Erstbesuch | `patient.patientenDetails.ersterBesuch` |
| `p_erwerbstaetig` | bool | Patient: Erwerbstätig? | `patient.patientenDetails.beschaeftigungsstatus.erwerbstaetig` |
| `p_fekFallnummer` | string | Patient: FEK-Nummer | `patient.patientenDetails.patientennummerFEK` |
| `p_fekFallnummerGesendet` | bool | Patient: Sendestatus der FEK-Nummer | `patient.patientenDetails.patientennummerFEKGesendet` |
| `p_freitext` | string | Patient: Inhalt des Patienteninfo-Textfeldes | `patient.patientenDetails.freitext` |
| `p_geburt` | date | Patient: Geburtsdatum | `patient.geburtsDatum` |
| `p_geistig` | bool | Patient: überwiegend geistige Tätigkeit? | `patient.patientenDetails.beschaeftigungsstatus.ueberwiegendGeistig` |
| `p_geschlecht` | string | Patient: Geschlecht - männliche 'M', weiblich 'W' | `patient.patientenDetails.geschlecht` |
| `p_handy` | string | Patient: Handynummer | `patient.patientenDetails.kontaktdaten.handyNummer` |
| `p_hksFallnummerGesendet` | bool | Patient: Sendestatus der HKS-Nummer | `patient.patientenDetails.patientennummerHKSGesendet` |
| `p_hksNummer` | string | Patient: HKS-Nummer | `patient.patientenDetails.patientennummerHKS` |
| `p_id` | integer | Patient: Ident | `patient.ident` |
| `p_kriegsgeschaedigt` | bool | Patient: Kriegsgeschädigt | `patient.patientenDetails.schwerbehindertenausweis.kriegsgeschaedigt` |
| `p_land` | string | Patient: Land | `patient.patientenDetails.kontaktdaten.adresse.land` |
| `p_letzterbesuch` | date | Patient: letzter Besuch | `patient.patientenDetails.datumLetzterBesuch` |
| `p_merkzeichen1Kl` | bool | Patient: Berechtigt zur Nutzung der 1. Klasse in der Deutschen Bahn | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_1Kl` |
| `p_merkzeichenAG` | bool | Patient: Außergewöhnliche Gehbehinderung | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_aG` |
| `p_merkzeichenB` | bool | Patient: Berechtigung zur Mitnahme einer Begleitperson | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_B` |
| `p_merkzeichenBl` | bool | Patient: Blind | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_Bl` |
| `p_merkzeichenG` | bool | Patient: Bewegungsfähigkeit im Straßenverkehr erheblich eingeschränkt | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_G` |
| `p_merkzeichenGl` | bool | Patient: Gehörlos | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_Gl` |
| `p_merkzeichenH` | bool | Patient: Hilflos | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_H` |
| `p_merkzeichenRF` | bool | Patient: Ermäßigung des Rundfunkbeitrags | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_RF` |
| `p_merkzeichenTBl` | bool | Patient: Taubblind | `patient.patientenDetails.schwerbehindertenausweis.merkzeichen_TBl` |
| `p_nachname` | string | Patient: Nachname | `patient.nachname` |
| `p_namenszusatz` | string | Patient: Namenszusatz | `patient.patientenDetails.namensZusatz` |
| `p_nationalitaet` | string | Patient: Nationalität | `patient.patientenDetails.nationalitaet` |
| `p_optionalCheck1` | bool | Patient: Status des 1. frei wählbaren Häkchens. | `patient.patientenDetails.boolCol1` |
| `p_optionalCheck2` | bool | Patient: Status des 2. frei wählbaren Häkchens. | `patient.patientenDetails.boolCol2` |
| `p_optionalText1` | string | Patient: Inhalt des 1. frei wählbaren Textfeldes. | `patient.patientenDetails.stringCol1` |
| `p_optionalText2` | string | Patient: Inhalt des 2. frei wählbaren Textfeldes. | `patient.patientenDetails.stringCol2` |
| `p_optionalText3` | string | Patient: Inhalt des 3. frei wählbaren Textfeldes. | `patient.patientenDetails.stringCol3` |
| `p_optionalText4` | string | Patient: Inhalt des 4. frei wählbaren Textfeldes. | `patient.patientenDetails.stringCol4` |
| `p_ort` | string | Patient: Ort | `patient.ort` |
| `p_pflegegrad` | integer | Patient: Pflegegrad | `patient.patientenDetails.pflegegrad.grad` |
| `p_plz` | string | Patient: Postleitzahl | `patient.patientenDetails.kontaktdaten.adresse.plz` |
| `p_privateZusatzversicherungText` | string | Patient: Text zur privaten Zusatzversicherung. | `patient.patientenDetails.privateZusatzversicherungText` |
| `p_privatpatient` | bool | Patient: Privatpatient? | `patient.patientenDetails.privatPatient` |
| `p_schwerbehindertenausweisGueltigBis` | date | Patient: Schwerbehindertenausweis gültig bis | `patient.patientenDetails.schwerbehindertenausweis.gueltigBis` |
| `p_schwerbehindertenausweisGueltigVon` | date | Patient: Schwerbehindertenausweis gültig von | `patient.patientenDetails.schwerbehindertenausweis.gueltigVon` |
| `p_selbststaendig` | bool | Patient: Selbstständig | `patient.patientenDetails.selbststaendig` |
| `p_sitzend` | bool | Patient: überwiegend sitzende Tätigkeit? | `patient.patientenDetails.beschaeftigungsstatus.ueberwiegendSitzend` |
| `p_staatsangehoerigkeit` | string | Patient: Staatsangehörigkeit | `patient.patientenDetails.staatsangehoerigkeit` |
| `p_stationaereZusatzversicherung` | bool | Patient: stationäre Zusatzversicherung? | `patient.patientenDetails.stationaereZusatzversicherung` |
| `p_strasse` | string | Patient: Straße | `patient.patientenDetails.kontaktdaten.adresse.strasse` |
| `p_tel` | string | Patient: Telefonnummer | `patient.patientenDetails.kontaktdaten.telefon` |
| `p_titel` | string | Patient: Titel | `patient.titel` |
| `p_unfalldatum` | date | Patient: letztes Unfalldatum | `patient.patientenDetails.lastUnfalltag` |
| `p_unfallort` | string | Patient: letzter Unfallort | `patient.patientenDetails.lastUnfallort` |
| `p_vorname` | string | Patient: Vorname | `patient.vorname` |
| `p_willKeineSMS` | bool | Patient: Mit Fax/SMS nicht einverstanden. | `patient.patientenDetails.kontaktdaten.willKeineSMS` |
| `patientenInfo_pdfEncryptKey` | bool | PDF-Verschlüsselungscode in den Patientendetails in den Kontaktdaten gesetzt | – |

## Versicherung (gk_…, pk_…)

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `gk_ik` | string | GKV: 9-Digit-IK | `patient.patientenDetails.aktuelleGVKKartendaten.nineDigitIK` |
| `gk_kostentraeger` | string | GKV: Name des Kostenträgers | `patient.patientenDetails.aktuelleGVKKartendaten.abgeleiteterKostentraeger.kassenName` |
| `gk_name` | string | GKV: Name auf der Karte - gk_kostentraeger ist zuverlässiger! | `patient.patientenDetails.aktuelleGVKKartendaten.kassenname` |
| `gk_pversnr` | string | GKV-Versicherungsnummer | `patient.patientenDetails.aktuelleGVKKartendaten.versichertennummer` |
| `gk_status` | string | GKV: Status | `patient.patientenDetails.aktuelleGVKKartendaten.gkvStatus.code` |
| `pk_name` | string | PKV: Name | `patient.patientenDetails.aktuellePVKartendaten.privatkasse.kurzname` |
| `pk_register` | string | PKV: Registernummer | `patient.patientenDetails.aktuellePVKartendaten.privatkasse.registerNr` |
| `pk_versnr` | string | PKV-Versicherungsnummer | `patient.patientenDetails.aktuellePVKartendaten.versichertennummer` |

## Kontakte: Hausarzt, Facharzt/Überweiser, Folgearzt, Arbeitgeber, BG

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `ag_name` | string | Arbeitgeber: Name | `patient.patientenDetails.arbeitgeber.name` |
| `ag_ort` | string | Arbeitgeber: Ort | `patient.patientenDetails.arbeitgeber.kontaktdaten.adresse.ort` |
| `ag_plz` | string | Arbeitgeber: Postleitzahl | `patient.patientenDetails.arbeitgeber.kontaktdaten.adresse.plz` |
| `ag_strasse` | string | Arbeitgeber: Straße | `patient.patientenDetails.arbeitgeber.kontaktdaten.adresse.strasse` |
| `ag_tel` | string | Arbeitgeber: Telefonnummer | `patient.patientenDetails.arbeitgeber.kontaktdaten.telefon` |
| `bg_name` | string | Berufsgenossenschaft: Name | `patient.patientenDetails.arbeitgeber.berufsgenossenschaft.name` |
| `bg_ort` | string | Berufsgenossenschaft: Ort | `patient.patientenDetails.arbeitgeber.berufsgenossenschaft.kontaktdaten.adresse.ort` |
| `bg_plz` | string | Berufsgenossenschaft: Postleitzahl | `patient.patientenDetails.arbeitgeber.berufsgenossenschaft.kontaktdaten.adresse.plz` |
| `bg_strasse` | string | Berufsgenossenschaft: Straße | `patient.patientenDetails.arbeitgeber.berufsgenossenschaft.kontaktdaten.adresse.strasse` |
| `fachartz_tel` | string | Facharzt/Überweiser: Telefonnummer | `patient.patientenDetails.ueberweiser.praxiskontakt.telefon` |
| `facharzt_fax` | string | Facharzt/Überweiser: Fax | `patient.patientenDetails.ueberweiser.praxiskontakt.fax` |
| `facharzt_nachname` | string | Facharzt/Überweiser: Nachname | `patient.patientenDetails.ueberweiser.nachname` |
| `facharzt_ort` | string | Facharzt/Überweiser: Ort | `patient.patientenDetails.ueberweiser.praxiskontakt.adresse.ort` |
| `facharzt_plz` | string | Facharzt/Überweiser: Postleitzahl | `patient.patientenDetails.ueberweiser.praxiskontakt.adresse.plz` |
| `facharzt_strasse` | string | Facharzt/Überweiser: Strasse | `patient.patientenDetails.ueberweiser.praxiskontakt.adresse.strasse` |
| `facharzt_vorname` | string | Facharzt/Überweiser: Vorname | `patient.patientenDetails.ueberweiser.vorname` |
| `folgearzt_fax` | string | Folgearzt: Fax | `patient.patientenDetails.folgeArzt.praxiskontakt.fax` |
| `folgearzt_nachname` | string | Folgearzt: Nachname | `patient.patientenDetails.folgeArzt.nachname` |
| `folgearzt_ort` | string | Folgearzt: Ort | `patient.patientenDetails.folgeArzt.praxiskontakt.adresse.ort` |
| `folgearzt_plz` | string | Folgearzt: Postleitzahl | `patient.patientenDetails.folgeArzt.praxiskontakt.adresse.plz` |
| `folgearzt_strasse` | string | Folgearzt: Strasse | `patient.patientenDetails.folgeArzt.praxiskontakt.adresse.strasse` |
| `folgearzt_tel` | string | Folgearzt: Telefonnummer | `patient.patientenDetails.folgeArzt.praxiskontakt.telefon` |
| `folgearzt_vorname` | string | Folgearzt: Vorname | `patient.patientenDetails.folgeArzt.vorname` |
| `hausarzt_fax` | string | Hausarzt: Fax | `patient.patientenDetails.hausarzt.praxiskontakt.fax` |
| `hausarzt_nachname` | string | Hausarzt: Nachname | `patient.patientenDetails.hausarzt.nachname` |
| `hausarzt_ort` | string | Hausarzt: Ort | `patient.patientenDetails.hausarzt.praxiskontakt.adresse.ort` |
| `hausarzt_plz` | string | Hausarzt: Postleitzahl | `patient.patientenDetails.hausarzt.praxiskontakt.adresse.plz` |
| `hausarzt_strasse` | string | Hausarzt: Strasse | `patient.patientenDetails.hausarzt.praxiskontakt.adresse.strasse` |
| `hausarzt_tel` | string | Hausarzt: Telefonnummer | `patient.patientenDetails.hausarzt.praxiskontakt.telefon` |
| `hausarzt_vorname` | string | Hausarzt: Vorname | `patient.patientenDetails.hausarzt.vorname` |

## Homöopathie-Vertrag (hom_…)

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `hom_aktivoderoffen` | integer | Homöopathie: wahr wenn aktiv oder offene Scheine | `patient.patientenDetails.homoeoTeilnahme.aktivOderOffeneScheine` |
| `hom_bestaetigt` | string | Homöopathie: wann die übermittelte Teilnahmeerklärung bestätigt wurde | `patient.patientenDetails.homoeoTeilnahme.datumBestaetigt` |
| `hom_erstanamnese` | string | Homöopathie: wann die Erstanamnese erfolgte | `patient.patientenDetails.homoeoTeilnahme.datumErstanamnese` |
| `hom_uebermittelt` | string | Homöopathie: wann die unterschriebene Teilnahmeerklärung übermittelt wurde | `patient.patientenDetails.homoeoTeilnahme.datumUebermittelt` |
| `hom_unterschrieben` | string | Homöopathie: wann die Teilnahmeerklärung unterschrieben wurde | `patient.patientenDetails.homoeoTeilnahme.datumUnterschrieben` |
| `hom_vz1` | date | Homöopathie: Versorgungszyklus Eins (Leistungszeitraum von) | `patient.patientenDetails.homoeoTeilnahme.versorgungszyklus1` |
| `hom_vz2` | date | Homöopathie: Versorgungszyklus Zwei (Leistungszeitraum bis) | `patient.patientenDetails.homoeoTeilnahme.versorgungszyklus2` |
| `hom_vz3` | date | Homöopathie: Versorgungszyklus Drei (Vergütungsfrei von) | `patient.patientenDetails.homoeoTeilnahme.versorgungszyklus3` |
| `hom_vz4` | date | Homöopathie: Versorgungszyklus Vier (Vergütungsfrei bis) | `patient.patientenDetails.homoeoTeilnahme.versorgungszyklus4` |

## Schwangerschaft

| Variable | Datentyp | Beschreibung | Ausdruck |
|---|---|---|---|
| `entbindung` | date | Datum der Entbindung | `patient.patientenDetails.schwangerschaftsdetails.geburtstermin` |
| `zyklusdauer` | integer | Zyklusdauer | `patient.patientenDetails.schwangerschaftsdetails.zyklusdauer` |

## Quelltext der vordefinierten Funktionen

tomedo stellt diese Definitionen dem Skript voran. `datetime` ist damit ohne `import` verfügbar.

### `heuteDatum`

```python
heuteDatum = datetime.datetime.strftime(datetime.datetime.now(),'%d.%m.%Y')
```

### `heuteQuartal`

```python
heuteQuartal = datetime.datetime.now().year + 0.25*int((datetime.datetime.now().month-1)/3)
```

### `jahre`

```python
def jahre(string_date):
	born = datetime.datetime.strptime(string_date,'%d.%m.%Y')
	today = datetime.date.today()
	return today.year - born.year - ((today.month, today.day) < (born.month, born.day))
```

### `mutterschutz`

```python
def mutterschutz(date_string):
	aux = datetime.datetime.strptime(date_string,'%d.%m.%Y') - datetime.timedelta(days=42)
	return aux.strftime('%d.%m.%Y')
```

### `schwangerschaftstage`

```python
def schwangerschaftstage(date_string, dauer_int):
	today = datetime.datetime.now()
	geburt = datetime.datetime.strptime(date_string,'%d.%m.%Y')
	dauer = 280
	if int(dauer_int) > 0:
		dauer = dauer + int(dauer_int) - 28
	dt = geburt - today
	return dauer - dt.days
```

### `select`

```python
def select(array, startDatum = '', endDatum = '', startQuartal = 0, endQuartal = 0):
	if(startDatum != '' and endDatum != ''):
		return [e for e in array if ((datetime.datetime.strptime(endDatum,'%d.%m.%Y') >= datetime.datetime.strptime(e['datum'],'%d.%m.%Y')) and (datetime.datetime.strptime(startDatum,'%d.%m.%Y') <= datetime.datetime.strptime(e['datum'],'%d.%m.%Y')))]
	if(startQuartal != 0 and endQuartal != 0):
		return [e for e in array if ((endQuartal >= (e['jahr']+0.25*(e['quartal']-1))) and (startQuartal <= (e['jahr']+0.25*(e['quartal']-1))))]
	return array
```
