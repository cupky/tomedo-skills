# Vollständiger Katalog der Aktionstypen in tomedo Aktionsketten

Extrahiert aus der tomedo-Oberfläche (Admin → Aktionsketten → Aktionsketten → +Aktion).
Stand: März 2026. Die Liste wird kontinuierlich durch zollsoft erweitert.

Jede Aktion hat bis zu 4 Spalten: **Typ**, **Wert**, **Vorbefüllung**, **Konfiguration**.
Die verfügbaren Optionen in Wert/Vorbefüllung/Konfiguration hängen vom gewählten Typ ab.

---

## Kategorie: Abrechnung (Submenu)

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Abrechnungs-Tab | – | – | – | Öffnet den Abrechnungsreiter |
| BG-Facharztrechnung | – | – | – | Berufsgenossenschaft |
| EBM-Ziffer anlegen | Favorit (z.B. 03360) | – | Häkchen-Modus + Anlage-Modus | Wert = EBM-Leistungsfavorit. Konfiguration hat 2 Dropdowns: (1) Häkchen in Auswahlfenster automatisch setzen / nicht setzen (2) Immer anlegen / nur wenn heute nicht vorhanden / nur wenn auf Schein/Rechnung nicht vorhanden |
| EBM-Ziffer löschen | Favorit | – | – | Entfernt eine EBM-Ziffer |
| GOÄ-Ziffer anlegen | Favorit | – | analog EBM | Privatabrechnung |
| GOÄ-Ziffer löschen | Favorit | – | – | |
| Hybrid-DRG-Fall anlegen | – | – | – | HDRG-Modul |
| HZV-Ziffer anlegen | Favorit | – | – | Hausarztzentrierte Versorgung |
| KV-Schein anlegen | – | – | – | Legt GKV-Schein an |
| KV-Schein löschen (nur wenn ohne Ziffern) | – | – | – | Sicherheitscheck eingebaut |
| Privatrechnung anlegen | Rechnungstyp-Favorit (links) | Rechnungsvorlage (rechts) | – | Wert-Dropdown: praxisspezifische Rechnungstypen (z.B. BA Arbeitsamt, Privatrechnung, Kostenvoranschlag...). Vorbefüllung-Dropdown: Rechnungsvorlagen (z.B. Privat-Osteopathie, Zuzahlung-Physio...) |
| Privatrechnung drucken | – | – | – | |
| Sachkosten | – | – | – | GOÄ-Sachkosten |
| UVGOÄ-Ziffer anlegen | Favorit | – | – | Unfallversicherung |
| via OPS | – | – | – | OPS-basierte Anlage |

### Detail: EBM-Ziffer anlegen — Konfiguration

Konfiguration besteht aus **zwei separaten Dropdowns**:

**Dropdown 1 — Häkchen-Modus:**
- `Häkchen in Auswahlfenster automatisch setzen` — Ziffer wird im Auswahlfenster vorausgewählt
- `Häkchen in Auswahlfenster nicht setzen` — Nutzer muss manuell bestätigen

**Dropdown 2 — Anlage-Modus:**
- `Immer anlegen` — Duplikate möglich
- `Anlage nur wenn am heutigen Tag nicht vorhanden` — Duplikatschutz pro Tag
- `Anlage nur wenn auf Schein/Rechnung nicht vorhanden` — Duplikatschutz pro Schein

**Praxis-Tipp:** Für automatisierte Workflows (z.B. via Auslöser bei Besuchsanlage) empfiehlt sich "Häkchen automatisch setzen" + "Anlage nur wenn auf Schein nicht vorhanden", um Doppelabrechnung zu vermeiden.

### Detail: Privatrechnung anlegen — Wert und Vorbefüllung

**Wert (linkes Dropdown)** = Rechnungstyp-Favoriten. Praxisspezifisch konfiguriert, z.B.:
- BA Arbeitsamt, BA Deutsche Rentenversicherung, BA Sozialamt
- Blutegeltherapie, Sozialgericht
- (weitere praxisspezifische Typen)

**Vorbefüllung (rechtes Dropdown)** = Rechnungsvorlagen. Praxisspezifisch, z.B.:
- BA Sozialgericht DD, Deutsche Rentenversicherung
- Kostenvoranschlag
- Privat-Osteopathie, Privat-Physio
- Privat-Physiotherapie-mitDiagnose, Privat-Physiotherapie-ohneDiagnose
- Privatrechnung, Sozialamt, Zuzahlung-Physio

**Praxis-Tipp:** Für automatisierte behandlerabhängige Privatrechnungen: Haupt-Aktionskette mit Aktionskettenbedingungen pro Behandler, die jeweils eine Unter-Aktionskette mit dem passenden Rechnungstyp starten. Siehe Rezeptbuch → Automatische Privatrechnung.

---

## Kategorie: eDoku (Submenu)

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| DMP anlegen | – | – | – | Disease-Management-Programm |
| FEK anlegen | – | – | – | Früherkennungsuntersuchung |
| HKS anlegen | – | – | – | Hautkrebsscreening |
| Krebsregistermeldung | – | – | – | Onkologie-Modul |
| oKFE anlegen | – | – | – | Organisierte Krebsfrüherkennung |

---

## Kategorie: ToDo (Submenu)

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Nächstes ToDo | – | – | – | Verschiebt zum nächsten ToDo-Schritt |
| ToDo anlegen | ToDo-Typ | – | – | Legt ein ToDo in der Tagesliste an |
| ToDo verschieben | Ziel-ToDo | – | – | Verschiebt aktuelles ToDo |
| ToDoKette anlegen | – | – | – | Legt eine ToDo-Kette an |

**Praxis-Tipp:** ToDo-Aktionen sind zentral für Workflow-Steuerung. Ein häufiges Pattern: Auslöser = ToDo-Verschiebung → Aktionskette mit Karteieintrag + Leistung. ToDos sind auch Auslöser-Objekte (siehe Auslöser-Referenz).

---

## Einzelaktionen (ohne Submenu)

### Steuerung & Verzweigung

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Aktionskettenbedingung | Bedingungsname | – | Aktionskette + Reihenfolge | Wert = Auswahl der Bedingung. Konfiguration: (1) Auszuführende Aktionskette bei Erfüllung (2) Reihenfolge: "Warteschlange Platz 1" vs "aktive Kette abbrechen". KERNBAUSTEIN für bedingte Logik. |
| Aktionskettenfrage | Fragename | – | – | Zeigt Entscheidungsdialog. Jede Antwort löst eigene Aktionskette aus. |
| Hinweisfenster | Text | – | – | Zeigt Popup mit Info-Text. Blockierend. |
| Info | Text | – | – | Zeigt Information an |

### Dokumentation & Kartei

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Karteieintrag anlegen | KE-Typ (z.B. ANA, BEF) | Kommando/Text | zeige kein Popover u.a. | Wert = Karteieintragtyp. Vorbefüllung = Text oder Briefkommandos (z.B. Textbausteine). Konfiguration: ob Popover gezeigt wird oder KE direkt angelegt wird. **Blockierende Aktion.** |
| Karteieintrag öffnen | KE-Typ | – | – | Öffnet letzten KE dieses Typs. **Nicht-blockierende Aktion** (Achtung bei Reihenfolge!) |
| Karteidatum setzen | Datum | – | – | Setzt das Karteidatum |
| CAVE erstellen | – | – | – | Erstellt CAVE-Eintrag (Achtung/Warnung) |
| Org. CAVE erstellen | – | – | – | Organisatorischer CAVE |
| Diagnose | ICD-Favorit | – | – | Legt Diagnose an (aus Favoriten) |
| Diagnose Übernahmefenster | – | – | – | Öffnet Diagnose-Übernahme |
| Diagnose via Favoritenname | Favoritenname | – | – | Alternative Diagnose-Anlage |
| Vitalwerte | – | – | – | Öffnet Vitalwerte-Erfassung |
| Formular | Formularname | – | – | Öffnet ein Formular |
| BMP öffnen | – | – | – | Bundeseinheitlicher Medikationsplan |
| Medikament | – | – | – | Medikamentenverordnung |
| Marker | Markername | – | – | Setzt einen Patienten-Marker |

### Kommunikation

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Nachricht | Nachrichtenvorlage | – | – | Interne tomedo-Nachricht (erfordert Vorlage!) |
| Aufgabe | Aufgabenvorlage | – | – | Interne Aufgabe (erfordert Vorlage!) |
| Patientenaufgaben anzeigen | – | – | – | Zeigt Aufgaben des Patienten |
| Brief | Briefvorlage | – | – | Erstellt Brief aus Vorlage |
| E-Mail aus Vorlage | E-Mail-Vorlage | – | – | Versendet E-Mail |
| E-Mail aus Versandprofil | Versandprofil | – | – | E-Mail via Profil |
| ArztDirekt Nachricht | – | – | – | Messenger-Nachricht |
| SMS | – | – | – | SMS an Patient |

### Termin & Kalender

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Terminsuche (Definiert) | Terminsuche-Konfig | – | – | Öffnet definierte Terminsuche. **Blockierende Aktion.** |
| Terminsuche (Kette) | Kettenterminsuche | – | – | Kettenterminsuche |
| Sprechstundenassistent | – | – | – | Öffnet Sprechstundenassistenten |

⚠ **Negativbefund (geprueft 07/2026): keine dieser drei Aktionen schreibt.** Alle drei sind
interaktiv (oeffnen ein Fenster, warten auf den Nutzer). Es gibt in der gesamten Kategorie
**kein** „Termin anlegen", **kein** „Sperrtag", **kein** „Urlaubstag", **keine** Ganztagsart.

Konsequenz: Sperrtage und Termine sind **nicht** per Aktionskette erzeugbar — auch nicht
mittelbar ueber `call aktionskette`. Wer Ganztags-Abwesenheiten programmatisch setzen will,
braucht den Weg ueber das Arbeitszeitkonto (ArZeKo → nativer tomedo-Sync); ein Sperrtag, der
direkt im Kalender gesetzt wird, verbucht **keinen** Urlaubsanspruch und reduziert **keine**
Sollzeit. Lesend: `terminkalendertag.sperrmodus = 1` (Skill `tomedo-statistik-hql`).

**Baubar sind dagegen** `Aufgabe` (aus Aufgabenvorlage — der Standard-Meldekanal),
`Nachricht` (Nachrichtenvorlage), `ToDo anlegen` (Tagesliste) und `AppleScript` (laeuft *nach*
der Aktion, nicht gleichzeitig).

### Workflow & Navigation

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Abrechner des Besuchs setzen | Nutzer | – | – | Setzt den abrechnenden Arzt |
| Warteschlangenaufruf | – | – | – | Ruft Patient aus Warteschlange |
| Zurückschreiben | Zielfeld | Wert/Kommando | – | Schreibt Wert in Besuchs-/Patientenfelder. Zielfelder: Besuch Info/Bool1-4/String1-2/KV-Fall/BG-Fall/Privat-Fall/Wichtig, Patient Info/Bool1-2/String1-4, KarteiEintrag (aktuellsten) |

### Patientenlisten & DICOM

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Patient zu Patientenliste hinzufügen | Listenname | – | – | |
| Patient von Patientenliste löschen | Listenname | – | – | |
| Patient zu DICOMWorklist hinzufügen | – | – | – | Radiologie/Bildgebung |
| Patient von DICOMWorklist löschen | – | – | – | |
| Zugriffsrecht für Patient setzen | – | – | – | Datenschutz |

### Schnittstellen & Sonstiges

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| AppleScript | Script-Text | – | – | Führt macOS-Script aus. Wird NACH der Aktion ausgeführt (nicht gleichzeitig!) |
| GDT | – | – | – | Gerätedatentransfer |
| Intellimago | – | – | – | Bildgebungs-Integration |
| Order Entry | – | – | – | Laboraufträge |
| TI-Verbindung aufbauen | – | – | – | Telematikinfrastruktur |
| TI-Verbindung abbauen | – | – | – | |
| Früherkennung abrechnen | – | – | – | |

---

## Wichtige Verhaltenseigenschaften

### Blockierende vs. nicht-blockierende Aktionen

**Blockierend** (wartet auf Nutzerinteraktion/OK bevor nächste Aktion startet):
- Karteieintrag anlegen (mit Popover)
- Terminsuche (Definiert)
- Terminsuche (Kette)
- Aktionskettenfrage
- Hinweisfenster

**Nicht-blockierend** (nächste Aktion startet sofort):
- Karteieintrag öffnen
- BMI/BIO-Karteieinträge (Zwitter: blockiert bei Eingabe, nicht bei Perzentil-Öffnung)

**Praxis-Konsequenz:** Bei nicht-blockierenden Aktionen kann die Folgeaktion die aktuelle "überholen". Workaround: Jede Aktion als separate Aktionskette starten und über Aktionskettenbedingung sequenziell verketten.

### Vorlagen-Abhängigkeiten

Viele Aktionen greifen auf **Vorlagen/Favoriten** zurück, die VOR der Aktionsketten-Konfiguration erstellt werden müssen:
- EBM/GOÄ-Ziffern → Leistungsfavoriten
- Diagnosen → Diagnosefavoriten
- Aufgaben → Aufgabenvorlagen
- Nachrichten → Nachrichtenvorlagen
- Briefe → Briefvorlagen
- E-Mails → E-Mail-Vorlagen / Versandprofile
- Privatrechnungen → Rechnungstypen + Rechnungsvorlagen

### Aktionsketten-Grundstruktur (UI)

```
Verwaltung Aktionsketten
├── Kürzel: [eindeutiges Kürzel]
├── Name: [beschreibender Name]
├── Aktionsliste (Tabelle):
│   ├── Zeile 1: Typ | Wert | Vorbefüllung | Konfiguration
│   ├── Zeile 2: ...
│   └── [+ Aktion] Button unten
├── Leistungen, Diagnosen, etc. (aus Favoriten) — linke Spalte
├── Sichtbarkeit:
│   ├── ☐ auswählbar in Kommandozeile der Kartei
│   └── ☐ auswählbar im Termin-Popover
├── [Zeige Verlauf] Checkbox
├── [Kopie] Button — kopiert selektierte Aktionen in Zwischenspeicher
└── Rechtsklick → zeigt Verwendung in Auslösern/Fragen/anderen Ketten
```

### Reihenfolge und Kopieren

- Aktionen werden **in Tabellenreihenfolge** abgearbeitet (top → bottom)
- Reihenfolge per **Drag & Drop** änderbar
- **Kopie-Button**: Selektierte Aktionen in Zwischenspeicher → in andere Kette einfügen
- **Rechtsklick** auf Kette → zeigt alle Auslöser, Fragen und anderen Ketten, die diese Kette verwenden
