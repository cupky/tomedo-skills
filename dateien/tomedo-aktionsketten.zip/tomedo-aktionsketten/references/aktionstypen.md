# Vollständiger Katalog der Aktionstypen in tomedo-Aktionsketten

Admin → Aktionsketten → Aktionsketten, Fenster „Aktionskettenverwaltung“, Knopf **Aktion**.
Stand: 22.10.2026.
Die Liste wird von zollsoft laufend erweitert.

**Kennzeichnung:** ohne Zusatz = belegt · **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor
dem Einsatz an einer Testakte prüfen · **[Messung]** = an der Referenzinstallation beobachtet.

Jeder Schritt hat die Spalten **Typ · Wert · Vorbefüllung · Konfiguration**; was darin wählbar ist,
hängt vom Typ ab. **Ablauf:** *blockierend* = der nächste Schritt startet erst, wenn das Fenster bzw. der
Dialog geschlossen ist · *wartet* = auf einen Vorgang ohne Nutzer · *sofort* = nächster Schritt sofort,
ein Fenster bleibt evtl. offen.

---

## Aufbau der Kette

```
Aktionskettenverwaltung
├── Links: Baum (Element · Gruppe · Kopie · − · A..Z↓ · Suche mit Filter Kürzel/Name/Eintrag-Typ/-Name)
│   └── Rechtsklick: wo die Kette verwendet wird (Ketten, Auslöser, Fragen) – springt dorthin
│
├── Kürzel · Name
├── ☑ Zeige Verlauf                              (Standard an)
├── Bild (Drag & Drop)                           → Symbol des Symbolleisten-Knopfs
├── ☐ auswählbar im Termin-Popover
├── ☑ auswählbar in Kommandozeile der Kartei
├── ☐ gelöscht
└── Schritt-Tabelle „Leistungen, Diagnosen, etc. (aus Favoriten)“
    ├── Typ | Wert | Vorbefüllung | Konfiguration
    ├── [Aktion] (fügt hinter der Auswahl ein) · [−] · [Kopie] (dupliziert in derselben Kette)
    └── Rechtsklick: „selektierte Zeilen in Zwischenspeicher kopieren“ /
                     „Zeilen … aus Zwischenspeicher einsetzen“ (auch in andere Ketten)
```

| Option | Wirkung |
|---|---|
| **Kürzel** | Aufrufschlüssel (Kommandozeile, Symbolleiste, AppleScript, URL). Kein Leerzeichen, kein Komma („Bitte verwenden Sie stattdessen Unterstriche!“). Warnung, wenn das Kürzel schon bei einem Karteieintragstyp, Formulartyp oder einer anderen Kette vorkommt. |
| **Name** | Titel des Verlaufsfensters, Tooltip in der Symbolleiste |
| **Zeige Verlauf** | Schwebendes Verlaufsfenster mit Schritten, wartenden Ketten und **Abbrechen**. Ohne Verlauf ist der Abbruch nur über das Symbolleistensymbol „akt. Aktionskette“ des Hauptfensters erreichbar. Beim KI-Prompt hängt der Datenschutz-Dialog an diesem Fenster. |
| **Bild** | nur Symbol des Symbolleisten-Knopfs |
| **auswählbar im Termin-Popover** | Kette erscheint als Symbol im Termin-Popover; Gruppen als Untermenü |
| **auswählbar in Kommandozeile der Kartei** | Kette erscheint als Vorschlag in der Kommandozeile |
| **Symbolleiste** | **Jede** sichtbare Kette (keine Gruppe) steht in der Symbolleisten-Anpassung zur Verfügung; eigene Option gibt es nicht. Ohne Patient: „Es ist kein Patient ausgewählt.“ |
| **Kopie** (Baum) | kopiert die Kette mit allen Schritten, ohne Kürzel |
| **Gruppe** | Ordner; nicht ausführbar. Löschen einer Gruppe löscht ihre Einträge. |

Einen **Hintergrundmodus** gibt es nicht: Jede Kette läuft im Programm des Arbeitsplatzes mit ihren Fenstern.

---

## Das Menü „Aktion“

Sieben Untermenüs — **Abrechnung · Aktionskette · Besuch · eDoku · Kartei · Nachricht · Panel** — und
Einträge ohne Untermenü; alles alphabetisch. **Ein Untermenü „ToDo“ gibt es nicht**, die ToDo-Aktionen
liegen unter **Besuch**. Im deutschen Standardmenü stehen **77 Typen** (+1 per Systemeinstellung).
Österreich, Schweiz und Zahnarzt sehen andere Abrechnungstypen (Abschnitt „Andere Installationsarten“).

---

## Untermenü Kartei

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Ablauf, Hinweise |
|---|---|---|---|---|
| **Karteieintrag anlegen** | KE-Typ (ohne Formular- und Brieftypen) | Text mit Briefkommandos (bei Text, Bild, Labor) bzw. Favorit (Allergie) | ☐ „Lege Karteieintrag direkt an (zeige kein Popover)“ — nur bei Text, Bild, Labor, CKE, OP | Mit Popover **blockierend**. Direkt: ohne Dialog. CKE: keine Vorbefüllung. Fortlaufende Tabelle/Marcumar: bestehender Eintrag wird erweitert. |
| **Karteieintrag öffnen** | KE-Typ | – | – | Öffnet den **jüngsten** Eintrag dieses Typs im Popover. Kein Eintrag → Meldung, weiter. Zum Ablauf siehe „Blockierend oder nicht“. |
| **Karteieintrag löschen** | KE-Typ | – | „Eintragsdatum (Tage)“ von/bis, relativ zu heute (0 = heute, −7 = vor einer Woche) | Löscht (weich) alle Einträge **und Formulare** des Typs im Zeitraum, mit Rechteprüfung. **Beide Felder leer → es wird nichts gelöscht.** |
| **Formular** | Formulartyp | Formular-Vorlage | „nichts“ / „Drucke Formular sofort“ / „Speichere Formular sofort“ (bei Handoff-Typ „immer“: Handoff) | „nichts“: Formularfenster, **blockierend**. Drucken/Speichern: ohne Fenster, sofort. |
| **Formular löschen** | Formulartyp | – | Eintragsdatum (Tage) von/bis | wie Karteieintrag löschen |
| **Brief** | Briefvorlage | – | „Brief-schreiben-Fenster öffnen“ / „Sofort drucken“ / „Sofort speichern“ | **Blockierend**. Sofort-Optionen funktionieren nur bei Vorlagen mit „Empfängertyp für Vorlage merken“. |
| **Karteidatum setzen** | Datum, Briefkommando möglich (`TT.MM.JJ`, `TT.MM.JJJJ`, optional Uhrzeit) | – | – | Leer oder unlesbar → **keine Änderung, keine Meldung**. Vor 1901 / nach 2100 → Meldung. |
| **Diagnose** | Diagnose-Favorit(en) | – | ☐ „Häkchen in Auswahlfenster automatisch setzen“ · ☐ „Diagnose auch in Kartei“ | Wird mit benachbarten Favoriten-Schritten zu **einem** Auswahlfenster gebündelt, **blockierend**. |
| **Diagnose via Favoritenname** | Favoritenname, Briefkommando möglich | – | – | Legt die Diagnose **ohne Fenster** an, inklusive Kartei. Kein Treffer → Meldung. |
| **Diagnose Übernahmefenster** | – | – | – | Dauerdiagnosen-Übernahme für den gewählten Schein, **blockierend** |
| **Medikament** | Hausapotheken-Element | – | – | Aufeinanderfolgende Medikament-Schritte → **ein** Verordnungsfenster, **blockierend** |
| **CAVE erstellen** | – | Text (Briefkommandos) | – | legt Karteieintrag CAVE direkt an |
| **Org. CAVE erstellen** | – | Text (Briefkommandos) | – | legt eine Org.-CAVE beim Patienten an |

## Untermenü Nachricht

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Ablauf, Hinweise |
|---|---|---|---|---|
| **E-Mail aus Vorlage** | E-Mail-Vorlage | – | E-Mail-Konto (E-Mail oder KIM); bei KIM Empfänger: Keine Vorbelegung / Hausarzt / Facharzt / Folgearzt (Patienteninfos) / Überweiser / Weiterbehandler (aus Schein des Quartals) / Briefkommando | Versand **ohne Dialog**, wenn E-Mail-Versand für den Patienten zulässig. Termine einer vorherigen Terminsuche werden mitgegeben. *wartet* |
| **E-Mail aus Versandprofil** | Versandprofil | – | wie oben | Versand nach Profil, inkl. markierter Karteieinträge |
| **Hinweisfenster** | Text (mehrzeilig, Briefkommandos, Links klickbar) | – | – | Dialog mit OK, **blockierend**. Im Kiosk-Modus unterdrückt. |
| **Info** | Text | – | – | Meldung, *sofort* |
| **Nachricht** | Nachrichten-Favorit | – | ☐ „Lege Nachricht direkt an“ | Direkt: ohne Fenster (Favorit braucht Empfänger und Text). Sonst Fenster, **blockierend**. |
| **SMS** | SMS-Vorlage | – | – | SMS-Fenster, *sofort* |
| **ArztDirekt Nachricht** | – | Nachrichtentext (Briefkommandos) | ☐ „Lege Nachricht direkt an“ | Nur wenn der Patient arzt-direkt-Kontakt akzeptiert, sonst still übersprungen. Ohne „direkt“: Chatfenster, **blockierend**. |

## Untermenü Aktionskette

| Aktionstyp | Wert | Konfiguration | Ablauf |
|---|---|---|---|
| **Aktionskette** | – | Ziel-Kette + 4 Warteschlangen-Optionen | Reiht die Ziel-Kette ein (Unterkette) |
| **Aktionskettenbedingung** | Bedingung | Ziel-Kette + 4 Warteschlangen-Optionen | Bedingung **erfüllt → Ziel-Kette einreihen; nicht erfüllt → nichts, die Kette läuft weiter.** Kein Sonst-Zweig, kein Abbruch. Die Bedingung sieht auch Karteieinträge und Formulare, die diese Kette gerade angelegt hat. |
| **Aktionskettenfrage** | Frage | 4 Warteschlangen-Optionen | Dialog **blockierend**; die gewählten Antwort-Ketten werden eingereiht |

**Die vier Warteschlangen-Optionen** (bei allen drei Typen):

| Option | Wirkung |
|---|---|
| (keine) | Ziel-Kette ans **Ende der Warteschlange** — sie läuft erst, wenn die aktuelle Kette **ganz fertig** ist |
| **Kette wird eingeschoben** | Die aktuelle Kette wird hier geteilt: Ziel-Kette läuft **sofort**, danach der Rest als „… (Teil 2)“. Sperrt die drei anderen. |
| **Kette kommt in Warteschlange auf Platz 1** | Ziel-Kette läuft direkt nach dem Ende der aktuellen Kette, vor anderen wartenden |
| **Kette wird nur einmal in Warteschlange gesetzt** | nicht einreihen, wenn sie schon wartet (laufende oder gelaufene zählen nicht) |
| **Aktive Kette wird abgebrochen und danach die Warteschlange abgearbeitet** | die restlichen Schritte der aktuellen Kette entfallen |

„Platz 1“ und „Aktive Kette abbrechen“ lassen sich kombinieren.

## Untermenü Besuch (enthält die ToDo-Aktionen)

| Aktionstyp | Wert | Konfiguration | Ablauf, Hinweise |
|---|---|---|---|
| **ToDoKette anlegen** | ToDo-Kette | ☐ „ToDo(s) an den Anfang der anstehenden ToDos“ | ohne echten Besuch → Meldung |
| **ToDo anlegen** | ToDo-Vorlage | wie oben | |
| **ToDo weiterschalten (Nächstes ToDo)** | ToDo-Vorlage (optional) | – | Beendet das aktuelle ToDo, startet das nächste anstehende; gibt es keins, wird das **Besuchsende gesetzt**. Mit Vorlage nur, wenn das aktuelle ToDo diese Vorlage hat. |
| **ToDo verschieben** | ToDo-Vorlage | Aktion: anstehend → aktuell (Raum konfigurieren) · anstehend → aktuell (Raum wird nachgefragt) · anstehend → abgearbeitet · aktuell oder anstehend → abgearbeitet · aktuell → abgearbeitet · aktuell → anstehend; bei „→ aktuell“ zusätzlich, was mit dem bisherigen aktuellen ToDo geschieht | Raumabfrage kann einen Dialog öffnen; belegter Einzelraum → Rückfrage |
| **Raum setzen (Auswahl)** | Raum | – | setzt den Raum des **aktuellen** ToDos; sonst „Kein aktuelles ToDo.“ |
| **Raum setzen (Kürzel)** | Raumkürzel, Briefkommando möglich | – | Groß-/Kleinschreibung egal |
| **Abrechner setzen (Kürzel)** | Nutzerkürzel, Briefkommando möglich | Nur setzen wenn kein Abrechner · Aktuellen Abrechner ersetzen · Als zusätzlicher Abrechner hinzufügen · Als Haupt-Abrechner hinzufügen · Nachfrage wenn kein Abrechner · Nachfragen für zusätzlichen Abrechner · Nachfragen für Haupt-Abrechner | Nutzer muss Leistungserbringer sein. Nachfrage-Modi: Dialog, **blockierend**. |
| **Abrechner setzen (Auswahl)** | Nutzer | wie oben | |

## Untermenü Abrechnung (Deutschland)

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Ablauf, Hinweise |
|---|---|---|---|---|
| **EBM-Ziffer anlegen** | EBM-Favorit | – | Popup 1: Häkchen automatisch setzen / nicht setzen · Popup 2: Immer anlegen / nur wenn am heutigen Tag nicht vorhanden / nur wenn auf Schein/Rechnung nicht vorhanden | **Immer über das Auswahlfenster**, „direkt übernehmen“ gibt es für EBM nicht. **Neue EBM-Schritte stehen auf „nicht setzen“.** |
| **EBM-Ziffer aus Code anlegen** | Code (Briefkommando möglich) | – | „Anzahl:“ | Braucht einen ausgewählten, nicht abgerechneten KV-Schein. Fragt **jedes Mal** „EBM Ziffer anlegen?“, **blockierend**. |
| **EBM-Ziffer löschen** | EBM-Katalogsuche oder ☑ Regex („Regex für EBM-Code“, ganzer Code) | – | ☐ „offener Schein“ oder „Quartal von/bis“ relativ (0 = dieses, −1 = Vorquartal) | weiches Löschen in nicht abgerechneten Scheinen |
| **GOÄ-Ziffer anlegen** | GOÄ-Favorit | – | Popup 1 zusätzlich „**Leistung direkt auf Schein/Rechnung übernehmen**“ · Popup 2 wie EBM | Direkt: ohne Fenster, wenn der Typ zum Schein passt |
| **GOÄ-Ziffer aus Code anlegen** | Code | – | „Anzahl:“, „Begründung:“, „Steigerungsfaktor:“, „Einzelkosten in Cent:“ (je Briefkommando möglich; Faktor und Kosten zugleich → Kosten gewinnen) | Braucht eine ausgewählte, nicht abgerechnete Privatrechnung. **Ohne** Rückfrage. |
| **GOÄ-Ziffer löschen** | GOÄ-Katalogsuche oder Regex | – | ☐ „offene Rechnung“; Rechnungsdatum (Tage) von/bis; **Leistungsdatum (Tage) von/bis — beide leer → nichts gelöscht** | weiches Löschen |
| **UVGOÄ-Ziffer anlegen** | UVGOÄ-Favorit | – | Popup 1 (2 Optionen) + Popup 2 | Auswahlfenster |
| **HZV-Ziffer anlegen** | HZV-Favorit | – | Popup 1 (2) + Popup 2 | |
| **Sachkosten** | Sachkosten-Vorlage | – | Popup 1 inkl. „direkt“ + Popup 2 | |
| **KV-Schein anlegen** | KV-Schein-Vorlage (optional) | – | – | Mit Vorlage wird ein offener Schein des Quartals mit gleichem IK **wiederverwendet** (außer „Doppelanlage erlauben“ in der Vorlage). **Fehlt dem Nutzer das Recht, KV-Scheine anzulegen, startet die ganze Kette nicht.** |
| **KV-Schein löschen (nur wenn ohne Ziffern)** | – | – | „Quartal von/bis“ (relativ) | nur nicht abgerechnete Scheine ohne sichtbare EBM-Leistung |
| **Privatrechnung anlegen** | Rechnungstyp | Rechnungsmuster | – | Mit Typ oder Muster: Rechnung direkt angelegt und ausgewählt. Ohne beides: Fenster „Neue Rechnung“, **blockierend**. |
| **Privatrechnung drucken** | – | – | – | nur bei geöffneter Privatabrechnung |
| **Abrechnungs-Tab** | Tab: GKV / Privat / BG / SV / HDRG (mit DRG-Modul) | – | GKV → Scheingruppe · Privat → Rechnungstyp · SV → Honoraranlage; ☐ „Keine Rechnung/keinen Schein selektieren, wenn … nicht vorhanden“ | Wechselt den Tab und wählt Schein bzw. Rechnung; mehrere passende → Auswahldialog |
| **BG-Facharztrechnung** | BG-Rechnungstyp | BG-Muster (wird bei der Ausführung **nicht** verwendet) | – | nur mit Modul BG-Facharztverfahren |
| **Hybrid-DRG-Fall anlegen** | DRG-Fallvorlage | – | – | |
| **via OPS** | – | OPS-Text (Briefkommandos) | – | nur mit ausgewähltem KV-Schein; OPS-Browser, **blockierend** |

**Favoriten-Bündelung:** Aufeinanderfolgende Leistungs- und Diagnose-Favoriten-Schritte erscheinen in
**einem** Auswahlfenster. Schritte mit „direkt übernehmen“ laufen einzeln ohne Fenster. Gelöschte Favoriten
→ Meldung, übersprungen. Passt der Favorit nicht zum gewählten Schein oder ist der Schein abgerechnet →
Meldung, weiter. Der Duplikatschutz (Popup 2) vergleicht über den Code; „heute“ = gleicher Kalendertag des
Leistungsdatums.

## Untermenü eDoku (Deutschland)

| Aktionstyp | Hinweis |
|---|---|
| DMP anlegen | legt DMP-Dokumentation an |
| HKS anlegen | Hinweis, falls eDoku-Modul aus |
| **FEK anlegen** | **legt nichts mehr an** — zeigt nur den Hinweis zur Umstellung auf das oKFE-Programm |
| oKFE anlegen | legt oKFE-Dokumentation an |
| Krebsregistermeldung | nur mit eingeschaltetem KRM-Modul, sonst übersprungen |

## Untermenü Panel

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Hinweise |
|---|---|---|---|---|
| Patient zu Patientenliste hinzufügen | Patientenliste | Info-Text (Briefkommandos) | – | *sofort* |
| Patient von Patientenliste löschen | Patientenliste | – | – | *sofort* |
| Patient zu DICOMWorklist hinzufügen | Modalität | Untersuchungsregion (Briefkommandos) | Untersuchungsregion: Niemals / wenn Region fehlt / Immer nachfragen | |
| Patient von DICOMWorklist löschen | Modalität | – | – | |
| **Warteschlangenaufruf** | **AppleScript** (aus Admin › Skripte) | – | – | ruft die Wartenummer über das Skript auf; mehrere Nummern → Auswahl; *wartet* auf Skriptende |

## Ohne Untermenü

| Aktionstyp | Wert | Vorbefüllung | Konfiguration | Ablauf, Hinweise |
|---|---|---|---|---|
| **AppleScript** | **Skript aus Admin › Skripte** (kein Freitext) | – | – | läuft mit Patient/Besuch; nächster Schritt **nach Skriptende** |
| **Aufgabe** | Aufgabenvorlage | – | ☐ „Lege Aufgabe direkt an“ | Direkt: ohne Fenster. Sonst Aufgabenfenster, **blockierend**. Termine einer Terminsuche werden verknüpft. |
| **Marker** | Marker (nur manuelle, sichtbare, keine Gruppen) | – | ◉ setzen / ○ entfernen | sofort |
| **Terminsuche (Definiert)** | Terminsuche | – | – | **blockierend**; gefundene Termine gehen an Folgeschritte und Folgeketten, Abbruch verwirft sie |
| **Terminsuche (Kette)** | Terminkettensuche | – | – | wie oben |
| **Zugriffsrecht für Patient setzen** | Zugriffsprofil | – | ☐ „Beim Ausführen festlegen“ | mit Option: Auswahl beim Ausführen; vorhandene Rechte → Rückfrage |
| **Patientenaufgaben anzeigen** | – | – | alle anzeigen / ab Priorität niedrig · normal · hoch · höchste | Fenster nur, wenn Aufgaben vorhanden; *sofort* |
| **Zurückschreiben** | Zielfeld | Wert (Text/Briefkommando) | Schreibweise + Separator | siehe unten |
| **KI-Prompt** | Prompt (Anwendungsfall Aktionsketteneintrag) | – | Ergebnis-Briefkommando; Beschreibung des erwarteten Ergebnisses | **blockierend** bis zur Antwort → `ki-prompt-aktion.md` |
| **Patientenformular anfordern** *(neu 2026)* | – | – | Knopf „Konfigurieren…“: Weg **E-Mail** / **QR-Code** / **iPad (Handoff-Schlange)**; Formularauswahl **Individuell** / **Vorauswahl**; E-Mail-Vorlage (Warnung ohne Formularlink-Kommando), E-Mail-Konto, Handoff-Schlange | Nicht konfiguriert → übersprungen. QR-Code: wartet bis Ablauf oder Abbruch. Formulare selbst → Skill `tomedo-patientenformulare` |
| **GDT** | GDT-Verbindung (aus den **Arbeitsplatz-Einstellungen**) | – | – | Export, *wartet* |
| **Order Entry** | Order-Entry-Typ | Kostenträger „KT:“ + KV/Privat/BG | – | *sofort* |
| **Früherkennung abrechnen** | Früherkennungs-Krankheit | – | – | *sofort* |
| **Vitalwerte** | Vitalwerte-Einstellung | – | – | **setzt die Vitalwerte-Einstellung des Patienten** — öffnet kein Erfassungsfenster |
| **Sprechstundenassistent** | – | – | ☐ „Aktionskette beim Öffnen sofort fortsetzen“ | Standard **blockierend** bis das Fenster zu ist |
| BMP öffnen | – | – | – | Medikationsplan |
| TI-Verbindung aufbauen / abbauen | – | – | – | *wartet* auf Ergebnis |
| Intellimago | – | – | – | öffnet den Patienten in intellimago |
| Patient an intellimago senden | – | – | – | nur mit Systemeinstellung (von zollsoft freizuschalten) |

### Zurückschreiben

**Zielfelder** (Untermenüs Besuch, Patient, Datenschutz):

| Gruppe | Zielfeld | Art |
|---|---|---|
| Besuch | Besuch Info | Text |
| Besuch | Besuch Bool1 · Bool2 | Haken |
| Besuch | Besuch Bool3 · Bool4 | Haken, **nutzerbezogen**: setzt „abgerechnet“ bzw. „dokumentiert“ **für den angemeldeten Nutzer** |
| Besuch | Besuch String1 · String2 | Text (**nur 1–2**) |
| Besuch | Besuch KV-Fall · BG-Fall · Privat-Fall · Wichtig | Haken |
| Patient | Patient Info · String1–String4 | Text |
| Patient | Patient Bool1 · Bool2 | Haken |
| Datenschutz | Kontakt per Telefon/E-Mail/FAX/SMS; Inhalt Infobriefe/Newsletter, Termindetails, Medizinische Dokumentation, Rechnungen, Recall, arbeitsmed. Bescheinigung an Probanden/Arbeitgeber (10 Haken) | Haken |
| – | Karteieintrag (+ KE-Typ Text, Bild, CKE, OP, Refraktion, Visus; bei CKE/OP das Element) | Text |

**Welcher Karteieintrag?** Wurde die Kette von einem Auslöser zu einem bestimmten Karteieintrag gestartet,
wird **dieser** beschrieben, sonst der jüngste des gewählten Typs. CKE/OP: Wert des gleichnamigen Elements,
danach wird der Karteitext neu erzeugt.

**Schreibweise (Text-Ziele):** Anhängen · Anhängen wenn nicht schon im Text *(Standard)* · … wenn nicht schon
am Ende · Ersetzen · Ersetzen wenn nicht schon im Text · … am Ende · Setzen nur wenn Feld leer · Voranstellen ·
Voranstellen wenn nicht schon im Text · … am Anfang. Separator nur bei Anhängen/Voranstellen. Der Wert wird
getrimmt; leerer Wert bei Anhängen/Voranstellen → nichts. „nicht schon im Text“ = Teilstring mit
Groß-/Kleinschreibung.

**Haken-Ziele:** Zahl ≥ 1, „ja“, „yes“, „true“, „x“ → an; Zahl < 1, „nein“, „no“, „false“, „-“ → aus
(Groß/klein egal); „null“/„nil“ → leer (nicht bei Datenschutz); alles andere → keine Änderung.

Die Zielfelder lassen sich in Aktionskettenbedingungen auslesen → Datenaustausch zwischen Ketten.

---

## Andere Installationsarten

| Installation | Abweichende Typen |
|---|---|
| Österreich | Wahlarztrechnung, Privatleistung anlegen, DVP-Leistung anlegen, Konsultation (e-card-Behandlungsfall, blockierend); Abrechnungs-Tab mit DVP/Privat/Wahlarzt |
| Schweiz | KVG, IVG/MVG/UVG, Selbstzahler, VVG (TARDOC-Favoriten); Medikament mit „Verordne sofort“ |
| Zahnarzt | BEMA-, GOZ-Ziffer anlegen, KZV, 01-/PSI-/PAR-Befund; ohne EBM, GOÄ, KV-Schein, eDoku (Zahnarzt MKG: zusätzlich alle deutschen Typen) |

---

## Ablauf einer Kette

### Start
- **Je Patient läuft nur eine Kette.** Ein zweiter Start meldet „Es ist noch eine Karteikette für den
  Patienten offen…“ und bricht ab. Auslöser und Unterketten werden dagegen in die Warteschlange gehängt.
- Vor dem Start werden die Patientendetails geladen; Fehler → Kette bricht ab.
- Braucht ein Schritt die Kartei (Karteieintrag, Diagnose, Ziffern, Schein, Brief, eDoku, Rechnung,
  Karteidatum, Zurückschreiben in Karteieintrag …), **öffnet tomedo die Kartei** des Patienten; wird sie
  während des Laufs geschlossen, öffnet die Kette sie wieder.
- Kiosk-Modus: Ketten nur mit der Einstellung „Aktionsketten zulassen“.
- Ein Schritt mit gelöschter Vorlage, Kette, Bedingung oder Frage wird mit Meldung übersprungen.

### Blockierend oder nicht

- **Blockierend:** Karteieintrag anlegen (Popover), Formular „nichts“, Brief, Medikament, Hinweisfenster,
  Nachricht/Aufgabe/arzt-direkt ohne „direkt“, Favoriten-Auswahlfenster, Diagnose Übernahmefenster,
  Aktionskettenfrage, Terminsuchen, Privatrechnung ohne Typ/Muster, Abrechner-Nachfrage, EBM aus Code, via
  OPS, Sprechstundenassistent, KI-Prompt, Zugriffsrecht „beim Ausführen“.
- **Wartet ohne Nutzer:** AppleScript, Warteschlangenaufruf, GDT, E-Mail, TI, Löschschritte,
  Aktionskettenbedingung (Datenladen), Privatrechnung drucken.
- **Sofort:** Info, SMS, Patientenaufgaben, Früherkennung abrechnen, Order Entry, Sprechstundenassistent mit
  „sofort fortsetzen“, alle „direkt“-Varianten.

**Karteieintrag öffnen:** Nach aktuellem Stand wartet die Kette auf das Schließen des Popovers. In der Praxis wurde
beobachtet, dass die Folgeaktion „überholt“ **[Messung]**. Wahrscheinliche Ursache: Ein noch offenes Popover
eines vorherigen Schritts wird beim Öffnen geschlossen, und dessen Schließ-Meldung schaltet die Kette weiter.
**[ungeprüft]** Vorsichtshalber so bauen, als sei der Schritt nicht blockierend: keinen Popover-Schritt
unmittelbar davor, oder den Rest per Unterkette mit „Kette wird eingeschoben“ trennen.

**Abbruch in einem Schritt-Dialog** (Terminsuche, Rechnung abbrechen) beendet **nicht** die Kette; sie läuft
mit dem nächsten Schritt weiter. Ganze Kette abbrechen: Knopf **Abbrechen** im Verlaufsfenster (beendet auch
die Warteschlange). Läuft eine Kette länger als 10 Minuten, fragt tomedo beim nächsten Auslösen, ob sie
abgebrochen werden soll.

### Bedingte Schritte

Es gibt **keine Bedingung, keine Frage und keine Wartezeit je Schritt**. Bedingte Logik entsteht über
Unterketten:

```
Hauptkette
├── Karteieintrag anlegen …
├── Aktionskettenbedingung  PRIVAT        → Kette PRIV_RECHNUNG   [Kette wird eingeschoben]
├── Aktionskettenbedingung  GESETZLICH    → Kette KV_ZIFFERN      [Kette wird eingeschoben]
└── Hinweisfenster „fertig“
```

Ohne „Kette wird eingeschoben“ laufen die Unterketten erst **nach** dem Hinweisfenster. Für „sonst“ braucht
es einen zweiten Bedingungsschritt mit der Gegen-Bedingung.

### Variablen und Daten zwischen Schritten

- Alle Schritte einer Kette und alle eingereihten Unterketten teilen **denselben Briefkommando-Kontext**
  (Variablen, KI-Ergebnis-Kommandos) und dieselben Termine aus einer Terminsuche.
- Hat ein Auslöser mit SQL-Bedingung die Kette gestartet, stehen die Spalten der ersten Ergebniszeile als
  `$[Spaltenname]$` bereit (siehe `ausloser.md`).
- Werte, die per URL oder HTTP übergeben werden, stehen je nach Modus als Variable oder Briefkommando bereit
  (siehe `SKILL.md`, Abschnitt „Von außen startbar“).
- **Kein Termin im Kontext:** In Aktionsketten ist kein Termin gesetzt; Termin-Kommandos liefern leer. Ausnahmen:
  Start aus der Termininfo (Termin-Popover) oder nach einem Schritt „Terminsuche“ — dann stehen die gefundenen bzw.
  gewählten Termine bereit. **[ungeprüft]**

### Schleifen

**Ein wirksamer Endlosschleifen-Schutz fehlt.** tomedo protokolliert eine Wiederholung nur. Eine Kette, die
sich selbst (oder über eine andere Kette) wieder einreiht, läuft endlos, bis jemand im Verlaufsfenster
abbricht. **[ungeprüft]** Gegenmittel: „Kette wird nur einmal in Warteschlange gesetzt“ und eine
Guard-Bedingung (z. B. Marker), die beim zweiten Durchlauf falsch ist; bei Selbstaufrufen „Zeige Verlauf“
eingeschaltet lassen.

**Kette aus einem CKE:** Das CKE-Element „Aktionskette aufrufen“ speichert den Eintrag und schiebt die Kette
**direkt** ein. Die Warteschlangen-Optionen gelten dort nicht, und auch „nur einmal“ greift nicht. **[ungeprüft]**
Bau des Elements → Skill `tomedo-cke`.

---

## Termine und Sperrtage — Negativbefund

⚠ **Kein Aktionstyp legt einen Termin, Sperrtag oder Urlaubstag an** (Abgleich des vollständigen Katalogs).
Terminsuchen und Sprechstundenassistent sind interaktiv und schreiben nichts selbst. Sperrtage und Termine
sind also **nicht** per Aktionskette erzeugbar — auch nicht mittelbar über `call aktionskette`. Wer
Ganztags-Abwesenheiten programmatisch setzen will, braucht den Weg über das Arbeitszeitkonto; ein Sperrtag
direkt im Kalender verbucht **keinen** Urlaubsanspruch und reduziert **keine** Sollzeit. Lesend:
`terminkalendertag.sperrmodus = 1` (Skill `tomedo-statistik-hql`).

**Baubar sind dagegen** Aufgabe (der Standard-Meldekanal), Nachricht, ToDo anlegen und AppleScript.

---

## Vorlagen-Abhängigkeiten

Diese Vorlagen müssen **vor** der Kette existieren: Leistungsfavoriten (EBM, GOÄ, UVGOÄ, HZV, Sachkosten),
Diagnosefavoriten, Aufgabenvorlagen, Nachrichtenfavoriten, Briefvorlagen, E-Mail- und SMS-Vorlagen,
Versandprofile, Rechnungstypen und -muster, ToDo-Vorlagen und -Ketten, Terminsuchen, Skripte unter
Admin › Skripte, KV-Schein-Vorlagen, Zugriffsprofile, Vitalwerte-Einstellungen, KI-Prompts.
