# Vollständige Referenz: Aktionsketten-Auslöser

Extrahiert aus der tomedo-Oberfläche (Admin → Aktionsketten → Aktionsketten-Auslöser).
Stand: März 2026.

---

## Aufbau eines Auslösers — Alle Felder

Das Verwaltungsfenster "Verwaltung Auslöser für Aktionsketten" enthält folgende Felder:

```
Verwaltung Auslöser für Aktionsketten
├── Kürzel: [eindeutiges Kürzel]
├── Name: [beschreibender Name]
│
├── Objekt: [Dropdown 1 — WAS wird überwacht]
│   └── Unter-Typ: [Dropdown 2 — Spezifizierung, z.B. KE-Typ bei KarteiEintrag]
├── Aktion des Objektes: [Dropdown — WELCHE Aktion am Objekt auslöst]
│
├── SQL-Bedingung für Ausführen: [Dropdown — optionale SQL/HQL-basierte Vorbedingung]
│   └── Hinweis: "Statistik liefert mind. 1 Ergebnis (siehe Tooltip)"
├── Aktionskettenbedingung: [Dropdown — optionale Bedingung auf Briefkommando-Basis]
│
├── Ausführende Aktionskette: [Dropdown — welche Kette gestartet wird]
│   ├── Rechts daneben: Toggle [Aktionskette | AK-Frage]
│   └── Warten vor Ausführen (in ms): [Zahl, Default 0]
│
└── Arbeitsplätze/Nutzer:
    ├── Verknüpfung: [ODER Verknüpfung von Nutzer und Arbeitsplatz] (Dropdown)
    ├── Nutzer: [Checkbox-Liste mit "alle" + "umkehren"]
    ├── Arbeitsplatz: [Checkbox-Liste mit "alle" + "umkehren"]
    ├── NutzerGruppe: [Checkbox-Liste]
    └── ArbeitsplatzGruppe: [Checkbox-Liste]
```

---

## Dropdown 1: Objekt (WAS wird überwacht)

Vollständige Liste aller verfügbaren Auslöser-Objekte:

| Objekt | Unter-Typ-Dropdown | Beschreibung |
|---|---|---|
| arzt-direkt Kopplung | – | Messenger-Integration |
| Aufgabe | – | Interne Aufgaben |
| Besuch | – | Patientenbesuch (Anlage, Änderung) |
| DMP | – | Disease-Management-Programm |
| E-Mail | – | E-Mail Ein-/Ausgang |
| E-Rezept | – | Elektronisches Rezept |
| EBM | – | EBM-Leistungsziffer |
| EBM (Codesuche via Regex) | – | EBM per Regex-Pattern |
| ePA | – | Elektronische Patientenakte |
| Formular | – | Custom-/Patientenformulare |
| GOÄ | – | GOÄ-Leistungsziffer |
| GOÄ (Codesuche via Regex) | – | GOÄ per Regex-Pattern |
| HZV/SV-Leistung | – | Selektivvertrag-Leistung |
| HZV/SV-Leistung (Codesuche via Regex) | – | HZV per Regex |
| HZV/SV-Schein | – | Selektivvertrag-Schein |
| ICD-Diagnose | – | Einzelne ICD-Diagnose |
| ICD-Gruppe | – | ICD-Diagnosegruppe |
| **KarteiEintrag** | **KE-Typ (z.B. BEH, ANA, PSY...)** | Karteieintrag — häufigster Auslöser! Unter-Typ = Karteieintragtyp-Kürzel |
| KarteiFenster | – | Öffnen/Schließen der Kartei |
| KVSchein | – | GKV-Kassenärztlicher Schein |
| Laborbefund | – | Laborergebnis |
| Marker | – | Patienten-Marker |
| Medikament-ATC-Code | – | Medikament per ATC |
| Medikament-PZN | – | Medikament per PZN |
| Mutterpass | – | Gynäkologie |
| NFDM | – | Notfalldatenmanagement |
| Notruf | – | Praxisnotruf |
| Patient | – | Patient selbst (Anlage, Änderung) |
| Patientenformular | – | Patientenformular-Rücklauf |
| Patienteninformation | – | Patienteninfo-Änderung |
| Raum | – | Raumverwaltung |
| Rechnung | – | Privatrechnung |
| Rezept | – | Rezepterstellung |
| Terminsuche (Definiert) | – | Definierte Terminsuche |
| Terminsuche (Einzel) | – | Einzelterminsuche |
| Terminsuche (Kette) | – | Kettenterminsuche |
| **ToDo** | – | ToDo-Verschiebung — zweithäufigster Auslöser! |
| ToDokette (jedes einzelne ToDo) | – | Jedes ToDo einer Kette einzeln |
| UVGOÄ | – | Unfallversicherung-Ziffer |
| UVGOÄ (Codesuche via Regex) | – | UVGOÄ per Regex |
| Vorsorgemaßnahme | – | Vorsorge/Früherkennung |

**Gesamt: 40 Objekte**

### Unter-Typ bei KarteiEintrag (Dropdown 2)

Wenn Objekt = "KarteiEintrag", erscheint ein zweites Dropdown mit dem KE-Typ-Kürzel. Vollständige Liste der verfügbaren KE-Typen (praxisspezifisch + Standard):

> **Die Liste ist je Installation verschieden.** Sie mischt tomedo-Standardtypen mit
> praxiseigenen Custom-Typen; an der Referenzinstallation waren es rund 130. Ein Auslöser,
> der auf ein Kürzel aus einer fremden Praxis zeigt, feuert nie.

**Eigene Liste ermitteln:** Admin → Karteieintragstypen (vollständig, mit Kürzel und
Bezeichnung) oder direkt das zweite Dropdown im Auslöser-Dialog aufklappen — dort steht
genau der Bestand, gegen den die Kette später prüft.

**Für die Kette heißt das:** Kürzel nie aus einer Vorlage übernehmen, sondern einmal
gegen den eigenen Bestand abgleichen. Gleiche Fachbedeutung, anderes Kürzel ist der
Normalfall, nicht die Ausnahme — Therapie-, Befund- und Verlaufszeilen heißen praktisch
überall anders.


---

## Dropdown: Aktion des Objektes

Die verfügbaren Aktionen hängen vom gewählten Objekt ab. Die häufigsten:

| Aktion | Typische Objekte | Beschreibung |
|---|---|---|
| Anlegen | KarteiEintrag, Besuch, ToDo, Diagnose, EBM, GOÄ, KVSchein, Rechnung | Wird ausgelöst wenn das Objekt neu erstellt wird |
| Ändern | KarteiEintrag, Besuch, Patient | Wird ausgelöst wenn das Objekt modifiziert wird |
| Löschen | KarteiEintrag, Diagnose, EBM, GOÄ | Wird ausgelöst wenn das Objekt entfernt wird |
| Öffnen | KarteiFenster | Kartei wird geöffnet |
| Verschieben | ToDo | ToDo-Status wechselt (anstehend → aktuell → erledigt) |
| Drucken | Rechnung | Rechnung wird gedruckt |

**Hinweis:** Nicht jedes Objekt unterstützt jede Aktion. Die Liste im Dropdown passt sich dem gewählten Objekt an.

### Objektspezifische Aktionen — Beispiele

**Objekt: Patient**
| Aktion | Hinweis |
|---|---|
| Kein Wert | – |
| Änderung der Freitexte | Freitextfelder am Patienten |
| Änderung der Stammdaten (Aktion lokal, 5 Sekunden zeitversetzt) | Eingebaute 5s Verzögerung! |
| Neuanlage (Aktion lokal, 5 Sekunden zeitversetzt) | Eingebaute 5s Verzögerung! |

**Hinweis "Aktion lokal, 5 Sekunden zeitversetzt":** Bei Patient-Aktionen ist die Verzögerung fest eingebaut (nicht konfigurierbar wie das ms-Feld). "Lokal" bedeutet: Die Aktion wird nur am Arbeitsplatz ausgeführt, der den Patienten angelegt/geändert hat.

---

## SQL-Bedingung für Ausführen

Optionale Vorbedingung basierend auf SQL/HQL-Queries. Das Dropdown zeigt:

**Struktur:**
- Kein Wert (= keine SQL-Bedingung)
- Eigene Abfragen → [Liste praxisspezifischer Statistik-Queries]
- Allg. Abfragen → [tomedo-Standardabfragen]
- SQL Bedingungen für Aktionsketten → [spezielle AK-optimierte Queries]

**Auslöse-Logik:** "Statistik liefert mind. 1 Ergebnis (siehe Tooltip)" — die Aktionskette wird NUR ausgeführt, wenn die SQL-Query mindestens einen Treffer liefert.

**Praxis-Tipp:** Hier können HQL-Queries aus dem `tomedo-statistik-hql` Skill direkt verwendet werden! Beispiel: Query prüft ob Patient bestimmte Diagnose hat → nur dann wird Aktionskette gestartet. **Vorteil:** Mächtiger als Aktionskettenbedingungen, da voller SQL-Zugriff auf die Datenbank. **Nachteil:** Nur bei aktivem Server funktionsfähig, erfordert SQL-Kenntnisse.

---


### Semantik: Gate, nicht Datenlieferant (Realbefund 2026-08-26)

**Die SQL-Bedingung ist ein praxisweites Gate, kein Datenlieferant.** Ausgewertet wird nur, ob
mindestens eine Zeile zurueckkommt; **Inhalt und Spaltennamen des Ergebnisses werden nicht gelesen**.
Den Patientenkontext bezieht die Kette ausschliesslich vom Ausloeser-Objekt (bei
`Objekt: KarteiEintrag` also vom Patienten des Karteieintrags).

Daraus folgen drei Regeln:

1. **Es gibt keinen Bindungs-Token fuer den ausloesenden Patienten.** Versuche wie
   `AND t.patient_ident = :PATIENT` brechen mit `syntax error at or near ":"` ab. Die Query kann
   nicht wissen, fuer wen sie laeuft.
2. **Patientenbindung gehoert in die Aktionskettenbedingung** (Briefkommando-Basis, wird
   patientenbezogen ausgewertet). Beide Bedingungsarten duerfen gleichzeitig gesetzt sein und
   muessen beide erfuellt sein — die uebliche Arbeitsteilung ist: SQL prueft globale Fakten
   (Frische, Mengen, Konfigurationszustand), Briefkommando prueft den Patienten.
3. **Die Query muss selbstkorrelierend sein.** Statt Patientenbindung zwei Ereignisse ueber
   dieselbe Zeile verjoinen (z.B. Termin und Karteieintrag ueber denselben Patienten plus
   Zeitdifferenz). Restrisiko bleibt: liegt ein *anderer* Patient gerade im Zeitfenster, feuert
   das Gate trotzdem, und die Kette laeuft am Ausloeser-Patienten. Bei hochfrequenten
   Ausloeser-Objekten (Beispiel Referenzinstallation: 250–300 `MAIL-Aus`/Tag) ist das kein Randfall.

## Aktionskettenbedingung

Optionale Vorbedingung basierend auf Briefkommandos (siehe bedingungen.md). Das Dropdown zeigt alle konfigurierten Bedingungen, organisiert in Gruppen:

**Struktur (Beispiel aus Praxis):**
- Kein Wert (= keine Bedingung)
- Summe_Privatrechnung_
- #_NichtLoeschen → SONO_WL_Bedingungen, #_Wartezimmer, ABR-Beh
- Aufgabe/Briefschreibung
- depr.Stimmung
- Allgemein
- (weitere praxisspezifische Gruppen)

**Unterschied zu SQL-Bedingung:** Aktionskettenbedingungen nutzen Briefkommandos (Keypaths auf Patientendaten), SQL-Bedingungen nutzen direkte Datenbankabfragen. Beide können gleichzeitig verwendet werden — BEIDE müssen erfüllt sein.

---

## Ausführende Aktionskette / AK-Frage

### Toggle: Aktionskette vs. AK-Frage

Rechts neben dem Aktionsketten-Dropdown gibt es einen Toggle mit zwei Optionen:
- **Aktionskette** — führt direkt eine Aktionskette aus (Standard)
- **AK-Frage** — zeigt eine Aktionskettenfrage (Entscheidungsdialog) an

### Warten vor Ausführen (in ms)

Verzögerung in Millisekunden bevor die Kette/Frage gestartet wird. Default: 0.

**Praxis-Tipp:** Sinnvoll bei Auslösern die kurz nach Objektanlage feuern, wenn die Daten noch nicht vollständig geladen sind. Z.B. 500ms Verzögerung bei Besuchsanlage, damit Patientendaten sicher geladen sind bevor die Bedingung prüft.

---

## Arbeitsplätze/Nutzer-Filter

### Verknüpfungs-Logik

Dropdown mit Optionen:
- **ODER Verknüpfung von Nutzer und Arbeitsplatz** (Standard) — Auslöser feuert wenn ENTWEDER der Nutzer ODER der Arbeitsplatz passt
- (Weitere Optionen je nach tomedo-Version)

### Vier Filter-Ebenen

| Filter | Checkbox "alle" | "umkehren"-Button | Beschreibung |
|---|---|---|---|
| Nutzer | ✅ (Default: alle) | Ja | Einzelne Nutzer ein-/ausschließen |
| Arbeitsplatz | ✅ (Default: alle) | Ja | Einzelne Arbeitsplätze ein-/ausschließen |
| NutzerGruppe | – | – | Gruppen (z.B. Arzt, Physiotherapie, Psychotherapie) |
| ArbeitsplatzGruppe | – | – | Standort-Gruppen |

### "umkehren"-Button — Wichtiger Trick

Statt alle Nutzer bis auf einen einzeln anzuhaken: Den auszuschließenden Nutzer anhaken → "umkehren" klicken → alle ANDEREN sind jetzt aktiv. Typischer Anwendungsfall: Kiosk-Arbeitsplatz soll keinen Auslöser triggern.

**Praxis-Tipp:** Bei Auslösern die nur für Ärzte gelten sollen: NutzerGruppe "Arzt" anhaken statt alle Ärzte einzeln. Bei Auslösern die am Empfang nicht feuern sollen: Empfangs-Arbeitsplatz auswählen → umkehren.

---

## Zusammenspiel: Wann feuert ein Auslöser?

Ein Auslöser löst die Aktionskette/Frage aus wenn ALLE folgenden Bedingungen erfüllt sind:

```
1. Objekt + Aktion stimmen überein
   (z.B. KarteiEintrag BEH + Anlegen)

2. UND SQL-Bedingung erfüllt (falls gesetzt)
   (Query liefert ≥ 1 Ergebnis)

3. UND Aktionskettenbedingung erfüllt (falls gesetzt)
   (Briefkommando-basierte Prüfung)

4. UND Nutzer/Arbeitsplatz-Filter passt
   (ODER-Verknüpfung: Nutzer stimmt ODER AP stimmt)

→ Dann: Ausführende Aktionskette starten
   (ggf. nach Wartezeit in ms)
```

---

## Häufige Auslöser-Patterns

### Pattern 1: Bei Besuchsanlage → Leistungen anlegen
```
Objekt: Besuch
Aktion: Anlegen
Bedingung: [z.B. Patient ist Privatpatient]
Aktionskette: [Privatrechnung anlegen + GOÄ-Ziffern]
```

### Pattern 2: Bei ToDo-Verschiebung → Kartei öffnen + CKE anlegen
```
Objekt: ToDo
Aktion: Verschieben (auf aktuell)
Bedingung: –
Aktionskette: [Karteieintrag anlegen CKE-Typ]
Hinweis: Kette läuft am AP wo ToDo geschoben wird!
```

### Pattern 3: Bei KarteiEintrag-Anlage → Score berechnen
```
Objekt: KarteiEintrag
Unter-Typ: BEH (Behandlung)
Aktion: Anlegen
Bedingung: [Diagnose VHF vorhanden + Score nicht heute angelegt]
Aktionskette: [CHA2DS2-VASc Score anlegen]
```

### Pattern 4: Bei Diagnose → Bedingungsgesteuerte Frage
```
Objekt: ICD-Diagnose
Aktion: Anlegen
Bedingung: –
Ausführend: AK-Frage [z.B. "Soll Score erstellt werden?"]
```

### Pattern 5: Neupatient → automatischer Marker (Praxis-Beispiel)
```
Kürzel: NEU-ePA-Aufklärung
Name: Neupatient erfordert ePA Aufklärung Marker
Objekt: Patient
Aktion: Neuanlage (Aktion lokal, 5 Sekunden zeitversetzt)
SQL-Bedingung: Kein Wert
Aktionskettenbedingung: Kein Wert
Ausführende Aktionskette: ePA_marker_NEU [Aktionskette]
Warten vor Ausführen: 0 ms
Arbeitsplätze/Nutzer: alle
```
→ Bei jeder Neuanlage eines Patienten wird automatisch ein ePA-Aufklärungs-Marker gesetzt. Die 5-Sekunden-Verzögerung ist im Objekt "Patient" eingebaut.


### Startpfad ausserhalb der Auslöser-Verwaltung: Textbaustein-Antwort

Eine **Antwortoption eines Frage-Antwort-Dialogs** kann eine Aktionskette starten. Der Weg
läuft nicht über einen Auslöser, sondern über das Textbaustein-Makro selbst und taucht
deshalb in keiner Auslöser-Liste auf.

```
∆¥ACTION_ANSWER2=<Kettenkürzel>¥Fragetitel<zsMacroAnswerDivider>EINS<zsMacroAnswerDivider>ZWEI∆
```

`<n>` zählt die **Antworten**; der Fragetitel zählt nicht mit. Im Konfigurator heißt die
Einstellung „Bei Auswahl der Antwort soll die Aktionskette mit dem folgenden Kürzel
gestartet werden". [belegt, Messung Referenzinstallation 2026-09-15]

**Warum das zählt:** Damit wird ein Dokumentationsbaustein zum Workflow-Auslöser. Beispiel:
Im psychischen Befund startet die Antwort „Suizidalität aktiv geäußert" eine Alarmkette
(Aufgabe an den ärztlichen Leiter, Marker setzen, Wiedervorstellung terminieren) — ohne dass
jemand daran denken muss.

**Fallstrick:** Die Kette startet bei der **Auswahl**, nicht beim Einfügen des fertigen
Textes. Wer den Dialog abbricht, hat die Kette trotzdem ausgelöst. Ketten an dieser Stelle
deshalb idempotent bauen (Guard-Bedingung „Marker noch nicht gesetzt").

Zum Bau des Bausteins selbst → Skill `tomedo-textbausteine`.

