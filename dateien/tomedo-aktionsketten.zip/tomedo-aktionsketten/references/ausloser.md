# Vollständige Referenz: Aktionsketten-Auslöser

Admin → Aktionsketten → Aktionsketten-Auslöser, Fenster „Verwaltung Auslöser für Aktionsketten“.
Stand: 22.10.2026. Überarbeitet im Oktober 2026, ergänzt um
Messbefunde der Referenzinstallation.

**Kennzeichnung:** ohne Zusatz = belegt · **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor
dem Einsatz an einer Testakte prüfen · **[Messung]** = an der Referenzinstallation beobachtet.

---

## Aufbau eines Auslösers — alle Felder

```
Verwaltung Auslöser für Aktionsketten
├── Links: Baum (Element · Gruppe · Kopie · − · A..Z↓ · Suche · ☐ gelöschte anzeigen)
│
├── Kürzel · Name                      ← der NAME bestimmt die Reihenfolge, s. „Mehrere Auslöser“
├── Objekt: [Dropdown 1 — WAS wird überwacht]
│   └── Unter-Typ: [je nach Objekt: KE-Typ, Formulartyp, Ziffer, Regex, ATC/PZN, Marker …]
├── Aktion des Objektes: [Dropdown — welches Ereignis]
├── SQL-Bedingung für Ausführen: [Statistik] (+ Hinweis „Statistik liefert mind. 1 Ergebnis“)
├── Aktionskettenbedingung: [Bedingung]
├── Ausführende Aktionskette | Ausführende Aktionskettenfrage   ← Umschalter [Aktionskette | AK-Frage]
├── Warten vor Ausführen (in ms): [Zahl, Standard 0]
├── Sprungknöpfe: zur Aktionsketten-/Fragenverwaltung, Statistikverwaltung, Bedingungsverwaltung
│
└── Arbeitsplätze/Nutzer
    ├── [ODER | UND] Verknüpfung von Nutzer und Arbeitsplatz
    ├── Nutzer:        ☑ alle  [umkehren]  + Liste
    ├── Arbeitsplatz:  ☑ alle  [umkehren]  + Liste
    ├── NutzerGruppe:  Liste
    └── ArbeitsplatzGruppe: Liste
```

Kopie übernimmt alles außer dem Kürzel. Ein doppeltes Kürzel ergibt nur einen Hinweis. Eine **Gruppe**
ist nur ein Ordner und feuert nie.

---

## Objekte und ihre Aktionen

Welche Objekte im Dropdown stehen, hängt **nur von der Installationsart** ab (Land, Zahnarzt), nicht von
Lizenzen oder genutzten Modulen: Auch ePA, NFDM, E-Rezept oder Notruf erscheinen in jeder deutschen
Arztpraxis. Im Dropdown sind Objekte und Aktionen alphabetisch sortiert.

### Deutschland, Humanmedizin — 41 Objekte

„Pflicht“ = das Unter-Typ-Feld muss gefüllt sein. **Ist ein Pflicht-Unter-Typ leer, feuert der Auslöser
nie** — es gibt keine Fehlermeldung.

| Objekt | Unter-Typ | Aktionen |
|---|---|---|
| arzt-direkt Kopplung | – | Erfolgreiche Kopplung (der Patienten-App) |
| Aufgabe | Aufgabenvorlage, Pflicht | Aufgabe angelegt · Aufgabe abgeschlossen · Aufgabe gelöscht |
| Besuch | – | Anlegen · Beenden |
| DMP | – | Anlegen · Öffnen · Schließen · Schließen (Doku vollständig) |
| E-Mail | E-Mail-Konto, Pflicht | E-Mail Patient zuweisen · Eingehende E-Mail Patient zuweisen |
| E-Rezept | – | E-Rezept erstellen · signieren · nur signieren (ohne versenden) · versenden · stornieren |
| EBM | EBM-Ziffer | Anlegen |
| EBM (Codesuche via Regex) | Regex | Anlegen |
| ePA | – | Dokumente erfolgreich in ePA hochgeladen |
| Formular | Formulartyp, Pflicht | Schließen · Drucken · Speichern |
| GOÄ | GOÄ-Ziffer | Anlegen |
| GOÄ (Codesuche via Regex) | Regex | Anlegen |
| HZV/SV-Leistung | HZV-Ziffer (Ziffer **und** Vertrag müssen passen) | Anlegen |
| HZV/SV-Leistung (Codesuche via Regex) | Regex | Anlegen |
| HZV/SV-Schein | Vertrag, **optional** (leer = alle) | Anlegen |
| ICD-Diagnose | ICD-Code, Pflicht | ICD-Code erstmalig erfasst · Neu-/Altdiagnose auf Schein erfasst |
| ICD-Gruppe | ICD-Gruppe (feuert für alle Untercodes) | wie ICD-Diagnose |
| **KarteiEintrag** | KE-Typ-Kürzel, faktisch Pflicht | Anlegen · Manuelles Vidieren · Ändern eines bestehenden Karteieintrags (OK-Button im Popover) · Anlegen oder Ändern eines bestehenden Karteieintrags (OK-Button im Popover) |
| KarteiFenster | – | Öffnen · Schließen · Öffnen (+ im Einzelfenstermodus auch: Anzeige eines anderen Patienten) · Öffnen (+ neuer Patient, alle Karteieinträge nachgeladen) · Schließen (+ im Einzelfenstermodus …) · ImpfDocNE: Impfung reservieren · ImpfDocNE: Impfung stornieren |
| KVSchein | – | Anlegen · OK Klick nach Anlage |
| Laborbefund | – | Laborbefund gelesen |
| Marker | Marker, Pflicht | Marker setzen (Aktion lokal) · Marker entfernen (Aktion lokal) |
| **Medikament-ATC-Code** | ATC-Codes, kommasepariert | Verordnen · Rezept Vorschau/Drucken |
| **Medikament-PZN** | PZNs, kommasepariert | Verordnen · Rezept Vorschau/Drucken |
| Mutterpass | – | Mutterpass anlegen |
| NFDM | – | Lese/Lösche/Schreibe DPE von/auf eGK · Lese DPE im Notfall · Lese/Lösche/Schreibe NFD von/auf eGK · Lese NFD im Notfall (8 Aktionen) |
| Notruf | Notruftyp, Pflicht | auslösen · empfangen |
| Patient | – | Neuanlage (Aktion lokal, 5 Sekunden zeitversetzt) · Änderung der Stammdaten (Aktion lokal, 5 Sekunden zeitversetzt) · Änderung der Freitexte |
| Patientenformular | Formulartyp (nur mit Online-Vorlage) | Gelesen |
| Patienteninformation | – | Öffnen · Schließen · (Einzelfenstermodus-Varianten wie KarteiFenster) |
| Raum | Raum, Pflicht | Setzen · Verlassen |
| Rechnung | Rechnungstyp, faktisch Pflicht | Anlegen |
| **Rezept** | – | Rezept Vorschau/Drucken |
| Terminsuche (Definiert) | Terminsuche, Pflicht | Anlegen |
| Terminsuche (Einzel) | – | Anlegen |
| Terminsuche (Kette) | Terminketten-Suche, Pflicht | Anlegen |
| **ToDo** | ToDo-Vorlage | ToDo neu auf anstehend (Aktion lokal) · ToDo anstehend auf aktuell (Aktion lokal) · ToDo aktuell auf anstehend (Aktion lokal) · ToDo aktuell auf abgearbeitet (Aktion lokal) |
| ToDokette (jedes einzelne ToDo) | ToDo-Kette | wie ToDo; feuert für **jede** ToDo-Kette, in der die Vorlage vorkommt |
| UVGOÄ | UVGOÄ-Ziffer | Anlegen |
| UVGOÄ (Codesuche via Regex) | Regex | Anlegen |
| Vorsorgemaßnahme | Früherkennungs-Krankheit, Pflicht | Statusänderung · Statusänderung grün · Statusänderung gelb · Statusänderung rot |

**Es gibt keine Aktionen „Ändern“ (außer beim Karteieintrags-Popover), „Löschen“ (außer „Aufgabe
gelöscht“) oder „Verschieben“.** Frühere Fassungen dieses Skills nannten sie; solche Auslöser lassen sich
nicht einstellen.

### Andere Installationsarten

| Installation | zusätzlich bzw. anders |
|---|---|
| Zahnarzt (DE) | BEMA, BEMA (Regex), Festzuschuss, Festzuschuss (via Code), GOZ, GOZ (Regex), Labor, Material, 01-Befund, PSI-Befund, PAR-Befund (Speichern); ohne EBM/UVGOÄ/HZV/KVSchein/ePA. Zahnarzt MKG: zusätzlich alle DE-Objekte |
| Österreich | DVP-Schein, DVP-Leistung, Wahlarztrechnung, Konsultation (angelegt · storniert · geändert; Behandlungsfall optional), Privatleistung; ohne ICD-Gruppe |
| Schweiz | KVG, SVG, Analysenliste, MiGeL, Sonstige Tarife |

Insgesamt kennt tomedo 62 Auslöser-Objekte.

---

## Wann genau ein Objekt feuert

| Objekt / Aktion | löst aus bei | Besonderheit |
|---|---|---|
| KarteiEintrag / Anlegen | neuer Karteieintrag dieses Typs, auch Typwechsel in der Kartei und E-Mail-Karteieinträge | Beim Anlegen feuern **„Anlegen“ und „Anlegen oder Ändern …“ gleichzeitig** — wer beide für denselben Typ hat, startet zwei Ketten. Beim Zusammenführen von Patienten feuert nichts. |
| KarteiEintrag / Ändern … (Popover) | OK im Popover, nur wenn sich der Eintrag geändert hat | feuert zusammen mit „Anlegen oder Ändern …“ |
| KarteiEintrag / Manuelles Vidieren | manuelle Vidierung | Laborbefunde ohne KE-Typ zählen als Typ „Labor“ |
| Patient / Neuanlage | neuer Patient | 5 s ab der ersten Änderung, weitere Änderungen in diesem Fenster werden **zu einem Aufruf gebündelt**. Neuanlage aus dem **Patientenformular-Eingang feuert sofort**. |
| Patient / Änderung der Stammdaten | **nur** Vorname, Nachname, Titel, Namenszusatz, Vorsatzwort, Geburtsdatum, Geschlecht, Ort, Privatpatient | **nicht** bei Straße, PLZ, Telefon, Kasse |
| Patient / Änderung der Freitexte | Freitextfelder 1–4 | ohne Verzögerung |
| Marker | Marker am Patienten gesetzt/entfernt | **auch automatische Marker** lösen aus; Gruppen-Marker nicht. Verglichen wird nur die **Anzahl** der Marker: fällt in einem Schritt einer weg und kommt ein anderer dazu, feuert nichts **[ungeprüft]**. Die Vorberechnung der Marker löst keine Ketten aus. |
| ToDo / ToDokette | neues ToDo am Besuch (→ anstehend); Beginn gesetzt (→ aktuell); Beginn entfernt (→ anstehend); Ende gesetzt (→ abgearbeitet) | |
| Raum | Raumwechsel eines ToDos | ein Wechsel = Verlassen (alter Raum) + Setzen (neuer Raum) |
| Besuch / Anlegen · Beenden | echter Besuch angelegt · Besuchsende gesetzt | |
| ICD / erstmalig erfasst | Diagnose, deren Code beim Patienten noch nicht dokumentiert ist (auch Code-Änderung einer bestehenden Diagnose) | |
| ICD / auf Schein erfasst | Diagnose an einen Schein gehängt | nicht beim Klonen/Konsolidieren |
| Ziffern (EBM, GOÄ, UVGOÄ, HZV) | neue Leistung auf Schein oder Rechnung | Objekt ergibt sich aus dem Katalog der Ziffer |
| Medikament / Verordnen | **je Medikament** beim Übernehmen in die Verordnung | |
| Medikament + Rezept / Rezept Vorschau/Drucken | nach dem Erzeugen der Rezepte (Papier **und** E-Rezept) | feuert **einmal je Vorgang**, wenn mindestens ein Medikament passt; nicht, wenn die E-Rezept-Erzeugung abbricht |
| E-Rezept | **je Verordnung** (3 Medikamente = 3 Ketten) | „nur signieren“ löst **zusätzlich** „signieren“ aus |
| Aufgabe | Aufgabe aus einer Vorlage **mit Patient** | ohne Patient: Hinweis, keine Kette |
| Notruf / empfangen | am **empfangenden** Arbeitsplatz | einzige Auslösung an einem fremden Arbeitsplatz |
| Vorsorgemaßnahme | Statuswechsel | grün/gelb/rot feuern **auch beim ersten Anzeigen** in der Sitzung |
| Patientenformular / Gelesen | Formular gelesen | ohne zugeordneten Patienten: Hinweis, keine Kette |
| Terminsuche | Suche angelegt | die gefundenen Termine werden an die Kette übergeben |

Nach aktuellem Stand **vermutlich nie wirksam** (vor Einsatz testen): KarteiFenster „ImpfDocNE: …“; beim
Zahnarzt Festzuschuss (feuert vermutlich nie) und Material (filtert vermutlich nicht nach Material).
**[ungeprüft]**

---

## Unter-Typen im Detail

### Medikament-ATC-Code und Medikament-PZN

| Punkt | Regel |
|---|---|
| ATC-Vergleich | **„beginnt mit“, Groß-/Kleinschreibung egal.** `N02` trifft alle Analgetika der Gruppe N02, `N02AA` nur die Opioid-Alkaloide. |
| PZN-Vergleich | **exakt** (Schweiz: das Feld wird mit der EAN verglichen) |
| Mehrere Werte | **kommasepariert, ohne Leerzeichen**: `N02A,M01A`. Bei `N02A, M01A` greift der zweite Eintrag nie (die Werte werden nicht getrimmt — anders als in den Bedingungen). |
| Voraussetzung | Nur Medikamente **mit Datensatz aus der Arzneimitteldatenbank** lösen aus. Freitext-Verordnungen und Rezepturen ohne Datenbankbezug lösen ATC/PZN nie aus. |
| Aktionen | „Verordnen“ je Medikament; „Rezept Vorschau/Drucken“ einmal je Rezeptvorgang |

Das frühere Objekt „Medikament-ATC“ ist durch „Medikament-ATC-Code“ ersetzt; Auslöser mit dem alten
Objekt erscheinen nicht mehr und sind neu anzulegen. **[ungeprüft]**

### Objekte „(Codesuche via Regex)“

- Das Muster muss den **ganzen Code** abdecken (wie mit `^…$`, das man nicht schreiben muss): `03.*` trifft
  `03230`, `03` trifft nur `03`.
- **Groß-/Kleinschreibung zählt.**
- Bei Alternativen zählt die **zuerst passende**: `03|0300` trifft `0300` nicht (der Teil `03` passt
  zuerst, deckt aber nicht den ganzen Code ab). Längere Alternative zuerst schreiben: `0300|03`.
- Ungültiges Muster → Meldung „Problem mit Aktionskettenauslöser: …“, kein Treffer.

### Ziffern und Diagnosen

- EBM, GOÄ, UVGOÄ, HZV: verglichen wird der **Code-Text**, nicht der Katalogdatensatz.
- ICD-Diagnose: verglichen wird **der Katalogeintrag**. Ob ein Auslöser den jährlichen ICD-Katalogwechsel
  übersteht, ist ungeklärt — nach dem Wechsel testen. **[ungeprüft]**
- ICD-Gruppe: alle Untercodes zum heutigen Datum.

---

## Ablauf beim Feuern — Reihenfolge

```
Ereignis am Arbeitsplatz (Objekt + Aktion + Unter-Typ)
  │
  1  Kandidaten: alle nicht gelöschten Auslöser, sortiert nach NAME
  2  Objekt, Aktion und Unter-Typ passen?
  3  Ziel-Kette bzw. -Frage nicht gelöscht?
  4  Nutzer-/Arbeitsplatzfilter erfüllt?
  5  SQL-Bedingung (falls gesetzt): ≥ 1 Ergebniszeile?            ← bei der Auslösung
  │
  6  Einreihen in die Warteschlange (alle verbliebenen Auslöser)
  │     … wartet, bis die Ketten davor fertig sind …
  │
  7  Aktionskettenbedingung (falls gesetzt), mit frisch geladenen
     Patientendaten und den Ladeoptionen der Bedingung              ← erst bei der Ausführung
  8  Warten vor Ausführen (ms)
  9  Kette bzw. Frage startet
 10  Erst wenn sie beendet oder abgebrochen ist, kommt der nächste Auslöser dran
```

Folgen:
- **Die Wartezeit wirkt nach der Bedingung**, nur unmittelbar vor dem Kettenstart. Sie hilft nicht, „damit
  die Bedingung Daten hat“ — die Bedingung lädt die Patientendaten selbst (Ladeoptionen der Bedingung).
  Sinnvoll ist sie, wenn die **Kette** auf etwas warten muss, das unmittelbar nach dem Ereignis noch
  entsteht. Einheit Millisekunden, Kommazahl erlaubt.
- Die Aktionskettenbedingung wird zum **Ausführungszeitpunkt** geprüft, nicht zum Ereigniszeitpunkt. Läuft
  vorher eine lange Kette, kann sich die Lage inzwischen geändert haben.
- **Eine gelöschte Aktionskettenbedingung wird weiter ausgewertet**, solange sie im Auslöser steht.

### Mehrere passende Auslöser

- **Alle feuern**, keiner verdrängt den anderen.
- Reihenfolge: **alphabetisch nach Name** (Groß-/Kleinschreibung beachtet), nicht nach der Position im Baum.
  Wer eine Reihenfolge braucht, nummeriert die Namen („10 …“, „20 …“).
- Strikt nacheinander. Ketten, die selbst Objekte anlegen (Karteieintrag, Ziffer), lösen wieder Auslöser
  aus; diese werden hinten angehängt. **[ungeprüft]**
- Läuft eine Kette länger als 10 Minuten, fragt tomedo beim nächsten Auslösen, ob sie abgebrochen werden soll.

### Wo die Kette läuft — „Aktion lokal“

Auslöser werden **an dem Arbeitsplatz ausgewertet, an dem das Ereignis stattfand**, und die Kette läuft dort. Das
gilt technisch für **alle** Auslöser, nicht nur für die mit „(Aktion lokal)“ im Namen. Einzige Ausnahme:
Notruf „empfangen“. Änderungen, die vom Server oder von anderen Arbeitsplätzen eingespielt werden, lösen
an diesem Arbeitsplatz nichts aus. Das deckt den Messbefund „Kein Arbeitsplatz, keine Kette“ in `SKILL.md`.

Die eingebauten **5 Sekunden** bei Patient „Neuanlage“ und „Änderung der Stammdaten“ sind fest und wirken
**zusätzlich** zu „Warten vor Ausführen“.

---

## SQL-Bedingung für Ausführen

### Auswahl

Angeboten werden **nicht gelöschte, nicht patientenbezogene Statistiken**: eigene Abfragen sowie die
mitgelieferten „SQL-Bedingungen für Aktionsketten“. Eine patientenbezogene Statistik wird abgelehnt
(„Patientenbezogene Statistiken können nicht für Aktionskettenauslöser genutzt werden.“). Ob weitere
Ordner im Dropdown erscheinen: **[ungeprüft]**. Die Prüfung braucht eine Serververbindung.

### Patientenbindung und Ergebnis

**Berichtigt gegenüber früheren Fassungen** („Gate, nicht Datenlieferant“): tomedo ersetzt
im SQL-Text vor der Ausführung zwei Platzhalter (so steht es auch im Tooltip des Feldes):

| Platzhalter im SQL | wird ersetzt durch |
|---|---|
| `$[patientident]$` | die Kennung des auslösenden Patienten |
| `$[besuchident]$` | die Kennung des auslösenden Besuchs |

Und das Ergebnis geht an die Kette weiter:

| Briefkommando in der Kette | liefert |
|---|---|
| `$[Spaltenname]$` | den Wert dieser Spalte aus der **ersten** Ergebniszeile |
| `$[statistikResultat]$` | das ganze Ergebnis |

```sql
-- Gate nur für den auslösenden Patienten, liefert zugleich einen Wert an die Kette
SELECT COUNT(k.ident) AS anzahl
FROM karteieintrag k
WHERE k.patient_ident = $[patientident]$
  AND ...
HAVING COUNT(k.ident) > 0
```
→ in der Kette steht `$[anzahl]$` zur Verfügung.

**[Messung, 26.08.2026]** Ein Versuch mit `:PATIENT` als Platzhalter brach mit `syntax error at or near ":"`
ab — das passt: tomedo kennt nur die Schreibweise `$[patientident]$`. Die Ersetzung selbst und die
Weitergabe an die Kette sind an der Referenzinstallation **noch nicht
nachgemessen**. **[ungeprüft]**

Regeln:
- 0 Zeilen oder Fehler → der Auslöser fällt weg. ≥ 1 Zeile → weiter.
- Beim vorläufigen Besuch (Patient noch nicht gespeichert) bleiben die Platzhalter stehen; tomedo zeigt
  „Leider ist der derzeitige Besuch virtuell und nicht in der Datenbank!“.
- Spaltennamen kurz und ohne Leerzeichen wählen (`AS anzahl`), damit sie als Kommando taugen.
- **Keine Filter-Tags:** Filter einer Statistik (`<ZS:…>`, `<ZSBLOCK>` usw.) werden in der SQL-Bedingung **nicht**
  ersetzt — nur `$[patientident]$` und `$[besuchident]$`. Eine Statistik mit Filtern taugt deshalb nicht als
  SQL-Bedingung; für die Bedingung eine eigene Statistik ohne Filter anlegen. **[ungeprüft]**
- **Arbeitsteilung bleibt sinnvoll:** SQL für praxisweite Fakten und Zählungen über die Datenbank, die
  Aktionskettenbedingung für alles, was Briefkommandos direkt liefern. Eine SQL-Bedingung **ohne**
  `$[patientident]$` prüft praxisweit — dann gilt weiter: liegt irgendein anderer Patient im Zeitfenster,
  feuert das Gate, und die Kette läuft beim auslösenden Patienten.

HQL- bzw. SQL-Abfragen baut der Skill `tomedo-statistik-hql`.

---

## Aktionskettenbedingung

Optionale Bedingung auf Briefkommando-Basis (`bedingungen.md`). Wird **erst bei der Ausführung**
geprüft (Schritt 7), mit dem Patienten und Besuch des Auslösers; Variablen einer Kette gibt es hier
noch nicht. SQL-Bedingung und Aktionskettenbedingung dürfen beide gesetzt sein, dann müssen beide erfüllt sein.

---

## Ausführende Aktionskette / AK-Frage

Der Umschalter rechts wählt das Ziel: **Aktionskette** oder **AK-Frage**; je nach Stellung ist nur die
passende Auswahlliste sichtbar. Eine Frage wird über eine kleine Hilfskette gestartet. Ist die Ziel-Kette
gelöscht, wird der Auslöser übergangen; ist die Ziel-Frage gelöscht, feuert er und meldet „…wurde gelöscht.
Überspringe Eintrag.“

---

## Nutzer-/Arbeitsplatzfilter

### Auswertung

Jede Seite für sich:
- **Arbeitsplatz-Seite erfüllt**, wenn „alle“ angehakt ist **oder** der Arbeitsplatz angehakt ist **oder**
  er Mitglied einer angehakten ArbeitsplatzGruppe ist.
- **Nutzer-Seite** analog mit dem angemeldeten Nutzer und den NutzerGruppen.

Dann die Verknüpfung (genau zwei Möglichkeiten):

| Verknüpfung | Auslöser feuert, wenn |
|---|---|
| **ODER** (Standard) | eine der beiden Seiten erfüllt ist |
| **UND** | beide Seiten erfüllt sind |

### Die ODER-Falle

**Wer bei ODER nur eine Seite einschränkt und auf der anderen „alle“ stehen lässt, schränkt gar nicht ein**
— die „alle“-Seite ist immer erfüllt. Beispiel: „alle Nutzer“ an, Arbeitsplatz „Empfang“ abgewählt → feuert
trotzdem am Empfang.

Richtig einschränken:
- nur nach Arbeitsplatz: Verknüpfung **UND**, Nutzer „alle“, Arbeitsplätze auswählen; oder
- nur nach Nutzer: Verknüpfung **UND**, Arbeitsplatz „alle“, Nutzer bzw. NutzerGruppen auswählen; oder
- bei ODER **beide** Seiten einschränken.

### „umkehren“

Der Knopf dreht die Häkchen der Liste **einmal** um und speichert das Ergebnis als normale Auswahl. Es ist
**kein dauerhafter Ausschluss**: Später angelegte Nutzer oder Arbeitsplätze sind nicht automatisch dabei.
Er ist nur aktiv, wenn „alle“ aus ist; Gruppen haben keinen Umkehren-Knopf. Bei „alle“ sind Liste und
Gruppen ausgegraut.

### Sonderfall Aufgabe

Für das Objekt **Aufgabe** zählen nur direkt angehakte Nutzer und Arbeitsplätze, **keine Gruppen**. Ein
Aufgabe-Auslöser, der nur über NutzerGruppe/ArbeitsplatzGruppe eingeschränkt ist, feuert nie.

Ohne eingestellten Arbeitsplatz bzw. angemeldeten Nutzer erscheint bei jedem Ereignis „Es ist kein
Arbeitsplatz eingestellt!“ bzw. „Es ist kein Nutzer angemeldet!“.

---

## Häufige Auslöser-Patterns

### Pattern 1: Bei Besuchsanlage → Leistungen anlegen
```
Objekt: Besuch
Aktion: Anlegen
Bedingung: [z. B. $[patient_versichertenstatus]$ ist privat]
Aktionskette: [Privatrechnung anlegen + GOÄ-Ziffern]
```

### Pattern 2: ToDo auf aktuell → Kartei öffnen + CKE anlegen
```
Objekt: ToDo
Unter-Typ: [ToDo-Vorlage]
Aktion: ToDo anstehend auf aktuell (Aktion lokal)
Aktionskette: [Karteieintrag anlegen CKE-Typ]
```
Die Kette läuft an dem Arbeitsplatz, an dem das ToDo auf aktuell gesetzt wird.

### Pattern 3: Bei Karteieintrag → Score berechnen
```
Objekt: KarteiEintrag
Unter-Typ: BEH
Aktion: Anlegen
Bedingung: [Diagnose vorhanden + Score heute noch nicht angelegt]
Aktionskette: [Score anlegen]
```
Nicht zusätzlich einen Auslöser „Anlegen oder Ändern …“ für denselben Typ anlegen — beide feuern beim Anlegen.

### Pattern 4: Bei Diagnose → Frage
```
Objekt: ICD-Diagnose
Unter-Typ: [ICD-Code, Pflicht]
Aktion: ICD-Code erstmalig erfasst
Ausführend: AK-Frage [z. B. „Soll ein Score erstellt werden?“]
```
Für eine ganze Diagnosegruppe: Objekt ICD-Gruppe.

### Pattern 5: Neupatient → Marker
```
Kürzel: NEU-ePA-Aufklärung
Objekt: Patient
Aktion: Neuanlage (Aktion lokal, 5 Sekunden zeitversetzt)
Ausführende Aktionskette: ePA_marker_NEU
Arbeitsplätze/Nutzer: alle
```
Neuanlagen aus dem Patientenformular-Eingang feuern ohne die 5 Sekunden.

### Pattern 6: Opioid verordnet → Hinweis oder Doku
```
Objekt: Medikament-ATC-Code
Unter-Typ: N02A            (mehrere: N02A,N02B — ohne Leerzeichen)
Aktion: Verordnen          (je Medikament)  oder  Rezept Vorschau/Drucken (einmal je Rezept)
Aktionskette: [Hinweis / Karteieintrag BTM-Doku / ToDo]
```
Nur Medikamente aus der Arzneimitteldatenbank lösen aus. Für „einmal pro Rezept“ die Aktion
„Rezept Vorschau/Drucken“ wählen, für „je Medikament“ „Verordnen“. **[ungeprüft]**

### Pattern 7: Leistung per Regex
```
Objekt: EBM (Codesuche via Regex)
Unter-Typ: 3523[0-9]       (ganzer Code, Groß/klein beachtet)
Aktion: Anlegen
```

---

## Startpfad außerhalb der Auslöser-Verwaltung: Textbaustein-Antwort

Eine **Antwortoption eines Frage-Antwort-Dialogs** kann eine Aktionskette starten. Der Weg läuft nicht
über einen Auslöser, sondern über das Textbaustein-Makro selbst und taucht deshalb in keiner Auslöser-Liste auf.

```
∆¥ACTION_ANSWER2=<Kettenkürzel>¥Fragetitel<zsMacroAnswerDivider>EINS<zsMacroAnswerDivider>ZWEI∆
```

`<n>` zählt die **Antworten**; der Fragetitel zählt nicht mit. Im Konfigurator heißt die Einstellung „Bei
Auswahl der Antwort soll die Aktionskette mit dem folgenden Kürzel gestartet werden“. **[Messung, 15.09.2026]**
Gestartet werden kann nur eine Aktionskette, keine Aktionskettenfrage (Umweg: Kette mit dem Schritt
„Aktionskettenfrage“).

**Warum das zählt:** Damit wird ein Dokumentationsbaustein zum Workflow-Auslöser. Beispiel: Im psychischen
Befund startet die Antwort „Suizidalität aktiv geäußert“ eine Alarmkette (Aufgabe an den ärztlichen Leiter,
Marker setzen, Wiedervorstellung terminieren).

**Wann die Kette startet:** erst wenn der Dialog mit **OK** abgeschlossen ist, und nur bei geöffnetem
Patienten. **Abbrechen startet nichts** (Fassung 1.4 behauptete das Gegenteil; das war nie gemessen und ist
falsch). Bei verschachtelten Bausteinen werden alle gewählten Ketten gesammelt und nach dem Dialog
nacheinander gestartet. Gibt es das Kürzel nicht, meldet tomedo „Die Aktionskette mit dem Kürzel '…' existiert
leider nicht. Das Makro ist falsch konfiguriert.“ Ketten hier trotzdem idempotent bauen (Guard-Bedingung „Marker
noch nicht gesetzt“), denn derselbe Baustein kann mehrfach eingefügt werden.

Zum Bau des Bausteins selbst → Skill `tomedo-textbausteine`.
