# Die Aktion „KI-Prompt"

Wie Sprachmodell-Aufrufe in Aktionsketten eingebunden werden, was sie koennen,
und die eine Eigenschaft, die jede Vollautomatisierung begrenzt.

**Statuskennzeichnung mit Quellendatum.**
`[Hersteller, TT.MM.JJJJ]` = Onlinehilfe oder zollsoft-Aussage ·
`[Fremdbericht, TT.MM.JJJJ]` = Forums-Erfahrungsbericht, nicht reproduziert ·
`[Referenzinstallation, TT.MM.JJJJ]` = eigene Erhebung · `[plausibel]` = abgeleitet.

---

## 1 · Was die Aktion ist

Die Aktion `KI-Prompt` bringt die KI-Funktionen des KarteiChats in die
Aktionskette. Wiederkehrende Aufgaben — Laborwerte auswerten, Karteieintraege
anlegen, Erinnerungen erstellen — laufen damit patientenbezogen und
automatisiert. [Hersteller, 11.09.2026]

**Wichtig fuer die Einordnung:** Das ist keine eigene Engine. Es ist derselbe
Agent mit derselben Werkzeugebene wie im Chat. Alles, was fuer den KarteiChat
gilt — Werkzeugzugriff, Quellenverknuepfung, Zweckbestimmung — gilt hier
ebenfalls. Fuer die Werkzeugebene siehe
`karteichat-prompting/references/llm-toolebene.md`.

---

## 2 · Einrichtung in drei Schritten

### Schritt 1 — Prompt freigeben

Ein Prompt steht in der Aktionskette **erst zur Verfuegung, wenn er in der
Promptverwaltung fuer Aktionsketten freigegeben wurde.**
[Hersteller, 11.09.2026]

Pflegeort: Verwaltung › Sprechstunden-Assistent › KI-Assistenten-Verwaltung.

> Prompts sind Textbausteine. Es lassen sich **nur reine** Textbausteine
> verwenden — Frage-Antwort-Makros und Auswahl-Makros werden nicht ausgefuehrt,
> sondern als Rohtext weitergereicht. [Hersteller, 11.09.2026]
>
> Und: Ein in der Promptverwaltung geloeschter Eintrag loescht den
> **Textbaustein**. [Hersteller, 11.09.2026]

### Schritt 2 — Aktion einfuegen

In der Aktionskette die Aktion `KI-Prompt` waehlen und aus der Liste der
freigegebenen Prompts den gewuenschten auswaehlen. [Hersteller, 11.09.2026]

### Schritt 3 — Ergebnis weiterreichen

Das Ergebnis des ausgefuehrten Prompts laesst sich **in einem eigenen Kommando
speichern** und damit an nachfolgende Schritte der Kette weitergeben. Diese
Folgeschritte koennen selbst wieder KI-Prompts sein, die die Daten
weiterverarbeiten. [Hersteller, 11.09.2026]

Der Hersteller empfiehlt, in der **Ergebnis-Beschreibung** praezise zu
formulieren, was zurueckkommen soll — je genauer, desto verwertbarer die Daten
fuer die Folgeschritte. Als Beispiel wird eine Vorgabe genannt, die nur zwei
bestimmte Laborwerte aus dem letzten Labor zurueckgeben laesst.
[Hersteller, 11.09.2026]

---

## 3 · Der Bestaetigungsdialog

> **Auch bei Ausfuehrung durch eine Aktionskette kann eine Zustimmung des
> Nutzers erforderlich werden. Der Nutzer wird dann mit einem
> Bestaetigungsdialog darauf hingewiesen, und die Kette laeuft nur weiter, wenn
> zugestimmt wird. Dieser Dialog muss aus Datenschutzgruenden immer manuell
> bestaetigt werden.** [Hersteller, 11.09.2026]

**Das ist die wichtigste Planungsgrenze dieser Aktion.** Konsequenzen:

| Vorhaben | Tragfaehig? |
|---|---|
| Interaktive Kette am Arbeitsplatz, Nutzer sitzt davor | ja |
| Kette mit Popover-Schritten, ohnehin blockierend | ja — der Dialog reiht sich ein |
| Naechtlicher Stapellauf ohne Aufsicht | **nein, solange ungeklaert** |
| Statistik-Ergebnisliste zeilenweise abarbeiten | **nur mit Aufsicht** [plausibel] |

**Offen und vor jeder Batch-Planung zu klaeren:** unter welchen Bedingungen der
Dialog erscheint. Der Hersteller schreibt „kann erforderlich werden", nennt die
Bedingung aber nicht. Ohne diese Antwort ist kein unbeaufsichtigter Betrieb
planbar. [Referenzinstallation, 13.09.2026]

Wer unbeaufsichtigt fahren muss, nimmt den Skript-Pfad ueber den
LLM-Service-Endpunkt — dort gibt es keinen Dialog, dafuer keine Werkzeuge.
Siehe `tomedo-navigation/references/applescript-rezeptbuch.md`.

---

## 4 · Ergebnisweitergabe gegen Marker-Bastelei

Im Forum kursiert ein Muster, das die fehlende Werkzeugebene des Skript-Pfads
per selbstgebautem Ausgabeformat nachbaut: Das Modell gibt Werte zwischen
selbstdefinierten Begrenzern aus, eine Regex zieht sie heraus, die Kette
schreibt sie zurueck. [Fremdbericht, 10.09.2026]

**Auf dem KI-Prompt-Pfad ist das nicht noetig.** Die Ergebnisweitergabe per
Kommando aus Schritt 3 leistet dasselbe mit Bordmitteln.
[Hersteller, 11.09.2026]

| Aspekt | Ergebnis-Kommando | Marker plus Regex |
|---|---|---|
| Aufwand | Feld ausfuellen | Prompt-Design, Regex, Fehlerbehandlung |
| Bruchstelle | Beschreibung zu vage | Modell laesst Begrenzer weg |
| Modellwahl | ueber den Support | frei pro Anfrage |
| Unbeaufsichtigt | Dialog moeglich | ja |

**Regel:** Vor jedem Nachbau des Marker-Pfads pruefen, ob die
Ergebnisweitergabe reicht. Der Marker-Pfad bleibt richtig, wenn freie
Modellwahl oder unbeaufsichtigter Betrieb gebraucht wird.

---

## 5 · Prompt-Design fuer Ketten

Ein Prompt in der Kette hat kein Gegenueber, das nachfragt. Deshalb gelten die
Regeln aus `karteichat-prompting` hier **strenger**:

1. **Eine Aufgabe pro Prompt.** Mehrere Aufgaben lieber als mehrere
   KI-Prompt-Schritte mit Ergebnisweitergabe.
2. **Typdefinition ueber Eintrags-Bezeichnungen**, wo ein Fachbegriff vorkommt
   — der wirksamste Baustein. [Referenzinstallation, 08.09.2026]
3. **Guard-Satz**, wenn Anker gesetzt werden: ein leerer Anker ist der
   gefaehrlichste Fehler. [Referenzinstallation, 08.09.2026]
4. **Ergebnis-Beschreibung so eng wie moeglich.** Sie ist der Vertrag mit dem
   Folgeschritt.
5. **Keine Formulierung, die als Schreibauftrag lesbar ist**, wenn nur gelesen
   werden soll — die Werkzeugebene kann generisch Datenbankobjekte anlegen und
   aendern. [plausibel]
6. **Quellenmarker entfernen lassen**, bevor ein Ergebnis in einen
   Karteieintrag geschrieben wird — die Schreib-Tools verlangen Inhalt ohne
   Verweise. [Export, 13.09.2026]

---

## 6 · Belegte Systemgrenzen im Umfeld

| Grenze | Status |
|---|---|
| Bestaetigungsdialog muss manuell bestaetigt werden | [Hersteller, 11.09.2026] |
| „Zurueckschreiben" wirkt nur auf den **juengsten** Karteieintrag | [Fremdbericht, 10.09.2026] |
| Karteieintragstyp und -datum sind per Aktionskette **nicht** aenderbar | [Fremdbericht, 10.09.2026] |
| Nur reine Textbausteine als Prompts | [Hersteller, 11.09.2026] |
| Eintrag bearbeiten heisst **vollstaendig ersetzen**, nicht ergaenzen | [Export, 13.09.2026] |

Die beiden Fremdberichts-Zeilen sind Anwendererfahrung, nicht
Herstellerzusage — vor einem Bau, der darauf aufsetzt, selbst pruefen.

---

## 7 · Qualitaetsvorbehalt aus dem Forum, richtig eingeordnet

Ein Anwender berichtet, dieselbe Aufgabe habe ueber den KI-Prompt deutlich
schlechter gelaufen als ueber einen direkten API-Aufruf — Halluzinationen,
Meldungen ueber angeblich fehlenden Text, drei Aufrufe mit drei verschiedenen
Ergebnissen. [Fremdbericht, 09/2026]

**Der Vergleich ist konfundiert.** Vermengt sind mindestens drei Faktoren:
das Modell (er nutzt `gemini-2.5-pro`, der KI-Prompt das intern gesetzte), die
Orchestrierung, und der Prompt-Zustand (nach eigener Angabe „gering
abgewandelt"). Eine eigene Messung am Endpunkt zeigt, dass der Modellwechsel
vor allem **Konstanz** bringt, nicht Fachqualitaet. [Referenzinstallation, 13.09.2026]

**Fazit:** Der Bericht taugt als Hinweis, nicht als Urteil ueber die Aktion.
Wer bessere Konstanz braucht und die Werkzeugebene behalten will, fragt beim
Support nach dem Modellwechsel, statt den Pfad zu verlassen.
[Hersteller, 11.09.2026]

---

## 8 · Pruefliste vor Produktivsetzung

```
[ ] 1. Prompt in der Promptverwaltung fuer Aktionsketten freigegeben
[ ] 2. Prompt ist ein reiner Textbaustein, keine Makros enthalten
[ ] 3. Genau eine Aufgabe im Prompt
[ ] 4. Typdefinition vorhanden, wo ein Fachbegriff vorkommt
[ ] 5. Guard-Satz vorhanden, wenn Anker gesetzt sind
[ ] 6. Ergebnis-Beschreibung eng formuliert
[ ] 7. Ergebnis-Kommando gesetzt, wenn Folgeschritte es brauchen
[ ] 8. Geprueft, ob ein Bestaetigungsdialog erscheint — und ob das zum
       geplanten Betriebsmodus passt
[ ] 9. Juengster-Eintrag-Bedingung beruecksichtigt, falls zurueckgeschrieben wird
[ ] 10. Mit [Testen] gefahren, mindestens zwei Laeufe, Ergebnisse gediffed
```

---

*Erhoben 09/2026. Quellen: Onlinehilfe Kartei-Chat, Abschnitt KI-Prompt in
Aktionsketten (Stand 11.09.2026); Forum-Threads 124592 und 125081;
Tool-Export der eigenen Installation; A/B-Messreihe vom 13.09.2026.*
