# Vollständige Referenz: Aktionsketten-Bedingungen

Admin → Aktionsketten → Aktionsketten-Bedingungen, Fenster „Verwaltung Bedingungen für Aktionsketten“.
Stand: 22.10.2026.
Bedingungen setzen Grundkenntnisse in Briefkommandos voraus (Skill `tomedo-kommandos`).

**Kennzeichnung:** ohne Zusatz = belegt · **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt —
vor dem Einsatz an einer Testakte prüfen.

---

## Aufbau einer Bedingung — alle Felder

```
Verwaltung Bedingungen für Aktionsketten
├── Links: Baum mit Gruppen und Elementen
│   └── Element · Gruppe · Kopie · − · A..Z↓ · Suche · auf-/zuklappen · ☐ gelöschte anzeigen
│
└── Rechts: Bedingung
    ├── Kürzel · Name
    ├── Bedingungseditor
    │   ├── oberste Zeile: [Eines | Alle | Keines] der folgenden Einträge ist/sind wahr
    │   └── Zeilen: [Text links] | [Relation] | [Text rechts] | [+] [−]
    ├── Hinweis: „Durch drücken der alt-Taste (opt, option, ⌥) kann man logische
    │            Verschachtelungen erstellen“
    ├── [Kommandos] — Liste der Briefkommandos zum Einfügen
    ├── [Favoriten] — ganze Bedingungen einfügen, eigene Favoriten speichern/verwalten
    ├── [Testen] · Test-Patientensuche · „Testpatient: …“ [x]
    ├── Ladeoptionen (drei Kästchen, s. u.)
    └── ☐ gelöscht
```

---

## Verknüpfung: UND, ODER, NICHT

Die **oberste Zeile** des Editors legt fest, wie die Zeilen darunter verknüpft sind:

| Auswahl | Bedeutung |
|---|---|
| **Alle** der folgenden Einträge sind wahr | UND |
| **Eines** der folgenden Einträge ist wahr | ODER |
| **Keines** der folgenden Einträge ist wahr | NICHT (keine Zeile darf zutreffen) |

- **Mehrere Zeilen sind nicht automatisch UND-verknüpft.** Maßgeblich ist die Auswahl in der obersten
  Zeile. Eine neue, leere Bedingung beginnt dort mit **„Eines“ (ODER)**. Wer UND will, stellt auf
  „Alle“ um. **[ungeprüft]** — vor dem ersten Einsatz mit „Testen“ kontrollieren: die Testausgabe zeigt
  die gespeicherte Bedingung mit `AND` bzw. `OR`.
- **Verschachtelung:** Mit gedrückter **⌥-Taste** wird aus dem [+] ein Knopf für eine Unter-Verknüpfung
  mit eigener Auswahl Eines/Alle/Keines. So entstehen Klammern, z. B. `A UND (B ODER C)`.

```
Alle der folgenden Einträge sind wahr
├── $[palter]$                       ist größer als oder gleich   18
└── Eines der folgenden Einträge ist wahr        (⌥ + [+])
    ├── $[patient_versichertenstatus]$  ist  privat
    └── $[istMarkerGesetzt BG]$         ist  1
```

---

## Linke und rechte Seite

Beide Seiten sind freie Textfelder. **Beide werden als Briefkommando-Text aufgelöst** — auch der
Vergleichswert rechts. Links steht in der Praxis genau ein Briefkommando.

### Syntax

```
$[kommando parameter]$        Briefkommando
$[&p.attribut]$               Keypath auf den Patienten (p) — z. B. $[&p.alter]$
$[&besuch.attribut]$          Keypath auf den Besuch                       [ungeprüft]
```

### Kontext: Patient und Besuch — mehr nicht

Ausgewertet wird mit dem Patienten und dem Besuch des Auslösers bzw. der Kette. **Nur im Kettenschritt
„Aktionskettenbedingung“** stehen zusätzlich die Variablen und Vorbefüllungen der laufenden Kette und die
Werte von CKE-Feldern zur Verfügung, die in derselben Kette gerade angelegt wurden (`$[Feldname]$`).

Kommandos, die einen Brief-, Rechnungs- oder Terminkontext brauchen (z. B. Rechnungssummen,
`selektierterTermin`), liefern im Auslöser, in Aufgaben und im Test **vermutlich leer**. **[ungeprüft]**
Kommandos, die es nur in Word-Briefvorlagen gibt (z. B. `a` für die Anrede-Auswahl, `medikamentenplan`), lösen in
Bedingungen gar nicht auf. **[ungeprüft]** Welche das sind → Skill `tomedo-kommandos`.

### Belegte Kommandos für Bedingungen

| Kommando | liefert |
|---|---|
| `$[palter]$` oder `$[&p.alter]$` | Alter in Jahren |
| `$[patient_geschlecht]$` | „männlich“ / „weiblich“ (Langtext) |
| `$[patient_versichertenstatus]$` | „privat“ / „gesetzlich“ |
| `$[istMarkerGesetzt NAME]$` | „1“ / „0“; Name exakt wie angezeigt, nur sichtbare Marker |
| `$[formularEintrag …]$` | Wert aus einem Formular |
| `$[karteiEintragWert …]$` | Wert aus einem Karteieintrag |
| `$[d …]$` | **Datums-Kommando** (kein Diagnose-Check!); liefert bei fehlendem Eintrag „-“ |

**Berichtigt gegenüber früheren Fassungen:** `$[&p.geschlecht]$`, `$[&p.versicherungsart]$`,
`$[&p.selektierterBesuch.…]$` und `$[&heute]$` lösen **nicht** auf — der Patient
hat diese Attribute nicht (Geschlecht liegt in den Patientendetails), einen Keypath `heute` gibt es nicht.
Stattdessen die Kommandos der Tabelle oben nehmen. Ein nicht auflösbarer Keypath liefert den Text
„Fehler: Keypath … konnte nicht aufgelöst werden!“ — die Bedingung läuft dann still mit diesem Text
weiter. Darum jede Bedingung mit „Testen“ prüfen: dort steht der aufgelöste Wert. Die Besuchsfelder für den Datenaustausch zwischen Ketten heißen im Datenmodell
`boolCol1/2`, `stringCol1/2` und `infoText`. Die Syntax der Kommandos selbst → Skill `tomedo-kommandos`.

---

## Relationen — 16, in der Reihenfolge des Menüs

| # | Relation | Vergleich |
|---|---|---|
| 1 | `ist` | Textgleichheit |
| 2 | `ist nicht` | Text ungleich |
| 3 | `beginnt mit` | Text-Präfix |
| 4 | `beginnt nicht mit` | Negation |
| 5 | `endet mit` | Text-Suffix |
| 6 | `endet nicht mit` | Negation |
| 7 | `enthält` | Teilstring |
| 8 | `enthält - Groß-/kleinschreibungs-insensitiv` | Teilstring, Groß/klein egal |
| 9 | `enthält einen der Einträge in (kommasepariert)` | Teilstring je Listeneintrag, ODER |
| 10 | `enthält nicht` | Negation von 7 |
| 11 | `enthält nicht - Groß-/kleinschreibungs-insensitiv` | Negation von 8 |
| 12 | `enthält keinen der Einträge in (kommasepariert)` | Negation von 9 |
| 13 | `ist kleiner als` | Zahl oder Datum |
| 14 | `ist kleiner als oder gleich` | Zahl oder Datum |
| 15 | `ist größer als` | Zahl oder Datum |
| 16 | `ist größer als oder gleich` | Zahl oder Datum |

### Vergleichslogik im Detail

**Textvergleiche (1–12):**
- **Groß-/Kleinschreibung zählt** bei allen außer 8 und 11.
- **Akzente zählen immer**, auch bei 8 und 11: „ä“ ≠ „a“, „Müller“ ≠ „Muller“.
- **Nichts wird getrimmt.** Ein Leerzeichen oder Zeilenumbruch im Kommandoergebnis oder im
  Vergleichswert lässt `ist` scheitern. `ist` vergleicht reinen Text: „65“ ≠ „65.0“.
- **Kommalisten (9, 12):** Die rechte Seite wird an Kommas geteilt, **jeder Eintrag wird getrimmt** —
  Leerzeichen nach dem Komma schaden also nicht. Jeder Eintrag ist eine **Teilstring-Suche mit
  Groß-/Kleinschreibung**: `AOK` trifft auch „AOK PLUS“, `aok` trifft „AOK“ nicht. Geteilt wird vor der
  Kommando-Auflösung: ein Kommando rechts, das selbst eine Kommaliste liefert, wird nicht als Liste gelesen.
- `enthält` mit leerem Vergleichswert ist falsch, `enthält nicht` mit leerem Wert also immer wahr.
  **[ungeprüft]**

**Zahl- und Datumsvergleiche (13–16):** Jede Seite wird nacheinander gelesen als
1. Datum `TT.MM.JJJJ`, dann `TT.MM.JJJJ HH:mm`, dann `TT.MM.JJJJ HH:mm:ss` → chronologischer Vergleich,
2. Zahl (getrimmt, Systemformat),
3. sonst führende Zahl; **Text ohne Zahl, „-“ und leer werden 0**.

Folge: **`leer ist kleiner als 5` ist wahr.** Wer „Wert fehlt“ ausschließen will, braucht eine zweite
Zeile (z. B. `ist nicht` leer bzw. `ist nicht -`) unter „Alle“. Jahreszahlen oder `JJJJMMTT`-Datumswerte
lassen sich als Zahl vergleichen — so arbeiten auch die mitgelieferten Favoriten.
Dezimalkomma unter deutscher Systemsprache („12,5“ gegen „12.5“): **[ungeprüft]**.

### Sonderfälle

| Fall | Verhalten |
|---|---|
| Bedingung ganz leer | Meldung „Die Aktionskettenbedingung macht Probleme.“ — gilt dann als **erfüllt** |
| Unbekanntes Kommando | Meldung „Die Sequenz … konnte nicht aufgelöst werden.“, der Text `$[…]$` bleibt wörtlich stehen |
| Text „ LIKE “ wörtlich in einem Kommando oder Vergleichswert | wird intern ersetzt — vermeiden |

---

## Favoriten — ganze Bedingungen, keine Kommandos

Der Knopf **„Favoriten“** fügt **fertige Bedingungen** ein, keine Briefkommandos (dafür gibt es den
Knopf **„Kommandos“**). Eine leere Bedingung übernimmt den Favoriten; sonst wird er **mit UND hinten
angehängt**.

Menü des Knopfs: **Mitgelieferte Favoriten** · **Eigene Favoriten** · „Aktuelle Bedingung als Favorit
speichern …“ · „Eigene Favoriten verwalten …“.

**Mitgelieferte Favoriten** (fest im Programm, als Vorlagen zum Anpassen):

| Gruppe | Favoriten |
|---|---|
| Patientendaten | ist männlich · ist weiblich · Alter < 6 · 6–59 · > 59 Jahre |
| Abrechnung | Versichertenstatus privat · gesetzlich |
| Leistungen | eine Ziffer im Kalenderjahr höchstens einmal · bereits · noch nicht · zuletzt vorletztes Jahr oder nie |
| Diagnosen | eine Diagnose im Quartal enthalten · nicht gefunden |
| Karteieinträge | Eintrag mit Text am Tageslistendatum ja/nein · Eintrag älter als zwei Jahre · kein Eintrag oder älter |
| Marker | ist Raucher · Marker „arzt-direkt App“ gesetzt / nicht gesetzt |

Ziffer, Diagnose, KE-Kürzel und Text nach dem Einfügen anpassen.

**Eigene Favoriten** (seit Herbst 2026): Fenster „Eigene Favoriten für Aktionskettenbedingungen“ mit
Ordnern, Name und eigenem Bedingungseditor. Sie werden über den Server für alle Arbeitsplätze
bereitgestellt. **[ungeprüft]**

---

## Ladeoptionen — was vorher geladen wird

| Kästchen | lädt vollständig |
|---|---|
| Lade alle Karteieinträge/Formulare vor Ausführung (kann signifikant lange dauern) | Karteieinträge, Formulare |
| Lade alle Scheine/Rechnungen vor Ausführung (kann signifikant lange dauern) | KV-, KZV-, HZV-Scheine, Rechnungen |
| Lade alle MediVerordnungen/MediPläne vor Ausführung (kann signifikant lange dauern) | Verordnungen, Medikamentenpläne |

- **Warum es die Optionen gibt:** Aktionsketten starten schon bei teilweise geladener Akte. Ist das
  teilweise Laden in der Praxis eingeschaltet (Systemeinstellung), lädt tomedo zunächst höchstens die
  neuesten **100 Karteieinträge, 20 Formulare, 10 Verordnungen und 10 Medikamentenpläne**. Eine
  Bedingung, die ältere Einträge prüft, sieht sie ohne Option nicht.
- **Ladezeit hängt an der Größe der einzelnen Akte**, nicht an der Größe der Datenbank. Ist die Akte schon
  geladen, wird nur das Fehlende nachgeholt.
- **Die Optionen wirken nur im Auslöser und im Kettenschritt „Aktionskettenbedingung“.** Der Knopf
  „Testen“, Aufgaben, Selektivverträge und die eAU-Vorschaltung beachten sie nicht (Aufgaben laden fest
  Karteieinträge und Formulare).
- Stammdaten (Alter, Geschlecht, Versichertenstatus, Marker) brauchen keine Option.

---

## Wo eine Bedingung wirkt

| Ort | Verhalten |
|---|---|
| **Aktionsketten-Auslöser**, Feld „Aktionskettenbedingung“ | Geprüft, wenn der Auslöser in der Warteschlange an der Reihe ist — **vor** der Wartezeit. Falsch → keine Kette. **Eine gelöschte Bedingung wird hier weiter ausgewertet** — erst aus dem Auslöser nehmen, dann löschen. |
| **Kettenschritt „Aktionskettenbedingung“** | Wahr → die gewählte Kette wird eingereiht; falsch → nichts, nächster Schritt. **Es gibt keinen Sonst-Zweig** (für „sonst“: zweiter Schritt mit der Gegen-Bedingung). Gelöschte Bedingung → Meldung, Schritt übersprungen. Zeitpunkt der eingereihten Kette: Kästchen am Schritt, siehe `fragen.md`, Abschnitt „Warteschlange“. |
| Andere Schritt-Typen | haben **keine** eigene Bedingung. Bedingte Schritte baut man über eine Unterkette hinter einem Schritt „Aktionskettenbedingung“. |
| **Aufgaben: Abschlussbedingungen** (je Bedingung optional ein Hinweis) | Beim Setzen auf erledigt; nicht erfüllt → „Die Aufgabe kann nicht abgeschlossen werden, weil nicht alle Abschlussbedingungen erfüllt sind:“ plus Hinweis |
| **Selektivvertrag** (sonstige Verträge beim Nutzer), Feld „Bedingung“ | Voraussetzung für die (Auto-)Einschreibung |
| **eAU**: vorgeschaltete Bedingung | Falsch → „Die eAU kann wegen der Aktionskettenbedingung '…' nicht erstellt werden.“ Menüweg der Einstellung: **[ungeprüft]** |

In Auswahllisten erscheinen nur nicht gelöschte Bedingungen; im Kettenschritt mit Kürzel, in Aufgaben
mit Namen.

---

## Testen

- Mit **Testpatient**: Auswertung mit dem Besuch von heute; die Kartei wird bei Bedarf geöffnet.
- **Ohne Testpatient**: die zuletzt benutzte Kartei; ohne offene Kartei „Es ist keine Kartei geöffnet.“
- Das Ergebnisfenster „Test Aktionskettenbedingung“ zeigt die gespeicherte Bedingung, die Fassung **nach
  der Kommando-Ersetzung mit den aufgelösten Werten** und das Ergebnis ✅/❌. Damit sieht man sofort,
  welchen Wert ein Kommando wirklich liefert.
- **Grenzen des Tests:** keine Ladeoptionen, keine Kettenvariablen, keine frisch angelegten CKE-Werte.
  Was im Test klappt, kann im Kettenschritt anders ausfallen und umgekehrt.

**Praxis-Regel:** Jede Bedingung vor dem Einsatz mit „Testen“ gegen einen passenden und einen nicht
passenden Testpatienten prüfen.

## Protokoll

Menü **Hilfe › Logs › Loglevels Feinschaltung**, Eintrag **„LogLevelAktionsKettenBedingung“**. Das Log
zeigt je Auswertung den Namen, die gespeicherte Bedingung, die Fassung nach der Kommando-Ersetzung und
das Ergebnis. Ergänzend: „LogLevelBriefkommandos“ (jede einzelne Ersetzung) und „LogLevelAktionsKetten“
(Kettenstart durch Auslöser).

## Weitere Bedienelemente

- **Kürzel:** doppeltes Kürzel ergibt nur einen Hinweis, keine Sperre.
- **Kopie** übernimmt alles außer dem Kürzel.
- **Gruppe:** Ordner ohne Bedingung.
- **Hilfe-Knopf:** öffnet das Handbuch zu den Bedingungen.

---

## Praxis-Beispiele

### Beispiel 1: Alter ab 65
```
Kürzel: ALTER_AB_65
Oberste Zeile: Alle
Zeile 1: $[palter]$  |  ist größer als oder gleich  |  65
Ladeoptionen: keine
```

### Beispiel 2: Privat- oder BG-Fall
```
Kürzel: PRIVAT_ODER_BG
Oberste Zeile: Eines
Zeile 1: $[patient_versichertenstatus]$  |  ist  |  privat
Zeile 2: $[istMarkerGesetzt BG]$          |  ist  |  1
```
(Marker „BG“ als Beispiel — Name genau wie in der eigenen Installation.)

### Beispiel 3: Neupatient bei bestimmter Kasse laut Patientenformular
```
Kürzel: NEUPAT_KASSE
Oberste Zeile: Alle
Zeile 1: $[formularEintrag PatF-…]$  |  enthält einen der Einträge in (kommasepariert)  |  Barmer, AOK
Ladeoptionen: ☑ Karteieinträge/Formulare
```
Teilstring mit Groß-/Kleinschreibung: „AOK“ trifft auch „AOK PLUS“.

### Beispiel 4: Wert vorhanden UND unter Grenze
```
Oberste Zeile: Alle
Zeile 1: $[karteiEintragWert …]$  |  ist nicht            |  (leer lassen)
Zeile 2: $[karteiEintragWert …]$  |  ist kleiner als      |  5
```
Ohne Zeile 1 wäre die Bedingung auch bei fehlendem Wert wahr (leer = 0). Ob der Editor einen leeren
Vergleichswert speichert, mit „Testen“ prüfen; sonst gegen „-“ oder mit `beginnt mit` und einer Ziffer
arbeiten. **[ungeprüft]**

### Beispiel 5: Guard gegen Doppelausführung
Die Kette setzt am Ende einen Marker; die Bedingung prüft `$[istMarkerGesetzt NAME]$ ist 0`. Der
Marker rechnet, die Kette handelt (Skill `tomedo-marker`).

---

## Synergie mit dem HQL-Statistik-Skill

Briefkommandos in Bedingungen und HQL-Abfragen greifen teils auf dieselben Daten zu, aber in anderer
Syntax. Was über Briefkommandos nicht geht, prüft die **SQL-Bedingung im Auslöser** — sie bekommt den
auslösenden Patienten über `$[patientident]$` (siehe `ausloser.md`). Abfragen baut der Skill
`tomedo-statistik-hql`.
