# Vollständige Referenz: Aktionsketten-Bedingungen

Extrahiert aus der tomedo-Oberfläche (Admin → Aktionsketten → Aktionsketten-Bedingungen).
Stand: März 2026. Bedingungen erfordern Grundkenntnisse in Briefkommandos.

---

## Aufbau einer Bedingung — Alle Felder

```
Verwaltung Bedingungen für Aktionsketten
├── Links: Baumstruktur mit Gruppen und Elementen
│   ├── Suche
│   ├── > aufklappen / v zuklappen
│   └── Gruppen mit Elementen (z.B. "#_NichtLoeschen (3)", "Allgemein (2)")
│
├── Rechts: Bedingung (Detail)
│   ├── Kürzel: [eindeutiges Kürzel]
│   ├── Name: [beschreibender Name]
│   │
│   ├── Bedingungszeilen (Tabelle, mehrere Zeilen möglich):
│   │   ├── Zeile: [Kommando] | [Relation] | [Vergleichswert] | [+] [-]
│   │   └── (weitere Zeilen = UND-Verknüpfung)
│   │
│   ├── Buttons:
│   │   ├── [Favoriten] — Briefkommando-Favoriten einfügen
│   │   ├── [Testen] — Bedingung gegen Testpatienten auswerten
│   │   └── Testpatient: "Testpatient: [Name] - Nr.: [ID]"
│   │
│   ├── Hinweis (blau):
│   │   └── "Durch drücken der alt-Taste (opt, option, ⌥) kann man
│   │        logische Verschachtelungen erstellen"
│   │
│   └── Datenlade-Optionen (Checkboxen):
│       ├── ☐ Lade alle Karteieinträge/Formulare vor Ausführung
│       │     (kann signifikant lange dauern)
│       ├── ☐ Lade alle Scheine/Rechnungen vor Ausführung
│       │     (kann signifikant lange dauern)
│       └── ☐ Lade alle MediVerordnungen/MediPläne vor Ausführung
│             (kann signifikant lange dauern)
```

---

## Bedingungszeilen — Aufbau

Jede Zeile besteht aus drei Teilen:

```
[Kommando/Briefbefehl]  |  [Relation]  |  [Vergleichswert]
```

**Mehrere Zeilen** = UND-Verknüpfung (alle müssen erfüllt sein).

**Logische Verschachtelungen** (ODER, Klammern) können per **Alt-Taste (⌥)** beim Hinzufügen erstellt werden.

---

## Kommando-Feld (linke Spalte)

Das Kommando-Feld enthält **Briefkommandos** — dieselbe Syntax wie in tomedo-Briefvorlagen. Die Kommandos greifen auf Patientendaten, Besuchsdaten, Scheine, Rechnungen, Karteieinträge und Formulare zu.

### Syntax

Briefkommandos haben die Form:
```
$[kommando parameter]$
```

oder bei Keypaths:
```
$[&p.keypath]$
```

### Häufig verwendete Kommandos in Bedingungen

| Kommando | Beschreibung | Beispiel-Wert |
|---|---|---|
| `$[&p.alter]$` | Alter des Patienten in Jahren | 65 |
| `$[&p.geschlecht]$` | Geschlecht | m / w / d |
| `$[&p.versicherungsart]$` | Versicherungsart | GKV / PKV |
| `$[&p.selektierterSchein.scheinUntergruppe]$` | Scheinart | – |
| `$[&p.selektierterBesuch.info]$` | Besuch-Info-Feld | Freitext |
| `$[&p.selektierterBesuch.bool1]$` | Besuch Bool1 | 1 / 0 |
| `$[&p.selektierterBesuch.string1]$` | Besuch String1 | Freitext |
| `$[formularEintrag FORMULARNAME]$` | Wert aus Patientenformular | z.B. "Barmer" |
| `$[pr_rechnungsSummeReal]$` | Summe der Privatrechnung | z.B. 1000 |
| `$[karteiEintragWert TYP FELD]$` | Wert aus Karteieintrag | variabel |
| `$[d ICD-CODE]$` | Prüft ob Diagnose vorhanden | 1 / 0 / leer |
| `$[if ...]$...$[/if]$` | Bedingte Auswertung | Text oder leer |

**Praxis-Tipp:** Der Button "Favoriten" öffnet eine Auswahlliste häufig genutzter Briefkommandos. Die vollständige Kommando-Referenz findet sich im Handbuch unter Briefschreibung → Kommandos → Liste der Briefkommandos.

**Praxis-Tipp:** Kommandos aus Briefvorlagen können 1:1 in Bedingungen verwendet werden. Wenn ein Kommando in einem Brief funktioniert, funktioniert es auch in einer Bedingung.

---

## Relationen (mittlere Spalte)

Vollständige Liste aller verfügbaren Vergleichsoperatoren:

### Gleichheit / Ungleichheit
| Relation | Beschreibung | Hinweis |
|---|---|---|
| `ist` | Exakter Vergleich (Zeichenkette oder Zahl) | ⚠ Leerzeichen-sensitiv! |
| `ist nicht` | Ungleich | |

### String-Vergleiche (Anfang/Ende)
| Relation | Beschreibung |
|---|---|
| `beginnt mit` | Kommando-Ergebnis beginnt mit Vergleichswert |
| `beginnt nicht mit` | Negation |
| `endet mit` | Kommando-Ergebnis endet mit Vergleichswert |
| `endet nicht mit` | Negation |

### Enthält-Vergleiche
| Relation | Beschreibung | Hinweis |
|---|---|---|
| `enthält` | Teilstring-Suche | Case-sensitiv! |
| `enthält - Groß-/kleinschreibungs-insensitiv` | Teilstring-Suche ohne Beachtung der Groß-/Kleinschreibung | Empfohlen bei Freitext |
| `enthält einen der Einträge in (kommasepariert)` | Prüft ob Ergebnis EINEN der kommaseparierten Werte enthält | z.B. Vergleichswert: "Barmer,AOK,TK" |
| `enthält nicht` | Negation von enthält | |
| `enthält nicht - Groß-/kleinschreibungs-insensitiv` | Negation case-insensitiv | |
| `enthält keinen der Einträge in (kommasepariert)` | Keiner der kommaseparierten Werte enthalten | |

### Numerische Vergleiche
| Relation | Beschreibung |
|---|---|
| `ist kleiner als` | Numerisch < |
| `ist kleiner als oder gleich` | Numerisch ≤ |
| `ist größer als` | Numerisch > |
| `ist größer als oder gleich` | Numerisch ≥ |

**Gesamt: 16 Relationen**

### Wichtige Hinweise zu Relationen

- **"ist" ist leerzeichen-sensitiv:** Ein unsichtbares Leerzeichen im Vergleichswert führt dazu, dass die Bedingung nie erfüllt ist. Im Zweifel lieber "enthält" verwenden.
- **Numerische Vergleiche:** Funktionieren nur wenn das Kommando-Ergebnis eine Zahl liefert. Briefkommandos liefern Strings — tomedo konvertiert automatisch, aber bei gemischten Ergebnissen (z.B. "1.234,56") kann es Probleme geben.
- **Kommaseparierte Listen:** Bei "enthält einen der Einträge" die Werte mit Komma trennen, KEINE Leerzeichen nach dem Komma.

---

## Datenlade-Optionen

Drei Checkboxen am unteren Rand des Bedingungsfensters steuern, welche Daten VOR der Bedingungsauswertung geladen werden:

| Checkbox | Wann aktivieren? | Performance-Impakt |
|---|---|---|
| Lade alle Karteieinträge/Formulare | Wenn Bedingung auf KE-Inhalte oder Formularwerte zugreift (z.B. `$[karteiEintragWert ...]$`, `$[formularEintrag ...]$`) | Kann signifikant lange dauern |
| Lade alle Scheine/Rechnungen | Wenn Bedingung auf Schein-/Rechnungsdaten zugreift (z.B. `$[pr_rechnungsSummeReal]$`) | Kann signifikant lange dauern |
| Lade alle MediVerordnungen/MediPläne | Wenn Bedingung auf Medikamentendaten zugreift | Kann signifikant lange dauern |

**Praxis-Tipp:** Nur die wirklich benötigten Daten laden! Bei großen Datenbanken (>10.000 Patienten) kann das Laden ALLER Karteieinträge mehrere Sekunden dauern und die Praxisarbeit spürbar verlangsamen. Wenn die Bedingung nur auf Patientenstammdaten zugreift (Alter, Geschlecht, Versicherungsart), sind KEINE Datenlade-Optionen nötig.

---

## Testen-Funktion

Unten im Fenster gibt es:
- **Testpatient:** Zeigt den aktuell ausgewählten Testpatienten (z.B. "Testpatient: Max Mustermann – Nr.: 4711")
- **[Testen]-Button:** Wertet die Bedingung gegen den Testpatienten aus und zeigt das Ergebnis

**Praxis-Tipp:** IMMER erst mit dem Testen-Button prüfen bevor man den Auslöser aktiviert! Dadurch sieht man sofort, ob das Kommando den erwarteten Wert liefert und die Relation korrekt greift.

---

## Logische Verschachtelungen

Per **Alt-Taste (⌥) + Klick auf [+]** können logische Verschachtelungen erstellt werden:

```
Beispiel: ODER-Verknüpfung
┌─ ODER ──────────────────────────────────┐
│  Zeile 1: $[&p.versicherungsart]$ ist PKV  │
│  Zeile 2: $[&p.versicherungsart]$ ist BG   │
└─────────────────────────────────────────┘
→ Erfüllt wenn Patient PKV ODER BG ist
```

Ohne Alt-Taste sind mehrere Zeilen immer UND-verknüpft.

---

## Debugging

Unter `Hilfe → LoglevelFeinschaltung → LogLevelAktionskettenbedingung` aktivieren:
- Im Log erscheinen dann die Auswertungsschritte
- Man sieht den aufgelösten Wert des Kommandos
- Man sieht das Ergebnis der Relation
- Essentiell bei komplexen Bedingungen mit mehreren Zeilen

---

## Praxis-Beispiele

### Beispiel 1: Privatrechnungssumme prüfen
```
Kürzel: Summe_Privatrechnung_
Name: Summe_Privatrechnung_größer
Zeile 1: $[pr_rechnungsSummeReal]$  |  ist größer als  |  1000
Datenlade: ☑ Lade alle Scheine/Rechnungen vor Ausführung
```
→ Erfüllt wenn die aktuelle Privatrechnung > 1000€

### Beispiel 2: Neupatient bei bestimmter Kasse
```
Kürzel: AIMA_Neupatient_Barmer
Name: AIMA_Neupatient_Barmer
Zeile 1: $[formularEintrag PatF-Terminvereinba...]$  |  ist  |  Barmer
Datenlade: ☑ Lade alle Karteieinträge/Formulare vor Ausführung
```
→ Erfüllt wenn im Patientenformular "PatF-Terminvereinbarung" der Wert "Barmer" steht

### Beispiel 3: Alter > 65 (typisches Pattern)
```
Kürzel: ALTER_ÜBER_65
Name: Patient ist über 65 Jahre
Zeile 1: $[&p.alter]$  |  ist größer als  |  65
Datenlade: keine nötig (Stammdaten sind immer geladen)
```

### Beispiel 4: Diagnose vorhanden + noch kein Score heute
```
Kürzel: VHF_OHNE_SCORE
Name: VHF-Diagnose ohne heutigen CHA2DS2-Score
Zeile 1: $[d I48.1]$  |  ist nicht  |  (leer)
Zeile 2: $[karteiEintragWert CHA2DS2 datum]$  |  ist nicht  |  $[&heute]$
Datenlade: ☑ Lade alle Karteieinträge/Formulare vor Ausführung
```
→ UND-Verknüpfung: Diagnose I48.1 vorhanden UND CHA2DS2-Score nicht heute angelegt

### Beispiel 5: Negative Bedingung (Kette NICHT auslösen wenn bereits erledigt)
```
Kürzel: SCORE_NICHT_VORHANDEN
Name: Score heute noch nicht angelegt
Zeile 1: $[karteiEintragWert CHA2DS2 datum]$  |  ist nicht  |  $[&heute]$
```
→ Wird in Auslöser eingebunden um Doppelausführung zu verhindern

---

## Synergie mit HQL-Statistik-Skill

Aktionskettenbedingungen und HQL-Queries nutzen teils **dieselben Datenpfade** (Keypaths), aber in unterschiedlicher Syntax:

| Bedingung (Briefkommando) | HQL (SQL-Pfad) | Beschreibung |
|---|---|---|
| `$[&p.alter]$` | `EXTRACT(YEAR FROM AGE(p.geburtsdatum))` | Patientenalter |
| `$[&p.geschlecht]$` | `p.geschlecht` | Geschlecht |
| `$[d I48.1]$` | `WHERE d.icdCode = 'I48.1'` | Diagnosecheck |
| `$[pr_rechnungsSummeReal]$` | `pr.rechnungsSummeReal` | Rechnungssumme |

Für komplexe Auswertungen die über Briefkommandos hinausgehen → SQL-Bedingung im Auslöser verwenden (siehe ausloser.md) mit Query aus dem `tomedo-statistik-hql` Skill.
