# Vollständige Referenz: Aktionsketten-Fragen

Admin → Aktionsketten → Aktionsketten-Fragen, Fenster „Verwaltung Fragen für Aktionsketten“.
Stand: 22.10.2026.

**Kennzeichnung:** ohne Zusatz = belegt · **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt —
vor dem Einsatz an einer Testakte prüfen · **[Handbuch]** = nur aus der Onlinehilfe.

---

## Konzept

Aktionskettenfragen sind **Entscheidungsdialoge** für den Nutzer. Sie zeigen eine Frage mit
mehreren Antworten; jede Antwort startet eine Aktionskette oder eine weitere Frage (Kaskade).
Sie sind die „Weiche“ zwischen Ketten.

**Typische Einsätze:**
- Arzt entscheidet am Bildschirm zwischen Behandlungspfaden
- MFA wählt bei der Patientenannahme den passenden Ablauf
- Nutzer bestätigt oder verwirft einen automatischen Vorschlag

---

## Aufbau einer Frage — alle Felder

```
Verwaltung Fragen für Aktionsketten
├── Links: Baum mit Gruppen und Elementen
│   ├── + Element · + Gruppe · Kopie · − (löschen) · A..Z↓ · Suche · auf-/zuklappen
│   ├── ☐ gelöschte anzeigen
│   └── Rechtsklick auf eine Frage: zeigt, wo sie verwendet wird
│       (Aktionsketten, Auslöser, andere Fragen) und springt dorthin
│
└── Rechts: Rahmen „Frage“ (bei Gruppen ausgeblendet)
    ├── Kürzel
    ├── Text (mehrzeilig) — der Fragetext
    ├── ☐ Multiselektion          (Standard: aus)
    ├── ☑ Abbrechen Knopf         (Standard: an)
    ├── ☑ Tastenkürzel            (Standard: an)
    ├── Bild (78×78, per Drag & Drop, Minus-Knopf entfernt)
    ├── Antworttabelle: pos | Antworttext | Umschalter Aktionskette/AK-Frage + Auswahl | Farbe
    │   ├── [Zur Aktionskettenverwaltung…] — öffnet die gewählte Kette bzw. Folgefrage
    │   ├── [Kommandos] — Briefkommando-Liste für die Antworttexte
    │   └── [+] [−]
    └── ☐ in Kommandozeile ausblenden
```

---

## Felder der Frage

| Feld | Wirkung |
|---|---|
| **Kürzel** | Suchschlüssel für Kommandozeile, Spotlight und Symbolleiste; Beschriftung des Symbolleisten-Knopfs. Kein Leerzeichen, kein Komma, nicht leer. Ein **doppeltes Kürzel ist nicht gesperrt**, es gibt nur eine Warnung — trotzdem eindeutig halten. |
| **Text** | Überschrift im Dialog, Tooltip in der Symbolleiste, zweiter Suchschlüssel in Kommandozeile und Spotlight. Textbausteine **und Briefkommandos** werden ersetzt — mit Patient und Besuch, aber ohne die Variablen der laufenden Kette (die gibt es nur im Antworttext). Ein Frage-Antwort-Baustein (`∆…∆`) im Text öffnet seinen Dialog. (Fassung 1.4 sagte fälschlich, Briefkommandos würden im Fragetext nicht ersetzt.) |
| **Multiselektion** | An: Antworten erscheinen als Kästchen mit Knopf „OK“. Aus: jede Antwort ist ein Knopf, ein Klick wählt sofort. |
| **Abbrechen Knopf** | Aus: der Knopf „Abbrechen“ fehlt. |
| **Tastenkürzel** | An: die ersten **neun** angezeigten Antworten bekommen die Tasten **1–9** (links steht „1:“ usw.). Ab der zehnten Antwort gibt es keine Taste. |
| **Bild** | Nur das **Symbol des Symbolleisten-Knopfs** dieser Frage. Im Dialog erscheint es nicht. |
| **in Kommandozeile ausblenden** | Die Frage fehlt in der **Kartei-Kommandozeile**. In **Spotlight** und in der Auswahl für die **Symbolleiste** bleibt sie wählbar. |
| **gelöscht** | Löschen setzt nur unsichtbar. Gelöschte Fragen fehlen in Kommandozeile, Spotlight und Symbolleiste. |
| **Gruppe** | Ordner im Baum, erscheint nirgends zur Auswahl. „Kopie“ einer Gruppe kopiert alle Einträge mit. |
| **Kopie** | Übernimmt die Frage mit allen nicht gelöschten Antworten; das Kürzel wird eindeutig umbenannt. |

Schrift, Breite, Höhe und Farbe der Frage gibt es im Datenmodell, aber ohne Eingabefeld und ohne
Wirkung. Die Dialoggröße ergibt sich aus den Texten.

---

## Felder der Antwort

| Spalte | Wirkung |
|---|---|
| **pos** | Reihenfolge im Dialog. Wird bei + und − automatisch durchnummeriert; umordnen per Ziehen. |
| **Antworttext** | Beschriftung von Knopf bzw. Kästchen. **Textbausteine und Briefkommandos werden aufgelöst.** |
| **Umschalter Aktionskette / AK-Frage** | Je Antwort: eine Aktionskette starten oder eine Folgefrage öffnen. Es ist nur die passende Auswahlliste sichtbar. |
| **Farbe** | Färbt bei Einzelauswahl den Antwortknopf. |

Schrift und eine Positionsangabe je Antwort gibt es im Datenmodell, aber ohne Wirkung: Die Antworten
stehen **immer untereinander**, ein Raster-Layout gibt es nicht.

### Sichtbarkeitsregel — wann eine Antwort fehlt

Angezeigt werden die nicht gelöschten Antworten in pos-Reihenfolge, **deren Text nach dem Auflösen
von Textbausteinen und Briefkommandos nicht leer ist**.

- **Eine Antwort ohne Ziel wird angezeigt.** Ein Klick darauf meldet
  „Aktionskettenfragen-Antwort '…' ist nicht richtig konfiguriert.“ und es geschieht nichts weiter.
  (Frühere Fassungen dieses Skills sagten das Gegenteil.)
- **Bedingte Antworten:** Weil Briefkommandos im Antworttext aufgelöst werden, lässt sich eine
  Antwort ausblenden, indem ihr Text leer wird — z. B. mit einem `if`-Kommando, das nur bei
  passender Patientenlage Text liefert. **[ungeprüft]** Syntax des Kommandos → Skill `tomedo-kommandos`.
- Die Tasten 1–9 zählen die **angezeigten** Antworten. Wird eine Antwort ausgeblendet, rutschen die
  Tasten der folgenden nach.

### Farben

Bei **Einzelauswahl** färbt die Farbe den Knopf. Bei **Multiselektion** setzt tomedo die Farbe auf ein
randloses Kästchen; laut Handbuch ist sie dort nicht sichtbar. **[Handbuch, ungeprüft]**

Empfehlung: Grün = Standardpfad, Rot = Abbruch/Sonderfall, Gelb/Orange = Alternative mit
Aufmerksamkeit, keine Farbe = neutral.

---

## Der Dialog zur Laufzeit

- Fenster „Aktionsketten-Frage“: oben der Fragetext, darunter die Antworten untereinander.
- Der Dialog ist **für ganz tomedo modal** — bis zur Antwort ist nichts anderes bedienbar.
- Das Fenster hat **keinen Schließknopf**. Ohne „Abbrechen Knopf“ muss bei Einzelauswahl eine Antwort
  gewählt werden.
- Die Fensterposition wird gemerkt, **eine Position für alle Fragen**, je Arbeitsplatz.

| Taste | Wirkung |
|---|---|
| **1–9** | Einzelauswahl: wählt sofort. Multiselektion: schaltet das Kästchen um. **[ungeprüft für Multiselektion]** |
| **Esc** | Abbrechen (sofern der Knopf angezeigt wird) |
| **Return** | OK bei Multiselektion |

**Multiselektion:** „OK“ liefert die angehakten Antworten in pos-Reihenfolge. **„OK“ ohne Haken wirkt
wie Abbrechen** — auch wenn der Abbrechen-Knopf ausgeschaltet ist.

---

## Wann die gewählte Kette läuft — die Warteschlange

Aktionsketten laufen in tomedo über eine **Warteschlange**: Es läuft immer nur eine Kette, weitere
warten. Das bestimmt, wann die Antwort einer Frage wirkt.

### Frage als Schritt einer Kette (Aktion „Aktionskettenfrage“)

1. Die aufrufende Kette **wartet** am Schritt, bis der Nutzer antwortet.
2. Die gewählte Kette läuft **nicht sofort**. Sie wird eingereiht — standardmäßig **ans Ende** der
   Warteschlange, läuft also erst nach dem **Rest der aufrufenden Kette** und allen schon wartenden Ketten.
3. **Abbrechen beendet die aufrufende Kette nicht.** Sie läuft mit dem nächsten Schritt weiter.

Den Zeitpunkt steuern vier Kästchen am Schritt „Aktionskettenfrage“:

| Kästchen am Schritt | Wirkung |
|---|---|
| (keins) | Ende der Warteschlange |
| **Kette wird eingeschoben** | Die aufrufende Kette wird hier geteilt: erst die gewählte Kette, dann der Rest. Sperrt die drei anderen Kästchen. **Das ist die Einstellung für „Antwort wirkt sofort“.** |
| **Kette kommt in Warteschlange auf Platz 1** | Direkt hinter die laufende Kette, also nach deren restlichen Schritten, aber vor allen anderen wartenden |
| **Kette wird nur einmal in Warteschlange gesetzt** | Nicht einreihen, wenn die Kette schon wartet |
| **Aktive Kette wird abgebrochen und danach die Warteschlange abgearbeitet** | Die restlichen Schritte der aufrufenden Kette entfallen |

Bei Multiselektion mit „eingeschoben“ oder „Platz 1“ wird jede Kette einzeln an dieselbe Stelle
gesetzt; die Reihenfolge **kehrt sich dann vermutlich um** (zuletzt angehakte zuerst). **[ungeprüft]**

### Folgefragen (Kaskade)

Eine Antwort mit Ziel „AK-Frage“ öffnet die Folgefrage **nicht sofort**: tomedo reiht eine kleine
Hilfskette ein, die nur aus dieser Frage besteht. Folge:

- Aus Symbolleiste, Kommandozeile oder Auslöser erscheint die Folgefrage praktisch sofort (nichts
  anderes wartet).
- Als Kettenschritt mit Standard-Einstellung erscheint sie erst **nach dem Rest der aufrufenden Kette**.
  Wer einen mehrstufigen Entscheidungsbaum mitten in einer Kette braucht, setzt am Schritt
  „Kette wird eingeschoben“. **[ungeprüft]**
- Multiselektion mit Folgefragen ist laut einem Meldungstext von tomedo nicht vorgesehen, aber nicht
  gesperrt. Nicht kombinieren.

### Schleifen

**Fragen-Schleifen (A → B → A) werden nicht abgefangen.** Ein wirksamer Endlosschleifen-Schutz fehlt.
Weil jede Runde einen Klick braucht, hängt sich tomedo nicht von selbst auf — der Nutzer kommt aber nur
über „Abbrechen“ heraus. Ohne Abbrechen-Knopf in einer Schleife also nie.

---

## Aufrufwege

| Weg | Verhalten |
|---|---|
| **Aktionsketten-Auslöser**, Umschalter „AK-Frage“ | Frage erscheint, wenn der Auslöser an der Reihe ist (nach Bedingung und Wartezeit). Ist die Frage gelöscht, feuert der Auslöser trotzdem und meldet „…Aktionskettenfrage wurde gelöscht. Überspringe Eintrag.“ |
| **Kettenschritt „Aktionskettenfrage“** | siehe Warteschlange oben |
| **Antwort einer anderen Frage** | Folgefrage, siehe oben |
| **Kartei-Kommandozeile** | Treffer über Kürzel oder Fragetext, Anzeige „Kürzel - Text“. Nicht bei „in Kommandozeile ausblenden“. |
| **Spotlight** | Anzeige „Kürzel = Text“; öffnet die Kartei des aktuellen Patienten. Auch ausgeblendete Fragen sind hier wählbar. Nicht in der Kompaktkartei. |
| **Symbolleiste** (Kartei und Hauptfenster) | Eigener Knopf je Frage: Beschriftung = Kürzel, Tooltip = Text, Symbol = Bild. Ohne ausgewählten Patienten: „Es ist kein Patient ausgewählt.“ |
| **AppleScript** | Kein eigener Befehl. Umweg: eine Kette mit dem Schritt „Aktionskettenfrage“ per `call aktionskette` starten. |
| **Textbaustein-Antwort** | Startet nur Aktionsketten, keine Fragen — Umweg wie bei AppleScript. |

Abbrechen bei Aufruf aus Symbolleiste, Kommandozeile oder Spotlight: Es passiert nichts.

---

## Praxis-Patterns

### Pattern 1: Einfache Ja/Nein-Frage
```
Kürzel: SCORE_ANLEGEN
Text: Soll der CHA2DS2-VASc-Score angelegt werden?
Multiselektion: ☐   Abbrechen: ☑   Tastenkürzel: ☑
Antworten:
  1. "Ja, Score anlegen"  → Aktionskette: CHA2DS2_anlegen  [Farbe: grün]
  2. "Nein, überspringen" → Aktionskette: (leere Kette)    [Farbe: rot]
```
Für „Nein“ braucht es eine leere Kette (oder nur den Abbrechen-Knopf). Eine Antwort ganz ohne Ziel
erzeugt eine Fehlermeldung.

### Pattern 2: Behandlungspfad-Auswahl
```
Kürzel: BEH_PFAD
Text: Welche Behandlung soll dokumentiert werden?
Antworten:
  1. "Osteopathie"     → Aktionskette: BEH_Osteo
  2. "Physiotherapie"  → Aktionskette: BEH_Physio
  3. "Schmerztherapie" → Aktionskette: BEH_Schmerz
  4. "Psychotherapie"  → Aktionskette: BEH_PSY
```

### Pattern 3: Mehrstufiger Entscheidungsbaum (Kaskade)
```
Kürzel: NEUPATIENT_FRAGE
Text: Welches Kriterium trifft auf den Patienten zu?
Antworten:
  1. "Kriterium B" → Aktionskette: TEST   [grün]
  2. "Kriterium A" → AK-Frage: Toolbox    [rot]   → öffnet die Folgefrage
```
Aus einer Kette heraus: am Schritt „Kette wird eingeschoben“ setzen, sonst kommt die Folgefrage erst
nach dem Rest der Kette.

### Pattern 4: Multiselektion (mehrere Maßnahmen)
```
Kürzel: MASSNAHMEN
Text: Welche Maßnahmen sollen durchgeführt werden?
Multiselektion: ☑   Abbrechen: ☑
Antworten:
  1. "Laborauftrag anlegen"  → Aktionskette: LAB_anlegen
  2. "EKG dokumentieren"     → Aktionskette: EKG_anlegen
  3. "Überweisung erstellen" → Aktionskette: ÜBERW_anlegen
  4. "Termin vereinbaren"    → Aktionskette: TERMIN_suche
```
→ z. B. 1 + 3 angehakt: beide Ketten laufen nacheinander in Listenreihenfolge. Keine Folgefragen
als Ziel.

### Pattern 5: Antwort nur bei passender Patientenlage
Antworttext mit einem Briefkommando, das nur unter einer Bedingung Text liefert (z. B. nur bei
Privatpatienten „Privatrechnung anlegen“). Liefert es leer, fehlt die Antwort. **[ungeprüft]**

---

## Zusammenspiel mit anderen Bausteinen

```
Auslöser ──→ AK-Frage ──→ Antwort 1 → Aktionskette A
         │              ├→ Antwort 2 → Aktionskette B
         │              └→ Antwort 3 → AK-Frage 2 (Kaskade, über die Warteschlange)
         │                              ├→ Antwort 3a → Aktionskette C
         │                              └→ Antwort 3b → Aktionskette D
         │
         └── Alternativ: Auslöser → Aktionskette → Schritt „Aktionskettenfrage“
                                     → Dialog mitten in der Kette; gewählte Kette per
                                       Standard erst NACH dem Rest dieser Kette
```
