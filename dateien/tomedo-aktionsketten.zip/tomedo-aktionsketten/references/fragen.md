# Vollständige Referenz: Aktionsketten-Fragen

Extrahiert aus der tomedo-Oberfläche (Admin → Aktionsketten → Aktionsketten-Fragen).
Stand: März 2026.

---

## Konzept

Aktionskettenfragen sind **Entscheidungsdialoge** für den Nutzer. Sie präsentieren eine Frage mit mehreren Antwortoptionen, wobei jede Antwort eine eigene Aktionskette oder eine weitere Aktionskettenfrage (Kaskadierung) auslöst. Sie fungieren als "Aktionskettenweiche".

**Typische Einsätze:**
- Arzt entscheidet am Bildschirm zwischen verschiedenen Behandlungspfaden
- MFA wählt bei Patientenannahme den passenden Workflow
- Nutzer bestätigt oder verwirft einen automatischen Vorschlag

---

## Aufbau einer Frage — Alle Felder

```
Verwaltung Fragen für Aktionsketten
├── Links: Baumstruktur mit Gruppen und Elementen
│   ├── + Element — neue Frage anlegen
│   ├── + Gruppe — neue Ordnergruppe
│   ├── Kopie — Element/Gruppe duplizieren
│   ├── — (Minus) — löschen
│   ├── A..Z↓ — alphabetisch sortieren
│   ├── Suche
│   ├── > aufklappen / v zuklappen
│   └── ☐ gelöschte anzeigen
│
├── Rechts: Frage (Detail)
│   ├── Kürzel: [eindeutiges Kürzel]
│   ├── Text: [Fragetext — wird im Dialog angezeigt]
│   │         (Mehrzeiliges Textfeld)
│   │
│   ├── Optionen (Checkboxen):
│   │   ├── ☐ Multiselektion — mehrere Antworten gleichzeitig wählbar
│   │   ├── ☑ Abbrechen Knopf — Dialog kann ohne Auswahl geschlossen werden
│   │   └── ☑ Tastenkürzel — Antworten per Tastatur wählbar
│   │
│   ├── Antworttabelle:
│   │   ├── Spalte: pos (Reihenfolge 1, 2, 3...)
│   │   ├── Spalte: Antworttext (Freitext)
│   │   ├── Spalte: Aktionskette/Aktionskettenfrage
│   │   │   ├── Toggle: [Aktionskette ↕] oder [AK-Frage ↕]
│   │   │   └── Dropdown: Auswahl der konkreten Kette/Frage
│   │   ├── Spalte: Farbe (Farbfeld pro Antwort)
│   │   ├── [⊕] Button — Einstellungen öffnen (AK-Verwaltungsfenster)
│   │   └── [+] [−] Buttons — Zeile hinzufügen/entfernen
│   │
│   └── ☐ in Kommandozeile ausblenden
```

---

## Felder im Detail

### Kürzel und Text

- **Kürzel:** Eindeutiger Bezeichner, über den die Frage in Auslösern und anderen Ketten referenziert wird
- **Text:** Der angezeigte Fragetext im Dialog. Kann mehrzeilig sein. Sollte klar und handlungsleitend formuliert sein (z.B. "Welches Kriterium trifft auf den Patienten zu?")

### Optionen

| Option | Beschreibung | Default |
|---|---|---|
| **Multiselektion** | Erlaubt mehrere Antworten gleichzeitig zu wählen. Alle gewählten Aktionsketten werden nacheinander ausgeführt. | ☐ Aus |
| **Abbrechen Knopf** | Zeigt einen "Abbrechen"-Button im Dialog, mit dem der Nutzer den Dialog ohne Auswahl schließen kann. Ohne diese Option MUSS eine Antwort gewählt werden. | ☑ An (empfohlen) |
| **Tastenkürzel** | Antworten können per Tastatur (1, 2, 3...) ausgewählt werden statt per Mausklick. | ☑ An (empfohlen) |

**Praxis-Tipp Multiselektion:** Wenn aktiviert, wird die **Farbe** der Antwortoptionen im Dialog NICHT angezeigt (laut Handbuch). Bei Einzelauswahl sind die Farben sichtbar.

**Praxis-Tipp Abbrechen:** Immer aktivieren, es sei denn der Workflow erfordert zwingend eine Auswahl (z.B. Triage-Entscheidung).

### Antworttabelle

Jede Zeile in der Antworttabelle definiert eine Antwortoption:

| Spalte | Beschreibung |
|---|---|
| **pos** | Position/Reihenfolge (1, 2, 3...). Bestimmt die Reihenfolge der Buttons im Dialog. |
| **Antworttext** | Der im Dialog angezeigte Text (z.B. "Kriterium B", "Kriterium A") |
| **Aktionskette/Aktionskettenfrage** | Toggle zwischen Aktionskette und AK-Frage + Auswahl der konkreten Kette/Frage |
| **Farbe** | Farbfeld für den Antwort-Button im Dialog. Nur sichtbar bei Einzelauswahl (nicht bei Multiselektion). |

### Toggle: Aktionskette vs. AK-Frage pro Antwort

Jede Antwortoption kann individuell entweder eine **Aktionskette** oder eine **weitere AK-Frage** auslösen:

- **Aktionskette** → Führt direkt eine Aktionskette aus (häufigster Fall)
- **AK-Frage** → Öffnet eine weitere Aktionskettenfrage (Kaskadierung/Verschachtelung)

**Praxis-Tipp:** Durch Kaskadierung von AK-Fragen lassen sich mehrstufige Entscheidungsbäume aufbauen: Frage 1 → Antwort "Kategorie A" → Frage 2 → Antwort "Unterkategorie A1" → Aktionskette.

### Farben

Jede Antwort kann eine eigene Farbe erhalten. Die Farbe wird als Button-Hintergrund im Auswahldialog angezeigt.

**Empfehlung:**
- Grün = Standardpfad / Bestätigung
- Rot = Abbruch / Sondersituation
- Gelb/Orange = Aufmerksamkeit erfordernde Alternative
- Keine Farbe = Neutrale Option

**Achtung:** Farben sind NUR bei Einzelauswahl sichtbar, NICHT bei Multiselektion!

### Sichtbarkeitsregel

**Wichtig:** Antwortoptionen ohne zugeordnete Aktionskette/Frage werden im Dialog **NICHT angezeigt**. Jede Antwortoption MUSS eine Kette oder Frage zugeordnet haben, sonst verschwindet sie.

### "in Kommandozeile ausblenden"

Checkbox unten im Fenster. Wenn aktiviert, erscheint die Frage nicht als Option in der Kommandozeile der Kartei. Sinnvoll für Fragen, die nur über Auslöser (automatisch) getriggert werden sollen.

---

## Auslösen von Aktionskettenfragen

Fragen können auf drei Wegen ausgelöst werden:

1. **Manuell über Kommandozeile** — Nutzer tippt Kürzel in die Kartei-Kommandozeile (sofern nicht ausgeblendet)
2. **Über Aktionsketten-Auslöser** — Im Auslöser den Toggle auf "AK-Frage" setzen statt "Aktionskette"
3. **Innerhalb einer Aktionskette** — Aktion "Aktionskettenfrage" mit der Frage als Wert
4. **Über eine andere AK-Frage** — Antwort einer Frage verweist auf weitere Frage (Kaskadierung)

---

## Praxis-Patterns

### Pattern 1: Einfache Ja/Nein-Frage
```
Kürzel: SCORE_ANLEGEN
Text: Soll der CHA2DS2-VASc-Score angelegt werden?
Multiselektion: ☐
Abbrechen: ☑
Tastenkürzel: ☑
Antworten:
  1. "Ja, Score anlegen"  → Aktionskette: CHA2DS2_anlegen  [Farbe: grün]
  2. "Nein, überspringen"  → Aktionskette: (leere Kette)    [Farbe: rot]
```

### Pattern 2: Behandlungspfad-Auswahl
```
Kürzel: BEH_PFAD
Text: Welche Behandlung soll dokumentiert werden?
Multiselektion: ☐
Abbrechen: ☑
Antworten:
  1. "Osteopathie"         → Aktionskette: BEH_Osteo
  2. "Physiotherapie"      → Aktionskette: BEH_Physio
  3. "Schmerztherapie"     → Aktionskette: BEH_Schmerz
  4. "Psychotherapie"      → Aktionskette: BEH_PSY
```

### Pattern 3: Mehrstufiger Entscheidungsbaum (Kaskadierung)
```
Kürzel: NEUPATIENT_FRAGE
Text: Welches Kriterium trifft auf den Patienten zu?
Antworten:
  1. "Kriterium B"  → Aktionskette: TEST          [Farbe: grün]
  2. "Kriterium A"  → AK-Frage: Toolbox           [Farbe: rot]
                       ↓
                    Öffnet nächste Frage "Toolbox" mit weiteren Optionen
```

### Pattern 4: Multiselektion (mehrere Maßnahmen gleichzeitig)
```
Kürzel: MASSNAHMEN
Text: Welche Maßnahmen sollen durchgeführt werden?
Multiselektion: ☑
Abbrechen: ☑
Antworten:
  1. "Laborauftrag anlegen"   → Aktionskette: LAB_anlegen
  2. "EKG dokumentieren"      → Aktionskette: EKG_anlegen
  3. "Überweisung erstellen"  → Aktionskette: ÜBERW_anlegen
  4. "Termin vereinbaren"     → Aktionskette: TERMIN_suche
→ Nutzer kann z.B. 1+3 gleichzeitig wählen → beide Ketten laufen nacheinander
```

---

## Zusammenspiel mit anderen Bausteinen

```
Auslöser ──→ AK-Frage ──→ Antwort 1 → Aktionskette A
         │              ├→ Antwort 2 → Aktionskette B
         │              └→ Antwort 3 → AK-Frage 2 (Kaskade)
         │                              ├→ Antwort 3a → Aktionskette C
         │                              └→ Antwort 3b → Aktionskette D
         │
         └── Alternativ: Auslöser → Aktionskette → Aktion "Aktionskettenfrage"
                                                     → Dialog erscheint mitten in der Kette
```

**Hinweis:** Aktionskettenfragen sind **blockierend** — die Kette wartet auf die Nutzerauswahl bevor sie fortfährt.
