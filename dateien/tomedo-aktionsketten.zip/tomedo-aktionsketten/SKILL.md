---
name: tomedo-aktionsketten
description: >-
  Erstellt und konfiguriert Aktionsketten, -ausloeser, -bedingungen und -fragen fuer das tomedo
  Praxisverwaltungssystem. Verwende diesen Skill IMMER wenn tomedo-Aktionsketten, Automatisierung,
  Workflow-Konfiguration, ToDo-Ketten, automatische Abrechnung, bedingte Karteieintraege,
  Aktionskettenausloeser, Aktionskettenbedingungen oder Aktionskettenfragen erwaehnt werden. Auch
  verwenden bei: Workflow bauen, Praxisablaeufe automatisieren, Ausloeser konfigurieren, Bedingung
  formulieren, Aktionskette erstellen, ToDo-gesteuerte Ablaeufe, automatische Privatrechnung,
  bedingte Leistungsanlage, oder jede Frage zu tomedo-Automatisierung. Der Skill enthaelt den
  vollstaendigen Aktionstypen-Katalog, Ausloser-Referenz (auch Medikament-ATC-Code, PZN,
  Rezept Vorschau/Drucken, E-Rezept), Bedingungs-Syntax, Warteschlangen-Logik, Start per URL und
  praxiserprobte Rezepte.
metadata:
  version: 1.6
---

# tomedo Aktionsketten-Skill

Dieser Skill ermöglicht das strukturierte Erstellen von Aktionsketten und deren Komponenten (Auslöser, Bedingungen, Fragen) für tomedo. Er basiert auf der offiziellen Handbuch-Dokumentation, Forum-Erfahrungen und validierten Praxis-Patterns. Seit Fassung 1.4 sind alle Einstellungen der vier Bausteine systematisch überprüft. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — solche Punkte vor dem Einsatz an einer Testakte prüfen.

## Vier Bausteine der Automatisierung

1. **Aktionsketten** — Abfolge von Aktionen (Karteieinträge, Leistungen, Diagnosen, Kommunikation etc.)
2. **Aktionsketten-Auslöser** — Automatische Trigger (bei Besuchsanlage, ToDo auf aktuell, Verordnung eines Wirkstoffs etc.)
3. **Aktionsketten-Bedingungen** — Logische Prüfungen auf Briefkommando-Basis (Alter ≥ 65, Marker gesetzt etc.)
4. **Aktionsketten-Fragen** — Entscheidungsdialoge für den Nutzer (Weiche zwischen verschiedenen Ketten)

Alle vier werden unter `Admin → Aktionsketten` konfiguriert.

## Workflow

1. **Zuerst Referenzdateien lesen** — je nach Aufgabe:
   - Welche Aktion ist verfügbar? → `references/aktionstypen.md`
   - Auslöser konfigurieren, Reihenfolge beim Feuern, SQL-Bedingung → `references/ausloser.md`
   - Bedingung formulieren, Relationen, Ladeoptionen → `references/bedingungen.md`
   - Entscheidungsbaum bauen, Warteschlange → `references/fragen.md`
   - Bewährtes Pattern gesucht → `references/ausloser.md` (Abschnitt „Häufige Auslöser-Patterns“) und `references/fragen.md` (Abschnitt „Praxis-Patterns“); ein eigenes Rezeptbuch gibt es noch nicht
   - KI-Prompt in der Kette einsetzen → `references/ki-prompt-aktion.md`
2. **Ziel des Nutzers in Bausteine dekomponieren**
3. **Vorlagen-Abhängigkeiten identifizieren** (Favoriten, Briefvorlagen etc. die VOR der Kette existieren müssen)
4. **Kette Schritt für Schritt konfigurieren** — mit konkreten Angaben für Typ/Wert/Vorbefüllung/Konfiguration
5. **Auslöser zuordnen** — manuell (Kommandozeile/Termin-Popover) oder automatisch (Auslöser)
6. **Bei Bedarf: HQL-Queries über den tomedo-statistik-hql Skill erstellen** — für Statistik-gesteuerte Massenaktionen

## Kritische Regeln (Lessons Learned)

### Blockierend vs. Nicht-blockierend
Aktionen mit Fenster (Karteieintrag anlegen mit Popover, Brief, Formular, Hinweisfenster, Terminsuche, Aktionskettenfrage …) blockieren die Kette bis zum Schließen. Info, SMS, Order Entry, Früherkennung abrechnen und alle „direkt“-Varianten laufen sofort weiter. "Karteieintrag öffnen" wartet nach aktuellem Stand auf das Popover, wurde in der Praxis aber überholt — so bauen, als sei es nicht blockierend. Vollständige Liste: `references/aktionstypen.md`, Abschnitt „Ablauf einer Kette“.

### Unterketten laufen standardmäßig erst danach — die Warteschlange
Es läuft je Patient immer nur **eine** Kette; weitere warten in einer Warteschlange. Die Schritte „Aktionskette“, „Aktionskettenbedingung“ und „Aktionskettenfrage“ **reihen** ihre Ziel-Kette nur ein: ohne weitere Option läuft sie erst, **wenn die aktuelle Kette ganz fertig ist**. Sofort (mitten in der Kette) läuft sie nur mit **„Kette wird eingeschoben“**. Ist eine Aktionskettenbedingung nicht erfüllt, passiert nichts und die Kette läuft weiter — es gibt keinen Sonst-Zweig und keine Bedingung je Schritt. Ein wirksamer **Endlosschleifen-Schutz fehlt**: Selbstaufrufe mit „Kette wird nur einmal in Warteschlange gesetzt“ und einer Guard-Bedingung absichern. Details: `references/aktionstypen.md` und `references/fragen.md`.

### Vorlagen müssen vorher existieren
EBM/GOÄ-Ziffern → Leistungsfavoriten, Diagnosen → Diagnosefavoriten, Aufgaben → Aufgabenvorlagen, Nachrichten → Nachrichtenvorlagen. Alle müssen VOR der Aktionsketten-Konfiguration angelegt sein.

### Aktionsketten laufen am auslösenden Arbeitsplatz
UI-Effekte (Kartei öffnen, KE anzeigen) passieren NUR am Arbeitsplatz, der die Kette ausgelöst hat. Andere Arbeitsplätze hören/sehen nur Sound/Panel-Effekte. Wenn ein ToDo an AP-A geschoben wird, läuft die Kette an AP-A — nicht an AP-B wo der Patient sitzt. Auslöser werden an dem Arbeitsplatz ausgewertet, an dem die Änderung gemacht wurde; vom Server oder anderen Arbeitsplätzen eingespielte Änderungen lösen dort nichts aus (einzige Ausnahme: Notruf „empfangen“).


⚠ **Kein Arbeitsplatz, keine Kette.** Objekte, die **serverseitig oder von einem Automatismus**
erzeugt werden, loesen keine Aktionskette aus — es gibt keinen ausloesenden Arbeitsplatz, an dem
sie laufen koennte. Belegt 2026-08-26 per Isolationstest: derselbe Ausloeser
(`KarteiEintrag MAIL-Aus / Anlegen`) feuert bei **manuell** angelegtem Karteieintrag zuverlaessig
samt Popup, bei den **automatisch** erzeugten Mail-Karteieintraegen des Terminerinnerungsversands
nie.

Konsequenz fuer den Entwurf: bevor eine Kette an ein Objekt gehaengt wird, klaeren **wer das
Objekt erzeugt**. Kandidaten fuer „hat keinen Arbeitsplatz": Terminerinnerungsversand,
Formularrueckläufe, Importe, KIM/eArztbrief-Eingang, zeitgesteuerte Skripte. Diagnose:
`karteieintrag.dokumentierendernutzer_ident` der automatisch erzeugten Objekte pruefen — ist dort
ein Nutzer eingetragen, kann der zugehoerige Arbeitsplatz in den Ausloeser-Filter aufgenommen
werden; ist es `NULL`, ist die Ausloeser-Route endgueltig zu.

**Isolationstest als Standardvorgehen:** Ausloeser voruebergehend **ohne jede Bedingung** speichern
und das Objekt von Hand anlegen. Feuert die Kette dann, liegt der Fehler in der Bedingung; feuert
sie nicht, in Ausloeser oder Arbeitsplatzfilter — und jede weitere Query-Reparatur ist verlorene Zeit.

**Trigger-Diskriminator statt Freitextpruefung:** `emailvorlage.karteieintragtyp_ident` ist ein
Fremdschluessel — jede E-Mail-Vorlage kann in einen **eigenen** Karteieintragstyp schreiben. Wo
mehrere Vorlagen denselben KE-Typ benutzen und die Kette nur bei einer feuern soll, ist ein eigener
KE-Typ pro Vorlage die saubere Loesung: der Ausloeser **ist** dann die Bedingung. Vorlagenname und
Betreff sind aus dem Karteieintrag **nicht** rekonstruierbar (kein FK `karteieintrag` → `emailvorlage`).


**Messbeleg zur Diagnose (2026-08-31).** Die im Absatz genannte Diagnose ist durchgeführt und
schliesst die Route endgültig: **86,9 Prozent der automatisch erzeugten MAIL-Aus** haben
`dokumentierendernutzer_ident IS NULL` — 5.553 von 6.392 im Juli, 7.967 von 9.164 im August,
also in beiden Monaten derselbe Anteil, der exakt dem automatischen Erinnerungsversand
entspricht. Es gibt keinen Nutzer und damit keinen Arbeitsplatz, über dessen Filter die Kette
erreichbar wäre.

Damit ist der Befund nicht „die Kette feuert nicht", sondern **strukturell unerreichbar**. Wer
Kommunikation an serverseitig erzeugte Objekte hängen will, nimmt den Konfigurationsweg
(Terminerinnerungsstufen), nicht den Automatisierungsweg. Ergänzender Beleg: dieselben
Karteieinträge tragen auch keinen Termin-Fremdschlüssel (0 von 15.556), sind also selbst dann
kein brauchbarer Aufhänger, wenn ein Arbeitsplatz existierte.

### Duplikatschutz bei Ziffern
Für automatisierte Leistungsanlage immer "Anlage nur wenn auf Schein/Rechnung nicht vorhanden" nutzen, sonst entstehen Doppelziffern bei mehrfacher Auslösung. Bei **EBM** erscheint trotzdem immer das Auswahlfenster („direkt übernehmen“ gibt es nur bei GOÄ, Sachkosten u. a.); neue EBM-Schritte stehen auf „Häkchen nicht setzen“. Ohne Fenster geht EBM nur mit „EBM-Ziffer aus Code anlegen“ — das fragt aber jedes Mal nach.

### Zurückschreiben — Datenaustausch zwischen Ketten
Die Aktion "Zurückschreiben" schreibt in Besuchsfelder (Info, Bool1–2, String1–2, KV-/BG-/Privat-Fall, Wichtig), Patientenfelder (Info, Bool1–2, String1–4), zehn Datenschutz-Haken oder einen Karteieintrag. **Besuch Bool3/Bool4 sind nutzerbezogen** (setzen „abgerechnet“ bzw. „dokumentiert“ für den angemeldeten Nutzer) und taugen nicht als Ketten-Flag. Die Felder können in Aktionskettenbedingungen ausgelesen werden → Kommunikation zwischen Ketten. Innerhalb einer Kette und ihrer Unterketten geht es einfacher: alle teilen denselben Briefkommando-Kontext (Variablen).

### Bedingungen erfordern geladene Daten
Aktionskettenbedingungen greifen auf Patientendaten zu, die am Arbeitsplatz geladen sein müssen. Bei teilweisem Laden sieht eine Bedingung nur die neuesten 100 Karteieinträge, 20 Formulare und 10 Verordnungen — die drei Ladeoptionen der Bedingung holen den Rest (wirken nur im Auslöser und im Kettenschritt). Die Ladezeit hängt an der Größe der einzelnen Akte. Achtung: **mehrere Zeilen sind nicht automatisch UND** — die oberste Zeile („Eines/Alle/Keines“) entscheidet. Und `leer` ist bei „kleiner als“ gleich 0.

### Debugging
Erst der Knopf **Testen** in der Bedingungsverwaltung: er zeigt die Bedingung nach der Kommando-Ersetzung mit den aufgelösten Werten. Für den Echtbetrieb unter `Hilfe › Logs › Loglevels Feinschaltung` den Eintrag `LogLevelAktionsKettenBedingung` aktivieren (dazu `LogLevelAktionsKetten` für den Kettenstart). Dann erscheinen im Log die Auswertungsschritte der Bedingungen.

### Von aussen startbar: `call aktionskette` (ohne Parameter) und URL (mit Parametern)

tomedo ist offiziell scriptbar (`NSAppleScriptEnabled = true`, `Resources/tomedo.sdef`).
Das Dictionary ist minimal, aber es enthaelt `call aktionskette <kuerzel>`. Damit braucht eine
Kette **keinen** tomedo-internen Ausloeser mehr — der externe Aufruf *ist* der Ausloeser
(zusaetzlich: `Admin › Skripte` mit Zeitintervall, Startup, Toolbar-Platzierung, Ereignis-Hooks).

Zwei harte Grenzen:

1. **Keine Parameter.** Nur das Kuerzel wird uebergeben — konkrete Werte (Behandler, Datum,
   Terminzeit) nicht. Haeufige Syntaxfalle: das Wort `kuerzel` im AppleScript-Aufruf
   **weglassen**. Die Kette muss ihre Daten selbst beschaffen — **oder** man nimmt die URL
   (naechster Absatz).
2. **`call statistik` ist ein Anzeige-, kein Abfragekanal.** Es rendert eine CSV im
   Statistikfenster; es fuehrt keine HQL-Statistik aus und liefert kein Ergebnis zurueck.

**Ausweg 1 aus Grenze 1: die URL `tomedo://aktionskette`.** Nach aktuellem Stand (10/2026,
an der Referenzinstallation noch nicht nachgemessen **[ungeprüft]**) startet dieser Link
eine Kette **mit** Patient und beliebigen Werten:

```
tomedo://aktionskette?<Kuerzel>&patientident=<ident>&behandler=MUS&datum=24.10.2026#variable
```

| Teil | Wirkung |
|---|---|
| erster Parameter | Kettenkürzel, **ohne** `=` und Wert (sonst „Der erste Query-Parameter darf nur das Kürzel der Aktionskette sein!“) |
| `patientident=` / `besuchident=` | Patient (Besuch von heute) bzw. genau dieser Besuch; ohne beides: die zuletzt benutzte Kartei |
| weitere `name=wert` | gehen an die Kette |
| Fragment `#variable` (Standard) · `#briefkommando` · `#beides` | Werte als Variablen der Kette, als Briefkommando `$[name]$` oder beides |
| `variablenmodus=variable` · `briefkommando` · `beides` | dasselbe als Parameter; hat **Vorrang** vor dem Fragment |

Grenzen und Risiken **[ungeprüft]**:
- Die Kennungen werden als **32-Bit-Zahl** gelesen. Patientennummern passen, **Besuchskennungen sind dafür zu
  groß** und kommen verfälscht an — `besuchident` nicht verwenden, `patientident` nehmen.
- Der Link startet **jede sichtbare Kette ohne Rückfrage**, auch aus einer Mail oder Webseite. Ketten, die
  schreiben, versenden oder löschen, nicht über Links anbieten, die Dritte sehen.
- Der HTTP-Endpunkt hat in den Einstellungen die Modi „nicht starten“, „mit Nachfrage“ und „einfach starten“.

Aus AppleScript: `open location "tomedo://aktionskette?…"`. Zusätzlich kennt tomedo einen
HTTP-Endpunkt `/aktionskette` mit derselben Syntax, der in den Einstellungen freigegeben werden
muss und IP-Freigabe und Token verlangt. Werte gehören URL-kodiert; keine Patientendaten außer der
Kennung in die URL schreiben. `call aktionskette` (AppleScript) braucht dagegen eine offene Kartei und nimmt
die zuletzt aktive. Menüwege und Einstellungen dazu: Skill `tomedo-navigation`.

**Ausweg 2: Statistik-Ergebnislisten.** Die Aktion „Aktionskette fuer alle
Listeneintraege nacheinander ausfuehren" iteriert eine Statistik-Ergebnisliste; der Kontext
kommt aus der Listenzeile statt aus einem Aufrufparameter.

```
HQL-Statistik (eine Zeile je Fall)
        ↓ Ergebnisliste
Aktionskette je Listeneintrag → Aktionstyp „Aufgabe" (aus Aufgabenvorlage)
```

Offen: ob dieser Durchlauf automatisiert anstossbar ist oder eine Nutzeraktion im
Statistikfenster erfordert (halbautomatisch genuegt fuer Meldekanaele meist).

⚠ **Skripttexte sind kein Ort fuer Geheimnisse.** Der Skripttext von `Admin › Skripte`
liegt im **Klartext** in der Server-DB *und* im lokalen Cache **jedes** Arbeitsplatzes.
Zugangsdaten gehoeren in den Login-Schluesselbund; `do shell script` (in 28 von 30
Bestandsskripten genutzt) haelt die Logik ausserhalb.

## Synergie mit HQL-Statistik-Skill

Aktionsketten können aus **Statistik-Ergebnislisten** heraus für alle Listeneinträge nacheinander ausgeführt werden (Aktion "Aktionskette für alle Listeneinträge nacheinander ausführen"). Damit lassen sich per HQL-Query identifizierte Patientengruppen automatisiert bearbeiten. Für die Query-Erstellung den `tomedo-statistik-hql` Skill verwenden.

Zusätzlich nutzen Aktionskettenbedingungen **Briefkommandos** (gleiche Syntax wie in Briefvorlagen), die auf Patientendaten zugreifen — ähnliche Keypaths wie im HQL-Datenmodell.

## Synergie mit Marker-Skill

Bewährte Arbeitsteilung: **Der Marker rechnet** (Kasse, Alter, Ziffer im Zeitfenster), **die Kette handelt** (Hinweis, Ziffer anlegen, ToDo). Der Auslöser „Marker“ startet eine Kette, wenn sich ein Marker ändert; als Bedingung dient `$[istMarkerGesetzt NAME]$` ist `1` (Name genau wie angezeigt, kein Leerzeichen nach der `1`). Die Aktion „Marker setzen“ bietet **nur manuelle Marker** an, automatische sind dort nicht wählbar. Ein automatischer Marker rechnet erst, wenn die Kartei geladen wird. Wer eine Kette auf ihn stützt, plant die Vorberechnung der Marker ein. Die Regel des Markers selbst baut der Skill `tomedo-marker` (Belege im Skill `tomedo-marker`, Datei `zusammenspiel.md`, §1 und §3).

## Status der Referenzdateien

| Datei | Status | Inhalt |
|---|---|---|
| `references/aktionstypen.md` | ✅ überarbeitet 10/2026 | 77 Aktionstypen in sieben Untermenüs mit Wert/Vorbefüllung/Konfiguration und Ablauf, Kettenoptionen, Warteschlange, Zurückschreiben, Länder-Varianten |
| `references/ausloser.md` | ✅ überarbeitet 10/2026 | 41 Objekte (DE) mit allen Aktionen und Unter-Typen, ATC/PZN/Regex-Regeln, Reihenfolge beim Feuern, SQL-Bedingung mit `$[patientident]$`, Nutzer/AP-Filter samt ODER-Falle, Patterns |
| `references/bedingungen.md` | ✅ überarbeitet 10/2026 | Verknüpfung Eines/Alle/Keines, 16 Relationen mit genauer Vergleichslogik, belegte Kommandos, Favoriten, Ladeoptionen, Verwendungsorte, Testen |
| `references/fragen.md` | ✅ überarbeitet 10/2026 | Felder, Sichtbarkeitsregel, Laufzeitdialog, Warteschlange und Kaskaden, Aufrufwege, 5 Patterns |
| Rezeptbuch (eigene Datei) | ⏳ geplant, nicht im Paket | Validierte Praxis-Patterns; bis dahin in `ausloser.md` und `fragen.md` |
| `references/ki-prompt-aktion.md` | ✅ FERTIG | Aktion KI-Prompt: Freigabe in der Promptverwaltung, Ergebnis-Kommando und Weitergabe an Folgeschritte, **manuell zu bestätigender Datenschutz-Dialog**, Prompt-Design für Ketten, belegte Systemgrenzen |
