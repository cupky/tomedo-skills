---
name: tomedo-aktionsketten
description: >-
  Erstellt und konfiguriert Aktionsketten, -ausloeser, -bedingungen und -fragen fuer das tomedo
  Praxisverwaltungssystem. Verwende diesen Skill IMMER wenn tomedo-Aktionsketten, Automatisierung,
  Workflow-Konfiguration, ToDo-Ketten, automatische Abrechnung, bedingte Karteieintraege,
  Aktionskettenausloeser, Aktionskettenbedingungen oder Aktionskettenfragen erwaehnt werden. Auch
  verwenden bei: Workflow bauen, Praxisablaeufe automatisieren, Ausloeser konfigurieren, Bedingung
  formulieren, Aktionskette erstellen, ToDo-gesteuerte Ablaeufe, automatische Privatrechnung,
  bedingte Leistungsanlage, oder jede Frage zu tomedo-Automatisierung. Der Skill enthaelt den
  vollstaendigen Aktionstypen-Katalog, Ausloser-Referenz, Bedingungs-Syntax und praxiserprobte
  Rezepte.
metadata:
  version: 1.1
---

# tomedo Aktionsketten-Skill

Dieser Skill ermöglicht das strukturierte Erstellen von Aktionsketten und deren Komponenten (Auslöser, Bedingungen, Fragen) für tomedo. Er basiert auf der offiziellen Handbuch-Dokumentation, Forum-Erfahrungen und validierten Praxis-Patterns.

## Vier Bausteine der Automatisierung

1. **Aktionsketten** — Abfolge von Aktionen (Karteieinträge, Leistungen, Diagnosen, Kommunikation etc.)
2. **Aktionsketten-Auslöser** — Automatische oder manuelle Trigger (bei Besuchsanlage, ToDo-Verschiebung etc.)
3. **Aktionsketten-Bedingungen** — Logische Prüfungen vor Ausführung (Alter > 65, Diagnose vorhanden etc.)
4. **Aktionsketten-Fragen** — Entscheidungsdialoge für den Nutzer (Weiche zwischen verschiedenen Ketten)

Alle vier werden unter `Admin → Aktionsketten` konfiguriert.

## Workflow

1. **Zuerst Referenzdateien lesen** — je nach Aufgabe:
   - Welche Aktion ist verfügbar? → `references/aktionstypen.md`
   - Auslöser konfigurieren → `references/ausloser.md` (TODO)
   - Bedingung formulieren → `references/bedingungen.md` (TODO)
   - Entscheidungsbaum bauen → `references/fragen.md` (TODO)
   - Bewährtes Pattern gesucht → `references/rezeptbuch.md` (TODO)
   - KI-Prompt in der Kette einsetzen → `references/ki-prompt-aktion.md`
2. **Ziel des Nutzers in Bausteine dekomponieren**
3. **Vorlagen-Abhängigkeiten identifizieren** (Favoriten, Briefvorlagen etc. die VOR der Kette existieren müssen)
4. **Kette Schritt für Schritt konfigurieren** — mit konkreten Angaben für Typ/Wert/Vorbefüllung/Konfiguration
5. **Auslöser zuordnen** — manuell (Kommandozeile/Termin-Popover) oder automatisch (Auslöser)
6. **Bei Bedarf: HQL-Queries über den tomedo-statistik-hql Skill erstellen** — für Statistik-gesteuerte Massenaktionen

## Kritische Regeln (Lessons Learned)

### Blockierend vs. Nicht-blockierend
Aktionen wie "Karteieintrag anlegen" (mit Popover) blockieren die Kette bis zur Bestätigung. "Karteieintrag öffnen" ist NICHT-blockierend — die nächste Aktion startet sofort. Bei Mischung: separate Unter-Aktionsketten verwenden.

### Vorlagen müssen vorher existieren
EBM/GOÄ-Ziffern → Leistungsfavoriten, Diagnosen → Diagnosefavoriten, Aufgaben → Aufgabenvorlagen, Nachrichten → Nachrichtenvorlagen. Alle müssen VOR der Aktionsketten-Konfiguration angelegt sein.

### Aktionsketten laufen am auslösenden Arbeitsplatz
UI-Effekte (Kartei öffnen, KE anzeigen) passieren NUR am Arbeitsplatz, der die Kette ausgelöst hat. Andere Arbeitsplätze hören/sehen nur Sound/Panel-Effekte. Wenn ein ToDo an AP-A geschoben wird, läuft die Kette an AP-A — nicht an AP-B wo der Patient sitzt.


⚠ **Kein Arbeitsplatz, keine Kette.** Objekte, die **serverseitig oder von einem Automatismus**
erzeugt werden, loesen keine Aktionskette aus — es gibt keinen ausloesenden Arbeitsplatz, an dem
sie laufen koennte. Belegt 2026-08-26 per Isolationstest: derselbe Ausloeser
(`KarteiEintrag MAIL-Aus / Anlegen`) feuert bei **manuell** angelegtem Karteieintrag zuverlaessig
samt Popup, bei den **automatisch** erzeugten Mail-Karteieintraegen des Terminerinnerungsversands
nie.

Konsequenz fuer den Entwurf: bevor eine Kette an ein Objekt gehaengt wird, klaeren **wer das
Objekt erzeugt**. Kandidaten fuer „hat keinen Arbeitsplatz": Terminerinnerungsversand,
Formularrueckläufe, Importe, KIM/eArztbrief-Eingang, zeitgesteuerte Skripte. Diagnose:
`karteieintrag.dokumentierendernutzer_ident` der automatisch erzeugten Objekte pruefen — ist dort
ein Nutzer eingetragen, kann der zugehoerige Arbeitsplatz in den Ausloeser-Filter aufgenommen
werden; ist es `NULL`, ist die Ausloeser-Route endgueltig zu.

**Isolationstest als Standardvorgehen:** Ausloeser voruebergehend **ohne jede Bedingung** speichern
und das Objekt von Hand anlegen. Feuert die Kette dann, liegt der Fehler in der Bedingung; feuert
sie nicht, in Ausloeser oder Arbeitsplatzfilter — und jede weitere Query-Reparatur ist verlorene Zeit.

**Trigger-Diskriminator statt Freitextpruefung:** `emailvorlage.karteieintragtyp_ident` ist ein
Fremdschluessel — jede E-Mail-Vorlage kann in einen **eigenen** Karteieintragstyp schreiben. Wo
mehrere Vorlagen denselben KE-Typ benutzen und die Kette nur bei einer feuern soll, ist ein eigener
KE-Typ pro Vorlage die saubere Loesung: der Ausloeser **ist** dann die Bedingung. Vorlagenname und
Betreff sind aus dem Karteieintrag **nicht** rekonstruierbar (kein FK `karteieintrag` → `emailvorlage`).


**Messbeleg zur Diagnose (2026-08-31).** Die im Absatz genannte Diagnose ist durchgeführt und
schliesst die Route endgültig: **86,9 Prozent der automatisch erzeugten MAIL-Aus** haben
`dokumentierendernutzer_ident IS NULL` — 5.553 von 6.392 im Juli, 7.967 von 9.164 im August,
also in beiden Monaten derselbe Anteil, der exakt dem automatischen Erinnerungsversand
entspricht. Es gibt keinen Nutzer und damit keinen Arbeitsplatz, über dessen Filter die Kette
erreichbar wäre.

Damit ist der Befund nicht „die Kette feuert nicht", sondern **strukturell unerreichbar**. Wer
Kommunikation an serverseitig erzeugte Objekte hängen will, nimmt den Konfigurationsweg
(Terminerinnerungsstufen), nicht den Automatisierungsweg. Ergänzender Beleg: dieselben
Karteieinträge tragen auch keinen Termin-Fremdschlüssel (0 von 15.556), sind also selbst dann
kein brauchbarer Aufhänger, wenn ein Arbeitsplatz existierte.

### Duplikatschutz bei Ziffern
Für automatisierte Leistungsanlage immer "Anlage nur wenn auf Schein/Rechnung nicht vorhanden" nutzen, sonst entstehen Doppelziffern bei mehrfacher Auslösung.

### Zurückschreiben — Datenaustausch zwischen Ketten
Die Aktion "Zurückschreiben" kann Werte in Besuchs- und Patientenfelder schreiben (Bool1-4, String1-4, Info etc.). Diese Felder können in Aktionskettenbedingungen ausgelesen werden → ermöglicht Kommunikation zwischen Ketten.

### Bedingungen erfordern geladene Daten
Aktionskettenbedingungen greifen auf Patientendaten zu, die am Arbeitsplatz geladen sein müssen. Optionen zum Vorladen gibt es in der Bedingungskonfiguration. Bei großen Datenbanken: Ladezeit beachten!

### Debugging
Unter `Hilfe → LoglevelFeinschaltung → LogLevelAktionskettenbedingung` aktivieren. Dann erscheinen im Log die Auswertungsschritte der Bedingungen.

### Von aussen startbar: `call aktionskette` (ohne Parameter)

tomedo ist offiziell scriptbar (`NSAppleScriptEnabled = true`, `Resources/tomedo.sdef`).
Das Dictionary ist minimal, aber es enthaelt `call aktionskette <kuerzel>`. Damit braucht eine
Kette **keinen** tomedo-internen Ausloeser mehr — der externe Aufruf *ist* der Ausloeser
(zusaetzlich: `Admin › Skripte` mit Zeitintervall, Startup, Toolbar-Platzierung, Ereignis-Hooks).

Zwei harte Grenzen:

1. **Keine Parameter.** Nur das Kuerzel wird uebergeben — konkrete Werte (Behandler, Datum,
   Terminzeit) nicht. Haeufige Syntaxfalle: das Wort `kuerzel` im AppleScript-Aufruf
   **weglassen**. Die Kette muss ihre Daten selbst beschaffen.
2. **`call statistik` ist ein Anzeige-, kein Abfragekanal.** Es rendert eine CSV im
   Statistikfenster; es fuehrt keine HQL-Statistik aus und liefert kein Ergebnis zurueck.

**Der Ausweg aus Grenze 1: Statistik-Ergebnislisten.** Die Aktion „Aktionskette fuer alle
Listeneintraege nacheinander ausfuehren" iteriert eine Statistik-Ergebnisliste; der Kontext
kommt aus der Listenzeile statt aus einem Aufrufparameter.

```
HQL-Statistik (eine Zeile je Fall)
        ↓ Ergebnisliste
Aktionskette je Listeneintrag → Aktionstyp „Aufgabe" (aus Aufgabenvorlage)
```

Offen: ob dieser Durchlauf automatisiert anstossbar ist oder eine Nutzeraktion im
Statistikfenster erfordert (halbautomatisch genuegt fuer Meldekanaele meist).

⚠ **Skript-Quelltexte sind kein Ort fuer Geheimnisse.** Der Quelltext von `Admin › Skripte`
liegt im **Klartext** in der Server-DB *und* im lokalen Cache **jedes** Arbeitsplatzes.
Zugangsdaten gehoeren in den Login-Schluesselbund; `do shell script` (in 28 von 30
Bestandsskripten genutzt) haelt die Logik ausserhalb.

## Synergie mit HQL-Statistik-Skill

Aktionsketten können aus **Statistik-Ergebnislisten** heraus für alle Listeneinträge nacheinander ausgeführt werden (Aktion "Aktionskette für alle Listeneinträge nacheinander ausführen"). Damit lassen sich per HQL-Query identifizierte Patientengruppen automatisiert bearbeiten. Für die Query-Erstellung den `tomedo-statistik-hql` Skill verwenden.

Zusätzlich nutzen Aktionskettenbedingungen **Briefkommandos** (gleiche Syntax wie in Briefvorlagen), die auf Patientendaten zugreifen — ähnliche Keypaths wie im HQL-Datenmodell.

## Status der Referenzdateien

| Datei | Status | Inhalt |
|---|---|---|
| `references/aktionstypen.md` | ✅ FERTIG | Vollständiger Katalog aller ~50 Aktionstypen mit Wert/Vorbefüllung/Konfiguration |
| `references/ausloser.md` | ✅ FERTIG | 40 Objekte, KE-Typ-Liste (~130), Aktion-Matrix, Nutzer/AP-Filter, SQL+AK-Bedingung, Verzögerung, Patterns |
| `references/bedingungen.md` | ✅ FERTIG | 16 Relationen, Kommando-Syntax, Datenlade-Optionen, Verschachtelung, 5 Praxisbeispiele |
| `references/fragen.md` | ✅ FERTIG | Entscheidungsbaum, Multiselektion, Farben, Kaskadierung, Tastenkürzel, 4 Patterns |
| `references/rezeptbuch.md` | ⏳ TODO | Validierte Praxis-Patterns |
| `references/ki-prompt-aktion.md` | ✅ FERTIG | Aktion KI-Prompt: Freigabe in der Promptverwaltung, Ergebnis-Kommando und Weitergabe an Folgeschritte, **manuell zu bestätigender Datenschutz-Dialog**, Prompt-Design für Ketten, belegte Systemgrenzen |
