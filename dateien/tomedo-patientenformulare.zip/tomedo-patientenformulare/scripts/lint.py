#!/usr/bin/env python3
"""
lint.py — Pre-Flight-Linter fuer Patientenformulare (arzt-direct JSON).

Usage:
    python3 lint.py <pfad.json>

Exit:
    0 = keine ERRORs
    1 = mindestens ein ERROR
"""

import json
import re
import sys
from collections import Counter, defaultdict
from typing import Any, Dict, List, Tuple


# ---------- Helpers ----------

def iter_elements(survey: Dict[str, Any]):
    """Yield (page_name, element) for every element in every page — auch in Panels
    und dynamischen Panels (templateElements). Bis Fassung 1.1 nur die oberste Ebene."""
    def walk(els, page_name):
        for el in els or []:
            yield page_name, el
            yield from walk(el.get("elements"), page_name)
            yield from walk(el.get("templateElements"), page_name)
    for page in survey.get("pages", []):
        yield from walk(page.get("elements", []), page.get("name", "?"))


def collect_names(survey: Dict[str, Any]) -> Dict[str, List[str]]:
    """Map name -> list of pages where it appears (for duplicate detection)."""
    m: Dict[str, List[str]] = defaultdict(list)
    for page_name, el in iter_elements(survey):
        n = el.get("name")
        if n:
            m[n].append(page_name)
    return m


def extract_referenced_names(text: str) -> List[str]:
    """Extract referenced field names from visibleIf/expression/template strings.

    Recognizes:
      {feldname}           — SurveyJS syntax
      wert("feldname")     — tomedo extension
      wert('feldname')     — variant
      $[text('feldname')]$ — karteitextHtmlTemplate
      $[text("feldname")]$ — variant
    """
    refs = set()
    # {feldname} — but skip Item, Spalte, Zeile, true/false/empty etc
    for m in re.finditer(r"\{([^}]+)\}", text):
        ref = m.group(1).strip()
        # Strip ".Zeile1" / ".Spalte2" matrix-cell suffixes
        ref = ref.split(".")[0]
        refs.add(ref)
    # wert("name") and wert('name')
    for m in re.finditer(r"""wert\s*\(\s*["']([^"']+)["']\s*\)""", text):
        ref = m.group(1).split(".")[0]
        refs.add(ref)
    # $[text('name')]$
    for m in re.finditer(r"""\$\[text\(\s*["']([^"']+)["']\s*\)\]\$""", text):
        refs.add(m.group(1))
    return list(refs)


# ---------- Rule checks ----------

def check_duplicates(survey, findings):
    """E1: name eindeutig"""
    names = collect_names(survey)
    for n, pages in names.items():
        if len(pages) > 1:
            findings.append(("ERROR", "E1", f"name '{n}' wird mehrfach verwendet (Pages: {', '.join(pages)})"))


def check_missing_name(survey, findings):
    """E2: name fehlt bei Nicht-html-Element"""
    for page_name, el in iter_elements(survey):
        if el.get("type") in ("html", "image"):
            continue
        if not el.get("name"):
            findings.append(("ERROR", "E2",
                             f"Element vom Typ '{el.get('type')}' auf Page '{page_name}' hat keinen 'name'"))


def check_visibleif_refs(survey, findings):
    """E3: visibleIf referenziert nicht-existenten name"""
    names = set(collect_names(survey).keys())
    # Page-level visibleIf
    for page in survey.get("pages", []):
        vi = page.get("visibleIf")
        if vi:
            for ref in extract_referenced_names(vi):
                if ref not in names:
                    findings.append(("ERROR", "E3",
                                     f"visibleIf der Page '{page.get('name')}' referenziert nicht-existenten name '{ref}'"))
    # Element-level visibleIf
    for page_name, el in iter_elements(survey):
        for key in ("visibleIf", "enableIf", "requiredIf"):
            vi = el.get(key)
            if vi:
                for ref in extract_referenced_names(vi):
                    if ref not in names:
                        findings.append(("ERROR", "E3",
                                         f"{key} von '{el.get('name')}' (Page '{page_name}') referenziert nicht-existenten name '{ref}'"))


def check_expression_refs(survey, findings):
    """E4: expression referenziert nicht-existenten name"""
    names = set(collect_names(survey).keys())
    for page_name, el in iter_elements(survey):
        expr = el.get("expression")
        if expr:
            for ref in extract_referenced_names(expr):
                if ref not in names:
                    findings.append(("ERROR", "E4",
                                     f"expression von '{el.get('name')}' (Page '{page_name}') referenziert nicht-existenten name '{ref}'"))
        # Validators mit type=expression auch pruefen
        for v in el.get("validators", []):
            if v.get("type") == "expression":
                vexpr = v.get("expression", "")
                for ref in extract_referenced_names(vexpr):
                    # ignoriere {selfname} wenn es das eigene feld ist
                    if ref != el.get("name") and ref not in names:
                        findings.append(("ERROR", "E4",
                                         f"Validator-expression von '{el.get('name')}' (Page '{page_name}') referenziert nicht-existenten name '{ref}'"))


def check_karteitext_refs(survey, findings):
    """E5: karteitextHtmlTemplate referenziert nicht-existenten name"""
    tmpl = survey.get("karteitextHtmlTemplate")
    if not tmpl:
        findings.append(("INFO", "I1", "karteitextHtmlTemplate fehlt — Default-Renderer wird verwendet"))
        return
    names = set(collect_names(survey).keys())
    refs_in_template = extract_referenced_names(tmpl)
    for ref in refs_in_template:
        if ref not in names:
            findings.append(("ERROR", "E5",
                             f"karteitextHtmlTemplate referenziert nicht-existenten name '{ref}'"))


def check_iff_typo(survey, findings):
    """E6: iff statt iif"""
    iff_re = re.compile(r"\biff\s*\(")
    for page_name, el in iter_elements(survey):
        expr = el.get("expression", "")
        if iff_re.search(expr):
            findings.append(("ERROR", "E6",
                             f"expression von '{el.get('name')}' verwendet 'iff(' — korrekt ist 'iif('"))
    tmpl = survey.get("karteitextHtmlTemplate", "")
    if iff_re.search(tmpl):
        findings.append(("ERROR", "E6", "karteitextHtmlTemplate verwendet 'iff(' — korrekt ist 'iif('"))


def check_de_locale(survey, findings):
    """W8: {"de": ...} statt {"default": ...} — Bestand hat einzelne Cases"""
    def scan(obj, path=""):
        if isinstance(obj, dict):
            if "de" in obj and "default" not in obj:
                if isinstance(obj.get("de"), str):
                    findings.append(("WARN", "W8",
                                     f"Locale-Key 'de' statt 'default' bei {path} — Konvention ist 'default'"))
            for k, v in obj.items():
                scan(v, f"{path}.{k}" if path else k)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                scan(v, f"{path}[{i}]")
    scan(survey)


def check_choices_completeness(survey, findings):
    """E8: choices ohne text"""
    for page_name, el in iter_elements(survey):
        for ch in el.get("choices", []):
            if isinstance(ch, dict):
                if "value" not in ch:
                    findings.append(("ERROR", "E8",
                                     f"choices-Eintrag in '{el.get('name')}' ohne 'value': {ch}"))
                if "text" not in ch:
                    findings.append(("ERROR", "E8",
                                     f"choices-Eintrag value='{ch.get('value')}' in '{el.get('name')}' ohne 'text'"))


# ---------- WARN ----------

WFA_ORZ_RE = re.compile(r"^\$(wfa|orz)[A-Za-z]+\$$")
ST_STRICT_RE = re.compile(r"^[A-Za-z]+$")


def check_missing_short_title(survey, findings):
    """W1: shortTitle fehlt"""
    skip_types = {"html", "image", "signaturepad", "panel"}   # panel: shortTitle lehnt der Editor ab (G9)
    for page_name, el in iter_elements(survey):
        if el.get("type") in skip_types:
            continue
        if el.get("name") and not el.get("shortTitle"):
            findings.append(("WARN", "W1",
                             f"shortTitle fehlt bei name='{el.get('name')}' (Page '{page_name}', type={el.get('type')})"))


def check_short_title_charclass(survey, findings):
    """I5: shortTitle mit Sonderzeichen (Bestandspraxis akzeptiert, INFO-Niveau)"""
    offenders = []
    for page_name, el in iter_elements(survey):
        st = el.get("shortTitle")
        if st and not ST_STRICT_RE.match(st):
            offenders.append(st)
    if offenders:
        # Eine Sammel-Meldung statt 40 Einzel-Warnungen
        sample = ", ".join(sorted(set(offenders))[:5])
        more = f" und {len(set(offenders))-5} weitere" if len(set(offenders)) > 5 else ""
        findings.append(("INFO", "I5",
                         f"{len(offenders)} shortTitle(s) mit Sonderzeichen (Umlaut/Bindestrich): {sample}{more} — Bestandspraxis akzeptiert, bei Neubogen [A-Za-z]+ vorziehen"))


def check_wfa_orz_shorttitle(survey, findings):
    """W3: $wfa$/$orz$-name ohne sprechenden shortTitle"""
    for page_name, el in iter_elements(survey):
        n = el.get("name", "")
        if WFA_ORZ_RE.match(n):
            st = el.get("shortTitle")
            if not st or st == n:
                findings.append(("WARN", "W3",
                                 f"Stammdaten-name '{n}' ohne sprechenden shortTitle"))


def check_matrix_without_expression(survey, findings):
    """W4: matrix ohne Parallel-expression"""
    matrices = []
    expr_refs = set()
    for page_name, el in iter_elements(survey):
        if el.get("type") == "matrix":
            matrices.append(el.get("name"))
        if el.get("type") == "expression":
            for ref in extract_referenced_names(el.get("expression", "")):
                expr_refs.add(ref)
    # Templates auch
    tmpl_refs = set(extract_referenced_names(survey.get("karteitextHtmlTemplate", "")))
    referenced = expr_refs | tmpl_refs
    for m in matrices:
        if m not in referenced:
            findings.append(("WARN", "W4",
                             f"matrix '{m}' wird nirgendwo per expression/template ausgelesen — Briefkommando liefert nur Indizes"))


def check_visible_score(survey, findings):
    """W6: Score-expression mit visible != false"""
    for page_name, el in iter_elements(survey):
        if el.get("type") == "expression":
            if el.get("visible") is not False:
                findings.append(("WARN", "W6",
                                 f"expression '{el.get('name')}' ohne 'visible: false' — taucht in Patient-UI auf"))


def check_required_on_conditional(survey, findings):
    """I6: isRequired + visibleIf (Bestandspraxis akzeptiert)"""
    count = 0
    for page_name, el in iter_elements(survey):
        if el.get("isRequired") and el.get("visibleIf"):
            count += 1
    if count > 0:
        findings.append(("INFO", "I6",
                         f"{count} Felder haben isRequired UND visibleIf — funktioniert, requiredIf ist semantisch sauberer"))


# ---------- INFO ----------

def check_long_pages(survey, findings):
    """I3: Page mit >15 Elementen"""
    for page in survey.get("pages", []):
        n = len(page.get("elements", []))
        if n > 15:
            findings.append(("INFO", "I3",
                             f"Page '{page.get('name')}' hat {n} Elemente — Mobile-Usability pruefen"))


def check_wide_matrix(survey, findings):
    """I4: matrix mit >4 Spalten"""
    for page_name, el in iter_elements(survey):
        if el.get("type") == "matrix":
            n = len(el.get("columns", []))
            if n > 4:
                findings.append(("INFO", "I4",
                                 f"matrix '{el.get('name')}' hat {n} Spalten — Mobile-Usability pruefen"))


def check_wfainputtype_without_validator(survey, findings):
    """I2: wfaInputType: number ohne numeric-validator"""
    for page_name, el in iter_elements(survey):
        if el.get("wfaInputType") == "number":
            vs = el.get("validators", [])
            if not any(v.get("type") in ("numeric", "expression") for v in vs):
                findings.append(("INFO", "I2",
                                 f"'{el.get('name')}' hat wfaInputType=number, aber keinen numeric-Validator"))



# ---------- Gestaltung (G-Regeln) ----------
# Quelle: references/gestaltung.md — Gegentest 29.09.2026, survey-core 2.3.16.
# Grundsatz: nur freigegebene Gestaltungsmittel. Was nachweislich nicht wirkt, ist ERROR;
# was nicht geprueft ist, ist WARN ("ungeprueft").

def iter_all(survey):
    """Yield (pfad, element) fuer Seiten und alle Elemente, auch in Panels."""
    def walk(els, pfad):
        for el in els or []:
            yield f"{pfad}/{el.get('name', el.get('type', '?'))}", el
            yield from walk(el.get("elements"), f"{pfad}/{el.get('name', '?')}")
    for page in survey.get("pages", []):
        yield f"page:{page.get('name', '?')}", page
        yield from walk(page.get("elements"), f"page:{page.get('name', '?')}")


def _texte(v):
    """Alle Strings eines lokalisierten Werts."""
    if isinstance(v, str):
        return [v]
    if isinstance(v, dict):
        return [x for x in v.values() if isinstance(x, str)]
    return []


def _html_quellen(survey):
    """(ort, html) fuer html-Elemente und completedHtml."""
    for pfad, el in iter_all(survey):
        if el.get("type") == "html":
            for t in _texte(el.get("html")):
                yield pfad, t
    for t in _texte(survey.get("completedHtml")):
        yield "completedHtml", t


NICHT_WIRKSAM = [
    # (property, bedingung(el), regel, meldung)
    ("state", lambda el: el.get("type") == "panel", "G1",
     "panel.state wird beim Speichern verworfen — Gruppe bleibt offen"),
    ("questionTitleLocation", lambda el: True, "G2",
     "questionTitleLocation wird verworfen — Titel stehen immer ueber dem Feld"),
    ("width", lambda el: True, "G3", "width wird verworfen — nebeneinander nur ueber startWithNewLine: false"),
    ("minWidth", lambda el: True, "G3", "minWidth wird verworfen"),
    ("maxWidth", lambda el: True, "G3", "maxWidth ist ungeprueft und vermutlich verworfen"),
    ("renderAs", lambda el: el.get("type") == "boolean", "G4",
     "boolean.renderAs wird verworfen — Darstellung bleibt Schalter Nein/Ja"),
    ("label", lambda el: el.get("type") == "boolean", "G4",
     "boolean.label wird verworfen — mit titleLocation hidden bleibt die Frage OHNE Text"),
    ("showOtherItem", lambda el: True, "G5", "showOtherItem wird verworfen — eigene Option + text-Frage mit visibleIf"),
    ("hasOther", lambda el: True, "G5", "hasOther (alt fuer showOtherItem) wird verworfen"),
    ("otherText", lambda el: True, "G5", "otherText wird verworfen"),
    ("shortTitle", lambda el: el.get("type") == "panel", "G9",
     "shortTitle auf panel: der Editor meldet 'Unknown property' und lehnt ab"),
]


def check_gestaltung_properties(survey, findings):
    """G1–G5, G9: nachweislich wirkungslose Properties an Elementen."""
    for pfad, el in iter_all(survey):
        for prop, bed, regel, msg in NICHT_WIRKSAM:
            if prop in el and bed(el):
                findings.append(("ERROR", regel, f"{pfad}: {msg}"))
    if survey.get("questionTitleLocation") == "left":
        findings.append(("ERROR", "G2", "Formular: questionTitleLocation wird verworfen"))


def check_gestaltung_formular(survey, findings):
    """G6, G10, G11: Formular-Properties, die nicht wirken oder abgelehnt werden."""
    if survey.get("questionsOnPageMode") in ("questionPerPage", "inputPerPage"):
        findings.append(("ERROR", "G6",
                         "questionsOnPageMode: arzt-direct setzt zur Laufzeit 'standard' — eine Frage je Seite von Hand bauen"))
    if survey.get("progressBarLocation") == "top":
        findings.append(("ERROR", "G10",
                         "progressBarLocation 'top' lehnt der Editor ab — 'aboveheader' oder 'belowheader'"))
    for prop in ("showQuestionNumbers", "editText"):
        if prop in survey:
            findings.append(("WARN", "G11", f"{prop} wird beim Speichern verworfen (wirkungslos)"))


def check_gestaltung_typen(survey, findings):
    """G7, G8, G12, G16: Elementtypen und Eigenschaften mit belegter Grenze."""
    for pfad, el in iter_all(survey):
        t = el.get("type")
        if t == "imagepicker":
            findings.append(("ERROR", "G8", f"{pfad}: imagepicker lehnt der Editor ab — image + checkbox"))
        if t == "rating" and el.get("rateType") != "smileys":
            for prop in ("rateColorMode", "scaleColorMode"):
                if prop in el:
                    findings.append(("ERROR", "G7",
                                     f"{pfad}: {prop} faerbt nur rateType 'smileys' — auf einer Zahlenskala ohne Wirkung"))
        for tt in _texte(el.get("title")):
            if re.search(r"</?[a-zA-Z][^>]*>", tt):
                findings.append(("ERROR", "G12",
                                 f"{pfad}: HTML im Titel wird roh angezeigt — Hinweis als eigenes html-Element"))
                break
        if t in ("datepicker", "text") and ("maskType" in el or "maskSettings" in el) and t == "datepicker":
            findings.append(("WARN", "G16", f"{pfad}: maskType/maskSettings am datepicker werden verworfen"))
        if t == "boolean" and el.get("titleLocation") == "hidden":
            findings.append(("ERROR", "G4",
                             f"{pfad}: boolean mit titleLocation hidden erscheint als Schalter Nein/Ja OHNE Fragetext"))


FONT_PROPS = re.compile(r"font-(family|weight|size)\s*:", re.I)
SYSTEM_SCHRIFTEN = {"georgia", "times new roman", "times", "arial", "helvetica", "verdana", "segoe ui",
                    "-apple-system", "system-ui", "serif", "sans-serif", "monospace", "inherit", "courier new"}


def check_gestaltung_css(survey, findings):
    """G13–G15, G17: CSS in html-Elementen und completedHtml."""
    for ort, html in _html_quellen(survey):
        styles = re.findall(r"<style[^>]*>(.*?)</style>", html, re.S | re.I)
        if styles:
            findings.append(("WARN", "G15",
                             f"{ort}: <style>-Block wirkt nur, solange diese Seite angezeigt wird — Inline-Styles bevorzugen"))
        for css in styles:
            if "--sjs-" in css:
                findings.append(("ERROR", "G14",
                                 f"{ort}: --sjs-*-Variablen — am :root wirkungslos (Theme inline am Survey-Root), "
                                 f"--sjs-base-unit an .sd-root-modern bis zum Handytest gesperrt (gestaltung.md §7)"))
            for sel, body in re.findall(r"(@?[^{}@]+)\{([^{}]*)\}", css):
                sel = sel.strip()
                if not FONT_PROPS.search(body) or sel.startswith("@"):
                    continue
                teile = [x.strip() for x in sel.split(",")]
                for t in teile:
                    stark = t.startswith(".sd-html ") or re.match(r"^div\.", t)
                    if not stark and "!important" not in body:
                        findings.append(("ERROR", "G13",
                                         f"{ort}: Schriftregel fuer '{t}' verliert gegen .sd-html div — "
                                         f"Selektor '.sd-html {t}', !important oder Inline-Style verwenden"))
        if ort == "completedHtml":
            h3_styled = re.search(r"<h3[^>]*style\s*=\s*(\"[^\"]*|'[^']*)(color|font-weight)", html, re.I)
            if h3_styled:
                findings.append(("ERROR", "G13",
                                 "completedHtml: <h3> mit color/font-weight — arzt-direct erzwingt beides mit !important; <div> mit Inline-Style verwenden"))
            elif re.search(r"<h3[\s>]", html, re.I):
                findings.append(("INFO", "G13", "completedHtml: <h3> erscheint in fester Farbe und Staerke von arzt-direct — fuer eigene Gestaltung <div> mit Inline-Style"))
            elif re.search(r"<h[1-6][^>]*style\s*=", html, re.I):
                findings.append(("WARN", "G13", "completedHtml: gestylte Ueberschrift ungeprueft — <div> mit Inline-Style ist belegt"))
        if re.search(r"<script", html, re.I):
            findings.append(("ERROR", "G17", f"{ort}: <script> ist ungeprueft und gehoert nicht in ein Patientenformular"))
        if re.search(r"(src|href)\s*=\s*[\"']https?://[^\"']+\.(png|jpe?g|gif|svg|webp|css|woff2?)", html, re.I) or \
           re.search(r"url\(\s*[\"']?https?://", html, re.I):
            findings.append(("WARN", "G17", f"{ort}: externe Ressource ungeprueft — Bilder und Schriften als data-URI einbetten"))
        eingebettet = {m.lower() for m in re.findall(r"@font-face\s*\{[^}]*font-family\s*:\s*[\"']?([^;\"'}]+)", html, re.I)}
        for fam in re.findall(r"font-family\s*:\s*([^;\"}]+(?:\"[^\"]*\"[^;\"}]*)*)", html, re.I):
            erste = fam.split(",")[0].strip().strip("'\"").strip("&quot;").lower()
            if erste and erste not in SYSTEM_SCHRIFTEN and erste not in eingebettet and not erste.startswith("var("):
                findings.append(("WARN", "G17",
                                 f"{ort}: Schrift '{erste}' ist nicht per @font-face eingebettet — der Browser nimmt die naechste Familie der Liste"))
                break


# Inline-CSS-Eigenschaften, die im Gegentest (29.09.2026) in gerenderten Formularen belegt sind.
BELEGTE_INLINE_CSS = {"color", "font-family", "font-size", "font-weight", "font-style", "line-height",
                      "margin", "margin-top", "margin-bottom", "margin-left", "margin-right",
                      "padding", "padding-top", "padding-bottom", "padding-left", "padding-right",
                      "background", "background-color", "border", "border-top", "border-left",
                      "border-radius", "height", "width", "max-width", "vertical-align"}


def check_gestaltung_inline_css(survey, findings):
    """G18: Inline-Styles nur mit belegten Eigenschaften und einfachen Werten."""
    for ort, html in _html_quellen(survey):
        fremd = set()
        for st in re.findall(r"style\s*=\s*(?:\"([^\"]*)\"|'([^']*)')", html, re.I):
            for decl in (st[0] or st[1]).split(";"):
                if ":" not in decl:
                    continue
                prop, wert = [x.strip().lower() for x in decl.split(":", 1)]
                if prop not in BELEGTE_INLINE_CSS:
                    fremd.add(prop)
                elif prop.startswith("background") and re.search(r"gradient|url\(|image", wert):
                    fremd.add(f"{prop}: {wert.split('(')[0]}(…)")
        if fremd:
            findings.append(("WARN", "G18",
                             f"{ort}: ungepruefte Inline-CSS ({', '.join(sorted(fremd))}) — belegt sind nur einfache Farben, "
                             f"Schrift, Abstaende, Rahmen, Rundung, Groessen; ungeprueft nur auf ausdruecklichen Wunsch"))


def check_gestaltung_mobil(survey, findings):
    """I-Hinweise zum Smartphone (kein Fehler, aber vorhersehbar)."""
    for pfad, el in iter_all(survey):
        if isinstance(el.get("colCount"), int) and el["colCount"] >= 2:
            findings.append(("INFO", "G20", f"{pfad}: colCount {el['colCount']} — auf dem Smartphone eine Spalte"))


# ---------- Runner ----------

RULES = [
    check_duplicates,
    check_missing_name,
    check_visibleif_refs,
    check_expression_refs,
    check_karteitext_refs,
    check_iff_typo,
    check_de_locale,
    check_choices_completeness,
    check_missing_short_title,
    check_short_title_charclass,
    check_wfa_orz_shorttitle,
    check_matrix_without_expression,
    check_visible_score,
    check_required_on_conditional,
    check_long_pages,
    check_wide_matrix,
    check_wfainputtype_without_validator,
    check_gestaltung_properties,
    check_gestaltung_formular,
    check_gestaltung_typen,
    check_gestaltung_css,
    check_gestaltung_inline_css,
    check_gestaltung_mobil,
]


def lint(path: str) -> int:
    try:
        with open(path) as f:
            survey = json.load(f)
    except Exception as e:
        print(f"FATAL: kann '{path}' nicht laden: {e}")
        return 2

    findings: List[Tuple[str, str, str]] = []
    for rule in RULES:
        try:
            rule(survey, findings)
        except Exception as e:
            findings.append(("WARN", "X0", f"Lint-Rule {rule.__name__} crashed: {e}"))

    # Sort by severity
    order = {"ERROR": 0, "WARN": 1, "INFO": 2}
    findings.sort(key=lambda f: (order.get(f[0], 99), f[1]))

    print(f"==> Linting {path}\n")
    counts = Counter(f[0] for f in findings)

    if not findings:
        print("[OK] Keine Beanstandungen.")
    else:
        for sev, rule_id, msg in findings:
            tag = f"[{sev}]".ljust(8)
            print(f"{tag} {rule_id}: {msg}")

    print()
    print(f"==> {counts.get('ERROR', 0)} ERROR, "
          f"{counts.get('WARN', 0)} WARN, "
          f"{counts.get('INFO', 0)} INFO")

    if counts.get("ERROR", 0) > 0:
        print("==> Abgabe BLOCKIERT (ERRORs vorhanden)")
        return 1
    print("==> Lint passed.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 lint.py <pfad.json>")
        sys.exit(2)
    sys.exit(lint(sys.argv[1]))
