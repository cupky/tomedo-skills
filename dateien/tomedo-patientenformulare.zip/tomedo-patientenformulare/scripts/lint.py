#!/usr/bin/env python3
"""
lint.py — Pre-Flight-Linter fuer Patientenformulare (arzt-direct JSON).

Usage:
    python3 lint.py <pfad.json>

Exit:
    0 = keine ERRORs
    1 = mindestens ein ERROR
"""

import json
import re
import sys
from collections import Counter, defaultdict
from typing import Any, Dict, List, Tuple


# ---------- Helpers ----------

def iter_elements(survey: Dict[str, Any]):
    """Yield (page_name, element) for every element in every page."""
    for page in survey.get("pages", []):
        page_name = page.get("name", "?")
        for el in page.get("elements", []):
            yield page_name, el


def collect_names(survey: Dict[str, Any]) -> Dict[str, List[str]]:
    """Map name -> list of pages where it appears (for duplicate detection)."""
    m: Dict[str, List[str]] = defaultdict(list)
    for page_name, el in iter_elements(survey):
        n = el.get("name")
        if n:
            m[n].append(page_name)
    return m


def extract_referenced_names(text: str) -> List[str]:
    """Extract referenced field names from visibleIf/expression/template strings.

    Recognizes:
      {feldname}           — SurveyJS syntax
      wert("feldname")     — tomedo extension
      wert('feldname')     — variant
      $[text('feldname')]$ — karteitextHtmlTemplate
      $[text("feldname")]$ — variant
    """
    refs = set()
    # {feldname} — but skip Item, Spalte, Zeile, true/false/empty etc
    for m in re.finditer(r"\{([^}]+)\}", text):
        ref = m.group(1).strip()
        # Strip ".Zeile1" / ".Spalte2" matrix-cell suffixes
        ref = ref.split(".")[0]
        refs.add(ref)
    # wert("name") and wert('name')
    for m in re.finditer(r"""wert\s*\(\s*["']([^"']+)["']\s*\)""", text):
        ref = m.group(1).split(".")[0]
        refs.add(ref)
    # $[text('name')]$
    for m in re.finditer(r"""\$\[text\(\s*["']([^"']+)["']\s*\)\]\$""", text):
        refs.add(m.group(1))
    return list(refs)


# ---------- Rule checks ----------

def check_duplicates(survey, findings):
    """E1: name eindeutig"""
    names = collect_names(survey)
    for n, pages in names.items():
        if len(pages) > 1:
            findings.append(("ERROR", "E1", f"name '{n}' wird mehrfach verwendet (Pages: {', '.join(pages)})"))


def check_missing_name(survey, findings):
    """E2: name fehlt bei Nicht-html-Element"""
    for page_name, el in iter_elements(survey):
        if el.get("type") in ("html", "image"):
            continue
        if not el.get("name"):
            findings.append(("ERROR", "E2",
                             f"Element vom Typ '{el.get('type')}' auf Page '{page_name}' hat keinen 'name'"))


def check_visibleif_refs(survey, findings):
    """E3: visibleIf referenziert nicht-existenten name"""
    names = set(collect_names(survey).keys())
    # Page-level visibleIf
    for page in survey.get("pages", []):
        vi = page.get("visibleIf")
        if vi:
            for ref in extract_referenced_names(vi):
                if ref not in names:
                    findings.append(("ERROR", "E3",
                                     f"visibleIf der Page '{page.get('name')}' referenziert nicht-existenten name '{ref}'"))
    # Element-level visibleIf
    for page_name, el in iter_elements(survey):
        for key in ("visibleIf", "enableIf", "requiredIf"):
            vi = el.get(key)
            if vi:
                for ref in extract_referenced_names(vi):
                    if ref not in names:
                        findings.append(("ERROR", "E3",
                                         f"{key} von '{el.get('name')}' (Page '{page_name}') referenziert nicht-existenten name '{ref}'"))


def check_expression_refs(survey, findings):
    """E4: expression referenziert nicht-existenten name"""
    names = set(collect_names(survey).keys())
    for page_name, el in iter_elements(survey):
        expr = el.get("expression")
        if expr:
            for ref in extract_referenced_names(expr):
                if ref not in names:
                    findings.append(("ERROR", "E4",
                                     f"expression von '{el.get('name')}' (Page '{page_name}') referenziert nicht-existenten name '{ref}'"))
        # Validators mit type=expression auch pruefen
        for v in el.get("validators", []):
            if v.get("type") == "expression":
                vexpr = v.get("expression", "")
                for ref in extract_referenced_names(vexpr):
                    # ignoriere {selfname} wenn es das eigene feld ist
                    if ref != el.get("name") and ref not in names:
                        findings.append(("ERROR", "E4",
                                         f"Validator-expression von '{el.get('name')}' (Page '{page_name}') referenziert nicht-existenten name '{ref}'"))


def check_karteitext_refs(survey, findings):
    """E5: karteitextHtmlTemplate referenziert nicht-existenten name"""
    tmpl = survey.get("karteitextHtmlTemplate")
    if not tmpl:
        findings.append(("INFO", "I1", "karteitextHtmlTemplate fehlt — Default-Renderer wird verwendet"))
        return
    names = set(collect_names(survey).keys())
    refs_in_template = extract_referenced_names(tmpl)
    for ref in refs_in_template:
        if ref not in names:
            findings.append(("ERROR", "E5",
                             f"karteitextHtmlTemplate referenziert nicht-existenten name '{ref}'"))


def check_iff_typo(survey, findings):
    """E6: iff statt iif"""
    iff_re = re.compile(r"\biff\s*\(")
    for page_name, el in iter_elements(survey):
        expr = el.get("expression", "")
        if iff_re.search(expr):
            findings.append(("ERROR", "E6",
                             f"expression von '{el.get('name')}' verwendet 'iff(' — korrekt ist 'iif('"))
    tmpl = survey.get("karteitextHtmlTemplate", "")
    if iff_re.search(tmpl):
        findings.append(("ERROR", "E6", "karteitextHtmlTemplate verwendet 'iff(' — korrekt ist 'iif('"))


def check_de_locale(survey, findings):
    """W8: {"de": ...} statt {"default": ...} — Bestand hat einzelne Cases"""
    def scan(obj, path=""):
        if isinstance(obj, dict):
            if "de" in obj and "default" not in obj:
                if isinstance(obj.get("de"), str):
                    findings.append(("WARN", "W8",
                                     f"Locale-Key 'de' statt 'default' bei {path} — Konvention ist 'default'"))
            for k, v in obj.items():
                scan(v, f"{path}.{k}" if path else k)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                scan(v, f"{path}[{i}]")
    scan(survey)


def check_choices_completeness(survey, findings):
    """E8: choices ohne text"""
    for page_name, el in iter_elements(survey):
        for ch in el.get("choices", []):
            if isinstance(ch, dict):
                if "value" not in ch:
                    findings.append(("ERROR", "E8",
                                     f"choices-Eintrag in '{el.get('name')}' ohne 'value': {ch}"))
                if "text" not in ch:
                    findings.append(("ERROR", "E8",
                                     f"choices-Eintrag value='{ch.get('value')}' in '{el.get('name')}' ohne 'text'"))


# ---------- WARN ----------

WFA_ORZ_RE = re.compile(r"^\$(wfa|orz)[A-Za-z]+\$$")
ST_STRICT_RE = re.compile(r"^[A-Za-z]+$")


def check_missing_short_title(survey, findings):
    """W1: shortTitle fehlt"""
    skip_types = {"html", "image", "signaturepad"}
    for page_name, el in iter_elements(survey):
        if el.get("type") in skip_types:
            continue
        if el.get("name") and not el.get("shortTitle"):
            findings.append(("WARN", "W1",
                             f"shortTitle fehlt bei name='{el.get('name')}' (Page '{page_name}', type={el.get('type')})"))


def check_short_title_charclass(survey, findings):
    """I5: shortTitle mit Sonderzeichen (Bestandspraxis akzeptiert, INFO-Niveau)"""
    offenders = []
    for page_name, el in iter_elements(survey):
        st = el.get("shortTitle")
        if st and not ST_STRICT_RE.match(st):
            offenders.append(st)
    if offenders:
        # Eine Sammel-Meldung statt 40 Einzel-Warnungen
        sample = ", ".join(sorted(set(offenders))[:5])
        more = f" und {len(set(offenders))-5} weitere" if len(set(offenders)) > 5 else ""
        findings.append(("INFO", "I5",
                         f"{len(offenders)} shortTitle(s) mit Sonderzeichen (Umlaut/Bindestrich): {sample}{more} — Bestandspraxis akzeptiert, bei Neubogen [A-Za-z]+ vorziehen"))


def check_wfa_orz_shorttitle(survey, findings):
    """W3: $wfa$/$orz$-name ohne sprechenden shortTitle"""
    for page_name, el in iter_elements(survey):
        n = el.get("name", "")
        if WFA_ORZ_RE.match(n):
            st = el.get("shortTitle")
            if not st or st == n:
                findings.append(("WARN", "W3",
                                 f"Stammdaten-name '{n}' ohne sprechenden shortTitle"))


def check_matrix_without_expression(survey, findings):
    """W4: matrix ohne Parallel-expression"""
    matrices = []
    expr_refs = set()
    for page_name, el in iter_elements(survey):
        if el.get("type") == "matrix":
            matrices.append(el.get("name"))
        if el.get("type") == "expression":
            for ref in extract_referenced_names(el.get("expression", "")):
                expr_refs.add(ref)
    # Templates auch
    tmpl_refs = set(extract_referenced_names(survey.get("karteitextHtmlTemplate", "")))
    referenced = expr_refs | tmpl_refs
    for m in matrices:
        if m not in referenced:
            findings.append(("WARN", "W4",
                             f"matrix '{m}' wird nirgendwo per expression/template ausgelesen — Briefkommando liefert nur Indizes"))


def check_visible_score(survey, findings):
    """W6: Score-expression mit visible != false"""
    for page_name, el in iter_elements(survey):
        if el.get("type") == "expression":
            if el.get("visible") is not False:
                findings.append(("WARN", "W6",
                                 f"expression '{el.get('name')}' ohne 'visible: false' — taucht in Patient-UI auf"))


def check_required_on_conditional(survey, findings):
    """I6: isRequired + visibleIf (Bestandspraxis akzeptiert)"""
    count = 0
    for page_name, el in iter_elements(survey):
        if el.get("isRequired") and el.get("visibleIf"):
            count += 1
    if count > 0:
        findings.append(("INFO", "I6",
                         f"{count} Felder haben isRequired UND visibleIf — funktioniert, requiredIf ist semantisch sauberer"))


# ---------- INFO ----------

def check_long_pages(survey, findings):
    """I3: Page mit >15 Elementen"""
    for page in survey.get("pages", []):
        n = len(page.get("elements", []))
        if n > 15:
            findings.append(("INFO", "I3",
                             f"Page '{page.get('name')}' hat {n} Elemente — Mobile-Usability pruefen"))


def check_wide_matrix(survey, findings):
    """I4: matrix mit >4 Spalten"""
    for page_name, el in iter_elements(survey):
        if el.get("type") == "matrix":
            n = len(el.get("columns", []))
            if n > 4:
                findings.append(("INFO", "I4",
                                 f"matrix '{el.get('name')}' hat {n} Spalten — Mobile-Usability pruefen"))


def check_wfainputtype_without_validator(survey, findings):
    """I2: wfaInputType: number ohne numeric-validator"""
    for page_name, el in iter_elements(survey):
        if el.get("wfaInputType") == "number":
            vs = el.get("validators", [])
            if not any(v.get("type") in ("numeric", "expression") for v in vs):
                findings.append(("INFO", "I2",
                                 f"'{el.get('name')}' hat wfaInputType=number, aber keinen numeric-Validator"))


# ---------- Runner ----------

RULES = [
    check_duplicates,
    check_missing_name,
    check_visibleif_refs,
    check_expression_refs,
    check_karteitext_refs,
    check_iff_typo,
    check_de_locale,
    check_choices_completeness,
    check_missing_short_title,
    check_short_title_charclass,
    check_wfa_orz_shorttitle,
    check_matrix_without_expression,
    check_visible_score,
    check_required_on_conditional,
    check_long_pages,
    check_wide_matrix,
    check_wfainputtype_without_validator,
]


def lint(path: str) -> int:
    try:
        with open(path) as f:
            survey = json.load(f)
    except Exception as e:
        print(f"FATAL: kann '{path}' nicht laden: {e}")
        return 2

    findings: List[Tuple[str, str, str]] = []
    for rule in RULES:
        try:
            rule(survey, findings)
        except Exception as e:
            findings.append(("WARN", "X0", f"Lint-Rule {rule.__name__} crashed: {e}"))

    # Sort by severity
    order = {"ERROR": 0, "WARN": 1, "INFO": 2}
    findings.sort(key=lambda f: (order.get(f[0], 99), f[1]))

    print(f"==> Linting {path}\n")
    counts = Counter(f[0] for f in findings)

    if not findings:
        print("[OK] Keine Beanstandungen.")
    else:
        for sev, rule_id, msg in findings:
            tag = f"[{sev}]".ljust(8)
            print(f"{tag} {rule_id}: {msg}")

    print()
    print(f"==> {counts.get('ERROR', 0)} ERROR, "
          f"{counts.get('WARN', 0)} WARN, "
          f"{counts.get('INFO', 0)} INFO")

    if counts.get("ERROR", 0) > 0:
        print("==> Abgabe BLOCKIERT (ERRORs vorhanden)")
        return 1
    print("==> Lint passed.")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 lint.py <pfad.json>")
        sys.exit(2)
    sys.exit(lint(sys.argv[1]))
