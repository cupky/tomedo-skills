---
name: tomedo-patientenformulare
description: >-
  Erzeuge und modifiziere Patientenformulare im SurveyJS-JSON-Format mit zollsoft/tomedo-
  Erweiterungen, wie sie über arzt-direct ausgespielt werden. Verwende diesen Skill IMMER wenn
  Patientenformulare, PatF, Schmerzfragebogen, arzt-direct-Formular, JSON-Formular für tomedo,
  Anamnesebogen, Quartalfragebogen, Kontaktformular für die Praxis, Überweisungsformular,
  Einwilligungsformular, Rezeptanforderung, Aufklärungsbogen oder Patientenzufriedenheits-
  Fragebogen erwähnt werden. Auch verwenden bei Stichworten wie shortTitle,
  karteitextHtmlTemplate, $wfaPatient$/$orz$-Stammdaten-Binding, von-Korff-Score-Berechnung im
  Formular, expression-Score, formularLinks-Briefkommando, oder wenn der User eine JSON-Datei für
  arzt-direct hochlädt und etwas damit machen will. Auch wenn der User sagt baue ein Formular,
  ändere dieses Formular, füge ein Feld hinzu, ergänze einen Score oder mache das Formular
  international.
metadata:
  version: 1.0
---

# tomedo-Patientenformulare (arzt-direct)

Dieser Skill steuert das Erstellen und Modifizieren von Patientenformularen für eine schmerzmedizinische Praxis. Die Formulare sind SurveyJS-JSONs mit zollsoft-spezifischen Erweiterungen, werden in arzt-direct gehostet und schreiben Antworten + narratives HTML in den tomedo-Karteieintrag zurück.

> **Geltungsbereich der Belegvermerke.** Vermerke wie „im Referenzbestand belegt" oder „in den
> Referenzbögen nicht vorgekommen" beziehen sich auf einen real ausgewerteten Formularbestand
> **einer** Praxis. Sie sagen, was sich dort bewährt hat — nicht, was SurveyJS oder tomedo
> zulassen. Bei abweichendem Bedarf gilt die Herstellerdokumentation, und der Fall ist zu testen.

## Zentrale Mechanik

```
arzt-direct (SaaS)                            tomedo (PVS)
─────────────────                            ─────────────
JSON-Template                                karteieintrag
  → Web-UI füllt Patient aus       ────▶     ├ text = gerendertes karteitextHtmlTemplate
  → karteitextHtmlTemplate rendert            ├ formularelement (bezeichner = shortTitle)
  → $wfaXxx$/$orzXxx$ → Stammdaten            └ Stammdatenfelder (über $wfa$/$orz$)
```

Drei Pfade, wie Patientenantworten in tomedo sichtbar werden:

| Pfad | Quelle im JSON | Ziel in tomedo |
|---|---|---|
| **Narrative HTML** | `karteitextHtmlTemplate` (Top-Level) | `karteieintrag.text` |
| **Rohwerte** | Element-`name` + Element-`shortTitle` | `formularelement.wert` (mit `bezeichner` = shortTitle) |
| **Stammdaten** | Element-`name = "$wfaXxx$"` / `"$orzXxx$"` | tomedo-Patientenstammdaten (automatisches Binding) |

**Briefkommando-Auslesen aus tomedo:**
- Gesamttext: `$[karteiEintragWert FOR text _ N]$`
- Einzelfeld: `$[formularEintrag <PatF-Kürzel> <shortTitle> 0]$`
- Versand-Link: `$[formularLinks PatF-<n>]$`

### Zweiter Ausspielweg: Permalink-API (ohne Browser)

Ein Permalink-Formular ist nicht nur patientenseitig ausfuellbar, sondern auch **maschinell
per HTTP-POST befuellbar** — genutzt fuer Systemmeldungen in einen MFA-Arbeitsvorrat.
Vier Dinge, die dabei jedes Formular-Design beruehren:

1. Antworten sind **E2E gegen das Praxiszertifikat verschluesselt**; der SaaS ist Transportweg,
   nicht Mitleser.
2. **Validatoren laufen nur im Browser** — der API-Weg umgeht sie vollstaendig.
3. In tomedo sind `html`-Elemente und `description` **unsichtbar**; ein Arbeitsauftrag muss
   ein gefuelltes **Feld** sein.
4. Ohne Patientenzuordnung rendert `karteitextHtmlTemplate` **nie**.

Vollstaendiger Kontrakt, Verschluesselung, Anhaenge und Anzeigegrenzen:
`references/permalink-api.md`.

## Workflow: Neues Formular bauen

**Schritt 1 — Klären (Spec-first).** Bei neuen Formular-Anforderungen *vor* dem JSON-Bau eine kurze Spec produzieren:

1. Use Case + Zielgruppe + Auslieferungspfad (Mail-Link, Otk-Online-Rezeption, QR im Wartezimmer)
2. Welche Felder gehen in tomedo-**Stammdaten** zurück? (Liste mit `$wfa$`/`$orz$`-Mapping aus `references/stammdaten-bindings.md`)
3. Welche **Scores** sollen automatisch berechnet werden? (`references/score-builder.md`)
4. **Branching-Logik** (`visibleIf`) — Skizze
5. **`karteitextHtmlTemplate`** — was soll als Fließtext in den Karteieintrag?
6. Sprachen — nur Deutsch oder international?

Wenn nach Spec-Runde noch Unklarheiten bestehen: bis zu 3 Klärungsfragen mit Empfehlungsdefaults, dann mit Best-Guess weiter und Annahmen als „Open Question" markieren.

**Schritt 2 — Skeleton wählen.** Nimm das passende Asset:
- Reines Kontakt-/Triage-Formular → `assets/skeleton-kontakt.json`
- Anamnese/Verlauf mit Karteieintrag-HTML → `assets/skeleton-mit-karteitext.json`
- Internationale Variante → `assets/skeleton-international.json`

**Schritt 3 — Bauen.** Folge den Konventionen in `references/conventions.md`. Für jeden Element-Typ siehe `references/element-types.md`. Für Stammdaten-Felder siehe `references/stammdaten-bindings.md`. Für Scores siehe `references/score-builder.md`. Für das Render-Template siehe `references/karteitext-template.md`.

**Schritt 4 — Linten.** Vor Abgabe `python3 scripts/lint.py <pfad.json>` ausführen. Der Linter prüft mechanisch: eindeutige `name`s, vorhandene `shortTitle`s, Regex-Konformität, referenzielle Integrität von `visibleIf`/`expression`/`karteitextHtmlTemplate`, sowie 4 weitere Klassen von Fehlern. Liefert grün → JSON ist abgabefähig.

**Schritt 5 — Abgabe.** JSON in Code-Fence `json` ausgeben, dazu kurze Zusammenfassung: was das Formular tut, welche Stammdaten-Felder es zurückschreibt, welche Scores berechnet werden, welche `karteitextHtmlTemplate`-Stellen man kennen sollte, und welche Open Questions offen blieben.

## Workflow: Bestehendes Formular ändern

**Minimalinvasiv.** Nur die explizit benannten Stellen anfassen. `name` und `shortTitle` existierender Felder NIEMALS ändern (würde Briefkommandos und Aktionsketten brechen). Antworten als idempotenten Apply-Diff formulieren, nicht als Komplettneubau.

Beim Hinzufügen neuer Felder: prüfen, ob `karteitextHtmlTemplate` und (falls relevant) zugehörige Scores aktualisiert werden müssen.

## Verbindliche Konventionen (Kurzform)

Diese 12 Regeln gelten projektweit. Volltext mit Beispielen in `references/conventions.md`.

1. Jedes Nicht-`html`-/Nicht-`image`-Element bekommt `name` + `shortTitle`.
2. `name` ist projektweit eindeutig. Bei Stammdaten-Binding zwingend `$wfaXxx$` oder `$orzXxx$`-Schema.
3. `shortTitle` als Briefkommando-Bezeichner. Sicherste Variante: `^[A-Za-z]+$`. Praxis erlaubt auch Umlaute und Bindestriche, aber Brief-Test einplanen.
4. Bei `$wfa$`/`$orz$`-Namen wird `shortTitle` als sprechender deutscher Alias gesetzt (z. B. `$wfaPatientVorname$` → `"Vorname"`).
5. Lokalisierung: Plain String für rein deutsche Bögen, sonst `{default: …, en: …, …}`. **Niemals** `{de: …}` — der primäre Sprach-Key ist `default`.
6. Scores immer zusätzlich als `expression` mit `visible: false` + eigenem `shortTitle`.
7. `visibleIf`/`enableIf`/`requiredIf`/`expression` referenzieren nur existierende `name`s.
8. `matrix` ist UX-tauglich, aber jeder auszulesende Wert braucht zusätzlich ein `expression` mit `shortTitle` (Briefkommando liefert sonst nur Indizes).
9. `html`-Elemente: bewusst einsetzen, NICHT per Briefkommando abrufbar.
10. `karteitextHtmlTemplate` aktiv pflegen: jedes Brief-relevante Feld dort einbauen.
11. Pflichtfelder sparsam — `isRequired: true` blockt Absenden.
12. Mobile-first: Seiten klein, `matrix`-Spalten ≤ 4, sonst auf `radiogroup`/`button-single-choice` pro Item ausweichen.

## Score-Funktionen (im `expression`-Feld)

- `iif(cond, then, else)` — **nicht** `iff` (deutsche tomedo-Doku schreibt's falsch)
- `sum(a, b, …)`, `avg(a, b, …)`
- `wert("feldname")` — Feldzugriff (tomedo-Erweiterung)
- `wert("matrixname.Zeile1")` — Matrix-Zellenzugriff
- Vergleiche werden mit String-Literalen geschrieben (`< "30"`). Lexikographische Semantik möglich — bei mehrstelligen Schwellwerten Vorsicht (`< "30"` kommt nach `< "200"`!).

Detaillierte Score-Bauanleitungen für von-Korff, PDI, DASS-21, PHQ-9, GAD-7, MPSS, NRS in `references/score-builder.md`.

## Häufige Stolperfallen

- **`shortTitle` mit Sonderzeichen** — funktioniert in Referenzinstallation, aber Briefkommando-Robustheit nicht vollständig validiert (Backlog T7).
- **String-Vergleiche in `iif`** lexikographisch, nicht numerisch.
- **`matrix`-Briefkommando** liefert Indizes statt Labels — daher Parallel-`expression` mit `shortTitle`.
- **`$wfa$`/`$orz$`-Namen** dürfen nicht verändert werden, sonst bricht Stammdaten-Binding.
- **Keine `de`-Lokalisierung** — primärer Key heißt `default`.
- **Page-Level kann `visibleIf` UND `orzPageAction`** haben (`"otk"` öffnet Online-Termin-Kalender, `"stop"` bricht Workflow ab) — siehe `references/page-actions.md`.
- **Choices-`value`** sind generisch (`Item1`, `Item2`, …) — im `karteitextHtmlTemplate` referenziert als `{feldname} == [Item1]`.
- **18-stellige tomedo-Idents niemals als Zahl** verarbeiten (Formular-ID, Karteieintrags-ID). JSON-Parser behandeln Zahlen als Double, ab 2^53−1 wird gerundet (`1.29...e+17`) und der Ident zeigt auf ein anderes oder gar kein Objekt. Immer als String führen — in Python `json.loads(s, parse_int=str)`, in JavaScript Reviver oder Vorverarbeitung. Quelle: Warnung in `LLMToolCreateFormular`, siehe `references/llm-toolebene.md`.

## Reference-Files (lade bei Bedarf)

| Datei | Wann lesen |
|---|---|
| `references/conventions.md` | Vollständige Begründung der 12 Konventionen mit Beispielen |
| `references/element-types.md` | Wenn ein bestimmter Element-Typ gebraucht wird (Standard + zollsoft-Custom) |
| `references/stammdaten-bindings.md` | Wenn Stammdaten zurückgeschrieben werden sollen (`$wfa$`/`$orz$`-Tabelle) |
| `references/score-builder.md` | Wenn ein Score berechnet werden soll (mit fertigen Snippets für vkorff, PDI, PHQ-9, GAD-7, DASS-21, MPSS, NRS) |
| `references/karteitext-template.md` | Wenn das HTML-Render-Template gebaut/geändert wird |
| `references/page-actions.md` | Wenn Page-Level-Branching, Otk-Integration oder Workflow-Abbrüche gebraucht werden |
| `references/lint-rules.md` | Wenn Lint-Output interpretiert werden muss |
| `references/llm-toolebene.md` | Wenn ein eingegangenes Formular per KI ausgelesen, ein tomedo-Formular per KI geöffnet/vorbefüllt oder eine Ident-Rundungsfrage geklärt werden soll. **Dokumentiert, nicht geprüft** |

## Assets (Skeletons)

| Datei | Use Case |
|---|---|
| `assets/skeleton-kontakt.json` | Triage/Kontaktformular, 1 Page, ohne Stammdaten-Binding |
| `assets/skeleton-mit-karteitext.json` | Anamnese/Verlauf mit `karteitextHtmlTemplate` + Stammdaten-Block |
| `assets/skeleton-international.json` | Mehrsprachiges Formular (de/en/es/it/fr) |
| `assets/score-snippets.json` | Fertige `expression`-Blöcke für die Standard-Scores |

## Script

`scripts/lint.py <jsonpfad>` — mechanische Pre-Flight-Prüfung. Exit 0 = grün, Exit 1 = Verstöße. Output ist menschenlesbar, geordnet nach Schweregrad (ERROR/WARN/INFO). Vor jeder Abgabe ausführen.
