---
name: tomedo-patientenformulare
description: >-
  Erzeuge und ändere Patientenformulare im SurveyJS-JSON-Format mit zollsoft/tomedo-Erweiterungen
  für arzt-direct. Verwende diesen Skill IMMER bei Patientenformular, PatF, Schmerzfragebogen,
  arzt-direct-Formular, JSON-Formular für tomedo, Anamnese-, Quartals-, Kontakt-, Überweisungs-,
  Einwilligungs-, Aufklärungs- oder Zufriedenheitsbogen, Rezeptanforderung. Auch bei shortTitle,
  karteitextHtmlTemplate, $wfaPatient$/$orz$-Stammdaten, expression-Score (von Korff),
  formularLinks, einer hochgeladenen arzt-direct-JSON, oder wenn der User sagt baue/ändere ein
  Formular, füge ein Feld hinzu, ergänze einen Score, mache es international. Ebenso IMMER bei
  Gestaltung, Design, Formatierung, Layout, Corporate Design, CI, Farben, Schrift, CSS,
  style-Block, Abschlussseite, Kopfband, Hinweisbox, Logo oder Smartphone-Darstellung:
  Gestaltung nur aus der Freigabeliste. Auch bei Anfordern (E-Mail, QR-Code, iPad),
  Rückschrieb in Stammdaten, Inbox Patientenformulare, formularEintrag liefert leer.
metadata:
  version: 1.3
---

# tomedo-Patientenformulare (arzt-direct)

Dieser Skill steuert das Erstellen und Modifizieren von Patientenformularen für eine schmerzmedizinische Praxis. Die Formulare sind SurveyJS-JSONs mit zollsoft-spezifischen Erweiterungen, werden in arzt-direct gehostet und schreiben Antworten + narratives HTML in den tomedo-Karteieintrag zurück. Was tomedo selbst mit den Formularen macht (Pflege, Anfordern, Rücklauf, Auslesen), steht in `references/tomedo-seite.md` — überarbeitet im Oktober 2026, noch nicht in der Oberfläche Nachgestelltes als **[ungeprüft]** markiert.

> **Geltungsbereich der Belegvermerke.** Vermerke wie „im Referenzbestand belegt" oder „in den
> Referenzbögen nicht vorgekommen" beziehen sich auf einen real ausgewerteten Formularbestand
> **einer** Praxis. Sie sagen, was sich dort bewährt hat — nicht, was SurveyJS oder tomedo
> zulassen. Bei abweichendem Bedarf gilt die Herstellerdokumentation, und der Fall ist zu testen.

## Zentrale Mechanik

```
arzt-direct (SaaS)                            tomedo (PVS)
─────────────────                            ─────────────
JSON-Template                                Karteieintrag (Formular)
  → Web-UI füllt Patient aus       ────▶     ├ Karteitext = gerendertes karteitextHtmlTemplate
  → karteitextHtmlTemplate rendert            │   (ohne Template: Einstellung „Karteitext“ je Element)
                                              ├ Formularelemente: „Kurztitel“ (= shortTitle) + Antwort
                                              └ $wfa…$-Felder → Reiter „Rückschrieb“ → Stammdaten
```

Drei Pfade, wie Patientenantworten in tomedo sichtbar werden:

| Pfad | Quelle im JSON | Ziel in tomedo |
|---|---|---|
| **Narrative HTML** | `karteitextHtmlTemplate` (Top-Level) | Karteitext des Eintrags |
| **Rohwerte** | Element-`name` + Element-`shortTitle` | Formularelement: Antwort unter dem „Kurztitel“ (= `shortTitle`), `name` als technischer Schlüssel |
| **Stammdaten** | Element-`name = "$wfaXxx$"` | Abgleich im Reiter „Rückschrieb“; **automatisch nur**, wenn in tomedo eingeschaltet und je Feld erlaubt — Vorname, Nachname, Geburtsdatum, Geburtsort, E-Mail nie automatisch [ungeprüft]. `$orz…$` kennt tomedo nicht (`references/stammdaten-bindings.md`) |

**Briefkommando-Auslesen aus tomedo:**
- Gesamttext: `$[karteiEintragWert FOR text _ N]$`
- Einzelfeld: `$[formularEintrag <Formular-Kürzel> <Kurztitel> N]$` — **`N`, nicht `0`**: `0` ist ein Altersfilter „0 Tage“ und liefert nur Formulare von heute [ungeprüft]. Regeln in `references/tomedo-seite.md` §6
- Versand-Link: `$[formularLinks <Formular-Kürzel> …]$` (Argumente sind Kürzel; unbekanntes Kürzel ergibt „(bereits ausgefüllt)“ [ungeprüft]). In der Anforderungs-E-Mail heißt der Platzhalter `$[Formularlinks]$`, in der Terminerinnerung `$[selektierterTermin %formularlinks]$` (`references/tomedo-seite.md` §3)

### Zweiter Ausspielweg: Permalink-API (ohne Browser)

Ein Permalink-Formular ist nicht nur patientenseitig ausfuellbar, sondern auch **maschinell
per HTTP-POST befuellbar** — genutzt fuer Systemmeldungen in einen MFA-Arbeitsvorrat.
Vier Dinge, die dabei jedes Formular-Design beruehren:

1. Antworten sind **E2E gegen das Praxiszertifikat verschluesselt**; der SaaS ist Transportweg,
   nicht Mitleser.
2. **Validatoren laufen nur im Browser** — der API-Weg umgeht sie vollstaendig.
3. In tomedo sind `html`-Elemente und `description` in der Ansicht „Tabelle“, im Karteitext und
   im Brief **unsichtbar** (nur der Reiter „Web“ zeigt das Formular); ein Arbeitsauftrag muss
   ein gefuelltes **Feld** sein.
4. Ohne Patientenzuordnung rendert `karteitextHtmlTemplate` **nie**.

Vollstaendiger Kontrakt, Verschluesselung, Anhaenge und Anzeigegrenzen:
`references/permalink-api.md`.

## Gestaltung: nur Freigegebenes (verbindlich)

arzt-direct zeigt längst nicht alles, was SurveyJS kennt. Der Editor (die arzt-direct-Weboberfläche,
in tomedo über „Zum Editor“ geöffnet) verwirft beim Speichern still, arzt-direct überstimmt zur Laufzeit. **Deshalb gilt für jede Gestaltung:**

1. **Nur Mittel aus der Freigabeliste** (`references/gestaltung.md`, Abschnitt 1) verwenden. Was dort
   nicht steht, ist **ungeprüft** — auch wenn die SurveyJS-Dokumentation es kennt. Nicht
   improvisieren, nicht „ausprobieren", keine CSS-Klassen erfinden.
2. **Nie ein Mittel aus der Negativliste** unten verwenden. `scripts/lint.py` blockiert sie als
   ERROR (Regeln G1–G17).
3. Wünscht der Nutzer etwas Ungeprüftes: sagen, dass es ungeprüft ist, die freigegebene Alternative
   anbieten. Nur auf **ausdrücklichen** Wunsch einbauen und in der Abgabe als „ungeprüft, testen"
   markieren.
4. Vorlage für gestaltete Formulare: `assets/skeleton-gestaltung.json` — jedes Mittel darin ist belegt.

**Negativliste — nachweislich ohne Wirkung** (Gegentest 29.09.2026, survey-core 2.3.16):

| Nicht verwenden | Stattdessen |
|---|---|
| `panel.state` (eingeklappt), `questionTitleLocation: "left"` | offene Gruppe, Titel über dem Feld |
| `width`, `minWidth` | `startWithNewLine: false` |
| `boolean` mit `renderAs`, `label` oder `titleLocation: "hidden"` | `boolean` mit sichtbarem Titel und `labelTrue`/`labelFalse` |
| `showOtherItem`, `otherText` | eigene Option plus `text`-Frage mit `visibleIf` |
| `questionsOnPageMode: "questionPerPage"` | eine Seite je Frage |
| `rateColorMode`/`scaleColorMode` auf Zahlenskala | `rateType: "smileys"` oder Randtexte |
| `imagepicker`, `shortTitle` auf `panel`, `progressBarLocation: "top"` | `image` + `checkbox`; `shortTitle` weglassen; `aboveheader`/`belowheader` |
| HTML im Fragetitel | eigenes `html`-Element davor |
| `<style>` mit Schrift über reine `.klasse`; `--sjs-*`-Variablen (am `:root` wirkungslos, an `.sd-root-modern` mit `!important` vor Handytest gesperrt, `gestaltung.md` §7) | `.sd-html .klasse`, `!important` oder Inline-Style |
| `<h3 style="color…">` im `completedHtml` | `<div>` mit Inline-Style |
| Hausschrift ohne `@font-face` | Systemschrift (Georgia, Arial) oder eingebettete Schrift |

**Tragfähig sind vor allem Inline-Styles** in `html`-Elementen. Ein `<style>`-Block wirkt nur auf
seiner eigenen Seite. Auf dem Smartphone werden `colCount` 2/3 einspaltig.

## Workflow: Neues Formular bauen

**Schritt 1 — Klären (Spec-first).** Bei neuen Formular-Anforderungen *vor* dem JSON-Bau eine kurze Spec produzieren:

1. Use Case + Zielgruppe + Auslieferungspfad (E-Mail-Link, Terminerinnerung, QR-Code, iPad, arzt-direkt-Nachricht, Permalink — `references/tomedo-seite.md` §3). Wird auch **ohne Patient** angefordert (Neupatient, QR im Wartezimmer, Permalink), braucht das Formular Vorname, Nachname, Geburtsdatum als `$wfa…$`-Felder
2. Welche Felder gehen in tomedo-**Stammdaten** zurück? (`$wfa…$`-Liste aus `references/stammdaten-bindings.md`; ob automatisch oder nach Prüfung, stellt die Praxis in tomedo ein)
3. Welche **Scores** sollen automatisch berechnet werden? (`references/score-builder.md`)
4. **Branching-Logik** (`visibleIf`) — Skizze
5. **`karteitextHtmlTemplate`** — was soll als Fließtext in den Karteieintrag?
6. Sprachen — nur Deutsch oder international?

Wenn nach Spec-Runde noch Unklarheiten bestehen: bis zu 3 Klärungsfragen mit Empfehlungsdefaults, dann mit Best-Guess weiter und Annahmen als „Open Question" markieren.

**Schritt 2 — Skeleton wählen.** Nimm das passende Asset:
- Reines Kontakt-/Triage-Formular → `assets/skeleton-kontakt.json`
- Anamnese/Verlauf mit Karteieintrag-HTML → `assets/skeleton-mit-karteitext.json`
- Internationale Variante → `assets/skeleton-international.json`
- Gestaltetes Formular (Kopfband, Hinweisboxen, Abschlussseite) → `assets/skeleton-gestaltung.json`

**Schritt 3 — Bauen.** Folge den Konventionen in `references/conventions.md`. Für jeden Element-Typ siehe `references/element-types.md`. Für Stammdaten-Felder siehe `references/stammdaten-bindings.md`. Für Scores siehe `references/score-builder.md`. Für das Render-Template siehe `references/karteitext-template.md`. Für **jede Gestaltung** ausschließlich `references/gestaltung.md`, Abschnitt 1 (siehe „Gestaltung: nur Freigegebenes").

**Schritt 4 — Linten.** Vor Abgabe `python3 scripts/lint.py <pfad.json>` ausführen. Der Linter prüft mechanisch: eindeutige `name`s, vorhandene `shortTitle`s, Regex-Konformität, referenzielle Integrität von `visibleIf`/`expression`/`karteitextHtmlTemplate`, sowie weitere Klassen von Fehlern (u. a. doppelte oder per Briefkommando nicht adressierbare Kurztitel W9/W10, `$wfa…$`-Namen ohne Rückschrieb in tomedo I9), dazu die **Gestaltungsregeln G1–G17** gegen die Negativliste. Liefert grün → JSON ist abgabefähig. Ein G-ERROR wird behoben, nicht begründet.

**Schritt 5 — Abgabe.** JSON in Code-Fence `json` ausgeben, dazu kurze Zusammenfassung: was das Formular tut, welche Stammdaten-Felder es zurückschreibt, welche Scores berechnet werden, welche `karteitextHtmlTemplate`-Stellen man kennen sollte, und welche Open Questions offen blieben. Bei Gestaltung zusätzlich: welche Mittel verwendet wurden — alle aus der Freigabeliste, sonst ausdrücklich als „ungeprüft" benannt.

## Workflow: Bestehendes Formular ändern

**Minimalinvasiv.** Nur die explizit benannten Stellen anfassen. `name` und `shortTitle` existierender Felder NIEMALS ändern (würde Briefkommandos und Aktionsketten brechen). Antworten als idempotenten Apply-Diff formulieren, nicht als Komplettneubau.

Beim Hinzufügen neuer Felder: prüfen, ob `karteitextHtmlTemplate` und (falls relevant) zugehörige Scores aktualisiert werden müssen.

## Verbindliche Konventionen (Kurzform)

Diese 12 Regeln gelten projektweit. Volltext mit Beispielen in `references/conventions.md`.

1. Jedes Frage-Element bekommt `name` + `shortTitle`. Ausnahmen: `html` und `image` ohne beides, `panel` nur mit `name` — `shortTitle` auf `panel` lehnt der Editor ab.
2. `name` ist projektweit eindeutig. Bei Stammdaten-Binding zwingend ein `$wfaXxx$`-Name aus der Liste in `references/stammdaten-bindings.md` (`$orz…$`-Namen wertet nur arzt-direct aus).
3. `shortTitle` als Briefkommando-Bezeichner (in tomedo „Kurztitel“), **je Formular eindeutig**. Sicherste Variante: `^[A-Za-z]+$`. tomedo vergleicht exakt (Groß-/Kleinschreibung zählt); Umlaute, Bindestriche und einzelne Leerzeichen gehen, doppelte oder Rand-Leerzeichen nicht [ungeprüft].
4. Bei `$wfa$`/`$orz$`-Namen wird `shortTitle` als sprechender deutscher Alias gesetzt (z. B. `$wfaPatientVorname$` → `"Vorname"`).
5. Lokalisierung: Plain String für rein deutsche Bögen, sonst `{default: …, en: …, …}`. `{de: …}` ist kein Fehler: arzt-direct speichert selbst als `{de: …}` und zeigt es an. Für neue Bögen trotzdem `default` als primären Schlüssel nehmen.
6. Scores immer zusätzlich als `expression` mit `visible: false` + eigenem `shortTitle`.
7. `visibleIf`/`enableIf`/`requiredIf`/`expression` referenzieren nur existierende `name`s.
8. `matrix` ist UX-tauglich, aber jeder auszulesende Wert braucht zusätzlich ein `expression` mit `shortTitle` (Briefkommando liefert sonst nur Indizes).
9. `html`-Elemente: bewusst einsetzen, NICHT per Briefkommando abrufbar.
10. `karteitextHtmlTemplate` aktiv pflegen: jedes Brief-relevante Feld dort einbauen.
11. Pflichtfelder sparsam — `isRequired: true` blockt Absenden.
12. Mobile-first: Seiten klein, `matrix`-Spalten ≤ 4, sonst auf `radiogroup`/`button-single-choice` pro Item ausweichen.

## Score-Funktionen (im `expression`-Feld)

- `iif(cond, then, else)` — **nicht** `iff` (deutsche tomedo-Doku schreibt's falsch)
- `sum(a, b, …)`, `avg(a, b, …)`
- `wert("feldname")` — Feldzugriff (Erweiterung von arzt-direct, nicht von tomedo)
- `wert("matrixname.Zeile1")` — Matrix-Zellenzugriff
- Vergleiche werden mit String-Literalen geschrieben (`< "30"`). Lexikographische Semantik möglich — bei mehrstelligen Schwellwerten Vorsicht (`< "30"` kommt nach `< "200"`!).

Detaillierte Score-Bauanleitungen für von-Korff, PDI, DASS-21, PHQ-9, GAD-7, MPSS, NRS in `references/score-builder.md`.

## Häufige Stolperfallen

- **`formularEintrag … 0` liefert leer** — das letzte Argument ist die Auswahl; `0` heißt „nur Formulare von heute“. Immer `N` (neuestes), `J` (selektiert) oder eine Zeitangabe wie `90d` [ungeprüft].
- **`shortTitle` mit Sonderzeichen** — tomedo vergleicht den Kurztitel exakt; Umlaute und Bindestriche sind unkritisch. Probleme machen doppelte Kurztitel im selben Formular (irgendein Wert wird geliefert), doppelte oder Rand-Leerzeichen und abweichende Groß-/Kleinschreibung — ein unbekannter Kurztitel liefert **leer ohne Hinweis** [ungeprüft].
- **Karteitext ohne `karteitextHtmlTemplate`** — kommt aus der tomedo-Einstellung „Karteitext“ je Element (Admin › Patientenformulare › „Elemente und Karteitext“, Vorgabe „Niemals“) [ungeprüft]. Für verlässlichen Brief-Output trotzdem ein Template bauen.
- **String-Vergleiche in `iif`** lexikographisch, nicht numerisch.
- **`matrix`-Briefkommando** liefert Indizes statt Labels — daher Parallel-`expression` mit `shortTitle`.
- **`$wfa$`/`$orz$`-Namen** dürfen nicht verändert werden, sonst bricht Stammdaten-Binding.
- **`{de: …}` wird angezeigt** — der Server schreibt `{default: …}` beim Speichern selbst zu `{de: …}` um. Neue Bögen trotzdem mit `default`; ein Diff gegen die Live-Definition zeigt diese Umschreibung als Rauschen, nicht als Fehler.
- **Page-Level kann `visibleIf` UND `orzPageAction`** haben (`"otk"` öffnet Online-Termin-Kalender, `"stop"` bricht Workflow ab) — siehe `references/page-actions.md`.
- **Choices-`value`** sind generisch (`Item1`, `Item2`, …) — im `karteitextHtmlTemplate` referenziert als `{feldname} == [Item1]`.
- **18-stellige tomedo-Idents niemals als Zahl** verarbeiten (Formular-ID, Karteieintrags-ID). JSON-Parser behandeln Zahlen als Double, ab 2^53−1 wird gerundet (`1.29...e+17`) und der Ident zeigt auf ein anderes oder gar kein Objekt. Immer als String führen — in Python `json.loads(s, parse_int=str)`, in JavaScript Reviver oder Vorverarbeitung. Quelle: Warnung in `LLMToolCreateFormular`, siehe `references/llm-toolebene.md`.

- **Gestaltung verschwindet still** — der Editor von arzt-direct entfernt beim Speichern ohne Meldung u. a. `panel.state`, `questionTitleLocation`, `width`, `boolean.renderAs`/`label` und `showOtherItem`; arzt-direct setzt `questionsOnPageMode` zur Laufzeit auf `standard`. Vollständige Liste und Auswege in `references/gestaltung.md`.
- **Einzelhäkchen nicht bauen** — `boolean` mit `renderAs: "checkbox"` und `titleLocation: "hidden"` endet als Schalter „Nein/Ja" **ohne jeden Fragetext**.
- **`<style>` im `html`-Element**: Farbe und Rahmen wirken, Schriftart und -stärke nur mit `.sd-html .klasse`, `!important` oder Inline-Style; der Block gilt nur auf seiner eigenen Seite. Im `completedHtml` Überschriften als `<div>` statt `<h3>` setzen.
- **Abstände verdichten** — kein JSON-Hebel. Ein `<style>` mit Kartenpolster und Titelabstand (`!important`) im `html`-Element **jeder** Seite wirkt im Browser, im PDF nicht. Ein leeres `html`-Element als Spacer vergrößert Abstände, im PDF nur als fester Block. Rezept in `references/gestaltung.md` §7.

## Reference-Files (lade bei Bedarf)

| Datei | Wann lesen |
|---|---|
| `references/conventions.md` | Vollständige Begründung der 12 Konventionen mit Beispielen |
| `references/element-types.md` | Wenn ein bestimmter Element-Typ gebraucht wird (Standard + zollsoft-Custom) |
| `references/stammdaten-bindings.md` | Wenn Stammdaten zurückgeschrieben werden sollen (`$wfa$`/`$orz$`-Tabelle) |
| `references/score-builder.md` | Wenn ein Score berechnet werden soll (mit fertigen Snippets für vkorff, PDI, PHQ-9, GAD-7, DASS-21, MPSS, NRS) |
| `references/karteitext-template.md` | Wenn das HTML-Render-Template gebaut/geändert wird |
| `references/page-actions.md` | Wenn Page-Level-Branching, Otk-Integration oder Workflow-Abbrüche gebraucht werden |
| `references/lint-rules.md` | Wenn Lint-Output interpretiert werden muss |
| `references/llm-toolebene.md` | Wenn ein eingegangenes Formular per KI ausgelesen, ein tomedo-Formular per KI geöffnet/vorbefüllt oder eine Ident-Rundungsfrage geklärt werden soll. **Dokumentiert, nicht geprüft** |
| `references/tomedo-seite.md` | Was tomedo mit dem Formular macht: Pflegeort und Kürzel, Karteitext je Element, Vorbefüllung, Textbaustein/CKE aus Elementen, Anfordern (Wege, Link-Platzhalter, Neupatienten), Fälligkeitsbedingungen, Inbox und Zuordnung, Ansichten, `formularEintrag`-Regeln, Aktionsketten. **[ungeprüft]-Marken beachten** |
| `references/gestaltung.md` | Wenn ein Formular gestaltet wird: was im Browser wirkt, was der Editor verwirft, was arzt-direct überstimmt, CSS in `html`-Elementen, Verhalten auf dem Smartphone. **Belegt am 29.09.2026, survey-core 2.3.16** |

## Assets (Skeletons)

| Datei | Use Case |
|---|---|
| `assets/skeleton-kontakt.json` | Triage/Kontaktformular, 1 Page, ohne Stammdaten-Binding |
| `assets/skeleton-mit-karteitext.json` | Anamnese/Verlauf mit `karteitextHtmlTemplate` + Stammdaten-Block |
| `assets/skeleton-international.json` | Mehrsprachiges Formular (de/en/es/it/fr) |
| `assets/skeleton-gestaltung.json` | Gestaltetes Formular nur mit freigegebenen Mitteln: Kopfband, Hinweisbox, Abschlussseite, Skalen |
| `assets/score-snippets.json` | Fertige `expression`-Blöcke für die Standard-Scores |

## Script

`scripts/lint.py <jsonpfad>` — mechanische Pre-Flight-Prüfung. Exit 0 = grün, Exit 1 = Verstöße. Output ist menschenlesbar, geordnet nach Schweregrad (ERROR/WARN/INFO). Vor jeder Abgabe ausführen.
