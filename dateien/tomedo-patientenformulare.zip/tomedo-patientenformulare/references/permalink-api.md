# Permalink-API (wfa) — Formulare ohne Browser einsenden

Erhoben am Produktivsystem 08/2026 · arzt-direkt/wfa 3.5.5-alpha · tomedo v1.169.0.21.
Zweiter Ausspielweg neben der arzt-direkt-Oberflaeche: ein Formular per **reinem HTTP-POST**
befuellen. Kein Headless-Browser, kein GUI-Scripting, keine tomedo-Sitzung.

## 1. Der Kontrakt

Der API-Host ist **nicht** das Frontend, sondern der OTK-Server:

```
BASE = https://onlinetermine.arzt-direkt.com/api/wfb/app

Formular laden   GET  {BASE}/getWfaForm?instanceIdentifier=<instanz>&wfaFormId=<slug>&loadCertificate=true
Antwort senden   POST {BASE}/createWfaFormResponseFromPermalink
Datei anhaengen  POST {BASE}/uploadWfaFormResponseFile
```

Der Permalink `…/webforms/permalink/<instanz>/<slug>` zerlegt sich direkt in beide Parameter —
**der Slug ist die `wfaFormId`**. Beides ist unauthentifiziert erreichbar; genau das macht den
Permalink zum Permalink. Antwort-Body von `createWfaFormResponseFromPermalink` traegt die
server-vergebene `responseId`; die SSE-Queue ist der Kanal, ueber den tomedo abholt.

## 2. Die Antworten sind Ende-zu-Ende verschluesselt

`getWfaForm` liefert mit `loadCertificate=true` ein X.509-Zertifikat (`CN=Tomedo`, RSA-2048).
Der Browser verschluesselt die Antworten **vor** dem Absenden dagegen; der SaaS speichert nur
Chiffrat, entschluesseln kann ausschliesslich tomedo.

| Schicht | Verfahren |
|---|---|
| Schluesseltransport | RSAES-OAEP, SHA-256, MGF1-SHA-256 |
| Inhalt | AES-256-CBC, PKCS#7-Padding, frischer IV |
| Huelle | CMS `EnvelopedData` (OID 1.2.840.113549.1.7.3), DER, base64 |

Das ist ein **RFC-Standard, kein Eigenbau** — erkennen war billiger als umgehen, und mit
`asn1crypto` + `cryptography` in ~60 Zeilen nachbaubar. **Datenschutzbewertung: der SaaS ist
Transportweg, nicht Mitleser.** `openssl cms` scheidet aus: macOS liefert LibreSSL (kein OAEP),
und selbst OpenSSL 3.6 lehnt `-keyopt rsa_padding_mode:oaep` beim *Verschluesseln* ab.

## 3. Der Klartext ist doppelt JSON-kodiert

Der Crypto-Worker stringifiziert sein bereits stringifiziertes Argument erneut. Verschluesselt
wird ein JSON-String-**Literal**:

```
Klartext = "{\"feld\":\"wert\",\"anzahl\":3}"      ← mit den Anfuehrungszeichen!
```

Einfach kodiert waere gueltiges JSON, und der Server nimmt es **genauso an** (er sieht nur
Chiffrat) — tomedo zeigt dann Muell. Deshalb der Grundsatz: **jede Integration beginnt mit
einem Testdatensatz, bevor Produktivcode entsteht.**

Nebenregel: der Permalink-Viewer ersetzt in Werten der **obersten** Ebene `"` durch `'`;
verschachtelte Strings (z. B. in einer Matrix) tastet er nicht an.

## 4. Zwei Pruefungen, die der API-Weg erzwingt

1. **Validatoren nachbilden.** Die Formular-Validatoren laufen nur im Browser; der API-Weg
   umgeht sie vollstaendig. Der Server nimmt auch einen Wert an, den `minLength`/`maxLength`
   verboten haetten.
2. **Feldnamen-Kontrakt pruefen.** Eigene Feldnamen gegen die **live** hinterlegte Definition
   vergleichen und bei Abweichung mit Klartextmeldung abbrechen. Der Server nimmt jede
   Einsendung an, und tomedo ordnet unbekannte Feldnamen niemandem zu — ein vergessener
   Upload fuehrt zu **stillem Datenverlust**.

## 5. Dateianhang — beide Wege belegt

**A · Inhalt in der Antwort.** Feldwert ist die SurveyJS-Form `[{_id, name, type, content}]`,
`content` als Data-URL (`data:text/html;base64,…`). Ein Request.

**B · Datei separat** (der Weg des Clients, empfohlen):

```
POST {BASE}/uploadWfaFormResponseFile
     {"responseId": "<aus der Einsendung>", "encryptedSjsExtractedFile": "<base64 CMS>"}
```

Verschluesselt wird `{file: {_id, name, type, content}, question: "<Feldname>"}` — mit
**derselben** doppelten JSON-Kodierung. B haelt die Antwort schlank und erlaubt, Uploads
einzeln zu wiederholen (dreimal, 2 s Abstand).

## 6. Was in tomedo sichtbar ist — und was nicht

| Element | In tomedo sichtbar? |
|---|---|
| Feld mit Antwortwert | **ja** — Ansicht *Tabelle*, Paare aus Kurztitel und Antwort |
| `html`-Element (statischer Text) | **nein** — nur im Webformular, das im Alltag niemand aufruft |
| `description` eines Feldes | **nein** |
| `karteitextHtmlTemplate` | nur bei Patientenzuordnung |
| Dateianhang | ja — Tab *Anhang*, „Herunterladen" und „Datei oeffnen" |

**Konsequenz:** ein Arbeitsauftrag an die MFA muss ein **gefuelltes Feld** sein, kein
Formulartext. Ein „grosser Hinweis" im Formular ist genau dort unsichtbar, wo gearbeitet wird.

## 7. Ohne Patientenzuordnung kein Karteieintrag

Eine Permalink-Einsendung kommt ohne Patientenbezug an. Folge: Rueckschrieb und Anhang-CKE
bleiben leer, `karteitextHtmlTemplate` rendert **nie**. Ein Karteieintrag haengt an einem
Patienten — eine Sammelmeldung ueber mehrere Patienten kann keinen haben. Der Umweg
(automatische Zuordnung zu einer festen Sammelakte) existiert, **lohnt aber nicht**: dieselbe
Pop-over-Bedienung, derselbe zweistufige Klick, dafuer Sammelakte und Zuordnungsregel als
Dauerlast. `karteitextHtmlTemplate` gehoert in solchen Formularen entfernt (toter Code).

## 8. In Formularfeldern ist keine URL klickbar — im Dateianhang schon

| Versuch | Ergebnis |
|---|---|
| nackte URL im Textfeld | roher Text |
| `<a href="tomedo://…">` im Feldwert | wird gerendert (blau, unterstrichen), **nicht klickbar** — und HTML-Rendering kostet die Zeilenumbrueche |
| Markdown `[Text](url)` | roher Text |
| `matrixdynamic` | als serialisiertes JSON gespeichert und so angezeigt |

**Was funktioniert: eine angehaengte HTML-Datei.** „Anhang → Datei oeffnen" stellt sie im
Browser dar, und **dort** loest der Browser `tomedo://…` auf (Einmal-Bestaetigung).
Regeln fuer so eine Datei:

- **eigenstaendig** — kein Script, kein externes CSS, keine `http`-Adresse. Eine Datei mit
  Patientendaten, die etwas nachlaedt, ist ein Datenabfluss.
- **DB-Werte maskieren** (`html.escape`) — sonst ist es eine Injektionsluecke.
- **kein Link ohne Ident.** Ein toter Link erzeugt den irrefuehrenden 404; sichtbar „keine ID"
  ist ehrlicher. Deeplink-Regeln: `tomedo-metabase-migration/references/deep-linking.md`.

## 9. Die Live-Definition ist die Quelle der Wahrheit

Nach dem Hochladen einer JSON-Definition ist die live hinterlegte Fassung **nicht** die
eingereichte. Beobachtet: `numeric`-Validator mit `minValue` → ersetzt durch
`{"type":"expression","expression":"isValidNumber({feld})"}` (die `minValue`-Regel ist danach
**weg**), `inputType: "custom-number"` wird ergaenzt, zu jedem lokalisierten Text kommt eine
`de:`-Kopie neben `default:`. **Regel:** nach jedem Upload die Live-Definition ziehen und die
eigene Kopie nachziehen; Regeln, die der Editor verwirft, muessen im eigenen Code leben.

## 10. Sicherheitsgrenze

Eine „Sicherheitsfrage" im Formular ist ein **Plausibilitaetsmerkmal, kein Zugangsschutz** —
der Permalink ist oeffentlich. Ohne Validator markiert sie nur; mit `regex`-Validator blockt
sie, dafuer steht die erwartete Antwort in der ausgelieferten Definition. Als Absender-Kennung
keinen Personennamen verwenden: eine Systembezeichnung ist genauso vertrauenswuerdig fuer die
MFA und ueberlebt Personalwechsel.
