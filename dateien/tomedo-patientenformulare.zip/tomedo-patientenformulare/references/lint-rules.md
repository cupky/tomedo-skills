# Lint-Regeln

`scripts/lint.py` prüft ein PatF-JSON mechanisch gegen diese Regeln. Schweregrade:

- **ERROR** — JSON ist mit hoher Wahrscheinlichkeit defekt, blockt Abgabe (Exit 1)
- **WARN** — Konvention verletzt, sollte begründet werden
- **INFO** — Hinweis, oft harmlos oder Bestandspraxis

## ERROR-Regeln

### E1 — Doppelter `name`

Jeder Element-`name` muss projektweit eindeutig sein. Auch über Pages hinweg.

```
ERROR: name 'Frage3' wird mehrfach verwendet (Pages: Triage, Details)
```

### E2 — `name` fehlt bei Nicht-`html`-Element

Jedes Element außer `html` und `image` braucht einen `name` — auch Fragen innerhalb von Panels.

### E3 — `visibleIf`/`enableIf`/`requiredIf` referenziert nicht-existenten `name`

Beispiel aus dem Referenzbestand (`survey-2.json`):
```
ERROR: visibleIf von 'medi4' referenziert nicht-existenten name 'medi6'
```
→ `medi6` wurde irgendwann entfernt, die Referenz blieb stehen. Echter Bug, sollte gepatcht werden.

### E4 — `expression` referenziert nicht-existenten `name`

Erkennt sowohl `{name}`-Syntax als auch `wert("name")`-Syntax. Matrix-Zell-Referenzen (`wert("matrix.Zeile1")`) reduziert der Linter auf den Matrix-Namen.

### E5 — `karteitextHtmlTemplate` referenziert nicht-existenten `name`

`$[text('xyz')]$` oder `{xyz}` im Template, wo `xyz` nicht existiert.

### E6 — `iff` statt `iif`

Häufiger Tippfehler durch die fehlerhafte deutsche tomedo-Doku. Im JSON immer `iif`.

### E8 — Choices-Item ohne `value` oder `text`

```json
"choices": [ { "value": "Item1" } ]   // fehlender text → ERROR
"choices": [ "Item1" ]                 // legitime Kurzschreibweise, kein Error
```

## WARN-Regeln

### W1 — `shortTitle` fehlt

Element hat einen `name`, aber keinen `shortTitle`. Damit ist es per `$[formularEintrag …]$`-Briefkommando nicht abrufbar.

Ausnahme: `html`-, `image`- und `signaturepad`-Elemente brauchen keinen `shortTitle`.

### W3 — `$wfa$`/`$orz$`-`name` ohne sprechenden `shortTitle`

Stammdaten-Bindings sollten einen sprechenden deutschen `shortTitle` haben (z. B. `$wfaPatientVorname$` → `"Vorname"`), nicht den `$…$`-Namen selbst.

### W4 — `matrix`-Element ohne Parallel-`expression`

Matrizen liefern im Briefkommando nur Indizes. Wenn die Matrix nirgendwo per parallele `expression` oder im Template ausgewertet wird, ist sie schwer im Brief verwertbar.

### W6 — Score-`expression` mit `visible != false`

Score-Elemente sollten normalerweise `visible: false` haben, damit sie nicht in der Patient-UI auftauchen.

### W8 — `{"de": "..."}` statt `{"default": "..."}`

SurveyJS-Konvention: primärer Sprach-Key heißt `default`. Kein Anzeigefehler: arzt-direct speichert selbst `{"de": …}` und zeigt es an (belegt 29.09.2026). Die Warnung bleibt, weil nur `default` als Rückfallsprache für weitere Sprachen dient. Bei einer aus arzt-direct gezogenen Live-Definition ist W8 an jeder Textstelle zu erwarten und kein Handlungsbedarf.

## INFO-Regeln

### I1 — `karteitextHtmlTemplate` fehlt

Das Formular hat keine Render-Direktive. Der Karteieintrags-Fließtext entsteht dann über einen Default-Renderer (Verhalten nicht 100 % spezifiziert).

### I2 — `wfaInputType: "number"` ohne Numeric-Validator

UI-Hint für Zifferntastatur ist gesetzt, aber kein `validators: [{ type: "numeric", … }]`. Funktioniert, lässt aber nicht-numerische Eingaben durch.

### I3 — Page mit >15 Elementen

Mobile-Usability-Hinweis.

### I4 — `matrix` mit >4 Spalten

Mobile-Usability-Hinweis. Schmerz-Skalen 0–10 (= 11 Spalten) sind im Referenzbestand üblich — funktioniert auf großen Smartphones, auf kleinen Displays scrollig.

### I5 — `shortTitle` mit Sonderzeichen

Sammel-Meldung statt Einzel-Warnungen. Referenzbestand nutzt Umlaute und Bindestriche breit — funktioniert beim Auslesen via `karteiEintragWert FOR text _ N`. Brief-Kompatibilität via `$[formularEintrag …]$` mit Sonderzeichen ist nicht abschließend praxis-validiert (Backlog T7). Pragmatik: bei Neubogen `[A-Za-z]+` einhalten, im Bestand nicht aktiv ändern.

### I6 — `isRequired` + `visibleIf`

Funktioniert. `requiredIf` ist semantisch sauberer, aber Bestandspraxis akzeptiert die Kombination.

### I7 — `html`-Element traegt eine Arbeitsanweisung

`html`-Element enthaelt Signalwoerter (`bitte`, `Aufgabe`, `Auftrag`, `pruefen`, `melden`).
In tomedo ist das Element unsichtbar — die Anweisung erreicht den internen Empfaenger nie.
→ als Feld mit Wert modellieren (`conventions.md` §9).

### I8 — `karteitextHtmlTemplate` in einem Formular ohne Patientenbezug

Formular wird per Permalink/API eingesendet (kein `$wfaPatient$`-Binding, keine
Stammdatenfelder), traegt aber ein `karteitextHtmlTemplate`. Das Template rendert nie.
→ entfernen (`karteitext-template.md`, Stolperfallen).

## Gestaltungsregeln (G)

Quelle: `gestaltung.md` (Gegentest 29.09.2026, survey-core 2.3.16). Grundsatz: nur freigegebene
Gestaltungsmittel. Was **nachweislich nicht wirkt**, ist ERROR und wird behoben, nicht begründet;
was **nicht geprüft** ist, ist WARN. Seit Fassung 1.2 prüft der Linter auch Fragen **in Panels**
(bis 1.1 nur die oberste Ebene).

| Regel | Stufe | Befund |
|---|---|---|
| G1 | ERROR | `panel.state` — beim Speichern verworfen |
| G2 | ERROR | `questionTitleLocation` (Element, Panel, Formular) — verworfen |
| G3 | ERROR | `width`, `minWidth`, `maxWidth` — verworfen |
| G4 | ERROR | `boolean` mit `renderAs`, `label` oder `titleLocation: "hidden"` — Schalter ohne Fragetext |
| G5 | ERROR | `showOtherItem`, `hasOther`, `otherText` — verworfen |
| G6 | ERROR | `questionsOnPageMode: "questionPerPage"` — arzt-direct setzt `standard` |
| G7 | ERROR | `rateColorMode`/`scaleColorMode` auf `rating` ohne `rateType: "smileys"` |
| G8 | ERROR | Fragetyp `imagepicker` — Editor lehnt ab |
| G9 | ERROR | `shortTitle` auf `panel` — Editor meldet „Unknown property" |
| G10 | ERROR | `progressBarLocation: "top"` — Editor lehnt ab |
| G11 | WARN | `showQuestionNumbers`, `editText` — verworfen, wirkungslos |
| G12 | ERROR | HTML-Tags im Fragetitel — werden roh angezeigt |
| G13 | ERROR | `<style>`-Schriftregel über reine Klasse (verliert gegen `.sd-html div`); `<h3>` mit `color`/`font-weight` im `completedHtml`. INFO bei schlichter `<h3>` |
| G14 | ERROR | `--sjs-*`-Variablen im `<style>` — am `:root` gewinnt das Inline-Theme von arzt-direct; an `.sd-root-modern` mit `!important` wirkt `--sjs-base-unit`, bleibt aber bis zum Handytest gesperrt (`gestaltung.md` §7) |
| G15 | WARN | `<style>`-Block überhaupt — wirkt nur auf seiner Seite |
| G16 | WARN | `maskType`/`maskSettings` am `datepicker` — verworfen |
| G17 | ERROR/WARN | `<script>` (ERROR); externe Bilder/Schriften, Schriftfamilie ohne `@font-face` (WARN) |
| G20 | INFO | `colCount` ≥ 2 — auf dem Smartphone eine Spalte |

Positivkontrolle: `assets/skeleton-gestaltung.json` muss 0 ERROR ergeben.

## Beispiel-Lint-Output (aus echtem Bestand)

```
==> Linting survey-2.json

[ERROR]  E3: visibleIf von 'medi4' referenziert nicht-existenten name 'medi6'
[ERROR]  E3: visibleIf von 'medi4-t' referenziert nicht-existenten name 'medi6'
[WARN]   W4: matrix 'intensitaet-ruhe-bel' wird nirgendwo per expression/template ausgelesen
[WARN]   W4: matrix 'behandlungen-effekt' wird nirgendwo per expression/template ausgelesen
[WARN]   W8: Locale-Key 'de' statt 'default' bei pages[0].elements[0].title
[INFO]   I1: karteitextHtmlTemplate fehlt — Default-Renderer wird verwendet
[INFO]   I3: Page 'allgmedi-vorschmemed' hat 19 Elemente — Mobile-Usability pruefen
[INFO]   I4: matrix 'schmerz-vkorff' hat 11 Spalten — Mobile-Usability pruefen
[INFO]   I5: 42 shortTitle(s) mit Sonderzeichen — Bestandspraxis akzeptiert
[INFO]   I6: 23 Felder haben isRequired UND visibleIf

==> 2 ERROR, 3 WARN, 5 INFO
==> Abgabe BLOCKIERT (ERRORs vorhanden)
```

Exit-Code: 1 bei mindestens einem ERROR, 0 sonst.
