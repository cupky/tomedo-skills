# Lint-Regeln

`scripts/lint.py` prüft ein PatF-JSON mechanisch gegen diese Regeln. Schweregrade:

- **ERROR** — JSON ist mit hoher Wahrscheinlichkeit defekt, blockt Abgabe (Exit 1)
- **WARN** — Konvention verletzt, sollte begründet werden
- **INFO** — Hinweis, oft harmlos oder Bestandspraxis

## ERROR-Regeln

### E1 — Doppelter `name`

Jeder Element-`name` muss projektweit eindeutig sein. Auch über Pages hinweg.

```
ERROR: name 'Frage3' wird mehrfach verwendet (Pages: Triage, Details)
```

### E2 — `name` fehlt bei Nicht-`html`-Element

Jedes Element außer `html` und `image` braucht einen `name`.

### E3 — `visibleIf`/`enableIf`/`requiredIf` referenziert nicht-existenten `name`

Beispiel aus dem Referenzbestand (`survey-2.json`):
```
ERROR: visibleIf von 'medi4' referenziert nicht-existenten name 'medi6'
```
→ `medi6` wurde irgendwann entfernt, die Referenz blieb stehen. Echter Bug, sollte gepatcht werden.

### E4 — `expression` referenziert nicht-existenten `name`

Erkennt sowohl `{name}`-Syntax als auch `wert("name")`-Syntax. Matrix-Zell-Referenzen (`wert("matrix.Zeile1")`) reduziert der Linter auf den Matrix-Namen.

### E5 — `karteitextHtmlTemplate` referenziert nicht-existenten `name`

`$[text('xyz')]$` oder `{xyz}` im Template, wo `xyz` nicht existiert.

### E6 — `iff` statt `iif`

Häufiger Tippfehler durch die fehlerhafte deutsche tomedo-Doku. Im JSON immer `iif`.

### E8 — Choices-Item ohne `value` oder `text`

```json
"choices": [ { "value": "Item1" } ]   // fehlender text → ERROR
"choices": [ "Item1" ]                 // legitime Kurzschreibweise, kein Error
```

## WARN-Regeln

### W1 — `shortTitle` fehlt

Element hat einen `name`, aber keinen `shortTitle`. Damit ist es per `$[formularEintrag …]$`-Briefkommando nicht abrufbar.

Ausnahme: `html`-, `image`- und `signaturepad`-Elemente brauchen keinen `shortTitle`.

### W3 — `$wfa$`/`$orz$`-`name` ohne sprechenden `shortTitle`

Stammdaten-Bindings sollten einen sprechenden deutschen `shortTitle` haben (z. B. `$wfaPatientVorname$` → `"Vorname"`), nicht den `$…$`-Namen selbst.

### W4 — `matrix`-Element ohne Parallel-`expression`

Matrizen liefern im Briefkommando nur Indizes. Wenn die Matrix nirgendwo per parallele `expression` oder im Template ausgewertet wird, ist sie schwer im Brief verwertbar.

### W6 — Score-`expression` mit `visible != false`

Score-Elemente sollten normalerweise `visible: false` haben, damit sie nicht in der Patient-UI auftauchen.

### W8 — `{"de": "..."}` statt `{"default": "..."}`

SurveyJS-Konvention: primärer Sprach-Key heißt `default`. Im Referenzbestand kommen 2 `de`-Cases vor, deren Verhalten unklar ist — bei Neubauten sicher `default` verwenden.

## INFO-Regeln

### I1 — `karteitextHtmlTemplate` fehlt

Das Formular hat keine Render-Direktive. Der Karteieintrags-Fließtext entsteht dann über einen Default-Renderer (Verhalten nicht 100 % spezifiziert).

### I2 — `wfaInputType: "number"` ohne Numeric-Validator

UI-Hint für Zifferntastatur ist gesetzt, aber kein `validators: [{ type: "numeric", … }]`. Funktioniert, lässt aber nicht-numerische Eingaben durch.

### I3 — Page mit >15 Elementen

Mobile-Usability-Hinweis.

### I4 — `matrix` mit >4 Spalten

Mobile-Usability-Hinweis. Schmerz-Skalen 0–10 (= 11 Spalten) sind im Referenzbestand üblich — funktioniert auf großen Smartphones, auf kleinen Displays scrollig.

### I5 — `shortTitle` mit Sonderzeichen

Sammel-Meldung statt Einzel-Warnungen. Referenzbestand nutzt Umlaute und Bindestriche breit — funktioniert beim Auslesen via `karteiEintragWert FOR text _ N`. Brief-Kompatibilität via `$[formularEintrag …]$` mit Sonderzeichen ist nicht abschließend praxis-validiert (Backlog T7). Pragmatik: bei Neubogen `[A-Za-z]+` einhalten, im Bestand nicht aktiv ändern.

### I6 — `isRequired` + `visibleIf`

Funktioniert. `requiredIf` ist semantisch sauberer, aber Bestandspraxis akzeptiert die Kombination.

### I7 — `html`-Element traegt eine Arbeitsanweisung

`html`-Element enthaelt Signalwoerter (`bitte`, `Aufgabe`, `Auftrag`, `pruefen`, `melden`).
In tomedo ist das Element unsichtbar — die Anweisung erreicht den internen Empfaenger nie.
→ als Feld mit Wert modellieren (`conventions.md` §9).

### I8 — `karteitextHtmlTemplate` in einem Formular ohne Patientenbezug

Formular wird per Permalink/API eingesendet (kein `$wfaPatient$`-Binding, keine
Stammdatenfelder), traegt aber ein `karteitextHtmlTemplate`. Das Template rendert nie.
→ entfernen (`karteitext-template.md`, Stolperfallen).

## Beispiel-Lint-Output (aus echtem Bestand)

```
==> Linting survey-2.json

[ERROR]  E3: visibleIf von 'medi4' referenziert nicht-existenten name 'medi6'
[ERROR]  E3: visibleIf von 'medi4-t' referenziert nicht-existenten name 'medi6'
[WARN]   W4: matrix 'intensitaet-ruhe-bel' wird nirgendwo per expression/template ausgelesen
[WARN]   W4: matrix 'behandlungen-effekt' wird nirgendwo per expression/template ausgelesen
[WARN]   W8: Locale-Key 'de' statt 'default' bei pages[0].elements[0].title
[INFO]   I1: karteitextHtmlTemplate fehlt — Default-Renderer wird verwendet
[INFO]   I3: Page 'allgmedi-vorschmemed' hat 19 Elemente — Mobile-Usability pruefen
[INFO]   I4: matrix 'schmerz-vkorff' hat 11 Spalten — Mobile-Usability pruefen
[INFO]   I5: 42 shortTitle(s) mit Sonderzeichen — Bestandspraxis akzeptiert
[INFO]   I6: 23 Felder haben isRequired UND visibleIf

==> 2 ERROR, 3 WARN, 5 INFO
==> Abgabe BLOCKIERT (ERRORs vorhanden)
```

Exit-Code: 1 bei mindestens einem ERROR, 0 sonst.
