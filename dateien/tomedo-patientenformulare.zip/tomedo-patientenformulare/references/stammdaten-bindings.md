# Stammdaten-Bindings

Felder mit `name = "$wfaXxx$"` erkennt tomedo als **Stammdatenfelder**. Zurückgeschrieben werden sie aber nicht von
arzt-direct und nicht bedingungslos, sondern vom tomedo-Server nach einer Einstellung der Praxis
(Stand Oktober 2026):

1. **Automatisch** nur, wenn unter Admin › Patientenformulare › „Globale Einstellungen“ › „Automatischer Rückschrieb“
   das Kästchen „automatischen Rückschrieb aktivieren“ gesetzt ist **und** das Feld dort auf „Immer“ steht [ungeprüft].
2. **Nie automatisch** – „aus datenschutzrechtlichen Gründen“ – Vorname, Nachname, Geburtsdatum, Geburtsort, E-Mail.
3. **Sonst** gleicht das Praxisteam ab: Reiter **„Rückschrieb“** am eingegangenen Formular, Spalten „Eigenschaft“, „In
   tomedo“, „Im Patientenformular“, „Übernehmen“; Knöpfe „Rückschreiben“ oder „Ignorieren“. Die Inbox zeigt den Stand in
   der Spalte „geprüft“ [ungeprüft].

Für den Formularbau heißt das: Der `name` muss exakt stimmen, damit tomedo das Feld überhaupt als Stammdatenfeld
erkennt. Ob der Wert dann automatisch in der Akte landet, entscheidet die Praxis in tomedo, nicht das JSON.

## Konvention

- **`$wfaXxx$`** = Stammdatenfeld, das tomedo kennt (Liste unten). Andere `$wfa…$`-Namen sind für tomedo gewöhnliche
  Formularfelder.
- **`$orzXxx$`** = Namen aus der Online-Rezeption von arzt-direct. tomedo kennt **keinen** `$orz…$`-Namen; es gibt dafür
  keinen Rückschrieb in die Stammdaten [ungeprüft]. Was arzt-direct damit macht (z. B. Verzweigung), ist dort zu prüfen.

`shortTitle` bei diesen Feldern als **sprechender deutscher Alias** setzen — der `name` darf nicht für Briefkommandos
verwendet werden (würde das `$…$`-Sonderzeichen-Problem auslösen). Für Vorname, Nachname und Geburtsdatum sind die
Kurztitel **„Vorname“, „Nachname“, „Geburtsdatum“** Pflicht: tomedo sucht diese Bezeichnungen als Rückfall, wenn es den
Namen „laut Formular“ braucht (Zuordnung, Patient anlegen).

## Stammdatenfelder, die tomedo kennt (`$wfa…$`)

Spalte „In tomedo“ = Beschriftung im Reiter „Rückschrieb“. Spalte „Auto“ = automatischer Rückschrieb erlaubt.

| `name` | In tomedo | Auto | Empfohlener `shortTitle` | Element-Typ (Referenzbestand) |
|---|---|---|---|---|
| `$wfaPatientTitel$` | Titel | ja | `Titel` | `academic-title` |
| `$wfaPatientVorname$` | Vorname | **nein** | `Vorname` | `text` |
| `$wfaPatientNachname$` | Nachname | **nein** | `Nachname` | `text` |
| `$wfaPatientNamenszusatz$` | Namenszusatz | ja | `Namenszusatz` | `text` |
| `$wfaPatientGeburtstag$` | Geburtsdatum | **nein** | `Geburtsdatum` | `birthdate` |
| `$wfaPatientGeburtsort$` | Geburtsort | **nein** | `Geburtsort` | `text` |
| `$wfaPatientGeschlecht$` | Geschlecht | ja | `Geschlecht` | `gender` |
| `$wfaPatientStrasseHausnummer$` | Straße und Hausnummer | ja | `Adresse` | `text` |
| `$wfaPatientPlz$` | Postleitzahl | ja | `PLZ` | `text` |
| `$wfaPatientOrt$` | Wohnort | ja | `Ort` | `text` |
| `$wfaPatientLand$` | Land | ja | `Land` | (Ländercode aus drei Buchstaben) |
| `$wfaPatientTelefonPrivat$` | Telefon privat | ja | `TelefonPrivat` | `text` (inputType: tel) |
| `$wfaPatientTelefonMobil$` | Telefon mobil | ja | `TelefonMobil` | `text` (inputType: tel) |
| `$wfaPatientTelefonGeschaeftlich$` | Telefon dienstlich | ja | `TelefonGeschaeftlich` | `text` (inputType: tel) |
| `$wfaPatientFaxnummer$` | Faxnummer | ja | `Fax` | `text` |
| `$wfaPatientEmail$` | E-Mail | **nein** | `Email` | `text` (inputType: email) |
| `$wfaPatientBeruf$` | Beruf | ja | `Beruf` | `text` |
| `$wfaPatientKontaktaufnahme$`, `$wfaPatientKontaktaufnahmeCustom$` | Kontaktaufnahme | ja | `Kontaktwege` | `contact` |
| `$wfaPatientVersandVonInformationen$`, `$wfaPatientVersandVonInformationenCustom$` | Versand von Informationen | ja | `Versand` | – |
| `$wfaPatientEpaZustimmung$` | Zustimmung zur elektronischen Patientenakte (ePA) | ja | `ePA` | – |
| `$wfaPatientPflegegrad$` | Pflegegrad | ja | `Pflegegrad` | – |
| `$wfaPatientGradDerBehinderung$` | Grad der Behinderung | ja | `GdB` | – |
| `$wfaPatientBoolCol1$`, `$wfaPatientBoolCol2$` | Patientenabhängiges Ja/Nein-Feld 1/2 | ja | sprechend | – |
| `$wfaPatientStringCol1$` … `$wfaPatientStringCol4$` | Patientenabhängiges Text-Feld 1–4 | ja | sprechend | – |
| `$wfaHauptversicherterVorname$`, `…Nachname$`, `…Titel$`, `…Namenszusatz$`, `…Geschlecht$`, `…Geburtstag$`, `…StrasseHausnummer$`, `…Plz$`, `…Ort$`, `…Land$` | … (Hauptversicherter) | ja | sprechend | – |
| `$wfaAlternativeRechnungsadresseVorname$`, `…Nachname$`, `…Titel$`, `…Namenszusatz$`, `…Geschlecht$`, `…Geburtstag$`, `…StrasseHausnummer$`, `…Plz$`, `…Ort$`, `…Land$`, `…Email$` | … (alt. Rechnungsadresse) | ja | sprechend | – |

Zusammen 51 Namen. Wo die Spalte „Element-Typ“ leer ist, kommt der Name im ausgewerteten Formularbestand nicht vor:
erst im arzt-direct-Editor prüfen, welches Element er erwartet. Werte, die tomedo erwartet: Datum als `JJJJ-MM-TT`,
Geschlecht und Kontaktwege so, wie die Elemente `gender` und `contact` sie liefern – nicht selbst nachbauen [ungeprüft].

## Namen ohne Rückschrieb in tomedo

Im Referenzbestand belegt, in tomedos Liste aber **nicht** enthalten – für tomedo gewöhnliche Formularfelder, kein
Stammdaten-Rückschrieb [ungeprüft]:

| `name` | Rolle im Formular | Empfohlener `shortTitle` | Element-Typ |
|---|---|---|---|
| `$wfaPatientKrankenkasse$` | Krankenkasse (nur Formularwert) | `Krankenkasse` | `text` |
| `$wfaPatientVersicherungsart$` | Versicherungsart GKV/PKV/SZ/BG (nur Formularwert, Verzweigung) | `Versicherungsart` | `button-single-choice` oder `radiogroup` |
| `$wfaBgUnfalldatum$` | BG-Unfalldatum (nur Formularwert) | `Unfalldatum` | `datepicker` |
| `$orzBestandspatient$` | Triage Bestand- vs. Neupatient (arzt-direct) | `Bestandspatient` | `button-single-choice` (Werte `"true"`/`"false"`) |
| `$orzUeberweisungFachrichtung$` | Überweisung: Fachrichtung | `Fachrichtung` | `text` |
| `$orzUeberweisungGrund$` | Überweisung: Grund (Freitext) | `Überweisungsgrund` | `comment` |

Die Namen nicht umbenennen, solange arzt-direct sie auswertet (Verzweigung, Online-Rezeption) – nur nicht erwarten,
dass tomedo die Akte daraus ändert.

## Patterns

### Stammdaten-Block für Neukontakt

Reihenfolge: identisch zur tomedo-Patientenakte. Die ersten 3 Felder eng zusammen, danach Adresse, dann Kontaktdaten.

```json
{
  "type": "academic-title",
  "name": "$wfaPatientTitel$",
  "shortTitle": "Titel",
  "title": "Akademischer Titel"
},
{
  "type": "text",
  "name": "$wfaPatientVorname$",
  "shortTitle": "Vorname",
  "title": "Vorname",
  "isRequired": true,
  "startWithNewLine": false
},
{
  "type": "text",
  "name": "$wfaPatientNachname$",
  "shortTitle": "Nachname",
  "title": "Nachname",
  "isRequired": true,
  "startWithNewLine": false
},
{
  "type": "birthdate",
  "name": "$wfaPatientGeburtstag$",
  "shortTitle": "Geburtsdatum",
  "title": "Geburtsdatum",
  "isRequired": true
},
{
  "type": "gender",
  "name": "$wfaPatientGeschlecht$",
  "shortTitle": "Geschlecht",
  "title": "Geschlecht",
  "isRequired": true
}
```

### Konditionales Stammdatenfeld (BG-Unfalldatum nur bei BG-Versicherung)

```json
{
  "type": "button-single-choice",
  "name": "$wfaPatientVersicherungsart$",
  "shortTitle": "Versicherungsart",
  "title": "Ihre Versicherungsart",
  "isRequired": true,
  "choices": [
    { "value": "gkv", "text": "Gesetzlich" },
    { "value": "pkv", "text": "Privat" },
    { "value": "sz",  "text": "Selbstzahler" },
    { "value": "bg",  "text": "Berufsgenossenschaft (BG)" }
  ]
},
{
  "type": "datepicker",
  "name": "$wfaBgUnfalldatum$",
  "shortTitle": "Unfalldatum",
  "title": "Bitte geben Sie das Unfalldatum an.",
  "visibleIf": "{$wfaPatientVersicherungsart$} = 'bg'",
  "minDate": "2016-01-01",
  "maxDate": "2036-12-31",
  "isRequired": true
}
```

### Telefon-Block mit `answercount`-Validierung

Mindestens eine Telefonnummer muss angegeben werden, aber nicht alle drei — `answercount`-Validator auf Element-Gruppen-Ebene oder per `requiredIf` pro Feld:

```json
{ "type": "text", "name": "$wfaPatientTelefonPrivat$", "shortTitle": "TelefonPrivat",
  "title": "Telefon (privat)", "inputType": "tel",
  "validators": [{ "type": "expression", "text": "Ungültige Telefonnummer.",
                   "expression": "isValidPhoneNumber({$wfaPatientTelefonPrivat$})" }] }
```

## Stolperfallen

1. **`name` mit `$…$`-Syntax niemals umbenennen.** tomedo erkennt Stammdatenfelder exakt an diesen Namen. Ein `$wfaPatientVorname$` ist nicht synonym mit `$wfaVorname$` — tomedo kennt nur die Schreibweisen der Liste oben.
2. **`$…$`-Felder erhalten trotzdem `shortTitle`.** Sonst wäre der Wert per `$[formularEintrag …]$` nicht ansprechbar, weil der `$`-Sonderzeichen-Wrapper im Briefkommando nicht funktioniert.
3. **`$orzBestandspatient$` mit Werten `"true"`/`"false"`** (als Strings, nicht Boolean). Das ist die zollsoft-Konvention für die Online-Rezeptions-Logik.
4. **Versicherungsart-Werte** sollten `gkv`/`pkv`/`sz`/`bg` lauten, wenn das BG-Unfalldatum-Branching funktionieren soll. Andere Werte sind theoretisch möglich, aber die `visibleIf`-Regel oben muss dann angepasst werden.
5. **Vorbefüllung** aus tomedo (Spalte „Vorbefüllungskommando“) ist für `$wfa…$`-Felder nicht möglich (`tomedo-seite.md` §2).

## Offene Punkte

- Was arzt-direct mit `$wfaPatientKrankenkasse$`, `$wfaPatientVersicherungsart$`, `$wfaBgUnfalldatum$` und `$orz…$`
  macht, ist aus tomedo nicht zu sehen.
- Ob tomedo je Formular vom globalen Rückschrieb abweichen kann: angelegt, eine Bedienung dafür ist nicht belegt.
