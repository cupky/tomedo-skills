# Stammdaten-Bindings

Felder mit `name = "$wfaXxx$"` oder `name = "$orzXxx$"` werden von arzt-direct **automatisch** in das jeweilige tomedo-Stammdatenfeld zurückgeschrieben. Kein zusätzliches Mapping nötig.

## Konvention

- **`$wfaXxx$`** = Wartezimmer-für-Anmeldung-Stammdaten (Patient-Basisinformationen)
- **`$orzXxx$`** = Online-Rezeption / Online-Terminkalender-spezifische Felder

`shortTitle` bei diesen Feldern als **sprechender deutscher Alias** setzen — der `name` darf nicht für Briefkommandos verwendet werden (würde das `$…$`-Sonderzeichen-Problem auslösen).

## Belegte Bindings ($wfa$)

| `name` | Tomedo-Stammdatenfeld | Empfohlener `shortTitle` | Element-Typ |
|---|---|---|---|
| `$wfaPatientTitel$` | Akademischer Titel | `Titel` | `academic-title` |
| `$wfaPatientVorname$` | Vorname | `Vorname` | `text` |
| `$wfaPatientNachname$` | Nachname | `Nachname` | `text` |
| `$wfaPatientGeburtstag$` | Geburtsdatum | `Geburtsdatum` | `birthdate` |
| `$wfaPatientGeschlecht$` | Geschlecht | `Geschlecht` | `gender` |
| `$wfaPatientStrasseHausnummer$` | Straße + Hausnummer | `Adresse` | `text` |
| `$wfaPatientPlz$` | PLZ | `PLZ` | `text` |
| `$wfaPatientOrt$` | Ort | `Ort` | `text` |
| `$wfaPatientTelefonPrivat$` | Telefon privat | `TelefonPrivat` | `text` (inputType: tel) |
| `$wfaPatientTelefonMobil$` | Telefon mobil | `TelefonMobil` | `text` (inputType: tel) |
| `$wfaPatientTelefonGeschaeftlich$` | Telefon geschäftlich | `TelefonGeschaeftlich` | `text` (inputType: tel) |
| `$wfaPatientEmail$` | E-Mail | `Email` | `text` (inputType: email) |
| `$wfaPatientKontaktaufnahme$` | Kontaktwege/-erlaubnisse (Multi) | `Kontaktwege` | `contact` |
| `$wfaPatientKrankenkasse$` | Krankenkasse | `Krankenkasse` | `text` |
| `$wfaPatientVersicherungsart$` | Versicherungsart (GKV/PKV/SZ/BG) | `Versicherungsart` | `button-single-choice` oder `radiogroup` |
| `$wfaBgUnfalldatum$` | BG-Unfalldatum | `Unfalldatum` | `datepicker` |

## Belegte Bindings ($orz$)

| `name` | Funktion | Empfohlener `shortTitle` | Element-Typ |
|---|---|---|---|
| `$orzBestandspatient$` | Triage Bestand- vs. Neupatient | `Bestandspatient` | `button-single-choice` (Werte `"true"`/`"false"`) |
| `$orzUeberweisungFachrichtung$` | Überweisung: Fachrichtung | `Fachrichtung` | `text` |
| `$orzUeberweisungGrund$` | Überweisung: Grund (Freitext) | `Überweisungsgrund` | `comment` |

## Patterns

### Stammdaten-Block für Neukontakt

Reihenfolge: identisch zur tomedo-Patientenakte. Die ersten 3 Felder eng zusammen, danach Adresse, dann Kontaktdaten.

```json
{
  "type": "academic-title",
  "name": "$wfaPatientTitel$",
  "shortTitle": "Titel",
  "title": "Akademischer Titel"
},
{
  "type": "text",
  "name": "$wfaPatientVorname$",
  "shortTitle": "Vorname",
  "title": "Vorname",
  "isRequired": true,
  "startWithNewLine": false
},
{
  "type": "text",
  "name": "$wfaPatientNachname$",
  "shortTitle": "Nachname",
  "title": "Nachname",
  "isRequired": true,
  "startWithNewLine": false
},
{
  "type": "birthdate",
  "name": "$wfaPatientGeburtstag$",
  "shortTitle": "Geburtsdatum",
  "title": "Geburtsdatum",
  "isRequired": true
},
{
  "type": "gender",
  "name": "$wfaPatientGeschlecht$",
  "shortTitle": "Geschlecht",
  "title": "Geschlecht",
  "isRequired": true
}
```

### Konditionales Stammdatenfeld (BG-Unfalldatum nur bei BG-Versicherung)

```json
{
  "type": "button-single-choice",
  "name": "$wfaPatientVersicherungsart$",
  "shortTitle": "Versicherungsart",
  "title": "Ihre Versicherungsart",
  "isRequired": true,
  "choices": [
    { "value": "gkv", "text": "Gesetzlich" },
    { "value": "pkv", "text": "Privat" },
    { "value": "sz",  "text": "Selbstzahler" },
    { "value": "bg",  "text": "Berufsgenossenschaft (BG)" }
  ]
},
{
  "type": "datepicker",
  "name": "$wfaBgUnfalldatum$",
  "shortTitle": "Unfalldatum",
  "title": "Bitte geben Sie das Unfalldatum an.",
  "visibleIf": "{$wfaPatientVersicherungsart$} = 'bg'",
  "minDate": "2016-01-01",
  "maxDate": "2036-12-31",
  "isRequired": true
}
```

### Telefon-Block mit `answercount`-Validierung

Mindestens eine Telefonnummer muss angegeben werden, aber nicht alle drei — `answercount`-Validator auf Element-Gruppen-Ebene oder per `requiredIf` pro Feld:

```json
{ "type": "text", "name": "$wfaPatientTelefonPrivat$", "shortTitle": "TelefonPrivat",
  "title": "Telefon (privat)", "inputType": "tel",
  "validators": [{ "type": "expression", "text": "Ungültige Telefonnummer.",
                   "expression": "isValidPhoneNumber({$wfaPatientTelefonPrivat$})" }] }
```

## Stolperfallen

1. **`name` mit `$…$`-Syntax niemals umbenennen.** Das Auto-Mapping in tomedo basiert exakt auf diesen Strings. Ein `$wfaPatientVorname$` ist nicht synonym mit `$wfaVorname$` — die zollsoft-Implementierung kennt nur die exakte Schreibweise oben.
2. **`$…$`-Felder erhalten trotzdem `shortTitle`.** Sonst wäre der Wert per `$[formularEintrag …]$` nicht ansprechbar, weil der `$`-Sonderzeichen-Wrapper im Briefkommando nicht funktioniert.
3. **`$orzBestandspatient$` mit Werten `"true"`/`"false"`** (als Strings, nicht Boolean). Das ist die zollsoft-Konvention für die Online-Rezeptions-Logik.
4. **Versicherungsart-Werte** sollten `gkv`/`pkv`/`sz`/`bg` lauten, wenn das BG-Unfalldatum-Branching funktionieren soll. Andere Werte sind theoretisch möglich, aber die `visibleIf`-Regel oben muss dann angepasst werden.

## Offene Punkte

In den vier Beispiel-Bögen nicht enthalten, aber wahrscheinlich existent:

- Weitere `$wfa$`-Felder für Beruf, Familienstand, Größe/Gewicht
- `$orz$`-Felder für Terminwunsch (Datum/Uhrzeit, Arzt-Präferenz)

Bei Bedarf bei zollsoft-Support oder im arzt-direct-Editor nachschlagen — die JSON-Beispiele decken die häufigsten ab, aber nicht alle.
