# tomedo-Seite: Pflege, Anforderung, Rücklauf, Auslesen

> Teil des Skills `tomedo-patientenformulare`. Der Navigator ist `SKILL.md`.

**Belegbasis:** Überarbeitet im Oktober 2026. **[ungeprüft]** = noch nicht in der Oberfläche nachgestellt — vor dem
Einsatz an einer Testakte prüfen. Menü- und Feldnamen sind
die der Oberfläche.

**Arbeitsteilung, die man kennen muss:** Das Formular-JSON, der Editor, das Rendern des `karteitextHtmlTemplate`, die
Abholung der Antworten und die automatische Patientenzuordnung liegen bei **arzt-direct** bzw. beim **tomedo-Server**.
Der tomedo-Client wertet das JSON nicht aus (er liest nur den Titel). Formulare zeigt und füllt er in einem eingebetteten
Web-Viewer aus. Alles, was dieser Skill über JSON-Eigenschaften sagt, ist deshalb Messbefund an arzt-direct; was hier
steht, ist das, was tomedo damit macht.

---

## 1 · Pflegeort in tomedo

**Admin › Patientenformulare** öffnet das Fenster „Patientenformular-Einstellungen“ (nur sichtbar, wenn das
Patientenformulare-Modul aktiv ist). Zwei Reiter:

- **„Formularübersicht“** – links die Liste der Formulare (Titel, Suchfeld), rechts je Formular:
  - „Formular bearbeiten“ › **„Zum Editor“**: öffnet ein tomedo-Fenster „Patientenformular-Editor“ mit der
    **arzt-direct-Weboberfläche**. tomedo hat keinen eigenen JSON-Editor; was „der Editor“ beim Speichern verwirft
    (`gestaltung.md`), verwirft arzt-direct.
  - **„Kürzel“** – in tomedo frei änderbar. Es ist der Schlüssel für `formularEintrag`, `formularLinks`, Toolbar-Einträge
    und Aktionsketten. Leer ist verboten („Leere Kürzel sind für Formulartypen nicht erlaubt.“); ein doppeltes Kürzel löst
    nur einen Hinweis aus, wird aber nicht verhindert [ungeprüft]. Ein geändertes Kürzel bricht alle Briefvorlagen und
    Textbausteine, die es nennen.
  - **„Titel (editierbar im Editor)“** – nur im Editor änderbar.
  - **„Permanenter Link“** – Schalter legt den Permalink bei arzt-direct an; dazu Kopieren, QR-Code, Öffnen
    (`permalink-api.md`). Für Thieme-Formulare gesperrt.
  - **„Briefkommando“** – kopiert `$[formularLinks <Kürzel>]$`.
  - „Textfarbe (in Kartei)“, „Hintergrundfarbe (in Kartei)“.
  - **„Elemente und Karteitext“** – Tabelle der Formularelemente (Abschnitt 2).
- **„Globale Einstellungen“** – „QR-Code“ (Anzeigedauer, Logo, nach Scan schließen, im Vordergrund),
  „Automatischer Rückschrieb“ (`stammdaten-bindings.md`), „Fälligkeiten“ (Abschnitt 4), „Anhänge“ („Anhänge aus
  Patientenformularen zusätzlich als separaten Eintrag in der Kartei ablegen“).

**Neu anlegen** geht nur über das arzt-direct-Dashboard („+“ › „Neues Formular erstellen“ bzw. „Vorlagen entdecken“,
Knopf „Übersicht“). Import, Export, Duplizieren einer Vorlage gibt es in tomedo nicht. Nach Änderungen im Dashboard
holt der Knopf „Patientenformulare aktualisieren“ die Vorlagen nach tomedo.

**Kategorie** und **„ausgeblendet“** pflegt man in der allgemeinen Formularverwaltung. Ausgeblendete Formulare fehlen
in der Auswahl zum Anfordern.

---

## 2 · „Elemente und Karteitext“ – was tomedo je Feld einstellt

Die Tabelle listet die Felder des Formulars mit **„Kurztitel“** – das ist der Wert, den Briefkommandos ansprechen. Er
entspricht dem `shortTitle` des Elements [ungeprüft: die Zuordnung macht der Server]. Der technische `name` bleibt
intern und dient tomedo u. a. zum Erkennen der `$wfa…$`-Stammdatenfelder.

| Spalte | Wirkung |
|---|---|
| „Karteitext“ | **„Niemals“** (Vorgabe), „Kurztitel & Antwort (Immer)“, „Kurztitel & Antwort (wenn Antwort vorhanden)“, „Nur Antwort (Immer)“, „Nur Antwort (wenn Antwort vorhanden)“, „Nur Kurztitel (wenn Antwort vorhanden)“. Steuert, was ohne `karteitextHtmlTemplate` in den Karteitext kommt [ungeprüft: Zusammenspiel mit dem Template] |
| „Kommando“ › „Kopieren“ | kopiert `$[formularEintrag <Kürzel> <Kurztitel> N]$` |
| „Vorbefüllungskommando“ | Briefkommando, das tomedo beim Öffnen eines **neuen** Formulars auswertet und als Antwort vorbelegt. Schlüssel ist der Kurztitel. Nicht für `$wfa…$`-Felder („Nicht möglich“). Die Spalte ist nicht in jeder Installation eingeblendet [ungeprüft] |

Darunter zwei Knöpfe für die ausgewählten Elemente:

- **„Textbaustein aus selektierten Elementen erstellen“** – Popover „Buttontext“ (Vorgabe „Zusammenfassung <Name>“) und
  „Kürzel“ (Vorgabe `_<Formularkürzel>`). Der Baustein enthält je Element eine Zeile
  `<Kurztitel>: $[formularEintrag <Kürzel> <Kurztitel> N]$`.
- **„Custom Karteieintrag aus selektierten Elementen erstellen“** – legt einen Karteieintragstyp mit **einem** Textfeld an,
  vorbelegt mit denselben Zeilen (Vorgabe-Kürzel `CKE_<Formularkürzel>`). Keine Feld-für-Feld-Abbildung, kein
  automatischer Rücklauf: Wer Einzelfelder will, teilt das Textfeld im CKE-Editor selbst auf.

**Folge für den Formularbau:** Ein Feld, dessen Kurztitel sich ändert, verliert Textbausteine, CKE-Vorbelegungen,
Vorbefüllung und Briefvorlagen – `name` und `shortTitle` bestehender Felder deshalb nie ändern.

---

## 3 · Anfordern: Wege und Platzhalter

**Aktion › Patientenformulare anfordern** öffnet „Patientenformulare anfordern“ (ebenso über Toolbar, Kartei-Teilen-Menü
und das Patienten-Panel). Spalte „Status“ zeigt fällige und angeforderte Formulare, „Ausstehende auswählen“ wählt beide.
Eine Auswahl lässt sich als Vorauswahl-Liste speichern (erscheint dann auch in Toolbar und Aktionsketten).

| Knopf | Was passiert |
|---|---|
| „E-Mail“ | E-Mail aus einer Vorlage vom Typ „Patientenformulare Anforderung“; `$[Formularlinks]$` wird durch die Links ersetzt |
| „QR-Code“ | Fenster mit QR-Code; „%@ Sekunden gültig“ ist nur die **Anzeigedauer** des Fensters, nicht die Gültigkeit des Links [ungeprüft] |
| „iPad“ | reiht das Formular in eine Handoff-Schlange für die iOS-App ein; nur mit gewähltem Patienten |
| „arzt-direkt“ | Nachricht „Bitte füllen Sie die Formulare unter folgendem Link aus:“ an die App; nur bei gekoppeltem Patienten |

Kein SMS-Knopf, kein „Link kopieren“ (das gibt es in der Inbox unter „Angefordert“). SMS geht nur über die
Terminerinnerung. **Mehrere Formulare ergeben einen gemeinsamen Link** [ungeprüft].

**Drei verschiedene Link-Platzhalter – nicht verwechseln:**

| Wo | Platzhalter | Hinweis |
|---|---|---|
| E-Mail-Vorlage „Patientenformulare Anforderung“ | `$[Formularlinks]$` | ohne Argument, kein Briefkommando. Fehlt er, geht die Mail **ohne Links** hinaus [ungeprüft] |
| Brief, andere Vorlagen | `$[formularLinks <Kürzel> <Kürzel> …]$`, `$[formularLinksOhneName …]$`, Sonderwert `fälligeFormulare` | Argumente sind **Formular-Kürzel**. Ausgabe `Name: URL` (bei mehreren „Formulare“) bzw. nur `URL`. Unbekanntes Kürzel oder nichts fällig → **„(bereits ausgefüllt)“** ohne Fehlermeldung [ungeprüft]. Jede Auflösung legt eine neue Anforderung an [ungeprüft] |
| Terminerinnerung (E-Mail **und** SMS) | `$[selektierterTermin %formularlinks]$` | Link zu den für diesen Termin fälligen Formularen (Abschnitt 4) |

**Ohne gewählten Patienten** (Neupatient) gehen „E-Mail“ und „QR-Code“. tomedo warnt „Fehlende Felder für
Neupatienten“, wenn kein gewähltes Formular **Vorname, Nachname und Geburtsdatum** erfasst. Nur mit allen drei kann
tomedo aus der Antwort später einen Patienten anlegen [ungeprüft]. Für Thieme-Formulare kommt zusätzlich „Mögliche
Mehrkosten ohne Patientenzuordnung“. Hat der Patient dem Versand medizinischer Daten per E-Mail widersprochen, geht
keine Anforderungs-Mail hinaus.

**Konsequenz für den Formularbau:** Ein Formular, das auch ohne Patient (QR im Wartezimmer, Permalink, Neupatient)
eingesetzt wird, braucht `$wfaPatientVorname$`, `$wfaPatientNachname$` und `$wfaPatientGeburtstag$` – mit den
Kurztiteln „Vorname“, „Nachname“, „Geburtsdatum“ (`stammdaten-bindings.md`).

Eine **„Online-Rezeption“** als Ausspielweg kennt tomedo nicht; `orzPageAction` wirkt, wenn überhaupt, nur bei
arzt-direct (`page-actions.md`).

---

## 4 · Fälligkeit: Anforderungsbedingungen

„Globale Einstellungen“ › „Fälligkeiten“ › Anforderungs-Einstellungen: „Hier kann eingestellt werden, welche
Patientenformulare unter welchen Bedingungen beim Besuch des Patienten fällig sind.“ Je Bedingung:

| Feld | Auswahl |
|---|---|
| „Gilt für folgende Formulare“ | Patientenformulare |
| „Gilt für folgende Patienten“ | Patientenfilter: Alter (von/bis), Geschlecht, Versicherung (GKV/Privat/HZV), spezifische Filter; leer = alle |
| „Gilt für folgende Situationen“ | „Bei jedem Besuch/Termin“ oder „Nur bei Terminen folgender Terminarten“ |
| „Häufigkeit“ | „Einmalig“, „Wenn letztes Formular älter als“ + Zeitraum, „Bei jedem Termin“ (nur terminbezogen) |

Die Bedingungen **verschicken nichts**. Sie markieren Formulare als fällig (Status-Spalte, Toolbar „Ausstehende“,
`fälligeFormulare`, `%formularlinks`). Ausgewertet wird beim Server [ungeprüft]. Die Kontrollanzeige „Terminerinnerung
eingerichtet?“ meldet, wenn für eine Terminart keine Terminerinnerung mit `$[selektierterTermin %formularlinks]$`
besteht. Automatischer Versand entsteht nur über diese Terminerinnerung oder eine Aktionskette.

---

## 5 · Rücklauf: Inbox, Zuordnung, Ansichten

**Inbox Patientenformulare** mit zwei Bereichen:

- **„Eingereicht“** – ausgefüllte Formulare, als Gruppe (eine Anforderung) mit Unterzeilen. Spalten u. a.
  „Patientenformular“, „Kürzel“, „Patient“ („nicht zugeordnet“), „Name lt. Patientenformular“, „Quelle“ (online / iPad /
  tomedo), „gelesen“, „geprüft“ (Stammdatenabgleich). Zeigt nur **online oder am Praxis-iPad** ausgefüllte Formulare,
  nicht die im Mac-Client ausgefüllten [ungeprüft]. Standard: letzte 30 Tage oder ungelesen.
- **„Angefordert“** – offene Anforderungen mit Spalte „Link“, Kontextmenü „Link kopieren“, Löschen der Anforderung.

Status eines Formulars beim Patienten: nur „fällig“, „angefordert“, „ausgefüllt“. Ein Ablaufdatum, ein Status
„geöffnet“ oder eine automatische Erinnerung gibt es in tomedo nicht [ungeprüft]. Gültigkeit der Links regelt der
Server bzw. arzt-direct.

**Zuordnung:** Angeforderte Formulare mit Patient kommen zugeordnet zurück. Die automatische Zuordnung sonst macht der
Server. In der Inbox: „Zuordnen“ (Suche vorbelegt mit „Nachname, Vorname Geburtsdatum“ laut Formular, neuen Patienten
anlegen möglich), „Patientenzuordnung aufheben“. Die Zuordnung gilt immer für die **ganze Gruppe**. Ohne Zuordnung
lässt sich keine Kartei öffnen („Kein Patient zugeordnet“).

**Ansichten** eines eingegangenen Formulars (Inbox, Kartei-Popover, eigenes Fenster) – vier Reiter:

| Reiter | Inhalt |
|---|---|
| „Web“ | das Formular im eingebetteten Viewer, schreibgeschützt |
| „Tabelle“ | Paare „Kurztitel“ / „Antwort“ (Bilder und Dateien mit Öffnen-Knopf); Häkchen **„Nur beantwortete anzeigen“** ist vorgegeben – leere Felder fehlen dann |
| „Anhang“ | Dateien je Upload-Feld (gruppiert nach `name`, Rest „Ohne Zuordnung“), Knöpfe „Datei öffnen“, „Lokal speichern“ |
| „Rückschrieb“ | Abgleich der `$wfa…$`-Felder mit den Patientendetails (`stammdaten-bindings.md`) |

Der **Karteitext** (Ergebnis von `karteitextHtmlTemplate`) erscheint in keinem dieser Reiter, nur in der Kartei, im Brief
und für die KI [ungeprüft].

**Formularwerte als Zahl** (Wertverlauf, Diagramm) nutzt tomedo nur bei `button-single-choice`, `expression`, `rating`,
`slider`, `text` – nicht bei `radiogroup`/`dropdown`, deren Antwort der `value` der Auswahl ist (`Item1` …) [ungeprüft].
Scores deshalb als `expression` anlegen.

**Löschen** in der Inbox blendet nur aus; ein Häkchen „Formular auch in der Kartei löschen?“ entfernt es dort mit.
Abgeschlossene Formulare sind schreibgeschützt; „Versionsverlauf anzeigen“ zeigt frühere Stände der **Antwort**.

---

## 6 · Auslesen per Briefkommando: `formularEintrag`

```
$[formularEintrag <Formular-Kürzel> <Kurztitel> <Auswahl>]$
```

| Teil | Regel |
|---|---|
| Formular-Kürzel | das Kürzel aus den Patientenformular-Einstellungen (nicht das Kürzel des Karteieintragstyps) |
| Kurztitel | alle Wörter zwischen Kürzel und letztem Argument, mit **einem** Leerzeichen verbunden. Exakter Vergleich: Groß-/Kleinschreibung zählt, Umlaute und Bindestriche gehen, doppelte oder Rand-Leerzeichen sind nicht adressierbar, das Wort `-index` ist reserviert [ungeprüft] |
| Auswahl | **`N`** = neuestes Formular (so erzeugt tomedo das Kommando selbst) · `J` = vorher selektiertes · eine Zeitangabe wie `7d`, `3M`, `1y` = nur Formulare dieses Alters. **`0` ist eine Zeitangabe „0 Tage“ und liefert nur Formulare von heute** – ältere ergeben leer [ungeprüft] |
| `-index <n>` | optional: 1 = neuestes (Vorgabe), 2 = vorletztes, −1 = ältestes |

Rückgabe ist die gespeicherte Antwort als Text; enthält sie HTML, wird sie zu Klartext. Ein **unbekannter Kurztitel**
liefert bei Patientenformularen **leer ohne Hinweis**; ein **doppelter Kurztitel** im selben Formular liefert irgendeinen
der Werte [ungeprüft]. Deshalb: Kurztitel je Formular eindeutig (Lint W9) und ohne Leerzeichen-Spielereien (Lint W10).
Unterschriften kommen als Bild-Datenstring (`data:image/png;base64,…`).

---

## 7 · Aktionsketten

- **Aktion „Patientenformular anfordern“** mit „Anforderungsweg:“ „E-Mail“, „QR-Code“ oder „iPad (Handoff-Schlange)“ – der
  Weg arzt-direkt fehlt dort. Enthält die gewählte E-Mail-Vorlage `$[Formularlinks]$` nicht, warnt tomedo.
- **Auslöser** beim Rücklauf gibt es nur einen: Objekt „Patientenformular“, Aktion **„Gelesen“**, je Formular. Er feuert,
  wenn jemand „gelesen“ anhakt (Inbox oder Kartei), und nur mit zugeordnetem Patienten; sonst meldet tomedo, dass die
  Kette nicht ausgelöst werden konnte [ungeprüft]. Einen Auslöser „Formular eingegangen“ gibt es nicht.
- Konfiguration im Detail: Skill `tomedo-aktionsketten`.
