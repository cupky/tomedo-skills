# karteitextHtmlTemplate — Render-Direktive

Das `karteitextHtmlTemplate` ist eine **Top-Level-Property** des JSON. arzt-direct rendert es serverseitig zum Zeitpunkt des Rückschriebs und schreibt das Ergebnis in `karteieintrag.text`. Das ist das, was der Arzt in der Kartei und im Brief liest.

## Syntax

Die Template-Syntax ist identisch zur tomedo-Briefkommando-Syntax. Drei Bausteine:

| Konstrukt | Funktion |
|---|---|
| `$[text('feldname')]$` | Feldwert eines Frage-Elements einfügen |
| `$[iif({feldname} == [Item1], 'TEXT_WENN_WAHR', 'TEXT_WENN_FALSCH')]$` | Bedingter Text |
| HTML | Beliebige Tags, primär `<p>`, `<br>`, `<strong>`, `<em>` |

**HTML-Escape:** Im JSON müssen Anführungszeichen escaped werden, daher steht `&#39;` für `'`. Beim Schreiben des JSON-Strings am besten direkt im Code-Editor escapen, beim Lesen in den Beispielen mental zurückübersetzen.

## Bedingte Vergleiche

`iif`-Bedingungen können auf zwei Arten verglichen werden:

```
$[iif({feldname} == [Item1], 'A', 'B')]$       — Item-Vergleich (eckige Klammern für choices.value)
$[iif({wert} > "30", 'hoch', 'niedrig')]$       — Schwellwertvergleich (Anführungszeichen, lexikographisch!)
$[iif({raucher} == true, 'Raucher', '')]$       — Boolean-Vergleich
```

**Bei Schwellwertvergleichen die Stolperfalle aus `score-builder.md` beachten** — lexikographisch, nicht numerisch.

## Pattern 1 — Minimal-Template (Kontakt-Triage)

```html
<p>Es handelt sich um eine Kontaktanfrage an: $[text('an-wen')]$.</p>
<p>Der Kontaktgrund lautet: $[text('anfragegrund')]$</p>
<p>Anliegen: $[text('anliegen')]$</p>
```

Pro Patient-Antwort ein Absatz, keine Conditionals. Tauglich für einfache Triage.

## Pattern 2 — Bedingte Sektionen (Multi-Use-Case-Triage)

```html
<p>Kontaktgrund: $[text('anfragegrund')]$</p>
<p>$[iif({anfragegrund} == [Item1], 'Gewünschter Termin: ', '')]$$[text('termin-dat')]$</p>
<p>$[iif({anfragegrund} == [Item2], 'Gewünschtes Rezept: ', '')]$$[text('Rezept-art')]$</p>
<p>$[iif({Rezept-art} == [Item4], 'Sonstiges: ', '')]$$[text('Rezept-sonst')]$</p>
```

Pattern aus `survey.json`: Eine Triage-Frage entscheidet, welche Folgefelder im Karteieintrag relevant sind. Pro Use Case ein `iif`-Block mit Label-Präfix.

## Pattern 3 — Anamnese-Narrative (psf-Bog-Stil)

```html
<p>Laut PSF bestehen Schmerzen im Bereich: $[text('schmerzregion')]$ seit
$[text('schmerzdauer')]$.</p>

<p>Es besteht eine Überweisung von $[text('überweisung')]$
($[text('überweisung-andere')]$).</p>

<p>Die Person kann $[text('zwei-etagen-möglich')]$ steigen.</p>

<p>Versicherung: $[text('Versicherungsart')]$
bei der $[text('$wfaPatientKrankenkasse$')]$.</p>

<p>Folgende Nachricht wird mitgeteilt: $[text('nachricht')]$.</p>
```

Pattern aus `survey-4.json`: Ganze Sätze, die der Patient-Antwort einen klinischen Kontext geben. Lesbar wie ein ärztlicher Anamnese-Block.

**Hinweis:** `$[text('$wfaPatientKrankenkasse$')]$` — hier wird ein Stammdaten-Feld referenziert. Der `$…$`-`name` wird einfach als String in `text()` übergeben. Bei sprechendem `shortTitle` wäre das eleganter, aber im Referenzbestand wird der `name` direkt verwendet.

## Pattern 4 — Score-Block mit klinischer Interpretation

```html
<h4>Scores</h4>
<p>von Korff Grad: <strong>$[text('vkorff')]$</strong></p>
<p>NRS (charakteristisch): $[text('schmerzintensität')]$</p>
<p>PDI: $[text('disability-punkte')]$</p>

<p>$[iif({vkorff} == "3", '<strong>Hinweis: hoher Chronifizierungsgrad — multimodale Therapie diskutieren.</strong>', '')]$</p>
<p>$[iif({vkorff} == "4", '<strong>Hinweis: maximaler Chronifizierungsgrad — multimodale Therapie indiziert.</strong>', '')]$</p>
```

## Pattern 5 — Medikamentenliste

Wenn die Patient-UI mehrere Medikamenten-Felder (`medi1`, `medi2`, …) hat:

```html
<h4>Aktuelle Schmerzmedikation</h4>
<p>1. $[text('medi1')]$ ($[text('medi1-t')]$)</p>
<p>$[iif({medi2} empty, '', '2. ')]$$[text('medi2')]$
   $[iif({medi2} empty, '', '(')]$$[text('medi2-t')]$$[iif({medi2} empty, '', ')')]$</p>
<p>$[iif({medi3} empty, '', '3. ')]$$[text('medi3')]$
   $[iif({medi3} empty, '', '(')]$$[text('medi3-t')]$$[iif({medi3} empty, '', ')')]$</p>
```

**Saubere Variante:** `paneldynamic` mit `expression`-Ausgabe — aber `paneldynamic` ist in den Referenzbögen nicht belegt. Bei Bedarf erst arzt-direct-Editor-Verträglichkeit prüfen.

## Pattern 6 — Internationale Anamnese

Wenn das Formular mehrsprachig ist, bleibt das `karteitextHtmlTemplate` **deutsch** (es geht in den deutschen tomedo-Karteieintrag). Die `text()`-Aufrufe ziehen die Patient-Antworten, die in der gewählten Sprache erfasst wurden, aber für die Praxisdokumentation reichen die `value`s der Choices (`Item1`, `gkv`, …) — die musst Du im Template per `iif` zurückübersetzen:

```html
<p>Versicherungsart: $[iif({$wfaPatientVersicherungsart$} == "gkv", 'GKV',
                       iif({$wfaPatientVersicherungsart$} == "pkv", 'PKV',
                       iif({$wfaPatientVersicherungsart$} == "sz",  'Selbstzahler',
                       iif({$wfaPatientVersicherungsart$} == "bg",  'BG', '?'))))]$</p>
```

## Stolperfallen

1. **Vergessenes Feld im Template** = Feld ist im Karteieintrag-Fließtext unsichtbar. Es ist zwar per `$[formularEintrag …]$`-Briefkommando abrufbar, aber wer nur den Karteieintrag liest, sieht es nicht.
2. **Lexikographische Schwellwertvergleiche** wie in `score-builder.md` beschrieben.
3. **`empty`-/`notempty`**-Operatoren funktionieren auch in `iif`: `{feldname} empty`.
4. **Matrix-Felder per `$[text('matrixname')]$`** liefern eine JSON-artige Stringdarstellung, nicht lesbaren Text. Stattdessen pro Zeile/Zelle eine `expression` mit eigenem `shortTitle` bauen und im Template diese referenzieren.
5. **`html`-Elemente sind nicht referenzierbar** — wenn Du einen Hinweistext im Karteieintrag haben willst, muss er direkt im `karteitextHtmlTemplate` als HTML stehen, nicht in einem `html`-Element der Patient-UI.
6. **`completedHtml`** (separates Top-Level-Property) ist die „Danke"-Seite, die der Patient nach Absenden sieht — **NICHT** der Karteieintragstext. Beide nicht verwechseln.
7. **Sonderzeichen-Encoding**: Beim Schreiben im JSON-String wird `'` zu `&#39;`. Beim Lesen mental zurückübersetzen, beim Schreiben aufpassen.

**Ohne Patientenzuordnung rendert das Template nie.** Eine Permalink-Einsendung kommt ohne
Patientenbezug an („Kein Patient zugeordnet"): Rueckschrieb- und Anhang-CKE-Tabs bleiben leer,
`karteitextHtmlTemplate` wird **nicht** ausgewertet. Ein Karteieintrag haengt zwingend an einem
Patienten. In Formularen, die strukturell ohne Patientenbezug eingehen (Systemmeldungen,
Sammelmeldungen ueber mehrere Patienten), ist das Template **toter Code** und gehoert entfernt.

## Wenn `karteitextHtmlTemplate` fehlt

In `psf-quartal` (`survey-2.json`) ist die Property **nicht** vorhanden. Trotzdem entsteht ein Karteieintragstext. Vermutung: arzt-direct hat einen Default-Renderer, der bei fehlendem Template alle Felder seriell ausgibt. Praktisch heißt das: für strukturierten Brief-Output **immer** ein `karteitextHtmlTemplate` definieren — auf den Default zu hoffen ist riskant.
