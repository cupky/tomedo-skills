# Konventionen (Volltext)

Begründung und Beispiele zu den 12 verbindlichen Regeln aus der SKILL.md.

## 1. `name` + `shortTitle` für jedes Frage-Element

Jedes Frage-Element braucht beide Properties. `html` und `image` brauchen keines von beiden; ein `panel` bekommt nur `name` — `shortTitle` auf `panel` lehnt der Editor (arzt-direct, in tomedo über „Zum Editor“) mit „Unknown property" ab.

- `name` ist die **technische ID** (interner SurveyJS-Schlüssel; tomedo erkennt daran u. a. die `$wfa…$`-Stammdatenfelder und gruppiert Dateianhänge danach).
- `shortTitle` ist die **Brücke ins Briefkommando**. tomedo zeigt ihn als **„Kurztitel“** (Ansicht „Tabelle“, Admin › Patientenformulare › „Elemente und Karteitext“) und adressiert ihn im Briefkommando `$[formularEintrag <Kürzel> <shortTitle> N]$` [ungeprüft: die Übernahme `shortTitle` → Kurztitel macht der Server].

Wenn `shortTitle` fehlt, ist das Feld **nicht sicher per Briefkommando abrufbar** — welchen Kurztitel der Server dann vergibt, ist nicht belegt. Textbausteine, CKE-Vorlagen und Vorbefüllung aus tomedo hängen ebenfalls am Kurztitel.

```json
{ "type": "text", "name": "telefonnummer", "shortTitle": "telefon",
  "title": "Telefonnummer" }
```

## 2. `name` projektweit eindeutig

Doppelte `name`s über Seiten hinweg führen zu undefinierten `visibleIf`-/`expression`-Referenzen. Bei Stammdaten-Feldern zwingend das `$wfaXxx$`/`$orzXxx$`-Schema (siehe `stammdaten-bindings.md`) — das ist eindeutig.

**Naming-Stil (empfohlen):** kebab-case-ascii (`kopfschmerz-tageprowoche`) oder camelCase (`terminBuchen`). Beide kommen in der Referenzinstallation vor. Umlaute sind erlaubt (`schmerzintensität`), aber kebab-case-ascii liest sich in Logs sauberer.

## 3. `shortTitle`-Regex

**Sicherste Variante: `^[A-Za-z]+$`** — nur ASCII-Buchstaben, keine Ziffern, Bindestriche oder Umlaute.

Praxis-Realität: Referenzbestand nutzt auch `schmerzintensität` (Umlaut) und `behandlungen-effekt` (Bindestrich), und das funktioniert beim Auslesen via `karteiEintragWert FOR text _ N`.

**Was tomedo beim Briefkommando tatsächlich prüft** ([ungeprüft]):
- Der Kurztitel wird **exakt** verglichen, Groß-/Kleinschreibung zählt. Umlaute und Bindestriche sind unkritisch.
- Einzelne Leerzeichen gehen (tomedo setzt alle Wörter zwischen Kürzel und letztem Argument wieder zusammen). Doppelte Leerzeichen, Leerzeichen am Rand und das Wort `-index` sind **nicht** adressierbar.
- Kommt ein Kurztitel im selben Formular **zweimal** vor, liefert das Kommando irgendeinen der beiden Werte.
- Ein unbekannter Kurztitel liefert **leer ohne Hinweis**.

**Pragmatische Regel:** Bei neuen Formularen `[A-Za-z]+` einhalten und jeden Kurztitel je Formular nur einmal vergeben (Lint W9, W10). Bei bestehenden Formularen die existierenden `shortTitle`s nicht ändern (würde alle existierenden Briefvorlagen brechen).

## 4. Stammdaten-Binding mit sprechendem `shortTitle`

Bei `$wfa…$`/`$orz…$`-`name` wird `shortTitle` als sprechender deutscher Alias gesetzt:

```json
{ "type": "text", "name": "$wfaPatientVorname$", "shortTitle": "Vorname",
  "title": "Vorname", "isRequired": true }
```

So bleibt das Briefkommando lesbar (`$[formularEintrag PatF-… Vorname N]$`), während der `name` die Konvention erfüllt, an der tomedo das Stammdatenfeld erkennt. Für Vorname, Nachname und Geburtsdatum sind „Vorname“, „Nachname“, „Geburtsdatum“ Pflicht: tomedo sucht diese Kurztitel als Rückfall, wenn es den Namen laut Formular braucht.

## 5. Lokalisierung

Drei Patterns kommen in der Praxis vor:

```json
// Pattern 1: Plain String (häufigster Fall, rein deutsch)
"title": "Vorname"

// Pattern 2: Default + selektive Übersetzung
"title": { "default": "Vorname", "en": "First name" }

// Pattern 3: Voll-Lokalisierung (z. B. Überweisungsformular international)
"title": {
  "default": "Vorname", "en": "First name",
  "es": "Nombre", "it": "Nome", "fr": "Prénom"
}
```

**Wichtig:** Der primäre Sprach-Key heißt `default`. `{"de": "..."}` wird trotzdem angezeigt: Beobachtet am 29.09.2026, dass arzt-direct beim Speichern alle Titel, Beschreibungen, `html`- und `placeholder`-Texte selbst von `{"default": …}` zu `{"de": …}` umschreibt und sie in allen geprüften Browsern darstellt. Für eigene Bögen bleibt `default` die Konvention, weil nur er als Rückfallsprache für weitere Sprachen dient.

Mischung in einer Datei ist erlaubt — z. B. internationale Patientendaten + deutsche praxis-interne Felder.

## 6. Scores als parallele `expression`

Score-Berechnungen werden als eigenes `type: "expression"`-Element realisiert, **zusätzlich** zur Rohwertfrage:

```json
{ "type": "expression", "name": "vkorff", "shortTitle": "vkorff",
  "title": "von Korff", "visible": false,
  "expression": "sum(iif({schmerzintensität} < \"1\", \"0\", iif({schmerzintensität} < \"50\", \"1\", \"2\")), iif({disability-punkte} < \"3\", \"0\", iif({disability-punkte} < \"5\", \"1\", \"2\")))" }
```

`visible: false` versteckt das Element in der Patient-UI, `shortTitle` macht den Score-Wert direkt per Briefkommando abrufbar.

Warum nicht `matrix`-Indizes per Briefkommando auswerten? Weil das Briefkommando bei `matrix` nur die Item-Indizes liefert, nicht die Labels — Auswertung im Brief wäre fehleranfällig.

## 7. Referenzielle Integrität

`visibleIf`, `enableIf`, `requiredIf` und `expression` referenzieren nur existierende `name`s:

```json
"visibleIf": "{körperregion} = 'Item2'"
"expression": "avg(wert(\"stärke-arbeit\"), wert(\"stärke-einschränk\"))"
```

**Syntax-Hinweise:**
- `visibleIf` nutzt `{feldname}`-Referenzen mit `=`/`<>`/`empty`/`notempty`/`allof`/`anyof`-Operatoren.
- `expression` nutzt **entweder** `{feldname}` (SurveyJS-Standard) **oder** `wert("feldname")` (Erweiterung von arzt-direct mit Matrix-Support, nicht von tomedo). Beide funktionieren, `wert(…)` ist nötig für Matrix-Zellen.
- String-Vergleichswerte in `iif` immer in Anführungszeichen: `< "30"` — siehe Stolperfalle.

Der Linter (`scripts/lint.py`) prüft diese Referenzen automatisch.

## 8. Matrix-Workaround

`matrix` ist UX-tauglich für Likert-Skalen oder Mehrfach-Bewertungen. Aber: Briefkommando-Auslese liefert nur Indizes (z. B. `Spalte3`), nicht Labels.

Lösung: pro relevanter Zeile/Zelle ein zusätzliches `expression` mit `shortTitle`, das den Label oder einen abgeleiteten Score erzeugt.

Beispiel `psf-quartal`, Matrix `schmerz-vkorff` → Score `schmerzintensität`:

```json
// UX-Frage
{ "type": "matrix", "name": "schmerz-vkorff", "shortTitle": "schmerz-vkorff",
  "rows": [ {"value": "Zeile1", "text": "Stärkster Schmerz"}, … ],
  "columns": [ {"value": "Spalte11", "text": "0"}, {"value": "Spalte1", "text": "1"}, … ] }

// Auslesbare Größe (durchschnittliche Intensität × 10)
{ "type": "expression", "name": "schmerzintensität", "shortTitle": "schmerzintensität",
  "visible": false,
  "expression": "avg(wert(\"schmerz-vkorff.Zeile1\"), wert(\"schmerz-vkorff.Zeile2\"), wert(\"schmerz-vkorff.Zeile3\")) * 10" }
```

## 9. `html`-Elemente sind Anzeige-only

```json
{ "type": "html", "name": "intro", "html": "<p>Vielen Dank, dass …</p>" }
```

Ein `shortTitle` ist nicht nötig (und wird ignoriert). Der Inhalt landet nicht in `formularelement`. Wenn ein Hinweistext im Karteieintrag erscheinen soll, gehört er ins `karteitextHtmlTemplate`, nicht in ein `html`-Element.

**Schaerfer als „nicht abrufbar": In tomedos Arbeitsansichten sind `html`-Elemente unsichtbar.**
Die Ansicht *Tabelle* zeigt ausschliesslich Paare aus Kurztitel und Antwort — ein statisches
`html`-Element erscheint dort nicht, und `description` ebenso wenig; mit dem vorgegebenen Haken
„Nur beantwortete anzeigen“ fehlen dort auch alle leeren Felder. Karteitext und Brief kennen beides
nicht. Sichtbar ist es nur im Reiter *Web* (das Formular im eingebetteten Viewer), der gleichrangig
neben *Tabelle*, *Anhang* und *Rückschrieb* steht [ungeprüft: ob der Viewer dort `html` und
`description` zeigt]. Wer intern arbeitet, schaut erfahrungsgemaess in Tabelle oder Kartei.

Konsequenz fuer jedes Formular, dessen Empfaenger **intern** arbeitet: Arbeitsauftraege,
Hinweise und Prioritaeten gehoeren in ein **Feld mit Wert** (z. B. `auftrag`), nicht in
Formulartext. Vor dem Bauen pruefen, **wo der Empfaenger tatsaechlich hinsieht.**

## 10. `karteitextHtmlTemplate` aktiv pflegen

Das `karteitextHtmlTemplate` (Top-Level-Property) ist die **Quelle, die das Formular selbst mitbringt**, für den Karteitext. Daneben kann die Praxis in tomedo je Element einstellen, ob Kurztitel und Antwort in den Karteitext kommen (Admin › Patientenformulare › „Elemente und Karteitext“, Spalte „Karteitext“, Vorgabe „Niemals“) [ungeprüft: Zusammenspiel beider]. Wenn ein neues Feld im Template nicht referenziert wird, taucht es im Fließtext also nur auf, wenn jemand das in tomedo einstellt — sonst ist es nur über `$[formularEintrag …]$` einzeln erreichbar.

Faustregel: Felder, deren Wert irgendjemand jemals lesen will, gehören ins `karteitextHtmlTemplate`. Volltext-Pattern siehe `karteitext-template.md`.

## 11. Pflichtfelder sparsam

`isRequired: true` blockt das Absenden, wenn das Feld leer ist. In Kombination mit `visibleIf` ist das meistens OK (Feld wird nur dann required, wenn überhaupt sichtbar). Bei langen Formularen werden zu viele `isRequired`s aber zur Abbruch-Quelle.

Wenn ein Feld konditional Pflicht sein soll, `requiredIf` statt `isRequired`:

```json
{ "type": "text", "name": "schmerzort-andere",
  "requiredIf": "{schmerzregion} allof ['Artikel 1']" }
```

## 12. Mobile-first

Die Patient-UI läuft überwiegend auf Smartphones (Mail-Link). Daher:

- Pages klein halten (5–15 Elemente pro Page ist gut)
- `matrix` mit ≤ 4 Spalten — alles darüber wird auf Mobile unbenutzbar. Bei vielen Optionen lieber pro Item ein `radiogroup`- oder `button-single-choice`-Element.
- `button-single-choice` für 2–4 Optionen mit hoher Klick-Sicherheit (großflächig)
- `dropdown` für 5+ Optionen ohne Gewichtung
- `tagbox` für Mehrfachauswahl mit vielen Optionen
- Texteingabe-Felder mit `wfaInputType: "number"` versehen, wenn nur Zahlen erwartet werden (öffnet Zifferntastatur)
