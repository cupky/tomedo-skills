# Score-Builder

Wie Scores im JSON technisch aufgebaut werden — mit fertigen, copy-paste-tauglichen Snippets für die praxisrelevanten Schmerz- und Psychometrie-Scores.

## Grundregel

Jeder Score ist ein eigenes `type: "expression"`-Element mit `visible: false` und eigenem `shortTitle`. Es wird **zusätzlich** zu den Frage-Elementen angelegt, deren Werte es aggregiert.

```json
{
  "type": "expression",
  "name": "scorename",
  "shortTitle": "scorename",
  "title": "Lesbarer Score-Name",
  "visible": false,
  "expression": "..."
}
```

## Verfügbare Funktionen

| Funktion | Quelle | Verwendung |
|---|---|---|
| `iif(cond, then, else)` | SurveyJS-Standard | Ternär. Achtung: **nicht** `iff`, das ist eine Doku-Falle. |
| `sum(a, b, …)` | SurveyJS-Standard | Summe |
| `avg(a, b, …)` | SurveyJS-Standard | Mittelwert |
| `min(a, b, …)`, `max(a, b, …)` | SurveyJS-Standard | Min/Max |
| `{feldname}` | SurveyJS-Standard | Direkter Feldzugriff |
| `wert("feldname")` | **tomedo-Erweiterung** | Feldzugriff mit Matrix-Support |
| `wert("matrix.Zeile1")` | **tomedo-Erweiterung** | Matrix-Zellenzugriff (Punkt-Notation) |
| `today()` | SurveyJS-Standard | Heutiges Datum |
| `age({geburtsdatum})` | SurveyJS-Standard | Alter aus Geburtsdatum |
| `isValidNumber({feld})` | **tomedo-Erweiterung** | Zahlen-Prüfung (für Validatoren) |
| `isValidPhoneNumber({feld})` | **tomedo-Erweiterung** | Telefon-Prüfung |

## Stolperfalle: String- statt Zahlenvergleich

`iif`-Vergleiche werden **lexikographisch** ausgewertet, wenn die Werte als Strings kommen:

```json
"expression": "iif({wert} < \"30\", ...)"
```

Bei zweistelligen Schwellen kein Problem. Bei dreistelligen: `"200"` ist lexikographisch kleiner als `"30"`! Lösung: **immer mit gleicher Stellenzahl pad**den oder explizit `+ 0` für Numeric-Cast:

```json
// Schlecht
"iif({wert} < \"100\", ...)"

// Besser
"iif(({wert} + 0) < 100, ...)"
```

## Score 1 — NRS (Numeric Rating Scale, 0–10 oder 0–100)

Direktwert aus einer Texteingabe oder Matrix-Mittelwert. Beispiel aus `psf-quartal`: NRS 0–100 als Mittelwert aus drei Matrix-Zeilen (Schmerz aktuell, durchschnittlich, stärkster):

```json
{
  "type": "matrix",
  "name": "schmerz-vkorff",
  "shortTitle": "schmerz-vkorff",
  "title": "Bitte bewerten Sie Ihre Schmerzen (0–10).",
  "columns": [
    { "value": "Spalte11", "text": "0" },
    { "value": "Spalte1",  "text": "1" },
    { "value": "Spalte2",  "text": "2" },
    { "value": "Spalte3",  "text": "3" },
    { "value": "Spalte4",  "text": "4" },
    { "value": "Spalte5",  "text": "5" },
    { "value": "Spalte6",  "text": "6" },
    { "value": "Spalte7",  "text": "7" },
    { "value": "Spalte8",  "text": "8" },
    { "value": "Spalte9",  "text": "9" },
    { "value": "Spalte10", "text": "10" }
  ],
  "rows": [
    { "value": "Zeile1", "text": "Schmerz aktuell" },
    { "value": "Zeile2", "text": "Schmerz durchschnittlich (letzte Wochen)" },
    { "value": "Zeile3", "text": "Stärkster Schmerz (letzte Wochen)" }
  ]
},
{
  "type": "expression",
  "name": "schmerzintensität",
  "shortTitle": "schmerzintensität",
  "title": "Charakteristische Schmerzintensität (0–100)",
  "visible": false,
  "expression": "avg(wert(\"schmerz-vkorff.Zeile1\"), wert(\"schmerz-vkorff.Zeile2\"), wert(\"schmerz-vkorff.Zeile3\")) * 10"
}
```

## Score 2 — von Korff Grad (0–4)

Originalpattern aus `psf-quartal`. Kombiniert `schmerzintensität` (siehe NRS) und `disability-punkte` (siehe PDI) zu einem Grad 0–4.

```json
{
  "type": "expression",
  "name": "vkorff",
  "shortTitle": "vkorff",
  "title": "von Korff Grad",
  "visible": false,
  "expression": "sum(iif({schmerzintensität} < \"1\", \"0\", iif({schmerzintensität} < \"50\", \"1\", \"2\")), iif({disability-punkte} < \"3\", \"0\", iif({disability-punkte} < \"5\", \"1\", \"2\")))"
}
```

**Logik:** Intensitätsachse (0–2) + Disability-Achse (0–2) → Summe 0–4.

## Score 3 — PDI (Pain Disability Index, vereinfachte praxiseigene Variante)

Originalpattern aus `psf-quartal`. Drei Items (Arbeit, Einschränkung, Freizeit) plus AU-Tage zu einem 4-stufigen Punktwert.

```json
{
  "type": "expression",
  "name": "disability-score",
  "shortTitle": "disability-score",
  "title": "Disability-Score (0–100)",
  "visible": false,
  "expression": "avg(wert(\"stärke-arbeit\"), wert(\"stärke-einschränk\"), wert(\"stärke-freizeit\")) * 10"
},
{
  "type": "expression",
  "name": "disability-punkte",
  "shortTitle": "disability-punkte",
  "title": "Disability-Punkte (0–6)",
  "visible": false,
  "expression": "sum(wert(\"anz-autage\"), iif({disability-score} < \"30\", \"0\", iif({disability-score} < \"50\", \"1\", iif({disability-score} < \"70\", \"2\", \"3\"))))"
}
```

## Score 4 — PHQ-9 (Depression, 0–27)

Standard PHQ-9: 9 Items, jedes 0–3, Summe 0–27.

**Vorbedingung:** 9 `radiogroup`-Items mit `value`s `"0"`, `"1"`, `"2"`, `"3"`. Naming-Konvention: `phq1`, `phq2`, …, `phq9`.

```json
// Frage-Element (×9)
{
  "type": "radiogroup",
  "name": "phq1",
  "shortTitle": "phq1",
  "title": "Wenig Interesse oder Freude an Tätigkeiten",
  "choices": [
    { "value": "0", "text": "Überhaupt nicht" },
    { "value": "1", "text": "An einzelnen Tagen" },
    { "value": "2", "text": "An mehr als der Hälfte der Tage" },
    { "value": "3", "text": "Beinahe jeden Tag" }
  ],
  "isRequired": true
},
// … phq2 bis phq9 analog …

// Score
{
  "type": "expression",
  "name": "phq9",
  "shortTitle": "phq9",
  "title": "PHQ-9 Summenwert",
  "visible": false,
  "expression": "sum(wert(\"phq1\"), wert(\"phq2\"), wert(\"phq3\"), wert(\"phq4\"), wert(\"phq5\"), wert(\"phq6\"), wert(\"phq7\"), wert(\"phq8\"), wert(\"phq9\"))"
}
```

**Schwellwerte für die Klinik:** 0–4 minimal · 5–9 leicht · 10–14 mittel · 15–19 schwer · 20–27 sehr schwer.

## Score 5 — GAD-7 (Angststörung, 0–21)

7 Items, jedes 0–3. Identisches Antwortschema wie PHQ-9.

```json
// Naming: gad1 … gad7, jeweils mit choices 0–3 wie PHQ-9

{
  "type": "expression",
  "name": "gad7",
  "shortTitle": "gad7",
  "title": "GAD-7 Summenwert",
  "visible": false,
  "expression": "sum(wert(\"gad1\"), wert(\"gad2\"), wert(\"gad3\"), wert(\"gad4\"), wert(\"gad5\"), wert(\"gad6\"), wert(\"gad7\"))"
}
```

**Schwellwerte:** 0–4 minimal · 5–9 leicht · 10–14 mittel · 15–21 schwer.

## Score 6 — DASS-21 (Depression, Anxiety, Stress; 3 Subskalen je 0–21)

21 Items, jedes 0–3. Drei Subskalen (je 7 Items): Depression, Angst, Stress.

**Item-Zuordnung (DASS-21-Standard):**
- Depression: 3, 5, 10, 13, 16, 17, 21
- Angst: 2, 4, 7, 9, 15, 19, 20
- Stress: 1, 6, 8, 11, 12, 14, 18

```json
// Naming: dass1 … dass21, jeweils mit choices 0–3

{
  "type": "expression", "name": "dass-depression", "shortTitle": "dass-depression",
  "title": "DASS-21 Depression", "visible": false,
  "expression": "sum(wert(\"dass3\"), wert(\"dass5\"), wert(\"dass10\"), wert(\"dass13\"), wert(\"dass16\"), wert(\"dass17\"), wert(\"dass21\")) * 2"
},
{
  "type": "expression", "name": "dass-angst", "shortTitle": "dass-angst",
  "title": "DASS-21 Angst", "visible": false,
  "expression": "sum(wert(\"dass2\"), wert(\"dass4\"), wert(\"dass7\"), wert(\"dass9\"), wert(\"dass15\"), wert(\"dass19\"), wert(\"dass20\")) * 2"
},
{
  "type": "expression", "name": "dass-stress", "shortTitle": "dass-stress",
  "title": "DASS-21 Stress", "visible": false,
  "expression": "sum(wert(\"dass1\"), wert(\"dass6\"), wert(\"dass8\"), wert(\"dass11\"), wert(\"dass12\"), wert(\"dass14\"), wert(\"dass18\")) * 2"
}
```

**Multiplikator `* 2`** ist DASS-21-Spezifikum (skaliert auf DASS-42-Range zur Schwellwert-Vergleichbarkeit).

## Score 7 — MPSS (Mainzer Pain Staging System, 1–3)

Mehrachsen-Score. Wird an der Referenzinstallation aktuell als Auswahl-Feld manuell erfasst (`CKEE.MPSS`-Eintrag), nicht als `expression`. Bei Bedarf kann eine vereinfachte Variante über Punkt-Zähler aus den Achsen-Items aufgebaut werden — sprich hier mit dem Arzt, das ist nicht standardisiert.

## Score 8 — VR-12 / SF-12 — NICHT nachbauen

**SF-12 ist lizenzpflichtig** (QualityMetric/Optum). **VR-12** ist der frei verwendbare Ersatz. Wenn ein VR-12-Modul gebraucht wird: Items beim Boston University / VA Health Outcomes Group herunterladen und im JSON 1:1 abbilden. Nicht selbst paraphrasieren — die Vergleichbarkeit mit Referenzdaten geht sonst verloren.

## Pattern: Score in `karteitextHtmlTemplate` einbauen

Sobald ein Score per `expression` berechnet wird, gehört er ins `karteitextHtmlTemplate`, damit er im Arztbrief und Karteieintrag sichtbar ist:

```html
<p>von Korff Grad: $[text('vkorff')]$</p>
<p>PHQ-9: $[text('phq9')]$ Punkte</p>
<p>$[iif({phq9} >= "10", '<strong>Hinweis: PHQ-9 ≥ 10 — diagnostische Abklärung empfohlen.</strong>', '')]$</p>
```

## Klinische Schwellwerte als Klartext

```html
<p>PHQ-9: $[text('phq9')]$ —
$[iif({phq9} < "5",  "minimal",
  iif({phq9} < "10", "leicht",
  iif({phq9} < "15", "mittel",
  iif({phq9} < "20", "schwer", "sehr schwer"))))]$</p>
```

(Wieder Vorsicht bei String-Vergleichen: `"15"` < `"5"` lexikographisch! Bei einstelligen Schwellwerten pad-den auf führende Null oder per `+ 0` casten.)
