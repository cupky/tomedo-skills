# Element-Types

Vollständige Liste der in den Referenzbögen empirisch belegten Element-Typen. Aufgeteilt in SurveyJS-Standard und zollsoft/tomedo-Erweiterungen.

## SurveyJS-Standard-Types

### `text` — einzeiliges Texteingabefeld

```json
{ "type": "text", "name": "telefonnummer", "shortTitle": "telefon",
  "title": "Telefonnummer", "inputType": "tel",
  "validators": [{ "type": "expression", "text": "Ungültige Telefonnummer.",
                   "expression": "isValidPhoneNumber({telefonnummer})" }] }
```

**`inputType`** (HTML5-Mapping): `text` (default), `number`, `date`, `email`, `tel`, `url`.
**`wfaInputType`** (zollsoft-Hint): `"number"` → öffnet auf Mobile die Zifferntastatur, ohne `inputType` zu erzwingen (Antwort bleibt String).

Validatoren siehe Abschnitt unten.

### `comment` — mehrzeiliges Texteingabefeld

```json
{ "type": "comment", "name": "anliegen", "shortTitle": "anliegen",
  "title": "Welches Anliegen führt Sie zu uns?",
  "placeholder": "Bitte beschreiben Sie kurz Ihr Anliegen." }
```

### `radiogroup` — Einfachauswahl (alle Optionen sichtbar)

```json
{ "type": "radiogroup", "name": "geschlecht", "shortTitle": "geschlecht",
  "title": "Geschlecht",
  "choices": [
    { "value": "Item1", "text": "weiblich" },
    { "value": "Item2", "text": "männlich" },
    { "value": "Item3", "text": "divers" } ] }
```

Für 2–5 Optionen geeignet. Bei mehr als 5 lieber `dropdown`.

### `checkbox` — Mehrfachauswahl mit Checkboxen

```json
{ "type": "checkbox", "name": "begleitsymptome", "shortTitle": "begleitsymptome",
  "title": "Welche Begleitsymptome treten auf?",
  "choices": [ {"value": "Item1", "text": "Übelkeit"}, … ] }
```

### `dropdown` — Einfachauswahl als Dropdown

```json
{ "type": "dropdown", "name": "schmerzcharakter", "shortTitle": "schmerzcharakter",
  "title": "Wie würden sie ihre Schmerzen beschreiben?",
  "choices": [ {"value": "Item1", "text": "Durchgängige Schmerzen mit leichten Schwankungen"}, … ] }
```

### `tagbox` — Mehrfachauswahl als Tag-Picker

```json
{ "type": "tagbox", "name": "kopf-begleit", "shortTitle": "kopf-begleit",
  "title": "Begleitsymptome während des Kopfschmerzes?",
  "description": "Es können mehrere ausgewählt werden",
  "choices": [ … ] }
```

Sinnvoll bei 8+ Optionen, wo `checkbox` zu viel vertikalen Platz frisst.

### `boolean` — Ja/Nein-Toggle

```json
{ "type": "boolean", "name": "raucher", "shortTitle": "raucher",
  "title": "Rauchen Sie?" }
```

Antwortwert: `true`/`false`. Im `karteitextHtmlTemplate` referenzieren als `{raucher} == true`.

### `matrix` — Matrix-Tabelle (Zeilen × Spalten)

```json
{ "type": "matrix", "name": "behandlungen-effekt", "shortTitle": "behandlungen-effekt",
  "title": "Welchen Effekt haben die Behandlungen?",
  "columns": [ {"value": "good", "text": "Gut geholfen"}, {"value": "none", "text": "Nicht geholfen"} ],
  "rows":    [ {"value": "medikamente", "text": "Medikamente"}, {"value": "physio", "text": "Physiotherapie"} ] }
```

**Wichtig:** Briefkommando-Auslese liefert nur Indizes (`good`/`none`/`medikamente`), nicht die Labels. Für Brief-Verwendung pro relevante Zelle eine `expression` daneben legen — siehe `conventions.md` §8.

### `expression` — versteckte Berechnung (Scores)

```json
{ "type": "expression", "name": "vkorff", "shortTitle": "vkorff",
  "title": "von Korff", "visible": false,
  "expression": "sum(iif({schmerzintensität} < \"1\", \"0\", iif({schmerzintensität} < \"50\", \"1\", \"2\")), …)" }
```

`visible: false` versteckt das Element in der Patient-UI, der Wert ist trotzdem in `formularelement.wert` verfügbar. Details in `score-builder.md`.

### `html` — Anzeige-only

```json
{ "type": "html", "name": "intro",
  "html": "<h3>Vielen Dank, dass Sie sich bei uns vorstellen.</h3><p>…</p>" }
```

Kein `shortTitle` nötig. Inhalt landet **nicht** in `formularelement`. Nur für Patient-UI-Hinweise.

### `signaturepad` — Unterschriften-Feld (nur Terminvereinbarung gesehen)

```json
{ "type": "signaturepad", "name": "signature", "shortTitle": "Unterschrift",
  "title": "Bitte unterschreiben Sie hier.", "isRequired": true }
```

Wert ist ein Base64-PNG.

## zollsoft/tomedo Custom Types

Diese Typen sind **nicht** Teil des SurveyJS-Standards. Sie werden vom arzt-direct-Renderer zusätzlich unterstützt.

### `button-single-choice` — Großflächige Touch-Buttons

```json
{ "type": "button-single-choice", "name": "$orzBestandspatient$",
  "shortTitle": "Bestandspatient",
  "title": "Bitte teilen Sie uns mit, ob Sie bereits bei uns waren.",
  "choices": [
    { "value": "true",  "text": "Bestandspatient:in" },
    { "value": "false", "text": "Neupatient:in" } ] }
```

UX-Variante von `radiogroup` mit großflächigen, klick-sicheren Buttons. Sinnvoll für 2–4 Optionen, wenn die Mobile-Klick-Sicherheit hoch sein muss (z. B. Triage-Entscheidung).

### `datepicker` — Datums-Picker mit Min/Max

```json
{ "type": "datepicker", "name": "$wfaBgUnfalldatum$", "shortTitle": "Unfalldatum",
  "title": "Bitte geben Sie das Unfalldatum an.",
  "minDate": "2016-01-01", "maxDate": "2036-12-31", "isRequired": true }
```

### `birthdate` — Geburtsdatum (stammdaten-kompatibel)

```json
{ "type": "birthdate", "name": "$wfaPatientGeburtstag$", "shortTitle": "Geburtsdatum",
  "title": "Geburtsdatum", "isRequired": true }
```

Separater Typ von `datepicker`, weil die UX (Drei-Felder-Picker tag/monat/jahr) und das Stammdaten-Mapping spezialisiert sind.

### `academic-title` — Anrede-Titel-Picker

```json
{ "type": "academic-title", "name": "$wfaPatientTitel$", "shortTitle": "Titel",
  "title": "Akademischer Titel" }
```

Dropdown mit standardisierten Werten (Dr., Prof., Prof. Dr., …).

### `gender` — Geschlechts-Picker

```json
{ "type": "gender", "name": "$wfaPatientGeschlecht$", "shortTitle": "Geschlecht",
  "title": "Geschlecht", "isRequired": true }
```

Liefert die in tomedo erwarteten Werte (`m`/`w`/`d`), nicht freie Strings — kompatibel mit dem Stammdaten-Binding.

### `contact` — Kontaktdaten-Block

```json
{ "type": "contact", "name": "$wfaPatientKontaktaufnahme$",
  "shortTitle": "Kontaktwege",
  "title": "Auf welchem Weg möchten Sie kontaktiert werden?" }
```

Spezial-Block, der mehrere Kontaktkanäle und Einwilligungen abfragt und in einem Multi-Wert ans tomedo-Stammdatenfeld zurückschreibt.

## Validators

Vier Validator-Typen kommen in den Referenzbögen vor:

```json
// email
{ "type": "email", "text": "Ungültige E-Mail Adresse." }

// numeric mit Range
{ "type": "numeric", "text": "Zahl zwischen 0 und 24.", "minValue": 0, "maxValue": 24 }

// answercount (für checkbox/tagbox)
{ "type": "answercount", "text": "Bitte mindestens eine Option auswählen.", "minCount": 1 }

// expression (frei programmierbar)
{ "type": "expression", "text": "Ungültige Telefonnummer.",
  "expression": "isValidPhoneNumber({telefonnummer})" }
```

**zollsoft-Erweiterungen** im `expression`-Validator:
- `isValidPhoneNumber({feldname})` — Telefonnummer-Validierung
- `isValidNumber({feldname})` — sanftere Zahlen-Prüfung als `type: numeric`

## Layout-Properties

| Property | Bedeutung |
|---|---|
| `startWithNewLine: false` | Element rendert in der gleichen Zeile wie das vorherige (z. B. Vorname + Nachname nebeneinander) |
| `colCount: 2` | Bei `radiogroup`/`checkbox`: Choices in 2 Spalten anordnen |
| `titleLocation: "hidden"` | Titel ausblenden (z. B. wenn die Frage durch ein vorangestelltes `html`-Element gestellt wird) |
| `placeholder` | Platzhaltertext im leeren Feld |
| `defaultValue` | Vorbelegung |

## Page-Level-Properties

| Property | Bedeutung |
|---|---|
| `name` | Page-ID (intern) |
| `title` | Page-Überschrift (string oder Locale-Dict) |
| `visibleIf` | Page komplett ausblenden, wenn Bedingung nicht erfüllt |
| `orzPageAction` | zollsoft-Spezial: `"otk"` öffnet Online-Termin-Kalender, `"stop"` bricht Workflow ab — siehe `page-actions.md` |
| `elements` | Array der Frage-Elemente |
