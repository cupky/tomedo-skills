# Gestaltung: was im Browser ankommt

> Teil des Skills `tomedo-patientenformulare`. Der Navigator ist `SKILL.md`.

**Belegbasis:** Gegentest vom 29.09.2026 an fünf live geschalteten Sondenformularen mit
36 Sonden, in vier Profilen (Desktop Chromium und WebKit, iPhone 15 und Pixel 7 **emuliert**),
15 echte Einsendungen. Jede Aussage ist mit einem Messwert aus DOM oder Computed Styles und
einem Screenshot belegt; zum Vergleich lief dieselbe Definition in reinem SurveyJS derselben
Version. Ausgeliefert wurde **survey-core 2.3.16**. Nach einem Update von arzt-direct oder
SurveyJS können sich einzelne Befunde ändern.

**Verbindlich:** Nur Mittel aus Abschnitt 1 verwenden. `scripts/lint.py` prüft Abschnitt 2
mechanisch (Regeln G1–G17, siehe `lint-rules.md`); ein gestaltetes Beispiel, in dem jedes Mittel
belegt ist, liegt in `assets/skeleton-gestaltung.json`.

Drei Stellen können eine Gestaltung verhindern. Wer sie unterscheidet, weiß, ob es sich lohnt,
weiter zu probieren:

| Wo | Was passiert | Erkennbar an |
|---|---|---|
| **tomedo-Editor beim Speichern** | bekannte, nicht freigegebene Properties werden **still** entfernt | fehlen in der Live-Definition |
| **arzt-direct zur Laufzeit** | Property steht in der Definition, wird aber überschrieben | Live-Definition hat sie, das laufende Modell nicht |
| **SurveyJS selbst** | Verhalten der Bibliothek, auch ohne arzt-direct | lokal mit reinem SurveyJS gleich |

## 1. Wirkt

| Mittel | Hinweis |
|---|---|
| `logo` als data-URI, `logoWidth`/`logoHeight`, `description` | Desktop: Logo rechts neben dem Titel. Handy: links über dem Titel |
| `firstPageIsStartPage` + `startSurveyText` | Startseite zählt nicht im Fortschritt und fehlt im Inhaltsverzeichnis |
| `startWithNewLine: false` | Desktop nebeneinander zu je 50 %, Handy untereinander |
| `colCount` 2 / 3 / 0 | Desktop wie angegeben; Handy siehe Abschnitt 4 |
| `labelTrue` / `labelFalse` | Beschriftung des Ja/Nein-Schalters |
| `tagbox` | Suchfeld, Auswahl als Chips |
| `rating` mit `displayMode: "buttons"`, `min/maxRateDescription` | Tastenreihe mit Randtexten |
| `rateType: "smileys"` / `"stars"`, `displayMode: "dropdown"` | echte Symbole (SVG) bzw. Auswahlliste |
| `matrix` | Handy: je Zeile als Liste |
| `image` mit data-URI (PNG, SVG), `<img src="data:…">` im `html` | |
| `requiredText` (wird gespeichert als `requiredMark`) | eigener Text statt `*`; im Web mit Leerzeichen, im PDF ohne |
| `questionErrorLocation: "bottom"`, `descriptionLocation: "underInput"` | |
| `titleLocation: "hidden"` + `placeholder` | |
| Inline-Styles im `html`-Element | tragfähigstes Gestaltungsmittel: Kästen, Linien, Farben, Links |
| `showTOC` | Desktop links; Handy siehe Abschnitt 4 |
| `showPreviewBeforeComplete` (gespeichert als `true` + `previewMode: "answeredQuestions"`), `previewText` | Vorschau mit „Bearbeiten" vor dem Absenden |
| `completedHtml` | Linien, Kästen, Emojis als Text; Überschriften siehe Abschnitt 3 |
| `progressBarType` `questions` / `requiredQuestions`, `progressBarLocation` `aboveheader` / `belowheader`, `progressBarShowPageTitles` | `progressBarLocation: "top"` lehnt der Editor ab |
| `pageNextText`, `pagePrevText`, `completeText` | |

## 2. Wirkt nicht

| Mittel | Ursache | Ausweg |
|---|---|---|
| `panel.state: "collapsed"` | Editor verwirft | keiner; Gruppe bleibt offen |
| `panel.questionTitleLocation: "left"` | Editor verwirft | keiner |
| `width`, `minWidth` | Editor verwirft | `startWithNewLine: false` |
| `boolean.renderAs` (radio, checkbox), `boolean.label` | Editor verwirft | **Einzelhäkchen nicht bauen**: mit `titleLocation: "hidden"` bleibt ein Schalter „Nein/Ja" ganz ohne Fragetext |
| `showOtherItem`, `otherText` | Editor verwirft | eigene Option plus `text`-Frage mit `visibleIf` |
| `showQuestionNumbers`, `editText` | Editor verwirft | „Bearbeiten" erscheint als Standardtext trotzdem |
| `questionsOnPageMode: "questionPerPage"` | **arzt-direct setzt zur Laufzeit `standard`**, obwohl die Definition den Wert behält | eine Frage je Seite von Hand bauen |
| `rateColorMode` / `scaleColorMode: "colored"` auf einer Zahlenskala | SurveyJS färbt nur `rateType: "smileys"` | Smileys oder Randtexte |
| HTML im Fragetitel | wird roh angezeigt | Hinweis als eigenes `html`-Element davor |
| Fragetyp `imagepicker` | Editor lehnt ab, in jeder Form | `image` + `checkbox` |
| `shortTitle` auf `panel` | Editor meldet „Unknown property" | weglassen |

## 3. CSS in `html`-Elementen

Die Content-Security-Policy erlaubt Inline-`<style>`, Inline-Styles, Bilder und Schriften als
data-URI. `<style>`-Blöcke bleiben beim Speichern erhalten und stehen im DOM. Drei Regeln
entscheiden, ob sie wirken:

1. **SurveyJS setzt `font-family`, `font-weight` und `font-size` für jedes `div` in einem
   `html`-Element** (`.sd-html div`, Spezifität 0,1,1). Eine reine Klasse (0,1,0) verliert.
   Farbe und Rahmen setzt die Regel nicht, die wirken auch über eine reine Klasse.
   Lokal gleich geprüft in Chromium und WebKit:

   | Schreibweise | Schriftstärke und -familie |
   |---|---|
   | `.klasse { … }` | wirkt nicht |
   | `span.klasse { … }` | wirkt nicht |
   | `div.klasse { … }` | wirkt |
   | `.sd-html .klasse { … }` | wirkt (empfohlen) |
   | `.klasse { … !important }` | wirkt |
   | `style="…"` am Element | wirkt |

2. **Ein `<style>` wirkt nur, solange seine Seite angezeigt wird.** Er verlässt beim
   Seitenwechsel mit dem Element das DOM. Globale Regeln (etwa Buttonfarben) gelten deshalb
   nur auf der Seite, die den Block enthält. Für ein seitenübergreifendes Design müsste der
   Block auf **jeder** Seite stehen.
3. **CSS-Variablen `--sjs-*` am `:root` wirken nicht.** arzt-direct setzt das Theme als
   Inline-Style auf `.sd-root-modern`; eine Variable am `:root` kommt dort nicht an. Nur
   direkte Regeln mit `!important` auf Buttons greifen, und auch die nur seitengebunden.
   Direkt an `.sd-root-modern` mit `!important` gesetzt, überstimmt eine Variable das
   Inline-Theme doch: `--sjs-base-unit` wirkt so am Desktop (Abschnitt 7). Bis zum Handytest
   bleibt das gesperrt, `lint.py` meldet jede `--sjs-*`-Variable als G14.

**Eingebettete Schrift:** `@font-face` mit `src: url(data:font/woff2;base64,…)` ist ladbar.
Angewendet wird sie nur mit einer Schreibweise, die Regel 1 übersteht. Sonst fordert der Browser
sie gar nicht erst an. Eine Schriftfamilie, die nirgends per `@font-face` eingebettet ist (etwa
eine Hausschrift aus dem Corporate Design), fällt auf die nächste Familie der Liste zurück.

**Abschlussseite (`completedHtml`):** arzt-direct erzwingt für `.sd-completedpage h3` Farbe
und Schriftstärke mit `!important`; ein Inline-Style an der `<h3>` kommt nicht durch.
**Überschriften als `<div>` mit Inline-Style bauen**, nicht als `<h3>`. Der Text der
Abschlussseite ist zentriert, darunter setzt arzt-direct einen Button „Als PDF exportieren".

```html
<!-- trägt: Inline-Style an einem div -->
<div style="font-family:Georgia,serif;font-size:1.4em;color:#1f2d3a">Vielen Dank.</div>
<!-- trägt nicht: h3 in completedHtml, Farbe und Stärke werden überstimmt -->
<h3 style="color:#1f2d3a;font-weight:400">Vielen Dank.</h3>
```

## 4. Smartphone

Auf iPhone- und Android-Emulation mit denselben Befunden:

| Mittel | Auf dem Handy |
|---|---|
| `colCount` 2 oder 3 | **eine Spalte** (SurveyJS, Klasse `sd-selectbase--mobile`) |
| `colCount: 0` | Fließzeile bricht um |
| NRS 0–10 als Tasten | drei Zeilen; der untere Randtext steht unter der Reihe |
| `matrix` | je Zeile eine Liste mit Radiobuttons |
| Logo | links über dem Titel |
| `showTOC` | Menüknopf oben rechts; er **überdeckt den Sprachknopf von arzt-direct** zur Hälfte |
| `progressBarShowPageTitles` | nur der Titel der aktuellen Seite |

Emulation ersetzt kein echtes Gerät. Bildschirmtastatur, Auto-Zoom kleiner Eingabefelder und
native Datumsdialoge sind damit nicht geprüft.

## 5. Was die Live-Definition verrät

- Der Server speichert Titel, Beschreibungen, `html`, `completedHtml`, `placeholder`,
  `labelTrue/False` und Validator-Texte als **`{"de": …}`**, Buttontexte und Randtexte als
  schlichten String. Angezeigt wird beides.
- Standardwerte (`logoFit`, `imageFit`, `tocLocation`, `rateMin`/`rateMax`) werden entfernt,
  `rateCount` wird aus `rateMin`/`rateMax` ergänzt.
- `maskType` und `maskSettings` am `datepicker` fehlen nach dem Speichern.
- Gegenprobe nach jedem Speichern: Live-Definition ziehen (`permalink-api.md` §9) und
  key-basiert über `name` mit der eigenen Fassung vergleichen.

## 6. PDF

Das PDF ignoriert CSS weitgehend (Hausschrift → Times, keine Kastenfarben). Text in
`html`-Elementen mit Zeichen außerhalb Latin-1 (– — „ " → und Emojis) erscheint im PDF mit
Präfix „þÿ" und gesperrten Buchstaben; Stellen nur mit Umlauten oder „·" bleiben sauber. Bis
zur Klärung in solchen Texten `-`, `"` und `->` verwenden. Belegt im Handtest; Ursache
plausibel, nicht geprüft.

## 7. Abstände zwischen Feldern

**Belegbasis:** Sondenformular „Sonde Abstände" vom 05.10.2026, sechs Seiten (S1 Referenz,
S2 Spacer, S3–S5 drei CSS-Varianten, S6 Kontrolle ohne CSS), Desktop-Screenshots und
PDF-Export. Werte grob aus Screenshots gemessen. **Smartphone nicht geprüft.**

Es gibt keinen JSON-Hebel: SurveyJS kennt keine Abstands-Property je Frage, `width` verwirft
der Editor (Abschnitt 2). Die `<style>`-Blöcke in `html`-Elementen überstanden das Speichern.

| Mittel | Desktop | PDF |
|---|---|---|
| Leeres `html`-Element `<div style="height:Npx"></div>` als Spacer | wirkt, vergrößert gezielt | fester Block, Höhe ignoriert (8, 24 und 48 px gleich groß) |
| `.sd-root-modern .sd-row{margin-top:4px !important}` | kaum Wirkung, der Zeilenabstand ist nicht der Hebel | keine Wirkung |
| zusätzlich Kartenpolster `.sd-element--with-frame` und Titelabstand `.sd-question__header` | wirkt: Feld zu Feld ≈ −15 %, Titel → Eingabe ≈ halbiert, Eingabefeld unverändert. **Empfohlen** | keine Wirkung |
| Grundeinheit `.sd-root-modern{--sjs-base-unit:5px !important}` | wirkt, verkleinert alles proportional, auch Eingabefeld (≈ −18 %) und Buttons | keine Wirkung |

**Rezept zum Verdichten** (in das erste `html`-Element **jeder** Seite, weil `<style>`
seitengebunden ist, Abschnitt 3):

```html
<style>
.sd-root-modern .sd-row{margin-top:4px !important}
.sd-root-modern .sd-element--with-frame{padding-top:8px !important;padding-bottom:8px !important}
.sd-root-modern .sd-question__header{padding-bottom:2px !important}
</style>
```

Die Grundeinheit (`--sjs-base-unit`) erst nach Handytest einsetzen: kleinere Eingabefelder
und Buttons können die Tippflächen unter eine bequeme Größe drücken. Bis dahin blockiert
`lint.py` sie als G14.

