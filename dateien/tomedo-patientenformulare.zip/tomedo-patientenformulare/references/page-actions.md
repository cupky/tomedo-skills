# Page-Actions & Page-Level-Branching

Page-Level-Properties steuern den Patient-Workflow zwischen den Seiten. Drei Mechanismen:

## 1. `visibleIf` auf Page-Ebene

Ganze Page ausblenden:

```json
{
  "name": "UeberweisungsDetails",
  "title": "Benötigte Überweisung",
  "visibleIf": "{$orzBestandspatient$} = 'false'",
  "elements": [ … ]
}
```

Funktioniert identisch zum Element-`visibleIf`, nur auf Page-Granularität. Sinnvoll für Use-Case-spezifische Sektionen (z. B. „Überweisungs-Details" nur für Neupatienten).

## 2. `orzPageAction` — zollsoft-Spezial

In der Online-Rezeption gibt es zwei Sonder-Aktionen, die Pages auslösen können:

| Wert | Effekt |
|---|---|
| `"otk"` | Bei Erreichen dieser Page wird der **Online-Termin-Kalender** (Otk) eingeblendet/geöffnet. Der Patient bucht direkt. |
| `"stop"` | Workflow wird **abgebrochen**. Hinweis-Page wird angezeigt, kein Weiter-Button. |

Pattern aus `survey-3.json` (Überweisung):

```json
{
  "name": "NeupatientOtk",
  "title": "Hinweis",
  "visibleIf": "{$orzBestandspatient$} = 'false'",
  "orzPageAction": "otk",
  "elements": [
    {
      "type": "html",
      "html": "<p>Sie sind Neupatient:in. Bitte buchen Sie hier einen Termin.</p>"
    }
  ]
},
{
  "name": "NeupatientGesperrt",
  "title": "Hinweis",
  "visibleIf": "{$orzBestandspatient$} = 'false'",
  "orzPageAction": "stop",
  "elements": [
    {
      "type": "html",
      "html": "<p>Aktuell nehmen wir keine Neupatienten an.</p>"
    }
  ]
}
```

**Hinweis:** `orzPageAction` setzt voraus, dass das Formular in der Online-Rezeption (Otk-Kontext) ausgespielt wird. Bei reinem Mail-Versand-Modus hat die Property keinen Effekt — der Patient kommt einfach zur nächsten Page.

## 3. Reihenfolge der Pages

SurveyJS rendert Pages in der Reihenfolge des `pages`-Arrays. `visibleIf` filtert heraus, was nicht passt. Eine sinnvolle Default-Reihenfolge:

1. **Triage-Page** (eine Frage entscheidet Hauptpfad)
2. **Use-Case-spezifische Pages** mit `visibleIf` auf den Triage-Wert
3. **Stammdaten-Page** (nur wenn überhaupt gebraucht)
4. **Abschluss/Bestätigung-Page** (Unterschrift, Einwilligung)

## Pattern — Triage-Workflow mit Stop-Page

```json
{
  "title": "Überweisung",
  "pages": [
    {
      "name": "Triage",
      "title": "Bestands- / Neupatient",
      "elements": [
        { "type": "button-single-choice", "name": "$orzBestandspatient$",
          "shortTitle": "Bestandspatient",
          "choices": [
            { "value": "true",  "text": "Bestandspatient:in" },
            { "value": "false", "text": "Neupatient:in" } ],
          "isRequired": true }
      ]
    },
    {
      "name": "NeupatientStop",
      "title": "Hinweis",
      "visibleIf": "{$orzBestandspatient$} = 'false'",
      "orzPageAction": "stop",
      "elements": [
        { "type": "html",
          "html": "<p>Aktuell nehmen wir keine Neupatienten an.</p>" }
      ]
    },
    {
      "name": "Details",
      "title": "Details zur Überweisung",
      "visibleIf": "{$orzBestandspatient$} = 'true'",
      "elements": [ … ]
    }
  ]
}
```

## Stolperfallen

1. **`orzPageAction: "stop"`** zeigt typischerweise ein `html`-Element als Hinweis. Wenn das Element fehlt, sieht der Patient eine leere Page mit Sperr-Status — schlechte UX.
2. **Visibility-Reihenfolge:** `visibleIf` wirkt erst nach der Auswertung des Vorgänger-Inputs. Bei reaktivem Branching-Bedarf alle Werte vorher einsammeln.
3. **Page-Name muss eindeutig sein** (analog zu Element-`name`). Doppelte Page-Namen sind in den Referenzbögen nicht vorgekommen, sind aber wahrscheinlich problematisch für `visibleIf`-Referenzen.
4. **Branching-Werte als Strings:** `{$orzBestandspatient$} = 'true'` — mit Anführungszeichen, weil die Choices `value: "true"` als String vorhalten, nicht als Boolean.
