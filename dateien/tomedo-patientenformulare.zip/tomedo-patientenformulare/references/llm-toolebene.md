# LLM-Toolebene: Formulare im KI-Kontext

> Teil des Skills `tomedo-patientenformulare`. Der Navigator ist `SKILL.md`.

---

**Belegbasis:** Export der tomedo-LLM-Tool-Definitionen (09/2026, 112 Funktionsdefinitionen im Function-Calling-Format).

**Statusregel:** Alles hier ist **dokumentiert** — Herstellerbeschreibung, von uns **nicht** nachgeprüft. Der Export ist die Union aller Toolsets; welche Tools in welchem Chat exponiert sind, ist unbelegt.

**Abgrenzung, die vorweg wichtig ist:** Diese Tools betreffen **tomedo-interne Formulare** (Formulartypen mit numerischer Formular-ID, Muster-Formulare wie AU, Überweisung, Rezept). Die von diesem Skill gebauten **arzt-direct-Patientenformulare** (SurveyJS-JSON) sind davon technisch verschieden. Der Berührungspunkt ist das **Auslesen**: ein eingegangenes PatF liegt als Karteieintrag mit Formularelementen vor, und dafür existiert jetzt ein zweiter Weg neben dem Briefkommando.

---

## 1 · Vier Formular-Operationen

| Tool | Wirkung | Kritische Auflage |
|---|---|---|
| `LLMToolListFormularTypes` | eindeutige ID **aller** öffenbaren Formulare plus Beschreibung | – |
| `LLMToolMatchFormularAgent` | ermittelt aus Beschreibung, Name oder Suchbegriff die Formular-ID | – |
| `LLMToolListFieldsInFormularAgent` | alle **bearbeitbaren** Felder eines Formulars | `query` muss ausschließlich die exakte ID sein, „ohne zusätzliche Beschreibung und ohne Markdown" |
| `LLMToolCreateFormular` | öffnet das Formular und befüllt es optional vor | **„UNWIDERRUFLICH – GENAU EINMAL aufrufen"** |

Dazu zwei Befüller: `LLMToolFormularBefuellerAgent` (Parameter `onlyUserInput` und `shouldFillBriefkommandos`, jeweils als String `"true"`/`"false"`, plus die vollständige flache Feldliste) und `LLMToolFillAndOpenFormularAgent` (Erstellen und Öffnen in einem, „gibt eine strukturierte Zusammenfassung der eingetragenen, ergänzten und manuell nachzutragenden Felder zurück").

### Das Feld-Format von `CreateFormular`

Flaches JSON-Array, ein Objekt je Feld, genau zwei Keys:

```json
[{"id": "textfeld_1", "content": "Max Mustermann"},
 {"id": "f6", "content": "01.01.2026"},
 {"id": "abc", "content": "true"}]
```

Aus der Beschreibung, wörtlich relevant:

- **Keine Verschachtelung**, keine `felder`-/`gruppen`-Schlüssel, keine Options-Objekte.
- **Eine Gruppe löst man auf**, indem man ein Objekt mit der `id` der **gewählten Option** einträgt — nicht die Gruppe mit einem Wert.
- Checkbox an = `"true"`; nur Felder aufnehmen, die tatsächlich gesetzt werden.
- Feld-IDs „Zeichen für Zeichen, keine Übersetzung".

Das ist strukturell eine andere Welt als das SurveyJS-JSON dieses Skills: dort trägt jedes Element `name` **und** `shortTitle`, hier gibt es nur eine opake `id`, die vorher über ein Tool geholt werden muss.

---

## 2 · Die Ident-Präzisionsfalle

Wörtlich aus der Beschreibung von `LLMToolCreateFormular`:

> Die ID des Formulars … als String in Anführungszeichen, z.B. `"129893642613555201"`. Übergib die Ziffernfolge exakt, vollständig und Zeichen für Zeichen, **NIEMALS als Zahl**: Eine Zahl dieser Länge wird beim Verarbeiten gerundet (z.B. zu `1.29...e+17`) und zeigt dann auf ein anderes oder gar kein Formular.

**Für diesen Skill übertragbar und wichtig:** Das ist keine Formular-Eigenheit, sondern eine Eigenschaft 18-stelliger tomedo-Idents in jeder JSON-Verarbeitung, die Zahlen als Double behandelt. Betrifft damit auch:

- Karteieintrags-Idents in Auswertungen, Exporten und Übergabedateien
- eigene Skripte, die PatF-Rückläufe verarbeiten
- alles, was `json.loads` / `JSON.parse` auf tomedo-Daten anwendet

**Regel: tomedo-Idents immer als String führen, nie als Zahl.** In Python bei Bedarf `json.loads(s, parse_int=str)`; in JavaScript `JSON.parse` mit Reviver oder Vorverarbeitung, weil `Number.MAX_SAFE_INTEGER` bei 2^53−1 liegt und 18 Stellen darüber liegen.

---

## 3 · Zweiter Auslesepfad für eingegangene Formulare

`LLMToolExtrahiereFormularAgent(query, formular)` — „liest den Inhalt eines ausgefüllten Formulars aus. Benötigt dafür die vollständige `ident` des entsprechenden **Karteieintrags**, in dem das Formular liegt."

Damit stehen für PatF-Rückläufe zwei Wege nebeneinander:

| Weg | Zugriff | Deterministisch | Setzt voraus |
|---|---|---|---|
| **Briefkommando** `$[formularEintrag <formulartyp> <bezeichner> d]$` | gezielt ein Feld | ja | `shortTitle` bekannt und exakt; formulartyp-spezifisch |
| **`ExtrahiereFormularAgent`** | Leseauftrag in natürlicher Sprache | nein | KE-`ident` bekannt |

**Bewertung:** Der Briefkommando-Weg bleibt der produktive. Der Agent-Weg ist wertvoll für **Exploration** — etwa um bei einem unbekannten Formular herauszufinden, welche Werte überhaupt drinstehen, bevor der Bezeichner gesucht wird. Er ersetzt nicht die Konvention „jeder relevante Wert braucht einen `shortTitle`", denn ohne diesen ist der Wert weder kommandierbar noch HQL-auswertbar.

Ebenfalls dokumentiert: `LLMToolGetPatientsHistory` nennt **gespeicherte Formulare** ausdrücklich in seinem Lieferumfang. Ein eingegangenes PatF ist damit auch im Chatkontext präsent, nicht nur über die genannten Tools.

---

## 4 · `LLMToolShowForm` — Dialog ohne Formularbau

Zeigt dem Nutzer ad hoc ein Eingabeformular und gibt die Eingaben als JSON zurück. Feldtypen: `text_single`, `text_multi`, `dropdown`, `checkbox`, `date`; optionale Keys `default_value`, `placeholder`, `required`.

Dropdowns auf genau einem von zwei Wegen:

- **statisch:** `options` als Array von `{"value": …, "label": …}` — der Nutzer sieht `label`, gesendet wird `value`
- **dynamisch:** `dynamic=true` plus `depends_on` aus einer Create-Signature; `options` dann **nicht** setzen, `entity_name` auf oberster Ebene

Bemerkenswert ist der Satz in der Beschreibung: „Da das eine schnelle Art zum sammeln von Informationen ist, kannst du ohne Bedenken alle fragwürdigen Informationen abfragen." Der Hersteller senkt hier bewusst die Schwelle zur Rückfrage. Für uns ist das ein Argument, das in die Formular-Ökonomie hineinspielt: eine Rückfrage im Chat kostet weniger als ein Pflichtfeld im Patientenformular — aber sie erreicht nur den **Mitarbeiter**, nicht den Patienten. Die Outsourcing-Logik dieses Skills (Erhebung zum Patienten verlagern) bleibt davon unberührt.

---

## 5 · Was die Toolebene für diesen Skill **nicht** kann

- **Kein arzt-direct-Formular anlegen oder ändern.** Kein Tool erzeugt SurveyJS-JSON, keines spielt eines aus. Der Bau bleibt vollständig bei diesem Skill.
- **Keine `shortTitle`-Vergabe, keine Score-`expression`.** Die zwölf Konventionen und `scripts/lint.py` bleiben unverändert verbindlich.
- **Kein Zugriff auf die Permalink-API.** Der zweite Ausspielweg ist der Toolebene unbekannt.

---

## 6 · Offene Punkte

1. Liefert `ExtrahiereFormularAgent` bei einem arzt-direct-PatF die Werte je `shortTitle` oder nur narrativ? Entscheidet, ob er als Prüfwerkzeug für neu gebaute Formulare taugt.
2. Sieht `ListFieldsInFormularAgent` auch arzt-direct-Formulare oder nur tomedo-Formulartypen?
3. Ist `matrix` im Chatkontext als Label oder — wie im Briefkommando — als Index `{ZeileN=SpalteM}` sichtbar? Falls als Label, wäre das ein Argument, das die Parallel-`expression` nur noch für den Kommando-Weg zu brauchen.

---

*Referenz zu `tomedo-patientenformulare`, Stand 2026-09-10. Belegbasis: Tool-Definitions-Export 09/2026. Alle Aussagen **dokumentiert**, keine geprüft. Kernaussage: die Toolebene liest und öffnet Formulare, baut aber keine — und die 18-stellige Ident-Rundungsfalle gilt für alle tomedo-Idents, nicht nur für Formular-IDs.*
