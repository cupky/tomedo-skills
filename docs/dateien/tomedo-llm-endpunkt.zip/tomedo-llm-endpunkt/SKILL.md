---
name: tomedo-llm-endpunkt
version: 1.0
description: >
  Baut und debuggt Aufrufe an den OpenAI-kompatiblen LLM-Service-Endpunkt des
  tomedo-Servers — den einzigen tomedo-KI-Pfad mit freier Modellwahl. Verwende
  diesen Skill IMMER wenn LLM-Service-Endpunkt, llmservice, chat/completions an
  tomedo, Modellwahl per Feld `model`, gemini-2.5-pro oder gemini-2.5-flash ueber
  tomedo, oder ein direkter API-Aufruf an den tomedo-Server erwaehnt werden. Auch
  verwenden bei: Endpunkt antwortet nicht, HTTP 404 auf llmservice, HTTP 422
  Unbekanntes Modell, HTTP 400 mit leerem Koerper, Antwort ohne Feld content,
  finish_reason length, Kosten hochrechnen, 5-Dollar-Limit, Token-Verbrauch
  unplausibel, Denk-Tokens, reasoning_effort, max_tokens, Streaming geht nicht,
  tools werden ignoriert, Modell zu langsam, Ausgabe streut zu stark, Stapellauf
  gegen den Endpunkt, Hintergrundprozess ruft tomedo-KI. NICHT fuer
  KarteiChat-Prompts (→ karteichat-prompting), nicht fuer KI-Prompts in
  Aktionsketten (→ tomedo-aktionsketten), nicht fuer HQL-Statistiken
  (→ tomedo-statistik-hql).
---

# tomedo LLM-Service-Endpunkt

Dieser Skill ist ein **Navigator**. Die Belege, Messwerte und Codebausteine
liegen in `references/`. Hier stehen nur Einordnung, Schnellstart, die Fallen
und der Wegweiser.

Alle Angaben belegt am Produktivsystem, tomedo **v1.170.0.16**, Stand
2026-09-13, aus 143 Messaufrufen, davon 95 als Datei gesichert — nicht aus
Dokumentation.

---

## 1 · Einordnung: drei KI-Pfade, nur einer mit Modellwahl

| Pfad | Modellwahl | Werkzeugzugriff | Zustaendiger Skill |
|---|---|---|---|
| KarteiChat | nein | **ja** | `karteichat-prompting` |
| KI-Prompt in Aktionskette | nein | **ja** | `tomedo-aktionsketten` |
| **LLM-Service-Endpunkt** | **ja, pro Anfrage** | **nein** | dieser Skill |

**Die Kernabwaegung:** Der Endpunkt gibt Modellwahl und Parameter, bietet aber
keinen Werkzeugzugriff. **Er sieht keine Akte.** Alles, was das Modell wissen
soll, muss in den Prompt. Fuer Aufgaben ueber Akteninhalte sind die beiden
anderen Pfade zustaendig — oder der Akteninhalt muss vorher beschafft und
eingebettet werden.

---

## 2 · Schnellstart

```bash
SRV="http://{host}:{port}/{db}"   # tomedo > Ueber tomedo > Server-URL
IDENT="{userIdent}"               # Testnutzer, nie ein Produktivnutzer

curl -i --max-time 60 \
  "$SRV/llmservice/$IDENT/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d '{"model":"gemini-2.5-pro","stream":false,
       "reasoning_effort":"minimal",
       "messages":[{"role":"user","content":"Antworte nur mit: OK"}]}'
```

`$SRV` enthaelt den Datenbanknamen mit — die vollstaendige Route steht in
`references/aufruf-und-parameter.md` Abschnitt 1, die Beschaffung der beiden
Werte in Abschnitt 2.

Drei Dinge, die im Schnellstart schon stecken:

- **`"messages"` ist ein Array.** Die offizielle Vorlage zeigt faelschlich ein
  Objekt.
- **Nie `curl -s` allein** — das verschluckt Fehler und liefert leere Ausgabe
  ohne Diagnose. Immer `-i` oder `-w '%{http_code}'`.
- **`reasoning_effort: minimal` gehoert in fast jeden Aufruf.** Es senkt die
  realen Kosten auf ein Drittel bis Viertel und die Latenz etwa auf die
  Haelfte. Siehe `references/kosten-und-budget.md`.

---

## 3 · Die fuenf Fallen

Jede einzelne hat in der Erprobung Zeit oder Geld gekostet.

1. **`HTTP 200` ist kein Beleg fuer eine Antwort.** Bei `finish_reason:
   "length"` fehlt das Feld `content` **vollstaendig** — nicht leer, es
   existiert nicht. Jeder Client muss das abfangen.
   → `references/fehlerdiagnose.md`

2. **`max_tokens` begrenzt Denken *und* Ausgabe zusammen.** Bei Pro reichten
   selbst 2000 Tokens nicht fuer eine einzige Antwortzeile — das Kontingent
   ging vollstaendig fuers Nachdenken drauf.
   → `references/kosten-und-budget.md`

3. **Das Feld `cost` untertreibt um Faktor 11 bis 543.** Es rechnet die
   Denk-Tokens nicht mit, Google berechnet sie aber.
   → `references/kosten-und-budget.md`

4. **Das 5-$-Limit bremst nicht.** Belegt: 10,10 $ reale Kosten an einem
   frischen Nutzer, null Ablehnungen. **Kostenkontrolle selbst bauen.**
   → `references/kosten-und-budget.md`

5. **`tools` und `stream` werden stillschweigend ignoriert** — kein Fehler,
   nur Wirkungslosigkeit. Wer `tools` mitschickt und auf Werkzeugaufrufe
   wartet, bekommt eine plausible, **frei erfundene** Textantwort.
   → `references/aufruf-und-parameter.md`

---

## 4 · Wegweiser

| Anliegen | Datei |
|---|---|
| Aufruf bauen, Werte beschaffen, Modellliste, welche Parameter gehen | `references/aufruf-und-parameter.md` |
| Kosten hochrechnen, Denk-Tokens, `reasoning_effort`, `max_tokens`, Budgetlage | `references/kosten-und-budget.md` |
| Fehlermeldung deuten, Antwort robust auswerten | `references/fehlerdiagnose.md` |
| Flash oder Pro? Latenz, Streuung, Formattreue | `references/modellwahl.md` |
| Stapelbetrieb, Hintergrundprozesse, Durchsatz, Messmethodik | `references/betrieb-und-messung.md` |

---

## 5 · Harte Randbedingungen

**Keine echten Patientendaten an den Endpunkt.** Die Antwort des Servers
enthaelt ein `Set-Cookie` fuer `.generativelanguage.googleapis.com` — die
Anfragen gehen nachweislich an Googles Generative Language API. Ob ein
Anonymisierungs-Gate davor noetig ist, ist eine **rechtliche** Frage fuer den
Datenschutzbeauftragten und in diesem Skill nicht zu entscheiden. Bis zu einer
dokumentierten Freigabe gilt: nur synthetische Demoakten.

**Kostenkontrolle selbst fuehren.** Das Serverlimit greift nachweislich nicht
beim realen Verbrauch. Nach jedem Aufruf die echten Kosten mitrechnen — der
Baustein steht in `references/kosten-und-budget.md`.

**Testnutzer statt Produktivnutzer.** Das Budget haengt am tomedo-Nutzer.

**Keine Reproduzierbarkeit erwarten.** `seed` wird abgelehnt; 20 Laeufe je
Modell mit identischem Prompt ergaben 20 verschiedene Ausgaben.

---

## 6 · Was dieser Endpunkt nicht kann

- **Keinen Werkzeugzugriff** — er sieht keine Akte, keinen Termin, keine Leistung
- **Keine Reproduzierbarkeit** — `seed` wird abgelehnt
- **Kein Streaming** — `stream` wird stillschweigend ignoriert
- **Keine Embeddings** — also kein RAG ueber diesen Weg
- **Keine Kontostandsabfrage** — das Budget ist blind
- **Keine Modellliste** — `/v1/models` gibt es nicht
- **Keine verlaessliche Kostenbremse** — siehe Falle 4

---

## 7 · Wirkungsbereich im tomedo-KI-Handbuch

Dieser Skill ist die Quelle fuer mehrere Abschnitte des Handbuchs (Stand v0.7).
**Wer hier eine Messzahl aendert, zieht sie dort in derselben Sitzung nach** —
in allen betroffenen Abschnitten, nicht nur in dem, der den Anlass gab.

| Handbuch | Was von hier einfliesst | Referenzdatei |
|---|---|---|
| **§8** LLM-Service-Endpunkt | Route und Routeninventar, Parameter-Positivliste, wirkungslose Felder, Fehlerbilder, launchd-Erreichbarkeit, Durchsatzgrenze | `aufruf-und-parameter.md`, `fehlerdiagnose.md`, `betrieb-und-messung.md` |
| **§9** Modellwahl und Modelleffekt | Vergleich bei n=20, Formattreue, Streuungsmasse, Empfehlung Pro mit `reasoning_effort: minimal` | `modellwahl.md` |
| **§12** Kosten | Untertreibung von `cost`, Denk-Tokens, `reasoning_effort`, `max_tokens`-Falle, Lasttest zum 5-$-Limit | `kosten-und-budget.md` |
| **§14** Grenzen und Fehlerquellen | Endpunkt-Systemgrenzen, Fehlerklassen „leere Antwort trotz HTTP 200" und „kleine Stichprobe taeuscht" | alle fuenf |
| **§15** Offene Fragen | F18 Promptgroesse, F19 Limitanrechnung, F20 ungemessene Modelle, F21 Systemdomaene | `kosten-und-budget.md`, `betrieb-und-messung.md` |

> **Warum das hier steht.** Handbuch v0.5 hat aus diesem Skill nur die
> Kostenaussage (§12) uebernommen und die Latenzkorrektur in §9 liegen lassen —
> obwohl beide aus derselben Messreihe stammen. Die falsche Zahl blieb eine
> Fassung laenger stehen. Die Tabelle oben ist die Gegenmassnahme.

> **Beim Erweitern dieses Skills:** Die Korrekturen an Beschreibungslaenge,
> Schnellstart und Kosten-Baustein sind kein Beiwerk — ohne sie scheitert der
> Org-Import. Nach jedem Neubau gegen die Checkliste in Abschnitt 4 des
> Handbuch-Anhangs beziehungsweise gegen das Gate-Script pruefen.
