# Lessons Learned — dokumentierte Fehlerquellen (v10)

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Neu angelegt. 46 Lessons aus SKILL.md v9 ausgelagert und thematisch gruppiert; Inhalt unverändert übernommen. SKILL.md enthält nur noch Verbote und Lese-Routing.

> Diese Datei sammelt die reproduzierten Fehler aus der Referenzinstallation. Jeder Abschnitt beschreibt einen Fehler, der mindestens einmal Zeit oder falsche Zahlen gekostet hat. Vor dem Bau einer Query den Abschnitt zur jeweiligen Domäne lesen.

## Inhalt

- **[A. tomedo-Ausführungsumgebung](#a-tomedoausführungsumgebung)** — Was die tomedo-Statistik-Engine anders macht als eine normale psql-Session.
  - Temp-Tabellen sterben zwischen Runs
  - ZS-Tags nur im finalen SELECT
  - Query-Text-Regeln fuer tomedo-Statistiken: kein Prozentzeichen, ein Semikolon
  - System-Katalog-Queries verboten
  - tomedo-Serializer: TIME-Spalten (Typ 92) brechen den Export
  - Unplausible Fehlerposition = abgeschnittenes Statement
- **[B. PostgreSQL-Fallen](#b-postgresqlfallen)** — Dialekt- und Typprobleme, die als Abbruch oder als stiller Zahlenfehler auftreten.
  - ::numeric Cast bei ROUND
  - `percentile_cont()` braucht Cast vor `ROUND`
  - GROUP BY ROLLUP wird nicht unterstützt
  - unknown-Typ bei string_agg ueber UNION-Literale
  - Alias-Kollision: PostgreSQL ist case-insensitiv
  - Dynamisches aktuelles Quartal & Alias-Kollision
  - Quartalsindex `qidx` — Projektstandard
  - Regex-Wortgrenze `\y` scheitert an Unterstrichen
  - LIKE und Backslash: Steuerzeichen nie per LIKE suchen
  - HTML-Erkennung: `%<%>%` ist untauglich
- **[C. Datenmodell-Fallen: Pfade, Bridges, Geldwerte](#c-datenmodellfallen-pfade-bridges-geldwerte)** — Falsche Pfade und Aggregationen. Häufigste Ursache für Prozente >100 % und für leere Ergebnisse.
  - Jahresscharfer Diagnose-JOIN
  - 2-Stufen EBM-Euro-Aggregation
  - Geldwerte: `eurowertincent`, nicht `eurowertahincent`
  - EBM-Codes tragen nichtnumerische Suffixe
  - Patientenliste ≠ Patientengruppe
  - Gruppenpsychotherapie & Patientenschlange (Lessons)
  - Patientenformulare (arzt-direct)
  - PatF-Zählung: kein JOIN zu karteieintragtyp nötig
  - `formulartyp`-Filter: idents vorauflösen, nie `LIKE` im JOIN
  - Textanalysen auf karteieintrag: Basistabelle, nicht View
- **[D. Epochen und Feldrealität der Referenzinstallation](#d-epochen-und-feldrealität-der-referenzinstallation)** — Welche Felder ab wann befüllt sind. Ein Feld im DB-Dump ist keine Zusage, dass Daten drinstehen.
  - Termin-Tabelle erst ab Nov 2025
  - Sperrtage: terminkalendertag statt Dauer-Heuristik
  - Bearbeitungszeitpunkte existieren an der Referenzinstallation nicht
  - Medikamentenverordnung: strukturierte Felder nur Post-Migration
  - Freie Kapazität (forward-looking) — keine Dienstplan-Tabelle
  - Aufgaben-System (aufgabe-Tabelle): oeffentlich/offen sauber filtern
  - Aktivitaets-Sessionisierung: Dichte-Untergrenze beachten
  - Nützliche neue Felder (Zollsoft 03/2026)
- **[E. Fachliche Marker, Codes und Auswahlregeln](#e-fachliche-marker-codes-und-auswahlregeln)** — Wie eine Fragestellung korrekt auf Codes, Kürzel und Kalender abgebildet wird.
  - Echter Behandler ≠ Abrechnungsarzt
  - Code-Discovery empirisch, nicht per Keyword
  - KH-Einweisung: Freitext-Detektor vs. Formular
  - MPSS: `%Chronifizierung%` ist kein Suchkriterium
  - AU-Formulare erkennen
  - Administrative Codes ohne Patientenkontakt
  - GOÄ-Quartal aus Datum ableiten
  - Outlook- und Raumkalender ausschließen
  - Verstorbene Patienten ausschließen
  - TRIM bei Terminart-Kürzel
  - Satzzaehlung in Rechnungs- und Abrechnungstexten
  - DATE-ZS-Filter: kein Semikolon

---

## A. tomedo-Ausführungsumgebung

*Was die tomedo-Statistik-Engine anders macht als eine normale psql-Session.*

### Temp-Tabellen sterben zwischen Runs

tomedo HQL löscht temp-Tabellen zwischen Ausführungen. **Jede SQL-Datei MUSS selbstständig sein** — alle benötigten temps neu aufbauen. Kein Chaining über mehrere Dateien.

### ZS-Tags nur im finalen SELECT

ZS-Filter-Tags (`/*{{Tag:...}}*/`) innerhalb von `CREATE TEMPORARY TABLE` werden von tomedo komplett entfernt (nicht aufgelöst), was zu ungültigem SQL führt (z.B. aufeinanderfolgende AND-Keywords). ZS-Tags dürfen **nur im finalen SELECT** stehen.

### Query-Text-Regeln fuer tomedo-Statistiken: kein Prozentzeichen, ein Semikolon

Im Text einer als tomedo-Statistik hinterlegten Query gilt:

1. **Kein Prozentzeichen — auch nicht in Kommentaren.** Sonst bricht die Ausfuehrung ab mit
   `ERROR: syntax error at or near "%"` samt Positionsangabe. Belegt zweimal in Folge, Ursache waren
   `%(kuerzel)s` (psycopg-Bindparameter) und `LIKE 'Arzeko%'` in **Kommentarzeilen**.
   Wildcards daher ueber `LEFT(TRIM(x), n) = '…'` statt `LIKE`.
2. **Nur ein Semikolon**, das Statement-Ende. Semikolons in Kommentaren sind riskant, falls tomedo den
   Text an `;` in Statements zerlegt.

**Vor der Abgabe pruefen:** Prozentzeichen-Anzahl = 0, Semikolon-Anzahl = 1.

**Konsequenz fuer Python-Queries:** `%(name)s`-Platzhalter sind ausschliesslich im psycopg-Pfad gueltig.
Eine parametrisierte Query kann nicht ohne Umbau in eine Statistik uebernommen werden — sie muss
parameterlos werden (Werte selbst aus der DB holen, z.B. per `EXISTS`/`JOIN`).

### System-Katalog-Queries verboten

`pg_tables`, `information_schema`, `pg_catalog` und andere PostgreSQL-System-Katalog-Tabellen dürfen in tomedo HQL **NIEMALS** abgefragt werden. Sie verursachen einen sofortigen Absturz der tomedo-Anwendung mit Datenbankfehler und erfordern ein Neuladen der lokalen Datenbank. Für Tabellen-/Spaltenexploration stattdessen explorative Queries gegen die bekannten Tabellen verwenden oder im Zollsoft-Datenmodell-Dump nachschlagen.

### tomedo-Serializer: TIME-Spalten (Typ 92) brechen den Export

Ein `::time`-Wert im finalen SELECT fuehrt zum Abbruch mit
`Wie serialisieren?  Typ: 92  <spaltenname>` (= `java.sql.Types.TIME`).

Workaround — Tageszeit als Minuten seit Mitternacht rechnen und als Text bauen:

```sql
-- in der CTE:
(EXTRACT(HOUR FROM MIN(ts)) * 60 + EXTRACT(MINUTE FROM MIN(ts)))::int AS start_mod
-- im finalen SELECT:
LPAD((MIN(start_mod) / 60)::text, 2, '0') || ':' ||
  LPAD(MOD(MIN(start_mod), 60)::text, 2, '0')                          AS startzeit
```

Fallback (rein numerisch, garantiert serialisierbar): `ROUND((MIN(start_mod) / 60.0)::numeric, 2)` — Lesart 8.5 = 08:30.

Betrifft `::time`, nicht `::date` und nicht `timestamp` — die serialisieren normal.

### Unplausible Fehlerposition = abgeschnittenes Statement

`ERROR: syntax error at or near "GROUP", Position: 6` bei einer 100-Zeilen-Query ist **kein** Syntaxfehler. Position 6 kann nicht auf ein `GROUP BY` am Ende zeigen. In diesem Fall war das Statement beim Einfuegen in tomedo abgeschnitten worden und begann mitten in der Abfrage.

Regel: passt die gemeldete Position nicht zum gemeldeten Token, **erst die Vollstaendigkeit des eingefuegten Statements pruefen**, bevor Konstrukte verdaechtigt werden. Ich hatte stattdessen `ntile(3) OVER (...)` verdaechtigt und einen Workaround ohne Fensterfunktion gebaut — die Originalabfrage lief beim zweiten Versuch fehlerfrei. Fensterfunktionen sind in tomedo unproblematisch.

---

## B. PostgreSQL-Fallen

*Dialekt- und Typprobleme, die als Abbruch oder als stiller Zahlenfehler auftreten.*

### ::numeric Cast bei ROUND

`ROUND(double precision, n)` existiert in PostgreSQL nicht. Immer `::numeric` casten:
```sql
ROUND(value::numeric, 2)
-- oder direkt in Temp-Tabelle: END::numeric AS euro
```

### `percentile_cont()` braucht Cast vor `ROUND`

`percentile_cont()` liefert `double precision`:

```sql
ROUND((percentile_cont(0.5) WITHIN GROUP (ORDER BY x))::numeric, 1)
```

### GROUP BY ROLLUP wird nicht unterstützt

`GROUP BY ROLLUP(...)` (und analog `GROUPING SETS`, `CUBE`) wird von tomedos SQL-Schicht **nicht** durchgereicht — sie interpretiert `ROLLUP` als Funktionsaufruf und wirft `ERROR: function rollup(text) does not exist`. Für Zwischen-/Gesamtsummen stattdessen `UNION ALL`: Detailzeilen per `GROUP BY`, Summenzeile als zweiter SELECT ohne `GROUP BY` (mit Konstanten-Label als Gruppen-Spalte), beide über dieselbe CTE. `ORDER BY` per Spaltenposition (`ORDER BY 2 DESC`), da Alias-Bezug über die UNION-Grenze uneinheitlich aufgelöst wird.

### unknown-Typ bei string_agg ueber UNION-Literale

`ERROR: failed to find conversion function from unknown to text`

Ursache: Ein String-**Literal** in einem CTE bleibt untypisiert (`unknown`). Wird die Spalte per `UNION ALL` aus zwei solchen Literalen gebildet, bleibt der Typ `unknown` — beim direkten `SELECT` faellt das nicht auf, aber jede Funktion mit Typ-Auflösung (`string_agg`, `concat_ws`, Vergleiche) bricht ab.

```sql
-- BRICHT
WITH a AS (SELECT 'quelle_a' AS q FROM t1
           UNION ALL SELECT 'quelle_b' FROM t2)
SELECT string_agg(DISTINCT q, ' + ') FROM a;

-- KORREKT
WITH a AS (SELECT 'quelle_a'::text AS q FROM t1
           UNION ALL SELECT 'quelle_b'::text FROM t2)
```

**Regel:** Jedes konstante String-Literal, das als Spalte aus einem CTE/UNION herausgeht, mit `::text` casten. Gleiches Muster fuer `::integer` / `::boolean` bei NULL-Literalen (`NULL::integer AS typ`).

### Alias-Kollision: PostgreSQL ist case-insensitiv

Unquotierte Aliase werden in der FROM-Klausel case-insensitiv behandelt — `L` und `l` sind dieselbe Referenz.
In langen CTE-Ketten durchgängig **mehrzeichige, eindeutige Aliase** verwenden (`LST`, `KVS`, `PDR`).

### Dynamisches aktuelles Quartal & Alias-Kollision

- **Aktuelles Quartal ohne ZS/Datum:** `EXTRACT(QUARTER FROM CURRENT_DATE)::int`, `EXTRACT(YEAR FROM CURRENT_DATE)::int`, Quartalsende `(DATE_TRUNC('quarter', CURRENT_DATE) + INTERVAL '3 months')::date`. Zeitfenster „heute..Quartalsende": `T.beginn >= CURRENT_DATE AND T.beginn < q_ende_excl`. Ideal für selbst-aktualisierende Management-Cards.
- **Alias-Kollision (PostgreSQL/tomedo):** unquotierte Aliase sind case-insensitiv -> `zeitraum Z` und `zuschlag z` kollidieren im finalen FROM: `ERROR: table name "z" specified more than once`. Regel: in Multi-CTE-Joins eindeutige, mehrbuchstabige Aliase (`zr`, `zu`, `i`) vergeben.
- **30700-Prognose-Pattern:** Ist (distinkte abgerechnete Ziffer) + geplanter Zuschlag (distinkte Patienten ohne Ziffer, `NOT EXISTS` gegen die Ziffer-Menge). Übertragbar auf jede „einmal je Quartal"-Pauschale.

### Quartalsindex `qidx` — Projektstandard

Für quartalsübergreifende Sortierung, Differenzen und Lückenerkennung immer ein einziger Integer:

```sql
(EXTRACT(YEAR FROM datum)::int * 4 + CAST(to_char(datum, 'Q') AS int)) AS qidx
```

Jahr und Quartal getrennt zu sortieren bricht über die Jahresgrenze.

### Regex-Wortgrenze `\y` scheitert an Unterstrichen

`\y` behandelt `_` als Wortzeichen — in Kalender- und Listennamen der Form
`<Gruppe>_<Kürzel>_<Jahr>` findet `\y<Kürzel>\y` daher nichts. Explizite Trennerklasse verwenden:

```sql
name ~ ('(^|[ _./-])' || kuerzel || '([ _./-]|$)')
```

### LIKE und Backslash: Steuerzeichen nie per LIKE suchen

In PostgreSQL ist der Backslash das **Standard-Escape-Zeichen fuer LIKE**. `LIKE '%\par%'` degeneriert zu `%par%` und trifft „Sparkasse", „separat", „Apartment". Ebenso unbrauchbar: `LIKE '%{\rtf%'`.

Korrekt ueber `strpos` mit `chr()`-Aufbau:

```sql
strpos(txt, chr(92) || 'par')            > 0   -- \par
strpos(txt, chr(123) || chr(92) || 'rtf') > 0   -- {\rtf
```

### HTML-Erkennung: `%<%>%` ist untauglich

`LIKE '%<%>%'` trifft **E-Mail-Adressen in spitzen Klammern** (`<buchhaltung@...>`), also jede Signatur — gemessene „100 % HTML" waren dadurch bedeutungslos. Echte Tags per Regex pruefen:

```sql
txt ~* '<[[:space:]]*(br|p|div|span|table|tr|td|font|html|body|head|style|img|a[[:space:]]|/)'
```

Zusaetzlich Entities (`&nbsp;`, `&amp;`) und zur Gegenprobe das Adressmuster `<[^<>[:space:]]+@[^<>[:space:]]+>` separat zaehlen.

---

### Idents sind 58 Bit breit — `::text` fuer jeden externen Konsumenten

`termin.ident` und `karteieintrag.ident` folgen `zeitstempel << 19` und sind 58 Bit breit.
Jeder Konsument mit IEEE-754-Double (JavaScript, `float()` in Python, viele BI-Werkzeuge) hat
53 Bit Mantisse und rundet. **Deshalb in jeder Query, deren Ergebnis ein Werkzeug weiterliest
oder verlinkt, `T.ident::text` ausgeben** — nicht nur wegen des Metabase-Link-Dropdowns.

Die Falle schlaegt **heute noch nicht** zu: durch die 19 Nullbits am Ende sind die aktuellen
Idents *zufaellig* exakt darstellbar. Der Fehler wird erst mit einer geaenderten Ident-Vergabe
sichtbar, und dann als Folgefehler an ganz anderer Stelle. `patient.ident` (27 Bit) ist
unkritisch. Konsumentenseitig: `int(str(wert))`, nie `int(float(wert))`.

## C. Datenmodell-Fallen: Pfade, Bridges, Geldwerte

*Falsche Pfade und Aggregationen. Häufigste Ursache für Prozente >100 % und für leere Ergebnisse.*

### Jahresscharfer Diagnose-JOIN

Wenn Diagnosen auf eine Patientenpopulation mit Jahresspalte gejoint werden, MUSS der JOIN auf **beide** Spalten erfolgen:
```sql
-- RICHTIG:
JOIN tempPat30700 T ON T.patientID = P.ident AND T.jahr = S.jahr
-- FALSCH (>100%-Bug):
WHERE P.ident IN (SELECT patientID FROM tempPat30700)
```

### 2-Stufen EBM-Euro-Aggregation

`MAX(DET.euroWertInCent)` in `SUM()` funktioniert nicht in einer Stufe wegen Bridge-Duplikaten. Pattern: Stufe 1 = Euro pro Leistung (GROUP BY A.ident), Stufe 2 = SUM pro Patient. Siehe `references/query-bausteine.md` §21.

### Geldwerte: `eurowertincent`, nicht `eurowertahincent`

`leistung.eurowertahincent` existiert an der Referenzinstallation **nicht** — korrektes Feld ist `eurowertincent`.
GOÄ-Eurobetrag pro Leistungszeile:

```sql
kostenincent::numeric * anzahl / GREATEST(COALESCE(anzahlnenner, 1), 1) / 100
```

`GREATEST(COALESCE(...,1),1)` ist Pflicht: `anzahlnenner` ist teils NULL, teils 0 — sonst Division durch Null.

### EBM-Codes tragen nichtnumerische Suffixe

Codes wie `35176H` verschwinden still bei `code IN ('35176', ...)`. Robust immer über den numerischen Stamm:

```sql
substring(code from '^[0-9]+') IN ('35173','35176','35225')
```

### Patientenliste ≠ Patientengruppe

Die in tomedo unter **Panel → Patientenliste** sichtbaren manuellen Listen (Wartelisten, Gruppentherapie-Teilnehmer, Arbeitslisten) stecken in `patientenschlange` + `patientenschlangeelement` (Bridge: `patientenschlange_schlange`). NICHT in `patientengruppe` — das ist ein separates Abrechnungsgruppen-Feature. Filter für manuelle Listen: `PS.dtype = 'Patientenschlange'`.

### Gruppenpsychotherapie & Patientenschlange (Lessons)

- **EBM-H-Suffix:** Grundversorgungs-/Probatorik-Gruppencodes treten mit Suffix auf (`35176H`). Exaktes `IN ('35176',…)` verfehlt sie → auf führende Ziffern matchen: `substring(B.code from '^[0-9]+') IN (...)`.
- **Gruppen-Code-Set (Tier 1 = „Sitzung abgerechnet"):** Probatorik-Gruppe `3516x` (letzte Ziffer = TN), Grundversorgung `3517x`, KZT-VT-Gruppe `3554x` (+ Zuschlag `3559x`). Tier 2 (Vorphase, NICHT zählen): 35140/41/50/51/52, 35600. Ausschluss Einzel: 35421, 35591. Referenz: `EBM-Gruppenpsychotherapie-Codeset.md`.
- **Regex-Wortgrenze `\y` scheitert am Unterstrich** (Underscore ist ein Wortzeichen) → für Kürzel-Parse aus Freitext explizite Trennklasse: `~* '(^|[ _./-])ruw([ _./-]|$)'`.
- **Datum aus Freitext-Namen:** `substring(name from '\d{1,2}\.\d{1,2}\.\d{2,4}')` + `to_date(...,'DD.MM.YY'|'DD.MM.YYYY')`; fehlendes Jahr aus `element.datum` ergänzen.
- **Leiterzuordnung von Gruppen:** `termin.behandler` ist bei Gruppenterminen leer (0%), `termin.dokumentierendernutzer_ident` = Anleger/MFA (nicht Leiter). Kalender-Parallel-Slot ist Artefakt (freie-Zeit statt Leitung). **Verlässliche Leiterquelle = `patientenschlange.name`.**

### Patientenformulare (arzt-direct)

Antworten in `formularelement` (bezeichner=Feldname, wert=Antwort), NICHT in CustomKarteiEintragEntry. Pfad: angefordertesjsonformular → karteieintrag (dtype=Formular, KE-Typ FOR) → karteieintrag_formularelemente → formularelement.

### PatF-Zählung: kein JOIN zu karteieintragtyp nötig

Für die Zählung von arzt-direct-Formular-Rückschrieben reichen drei Filter auf `karteieintrag` selbst, der JOIN zu `karteieintragtyp` ist überflüssig und war in Q-PatF-Count v1 die Fehlerursache (`typ_ident` existiert nicht — korrekter Spaltenname wäre `karteieintragtyp_ident`, aber selbst der wird hier nicht gebraucht).

**Minimalpattern:**

```sql
FROM karteieintrag k
JOIN formulartyp ft ON ft.ident = k.formulartyp_ident
WHERE k.visible        = true
  AND k.dtype          = 'Formular'
  AND k.jsonformsource = 1                       -- arzt-direct-Rückschrieb
  AND ft.name         LIKE 'Patientenformular_%' -- nur PatF
```

**Zusatzbeobachtung:** `k.dokumentierendernutzer_ident` ist bei arzt-direct-Rückschrieben systematisch `NULL` (Aggregation liefert `versender = 0`). Das ist kein Datenfehler, sondern Architektur: der Patient ist „Autor", kein tomedo-Nutzer hat den Eintrag dokumentiert. Nicht als Filter verwenden.

### `formulartyp`-Filter: idents vorauflösen, nie `LIKE` im JOIN

Ein `formulartyp.name LIKE '...'` im JOIN gegen `karteieintrag` kostet mehrere Minuten Laufzeit. Stattdessen die
idents in einem CTE vorauflösen und mit `IN` filtern:

```sql
WITH ft AS (SELECT ident FROM formulartyp WHERE name LIKE 'Patientenformular_%')
SELECT ... FROM karteieintrag k WHERE k.formulartyp_ident IN (SELECT ident FROM ft)
```

### Textanalysen auf karteieintrag: Basistabelle, nicht View

**Die View `karteieintragwithplaintext` hat nur 15 Spalten**, die Basistabelle rund 40. `datenmodell.md` fuehrt beide unter einer gemeinsamen Ueberschrift mit **einer** Spaltenliste — die Liste gehoert zur Basistabelle. Wer sie auf die View bezieht, laeuft in `ERROR: column ... does not exist`. Gegenprobe: der DB-Dump nennt fuer die View explizit „15 Spalten".

**`karteieintrag.serveronlyplaintext` ist praktisch unbrauchbar.** Das Feld existiert auf der Basistabelle, ist aber im **aeusseren SELECT nicht projizierbar** (`ERROR: column k.serveronlyplaintext does not exist`, Position zeigt auf die Projektion). Innerhalb eines CTE funktioniert es. Passend zum Namen „serveronly". Regel: gar nicht verwenden, Nutzlast steht in `karteieintrag.text`.

---

## D. Epochen und Feldrealität der Referenzinstallation

*Welche Felder ab wann befüllt sind. Ein Feld im DB-Dump ist keine Zusage, dass Daten drinstehen.*

### Termin-Tabelle erst ab Nov 2025

Die Termin-Tabelle (`termin`) ist erst seit der tomedo-Migration (November 2025) befüllt. Alle historischen Aktivitätsanalysen müssen über EBM-Leistungen und KV-Scheine laufen.

### Sperrtage: terminkalendertag statt Dauer-Heuristik

Ganztags-Sperren (Urlaub, Krank, Feiertag, Teamtag, Elternzeit) liegen ab Migration in `terminkalendertag.sperrmodus = 1`, **nicht** als 300-min-Blocker-Termin. Die alte Heuristik (`patient_ident IS NULL` + Dauer ≥300 min) findet moderne Sperren nicht und ist nur fuer Pre-Migrations-Epochen zu verwenden.

Zwei Fallen:
- **`terminkalendertag` hat eine Zeile pro Kalender × Tag, auch fuer freie Tage** (`sperrmodus=0`, `info='serverseitig'`). Ohne `sperrmodus = 1` matcht jeder Tag.
- **Die Tabelle fehlt in `datenmodell.md`-Altversionen** und stand nur im ZOLLSOFT-DB-Dump. Bei „Feld/Tabelle nicht gefunden" immer gegen `datenmodell_ZOLLSOFT_DB-dump.md` gegenpruefen.

Sperrgrund kommt aus `kalendersperrmodus.name`, Feiertag/Abwesenheit trennt `kalendersperrmodus.isfeiertag`.

### Bearbeitungszeitpunkte existieren an der Referenzinstallation nicht

tomedo protokolliert an der Referenzinstallation **nur Anlagezeitpunkte, keine Bearbeitungszeitpunkte**. Zwei Felder, die das leisten sollten, sind leer — beide 2026-07-29 auf Echtdaten validiert:

- **`karteieintrag.letzteaenderungam` = NULL, ausnahmslos.** Geprueft an 1.024/1.024 Zeilen. Das Feld ist in `datenmodell.md` als „Letzte Aenderung (fuer Dokumentationsanalysen)" beschrieben — fuer die Referenzinstallation ist das **falsifiziert**. Nie als Zeitachse verwenden.
- **`karteieintrag.druckdatum` = NULL bei 616/617** bearbeiteten Eintraegen (RECHN, MAIL-Ein, NACHR, ABR-ALT, DIA). Einziger Treffer: 1 MED-Eintrag. Als Erzeugungs-Proxy unbrauchbar.

**Konsequenz fuer Nutzer-Aktivitaetsanalysen:** Eintraege, bei denen ein Nutzer nur `letzternutzer_ident` ist (nicht `dokumentierendernutzer_ident`), sind **zeitlich nicht verortbar**. Man weiss *dass*, nicht *wann*. Bei rechnungsnahen Rollen betrifft das die Kerntaetigkeit — jede Arbeitszeitschaetzung ist dadurch systematisch nach unten verzerrt.

**Zeitachse quellenspezifisch waehlen, nicht einheitlich `datum`:**

| Rolle des Nutzers am KE | Korrekte Zeitachse | Warum |
|---|---|---|
| `dokumentierendernutzer_ident` | `karteieintrag.datum` | Anlagezeitpunkt, traegt echte Uhrzeit |
| `letzternutzer_ident` (nur bearbeitet) | keine verfuegbar | `datum` waere das Rechnungs-/Dokumentdatum, nicht die Bearbeitung |

### Medikamentenverordnung: strukturierte Felder nur Post-Migration

Die strukturierten Felder von `medikamentenverordnung` sind ein **Post-Migrations-Artefakt** (ab Nov 2025):
- `avpbeiverordnung` > 0: nur ~34 % (2023–25), 82 % (2026).
- `wirkstaerkebeiverordnung`, `mengebeiverordnung`, `atcbeiverordnung`: ~0 % (2023/24), ~5 % (2025), ~82 % (2026).
- `pzn`: nur ~16–20 % historisch. `wirkstoffnamebeiverordnung`: ~5 %.
- **`namebeiverordnung`: 98–100 % über alle Jahre** → einziger historisch tragfähiger Medikamenten-Schlüssel.

**Konsequenz für Within-Patient-Historie:** rohe AVP/MME über die Migrationsgrenze = Confound.
Pattern **standardisierte Kosten/MME**: Referenzwert je Wirkstoff aus Post-Migration (Median) ×
historische Menge; Wirkstoff-Klassifikation via kuratierter `CASE` auf `lower(namebeiverordnung)`.
Opioid-Detektion historisch über Freitext-Namensmuster (nicht ATC).

**Feld-Korrektur:** `wirkstaerkebeiverordnung` existiert (DB-Dump), fehlt aber in `datenmodell.md` →
DB-Dump ist maßgeblich.

**TEXT-Parser (robust genug für Median):** Stärke `substring(feld from '[0-9]+[.,]?[0-9]*')` + Komma→Punkt;
Menge `substring(feld from '[0-9]+')`, Packungscodes via `trim(feld) ~* '^n[0-9]'` verwerfen.

### Freie Kapazität (forward-looking) — keine Dienstplan-Tabelle

„Freie Stunden / Lücken im Arbeitstag" hat in tomedo **keine eigene Dienstplan-/Sprechzeiten-Tabelle**. Die verfügbare Zeit *sind* die Ressourcen-Termine (`terminart.infotermin=true` / `typ=1`). Rechnung: **freie Minuten = Ressourcen-Minuten − belegte Patientenminuten**, pro (Arzt × Ressource). Forward-looking-Variante von §18 (Auslastung):

- **Fenster vorwärts:** `T.beginn >= CURRENT_DATE AND T.beginn < DATE 'Quartalsende+1'` (statt `< CURRENT_DATE` wie bei No-Show §30).
- **Zukunfts-Sperrzeiten weiterhin abziehen** (§17): Urlaub/Feiertag liegt als Sperrzeit *über* dem bestehenden Ressourcenblock — sonst erscheinen Urlaubstage als „frei".
- **Schlüssel-Alignment (zentrale Falle):** Belegung VOR der Subtraktion über `terminart.terminresourceverbindung_ident` auf die Ressource zurückführen. Mehrere Buchungs-Terminarten zeigen auf eine Ressource (real: `G`,`WV`,`Gespr`,`NTWeichteil` → `SprSt`). Naives Gruppieren beider Seiten nach Kürzel ⇒ Key-Mismatch ⇒ falsche Differenz.
- **Ressource nie über Kürzel filtern:** Paar-Terminarten mit identischem Kürzel existieren (z.B. `AP` als Ressource *und* buchbar). Ressource = `infotermin=true`/`typ=1`.
- **Gruppentherapie-Raumkalender ausschließen** (`kalender.nutzer_ident IS NULL`): 1-Min-Slot-Workaround macht Minuten-Differenz sinnlos (>100% Auslastung systembedingt).
- **Anonym by design:** Auswertung braucht keine Patientenidentität — `patient_ident` nur als `IS NOT NULL`-Flag für „belegt".

### Aufgaben-System (aufgabe-Tabelle): oeffentlich/offen sauber filtern

Die `aufgabe`-Tabelle (Mitarbeiter-Aufgaben/Tickets) hat zwei undokumentierte, aber praxisrelevante Steuerfelder — beide 2026-06-19 per Echtdaten + Abhaken-Test validiert:

- `availability`: **0 = oeffentlich** (Checkbox im Dialog), **1 = persoenlich**, NULL = System-Vorlage. Klarer 31/69-Split (kein Default-Rauschen).
- `status`: **NULL = offen**, **1 = erledigt** (Abhaken setzt NULL->1, protokolliert in `laststatuschange` + Log „Offen->Fertig").
- `erdedigungstyp`: 0 = von einem, 1 = von allen.

**Achtung Datenqualitaet:** `availability=0` enthaelt viel operatives Rauschen (leere Titel, „neue Vorlage", „Aufgabe aus Nachricht", „Bitte Arztbrief…", „Physio Vo erstellen…"). Fuer eine saubere Agenda zusaetzlich `TRIM(aufgabentitle) <> ''` und ggf. Titel-Blacklist setzen.

**Verantwortliche-JOIN** (Kuerzel): `aufgabe -> aufgabe_verantwortliche(aufgabe_ident) -> verantwortliche_ident -> aufgabenempfaenger -> nutzer.kuerzel`. Mehrere Verantwortliche per `string_agg(DISTINCT NV.kuerzel, ', ')`.

**Agenda-Rezeptur (Q-AUFGABE-AGENDA-01):**
```sql
WHERE A.removed = false
  AND A.availability = 0          -- oeffentlich
  AND A.status IS NULL            -- offen
  AND COALESCE(A.archivedinkartei,false) = false
  AND TRIM(A.aufgabentitle) <> ''
ORDER BY A.priority DESC, A.erstelltam DESC   -- priority hoeher = wichtiger
```

### Aktivitaets-Sessionisierung: Dichte-Untergrenze beachten

Sessionisierung von Nutzer-Events (Gap-Schwelle bricht Session) ist nur ab **~9 Events pro aktivem Tag** belastbar. Darunter kollabiert das Modell: bei 5–8 Events/Tag erreicht das Verhaeltnis Tages-Span zu Session-Netto Faktoren bis **15,8** (gemessen: 6 aktive Tage, 20 Events, 2,2 h Session gegen 34,8 h Span). Bei 21 Events/Tag sinkt das Verhaeltnis auf 2,2.

Praxisregel: Monate mit <9 Events/aktivem Tag im Ergebnis als „nicht belastbar" markieren, nicht wegrechnen.

Gap-Schwelle **nicht** auf einen Wert festlegen — Sensitivitaet 30/45/60/90 min mitfuehren. Die Untergrenze variiert dadurch um Faktor 1,7. Engste Konvergenz von Session und Span (und damit realistischste Untergrenze) lag bei G=90.

### Nützliche neue Felder (Zollsoft 03/2026)

- `termin.isneuerpatient` (boolean) — Neupatient-Flag, relevant für Wartezeit-Analyse
- `termin.angelegt` (timestamp) — Erstellungszeitpunkt, für Vorlaufzeit-Analyse
- `nutzer.asrenabled` (boolean) — Spracherkennung aktiviert
- `nutzer.lanr` (text) — LANR direkt auf Nutzer
- `nutzer.leistungserbringer` (boolean) — Ist abrechnungsberechtigter Arzt
- `nutzer.psychotherapiequalifikation_ident` → psychotherapiequalifikation
- `patientendetails.statuspsychotherapiefall` (0/1/5/10) — PT-Fall-Status
- `patientendetails.datumletzterbesuch` (timestamp) — Letzter Besuch
- `patientendetails.beschaeftigungsstatus_ident` → beschaeftigungsstatus (Erwerbsstatus)
- `terminart.typ` (0=Termin, 1=Ressource, 2=Sperrbereich, 3=Ganztagsart) — differenzierter als infotermin
- `terminart.laenge` (integer) — Standard-Terminlänge in Minuten
- `medikamentenverordnung.dokumentierendernutzer_ident` → Verordner
- `besuch.ankunft`/`besuch.ende` (timestamp) — Für Wartezeitanalysen
- ⛔ `karteieintrag.letzteaenderungam` / `.druckdatum` — **an der Referenzinstallation leer** (1024/1024 bzw. 616/617 NULL, gemessen 07/2026).
  tomedo protokolliert keine Bearbeitungszeitpunkte. Dokumentationszeit nur über Sessionisierung von `datum` (query-bausteine §35).

---

## E. Fachliche Marker, Codes und Auswahlregeln

*Wie eine Fragestellung korrekt auf Codes, Kürzel und Kalender abgebildet wird.*

### Echter Behandler ≠ Abrechnungsarzt

`leistungserbringer_ident` auf EBM-Leistungen ist der **Abrechnungsarzt**, nicht der behandelnde Arzt. Bis zu 500 Fälle werden wegen KV-Fallzahllimit und Fachgebietsregeln umgeschichtet.

**Echter Behandler** über Karteieintragstyp + `dokumentierenderNutzer_ident`:
- `<TYP-A>` — Alt-Typ, endet mit der Umstellung
- `<TYP-B>` — Nachfolger, ab Umstellung aktiv
- `<TYP-C>` — Paralleltyp, kleiner Bestand

Alle kombinieren, sonst fehlt der Umstellungszeitraum; die eigenen Kürzel vorab ermitteln
(siehe `datenmodell.md`, Abschnitt Therapiezeilen-Kürzel). `arzt_ident` ist bei allen = 0.

**Zwei Ausnahmen, in denen direkt attribuiert werden darf:**
- **GOÄ:** `leistung.leistungserbringer_ident` ist sauber — kein KV-Fallzahllimit, also keine Umschichtung.
- **Psycho-EBM (35xxx / 232xx):** `leistung.dokumentierendernutzer_ident` ist direkt valide, weil PT ihre Sitzungen
  selbst dokumentieren und die Codes rechtlich an die Approbation gebunden sind.

### Code-Discovery empirisch, nicht per Keyword

Keyword-Codesets sind systematisch unvollständig. Im B72-Thread fehlte der dominierende spinale Eingriff
(GOÄ **469**, Kaudalanästhesie), weil das Kürzel nichts über den Text verrät. **Regel:** erst die eigenen
Abrechnungsdaten nach Häufigkeit gruppieren (query-bausteine §22 GOÄ-Explorer), dann das Codeset festlegen.
Eigene Abrechnungsdaten schlagen jede Keyword-Heuristik.

### KH-Einweisung: Freitext-Detektor vs. Formular

Für die praxisseitig veranlasste KH-Einweisung gibt es zwei Signale mit klarer Rollenteilung:

- **Muster-2-Formular** (`formulartyp='Krankenhausbehandlung'`) = belastbar, aber erst ab Sep 2025.
- **Freitext Therapiezeile** (die praxiseigenen Therapiezeilen-Typen, Term `%einweis%`/`%eingewiesen%`) = das saubere „wir haben eingewiesen"-Signal, migrationsübergreifend ab 2019. **Negationsrate nur ~1,9 %** (48/2.534 KE) — praktisch frei von „keine Einweisung".

**Nicht** als Detektor verwenden:
- `%krankenhaus%` / `%klinik%` im Freitext — dominiert von False Positives (Anamnese-Historie, verneinte/geplante Fälle, Klinik-Namen in Briefköpfen, eingehende Briefe). In `ANA` (Anamnese, ~9.000 Treffer) und `PSY` (Journal) sitzt fast nur Rauschen → ausschließen.
- KE-Typ `KRH` = eingehende Klinikpost, nicht eigene Einweisung.

**Kalibrierung:** Recall der Therapiezeile gegen das Muster-2-Formular (Overlap ab Sep 2025) = **46 %** (188/406). Historische Rohzahlen sind damit eine **Untergrenze**; der Recall lag vor der Migration vermutlich höher (Therapiezeile oft einziger Dokumentationsort). Korrektur-Korridor bis ~×2,16.

**Zeittrend-Falle:** Freitext-basierte Jahres-Serien steigen mit der Dokumentationsdichte — der Anstieg ist ein Artefakt, kein realer Ereignisanstieg. Nur den Gradient zwischen Gruppen interpretieren, nicht die Trajektorie.

### MPSS: `%Chronifizierung%` ist kein Suchkriterium

`text ILIKE '%Chronifizierung%'` matcht Basisgruppen-Textbausteine und produziert Falsch-Positive.
Für das Mainzer Stadienmodell nur `%MPSS%` und `%Gerbershagen%` (PSY-Freitext 04/2024–10/2025, Regex-Trefferquote
99,7 %) bzw. CKEE `name='MPSS'` (ab ~11/2025).

### AU-Formulare erkennen

```sql
formulartyp.name IN ('AU', 'FortbestehenAU', 'PrivateAU')
```
Ergibt nur **eigene** AUs — Untergrenze.

### Administrative Codes ohne Patientenkontakt

40110 (Versandmaterial), 86901 (Labor-Kostenpauschale) — bei WV-Zählung oder Kontaktzählung ausschließen.

### GOÄ-Quartal aus Datum ableiten

GOÄ-Leistungen haben kein `kvschein.quartal`:
```sql
CAST(to_char(A.datum, 'Q') AS integer) AS quartal
```

### Outlook- und Raumkalender ausschließen

~3.967 importierte Outlook-Termine verfälschen jede Kapazitäts- und Behandlerauswertung.
Therapeutenkalender: `K.nutzer_ident IS NOT NULL`. Raum-/Gruppenkalender (`NULL`) nur bewusst für
Gruppenanalysen zuschalten.

### Verstorbene Patienten ausschließen

```sql
AND P.nachname NOT ILIKE '%†'
```

### TRIM bei Terminart-Kürzel

Terminart-Kürzel haben teils trailing Spaces. Bei Vergleichen immer:
```sql
TRIM(TA.kuerzel) IN ('AP', 'Bespr-Ä', ...)
```

### Satzzaehlung in Rechnungs- und Abrechnungstexten

Satzenden ueber `[.!?]` zu zaehlen ist bei kaufmaennischen Texten **grob dreifach ueberhoeht**. Ursachen: Datumsangaben (`07.07.2026` = zwei Scheingrenzen), Betraege (`1.234,56`), Abkuerzungen (`Nr.`, `z.B.`, `ggf.`, `zzgl.`, `inkl.`).

Belegt an einem realistischen Satz mit Rechnungsnummer, Datum und Betrag: **7 Satzenden ohne Maskierung, 2 mit.** Gemessene Satzlaengen von 5,4 und 8,5 Woertern waren dadurch unplausibel; nach Korrektur 9,0 bis 17,6.

Maskierungskette **nur fuer die Zaehlfassung**, nicht fuer den Analysetext:

```sql
regexp_replace(
  regexp_replace(
    regexp_replace(txt, '([0-9])\.', '\1', 'g'),          -- Punkt nach Ziffer
    '(Nr|z\.B|zB|ggf|bzw|zzgl|inkl|ca|evtl|Dr|Tel|Abs|Str|u\.a|d\.h)\.', '\1', 'gi'),
  '\.\.+', '.', 'g')
```

Kontrolle: bleibt die Satzlaenge unter 8 Woertern, ist die Abkuerzungsliste unvollstaendig. Zeichen, Woerter, Wortlaenge und Absatzzahl duerfen sich durch die Maskierung **nicht** aendern — sonst lief sie faelschlich auf dem Analysetext.

### DATE-ZS-Filter: kein Semikolon

Bei DATE-Typ ZS-Filtern kein trailing Semikolon im Default-Wert.

---

## F. Praxis-Codetabellen (lokal)

Dekodierte Hauscodes stehen in keinem Herstellerkatalog: eigene GOÄ-Ziffern, Terminarten,
Kalendersperrmodi, Gruppenlisten-Namensschemata. Sie sind **je Praxis verschieden** und
gehören deshalb nicht in ein Referenzkorpus, sondern in eine lokale Datei.

**Vorgehen:** eigene Codes einmal dekodieren und als `references/praxis-lokal.md` neben diesen
Skill legen. Einstieg über die tatsächlich abgerechneten Ziffern statt über den Katalog:

```sql
SELECT g.ziffer, count(*) AS anzahl, round(avg(g.eurowertincent)/100.0, 2) AS eurowert_avg
FROM goaeleistung g
WHERE g.ziffer !~ '^[0-9]{3,5}$'      -- alles, was keine regulaere GOAe-Ziffer ist
GROUP BY g.ziffer
ORDER BY anzahl DESC;
```

Was dabei herauskommt — Bedeutung, Honorar, wer die Ziffer nutzt — ist Praxiswissen und bleibt
lokal. Eine Zuordnung „Ziffer gehört zu Behandler X" sollte dort nur stehen, wenn sie
abrechnungstechnisch nötig ist; als Analysemerkmal genügt die Ziffer.
