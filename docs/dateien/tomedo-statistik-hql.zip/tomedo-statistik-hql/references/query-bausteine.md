# Query-Bausteine (v10) — Bewährte Patterns

> **Geltungsbereich der Feldbefunde.** Aussagen der Form „an der Referenzinstallation leer",
> „nicht gepflegt" oder „X von Y NULL" beschreiben **eine** produktive tomedo-Installation zum
> genannten Zeitpunkt. Sie sind ein Hinweis darauf, dass ein Feld unzuverlässig sein *kann* —
> keine Eigenschaft von tomedo. Vor Verwendung in der eigenen Praxis nachmessen:
> `SELECT count(*) AS zeilen, count(feld) AS befuellt FROM tabelle;`


## CHANGELOG
- v10 (2026-08-04): Struktur-Refactoring — Lessons Learned aus SKILL.md nach `references/lessons-learned.md` ausgelagert; SKILL.md enthaelt nur noch Verbote und Lese-Routing.
- v9 (2026-08-04): 34 offene Delta-Bloecke aus 11 Threads eingearbeitet (terminkalendertag/Sperrquelle, aufgabe, Reassessment, Sessionisierung, Lesbarkeitsmetriken, Leistungsmenge, KH-Einweisung, Gruppen-PT) + Memory-Korrekturen: vier falsche Direkt-Pfade, eurowertahincent, letzteaenderungam/druckdatum-NULL-Realitaet, NULL-sicherer Privatrechnungsfilter.
- v8 (2026-04-27): + § 29 Formular-Karteieintrag-Dual-Bridge, + § 32 mutabo-Detection, + § 33 PatF-Zählung-Minimal-Pattern (von SKILL→hierhin geroutet), Cleanup: Duplikat-§20–§22-Block entfernt

> Stand: 16.04.2026 · Neu ggü. v6: §20 Quartals-Segmentierung, §21 Haupttherapeut-Ermittlung, §22 Jahresübergangs-Analyse, §29 Hauptbehandler via 30700-Häufigkeit, §30 No-Show-Basistabelle, §31 EBM-Euro pro Terminart.

## 1. EBM-Euro-Berechnung (mit Gültigkeits-JOIN)

```sql
LEFT JOIN ebmKatalogEintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
```

Euro-Berechnung:
```sql
(CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
      THEN (A.anzahl * DET.euroWertInCent) / 100.0
      ELSE (A.anzahl * A.prozentDerLeistung5013 * DET.euroWertInCent) / 10000.00
END)::numeric::money AS euro
```

Punktwert-Berechnung:
```sql
CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
     THEN A.anzahl * DET.punktwert
     ELSE (A.anzahl * A.prozentDerLeistung5013 * DET.punktwert) / 100.00
END AS punkte
```

Bei GROUP BY A.ident: `max(...)` um alle Werte wrappen (wegen möglicher Duplikate bei Details).

## 2. GOÄ-Euro-Berechnung (vereinfacht, ohne MwSt)

```sql
(A.kostenInCent * A.anzahl / 100.00)::numeric::money AS euro
```

Mit Teilleistungs-Divisor:
```sql
(A.kostenInCent * A.anzahl / GREATEST(COALESCE(A.anzahlNenner, 1.0), 1) / 100.00)::numeric::money AS euro
```

Besondere Kosten (bei typ=5):
```sql
(CASE WHEN B.typ = 5 THEN (A.anzahl * B.besonderekostenincent / 100.00) ELSE 0 END)::numeric::money AS besondere_kosten
```

## 3. Privatrechnungs-Standardfilter

```sql
WHERE
    A.dtype = 'GOAELeistung'
    AND I.visible = true
    AND A.visible = true
    AND COALESCE(PT.iskostenvoranschlag, false) = false
    AND NOT EXISTS (SELECT 1 FROM privatrechnungvorlage V WHERE V.vorlage_ident = I.ident)
```

⚠ **NULL-Sicherheit (Korrektur 2026-07):** `PT.iskostenvoranschlag = false` verliert alle Zeilen mit NULL
(kein Privatrechnungstyp gesetzt), und `NOT IN (subquery)` wird bei einem einzigen NULL in der Subquery
komplett unwahr — Ergebnis dann leer. Daher `COALESCE(...) = false` und `NOT EXISTS`. Der `privatrechnungtyp`
wird per `LEFT JOIN` angebunden: `LEFT JOIN privatrechnungtyp PT ON PT.ident = I.privatrechnungtyp_ident`.

## 4. EBM-Standardfilter

```sql
WHERE
    A.dtype = 'EBMLeistung'
    AND S.visible = true
    AND A.visible = true
    AND (S.ignoriertFuerAbrechnung IS NULL OR S.ignoriertFuerAbrechnung = false)
```

## 5. Termin-Dauer berechnen

```sql
ROUND((EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 3600.0)::numeric, 2) AS stunden
ROUND((EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 60.0)::numeric, 0) AS dauer_in_min
```
**Wichtig:** `ROUND(double precision, integer)` existiert in PostgreSQL nicht. Immer `::numeric` casten vor `ROUND()`.

## 6. Termin-Standardfilter

```sql
WHERE TA.infotermin = false
  AND (T.removed IS NULL OR T.removed = false)
```
**Hinweis:** `infotermin = false` filtert auf Patiententermine. `infotermin = true` sind Ressourcen/Kapazitätsblöcke (siehe §18).
**Hinweis:** Terminart-Kürzel haben teils trailing Spaces → bei Vergleichen immer `TRIM(TA.kuerzel)` verwenden.

## 7. Aktive Dauerdiagnosen

```sql
WHERE A.isddi = true
  AND A.visible = true
  AND (A.abgesetzt IS NULL OR A.abgesetzt < 1)
```

## 8. Karteieintragtyp-Lookup per Kürzel

```sql
ke.karteieintragtyp_ident = (SELECT ident FROM karteieintragtyp WHERE kuerzel = 'BES')
```

## 9. Zeitfenster-Aggregation (Umsatz pro Periode)

```sql
DROP TABLE IF EXISTS tempZeitfenster;
CREATE TEMP TABLE tempZeitfenster AS
SELECT DISTINCT date_trunc('month', datum) AS zeitfenster FROM tempLeistung;

DROP TABLE IF EXISTS tempSummen;
CREATE TEMP TABLE tempSummen AS
SELECT date_trunc('month', datum) AS zeitfenster, SUM(euro) AS summe
FROM tempLeistung
GROUP BY zeitfenster;

SELECT
    to_char(Z.zeitfenster, 'YYYY-MM') AS intervall,
    CAST(Z.zeitfenster AS date) AS startdatum,
    COALESCE(S.summe, '0'::numeric::money) AS summe
FROM tempZeitfenster Z
LEFT JOIN tempSummen S ON Z.zeitfenster = S.zeitfenster
ORDER BY startdatum;
```

## 10. NULL-sichere Vorfilterung (COALESCE-Pattern)

```sql
DROP TABLE IF EXISTS temp_nutzer;
CREATE TEMP TABLE temp_nutzer AS SELECT * FROM nutzer;
INSERT INTO temp_nutzer (ident) VALUES (0);

WHERE COALESCE(A.betriebsstaette_ident, 0) IN (SELECT ident FROM temp_betriebsstaette WHERE true)
```

## 11. Quartals-Berechnung aus Datum

```sql
CAST(to_char(datum, 'Q') AS integer) AS quartal
CAST(to_char(datum, 'YYYY') AS integer) AS jahr
to_char(datum, 'Q/YYYY') AS quartal_text
```

## 12. Arzt-Ermittlung bei Verordnungen (Fallback-Kette)

```sql
COALESCE(N3.kuerzel, N.kuerzel, N2.kuerzel) AS arzt
-- N3 = abweichender Verordner
-- N  = Arzt vom Karteieintrag
-- N2 = Arzt vom eRezept
```

## 13. ATC-Level-Parsing (Medikamente)

```sql
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 1) AS ATC_Level_1
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 3) AS ATC_Level_2
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 4) AS ATC_Level_3
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 5) AS ATC_Level_4
SUBSTRING(SUBSTRING(A.atcBeiVerordnung, 1, POSITION(' (' IN A.atcBeiVerordnung)-1), 1, 7) AS ATC_Level_5
```

## 14. IN/NOT IN für Mengenvergleiche

Pattern "hat X aber nicht Y":
```sql
WHERE P.ident IN (
    SELECT P.ident FROM karteieintrag ke
    JOIN patientendetailsrelationen_karteieintraege pdrke ON pdrke.karteieintraege_ident = ke.ident
    JOIN patientendetails pd ON pd.patientendetailsrelationen_ident = pdrke.patientendetailsrelationen_ident
    JOIN patient p ON p.patientendetails_ident = pd.ident
    WHERE ...
    GROUP BY P.ident
)
AND NOT P.ident IN (
    SELECT P.ident FROM ...
    WHERE ke.karteieintragtyp_ident = (SELECT ident FROM karteieintragtyp WHERE kuerzel = 'BES')
    GROUP BY P.ident
)
```

## 15. Empfänger-Aggregation (Nachrichten)

```sql
DROP TABLE IF EXISTS tempEmpfaenger;
CREATE TEMPORARY TABLE tempEmpfaenger AS
SELECT A.nachrichten_ident,
       ARRAY_TO_STRING(array_agg(ARRAY_TO_STRING(ARRAY[D.kuerzel, E.name], ' ')), ' ') AS empfaenger
FROM tempNachrichten A
JOIN Nachricht_empfaenger B ON A.nachrichten_ident = B.nachricht_ident
LEFT JOIN Nachrichtempfaenger C ON B.empfaenger_ident = C.ident
LEFT JOIN Nutzer D ON C.nutzer_ident = D.ident
LEFT JOIN Arbeitsplatz E ON C.arbeitsplatz_ident = E.ident
GROUP BY A.nachrichten_ident;
```

## 16. Selektivverträge eines Patienten aggregieren

```sql
DROP TABLE IF EXISTS tempSV;
CREATE TEMPORARY TABLE tempSV AS
SELECT A.patientID,
       ARRAY_TO_STRING(ARRAY_AGG(A.name), '; ') AS vertraege
FROM (
    SELECT HZVV.name, P.ident AS patientID
    FROM patient P
    JOIN patientendetails PD ON PD.ident = P.patientendetails_ident
    JOIN patientendetails_hzvDetails JT ON PD.ident = JT.patientendetails_ident
    JOIN hzvdetails HZVD ON JT.hzvdetails_ident = HZVD.ident
    LEFT JOIN hzvvertrag HZVV ON HZVD.hzvvertrag_ident = HZVV.ident
    WHERE HZVD.statusteilnahme = 2
      AND ((HZVD.statusFAVDirektaktivierung != 4 AND HZVD.statusFAVDirektaktivierung != 5)
           OR HZVD.statusFAVDirektaktivierung IS NULL)
    UNION ALL
    SELECT V.name, P.ident AS patientID
    FROM patient P
    JOIN patientendetails PD ON PD.ident = P.patientendetails_ident
    JOIN patientendetails_sonstigeSVTeilnahmen JT ON JT.patientendetails_ident = PD.ident
    JOIN svteilnahme T ON JT.sonstigeSVTeilnahmen_ident = T.ident
    LEFT JOIN selektivvertrag V ON V.ident = T.selektivvertrag_ident
    WHERE T.status = 2
) A
GROUP BY A.patientID;
```

## 17. Gesperrte Tage erkennen (Sperrzeiten)

Sperrzeiten sind Termine mit `infotermin=false`, `patient_ident IS NULL` und bestimmten Terminarten. Ein Tag gilt als gesperrt bei Dauer ≥300 Minuten.

```sql
DROP TABLE IF EXISTS tempGesperrteTage;
CREATE TEMPORARY TABLE tempGesperrteTage AS
SELECT DISTINCT
    kalenderID,
    tag
FROM tempTermine
WHERE infotermin = false
    AND patient_ident IS NULL
    AND terminart_kuerzel IN ('UNBEKANNT', 'Blocker', 'IMPORT_GANZTAG', 'Urlaub', 'Ü-Abbau')
    AND dauer_min >= 300
;
```

Anwendung: Per `LEFT JOIN` und `IS NULL` gesperrte Tage aus Kapazitätsberechnung ausschließen:
```sql
FROM tempTermine A
LEFT JOIN tempGesperrteTage G ON A.kalenderID = G.kalenderID AND A.tag = G.tag
WHERE ...
    AND G.kalenderID IS NULL
```

Zwei Varianten, je nach Epoche. **Variante A ist ab Migration (Nov 2025) die Leitquelle.**

### Variante A (Primaer, ab Migration) — terminkalendertag

```sql
DROP TABLE IF EXISTS tempGesperrteTage;
CREATE TEMPORARY TABLE tempGesperrteTage AS
SELECT
    TKT.kalender_ident      AS kalenderID,
    TKT.tag::date           AS tag,
    KSM.name                AS sperrgrund,
    KSM.isfeiertag          AS ist_feiertag
FROM terminkalendertag TKT
JOIN kalendersperrmodus KSM ON KSM.ident = TKT.kalendersperrmodus_ident
WHERE TKT.removed = false
    AND TKT.sperrmodus = 1          -- PFLICHT: Tabelle enthaelt auch freie Tage
;
```

`TKT.beginn IS NULL` = Ganztags-Sperre (Normalfall). Gefuellte `beginn`/`ende` = Teilsperre → Zeitueberlappung pruefen statt Tagesgleichheit.

### Variante B (Alt-Pfad, Pre-Migration) — Blocker-Termine

```sql
SELECT DISTINCT kalenderID, tag
FROM tempTermine
WHERE infotermin = false
    AND patient_ident IS NULL
    AND terminart_kuerzel IN ('UNBEKANNT','Blocker','IMPORT_GANZTAG','Urlaub','Ü-Abbau')
    AND dauer_min >= 300
;
```

### Anwendung: gesperrte Tage aus der Kapazitaet ausschliessen

```sql
FROM tempTermine A
LEFT JOIN tempGesperrteTage G ON A.kalenderID = G.kalenderID AND A.tag = G.tag
WHERE ...
    AND G.kalenderID IS NULL
```

### §17a — Konflikt: Sperrtag UND Patiententermin

Umkehrung des LEFT JOIN. tomedo raeumt bestehende Termine beim Sperren **nicht** auf, Serientermine bleiben stehen. Ein `INNER JOIN` statt Ausschluss liefert die Aufraeumliste:

```sql
SELECT
    TKT.tag::date                                       AS sperrtag,
    K.name                                              AS kalender,
    TRIM(N.kuerzel)                                     AS nutzer_kuerzel,
    KSM.name                                            AS sperrgrund,
    KSM.isfeiertag                                      AS ist_feiertag,
    T.ident                                             AS terminID,
    T.beginn                                            AS termin_beginn,
    (EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 60)::int  AS dauer_min,
    TRIM(TA.kuerzel)                                    AS terminart,
    T.patient_ident                                     AS patientID
FROM terminkalendertag TKT
JOIN kalender           K   ON K.ident   = TKT.kalender_ident
JOIN kalendersperrmodus KSM ON KSM.ident = TKT.kalendersperrmodus_ident
LEFT JOIN nutzer        N   ON N.ident   = K.nutzer_ident
JOIN termin_kalender    TK  ON TK.kalender_ident = K.ident
JOIN termin             T   ON T.ident   = TK.termin_ident
JOIN terminart          TA  ON TA.ident  = T.terminart_ident
WHERE TKT.removed   = false
    AND TKT.sperrmodus = 1
    AND T.removed     = false
    AND T.patient_ident IS NOT NULL     -- nur echter Patientenbezug
    AND TA.infotermin = false           -- keine Ressourcenbloecke
    AND T.beginn::date = TKT.tag::date
    AND TKT.tag >= CURRENT_DATE         -- nur offene Konflikte
    AND K.visible = true
    AND K.name NOT ILIKE 'Outlook%'
ORDER BY TKT.tag, K.name, T.beginn;
```

Kein CTE, keine Aggregation → direkt Metabase-faehig, 1 Zeile pro Konflikt-Termin.

**Falsch-Positiv-Filter:** `dauer_min = 1` sind Gruppen-1-Min-Slots (Gruppen-Workaround), kein Einzelkonflikt → `AND (EXTRACT(EPOCH FROM (T.ende - T.beginn)) / 60) > 1`.

**Falsch-Positiv-Filter (Q-KAL-01, Erstlauf 07/2026):** Treffer mit `dauer_min = 1` sind Gruppen-Slot-Header aus
dem Raumkalender-Workaround, keine echten Patiententermine — ausschließen. Hauptursache echter Konflikte sind
**Serientermine**, die beim Sperren stehen bleiben (20 offene Fälle im Erstlauf). Siehe ADR-KAL-01.

## 18. Auslastungsberechnung (Kapazität vs. Belegung)

**Formel:** Auslastung = Belegung / Netto-Kapazität × 100

- **Kapazität** = `infotermin=true`, exkl. Nicht-Patientenzeit (`Doku, Pau, Pause, Urlaub, Org, P&P, Test, Bespr%`)
- **Belegung** = `infotermin=false` mit `patient_ident IS NOT NULL`
- **Netto-Kapazität** = Kapazität abzgl. gesperrte Tage (siehe §17)

Nicht-Patientenzeit-Ausschluss:
```sql
WHERE A.infotermin = true
    AND TRIM(A.terminart_kuerzel) NOT IN ('Doku', 'Pau', 'Pause', 'Urlaub', 'Org', 'P&P', 'Test')
    AND TRIM(A.terminart_kuerzel) NOT ILIKE 'Bespr%'
```
**Ausnahme:** `AIMA` und `AIMA-Besp` SIND Patientenzeit (nicht ausschließen).

## 19. Therapeut-Ermittlung bei Terminen

```sql
COALESCE(T.behandler, KN.kuerzel) AS therapeut
```
Wobei `KN` der Nutzer des Kalenders ist (Fallback wenn `behandler` leer).

## 20. Jahresscharfer Diagnose-JOIN (Pflicht bei Jahresvergleichen)

**Problem:** Wenn Diagnosen ohne Jahresfilter auf die Patientenpopulation gejoint werden, können Patienten eines Jahres Diagnosen aus anderen Jahren beitragen → Prozente >100%.

**Falsch (>100%-Bug):**
```sql
WHERE P.ident IN (SELECT patientID FROM tempPat30700)
```

**Richtig:**
```sql
JOIN tempPat30700 T ON T.patientID = P.ident AND T.jahr = S.jahr
```

Immer wenn `tempPat30700` eine `jahr`-Spalte hat, muss der JOIN auf **beide** Spalten (patientID + jahr) erfolgen.

## 21. 2-Stufen EBM-Euro-Aggregation

**Problem:** `MAX(DET.euroWertInCent)` innerhalb von `SUM()` funktioniert nicht in einer einzigen Aggregationsstufe, weil die Details-Tabelle über eine Bridge gejoint wird und Duplikate erzeugen kann.

**Pattern:**
```sql
-- Stufe 1: Euro pro Leistung (GROUP BY A.ident)
DROP TABLE IF EXISTS tempEBMperLeistung;
CREATE TEMPORARY TABLE tempEBMperLeistung AS
SELECT
    P.ident AS patientID,
    A.ident AS leistungID,
    CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
         THEN (A.anzahl * MAX(DET.euroWertInCent)) / 100.0
         ELSE (A.anzahl * A.prozentDerLeistung5013 * MAX(DET.euroWertInCent)) / 10000.00
    END AS euro
FROM leistung A
LEFT JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (
    DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum)
)
JOIN kvschein S ON A.invkvschein_ident = S.ident
-- ... Patient-JOINs ...
WHERE A.dtype = 'EBMLeistung' AND A.visible = true AND S.visible = true
GROUP BY P.ident, A.ident, A.anzahl, A.prozentDerLeistung5013
;

-- Stufe 2: Aggregation pro Patient
SELECT patientID, SUM(euro) AS ebm_euro
FROM tempEBMperLeistung
GROUP BY patientID
;
```

## 22. GOÄ-Explorer (alle Codes einer Population)

**Zweck:** Explorativ alle GOÄ-Codes sichten, bevor man gezielt filtert. Vermeidet blinde Flecken.

```sql
SELECT
    G.code AS "GOÄ-Code",
    MAX(G.kurztext) AS "Bezeichnung",
    COUNT(DISTINCT P.ident) AS "Patienten",
    COUNT(*) AS "Leistungen",
    ROUND(COUNT(DISTINCT P.ident) * 100.0
        / NULLIF((SELECT COUNT(*) FROM tempPat30700), 0), 1) AS "% der Population"
FROM leistung A
JOIN goaekatalogeintrag G ON A.goaekatalogeintrag_ident = G.ident
LEFT JOIN privatrechnung_goaeleistungen J ON J.goaeleistungen_ident = A.ident
JOIN privatrechnung I ON I.ident = J.privatrechnung_ident
LEFT JOIN patient P ON P.ident = I.patient_ident
WHERE A.dtype = 'GOAELeistung'
    AND A.visible = true
    AND I.visible = true
    AND EXTRACT(YEAR FROM A.datum) = 2025
    AND P.ident IN (SELECT patientID FROM tempPat30700)
GROUP BY G.code
ORDER BY COUNT(DISTINCT P.ident) DESC
LIMIT 40
;
```

**Erkenntnis:** GOÄ 470/490/491/493/497/498 werden in der Praxis nicht verwendet. Immer erst explorieren, dann filtern.

## 23. Quartals-Segmentierung (Chroniker-Analyse)

Dynamische Erkennung auswertbarer Quartale:
```sql
SELECT LEAST(4, EXTRACT(QUARTER FROM LEAST(CURRENT_DATE, DATE '2025-12-31'))::integer) AS max_q;
```

Segmentierung mit dynamischen Labels:
```sql
CASE
    WHEN quartale_count >= max_q THEN '1_Chroniker (' || max_q || '/' || max_q || ' Q)'
    WHEN quartale_count = 1 THEN '4_Einmalig (1/' || max_q || ' Q)'
    WHEN quartale_count >= max_q - 1 THEN '2_Regelmaessig (' || (max_q - 1) || '/' || max_q || ' Q)'
    ELSE '3_Gelegentlich (' || quartale_count || '/' || max_q || ' Q)'
END AS segment
```
Sortierreihenfolge durch Nummernprefix (1_, 2_, 3_, 4_) sichergestellt.

## 24. Haupttherapeut-Ermittlung (DISTINCT ON)

Wer die meisten Karteieinträge der Therapiezeilen-Typen für einen Patienten geschrieben hat
(Kürzel praxiseigen, hier als `<TYP-A>`/`<TYP-B>`/`<TYP-C>`):
```sql
SELECT DISTINCT ON (patientID)
    patientID, therapeut
FROM (
    SELECT patientID, therapeut, COUNT(*) AS cnt
    FROM tempTherapiezeilen
    GROUP BY patientID, therapeut
) sub
ORDER BY patientID, cnt DESC
;
```
Bei Gleichstand gewinnt der alphabetisch erste (PostgreSQL-Determinismus).
DISTINCT ON ist performanter als ROW_NUMBER() für diesen Anwendungsfall.

## 25. Jahresübergangs-Analyse (Kohortenvergleich)

Pattern: Patienten eines Jahres mit Segmentierung in beiden Jahren vergleichen.
Basis: tempPQ2024 (Quartale Jahr 1), tempPQ2025 (Quartale Jahr 2), LEFT JOIN.
`COALESCE(q2025, 0) = 0 → '5_Weg'` für abgewanderte Patienten.
Sortierung: Abwanderung % DESC zeigt Problemsegmente zuerst.

## 26. Wiedervorstellungs-Logik (30700-Tag als Anker)

**Pattern:** 30700-Tag = Erstkontakt im Quartal. Alle anderen Leistungstage = Wiedervorstellung.
```sql
-- Ankertag
MIN(CAST(A.datum AS date)) AS tag_30700  -- pro Patient×Quartal
-- Klassifikation
CASE WHEN E.leistungstag = D.tag_30700 THEN 'Beileistung' ELSE 'WV' END
```
**Bestätigte Beileistungen:** 30704 (99,7% am 30700-Tag). 30702 implizit.
**Administrativ (kein Kontakt):** 40110 (Versandmaterial), 86901 (Labor-Kosten).

## 27. GOÄ-Quartal-Ableitung

GOÄ-Leistungen haben kein `kvschein.quartal`. Quartal wird aus Datum abgeleitet:
```sql
CAST(to_char(A.datum, 'Q') AS integer) AS quartal
```

---

## 28. Patientenliste als Filter (Panel → Patientenliste)

Lädt alle Patienten einer manuell angelegten Liste aus dem Panel → Patientenliste-Feature in eine Temp-Tabelle zur Weiterverarbeitung.

```sql
DROP TABLE IF EXISTS tempListePat;
CREATE TEMPORARY TABLE tempListePat AS
SELECT DISTINCT
    PSE.patient_ident AS patientID
FROM patientenschlange PS
JOIN patientenschlange_schlange PSS 
    ON PS.ident = PSS.patientenschlange_ident
JOIN patientenschlangeelement PSE 
    ON PSS.schlange_ident = PSE.ident
WHERE PS.removed = false
  AND PSE.removed = false
  AND PS.dtype = 'Patientenschlange'
  AND PS.name = 'DEIN_LISTENNAME'   -- ← anpassen
;

-- Weiterverarbeitung in beliebigem Query:
-- WHERE P.ident IN (SELECT patientID FROM tempListePat)
```

**Variante mit Kommentar:**
```sql
DROP TABLE IF EXISTS tempListePat;
CREATE TEMPORARY TABLE tempListePat AS
SELECT DISTINCT
    PSE.patient_ident AS patientID,
    PSE.infotext      AS kommentar,
    PSE.checked        AS abgehakt,
    PSE.datum::date    AS hinzugefuegt_am
FROM patientenschlange PS
JOIN patientenschlange_schlange PSS 
    ON PS.ident = PSS.patientenschlange_ident
JOIN patientenschlangeelement PSE 
    ON PSS.schlange_ident = PSE.ident
WHERE PS.removed = false
  AND PSE.removed = false
  AND PS.dtype = 'Patientenschlange'
  AND PS.name = 'DEIN_LISTENNAME'   -- ← anpassen
;
```

**Explorer: Alle Listen mit Patientenzahl anzeigen:**
```sql
SELECT
    PS.name                           AS "Listenname",
    PS.dtype                          AS "Typ",
    COUNT(DISTINCT PSE.patient_ident) AS "Anzahl Pat"
FROM patientenschlange PS
LEFT JOIN patientenschlange_schlange PSS 
    ON PS.ident = PSS.patientenschlange_ident
LEFT JOIN patientenschlangeelement PSE 
    ON PSS.schlange_ident = PSE.ident
    AND PSE.removed = false
WHERE PS.removed = false
GROUP BY PS.name, PS.dtype
ORDER BY PS.name
;
```

## 29. Hauptbehandler via EBM-30700-Häufigkeit

Ermittelt pro Patient den Arzt mit den meisten EBM 30700 als Hauptbehandler. Robuster als `PD.arzt_ident` (Praxisinhaber-Bias).

```sql
DROP TABLE IF EXISTS temp30700ProArzt;
CREATE TEMPORARY TABLE temp30700ProArzt AS
SELECT
    P.ident                         AS patientID,
    A.leistungserbringer_ident      AS arzt_ident,
    COUNT(*)                        AS anz_30700
FROM leistung A
JOIN ebmkatalogeintrag B    ON A.ebmkatalogeintrag_ident = B.ident
JOIN kvschein S             ON A.invkvschein_ident = S.ident
JOIN patientendetailsrelationen_kvscheine PDRK
                            ON S.ident = PDRK.kvscheine_ident
LEFT JOIN patientendetails PD
                            ON PD.patientendetailsrelationen_ident = PDRK.patientendetailsrelationen_ident
LEFT JOIN patient P         ON P.patientendetails_ident = PD.ident
WHERE A.dtype = 'EBMLeistung'
  AND A.visible = true AND S.visible = true
  AND B.code = '30700'
  AND S.jahr >= 2024   -- Zeitraum anpassen
  AND P.nachname NOT ILIKE '%†'
GROUP BY P.ident, A.leistungserbringer_ident;

DROP TABLE IF EXISTS tempHauptbehandler;
CREATE TEMPORARY TABLE tempHauptbehandler AS
SELECT DISTINCT ON (patientID)
    patientID, arzt_ident, anz_30700
FROM temp30700ProArzt
ORDER BY patientID, anz_30700 DESC, arzt_ident ASC;
```

**Anwendung:** JOIN auf `tempHauptbehandler HB` + `nutzer N ON HB.arzt_ident = N.ident` für Arzt-Kürzel.

---

## 30. No-Show-Basistabelle (Termin-Level mit Therapeut und Alter)

Alle vergangenen Patiententermine mit Therapeut, Altersgruppe und warda-Flag. Nur Therapeuten-Kalender (Outlook-Schatten raus), nur echte Patiententermine.

```sql
DROP TABLE IF EXISTS tempNS_Termine;
CREATE TEMPORARY TABLE tempNS_Termine AS
SELECT
    T.ident                  AS terminID,
    T.patient_ident          AS patientID,
    T.beginn,
    CAST(T.beginn AS date)   AS tag,
    TRIM(TA.kuerzel)         AS terminart,
    COALESCE(T.behandler, KN.kuerzel) AS therapeut,
    T.warda,
    EXTRACT(YEAR FROM AGE(T.beginn, P.geburtsdatum))::integer AS alter_jahre,
    CASE WHEN EXTRACT(YEAR FROM AGE(T.beginn, P.geburtsdatum))::integer <= 67
         THEN 'Erwerbsfähig' ELSE 'Rentner' END AS altersgruppe
FROM termin T
JOIN terminart TA       ON T.terminart_ident = TA.ident
JOIN patient P          ON P.ident = T.patient_ident
LEFT JOIN termin_kalender TK ON TK.termin_ident = T.ident
LEFT JOIN kalender K        ON K.ident = TK.kalender_ident
LEFT JOIN nutzer KN         ON KN.ident = K.nutzer_ident
WHERE TA.infotermin = false
    AND T.patient_ident IS NOT NULL
    AND (T.removed IS NULL OR T.removed = false)
    AND T.beginn >= '2025-11-01'
    AND T.beginn < CURRENT_DATE
    AND P.nachname NOT ILIKE '%†'
    AND K.nutzer_ident IS NOT NULL    -- nur Therapeuten-Kalender
;
```

**Hinweis:** Therapeuten-Kalender-Filter (`K.nutzer_ident IS NOT NULL`) schließt Outlook-Schattenkalender und Raumkalender aus. Für Gruppen-Analysen Raumkalender separat einbeziehen.

**Stufe 1 (warda-basiert):** auf `tempNS_Termine` nach Therapeuten-Whitelist filtern (siehe SKILL §No-Show: Zwei-Stufen-Modell).

---

## 31. EBM-Euro pro Terminart (über Abrechnungsdaten)

## 32. mutabo-Rückschrieb-Detection (zweigleisig)

Das mutabo-Alt-System (pre-11/2025) hat drei Epochen mit unterschiedlichen Markern. Robuste Detection kombiniert Marker-Match (Phase A/B) und Syntax-Match (Phase C):

```sql
-- Klassifikations-Flag pro Karteieintrag
CASE
  -- Phase A + B: explizite Marker
  WHEN ke.text ~ 'XD:MUTABO\.'           THEN 'mutabo_marker'
  WHEN ke.text ~ 'mutabo\.szdd\.de'
    AND kt.kuerzel NOT IN ('DOK','MAIL-Ein','MAIL-Aus')  -- E-Mail-FP ausschließen
                                         THEN 'mutabo_url'
  -- Phase C: Kurzform-Syntax (PSY + kurz + Korff-Score oder MFH-Score-Kopf)
  WHEN kt.kuerzel = 'PSY'
    AND LENGTH(COALESCE(ke.text,'')) < 50
    AND (ke.text ~* 'Korff\s+[0-9]+\.[0-9]+'
      OR ke.text ~* '^MFHW?\s*[-0-9]')  THEN 'mutabo_kurzform'
  -- MPSS-Zeile (separate Zeile pro Rückschrieb-Set)
  WHEN kt.kuerzel = 'PSY'
    AND LENGTH(COALESCE(ke.text,'')) < 40
    AND ke.text ~* '^MPSS\s+([0-9]|[IVX]+|Gesamtstadium)'
                                         THEN 'mutabo_mpss'
  ELSE NULL
END AS mutabo_klass
```

**Header-Identifikation für Set-Aggregation** (nur Phase A + B):
```sql
ke.text ~* '(Schmerz|Quartals)fragebogen abgeschlossen'
```
Phase C hat keinen Header — Sets dort werden nur über Patient + Kalendertag + `mutabo_klass IS NOT NULL` zusammengefasst.

**Volumen-Kalibrierung:** 
- Phase-A-Header: ~Einzel-Dutzend pro Patient, 2022
- Phase-B-Header: ~Einzelstück pro Patient, 11–12/2022
- Phase-C-Einträge: Hauptvolumen, ~4/Jahr pro Stammpatient (Quartalstakt)

Wenn `terminart_ebmleistungen` leer ist, Euro-Wert über tatsächliche Abrechnungen ableiten (Patient × Tag-Matching). Alle 3 Blöcke (2× CREATE + SELECT) müssen in **einem** Batch ausgeführt werden — Temp-Tables überleben nicht zwischen Runs.

```sql
-- Temp 1: Patiententermine
DROP TABLE IF EXISTS tempTerminLeistung;
CREATE TEMPORARY TABLE tempTerminLeistung AS
SELECT T.ident AS termin_id, T.patient_ident,
    TRIM(TA.kuerzel) AS terminart, CAST(T.beginn AS date) AS termin_tag,
    COALESCE(T.behandler, N.kuerzel) AS therapeut
FROM termin T
JOIN termin_kalender TK ON T.ident = TK.termin_ident
JOIN kalender K ON TK.kalender_ident = K.ident
LEFT JOIN nutzer N ON K.nutzer_ident = N.ident
JOIN terminart TA ON T.terminart_ident = TA.ident
WHERE (T.removed IS NULL OR T.removed = false)
    AND TA.infotermin = false AND T.patient_ident IS NOT NULL
    AND K.nutzer_ident IS NOT NULL;

-- Temp 2: EBM-Leistungen (Pfad über kvschein!)
DROP TABLE IF EXISTS tempEBMperTag;
CREATE TEMPORARY TABLE tempEBMperTag AS
SELECT S.patient_ident, CAST(A.datum AS date) AS leistungs_tag,
    B.code AS ebm_code, A.ident AS leistung_id,
    CASE WHEN A.prozentDerLeistung5013 IS NULL OR A.prozentDerLeistung5013 = 0
         THEN (A.anzahl * MAX(DET.euroWertInCent)) / 100.0
         ELSE (A.anzahl * A.prozentDerLeistung5013 * MAX(DET.euroWertInCent)) / 10000.00
    END AS euro
FROM leistung A
JOIN kvschein S ON A.invkvschein_ident = S.ident
JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
LEFT JOIN ebmKatalogEintrag_ebmKatalogEintragDetails J ON B.ident = J.ebmKatalogEintrag_ident
LEFT JOIN ebmKatalogEintragDetails DET ON (DET.ident = J.ebmKatalogEintragDetails_ident
    AND (DET.gueltigVon IS NULL OR DET.gueltigVon <= A.datum)
    AND (DET.gueltigBis IS NULL OR DET.gueltigBis >= A.datum))
WHERE A.dtype = 'EBMLeistung' AND A.visible = true AND S.visible = true
GROUP BY S.patient_ident, CAST(A.datum AS date), B.code, A.ident, A.anzahl, A.prozentDerLeistung5013;

-- Ergebnis: Euro pro Terminart
SELECT TL.terminart,
    COUNT(DISTINCT TL.termin_id) AS termine,
    ROUND((SUM(COALESCE(E.euro, 0)) / NULLIF(COUNT(DISTINCT TL.termin_id), 0))::numeric, 2) AS euro_pro_termin
FROM tempTerminLeistung TL
LEFT JOIN tempEBMperTag E ON TL.patient_ident = E.patient_ident AND TL.termin_tag = E.leistungs_tag
GROUP BY TL.terminart HAVING COUNT(DISTINCT TL.termin_id) >= 5
ORDER BY euro_pro_termin DESC NULLS LAST;
```

**Verknüpfungslogik:** Patient×Tag-Match — alle EBM-Leistungen eines Patienten am Termintag werden dem Termin zugeordnet. Bei mehreren Terminen am gleichen Tag gibt es Doppelzählungen (an der Referenzinstallation valide, weil Tagesklinik-Charakter selten).

## §29 — Formular-Karteieintrag via Dual-Bridge (Patient-Einstieg)

Für Karteieinträge mit `dtype='Formular'` funktioniert der Standard-Pfad über
`_karteieintraege` nicht — beide Bridges müssen gejoint und per `GREATEST`
kombiniert werden.

```sql
FROM karteieintrag ke
  LEFT JOIN patientendetailsrelationen_karteieintraege pdrk
         ON pdrk.karteieintraege_ident = ke.ident
  LEFT JOIN patientendetailsrelationen_formulare pdrf
         ON pdrf.formulare_ident = ke.ident
  LEFT JOIN patientendetails pd
         ON pd.patientendetailsrelationen_ident = GREATEST(
              pdrk.patientendetailsrelationen_ident,
              pdrf.patientendetailsrelationen_ident)
  JOIN patient p ON p.patientendetails_ident = pd.ident
WHERE p.ident = :patientId
  AND ke.dtype = 'Formular'
```

Für die Rohantworten zusätzlich:

```sql
JOIN karteieintrag_formularelemente kfe ON kfe.karteieintrag_ident = ke.ident
JOIN formularelement fe                  ON fe.ident = kfe.formularelemente_ident
-- fe.bezeichner, fe.jsonformkey, fe.wert, fe.listenpos
```

Session-Beleg: 21.04.2026, Patient 32385.

## 37. Leistungs-Codes mit Menge (xN) in STRING_AGG

**Problem:** `STRING_AGG(DISTINCT B.code, '; ')` kollabiert Mehrfachabrechnungen
(z.B. 30708 2× am Tag bei Wiedervorstellung im selben Quartal) zu einem einzigen
Code-Eintrag — die Menge geht verloren.

**Lösung:** Zweistufige Aggregation. Stufe 1 summiert `leistung.anzahl`
(Feld 5005, KV-Multiplikator) pro Patient und Code; Stufe 2 hängt die Menge
nur an, wenn sie > 1 ist.

```sql
SELECT
    pc.patientID,
    STRING_AGG(
        pc.code || CASE WHEN pc.menge > 1 THEN 'x' || pc.menge ELSE '' END,
        '; ' ORDER BY pc.code
    ) AS codes
FROM (
    SELECT P.ident AS patientID, B.code AS code, SUM(A.anzahl) AS menge
    FROM leistung A
    JOIN ebmkatalogeintrag B ON A.ebmkatalogeintrag_ident = B.ident
    -- ... Standard-Patientenpfad über kvschein + WHERE dtype/visible/datum ...
    GROUP BY P.ident, B.code
) pc
GROUP BY pc.patientID;
```

**Robustheit:** `SUM(anzahl)` fängt beide Erfassungsvarianten ab — eine Zeile
mit `anzahl=2` ODER zwei Zeilen mit `anzahl=1` ergeben beide `x2`.

**GOÄ:** Identisches Pattern mit `goaekatalogeintrag` + GOÄ-Pfad
(`privatrechnung_goaeleistungen → privatrechnung`). `anzahlnenner`
(Teilleistungs-Divisor) hier ignorieren — der ist nur für die Euro-Berechnung
relevant, nicht für „wie oft abgerechnet".

## 33. PatF-Zählung — Minimal-Pattern (kein Join zu karteieintragtyp nötig)

Für die Zählung von arzt-direct-Formular-Rückschrieben reichen drei Filter auf
`karteieintrag` selbst, der Join zu `karteieintragtyp` ist überflüssig und war
in Q-PatF-Count v1 die Fehlerursache (`typ_ident` existiert nicht — korrekter
Spaltenname ist `karteieintragtyp_ident`, aber selbst der wird hier nicht
gebraucht).

**Minimalpattern:**

```sql
FROM karteieintrag k
JOIN formulartyp ft ON ft.ident = k.formulartyp_ident
WHERE k.visible        = true
  AND k.dtype          = 'Formular'
  AND k.jsonformsource = 1                       -- arzt-direct-Rückschrieb
  AND ft.name         LIKE 'Patientenformular_%' -- nur PatF
```

**Zusatzbeobachtung:** `k.dokumentierendernutzer_ident` ist bei arzt-direct-
Rückschrieben systematisch `NULL` (Aggregation liefert `versender = 0`).
Das ist kein Datenfehler, sondern Architektur: der Patient ist „Autor", kein
tomedo-Nutzer hat den Eintrag dokumentiert. Nicht als Filter verwenden.

## 34. Reassessment-/Wiedererhebungs-Zählung (>=N gleichartige Ereignisse pro Patient)

**Zweck:** „Ist ein Patient >=2x re-assessiert/re-erhoben worden?" — für Verlaufs-/Reassessment-Kennzahlen (z.B. AGILE B2). Zählt gleichartige Ereignisse (Formulare eines Typs, EBM-Ziffer) pro Patient und bucketet nach Anzahl (1 / 2 / >=3).

**Muster (PatF-Quartalsbogen als dokumentierter Reassessment-Proxy):**
```sql
WITH qtyp AS (                        -- Formulartyp-Ident EINMAL vorauflösen
    SELECT ident FROM formulartyp
    WHERE name LIKE 'Patientenformular_psf-quartal%'
),
boegen AS (
    SELECT P.ident AS patientID, COUNT(DISTINCT k.ident) AS anz
    FROM karteieintrag k
    JOIN patientendetailsrelationen_formulare H ON H.formulare_ident = k.ident
    JOIN patientendetails PD ON PD.patientendetailsrelationen_ident = H.patientendetailsrelationen_ident
    JOIN patient P ON P.patientendetails_ident = PD.ident
    WHERE k.visible = true AND k.dtype = 'Formular' AND k.jsonformsource = 1
      AND k.formulartyp_ident IN (SELECT ident FROM qtyp)   -- statt LIKE über name!
      AND k.datum >= DATE '2025-11-01'
    GROUP BY P.ident
)
SELECT CASE WHEN anz=1 THEN '1' WHEN anz=2 THEN '2' ELSE '>=3' END AS bucket,
       COUNT(*) AS patienten
FROM boegen GROUP BY 1 ORDER BY 1;
```

**Performance-Kern:** Formulartyp-Ident **vorauflösen** (CTE `qtyp`) und `karteieintrag` auf `formulartyp_ident IN (...)` filtern — statt `formulartyp` zu joinen und auf `name LIKE ...` zu filtern. Sargable, vermeidet einen `LIKE` über die gesamte (große) `karteieintrag`-Tabelle; senkte eine mehrminütige Laufzeit auf Sekunden.

⚠ **EBM-Verlaufsziffern als Reassessment-Proxy nur mit Vorsicht:** EBM 30702 (Zusatzpauschale Schmerztherapie) wird praktisch für die **gesamte** 30700-Population abgerechnet (~100 % Deckung), ebenso 30704. `>=2x 30702` misst damit Betreuungs-/Abrechnungskontinuität (Obergrenze), NICHT dokumentierte Re-Erhebung. Für einen dokumentierten Reassessment-Nachweis den Formular-Pfad (>=2 Quartalsbögen) verwenden.

## 35. Nutzer-Aktivitaets-Sessionisierung (Arbeitszeit-Korridor)

Zweck: grobe Arbeitszeitschaetzung eines Nutzers aus zeitgestempelten Events. Liefert einen **Korridor**: Session-Modell als Untergrenze, Tages-Span als Obergrenze. Kein Einzelwert — tomedo hat keinen Login-Audit-Trail.

Eventquellen (alle nutzerattribuiert und mit echter Uhrzeit):

```sql
WITH ev_raw AS (
    SELECT K.datum AS ts FROM karteieintrag K
    WHERE K.visible = true AND K.datum IS NOT NULL
      AND K.dokumentierendernutzer_ident = (SELECT ident FROM nutzer WHERE TRIM(kuerzel) = 'XXX')
    UNION ALL
    SELECT A.erstelltam FROM aufgabe A
    WHERE A.removed = false AND A.erstelltam IS NOT NULL
      AND A.ersteller_ident = (SELECT ident FROM nutzer WHERE TRIM(kuerzel) = 'XXX')
    UNION ALL
    SELECT M.erstellt FROM nachricht M
    WHERE M.removed = false AND M.erstellt IS NOT NULL
      AND M.sender_ident = (SELECT ident FROM nutzer WHERE TRIM(kuerzel) = 'XXX')
),
-- Minutengranular deduplizieren: neutralisiert Batch-Stempel UND
-- Doppelzaehlung, wenn derselbe Nutzer dok + letzterNutzer am KE ist
ev_min AS (
    SELECT DISTINCT date_trunc('minute', ts) AS ts_min,
                    date_trunc('minute', ts)::date AS tag
    FROM ev_raw
    WHERE ts >= DATE '<von>' AND ts < DATE '<bis>'
      AND ts::time <> TIME '00:00:00'
),
thr AS (SELECT g FROM (VALUES (30),(45),(60),(90)) v(g)),
ev_gap AS (
    SELECT t.g, e.tag, e.ts_min,
           EXTRACT(EPOCH FROM (e.ts_min - LAG(e.ts_min)
               OVER (PARTITION BY t.g, e.tag ORDER BY e.ts_min))) / 60.0 AS gap_min
    FROM ev_min e CROSS JOIN thr t
),
ev_sess AS (
    SELECT g, tag, ts_min,
           SUM(CASE WHEN gap_min IS NULL OR gap_min > g THEN 1 ELSE 0 END)
               OVER (PARTITION BY g, tag ORDER BY ts_min) AS sess_id
    FROM ev_gap
),
sess AS (
    SELECT g, tag, sess_id, COUNT(*) AS events,
           EXTRACT(EPOCH FROM (MAX(ts_min) - MIN(ts_min))) / 60.0 AS netto_min
    FROM ev_sess GROUP BY g, tag, sess_id
)
-- Untergrenze: SUM(netto_min) pro Tag/Monat
-- Obergrenze: EXTRACT(EPOCH FROM (MAX(ts_min)-MIN(ts_min)))/60 pro Tag aus ev_min
```

**Regeln:**
- Deduplizierung **vor** der Gap-Berechnung, sonst zaehlen Batch-Stempel als Aktivitaet.
- `ts::time <> TIME '00:00:00'` filtert Eintraege ohne Uhrzeit.
- Monatsaggregation **kalendergenau** (`date_trunc('month', tag)`), nicht ueber den Wochenmontag — sonst wandern Events ueber Monatsgrenzen und erzeugen Scheineinbrueche.
- Keine `::time`-Spalte im finalen SELECT (Serializer Typ 92, siehe lessons-learned.md).
- Ab ~9 Events/aktivem Tag belastbar, darunter markieren.
- `letzternutzer_ident`-Eintraege sind **nicht** einbeziehbar (kein Zeitstempel, siehe lessons-learned.md).

## 36. Lesbarkeits- und Stilmetriken aus Freitext (ohne Inhaltsexport)

Zweck: Schreibstil und Lesbarkeit von Emails oder Karteieintraegen vergleichen, **ohne** dass Inhalte die Datenbank verlassen. Alle Ausgaben sind berechnete Kennzahlen.

**LIX** = Woerter/Saetze + 100 × Langwoerter/Woerter (Langwort = >6 Zeichen).
Deutung: <40 leicht · 40–50 mittel · 50–60 schwer · >60 sehr schwer. Normbereich Geschaeftskorrespondenz 45–55.
Sprachunabhaengig, keine Silbenzaehlung noetig — deshalb LIX und nicht Wiener Sachtextformel oder Flesch.

Normalisierungskette, Reihenfolge ist bindend:

```sql
-- 1. Signaturblock ab Grussformel abschneiden (macht 23-28 % der Laenge aus!)
split_part(txt, 'Mit freundlichen', 1)
-- 2. HTML-Tags UND spitze-Klammer-Adressen entfernen
regexp_replace(..., '<[^>]+>', ' ', 'g')
-- 3. Absatzumbrueche als ASCII-Sentinel sichern, dann Whitespace kollabieren
regexp_replace(..., '(\r?\n){2,}', ' @@ABS@@ ', 'g')
regexp_replace(..., '[ \t\r\n]+', ' ', 'g')
-- 4. Fuer die SATZZAEHLUNG separat maskieren (siehe lessons-learned.md)
```

Tokenisierung und Aggregation:

```sql
CROSS JOIN LATERAL regexp_split_to_table(text_clean,'[^[:alnum:]äöüÄÖÜß]+') AS t(tok)
...
COUNT(*) FILTER (WHERE length(tok) > 0) AS woerter,
COUNT(*) FILTER (WHERE length(tok) > 6) AS langwoerter,
AVG(length(tok)) FILTER (WHERE length(tok) > 0) AS wortlaenge
```

**Robustheitsrangfolge der Metriken** (aus Fehlererfahrung):
1. `wortlaenge` — unberuehrt von Satzzaehlungs- und Markup-Fehlern, belastbarster Einzelwert
2. `zeichen`, `woerter`, `absaetze` — nur vom Markup-Strip betroffen
3. `satzlaenge`, `lix` — von der Satzzaehlung abhaengig, ohne Maskierung unbrauchbar

**Stilmarker als Trefferquoten** — reine Vorkommensprueflung, von allen Messfehlern unberuehrt und daher besonders robust: Deeskalation (`bitte`, `gern`, `Verständnis`, `entschuldig`, `leider`), Konkretheit (`€`, `Frist`, `Rechnungsnummer`, `§`), Hedging (`eventuell`, `möglicherweise`), Form (`Sehr geehrte`), Dialogangebot (`Rückfrage`, `melden Sie sich`).

**Fallenkatalog:**
- Gesamtmediane zweier ungleich grosser Gruppen nicht direkt vergleichen — nach Laengenband stratifizieren (siehe ADR-MAILQ-15).
- Bei gepoolten Terzilen bestimmt die groessere Gruppe die Grenzen. Informativ, aber die kleine Gruppe landet ggf. komplett in einem Band.
- Auffaellige Gleichfoermigkeit von Zeichen-, Wort- und Satzmedianen ueber viele Mails = standardisierter Text, kein Freitext. Guter Klassifikator, wenn kein Betreff verfuegbar ist.
- Das aussagekraeftigste Mass ist nicht der absolute LIX, sondern das **Delta zwischen Vorlage und Freitext derselben Person** — es isoliert die eigene Schreibleistung vom Textsortenniveau.

