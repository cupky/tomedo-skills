---
name: tomedo-statistik-hql
version: 1.0
description: >-
  Erstellt und debuggt HQL-Statistik-Queries (PostgreSQL-Dialekt) fuer das
  tomedo Praxisverwaltungssystem. Verwende diesen Skill IMMER wenn tomedo-HQL,
  tomedo-Statistik, KV-Abrechnung, EBM-/GOAe-Leistungsauswertungen,
  Patientensegmentierung, Karteieintrag-Analysen, Termin-, Kalender- oder
  Sperrtagsauswertungen oder Praxiskennzahlen erwaehnt werden. Auch verwenden
  bei Query bauen, Statistik erstellen, HQL debuggen, Datenmodell-Frage,
  JOIN-Pfad finden, ZS-Filter einbauen, Umsatz berechnen, Chroniker-Analyse,
  Wiedervorstellungen zaehlen, Feld existiert nicht, Query bricht ab, Ergebnis
  unplausibel, oder jede Frage zu tomedo-Tabellen und -Feldern. Der Skill
  enthaelt das vollstaendige Datenmodell, validierte JOIN-Pfade, 37
  Query-Bausteine, ZS-Filter-Syntax und 46 dokumentierte Fehlerquellen.
---

# tomedo HQL-Statistik Skill

**v10 · 2026-08-04.** Basis: ~25 reverse-engineerte Hersteller-Queries, das Zollsoft-Herstellerdokument
(03/2026, 1.056 Tabellen), 11+ validierte Praxis-Queries und die Erkenntnisse aus 11 Analyse-Threads bis 07/2026.

Diese Datei ist absichtlich kurz. Sie enthaelt die **Verbote**, den **Lese-Routing-Plan** und die zwei Tabellen,
die bei fast jeder Query gebraucht werden. Alles Erklaerende steht in `references/` und wird bei Bedarf gelesen,
nicht auf Vorrat.

---

## 1 · Lese-Routing

| Frage oder Situation | Datei |
|---|---|
| Tabelle oder Feld gesucht | `references/datenmodell.md` |
| „Tabelle/Feld nicht gefunden" trotz Suche | `references/datenmodell_ZOLLSOFT_DB-dump.md` (**autoritativ** ueber `datenmodell.md`) |
| Pfad zum Patienten, Nutzer oder Kalender unklar | `references/join-pfade.md` |
| Bewaehrtes Pattern gesucht (37 Bausteine) | `references/query-bausteine.md` |
| Enum-Wert, Bitfeld, tomedo-eigene Funktion | `references/enums-und-funktionen.md` |
| Query soll reproduzierbar / parametrisierbar werden | `references/zs-filter.md` |
| **Query bricht ab · Ergebnis unplausibel · Feld unerwartet leer** | `references/lessons-learned.md` |
| Struktur- oder Beziehungshypothese ueber Core-Data-Introspektion | `references/llm-toolebene.md` (**nachgeordnet** — dokumentiert, ungeprueft, kein Beleg fuer Tabellen- oder Feldnamen) |
| **Neuer Analyseauftrag · Thread-Start · Scope noch offen** | Erst Scope klären: Nenner, Zeitfenster, Population, Abnahmekriterium — **dann** dieser Skill |

**Pflicht vor der ersten Zeile SQL:** `datenmodell.md` fuer die beteiligten Tabellen **und** den passenden
Abschnitt aus `lessons-learned.md` lesen. Dort stehen 46 reproduzierte Fehler, gegliedert nach
A Ausfuehrungsumgebung · B PostgreSQL-Fallen · C Pfade und Geldwerte · D Epochen und Feldrealitaet ·
E fachliche Marker und Codes · F Praxis-Codetabellen.

**Reihenfolge beachten:** Ist der Auftrag noch nicht definiert — Scope, Nenner, Zeitfenster, Definition of Done offen — dann gehoert die Strukturierung vor den Query-Bau und laeuft ueber den Opener-Skill. Dieser Skill setzt eine geklaerte Fragestellung voraus.

**Eine Einzelfallauskunft aus dem KI-Chat ist keine Kennzahl.** Der KarteiChat liefert zu *einem*
Patienten Dokumentation, Diagnosen, Leistungen, Formulare und Laborwerte ohne Query — aber ohne
Aggregation, Nenner und Zeitfenster ueber Faelle hinweg. Solche Auskuenfte duerfen nicht als Wert in
eine Auswertung wandern. Umgekehrt ist die Core-Data-Introspektion (`ListEntities`,
`DescribeEntitySchema`) eine **Hypothesenquelle** fuer Beziehungen, kein Beleg fuer Tabellen- und
Feldnamen: der Export sagt nur `className == entityName` im Objektmodell und nichts ueber die
Abbildung auf die PostgreSQL-Schicht. Der Beleg kommt weiterhin aus
`datenmodell_ZOLLSOFT_DB-dump.md`. Details: `references/llm-toolebene.md`.

---

## 2 · Arbeitsablauf

1. **Ohne ZS-Filter bauen** und gegen Echtdaten testen.
2. **ZS-Filter nachruesten** — erst wenn die Query reproduzierbar sein oder ins Forum gehen soll.
3. **Anonymisieren** (Abschnitt 4).
4. **Abgabecheck** durchlaufen (Abschnitt 3).

Bei mehr als einem Ergebnisblock: ein SELECT pro Ausfuehrung, getrennt mit
`-- ============ HIER TRENNEN: SELECT N ============`.

---

## 3 · Abgabecheck — harte Verbote

Vor jeder Abgabe durchgehen. Jede Zeile ist ein reproduzierter Abbruch oder ein stiller Zahlenfehler;
Details und Codebeispiele in `references/lessons-learned.md`.

| # | Regel | Kategorie |
|---|---|---|
| 1 | **Kein `%`-Zeichen im Query-Text** — auch nicht in Kommentaren. Wildcards ueber `LEFT(TRIM(x), n) = '…'` | A |
| 2 | **Genau ein Semikolon** (Statement-Ende) | A |
| 3 | **Nur ein SELECT pro Ausfuehrung** | A |
| 4 | **Keine System-Katalog-Tabellen** (`pg_tables`, `information_schema`, `pg_catalog`, `pg_stat_*`) — sofortiger tomedo-Crash | A |
| 5 | **Jede Datei selbsttragend** — Temp-Tabellen sterben zwischen Runs | A |
| 6 | **ZS-Tags nur im finalen SELECT**, niemals in `CREATE TEMPORARY TABLE` | A |
| 7 | **`ROUND()` nur mit `::numeric`-Cast**; `percentile_cont()` liefert `double precision` | B |
| 8 | **String-Literale aus CTE/UNION mit `::text` casten** — sonst `unknown`-Typfehler | B |
| 9 | **Mehrzeichige, eindeutige Aliase** — unquotierte Aliase sind case-insensitiv | B |
| 10 | **Jahresspalte im JOIN mitfuehren**, wenn die Population eine hat — sonst Prozente >100 % | C |
| 11 | **Sperrtage nicht in `termin` suchen** — sie liegen in `terminkalendertag.sperrmodus = 1` | D |
| 12 | **Kein `nachname` / `vorname` / `geburtsdatum` im finalen SELECT** (Abschnitt 4) | — |

---

## 4 · Datenschutz by Design

Alle Queries laufen vollstaendig lokal auf der praxiseigenen tomedo-Datenbank. Die KI sieht niemals
Patientendaten direkt: sie baut die Abfrage, der Nutzer fuehrt sie aus und meldet nur aggregierte Ergebnisse
zurueck.

**Finaler SELECT** darf `nachname`, `vorname`, `geburtsdatum` **nicht** enthalten. Stattdessen `patientID`
(= `patient.ident`) zur Zuordnung und `alter_jahre` fuer Altersanalysen. In Temp-Tabellen sind die Spalten als
JOIN-Hilfe in Ordnung, im Ergebnis nicht.

**Aktive Warnung — auch bei ausdruecklicher Anforderung.** Enthaelt eine Query personenbezogene Spalten im
Ergebnis, MUSS die KI proaktiv ausgeben:

> ⚠ **Hinweis:** Diese Query enthaelt personenbezogene Spalten (Name/Geburtsdatum) im Ergebnis. Das Ergebnis ist
> nur fuer die lokale Verwendung in tomedo bestimmt. Bitte pruefe es vor dem Teilen mit der KI und entferne
> Klartextdaten. Fuer die Analyse reichen `patientID` und `alter_jahre`.

**Explorative Queries** (Stichproben, Einzelfallpruefung) duerfen Klarnamen enthalten, damit der Nutzer die
Faelle in tomedo identifizieren kann. Ablauf: Warnung ausgeben → Nutzer fuehrt lokal aus → Nutzer entfernt die
personenbezogenen Spalten, **bevor** er Ergebnisse zurueckmeldet. Alternativ nur `patientID` plus Aggregate
zurueckmelden.

Vor Veroeffentlichung (Forum, Vortrag, Verbandsarbeit): absolute Zahlen gegebenenfalls randomisieren.

---

## 5 · ⛔ Die vier Direkt-Pfad-Korrekturen

Die Zollsoft-Doku 03/2026 listet FK-Shortcuts, die an der Referenzinstallation **nicht tragen**. Korrigierter Stand:

| Feld | Status (Referenzinstallation) | Konsequenz |
|---|---|---|
| `leistung.patient_ident` | **existiert nicht** | Immer Bridge — `kvschein` (EBM) bzw. `privatrechnung_goaeleistungen` (GOÄ) |
| `kvschein.patient_ident` | erst **ab Migration 11/2025** befüllt | Für historische Queries **verboten** — volle Bridge `kvschein → patientendetailsrelationen_kvscheine → patientendetails → patient` |
| `karteieintrag.patient_ident` | **existiert nicht** | Pfad über `patientendetailsrelationen_karteieintraege → patientendetails → patient`; Formular-KE zusätzlich über `_formulare`-Bridge (Dual-Bridge mit `GREATEST()`) |
| `leistung.containedonrechnung_ident` | Feld vorhanden, aber **nicht befüllt** | GOÄ-Pfad über `privatrechnung_goaeleistungen` (`J.goaeleistungen_ident = L.ident`, `J.privatrechnung_ident = I.ident`) |

**Einziger belastbarer Shortcut:** `karteieintrag.termin_ident → termin` (validiert, u.a. für KE-basierte No-Show-Signale).

**Merksatz:** Ein Feld im DB-Dump ist keine Zusage, dass es befüllt ist. Vor Nutzung eines neuen Direkt-FK immer
`COUNT(*) FILTER (WHERE feld IS NOT NULL)` gegen die Gesamtzahl prüfen — drei der vier Shortcuts oben sind genau
daran gescheitert.

---

## 6 · Disziplin-Mapping (interdisziplinaere Analysen)

| Disziplin | Signal | Quelle |
|---|---|---|
| Arzt | EBM 30700 | Leistung → KV-Schein |
| Psychologie | EBM 35xxx oder 232xx | Leistung → KV-Schein |
| Physiotherapie | KE-Typ PHY oder BEF_PHY | Karteieintrag → Patient |

PSY-KE-Typ ist als Psycho-Marker **ungeeignet** (24 Nutzer inkl. Ärzte). 30708 ist kein Interdisziplinaritäts-Marker (auch Arzt-Arzt-Fallkonferenzen).
