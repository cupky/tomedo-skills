---
name: tomedo-navigation
version: 1.0
description: >-
  Belegte Navigationswege, Pflegeorte und Automatisierungsgrenzen der tomedo-Oberflaeche.
  Verwende diesen Skill IMMER wenn gefragt wird, WO in tomedo etwas eingestellt, gepflegt,
  gefunden oder geoeffnet wird — "wo stelle ich X ein", "wo finde ich Y", "welches Menue",
  "Pflegeort", "Admin-Bereich", "Tastenkuerzel", "Verwaltungsfenster", "Menuepfad",
  "Einstellungen vs. Admin". Auch bei: Klickstrecke oder Schulungsunterlage schreiben,
  Menuepfad pruefen, Menuesichtbarkeit je Rolle, Sperrtage- und Kalenderverwaltung finden.
  Ebenso bei tomedo-Automatisierung von aussen: AppleScript, tomedo.sdef, call aktionskette,
  call statistik, Ereignis-Hooks, Toolbar-Buttons, Skript-Platzhalter, tomedo-Deeplinks,
  API-Verwaltung. Und beim LLM-Aufruf aus tomedo: llmservice-Endpunkt, userIdent ermitteln,
  Modellname setzen, Prompt per Env-Variable, HTTP 422 Unbekanntes Modell, Budget per cost.
  NICHT fuer die Konfiguration selbst: Aktionsketten baut tomedo-aktionsketten, Kommandos
  tomedo-kommandos, Queries tomedo-statistik-hql.
---

# tomedo-Navigation, Pflegeorte und Scriptability

Erhoben per Accessibility-Auslesung der laufenden Instanz (nicht aus der Doku),
tomedo **v1.169.0.21** (`com.zollsoft.tomedo-macOS`), Stand 07–08/2026.
Bundle-Analyse aus `tomedo.app` und dem lokalen Core-Data-Cache.

> **Zwei Vorbehalte, die fuer jede Auskunft gelten:**
> 1. **Rollenabhaengig.** Die Menueleiste haengt an den Rechten des eingeloggten Nutzers.
>    Das Top-Level-Menue `Admin` erscheint nur mit Adminberechtigung. Erfasst sind genau
>    zwei Zustaende (ohne / mit Adminrecht) — fuer eine MFA-Rolle fehlt die Erhebung.
> 2. **Kontextabhaengig.** Viele Eintraege sind nur mit selektiertem Patienten oder
>    offener Kartei aktiv. `(inaktiv)` heisst „hier nicht verfuegbar", nicht
>    „existiert nicht".

## Referenzdateien (bei Bedarf laden)

| Datei | Inhalt |
|---|---|
| `references/menue-atlas.md` | Ordnungslogik aller Menues, Kuerzel-Muster, vollstaendige `Admin`-Struktur, Pflegeort-Tabelle je Skill, Migrationsspuren, bekannte Luecken |
| `references/scriptability.md` | `tomedo.sdef`-Kommandoinventar, Skript-Feature (Intervall/Startup/Toolbar/Ereignis-Hooks/Platzhalter), Deeplinks, was **nicht** geht, Sicherheitsbefunde |
| `references/applescript-rezeptbuch.md` | LLM-Aufruf per AppleScript: `llmservice`-Endpunktschema, `userIdent`-Ermittlung, Kartei-Uebergabe per Briefkommando, Env-Variablen-Muster, Rueckkanal, Fehlerdiagnose inkl. HTTP 422, Budget ueber `cost`, Pruefliste |

## Die vier Merkregeln

**1 · Menue nach Handlungsabsicht.**

| Menue | Absicht |
|---|---|
| `Verwaltung` | „Ich will eine **Uebersicht**" — Listen und Verwaltungsfenster oeffnen (der Haupt-Hub) |
| `Aktion` | „Ich will **etwas erzeugen**" — neue Objekte im Patientenkontext |
| `Format` | Textauszeichnung — **und, unerwartet, der `LLM-Textgenerator`** (unterhalb `Schrift` und `Text`) |
| `Formular` | „Ich will ein **Vordruck-Dokument**" — Formulare drucken im Patientenkontext |
| `Panel` | „Ich will ein **Dauer-Fenster daneben**" |
| `Admin` | „Ich will **festlegen, wie tomedo arbeitet**" — Kataloge, Vorlagen, Rechte, Automatisierung |
| `tomedo › Einstellungen ⌘,` | **Arbeitsplatz**-Einstellungen, nicht Systemkonfiguration |

**2 · Das Kuerzel-Muster** — die halbe Navigation in einem Satz:

- **`⇧⌃` + Buchstabe = Liste OEFFNEN** · `⇧⌃P` Patientenuebersicht · `⇧⌃I` Inbox ·
  `⇧⌃N` Nachrichten · `⇧⌃A` Aufgaben · `⇧⌃E` E-Mail/KIM
- **`⌘⇧` + Buchstabe = NEUES Objekt ANLEGEN** · `⌘⇧N` Nachricht · `⌘⇧E` Erinnerung ·
  `⌘⇧T` Aufgabe

Weitere belegte Kuerzel: `⌘L` Tagesliste · `⌘⌥K` Kalender · `⌘⌥S` Statistiken ·
`⌘⇧K` Kassenbuch · `⌥⌃A` Privatabrechnung · `⌥⌃T` Neuer Termin (ohne Patient) ·
`⌘⌥A` Arbeitsunfaehigkeit (1/E) · `⌘⌥⌃R/B/G` Rotes/Blaues/Gruenes Rezept.

**3 · Die Pflegeorte liegen fast alle unter `Admin`, nicht unter `Verwaltung`.**
Wer erklaeren soll, *wo etwas eingerichtet wird*, sucht in `Admin`. Die vollstaendige
Zuordnung Admin-Pfad → Org-Skill steht in `references/menue-atlas.md`.

**4 · Klammerzusatz = umgezogen.** Findet sich „jetzt …", „alte …" oder „(veraltet)",
ist der Pfad umgezogen; tomedo laesst den alten Eintrag als **inaktiven** Wegweiser
stehen (`Aktion › Kalender (jetzt unter Verwaltung)`). Anleitungen, die den alten Pfad
nennen, sind veraltet. **Gegenprobe lohnt bei jeder Pfadangabe in einem Skill.**

## Der schnellste Einstieg bei Navigationsfragen

`Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht` — tomedo hat eine **eingebaute**
Uebersicht aller Verwaltungsfenster. Erste Anlaufstelle, bevor geraten wird.
Fuer Diagnose: `Hilfe › Logs ›` (`tomedo.log`, `tomedo.extra.log`, **Loglevels
Feinschaltung**, `plistHistory.log`).

## Automatisierung: was geht, was nicht

tomedo ist offiziell scriptbar (`NSAppleScriptEnabled = true`, `Resources/tomedo.sdef`) —
ein vom Hersteller vorgesehener Erweiterungspunkt, kategorial etwas anderes als ein
nicht unterstuetzter Direkt-Write in die Datenbank. Das Dictionary ist aber **minimal**:

| Kommando | Wirkung |
|---|---|
| `call aktionskette` | ruft eine Kette per **Kuerzel** auf — **ohne Parameter**. Der Hebel. |
| `call statistik <csv>` | zeigt eine **CSV** im Statistikfenster an. Anzeige-, kein Abfragekanal. |
| `search patient` | oeffnet die Patientensuche mit einem Suchtext |

**Kein Kommando erzeugt tomedo-Objekte direkt** — kein Termin, kein Sperrtag, keine
Aufgabe, kein Karteieintrag. Schreibende Wirkung nur **indirekt** ueber
`call aktionskette`. Und: kein Aktionstyp der Kategorie „Termin & Kalender" schreibt
(alle drei sind interaktiv) — Ganztags-Abwesenheiten laufen ueber das Arbeitszeitkonto,
nicht ueber eine Kette. Details und die Gegenprobe: `references/scriptability.md`.

**Drei harte Grenzen, die jede Planung fruehzeitig kennen muss:**

1. `call aktionskette` nimmt **keine** Parameter. Ausweg: die Aktion „Aktionskette fuer
   alle Listeneintraege nacheinander ausfuehren" iteriert eine Statistik-Ergebnisliste;
   der Kontext kommt aus der Zeile.
2. Eine Aktionskette laeuft **am ausloesenden Arbeitsplatz** — UI-Effekte passieren nur dort.
3. **`$[arbeitsplatz]$`** und `$[nutzerkuerzel]$` loesen das Mehrfachausfuehrungs-Problem
   periodischer Skripte (arbeitsplatzweite Aktivierung → Selbstbeschraenkung im Skript).

## Drei Sicherheits- und Datenschutzregeln dieser Erhebung

1. **Menue `Fenster` traegt PHI.** Fenstertitel enthalten Patientendaten (beobachtet:
   `Nachricht bzgl. <patient_id> - <Nachname Vornamen>`). Jedes Dump-Werkzeug muss
   `Fenster` ueberspringen oder redigieren. AX-Dumps immer auf die Zielperson filtern —
   ein unfilterter Button-Dump zieht den kompletten Mitarbeiter-Roster mit Klarnamen.
2. **Skript-Quelltexte sind kein Ort fuer Geheimnisse.** Der Quelltext liegt im
   **Klartext** in der Server-DB *und* im lokalen Cache **jedes** Arbeitsplatzes.
3. **Erhebung rein lesend.** Menues per Accessibility-API abfragen: kein Klick, kein
   `activate`, kein Fokuswechsel. Wer im Produktivsystem klickt, aendert es.

## Wenn ein Pfad nicht belegt ist

Nicht raten. Die Erhebung hat dokumentierte Luecken — `Einstellungen ⌘,` (Dialoginneres),
Kontextmenues (Rechtsklick), das Innenleben der Verwaltungsfenster, und je Untermenue
maximal 12 Eintraege im Auto-Dump (`Custom-Formulare` +78, `Arztbrief` +49, `KV` +36,
`Patientenformulare` +33; der **Admin-Dump ist vollstaendig**). Fehlt ein Pfad, ist die
ehrliche Antwort „nicht erhoben, hier ist der Nachbarpfad" plus der Hinweis auf
`Hilfe › Hilfswerkzeuge › Verwaltungsfensteruebersicht`.

---

*Stand 2026-08-11 · Quellen: Menueleisten-Dumps (ohne/mit Adminrecht) v1.169.0.21,
`tomedo.sdef`, `ZSKRIPT`-Bestand (30 Skripte), Deeplink-Pilot 08/2026.*
