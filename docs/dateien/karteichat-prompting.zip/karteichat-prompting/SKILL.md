---
name: karteichat-prompting
version: 1.0
description: >-
  Erstellt und debuggt Prompts und Prompt-Ketten fuer den tomedo KarteiChat (Agent mit
  Werkzeugebene; Modell wechselbar ueber den zollsoft-Support). Verwende diesen Skill IMMER
  wenn KarteiChat-Prompts, Multi-Turn-Prompts in tomedo, Briefe via KarteiChat, Berichte aus
  Karteieintraegen, Kurzberichte, Arztbriefe oder Antraege automatisiert generiert werden
  sollen. Auch bei: Prompt rutscht, Modell ignoriert Vorgaben, Filter-Bruch trotz Regeln,
  Output zu lang oder leer, Briefkommando im Prompt, harte Fakten verankern, Anker,
  Guard-Satz, Typdefinition, Modell nennt falsches Datum, Kartei wird nicht durchsucht,
  Anlage wird nicht gelesen, Vorbehalt geht verloren, KarteiChat testen, Testprotokoll. Ebenso bei: welche Tools hat
  der KarteiChat, LLMTool, Toolebene, Werkzeugzugriff, Quellenverknuepfung,
  Zweckbestimmung, Promptverwaltung, Textbaustein als Prompt, Modellwahl im Chat, Flash
  gegen Pro. Der Skill ist ein Navigator; die Inhalte liegen in references/.
---

# tomedo KarteiChat Prompting Skill

Best Practices für Prompts und Prompt-Ketten im tomedo KarteiChat. **Navigator** — die Inhalte liegen in `references/`.

> **Belegbasis:** Prompt-Engineering-Session psychotherapeutischer Kurzbericht (05/2026) und eine kontrollierte Testserie an einer synthetischen Demoakte mit 108 Karteieinträgen (09/2026, 8 Prompt-Varianten, je 3–4 Läufe, rund 40 protokollierte Antworten, Gegenvergleich gegen ein großes Modell bei identischem Input).

**Statuskennzeichnung:** **belegt** = mehrfach beobachtet, Läufe protokolliert · **plausibel** = einmal beobachtet oder abgeleitet · **zu evaluieren** = Vermutung.

---

## Wann diesen Skill verwenden

- Neue KarteiChat-Prompts für strukturierte Outputs (Berichte, Briefe, Anträge)
- Debugging bestehender Prompts, die unzuverlässig laufen
- Prompts, in die Briefkommandos eingebettet werden
- Multi-Turn-Prompt-Ketten entwerfen
- Testprotokolle für KarteiChat-Verhalten aufsetzen
- Vorbereitung von Forumsbeiträgen / Erfahrungsaustausch

**Nicht für:** den Bau von Briefvorlagen selbst (→ `tomedo-kommandos`), statische Textbausteine (→ `tomedo-textbausteine`), HQL-Auswertungen (→ `tomedo-statistik-hql`).

---

## Der Kern in fünf Sätzen

**Briefkommandos werden im KarteiChat-Eingabefeld aufgelöst** — etwa eine Sekunde nach dem Einfügen steht anstelle von `$[…]$` der Datenbankwert. Damit lässt sich eine Tatsache **vorgeben** („Anker"), statt sie das Modell erschließen zu lassen. Ein Anker bringt aber nur einen **Wert** mit, keine **Bedeutung**: die Beschriftung daneben prüft niemand, und ein vorgegebener Wert schlägt die Aktenlage. Gegen diesen Effekt wirken zwei Zusätze — ein **Guard-Satz**, der dem Anker die Unantastbarkeit nimmt, und eine **Typdefinition**, die den Fachbegriff der Frage in Karteieintragstypen ausdrückt. Die Typdefinition ist der wirksamste Baustein, der Guard der billigste, ein **leerer Anker** der gefährlichste Fehler.

> ⚠️ **Widerrufen:** die Skill-v1-Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat" ist falsch und entfernt.

> ⚠️ **Widerrufen (v2.1):** „einfaches Gemini-Modell" als Systemeigenschaft. Der Chat nutzt
> standardmaessig ein Google-Gemini-Modell; andere Modelle stehen auf Anfrage beim
> zollsoft-Support zur Verfuegung [Hersteller, 11.09.2026]. Vor jeder Modellgrenzen-Analyse
> pruefen, **welches** Modell antwortet. Eigene A/B-Messung: der Sprung Flash → Pro bringt
> keinen Qualitaets-, sondern einen **Konstanzsprung** — Laengenstreuung 142 statt 2444
> Zeichen bei gleicher Fachqualitaet [Referenzinstallation, 13.09.2026]. Details in `references/llm-toolebene.md`.

> ⚠️ **Zweckbestimmung.** Der Hersteller grenzt den Chat auf das *Auffinden vorhandener*
> Informationen ein; Auswertung und Interpretation zur Diagnose- und Therapieunterstuetzung
> sind ausgeschlossen [Hersteller, 11.09.2026]. Verdichtungs-Prompts brauchen eine Begruendung.

### Der belegte Fehlerkatalog

| Konstellation | Guard | Typdefinition | Ergebnis (3 Läufe) |
|---|---|---|---|
| Anker falsch beschriftet | – | – | **3/3 falsch**, identisch |
| Anker leer, Nebenfrage | – | – | **3/3 Recherche abgebrochen** |
| Anker löst nicht auf (`-`), Antwortslot | – | – | **3/3 falsch**, lautlos gefüllt |
| Anker falsch beschriftet | ✓ | – | **1/3 richtig**, Streuung inkl. Systemdatum |
| Anker falsch beschriftet | ✓ | ✓ | **3/3 richtig**, Abweichung benannt |
| Kein Anker, Freitext-Extraktion | – | – | **3/3 vollständig richtig** |

### Der stille Inhaltsverlust

Die gefährlichste Abweichung ist die, die **formal korrekt aussieht**. In der A/B-Messreihe
am LLM-Endpunkt erfüllte ein Lauf **alle sechs Prüfkriterien** — drei Rubriken, korrekte
Zeilenanfänge, je zwei Merkmale, keine Formatierungszeichen, fachlich richtig,
literaturgedeckt — und **ließ trotzdem einen von drei geforderten Inhaltsblöcken
vollständig weg**. Ursache: Das Modell schnitt die Rubriken nach einer anderen Achse
(Vergleichsdimensionen statt Sachtypen) und füllte die geforderte Rubrikzahl damit auf.
Das schwächere Modell tat das in 2 von 5 Läufen, das stärkere in 0 von 5.
[Referenzinstallation, 13.09.2026]

**Zwei Regeln folgen daraus:**

1. **Die Gliederungsachse gehört in die Strukturvorgabe.** „Bilde drei Rubriken" reicht
   nicht — es muss stehen, **wonach** gegliedert wird. Eine Zahl allein ist erfüllbar,
   ohne die Aufgabe zu erfüllen.
2. **Vollständigkeit ist ein eigenes Prüfkriterium.** Ein Raster aus Form und Fachlichkeit
   lässt fehlende Inhalte durch. Jeder Testkatalog braucht die Frage: *Kommt jeder
   geforderte Gegenstand im Ergebnis vor?* — getrennt von der Frage, ob das Ergebnis
   richtig ist.

Besonders scharf wird der Effekt, wenn eine **Mengenkappung** auf einen
**Vollständigkeitsanspruch** trifft — etwa im LLM-Textgenerator, dessen ausgelieferte
Vorlage auf 30 Karteieinträge kappt, während der System-Prompt Vollständigkeit verlangt
(`references/llm-textgenerator.md`).

### Der Prompt-Rahmen

```
Harte Fakten aus tomedo:
Aktive Diagnosen: $[x DDI _ _ _ NN NNJN NNNN ICDvornstripMednurAktiveDiagnosen K _]$
Letzter ärztlicher Kontakt: $[d E MN <TYP>]$

Die Angaben oben stammen aus einzelnen Feldern und können veraltet oder leer sein.
Prüfe sie gegen die Kartei. Weiche ab, wenn die Kartei etwas anderes zeigt, und
benenne die Abweichung. Ein leeres Feld bedeutet nicht, dass es den Sachverhalt
nicht gibt.

Ärztliche Kontakte sind Einträge der Typen Anamnese und Therapie. Einträge vom
Typ „Verlauf Physio" und „Verlauf Psychosomatik" sind keine ärztlichen Kontakte.

Aufgabe: <genau eine Aufgabe>. Verwende ausschließlich Daten und Zahlen aus den
Fakten oben und aus der Kartei. Füge keine eigenen Zahlen, Werte oder Zeitangaben
hinzu. Wenn die Akte eine Einschränkung zur Aussagekraft enthält, übernimm sie
wörtlich.
```

Herleitung, Wirkungsnachweise und die Entscheidungsregel „verankern oder nicht" → `references/anker-guard-typdefinition.md`.

---

## Referenz-Routing

| Frage | Datei |
|---|---|
| Was sind Anker, Guard, Typdefinition? Welche Regeln gelten? Verankern oder nicht? | `references/anker-guard-typdefinition.md` |
| Welches Kommando liefert Diagnosen, Daten, Volltexte, CKE- und Formularwerte? Praxiseigene Typkürzel? | `references/kommando-bibliothek.md` |
| Was kann das Modell nicht? Was kann es gut? Was ist überhaupt im Chatkontext? | `references/modellgrenzen-und-quellen.md` |
| Lückentext, Anti-Schmuggel-Liste, Multi-Turn, Arbeitsteilung Kommando ↔ Modell, Anti-Patterns | `references/patterns.md` |
| Wie teste ich einen neuen Prompt, bevor er produktiv geht? | `references/testprotokoll.md` |
| Welche Tools hat der Chat? Was darf er laut Hersteller? Welches Modell antwortet? Was bringt ein Modellwechsel? | `references/llm-toolebene.md` |
| Wie baue ich einen Kontext im LLM-Textgenerator? Wo liegt er? Welche Kappungen hat die Auslieferung? | `references/llm-textgenerator.md` |

---

## Praxis-Workflow für strukturierte Outputs

1. **Zonen festlegen:** welche Inhalte per Kommando, welche vom Modell (`patterns.md`, Pattern 9)
2. **Anker-Block bauen** und jedes Kommando einzeln auf Auflösung prüfen (`kommando-bibliothek.md`, Abschnitt „Pflichtschritt")
3. **Guard- und Typdefinitions-Block einsetzen** (`anker-guard-typdefinition.md`)
4. **Klassifikations-Prompt** mit Whitelist/Conditional/Blacklist-Trias
5. **Generierungs-Prompt** mit Lückentext, Anti-Schmuggel-Liste und Vorbehalts-Auftrag
6. **Im KarteiChat ausprobieren** (Chat leeren, Prompt 1, ≥30 s, Prompt 2)
7. **Testprotokoll fahren** (`testprotokoll.md`)
8. **Bei Versagen** Pattern-Analyse: welcher Constraint ist gerutscht, welcher Baustein fehlt
9. **Bei Erfolg** Prompt-Strang dokumentieren, ggf. als Textbaustein hinterlegen — **mit** Guard- und Definitionsblock, sonst geht die Wirkung beim Kopieren verloren

---

## Verifikations-Checkliste

```
[ ]  1. Eine Aufgabe pro Prompt
[ ]  2. Lückentext wörtlich, Inhaltsangaben in den Platzhaltern
[ ]  3. Anti-Schmuggel-Liste mit konkreten Begriffen
[ ]  4. Begründungs-Templates wörtlich vorgegeben
[ ]  5. Kein interner Self-Check als Qualitätssicherung
[ ]  6. Mehrfachlauf für produktionskritische Outputs
[ ]  7. Jeder Anker einzeln auf Auflösung geprüft
[ ]  8. Beschriftung des Ankers beschreibt die Kommando-Semantik, nicht den Wunsch
[ ]  9. Guard-Block vorhanden, inklusive Leerfeld-Satz
[ ] 10. Typdefinition über Eintrags-Bezeichnungen vorhanden, wo ein Fachbegriff vorkommt
[ ] 11. Jeder Anker hat eine begleitende Aufgabe
[ ] 12. Keine absolute Zeichenzahl als Vorgabe
[ ] 13. Vorbehalts-Auftrag im Prompt, wenn die Ausgabe nach außen geht
[ ] 14. Keine Abhängigkeit von Anlageninhalten
[ ] 15. Erwartungsanker vor dem ersten Lauf notiert
[ ] 16. Aufgelöster Prompt-Text gesichert
[ ] 17. Strukturvorgabe benennt die Gliederungsachse, nicht nur die Anzahl
[ ] 18. Vollständigkeit ist eigenes Prüfkriterium, nicht nur Form und Fachlichkeit
[ ] 19. Kein Satz im Prompt, der als Schreibauftrag lesbar ist, wenn nur gelesen werden soll
```

---

## Referenzen auf andere Skills

- `tomedo-kommandos` — vollständige Kommando- und Konfigurator-Syntax; verbindlich bei allen `$[…]$`-Fragen
- `tomedo-statistik-hql` — dieselben Definitionen als Query; Quelle der Typ-Abgrenzungen
- `tomedo-textbausteine` — statische Bausteine, in denen Prompt-Stränge hinterlegt werden
- `tomedo-patientenformulare` — CKE- und PatF-Felder anlegen, um Werte über die Verankerungslinie zu schieben

---

## Versionsverlauf

- **v1 (05/2026):** Initialversion nach Prompt-Engineering-Session „Psychotherapeutischer Kurzbericht v7". Patterns 1–7, Modellgrenzen-Tabelle, Anti-Patterns. Monolithisch.
- **v2 (09/2026):** Vollständige Neufassung nach Testserie an synthetischer Demoakte, zugleich Umbau auf Navigator plus `references/` (ADR-SKILL-01).
  - **Widerrufen:** die Regel „Keine `$[…]$`-Kommando-Evaluation im KarteiChat".
  - **Neu:** Anker-Guard-Typdefinition-Architektur mit belegtem Fehlerkatalog, Kommando-Bibliothek mit praxiseigenen Typkürzeln, belegte Stärken, Quellengrenzen-Tabelle inklusive Anlagen, vollständiger Prompt-Rahmen, Arbeitsteilung Kommando ↔ Modell, Testprotokoll.
  - **Ergänzt:** sechs neue Modellgrenzen (Ankerbindung, Leerfeld-Kollaps, Anker ohne Auftrag, Zeichenvorgaben, asymmetrischer Informationsverlust, Systemdatum), fünf Anti-Patterns, Checkliste von 6 auf 16 Punkte.
  - **Offen:** Trägerkürzel der „Therapie"-Einträge (praxiseigen, mehrere Kürzel unter einer Bezeichnung), Nutzer-Attribution im Chatkontext, Leistungen im Chatkontext.

---

*Skill v2 · Stand 2026-09-08 · Navigator plus 5 Referenzdateien. Belegbasis: Testserien 1–3 an Demoakte 03 (108 Karteieinträge, 6 Anlagen), Modellvergleich unter Bedingung A (Kartei-Volltext ohne Anlagen, ohne Spezifikations-Metaebenen). Kernaussage: der wirksamste Prompt-Baustein ist die Typdefinition, der billigste der Guard-Satz, der gefährlichste ein leerer Anker.*
